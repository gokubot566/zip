import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: '0.0.0.0',
    // In local dev, forward API calls to the Node audit backend on :7070.
    proxy: {
      '/api': 'http://localhost:7070',
    },
  },
  preview: { port: 7070, host: '0.0.0.0' },
})
