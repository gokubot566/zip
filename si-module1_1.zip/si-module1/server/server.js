/**
 * Security Impossible — Onboarding Audit Backend
 * --------------------------------------------------
 * Minimal Express server that:
 *   1. Serves the built React app (static files from ../dist)
 *   2. Records onboarding sign-in details (first name, last name, email)
 *      to an append-only audit log on the host's filesystem so they can
 *      be reviewed/audited later.
 *
 * Audit data is written to AUDIT_DIR (default /data), which is mounted
 * as a Docker volume so records persist on the Linux host.
 */
const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 7070;
const AUDIT_DIR = process.env.AUDIT_DIR || '/data';
const JSONL_FILE = path.join(AUDIT_DIR, 'onboarding_signins.jsonl');
const CSV_FILE = path.join(AUDIT_DIR, 'onboarding_signins.csv');

// Ensure the audit directory exists.
try {
  fs.mkdirSync(AUDIT_DIR, { recursive: true });
} catch (e) {
  console.error('Could not create audit dir', AUDIT_DIR, e.message);
}

// Write the CSV header once.
if (!fs.existsSync(CSV_FILE)) {
  try {
    fs.writeFileSync(CSV_FILE, 'timestamp,first_name,last_name,email,ip,user_agent\n');
  } catch (e) {
    console.error('Could not initialise CSV file', e.message);
  }
}

app.use(express.json({ limit: '32kb' }));

// Trust the nginx/Docker proxy so req.ip reflects the real client where possible.
app.set('trust proxy', true);

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function csvEscape(v) {
  const s = String(v == null ? '' : v);
  if (/[",\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
  return s;
}

// ─── Record a sign-in ──────────────────────────────────────────────────────
app.post('/api/signin', (req, res) => {
  const { firstName, lastName, email } = req.body || {};

  // Basic server-side validation.
  const fn = (firstName || '').toString().trim().slice(0, 120);
  const ln = (lastName || '').toString().trim().slice(0, 120);
  const em = (email || '').toString().trim().slice(0, 200);

  if (!fn || !ln || !em) {
    return res.status(400).json({ ok: false, error: 'All fields are required.' });
  }
  if (!EMAIL_RE.test(em)) {
    return res.status(400).json({ ok: false, error: 'Please enter a valid email address.' });
  }

  const record = {
    timestamp: new Date().toISOString(),
    firstName: fn,
    lastName: ln,
    email: em,
    ip: req.ip || req.socket?.remoteAddress || '',
    userAgent: (req.headers['user-agent'] || '').toString().slice(0, 400),
  };

  try {
    fs.appendFileSync(JSONL_FILE, JSON.stringify(record) + '\n');
    fs.appendFileSync(
      CSV_FILE,
      [record.timestamp, record.firstName, record.lastName, record.email, record.ip, record.userAgent]
        .map(csvEscape)
        .join(',') + '\n'
    );
  } catch (e) {
    console.error('Failed to write audit record', e.message);
    return res.status(500).json({ ok: false, error: 'Could not record sign-in.' });
  }

  return res.json({ ok: true });
});

// ─── Health check (kept for Docker healthcheck parity) ─────────────────────
app.get('/health', (_req, res) => res.type('text/plain').send('ok'));

// ─── Static app ────────────────────────────────────────────────────────────
const DIST = path.join(__dirname, '..', 'dist');
app.use(express.static(DIST, { extensions: ['html'] }));

// SPA fallback — anything not matched above returns index.html.
app.get('*', (_req, res) => {
  res.sendFile(path.join(DIST, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`SI onboarding server listening on :${PORT}`);
  console.log(`Audit records -> ${JSONL_FILE} and ${CSV_FILE}`);
});
