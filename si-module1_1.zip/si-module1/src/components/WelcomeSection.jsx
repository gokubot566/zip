import { motion } from 'framer-motion';
import { Shield, Target, AlertTriangle, Users, TrendingUp, Eye } from 'lucide-react';

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
  transition: { delay, duration: 0.55, ease: [0.16, 1, 0.3, 1] },
});

function StatCard({ icon: Icon, value, label, color, delay }) {
  return (
    <motion.div {...fadeUp(delay)} style={{
      padding: '20px', borderRadius: 14,
      background: 'rgba(255,255,255,0.03)',
      border: '1px solid rgba(255,255,255,0.06)',
      textAlign: 'center', position: 'relative', overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', inset: 0, opacity: 0.04,
        background: `radial-gradient(circle at 50% 0%, ${color} 0%, transparent 70%)`,
        pointerEvents: 'none',
      }} />
      <div style={{
        width: 40, height: 40, borderRadius: 10, margin: '0 auto 10px',
        background: `rgba(${color.replace('#','').match(/.{2}/g).map(h=>parseInt(h,16)).join(',')},0.15)`,
        border: `1px solid rgba(${color.replace('#','').match(/.{2}/g).map(h=>parseInt(h,16)).join(',')},0.25)`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon size={18} color={color} />
      </div>
      <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 22, fontWeight: 800, color: '#e2e8f0', lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 11, color: '#475569', fontFamily: "'Space Grotesk', sans-serif", marginTop: 4 }}>{label}</div>
    </motion.div>
  );
}

function InfoCard({ icon: Icon, title, body, color, delay }) {
  return (
    <motion.div {...fadeUp(delay)} style={{
      padding: '24px', borderRadius: 16,
      background: 'rgba(255,255,255,0.025)',
      border: '1px solid rgba(255,255,255,0.06)',
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 1,
        background: `linear-gradient(90deg, transparent, ${color}, transparent)`, opacity: 0.5,
      }} />
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
        <div style={{
          width: 44, height: 44, borderRadius: 12, flexShrink: 0,
          background: `rgba(${color.replace('#','').match(/.{2}/g).map(h=>parseInt(h,16)).join(',')},0.12)`,
          border: `1px solid rgba(${color.replace('#','').match(/.{2}/g).map(h=>parseInt(h,16)).join(',')},0.2)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon size={20} color={color} />
        </div>
        <div>
          <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 15, color: '#e2e8f0', marginBottom: 6 }}>{title}</div>
          <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13.5, color: '#64748b', lineHeight: 1.75 }}>{body}</div>
        </div>
      </div>
    </motion.div>
  );
}

export default function WelcomeSection() {
  return (
    <div>
      {/* Hero */}
      <motion.div
        {...fadeUp(0)}
        style={{
          position: 'relative', borderRadius: 20, overflow: 'hidden',
          marginBottom: 32,
          background: 'linear-gradient(135deg, rgba(10,17,34,0.9) 0%, rgba(6,10,18,0.95) 100%)',
          border: '1px solid rgba(99,179,237,0.14)',
          padding: '44px 44px 40px',
        }}
      >
        {/* Grid decoration */}
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.03,
          backgroundImage: 'linear-gradient(rgba(99,179,237,1) 1px,transparent 1px),linear-gradient(90deg,rgba(99,179,237,1) 1px,transparent 1px)',
          backgroundSize: '40px 40px', pointerEvents: 'none',
        }} />
        {/* Glow blobs */}
        <div style={{ position: 'absolute', top: -80, right: -80, width: 300, height: 300, borderRadius: '50%', background: 'radial-gradient(circle,rgba(26,86,219,0.18) 0%,transparent 70%)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', bottom: -60, left: -60, width: 200, height: 200, borderRadius: '50%', background: 'radial-gradient(circle,rgba(14,165,233,0.12) 0%,transparent 70%)', pointerEvents: 'none' }} />

        <div style={{ position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
            <div style={{
              padding: '4px 10px', borderRadius: 20,
              background: 'rgba(14,165,233,0.12)', border: '1px solid rgba(14,165,233,0.25)',
              fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#0ea5e9',
              letterSpacing: '0.1em', fontWeight: 700,
            }}>MODULE 01</div>
            <div style={{
              padding: '4px 10px', borderRadius: 20,
              background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)',
              fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#10b981',
              letterSpacing: '0.06em',
            }}>~15 MINUTES</div>
          </div>

          <h1 style={{
            fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 36,
            color: '#f1f5f9', lineHeight: 1.15, marginBottom: 14,
            background: 'linear-gradient(135deg, #f1f5f9 0%, #94a3b8 100%)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>
            Welcome & Why Security<br />Matters Here
          </h1>

          <p style={{
            fontFamily: "'Space Grotesk', sans-serif", fontSize: 15, color: '#64748b',
            lineHeight: 1.8, maxWidth: 620, marginBottom: 28,
          }}>
            Before you write a line of code, open a client file, or join your first meeting — we need
            to talk about something fundamental. Security at Security Impossible isn't a checklist or a
            compliance exercise. It is the foundation of every client relationship we have, and every
            piece of trust we've worked to build.
          </p>

          {/* Objectives */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {[
              'Understand why we are held to a higher security standard',
              'Recognise your personal role in protecting client trust',
              'Know what confidentiality means from day one',
              'Learn the real-world consequences of security failures',
            ].map((obj, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#0ea5e9', marginTop: 6, flexShrink: 0 }} />
                <span style={{ fontSize: 13, color: '#94a3b8', fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.5 }}>{obj}</span>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Stats row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14, marginBottom: 28 }}>
        <StatCard icon={Target} value="95%" label="Of breaches are preventable" color="#0ea5e9" delay={0.1} />
        <StatCard icon={AlertTriangle} value="$4.6M" label="Average cost of a data breach" color="#f59e0b" delay={0.15} />
        <StatCard icon={Users} value="74%" label="Involve human error or insiders" color="#8b5cf6" delay={0.2} />
      </div>

      {/* Why we're a high-value target */}
      <motion.div {...fadeUp(0.25)} style={{
        padding: '28px 32px', borderRadius: 18, marginBottom: 20,
        background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.06)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8, background: 'rgba(239,68,68,0.12)',
            border: '1px solid rgba(239,68,68,0.2)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Eye size={16} color="#f87171" />
          </div>
          <h2 style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 18, color: '#e2e8f0' }}>
            Why We're a High-Value Target
          </h2>
        </div>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, color: '#64748b', lineHeight: 1.85, marginBottom: 14 }}>
          Security Impossible provides cybersecurity consulting, assurance, and advisory services to organisations
          across financial services, government, infrastructure, and professional services. Our clients trust us
          with some of their most sensitive information — not because we have clever technology, but because they
          believe our people understand the weight of that trust.
        </p>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, color: '#64748b', lineHeight: 1.85, marginBottom: 14 }}>
          That makes us an unusually attractive target. An attacker who gains access to our systems and files could
          obtain a roadmap for attacking <strong style={{ color: '#94a3b8' }}>multiple high-value client organisations simultaneously</strong>.
          This makes a successful attack on us potentially worth far more than an attack on a single client.
        </p>
        <div style={{
          padding: '14px 18px', borderRadius: 10,
          background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.15)',
        }}>
          <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13.5, color: '#fca5a5', lineHeight: 1.7, margin: 0 }}>
            <strong>The assumption that "security people know better, so they won't be targeted" is false.</strong>{' '}
            We are targeted more, not less, precisely because of who we are and what we know.
          </p>
        </div>
      </motion.div>

      {/* Key principle cards */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
        <InfoCard
          icon={Shield} title="Client Trust is Everything"
          body="Every engagement we conduct is based on a client's decision to trust us with access to their systems, their people, and their most sensitive information. That decision is validated or undermined by every interaction our people have."
          color="#0ea5e9" delay={0.3}
        />
        <InfoCard
          icon={TrendingUp} title="Consequences Are Severe"
          body="When security fails at a cybersecurity firm, the consequences are disproportionately severe. Beyond reputational harm, incidents trigger regulatory obligations under the Privacy Act 1988 and the Notifiable Data Breaches scheme."
          color="#f59e0b" delay={0.35}
        />
      </div>

      {/* What security failure actually looks like */}
      <motion.div {...fadeUp(0.4)} style={{
        padding: '28px 32px', borderRadius: 18, marginBottom: 20,
        background: 'rgba(245,158,11,0.04)', border: '1px solid rgba(245,158,11,0.12)',
      }}>
        <h2 style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 18, color: '#e2e8f0', marginBottom: 16 }}>
          What Security Failure Actually Looks Like
        </h2>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, color: '#64748b', lineHeight: 1.85, marginBottom: 16 }}>
          It's easy to imagine security incidents as dramatic events — hackers, ransomware, state-sponsored actors.
          But the vast majority of security incidents are far more ordinary:
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {[
            { icon: '📧', text: 'Forwarding a client report to personal email to "work on it at home"' },
            { icon: '☕', text: "Discussing a sensitive engagement at a café without checking who's listening" },
            { icon: '💾', text: 'Plugging a personal USB drive into a firm laptop' },
            { icon: '🔗', text: 'Clicking a link in an email that seemed legitimate but wasn\'t' },
            { icon: '🖥️', text: 'Leaving a laptop unlocked on a desk when stepping away' },
            { icon: '📌', text: 'Writing a password on a sticky note attached to a monitor' },
          ].map((item, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'flex-start', gap: 10,
              padding: '12px 14px', borderRadius: 10,
              background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.05)',
            }}>
              <span style={{ fontSize: 16, flexShrink: 0 }}>{item.icon}</span>
              <span style={{ fontSize: 12.5, color: '#64748b', fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.5 }}>{item.text}</span>
            </div>
          ))}
        </div>
        <div style={{
          marginTop: 16, padding: '14px 18px', borderRadius: 10,
          background: 'rgba(245,158,11,0.07)', border: '1px solid rgba(245,158,11,0.15)',
        }}>
          <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13.5, color: '#fcd34d', lineHeight: 1.7, margin: 0 }}>
            <strong>None of these acts are malicious.</strong> Most are the result of convenience, habit, or a genuine belief
            that "it won't matter just this once." But every one of them represents a failure of the standard we hold ourselves to.
          </p>
        </div>
      </motion.div>

      {/* Your role */}
      <motion.div {...fadeUp(0.45)} style={{
        padding: '28px 32px', borderRadius: 18,
        background: 'rgba(139,92,246,0.04)', border: '1px solid rgba(139,92,246,0.12)',
      }}>
        <h2 style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 18, color: '#e2e8f0', marginBottom: 14 }}>
          Your Role in the Security Culture
        </h2>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, color: '#64748b', lineHeight: 1.85, marginBottom: 14 }}>
          Security culture is not created by policy documents. It is created by the daily decisions of every person in an
          organisation. When you lock your screen before stepping away from your desk, when you pause before clicking a
          suspicious link, when you speak up because something feels wrong —{' '}
          <strong style={{ color: '#a78bfa' }}>you are the security culture.</strong>
        </p>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, color: '#64748b', lineHeight: 1.85 }}>
          This means being curious about security rather than passive. It means asking questions when you are not sure.
          It means escalating concerns even when you're worried about inconveniencing others. The people who "bother"
          the security team with questions are almost always doing the right thing.
        </p>
      </motion.div>
    </div>
  );
}
