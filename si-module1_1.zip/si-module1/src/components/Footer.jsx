import { motion } from 'framer-motion';
import { Shield, Mail, ChevronRight } from 'lucide-react';

export default function Footer({ onComplete, completed }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3, duration: 0.45 }}
    >
      {/* Completion CTA */}
      {!completed ? (
        <div style={{
          padding: '28px 32px', borderRadius: 18, marginBottom: 24,
          background: 'linear-gradient(135deg,rgba(26,86,219,0.1),rgba(14,165,233,0.06))',
          border: '1px solid rgba(26,86,219,0.2)',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 20,
        }}>
          <div>
            <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 18, color: '#e2e8f0', marginBottom: 6 }}>
              Ready to move on?
            </div>
            <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13.5, color: '#64748b', lineHeight: 1.6, margin: 0, maxWidth: 440 }}>
              Complete the scenario and knowledge check above, then mark this module as complete to unlock Module 2: Confidentiality & Your Obligations.
            </p>
          </div>
          <button
            onClick={onComplete}
            style={{
              padding: '13px 24px', borderRadius: 10, flexShrink: 0,
              background: 'linear-gradient(135deg,#1a56db,#0ea5e9)',
              border: 'none', color: '#fff', cursor: 'pointer',
              fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, fontWeight: 700,
              display: 'flex', alignItems: 'center', gap: 8,
              boxShadow: '0 0 24px rgba(14,165,233,0.25)',
            }}
          >
            Mark Module Complete <ChevronRight size={16} />
          </button>
        </div>
      ) : (
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          style={{
            padding: '28px 32px', borderRadius: 18, marginBottom: 24, textAlign: 'center',
            background: 'linear-gradient(135deg,rgba(16,185,129,0.1),rgba(5,150,105,0.06))',
            border: '1px solid rgba(16,185,129,0.25)',
          }}
        >
          <div style={{ fontSize: 48, marginBottom: 12 }}>🎉</div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 22, color: '#10b981', marginBottom: 8 }}>
            Module 1 Complete!
          </div>
          <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, color: '#64748b', margin: '0 0 16px', maxWidth: 480, marginLeft: 'auto', marginRight: 'auto' }}>
            You've completed the Welcome & Why Security Matters module. Your progress has been saved.
            Continue to Module 2 to learn about your specific confidentiality obligations.
          </p>
          <button style={{
            padding: '11px 22px', borderRadius: 10,
            background: 'rgba(16,185,129,0.15)', border: '1px solid rgba(16,185,129,0.3)',
            color: '#10b981', cursor: 'pointer',
            fontFamily: "'Space Grotesk', sans-serif", fontSize: 13, fontWeight: 700,
            display: 'inline-flex', alignItems: 'center', gap: 8,
          }}>
            Continue to Module 2 <ChevronRight size={15} />
          </button>
        </motion.div>
      )}

      {/* Footer bar */}
      <div style={{
        padding: '18px 24px', borderRadius: 14,
        background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.05)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Shield size={15} color="#1a56db" />
          <span style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 12, color: '#334155' }}>Security Impossible Pty Ltd</span>
          <span style={{ fontSize: 11, color: '#1e293b', fontFamily: "'JetBrains Mono', monospace" }}>— Onboarding Portal v2.0</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Mail size={12} color="#334155" />
            <span style={{ fontSize: 11, color: '#334155', fontFamily: "'JetBrains Mono', monospace" }}>security@securityimpossible.com.au</span>
          </div>
          <div style={{
            padding: '3px 8px', borderRadius: 6,
            background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.15)',
            fontSize: 10, color: '#10b981', fontFamily: "'JetBrains Mono', monospace", fontWeight: 700,
          }}>
            CONFIDENTIAL
          </div>
        </div>
      </div>
    </motion.div>
  );
}
