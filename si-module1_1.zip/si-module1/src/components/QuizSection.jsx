import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { HelpCircle, CheckCircle, XCircle, Award } from 'lucide-react';

const QUESTIONS = [
  {
    id: 1,
    question: "A security consulting firm is an unusually attractive target because:",
    options: [
      "They have expensive equipment worth stealing",
      "Compromising them provides a roadmap for attacking multiple high-value clients simultaneously",
      "Their employees are less technically skilled",
      "They have weak internal security practices",
    ],
    correct: 1,
    explanation: "Security firms hold detailed knowledge of their clients' security postures, including vulnerabilities. This makes a successful attack potentially worth far more than targeting a single client organisation.",
  },
  {
    id: 2,
    question: "Most security incidents are caused by:",
    options: [
      "State-sponsored sophisticated hackers",
      "Malware downloaded from illegal websites",
      "Ordinary actions taken for convenience or habit, without malicious intent",
      "Outdated antivirus software",
    ],
    correct: 2,
    explanation: "The vast majority of incidents result from everyday actions — forwarding files to personal email, leaving screens unlocked, or clicking seemingly legitimate links. Not sophistication, but habit.",
  },
  {
    id: 3,
    question: "From which day do your confidentiality obligations begin?",
    options: [
      "After completing all onboarding modules",
      "After your 3-month probationary period",
      "From day one — they begin immediately upon joining",
      "Once you receive a formal security briefing from the CISO",
    ],
    correct: 2,
    explanation: "Confidentiality obligations begin from the moment you join the organisation. There is no grace period — client information you encounter on your first day is immediately protected.",
  },
  {
    id: 4,
    question: "What is the best response when you are unsure whether something is a security incident?",
    options: [
      "Wait to see if anything bad actually happens before reporting",
      "Try to investigate and resolve it yourself first",
      "Ask a colleague if they think it's serious",
      "Report it to the security team immediately — early reporting dramatically improves outcomes",
    ],
    correct: 3,
    explanation: "Early reporting is critical. If you report a suspicious click within minutes, it may be possible to contain any compromise before it spreads. Waiting always makes outcomes worse.",
  },
];

export default function QuizSection({ onComplete, completed }) {
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [current, setCurrent] = useState(0);

  const allAnswered = QUESTIONS.every(q => answers[q.id] !== undefined);
  const score = submitted ? QUESTIONS.filter(q => answers[q.id] === q.correct).length : 0;
  const perfect = score === QUESTIONS.length;

  function handleAnswer(qId, optIdx) {
    if (submitted) return;
    setAnswers(prev => ({ ...prev, [qId]: optIdx }));
  }

  function handleSubmit() {
    setSubmitted(true);
    if (!completed) onComplete();
  }

  function handleReset() {
    setAnswers({});
    setSubmitted(false);
    setCurrent(0);
  }

  const q = QUESTIONS[current];

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
      style={{ borderRadius: 18, overflow: 'hidden', border: '1px solid rgba(255,255,255,0.07)' }}
    >
      {/* Header */}
      <div style={{
        padding: '18px 28px',
        background: 'linear-gradient(90deg,rgba(139,92,246,0.12),rgba(109,40,217,0.06))',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: 'rgba(139,92,246,0.15)', border: '1px solid rgba(139,92,246,0.25)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <HelpCircle size={17} color="#a78bfa" />
          </div>
          <div>
            <div style={{ fontSize: 10, color: '#334155', fontFamily: "'JetBrains Mono', monospace", letterSpacing: '0.08em', marginBottom: 1 }}>KNOWLEDGE CHECK</div>
            <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 16, color: '#e2e8f0' }}>Module 1 — 4 Questions</div>
          </div>
        </div>
        {!submitted && (
          <div style={{ display: 'flex', gap: 6 }}>
            {QUESTIONS.map((q2, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                style={{
                  width: 28, height: 28, borderRadius: 6,
                  background: current === i ? 'rgba(139,92,246,0.2)' : answers[q2.id] !== undefined ? 'rgba(16,185,129,0.12)' : 'rgba(255,255,255,0.04)',
                  border: current === i ? '1px solid rgba(139,92,246,0.4)' : answers[q2.id] !== undefined ? '1px solid rgba(16,185,129,0.25)' : '1px solid rgba(255,255,255,0.06)',
                  color: current === i ? '#a78bfa' : answers[q2.id] !== undefined ? '#10b981' : '#475569',
                  fontSize: 11, fontFamily: "'JetBrains Mono', monospace", fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                {i + 1}
              </button>
            ))}
          </div>
        )}
      </div>

      <div style={{ padding: '28px', background: 'rgba(255,255,255,0.015)' }}>
        {!submitted ? (
          <>
            {/* Question */}
            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.25 }}
              >
                <div style={{
                  padding: '18px 20px', borderRadius: 12, marginBottom: 18,
                  background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)',
                }}>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                    <div style={{
                      width: 24, height: 24, borderRadius: 6, flexShrink: 0,
                      background: 'rgba(139,92,246,0.15)', border: '1px solid rgba(139,92,246,0.25)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 11, fontFamily: "'JetBrains Mono', monospace", color: '#a78bfa', fontWeight: 700,
                    }}>
                      {current + 1}
                    </div>
                    <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 15, fontWeight: 600, color: '#e2e8f0', lineHeight: 1.5, margin: 0 }}>
                      {q.question}
                    </p>
                  </div>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 20 }}>
                  {q.options.map((opt, i) => {
                    const isSelected = answers[q.id] === i;
                    return (
                      <motion.button
                        key={i}
                        whileHover={{ x: 4 }}
                        onClick={() => handleAnswer(q.id, i)}
                        style={{
                          textAlign: 'left', padding: '13px 16px', borderRadius: 10,
                          background: isSelected ? 'rgba(139,92,246,0.1)' : 'rgba(255,255,255,0.025)',
                          border: isSelected ? '1px solid rgba(139,92,246,0.35)' : '1px solid rgba(255,255,255,0.06)',
                          cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 10,
                          transition: 'all 0.18s',
                        }}
                      >
                        <div style={{
                          width: 22, height: 22, borderRadius: 6, flexShrink: 0,
                          background: isSelected ? 'rgba(139,92,246,0.25)' : 'rgba(255,255,255,0.05)',
                          border: isSelected ? '1px solid rgba(139,92,246,0.4)' : '1px solid rgba(255,255,255,0.08)',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontSize: 10, fontFamily: "'JetBrains Mono', monospace",
                          color: isSelected ? '#a78bfa' : '#475569', fontWeight: 700,
                        }}>
                          {String.fromCharCode(65 + i)}
                        </div>
                        <span style={{ fontSize: 13.5, fontFamily: "'Space Grotesk', sans-serif", color: isSelected ? '#c4b5fd' : '#64748b', lineHeight: 1.4 }}>
                          {opt}
                        </span>
                      </motion.button>
                    );
                  })}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <button
                onClick={() => setCurrent(Math.max(0, current - 1))}
                disabled={current === 0}
                style={{
                  padding: '9px 18px', borderRadius: 8, background: 'rgba(255,255,255,0.04)',
                  border: '1px solid rgba(255,255,255,0.07)', color: current === 0 ? '#1e293b' : '#64748b',
                  fontSize: 13, fontFamily: "'Space Grotesk', sans-serif", cursor: current === 0 ? 'default' : 'pointer',
                }}
              >← Previous</button>

              {current < QUESTIONS.length - 1 ? (
                <button
                  onClick={() => setCurrent(current + 1)}
                  style={{
                    padding: '9px 18px', borderRadius: 8,
                    background: answers[q.id] !== undefined ? 'rgba(139,92,246,0.15)' : 'rgba(255,255,255,0.04)',
                    border: answers[q.id] !== undefined ? '1px solid rgba(139,92,246,0.3)' : '1px solid rgba(255,255,255,0.07)',
                    color: answers[q.id] !== undefined ? '#a78bfa' : '#64748b',
                    fontSize: 13, fontFamily: "'Space Grotesk', sans-serif", cursor: 'pointer',
                  }}
                >Next →</button>
              ) : (
                <button
                  onClick={handleSubmit}
                  disabled={!allAnswered}
                  style={{
                    padding: '9px 22px', borderRadius: 8,
                    background: allAnswered ? 'linear-gradient(135deg,#7c3aed,#5b21b6)' : 'rgba(255,255,255,0.04)',
                    border: 'none', color: allAnswered ? '#fff' : '#334155',
                    fontSize: 13, fontFamily: "'Space Grotesk', sans-serif", fontWeight: 600,
                    cursor: allAnswered ? 'pointer' : 'not-allowed',
                    boxShadow: allAnswered ? '0 0 20px rgba(124,58,237,0.3)' : 'none',
                  }}
                >
                  Submit Answers
                </button>
              )}
            </div>
          </>
        ) : (
          /* Results */
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
            {/* Score */}
            <div style={{
              textAlign: 'center', padding: '28px', marginBottom: 24, borderRadius: 14,
              background: perfect ? 'rgba(16,185,129,0.07)' : 'rgba(139,92,246,0.07)',
              border: `1px solid ${perfect ? 'rgba(16,185,129,0.2)' : 'rgba(139,92,246,0.2)'}`,
            }}>
              <div style={{ fontSize: 52, marginBottom: 8 }}>{perfect ? '🏆' : score >= 3 ? '✅' : '📚'}</div>
              <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 28, fontWeight: 800, color: perfect ? '#10b981' : '#a78bfa', marginBottom: 4 }}>
                {score} / {QUESTIONS.length}
              </div>
              <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, color: '#64748b' }}>
                {perfect ? 'Perfect score! Excellent understanding.' : score >= 3 ? 'Great work! Review the explanations below.' : 'Good effort. Review the explanations and try again.'}
              </div>
            </div>

            {/* Detailed results */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 20 }}>
              {QUESTIONS.map((q2, i) => {
                const userAnswer = answers[q2.id];
                const isCorrect = userAnswer === q2.correct;
                return (
                  <div key={i} style={{
                    padding: '16px 18px', borderRadius: 12,
                    background: isCorrect ? 'rgba(16,185,129,0.05)' : 'rgba(239,68,68,0.05)',
                    border: `1px solid ${isCorrect ? 'rgba(16,185,129,0.18)' : 'rgba(239,68,68,0.15)'}`,
                  }}>
                    <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                      {isCorrect ? <CheckCircle size={15} color="#10b981" style={{ flexShrink: 0, marginTop: 2 }} /> : <XCircle size={15} color="#f87171" style={{ flexShrink: 0, marginTop: 2 }} />}
                      <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13.5, color: '#94a3b8', fontWeight: 600, lineHeight: 1.4 }}>{q2.question}</div>
                    </div>
                    {!isCorrect && (
                      <div style={{ marginLeft: 23, marginBottom: 6 }}>
                        <div style={{ fontSize: 11, color: '#f87171', fontFamily: "'JetBrains Mono', monospace", marginBottom: 2 }}>Your answer: "{q2.options[userAnswer]}"</div>
                        <div style={{ fontSize: 11, color: '#10b981', fontFamily: "'JetBrains Mono', monospace" }}>Correct: "{q2.options[q2.correct]}"</div>
                      </div>
                    )}
                    <div style={{
                      marginLeft: 23, fontSize: 12.5, color: '#475569',
                      fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.6,
                      padding: '8px 10px', background: 'rgba(255,255,255,0.03)', borderRadius: 6, marginTop: 4,
                    }}>
                      💡 {q2.explanation}
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              onClick={handleReset}
              style={{
                padding: '9px 18px', borderRadius: 8, background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.08)', color: '#64748b',
                fontSize: 13, fontFamily: "'Space Grotesk', sans-serif", cursor: 'pointer',
              }}
            >
              Retake Quiz
            </button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
