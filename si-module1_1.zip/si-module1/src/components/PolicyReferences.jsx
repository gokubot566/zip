import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, ChevronDown, ExternalLink, BookOpen } from 'lucide-react';

const POLICIES = [
  {
    id: 'pol-001',
    ref: 'SI-POL-001',
    title: 'Information Security Policy',
    summary: 'The foundational policy governing how all information assets are managed, protected, and handled across the organisation. Applies to all personnel from day one.',
    obligations: [
      'Treat all client information as confidential by default',
      'Report security incidents immediately without delay',
      'Use only approved systems and channels for firm work',
      'Complete mandatory security awareness training annually',
    ],
  },
  {
    id: 'pol-002',
    ref: 'SI-POL-002',
    title: 'Employee Code of Conduct',
    summary: 'Sets out the professional and ethical standards expected of all Security Impossible personnel, including contractors and interns.',
    obligations: [
      'Maintain professional conduct in all interactions',
      'Protect confidential information in all settings, including social situations',
      'Report potential conflicts of interest promptly',
      'Not discuss client matters in public or insecure environments',
    ],
  },
  {
    id: 'pol-003',
    ref: 'SI-POL-003',
    title: 'Acceptable Use Policy',
    summary: 'Defines appropriate use of firm technology, networks, devices, and software. Covers both work and incidental personal use.',
    obligations: [
      'Use firm technology for authorised business purposes',
      'Do not access, store, or transmit material that is illegal or harmful',
      'Do not circumvent security controls for any reason',
      'Do not install unapproved software on firm devices',
    ],
  },
  {
    id: 'pol-004',
    ref: 'SI-POL-004',
    title: 'Confidentiality Policy',
    summary: 'Specific provisions for protecting firm and client confidential information. Includes post-employment obligations.',
    obligations: [
      'Never disclose client identity or engagement details externally',
      'Store confidential information in approved systems only',
      'Confidentiality obligations survive termination of employment',
      'Seek guidance before sharing any information you are unsure about',
    ],
  },
];

export default function PolicyReferences() {
  const [expanded, setExpanded] = useState(null);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      style={{
        borderRadius: 18, overflow: 'hidden', border: '1px solid rgba(255,255,255,0.07)',
        marginBottom: 24,
      }}
    >
      {/* Header */}
      <div style={{
        padding: '18px 28px',
        background: 'linear-gradient(90deg,rgba(16,185,129,0.1),rgba(5,150,105,0.06))',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <div style={{
          width: 36, height: 36, borderRadius: 10,
          background: 'rgba(16,185,129,0.15)', border: '1px solid rgba(16,185,129,0.25)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <BookOpen size={17} color="#10b981" />
        </div>
        <div>
          <div style={{ fontSize: 10, color: '#334155', fontFamily: "'JetBrains Mono', monospace", letterSpacing: '0.08em', marginBottom: 1 }}>POLICY REFERENCES</div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 16, color: '#e2e8f0' }}>Referenced Policies — Module 1</div>
        </div>
        <div style={{ marginLeft: 'auto', padding: '3px 10px', borderRadius: 12, background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)', fontSize: 10, color: '#10b981', fontFamily: "'JetBrains Mono', monospace" }}>
          4 POLICIES
        </div>
      </div>

      <div style={{ background: 'rgba(255,255,255,0.015)', padding: '16px 20px' }}>
        {POLICIES.map((policy, i) => (
          <div key={policy.id} style={{ marginBottom: i < POLICIES.length - 1 ? 8 : 0 }}>
            <button
              onClick={() => setExpanded(expanded === policy.id ? null : policy.id)}
              style={{
                width: '100%', textAlign: 'left', padding: '14px 16px', borderRadius: 10,
                background: expanded === policy.id ? 'rgba(16,185,129,0.07)' : 'rgba(255,255,255,0.025)',
                border: `1px solid ${expanded === policy.id ? 'rgba(16,185,129,0.2)' : 'rgba(255,255,255,0.06)'}`,
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12,
                transition: 'all 0.2s',
              }}
            >
              <div style={{
                width: 36, height: 36, borderRadius: 8, flexShrink: 0,
                background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <FileText size={15} color="#64748b" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#10b981', fontWeight: 700 }}>{policy.ref}</span>
                </div>
                <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13.5, fontWeight: 600, color: '#94a3b8' }}>{policy.title}</div>
              </div>
              <motion.div animate={{ rotate: expanded === policy.id ? 180 : 0 }} transition={{ duration: 0.2 }}>
                <ChevronDown size={14} color="#334155" />
              </motion.div>
            </button>

            <AnimatePresence>
              {expanded === policy.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.28 }}
                  style={{ overflow: 'hidden' }}
                >
                  <div style={{
                    padding: '14px 16px 14px',
                    margin: '4px 0 0 0',
                    borderRadius: '0 0 10px 10px',
                    background: 'rgba(16,185,129,0.04)',
                    border: '1px solid rgba(16,185,129,0.12)', borderTop: 'none',
                  }}>
                    <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13, color: '#64748b', lineHeight: 1.7, marginBottom: 12 }}>
                      {policy.summary}
                    </p>
                    <div style={{ fontSize: 10, color: '#10b981', fontFamily: "'JetBrains Mono', monospace", marginBottom: 8, letterSpacing: '0.06em' }}>
                      YOUR OBLIGATIONS UNDER THIS POLICY
                    </div>
                    <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                      {policy.obligations.map((ob, j) => (
                        <li key={j} style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
                          <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#10b981', marginTop: 7, flexShrink: 0 }} />
                          <span style={{ fontSize: 12.5, color: '#64748b', fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.5 }}>{ob}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
