/* ============================================================================
 * ScenarioPreview.jsx — STANDALONE LIVE PREVIEW of the Module 1 cast scenario
 * ----------------------------------------------------------------------------
 * Drop this anywhere and render <ScenarioPreview /> to verify the character-
 * based scenario in isolation — no login gate, no module shell, no backend.
 *
 * Two ways to use it:
 *
 *   1) Inside this project (recommended — uses the real cast portraits):
 *        // src/main.jsx
 *        import ScenarioPreview from './components/ScenarioPreview.jsx'
 *        import './index.css'
 *        ReactDOM.createRoot(document.getElementById('root'))
 *          .render(<ScenarioPreview />)
 *      then:  npm run dev   →   open http://localhost:5173
 *
 *   2) Quick check of the LOGIC/COPY only, outside the project:
 *        set USE_LOCAL_PHOTOS = false below. Portraits fall back to a coloured
 *        monogram so the file has zero asset/CSS dependencies and runs in any
 *        React sandbox. (Inside the project keep it true for the real photos.)
 *
 * The scenario content + branching here is identical to the production version
 * wired into Module 1; this file just gives you a self-contained harness.
 * ========================================================================== */

import { useState, useMemo, useRef } from 'react';

/* Flip to false to run with no image/CSS deps (monogram avatars). */
const USE_LOCAL_PHOTOS = true;

/* ── Cast roster (constant identity colours) ─────────────────────────────── */
const CHARACTERS = {
  elena:   { name: 'Elena Vasquez', role: 'People & Compliance Lead',      color: '#6366f1', file: 'character-5.png' },
  marcus:  { name: 'Marcus Chen',   role: 'Head of IT & Security Ops',     color: '#3b82f6', file: 'character-4.png' },
  priya:   { name: 'Priya Patel',   role: 'CISO',                          color: '#10b981', file: 'character-1.png' },
  david:   { name: 'David Okafor',  role: 'Managing Director',             color: '#f59e0b', file: 'character-2.png' },
  auditor: { name: 'Hannah Wong',   role: 'External Auditor',              color: '#06b6d4', file: 'character-3.png' },
};

/* Resolve portraits from the project's bundled assets when available. Vite
 * inlines these at build time; the try/catch keeps the file runnable in a
 * bare sandbox where the assets don't exist. */
let PHOTOS = {};
if (USE_LOCAL_PHOTOS) {
  try {
    const mods = import.meta.glob('../assets/cast/character-*.png', { eager: true, as: 'url' });
    for (const [id, c] of Object.entries(CHARACTERS)) {
      const hit = Object.entries(mods).find(([p]) => p.endsWith(c.file));
      if (hit) PHOTOS[id] = hit[1];
    }
  } catch { /* sandbox without assets — fall through to monograms */ }
}

/* ── Scenario data (mirror of src/modules/scenario1.js) ──────────────────── */
const META = {
  kicker: 'Interactive Scenario',
  player: 'You — Security Analyst, Week 1',
  title: 'Day Two: The Prospect Question',
  summary:
    "It is your second day at Security Impossible. Over the next few hours you will hit four small, " +
    "ordinary moments where the right instinct protects the firm — and the wrong one quietly puts a " +
    "client relationship at risk. Work through them with the team.",
};

const SCENES = [
  {
    id: 's1', act: 'Act 1 — The Welcome', title: 'Why any of this matters',
    setting: "9:14 AM. You're in a small meeting room for your day-two induction. Elena from People & Compliance has your laptop ready; Priya, the CISO, drops in for five minutes between meetings.",
    dialogue: [
      { s: 'elena', t: "Morning. Yesterday was paperwork — today is the part that actually matters. Before any policy, I want you to understand *why* we're strict." },
      { s: 'priya', t: "Quick version from me, then I'll get out of your way. We're a security firm. Clients hand us their crown jewels — their networks, their weak spots, their people. The only reason they do that is trust." },
      { s: 'priya', t: "So here's the question I ask every new hire on day two…" },
    ],
    prompt: "Priya asks: \"Why do you think a confidentiality slip hurts a firm like us more than it would hurt, say, a normal software company?\"",
    options: [
      { id: 'a', text: "Because we hold more data than most companies do.", score: 'poor',
        reaction: { s: 'priya', t: "Volume isn't really it — plenty of firms hold more data than we do. Think about what we *sell*." },
        feedback: "Not the core reason. It isn't the quantity of data — it's that our entire product is trust. A security firm that can't keep a secret has nothing to sell." },
      { id: 'b', text: "Because our whole business is built on clients trusting us to protect them — a slip breaks that premise entirely.", score: 'best',
        reaction: { s: 'priya', t: "Exactly. We sell trust. If we can't protect information ourselves, why would anyone let us near theirs? That's existential for us in a way it isn't for most companies." },
        feedback: "Right on target. Security Impossible sells trust. A breach doesn't just cause a legal problem — it undermines the reason clients hire us at all. That's why our internal bar is higher than what we recommend to others." },
      { id: 'c', text: "Because the legal penalties for security firms are higher than for other businesses.", score: 'poor',
        reaction: { s: 'priya', t: "The law applies to everyone the same way. The harm to *us* is reputational and commercial — it's about credibility." },
        feedback: "Penalties aren't firm-specific. The disproportionate harm is to credibility: our value proposition is that we can be trusted with sensitive things. Lose that and the legal fine is the smaller problem." },
    ],
  },
  {
    id: 's2', act: 'Act 2 — When Do The Rules Start?', title: 'The grace-period myth',
    setting: "10:40 AM. Elena is walking you through the policy library. You mention, half-joking, that you'll \"properly read all of these once onboarding is finished.\" Marcus, Head of IT & Security Ops, overhears from the next desk.",
    dialogue: [
      { s: 'marcus', t: "Ha — sorry to eavesdrop. Just want to flag one thing people get wrong, because it's the one that bites." },
      { s: 'elena',  t: "He's right to. It's the single most common day-one misunderstanding." },
      { s: 'marcus', t: "People assume there's a grace period — that the rules switch on once you've finished the course or passed probation. So when do *you* think your confidentiality obligations actually begin?" },
    ],
    prompt: "Marcus asks: \"When do your obligations around confidentiality and data handling start?\"",
    options: [
      { id: 'a', text: "Once I've completed all 11 onboarding modules.", score: 'poor',
        reaction: { s: 'marcus', t: "That's the myth exactly. If that were true, your first two days would be a free-for-all — and you've already had access to things." },
        feedback: "This is the grace-period myth. Finishing the course doesn't switch obligations on — the employment relationship already did, on day one." },
      { id: 'b', text: "When I first get access to a live client engagement.", score: 'ok',
        reaction: { s: 'marcus', t: "Closer — but you don't need to be on an engagement to overhear or see confidential things. You already can." },
        feedback: "Partly right in spirit, but too narrow. You don't have to touch a client file to leak one — a hallway conversation or a visible screen counts. Obligations cover everything from day one." },
      { id: 'c', text: "On my first day — before the course, before probation, before any client work.", score: 'best',
        reaction: { s: 'marcus', t: "That's it. No grace period. The moment you walked in, you were inside the perimeter — and some of these obligations outlast your employment, too." },
        feedback: "Correct. Your obligations begin on day one and many continue after you leave. There is no warm-up period — awareness has to start immediately." },
    ],
  },
  {
    id: 's3', act: 'Act 3 — The Coffee-Shop Question', title: 'A friend asks who your clients are',
    setting: "6:30 PM. You're at a café after work. A friend from another company is genuinely curious about your new job. It's relaxed, friendly, completely informal — exactly the setting where slips happen.",
    dialogue: [
      { s: 'auditor', t: "(Hannah, SI's external auditor, happens to be at the next table reviewing files. She isn't watching you — but this is precisely the kind of moment I write up in assessments.)" },
    ],
    prompt: "Your friend leans in: \"So what does Security Impossible actually do? Who are your big clients — anyone I'd recognise?\" How do you answer?",
    options: [
      { id: 'a', text: "\"We do work for a couple of big banks and a government department. Last week we found some really critical stuff on one of them.\"", score: 'poor',
        reaction: { s: 'auditor', t: "(That just disclosed client sectors, implied identities, *and* a live finding. In an audit, that's a confirmed confidentiality breach — informal setting or not.)" },
        feedback: "This names sectors, hints at clients, and reveals an engagement finding. The 'friendly setting' offers no protection — this is exactly the accidental breach the policy is written to prevent." },
      { id: 'b', text: "\"Between us — mostly finance and government work. Can't say more than that.\"", score: 'poor',
        reaction: { s: 'auditor', t: "('Between us' has no legal weight, and a sector hint still narrows the field enough for someone to guess. Still a slip.)" },
        feedback: "'Between us' creates no protection, and even a sector hint helps an observer reconstruct our client base. When in doubt, share nothing specific." },
      { id: 'c', text: "\"We do cybersecurity consulting — assessments and advisory. I can't name clients or describe projects, but there's a good feel for the work on our public website.\"", score: 'best',
        reaction: { s: 'auditor', t: "(Textbook. Describes only what's already public, protects client relationships, redirects to a legitimate source. Nothing to write up.)" },
        feedback: "Exactly right. You described the firm in already-public terms, protected client identity, and pointed to a legitimate source — warm, professional, and fully compliant." },
    ],
  },
  {
    id: 's4', act: 'Act 4 — The Stakes, Made Real', title: 'What a single slip actually costs',
    setting: "Next morning, 8:55 AM. David, the Managing Director, catches you by the coffee machine. He's warm but he wants to make one thing land before you start real work.",
    dialogue: [
      { s: 'david', t: "Heard your induction went well — welcome aboard properly. One story before you dive in, because numbers don't stick but this does." },
      { s: 'david', t: "Years ago, at another firm, someone mentioned a client's name at a conference dinner. Harmless, they thought. That client heard about it, lost confidence, and walked. We lost the account and three referrals that came with it." },
      { s: 'priya', t: "And that's the part people miss — it's never just one relationship." },
    ],
    prompt: "David asks: \"So — in your own words, why does one careless comment carry so much weight here?\"",
    options: [
      { id: 'a', text: "\"Because it could lead to a regulatory fine for the company.\"", score: 'ok',
        reaction: { s: 'david', t: "A fine might come, sure. But the thing that actually ended that account wasn't a regulator — it was lost confidence." },
        feedback: "Fines are possible but secondary. The deeper cost is reputational: trust is hard to win and instant to lose, and lost trust takes clients and their referrals with it." },
      { id: 'b', text: "\"Because trust is our whole product — one slip can cost a client, their referrals, and the firm's credibility, far beyond the single careless moment.\"", score: 'best',
        reaction: { s: 'david', t: "That's exactly the instinct I want you carrying into every engagement. You've got it. Welcome to the team." },
        feedback: "Spot on. The harm is disproportionate because trust is the product. A single slip can cascade into lost clients, lost referrals, and lasting reputational damage." },
      { id: 'c', text: "\"Because most breaches are deliberate, so we have to assume bad intent everywhere.\"", score: 'poor',
        reaction: { s: 'david', t: "Other way round, actually — almost all of them are accidents. That café comment yesterday? Nobody meant harm. That's the whole point." },
        feedback: "The opposite is true: most breaches are accidental, not malicious. That's precisely why everyday awareness — not suspicion of everyone — is the real defence." },
    ],
  },
];

const DEBRIEF = {
  title: 'Debrief — You\u2019ve got the instinct',
  lines: [
    { s: 'elena', t: "That's the scenario. Notice none of these were dramatic — a question, a comment, a casual chat. That's where real risk lives." },
    { s: 'priya', t: "You've internalised the four things that matter most: trust is the product, obligations start on day one, client identity is confidential, and the careful instinct beats any checklist." },
    { s: 'david', t: "Carry that into every engagement and you'll do well here. On to Module 2." },
  ],
  takeaways: [
    'Security Impossible sells trust — our own security posture is the proof of our credibility.',
    'Obligations begin on day one and many survive the end of employment.',
    'Client identity — the very fact of who our clients are — is itself confidential.',
    'Most breaches are accidental; everyday awareness is your strongest defence.',
  ],
};

/* ── Avatar (real photo if available, otherwise coloured monogram) ───────── */
function Avatar({ id, size = 40, speaking = true }) {
  const c = CHARACTERS[id];
  if (!c) return null;
  const ring = { boxShadow: speaking
    ? `0 0 0 3px ${c.color}, 0 0 0 6px ${c.color}33`
    : `0 0 0 2px ${c.color}` };
  if (PHOTOS[id]) {
    return (
      <span style={{
        width: size, height: size, borderRadius: '50%', overflow: 'hidden',
        display: 'inline-block', flexShrink: 0, lineHeight: 0, background: '#ecedf0',
        opacity: speaking ? 1 : 0.55, filter: speaking ? 'none' : 'grayscale(0.45)', ...ring,
      }}>
        <img src={PHOTOS[id]} alt={c.name} draggable="false"
          style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
      </span>
    );
  }
  // Monogram fallback (sandbox / no assets)
  return (
    <span style={{
      width: size, height: size, borderRadius: '50%', flexShrink: 0,
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      background: c.color, color: '#fff', fontFamily: "'Inter', sans-serif",
      fontWeight: 700, fontSize: size * 0.4, ...ring,
    }}>
      {c.name.split(' ').map(w => w[0]).join('')}
    </span>
  );
}

function Line({ s, t }) {
  const c = CHARACTERS[s];
  if (!c) return null;
  return (
    <div style={{ display: 'flex', gap: 11, marginBottom: 12, alignItems: 'flex-start' }}>
      <Avatar id={s} size={40} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 4 }}>
          <span style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 13, color: '#0f1117' }}>{c.name}</span>
          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 10, color: c.color }}>{c.role}</span>
        </div>
        <div style={{
          padding: '11px 14px', background: '#fff', border: '1px solid #e2e4e9',
          borderLeft: `3px solid ${c.color}`, borderRadius: '4px 9px 9px 9px',
          fontFamily: "'Inter', sans-serif", fontSize: 14, color: '#3d4350', lineHeight: 1.6,
        }}>{t}</div>
      </div>
    </div>
  );
}

const TONE = {
  best: { bd: '#86efac', bg: '#f0fdf4', chip: '#dcfce7', fg: '#166534', icon: '#16a34a', mark: '✓' },
  ok:   { bd: '#fcd34d', bg: '#fffbeb', chip: '#fef3c7', fg: '#92400e', icon: '#b45309', mark: '~' },
  poor: { bd: '#fca5a5', bg: '#fef2f2', chip: '#fee2e2', fg: '#991b1b', icon: '#dc2626', mark: '✗' },
};

function Scene({ scene, onAdvance }) {
  const [sel, setSel] = useState(null);
  const speakers = useMemo(() => [...new Set(scene.dialogue.map(d => d.s))], [scene]);
  const tone = sel ? TONE[sel.score] : null;
  const canAdvance = sel && sel.score === 'best';

  return (
    <div>
      <div style={{ padding: '12px 15px', background: '#f8f9fa', border: '1px solid #e2e4e9', borderRadius: 7, marginBottom: 16 }}>
        <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', letterSpacing: '0.06em', marginBottom: 7 }}>SETTING</div>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: '#3d4350', lineHeight: 1.7, margin: 0 }}>{scene.setting}</p>
      </div>

      <div style={{ padding: '12px 15px', background: '#fff', border: '1px solid #e2e4e9', borderRadius: 7, marginBottom: 16 }}>
        <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', letterSpacing: '0.06em', marginBottom: 11 }}>IN THE ROOM</div>
        <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
          {speakers.map(id => (
            <div key={id} style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <Avatar id={id} size={34} />
              <div style={{ lineHeight: 1.2 }}>
                <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 12.5, color: '#0f1117' }}>{CHARACTERS[id].name.split(' ')[0]}</div>
                <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 9.5, color: CHARACTERS[id].color }}>{CHARACTERS[id].role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ marginBottom: 18 }}>{scene.dialogue.map((d, i) => <Line key={i} {...d} />)}</div>

      <div style={{ padding: '13px 16px', background: '#f3f0ff', border: '1px solid #c4b5fd', borderRadius: 8, marginBottom: 14, fontFamily: "'Inter', sans-serif", fontSize: 14.5, fontWeight: 500, color: '#3d1a78', lineHeight: 1.6 }}>{scene.prompt}</div>

      <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', letterSpacing: '0.06em', marginBottom: 10 }}>YOUR MOVE</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {scene.options.map((opt, i) => {
          const isSel = sel?.id === opt.id;
          const dimmed = sel && !isSel;
          const t = TONE[opt.score];
          return (
            <button key={opt.id} onClick={() => !sel && setSel(opt)} disabled={!!sel}
              style={{
                textAlign: 'left', padding: '12px 15px', borderRadius: 8, width: '100%',
                border: `1px solid ${isSel ? t.bd : '#e2e4e9'}`, background: isSel ? t.bg : '#f8f9fa',
                cursor: sel ? 'default' : 'pointer', display: 'flex', alignItems: 'flex-start', gap: 12,
                opacity: dimmed ? 0.35 : 1, transition: 'all 0.14s',
              }}>
              <span style={{
                width: 24, height: 24, borderRadius: 5, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: isSel ? t.chip : '#fff', border: `1px solid ${isSel ? t.bd : '#e2e4e9'}`,
                fontFamily: "'DM Mono', monospace", fontSize: 11, fontWeight: 600, color: isSel ? t.icon : '#9ca3af', marginTop: 1,
              }}>{isSel ? t.mark : String.fromCharCode(65 + i)}</span>
              <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, lineHeight: 1.55, color: isSel ? t.fg : '#3d4350' }}>{opt.text}</span>
            </button>
          );
        })}
      </div>

      {sel && (
        <div style={{ marginTop: 16 }}>
          <div style={{ marginBottom: 12 }}><Line {...sel.reaction} /></div>
          <div style={{ padding: '14px 16px', borderRadius: 8, background: tone.bg, border: `1px solid ${tone.bd}`, display: 'flex', gap: 10 }}>
            <span style={{ color: tone.icon, fontWeight: 700, flexShrink: 0 }}>{tone.mark}</span>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, lineHeight: 1.7, margin: 0, color: tone.fg }}>{sel.feedback}</p>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 14 }}>
            {canAdvance
              ? <button onClick={onAdvance} style={{ padding: '9px 20px', borderRadius: 7, background: '#6d28d9', border: '1px solid #5b21b6', color: '#fff', fontFamily: "'Inter', sans-serif", fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Continue →</button>
              : <button onClick={() => setSel(null)} style={{ padding: '9px 16px', borderRadius: 7, background: '#fff', border: '1px solid #e2e4e9', color: '#6b7280', fontFamily: "'Inter', sans-serif", fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>↺ Try a different response</button>}
          </div>
        </div>
      )}
    </div>
  );
}

export default function ScenarioPreview() {
  const [step, setStep] = useState(0);
  const total = SCENES.length;
  const atDebrief = step >= total;
  const top = useRef(null);
  const pct = Math.round((Math.min(step, total) / total) * 100);

  const advance = () => {
    setStep(s => Math.min(s + 1, total));
    requestAnimationFrame(() => top.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
  };

  return (
    <div style={{ minHeight: '100vh', background: '#f8f9fa', padding: '32px 16px', fontFamily: "'Inter', sans-serif" }}>
      <div ref={top} style={{ maxWidth: 720, margin: '0 auto' }}>
        <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#8b5cf6', letterSpacing: '0.07em', marginBottom: 6 }}>
          SECURITY IMPOSSIBLE · MODULE 1 · SCENARIO PREVIEW
        </div>

        <div style={{ background: '#fff', border: '1px solid #e2e4e9', borderRadius: 10, overflow: 'hidden', boxShadow: '0 1px 4px rgba(0,0,0,0.05)' }}>
          <div style={{ padding: '16px 22px', background: 'linear-gradient(90deg,#f3f0ff,#faf8ff)', borderBottom: '1px solid #e2e4e9' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
              <div>
                <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10, color: '#8b5cf6', letterSpacing: '0.07em', marginBottom: 2 }}>
                  {META.kicker.toUpperCase()} · {META.player.toUpperCase()}
                </div>
                <div style={{ fontWeight: 700, fontSize: 17, color: '#0f1117' }}>{META.title}</div>
              </div>
              <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#8b5cf6' }}>{atDebrief ? 'Done' : `${Math.min(step + 1, total)} / ${total}`}</span>
            </div>
            {!atDebrief && (
              <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#6b7280', marginBottom: 10 }}>
                {SCENES[step].act} · <span style={{ color: '#0f1117' }}>{SCENES[step].title}</span>
              </div>
            )}
            <div style={{ height: 4, background: '#ede9fe', borderRadius: 4, overflow: 'hidden' }}>
              <div style={{ height: '100%', width: `${pct}%`, background: '#6d28d9', borderRadius: 4, transition: 'width 0.4s' }} />
            </div>
          </div>

          <div style={{ padding: '20px 22px 24px' }}>
            {step === 0 && (
              <p style={{ fontSize: 14, color: '#6b7280', lineHeight: 1.7, marginBottom: 20, paddingBottom: 18, borderBottom: '1px solid #f0f1f3' }}>{META.summary}</p>
            )}
            {atDebrief ? (
              <div>
                <div style={{ padding: '16px 18px', background: '#f0fdf4', border: '1px solid #86efac', borderRadius: 9, marginBottom: 16 }}>
                  <div style={{ fontWeight: 700, fontSize: 15, color: '#166534' }}>{DEBRIEF.title}</div>
                  <div style={{ fontSize: 13, color: '#4ade80' }}>Scenario complete — every decision made the strong call.</div>
                </div>
                <div style={{ marginBottom: 16 }}>{DEBRIEF.lines.map((d, i) => <Line key={i} {...d} />)}</div>
                <div style={{ padding: '16px 18px', background: '#fff', border: '1px solid #e2e4e9', borderRadius: 9 }}>
                  <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', letterSpacing: '0.06em', marginBottom: 12 }}>WHAT TO CARRY FORWARD</div>
                  {DEBRIEF.takeaways.map((t, i) => (
                    <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: 10 }}>
                      <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#6d28d9', marginTop: 8, flexShrink: 0 }} />
                      <span style={{ fontSize: 14, color: '#3d4350', lineHeight: 1.6 }}>{t}</span>
                    </div>
                  ))}
                </div>
                <div style={{ textAlign: 'center', marginTop: 16 }}>
                  <button onClick={() => setStep(0)} style={{ padding: '9px 18px', borderRadius: 7, background: '#fff', border: '1px solid #e2e4e9', color: '#6b7280', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>↺ Replay scenario</button>
                </div>
              </div>
            ) : (
              <Scene key={step} scene={SCENES[step]} onAdvance={advance} />
            )}
          </div>
        </div>

        <p style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#c4c9d4', textAlign: 'center', marginTop: 16 }}>
          Standalone preview · the production version is wired into Module 1 via CharacterScenario.jsx
        </p>
      </div>
    </div>
  );
}
