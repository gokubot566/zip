import { motion, AnimatePresence } from 'framer-motion';
import { Check, Lock, Clock } from 'lucide-react';
import { ALL_MODULES } from '../modules/moduleData.js';

export default function Sidebar({ open, currentModuleId, completedModules, onNavigate }) {
  const done  = new Set(completedModules || []);
  const total = ALL_MODULES.length;
  const pct   = Math.round((done.size / total) * 100);

  return (
    <AnimatePresence>
      {open && (
        <motion.aside
          initial={{ x: -280, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -280, opacity: 0 }}
          transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
          style={{
            position: 'fixed', top: 56, left: 0, bottom: 0, zIndex: 150,
            width: 280,
            background: '#ffffff',
            borderRight: '1px solid #e2e4e9',
            display: 'flex', flexDirection: 'column',
            overflowY: 'auto',
            scrollbarWidth: 'thin',
            scrollbarColor: '#e2e4e9 transparent',
            boxShadow: '2px 0 8px rgba(0,0,0,0.04)',
          }}
        >
          {/* ── Progress header ── */}
          <div style={{
            padding: '18px 18px 16px',
            borderBottom: '1px solid #e2e4e9',
            background: '#fff',
          }}>
            <div style={{ marginBottom: 6, display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span style={{
                fontFamily: "'Inter', sans-serif", fontWeight: 600,
                fontSize: 13, color: '#0f1117',
              }}>Course Progress</span>
              <span style={{
                fontFamily: "'DM Mono', monospace", fontSize: 12,
                color: pct === 100 ? '#166534' : '#6d28d9', fontWeight: 500,
              }}>{done.size}/{total} modules</span>
            </div>
            <div style={{ height: 5, background: '#e2e4e9', borderRadius: 3, overflow: 'hidden' }}>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.7, ease: 'easeOut' }}
                style={{
                  height: '100%', borderRadius: 3,
                  background: pct === 100
                    ? 'linear-gradient(90deg,#166534,#16a34a)'
                    : 'linear-gradient(90deg,#6d28d9,#7c3aed)',
                }}
              />
            </div>
            {pct === 100 && (
              <p style={{
                marginTop: 8, fontFamily: "'Inter', sans-serif",
                fontSize: 12, color: '#166534',
              }}>All modules complete ✓</p>
            )}
          </div>

          {/* ── Module list ── */}
          <nav style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
            {ALL_MODULES.map((mod) => {
              const active    = mod.id === currentModuleId;
              const isDone    = done.has(mod.id);
              const unlocked  = mod.id === 1 || isDone || done.has(mod.id - 1);
              const hasAck    = mod.policyAck?.length > 0;

              return (
                <button
                  key={mod.id}
                  onClick={() => unlocked && onNavigate(mod.id)}
                  disabled={!unlocked}
                  style={{
                    width: '100%', textAlign: 'left', border: 'none',
                    borderLeft: `3px solid ${active ? '#6d28d9' : 'transparent'}`,
                    background: active ? '#f3f0ff' : 'transparent',
                    cursor: unlocked ? 'pointer' : 'default',
                    padding: '0 14px 0 13px',
                    display: 'block',
                    transition: 'background 0.1s',
                  }}
                  onMouseEnter={e => {
                    if (unlocked && !active)
                      e.currentTarget.style.background = '#f8f9fa';
                  }}
                  onMouseLeave={e => {
                    if (!active) e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <div style={{
                    display: 'flex', alignItems: 'center', gap: 10,
                    padding: '10px 0',
                    borderBottom: '1px solid #f0f1f3',
                    opacity: unlocked ? 1 : 0.35,
                  }}>
                    {/* Status indicator */}
                    <div style={{
                      width: 28, height: 28, borderRadius: 6, flexShrink: 0,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      background: isDone
                        ? '#f0fdf4'
                        : active
                          ? '#ede9fe'
                          : '#f4f5f7',
                      border: isDone
                        ? '1px solid #86efac'
                        : active
                          ? '1px solid #c4b5fd'
                          : '1px solid #e2e4e9',
                    }}>
                      {isDone ? (
                        <Check size={13} color="#16a34a" strokeWidth={2.5}/>
                      ) : !unlocked ? (
                        <Lock size={11} color="#d1d4db"/>
                      ) : (
                        <span style={{
                          fontFamily: "'DM Mono', monospace", fontSize: 10,
                          fontWeight: 500,
                          color: active ? '#6d28d9' : '#9ca3af',
                        }}>
                          {String(mod.id).padStart(2, '0')}
                        </span>
                      )}
                    </div>

                    {/* Text */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{
                        fontFamily: "'Inter', sans-serif",
                        fontSize: 13,
                        fontWeight: active ? 600 : isDone ? 400 : 500,
                        color: isDone
                          ? '#6b7280'
                          : active ? '#3d1a78' : unlocked ? '#0f1117' : '#9ca3af',
                        lineHeight: 1.35,
                        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                        marginBottom: 2,
                      }}>
                        {mod.title}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                        <Clock size={10} color="#d1d4db"/>
                        <span style={{
                          fontFamily: "'DM Mono', monospace", fontSize: 10, color: '#c4c9d4',
                        }}>{mod.duration}</span>
                        {active && !isDone && (
                          <span style={{
                            fontFamily: "'DM Mono', monospace", fontSize: 9, fontWeight: 500,
                            color: '#6d28d9', background: '#ede9fe',
                            border: '1px solid #c4b5fd', padding: '0 5px', borderRadius: 3,
                          }}>CURRENT</span>
                        )}
                        {hasAck && unlocked && !isDone && !active && (
                          <span style={{
                            fontFamily: "'DM Mono', monospace", fontSize: 9, fontWeight: 500,
                            color: '#92400e', background: '#fffbeb',
                            border: '1px solid #fcd34d', padding: '0 5px', borderRadius: 3,
                          }}>ACK</span>
                        )}
                      </div>
                    </div>

                    {isDone && (
                      <span style={{
                        fontFamily: "'DM Mono', monospace", fontSize: 10,
                        color: '#86efac', flexShrink: 0,
                      }}>✓</span>
                    )}
                  </div>
                </button>
              );
            })}
          </nav>

          {/* ── Footer ── */}
          <div style={{ padding: '14px 18px', borderTop: '1px solid #e2e4e9' }}>
            <p style={{
              fontFamily: "'Inter', sans-serif", fontSize: 12, color: '#9ca3af', lineHeight: 1.7,
            }}>
              Questions?{' '}
              <a href="mailto:contact@securityimpossible.com" style={{ color: '#6d28d9', textDecoration: 'none' }}>
                contact@securityimpossible.com
              </a>
            </p>
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  );
}
