import { useEffect, useRef, useState } from 'react';
import { X, FileText, ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';
import { FULL_POLICIES } from '../modules/policyFullText.js';

export default function PolicyModal({ policyName, onClose, onAck, isAcked }) {
  const policy   = FULL_POLICIES[policyName];
  const scrollRef = useRef(null);
  const [readToBottom, setReadToBottom] = useState(false);
  const [openSections, setOpenSections] = useState(new Set(policy?.sections.map((_, i) => i)));

  // Track scroll — user must scroll near bottom before they can acknowledge
  function onScroll(e) {
    const el = e.currentTarget;
    const nearBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 80;
    if (nearBottom) setReadToBottom(true);
  }

  // Trap focus & close on Escape
  useEffect(() => {
    function onKey(e) { if (e.key === 'Escape') onClose(); }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  // Prevent background scroll
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);

  function toggleSection(i) {
    setOpenSections(prev => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });
  }

  if (!policy) {
    return (
      <div style={overlay} onClick={onClose}>
        <div style={{ ...modal, maxWidth: 480, padding: 32, textAlign: 'center' }} onClick={e => e.stopPropagation()}>
          <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: '#3d4350' }}>
            Full policy text for <strong>{policyName}</strong> is not yet available in this system.
            Please request the document from your manager.
          </p>
          <button onClick={onClose} style={closeBtnStyle}>Close</button>
        </div>
      </div>
    );
  }

  return (
    <div style={overlay} role="dialog" aria-modal="true" aria-label={`${policy.ref}: ${policyName}`} onClick={onClose}>
      <div style={modal} onClick={e => e.stopPropagation()}>

        {/* ── Header ── */}
        <div style={{
          padding: '18px 24px 16px',
          borderBottom: '1px solid #e2e4e9',
          display: 'flex', alignItems: 'flex-start', gap: 14,
          background: '#fff', flexShrink: 0,
          borderRadius: '10px 10px 0 0',
        }}>
          <div style={{
            width: 38, height: 38, borderRadius: 8, flexShrink: 0,
            background: '#f3f0ff', border: '1px solid #c4b5fd',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <FileText size={18} color="#6d28d9"/>
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af',
              letterSpacing: '0.06em', marginBottom: 3,
            }}>
              {policy.ref} · Version {policy.version} · Effective {policy.effective}
            </div>
            <h2 style={{
              fontFamily: "'Inter', sans-serif", fontWeight: 700, fontSize: 17,
              color: '#0f1117', lineHeight: 1.25, margin: 0,
            }}>{policyName}</h2>
            <div style={{
              fontFamily: "'Inter', sans-serif", fontSize: 12, color: '#9ca3af', marginTop: 2,
            }}>
              Policy owner: {policy.owner}
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close policy"
            style={{
              width: 32, height: 32, borderRadius: 6, flexShrink: 0,
              background: 'transparent', border: '1px solid #e2e4e9',
              color: '#6b7280', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'all 0.14s',
            }}
            onMouseEnter={e => { e.currentTarget.style.background = '#f8f9fa'; e.currentTarget.style.color = '#0f1117'; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#6b7280'; }}
          >
            <X size={15}/>
          </button>
        </div>

        {/* ── Scroll-to-read notice ── */}
        {!readToBottom && !isAcked && (
          <div style={{
            padding: '8px 24px',
            background: '#fffbeb', borderBottom: '1px solid #fde68a',
            display: 'flex', alignItems: 'center', gap: 8,
            flexShrink: 0,
          }}>
            <span style={{
              fontFamily: "'Inter', sans-serif", fontSize: 12.5, color: '#92400e',
            }}>
              Please read the full policy before acknowledging. Scroll to the bottom to confirm you have read it.
            </span>
          </div>
        )}

        {/* ── Policy body ── */}
        <div
          ref={scrollRef}
          onScroll={onScroll}
          style={{
            flex: 1, overflowY: 'auto', padding: '4px 0',
            background: '#f8f9fa',
            scrollbarWidth: 'thin', scrollbarColor: '#d1d4db transparent',
          }}
        >
          {policy.sections.map((sec, i) => {
            const open = openSections.has(i);
            const isLegal = sec.heading.includes('IMPORTANT') || sec.heading.includes('Acknowledgement');
            return (
              <div key={i} style={{
                margin: '6px 16px',
                background: '#fff', border: '1px solid #e2e4e9', borderRadius: 8,
                overflow: 'hidden',
              }}>
                <button
                  onClick={() => toggleSection(i)}
                  style={{
                    width: '100%', textAlign: 'left', border: 'none',
                    background: open ? '#fff' : '#fafbfc',
                    padding: '12px 16px', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', gap: 10,
                    transition: 'background 0.12s',
                  }}
                >
                  <span style={{
                    fontFamily: "'DM Mono', monospace", fontSize: 10, color: '#9ca3af',
                    minWidth: 22, flexShrink: 0,
                  }}>{String(i + 1).padStart(2, '0')}</span>
                  <span style={{
                    fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 14,
                    color: isLegal ? '#6d28d9' : '#0f1117', flex: 1, lineHeight: 1.3,
                  }}>{sec.heading}</span>
                  {open
                    ? <ChevronUp size={14} color="#9ca3af"/>
                    : <ChevronDown size={14} color="#9ca3af"/>
                  }
                </button>
                {open && (
                  <div style={{ padding: '0 16px 16px', borderTop: '1px solid #f0f1f3' }}>
                    {sec.body.split('\n\n').map((para, j) => (
                      <p key={j} style={{
                        fontFamily: "'Inter', sans-serif", fontSize: 13.5, color: '#3d4350',
                        lineHeight: 1.8, marginTop: 12, marginBottom: 0,
                        whiteSpace: 'pre-line',
                      }}>{para}</p>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
          {/* Bottom spacer so user can scroll to bottom */}
          <div style={{ height: 16 }}/>
        </div>

        {/* ── Footer with acknowledgement ── */}
        <div style={{
          padding: '16px 24px',
          borderTop: '1px solid #e2e4e9',
          background: '#fff',
          flexShrink: 0,
          borderRadius: '0 0 10px 10px',
        }}>
          {isAcked ? (
            <div style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
            }}>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 9,
                fontFamily: "'Inter', sans-serif", fontSize: 13.5, color: '#166534',
              }}>
                <div style={{
                  width: 22, height: 22, borderRadius: 5,
                  background: '#16a34a', display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <svg width="11" height="11" viewBox="0 0 11 11" fill="none">
                    <polyline points="1.5,5.5 4.5,8.5 9.5,2.5" stroke="#fff" strokeWidth="2"
                      strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <span>You have acknowledged this policy.</span>
              </div>
              <button onClick={onClose} style={secondaryBtn}>Close</button>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {/* Ack statement */}
              <div style={{
                padding: '12px 14px', background: '#f8f9fa',
                border: '1px solid #e2e4e9', borderRadius: 7,
                fontFamily: "'Inter', sans-serif", fontSize: 13, color: '#3d4350',
                lineHeight: 1.65,
              }}>
                <strong style={{ color: '#0f1117' }}>Acknowledgement:</strong>
                {' '}I confirm that I have read and understood the <strong>{policyName}</strong> in full,
                and I agree to comply with all obligations set out in this policy. I understand these
                obligations are legally binding and, in some cases, survive the termination of my employment.
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <button onClick={onClose} style={secondaryBtn}>
                  Read later
                </button>
                <button
                  onClick={() => { onAck(); onClose(); }}
                  disabled={!readToBottom}
                  style={{
                    padding: '10px 24px', borderRadius: 7,
                    fontFamily: "'Inter', sans-serif", fontSize: 13.5, fontWeight: 600,
                    cursor: readToBottom ? 'pointer' : 'not-allowed',
                    display: 'flex', alignItems: 'center', gap: 8,
                    transition: 'background 0.14s',
                    ...(readToBottom
                      ? { background: '#6d28d9', border: '1px solid #5b21b6', color: '#fff', boxShadow: '0 2px 8px rgba(109,40,217,0.3)' }
                      : { background: '#f4f5f7', border: '1px solid #e2e4e9', color: '#c4c9d4' }
                    ),
                  }}
                  onMouseEnter={e => { if (readToBottom) e.currentTarget.style.background = '#5b21b6'; }}
                  onMouseLeave={e => { if (readToBottom) e.currentTarget.style.background = '#6d28d9'; }}
                >
                  {readToBottom
                    ? <>I have read and accept this policy</>
                    : <>Scroll to read the full policy</>
                  }
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ── Shared styles ────────────────────────────────────────────────────────── */
const overlay = {
  position: 'fixed', inset: 0, zIndex: 1000,
  background: 'rgba(0,0,0,0.45)',
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  padding: '20px',
  backdropFilter: 'blur(3px)',
};

const modal = {
  width: '100%', maxWidth: 720,
  maxHeight: '90vh',
  background: '#fff',
  borderRadius: 10,
  display: 'flex', flexDirection: 'column',
  boxShadow: '0 20px 60px rgba(0,0,0,0.18), 0 0 0 1px rgba(0,0,0,0.06)',
  overflow: 'hidden',
};

const secondaryBtn = {
  padding: '9px 18px', borderRadius: 7,
  background: 'transparent', border: '1px solid #e2e4e9',
  color: '#6b7280', fontFamily: "'Inter', sans-serif",
  fontSize: 13, cursor: 'pointer',
};

const closeBtnStyle = {
  marginTop: 16, padding: '9px 22px', borderRadius: 7,
  background: '#6d28d9', border: 'none', color: '#fff',
  fontFamily: "'Inter', sans-serif", fontSize: 13, fontWeight: 600, cursor: 'pointer',
};
