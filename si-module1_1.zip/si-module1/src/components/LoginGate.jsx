import { useState } from 'react';
import { motion } from 'framer-motion';
import { Lock, ArrowRight, ShieldCheck } from 'lucide-react';
import siLogo from '../assets/si-logo-full.png';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const fieldStyle = (focused, invalid) => ({
  width: '100%',
  padding: '11px 13px',
  borderRadius: 8,
  border: `1px solid ${invalid ? '#fca5a5' : focused ? '#6d28d9' : '#e2e4e9'}`,
  background: invalid ? '#fef2f2' : '#fff',
  fontFamily: "'Inter', sans-serif",
  fontSize: 14.5,
  color: '#0f1117',
  outline: 'none',
  boxShadow: focused ? '0 0 0 3px rgba(109,40,217,0.12)' : 'none',
  transition: 'border-color 0.15s, box-shadow 0.15s',
  boxSizing: 'border-box',
});

const labelStyle = {
  display: 'block',
  fontFamily: "'DM Mono', monospace",
  fontSize: 10.5,
  color: '#9ca3af',
  letterSpacing: '0.06em',
  marginBottom: 6,
};

export default function LoginGate({ onAuthenticated }) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [focus, setFocus] = useState(null);
  const [touched, setTouched] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const fnValid = firstName.trim().length > 0;
  const lnValid = lastName.trim().length > 0;
  const emValid = EMAIL_RE.test(email.trim());
  const allValid = fnValid && lnValid && emValid;

  async function submit() {
    setTouched(true);
    setError('');
    if (!allValid) return;
    setSubmitting(true);

    const payload = {
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      email: email.trim(),
    };

    try {
      const res = await fetch('/api/signin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'Could not record sign-in. Please try again.');
      }
      onAuthenticated({ ...payload, at: new Date().toISOString() });
    } catch (e) {
      // Network/back-end failure: surface a clear message and block entry,
      // since the sign-in must be recorded for auditing.
      setError(e.message || 'Sign-in could not be recorded. Please try again.');
      setSubmitting(false);
    }
  }

  function onKeyDown(e) {
    if (e.key === 'Enter') submit();
  }

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 1000,
      background: 'rgba(15,17,23,0.55)',
      backdropFilter: 'blur(4px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 20,
    }}>
      <motion.div
        initial={{ opacity: 0, y: 14, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
        onKeyDown={onKeyDown}
        style={{
          width: '100%', maxWidth: 440,
          background: '#fff', borderRadius: 14,
          border: '1px solid #e2e4e9',
          boxShadow: '0 12px 48px rgba(0,0,0,0.22)',
          overflow: 'hidden',
        }}
      >
        {/* Header */}
        <div style={{ padding: '30px 32px 20px', textAlign: 'center' }}>
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 20 }}>
            <img
              src={siLogo}
              alt="Security Impossible"
              style={{ height: 46, width: 'auto', maxWidth: '100%', objectFit: 'contain' }}
            />
          </div>
          <h1 style={{
            fontFamily: "'Inter', sans-serif", fontWeight: 700, fontSize: 21,
            color: '#0f1117', letterSpacing: '-0.02em', marginBottom: 6,
          }}>
            Security &amp; Governance Onboarding
          </h1>
          <p style={{
            fontFamily: "'Inter', sans-serif", fontSize: 13.5, color: '#6b7280',
            lineHeight: 1.6, margin: 0,
          }}>
            Please identify yourself before starting. Your details are recorded for
            compliance and audit purposes.
          </p>
        </div>

        <div style={{ height: 1, background: '#f0f1f3' }} />

        {/* Form */}
        <div style={{ padding: '24px 32px 8px' }}>
          <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
            <div style={{ flex: 1 }}>
              <label style={labelStyle}>FIRST NAME</label>
              <input
                type="text" value={firstName} autoFocus
                onChange={e => setFirstName(e.target.value)}
                onFocus={() => setFocus('fn')} onBlur={() => setFocus(null)}
                placeholder="Jane"
                style={fieldStyle(focus === 'fn', touched && !fnValid)}
              />
            </div>
            <div style={{ flex: 1 }}>
              <label style={labelStyle}>LAST NAME</label>
              <input
                type="text" value={lastName}
                onChange={e => setLastName(e.target.value)}
                onFocus={() => setFocus('ln')} onBlur={() => setFocus(null)}
                placeholder="Doe"
                style={fieldStyle(focus === 'ln', touched && !lnValid)}
              />
            </div>
          </div>

          <div style={{ marginBottom: 4 }}>
            <label style={labelStyle}>WORK EMAIL</label>
            <input
              type="email" value={email}
              onChange={e => setEmail(e.target.value)}
              onFocus={() => setFocus('em')} onBlur={() => setFocus(null)}
              placeholder="jane.doe@securityimpossible.com"
              style={fieldStyle(focus === 'em', touched && !emValid)}
            />
            {touched && !emValid && (
              <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: '#dc2626', margin: '6px 2px 0' }}>
                Please enter a valid email address.
              </p>
            )}
          </div>

          {error && (
            <div style={{
              marginTop: 14, padding: '10px 13px', borderRadius: 8,
              background: '#fef2f2', border: '1px solid #fca5a5',
              fontFamily: "'Inter', sans-serif", fontSize: 13, color: '#991b1b', lineHeight: 1.5,
            }}>
              {error}
            </div>
          )}
        </div>

        {/* Footer / submit */}
        <div style={{ padding: '16px 32px 26px' }}>
          <button
            onClick={submit}
            disabled={submitting}
            style={{
              width: '100%', padding: '12px 18px', borderRadius: 9,
              border: 'none', cursor: submitting ? 'wait' : allValid ? 'pointer' : 'pointer',
              fontFamily: "'Inter', sans-serif", fontSize: 14.5, fontWeight: 600,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              transition: 'background 0.15s, box-shadow 0.15s',
              ...(allValid && !submitting
                ? { background: '#6d28d9', color: '#fff', boxShadow: '0 2px 10px rgba(109,40,217,0.32)' }
                : { background: '#a78bfa', color: '#fff', opacity: submitting ? 0.85 : 1 }),
            }}
            onMouseEnter={e => { if (allValid && !submitting) e.currentTarget.style.background = '#5b21b6'; }}
            onMouseLeave={e => { if (allValid && !submitting) e.currentTarget.style.background = '#6d28d9'; }}
          >
            {submitting
              ? 'Recording…'
              : <>Start onboarding <ArrowRight size={16} /></>}
          </button>

          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
            marginTop: 16,
          }}>
            <ShieldCheck size={13} color="#9ca3af" />
            <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', letterSpacing: '0.04em' }}>
              Recorded securely for audit · Security Impossible Pty Ltd
            </span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
