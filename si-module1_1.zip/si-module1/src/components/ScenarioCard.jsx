import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, User, Users, AlertCircle, CheckCircle, ChevronDown } from 'lucide-react';

const RESPONSES = [
  {
    id: 'a',
    text: "Sure! We're currently working with three banks and a government department. The banks are worried about their cloud infrastructure and we found some critical vulnerabilities last week.",
    correct: false,
    feedback: "❌ This response discloses confidential client information — both the identity of clients and details of findings. Even sharing this with a trusted friend violates your confidentiality obligations and could constitute a notifiable data breach.",
  },
  {
    id: 'b',
    text: "I can't share specifics about our clients or what we're working on — that's all confidential. But I love the work! It's really technically interesting.",
    correct: true,
    feedback: "✅ This is exactly right. You've deflected without being rude, protected confidential information, and maintained the relationship. No client names, no engagement details, no findings.",
  },
  {
    id: 'c',
    text: "I'm not really supposed to talk about it, but between us... we're doing a lot of work in the finance sector right now. Nothing I can share specifically.",
    correct: false,
    feedback: "⚠️ Closer, but 'between us' framing and sector hints are still problematic. Even vague disclosures can help an adversary build a picture of our client base. The phrase 'between us' doesn't create any legal protection.",
  },
  {
    id: 'd',
    text: "Honestly I can't say anything at all about clients — it's a strict confidentiality thing. Happy to talk about the industry or cybersecurity generally though!",
    correct: true,
    feedback: "✅ Also correct. Clear, professional, and redirects to something you can discuss. Firm boundaries without being dismissive.",
  },
];

export default function ScenarioCard({ onComplete, completed }) {
  const [selected, setSelected] = useState(null);
  const [revealed, setRevealed] = useState(false);

  function handleSelect(resp) {
    setSelected(resp);
    setRevealed(true);
    if (resp.correct && !completed) onComplete();
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
      style={{
        borderRadius: 18, overflow: 'hidden',
        border: '1px solid rgba(255,255,255,0.07)',
        marginBottom: 24,
      }}
    >
      {/* Header */}
      <div style={{
        padding: '18px 28px',
        background: 'linear-gradient(90deg,rgba(26,86,219,0.15),rgba(14,165,233,0.08))',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <div style={{
          width: 36, height: 36, borderRadius: 10,
          background: 'rgba(14,165,233,0.15)', border: '1px solid rgba(14,165,233,0.25)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <MessageCircle size={17} color="#0ea5e9" />
        </div>
        <div>
          <div style={{ fontSize: 10, color: '#334155', fontFamily: "'JetBrains Mono', monospace", letterSpacing: '0.08em', marginBottom: 1 }}>WORKPLACE SCENARIO</div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 16, color: '#e2e8f0' }}>
            The Friday Evening Question
          </div>
        </div>
      </div>

      {/* Scene */}
      <div style={{ padding: '24px 28px', background: 'rgba(255,255,255,0.015)' }}>
        {/* Setting */}
        <div style={{
          padding: '14px 18px', borderRadius: 10, marginBottom: 20,
          background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.05)',
        }}>
          <div style={{ fontSize: 10, color: '#334155', fontFamily: "'JetBrains Mono', monospace", marginBottom: 6, letterSpacing: '0.06em' }}>SETTING</div>
          <p style={{ fontSize: 13.5, color: '#64748b', fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.7, margin: 0 }}>
            It's Friday evening. You've just wrapped up your first week at Security Impossible and you're catching up
            with a close friend over drinks. You're excited about your new job and the interesting work you're doing.
          </p>
        </div>

        {/* Conversation */}
        <div style={{ marginBottom: 20 }}>
          {/* Friend message */}
          <div style={{ display: 'flex', gap: 10, marginBottom: 12, justifyContent: 'flex-start' }}>
            <div style={{
              width: 32, height: 32, borderRadius: '50%', flexShrink: 0,
              background: 'linear-gradient(135deg,#374151,#4b5563)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Users size={15} color="#9ca3af" />
            </div>
            <div style={{ maxWidth: '75%' }}>
              <div style={{ fontSize: 10, color: '#334155', fontFamily: "'JetBrains Mono', monospace", marginBottom: 4 }}>YOUR FRIEND</div>
              <div style={{
                padding: '12px 16px', borderRadius: '4px 12px 12px 12px',
                background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)',
                fontSize: 13.5, color: '#94a3b8', fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.6,
              }}>
                "So what kind of clients does your firm work with? I'm curious about what a cybersecurity consulting firm actually does day to day. Any cool companies I'd recognise?"
              </div>
            </div>
          </div>

          {/* You bubble placeholder */}
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
            <div style={{ maxWidth: '75%' }}>
              <div style={{ fontSize: 10, color: '#334155', fontFamily: "'JetBrains Mono', monospace", marginBottom: 4, textAlign: 'right' }}>YOU</div>
              {selected ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  style={{
                    padding: '12px 16px', borderRadius: '12px 4px 12px 12px',
                    background: selected.correct ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.08)',
                    border: `1px solid ${selected.correct ? 'rgba(16,185,129,0.25)' : 'rgba(239,68,68,0.2)'}`,
                    fontSize: 13.5, color: '#94a3b8', fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.6,
                  }}
                >
                  "{selected.text}"
                </motion.div>
              ) : (
                <div style={{
                  padding: '12px 16px', borderRadius: '12px 4px 12px 12px',
                  background: 'rgba(26,86,219,0.06)', border: '1px dashed rgba(26,86,219,0.2)',
                  fontSize: 13.5, color: '#334155', fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.6, fontStyle: 'italic',
                }}>
                  Choose your response below...
                </div>
              )}
            </div>
            <div style={{
              width: 32, height: 32, borderRadius: '50%', flexShrink: 0,
              background: 'linear-gradient(135deg,#1e3a5f,#1a56db)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <User size={15} color="#93c5fd" />
            </div>
          </div>
        </div>

        {/* Response options */}
        <div>
          <div style={{ fontSize: 11, color: '#334155', fontFamily: "'JetBrains Mono', monospace", marginBottom: 10, letterSpacing: '0.06em' }}>
            HOW DO YOU RESPOND?
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {RESPONSES.map((resp, i) => {
              const isSelected = selected?.id === resp.id;
              const isCorrect = resp.correct;
              const showResult = revealed && isSelected;

              return (
                <motion.button
                  key={resp.id}
                  whileHover={!revealed ? { x: 4 } : {}}
                  onClick={() => !revealed && handleSelect(resp)}
                  style={{
                    textAlign: 'left', padding: '14px 16px', borderRadius: 10,
                    background: showResult
                      ? (isCorrect ? 'rgba(16,185,129,0.08)' : 'rgba(239,68,68,0.06)')
                      : revealed && !isSelected ? 'rgba(255,255,255,0.01)' : 'rgba(255,255,255,0.03)',
                    border: showResult
                      ? `1px solid ${isCorrect ? 'rgba(16,185,129,0.25)' : 'rgba(239,68,68,0.2)'}`
                      : '1px solid rgba(255,255,255,0.06)',
                    cursor: revealed ? 'default' : 'pointer',
                    display: 'flex', alignItems: 'flex-start', gap: 10,
                    opacity: revealed && !isSelected ? 0.35 : 1,
                    transition: 'all 0.2s',
                  }}
                >
                  <div style={{
                    width: 22, height: 22, borderRadius: 6, flexShrink: 0,
                    background: showResult
                      ? (isCorrect ? 'rgba(16,185,129,0.2)' : 'rgba(239,68,68,0.15)')
                      : 'rgba(255,255,255,0.06)',
                    border: showResult
                      ? `1px solid ${isCorrect ? 'rgba(16,185,129,0.3)' : 'rgba(239,68,68,0.25)'}`
                      : '1px solid rgba(255,255,255,0.08)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 11, fontFamily: "'JetBrains Mono', monospace",
                    color: showResult ? (isCorrect ? '#10b981' : '#f87171') : '#475569',
                    fontWeight: 700, marginTop: 1,
                  }}>
                    {showResult ? (isCorrect ? '✓' : '✗') : String.fromCharCode(65 + i)}
                  </div>
                  <span style={{
                    fontSize: 13.5, fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.55,
                    color: showResult ? (isCorrect ? '#86efac' : '#fca5a5') : '#64748b',
                  }}>
                    "{resp.text}"
                  </span>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Feedback */}
        <AnimatePresence>
          {revealed && selected && (
            <motion.div
              initial={{ opacity: 0, y: 10, height: 0 }}
              animate={{ opacity: 1, y: 0, height: 'auto' }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.35 }}
              style={{
                marginTop: 16, padding: '16px 18px', borderRadius: 10,
                background: selected.correct ? 'rgba(16,185,129,0.07)' : 'rgba(239,68,68,0.06)',
                border: `1px solid ${selected.correct ? 'rgba(16,185,129,0.2)' : 'rgba(239,68,68,0.15)'}`,
              }}
            >
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                {selected.correct
                  ? <CheckCircle size={16} color="#10b981" style={{ marginTop: 2, flexShrink: 0 }} />
                  : <AlertCircle size={16} color="#f87171" style={{ marginTop: 2, flexShrink: 0 }} />
                }
                <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13.5, color: selected.correct ? '#6ee7b7' : '#fca5a5', lineHeight: 1.7 }}>
                  {selected.feedback}
                </div>
              </div>
              {!selected.correct && (
                <button
                  onClick={() => { setSelected(null); setRevealed(false); }}
                  style={{
                    marginTop: 10, padding: '7px 14px', borderRadius: 7,
                    background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)',
                    color: '#94a3b8', fontSize: 12, fontFamily: "'Space Grotesk', sans-serif",
                    cursor: 'pointer', fontWeight: 600,
                  }}
                >
                  Try again
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
