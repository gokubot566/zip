import { useState, useMemo, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, CheckCircle, AlertCircle, RotateCcw, ArrowRight, Sparkles } from 'lucide-react';
import { CastPhoto } from './Cast.jsx';
import { CHARACTERS } from '../modules/cast.js';
import { SCENARIO_META, SCENES, SCENARIO_DEBRIEF } from '../modules/scenario1.js';

/* ── A single line of cast dialogue (avatar + name + bubble) ──────────────── */
function DialogueLine({ s, t, delay = 0 }) {
  const c = CHARACTERS[s];
  if (!c) return null;
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay }}
      style={{ display: 'flex', gap: 11, marginBottom: 12, alignItems: 'flex-start' }}
    >
      <CastPhoto id={s} size={40} speaking />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 4 }}>
          <span style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 13, color: '#0f1117' }}>
            {c.name}
          </span>
          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 10, color: c.color, letterSpacing: '0.02em' }}>
            {c.role}
          </span>
        </div>
        <div style={{
          padding: '11px 14px',
          background: '#fff',
          border: '1px solid #e2e4e9',
          borderLeft: `3px solid ${c.color}`,
          borderRadius: '4px 9px 9px 9px',
          fontFamily: "'Inter', sans-serif", fontSize: 14, color: '#3d4350', lineHeight: 1.6,
        }}>
          {t}
        </div>
      </div>
    </motion.div>
  );
}

/* ── The cast strip at the top of the scenario (who's in the room) ────────── */
function CastStrip({ ids, active }) {
  return (
    <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
      {ids.map(id => {
        const c = CHARACTERS[id];
        const on = active?.includes(id);
        return (
          <div key={id} style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <CastPhoto id={id} size={34} speaking={on} />
            <div style={{ lineHeight: 1.2 }}>
              <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 12.5, color: on ? '#0f1117' : '#9ca3af' }}>
                {c.name.split(' ')[0]}
              </div>
              <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 9.5, color: on ? c.color : '#c4c9d4' }}>
                {c.role}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ── One option button with result styling ───────────────────────────────── */
const TONE = {
  best: { bd: '#86efac', bg: '#f0fdf4', chip: '#dcfce7', fg: '#166534', icon: '#16a34a' },
  ok:   { bd: '#fcd34d', bg: '#fffbeb', chip: '#fef3c7', fg: '#92400e', icon: '#b45309' },
  poor: { bd: '#fca5a5', bg: '#fef2f2', chip: '#fee2e2', fg: '#991b1b', icon: '#dc2626' },
};

function OptionButton({ opt, idx, selected, revealed, onPick }) {
  const isSel = selected?.id === opt.id;
  const dimmed = revealed && !isSel;
  const tone = TONE[opt.score];
  return (
    <button
      onClick={() => !revealed && onPick(opt)}
      disabled={revealed}
      style={{
        textAlign: 'left', padding: '12px 15px', borderRadius: 8, width: '100%',
        border: `1px solid ${isSel ? tone.bd : '#e2e4e9'}`,
        background: isSel ? tone.bg : '#f8f9fa',
        cursor: revealed ? 'default' : 'pointer',
        display: 'flex', alignItems: 'flex-start', gap: 12,
        opacity: dimmed ? 0.35 : 1, transition: 'all 0.14s',
      }}
      onMouseEnter={e => { if (!revealed) { e.currentTarget.style.borderColor = '#6d28d9'; e.currentTarget.style.background = '#faf8ff'; } }}
      onMouseLeave={e => { if (!revealed) { e.currentTarget.style.borderColor = '#e2e4e9'; e.currentTarget.style.background = '#f8f9fa'; } }}
    >
      <span style={{
        width: 24, height: 24, borderRadius: 5, flexShrink: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: isSel ? tone.chip : '#fff',
        border: `1px solid ${isSel ? tone.bd : '#e2e4e9'}`,
        fontFamily: "'DM Mono', monospace", fontSize: 11, fontWeight: 600,
        color: isSel ? tone.icon : '#9ca3af', marginTop: 1,
      }}>
        {isSel ? (opt.score === 'best' ? '✓' : opt.score === 'ok' ? '~' : '✗') : String.fromCharCode(65 + idx)}
      </span>
      <span style={{
        fontFamily: "'Inter', sans-serif", fontSize: 14, lineHeight: 1.55,
        color: isSel ? tone.fg : '#3d4350',
      }}>
        {opt.text}
      </span>
    </button>
  );
}

/* ── A single scene ──────────────────────────────────────────────────────── */
function Scene({ scene, onAdvance }) {
  const [selected, setSelected] = useState(null);
  const [revealed, setRevealed] = useState(false);

  const speakers = useMemo(() => [...new Set(scene.dialogue.map(d => d.s))], [scene]);

  function pick(opt) {
    setSelected(opt);
    setRevealed(true);
  }
  function retry() {
    setSelected(null);
    setRevealed(false);
  }

  const tone = selected ? TONE[selected.score] : null;
  const canAdvance = selected && selected.score === 'best';

  return (
    <div>
      {/* Setting */}
      <div style={{
        padding: '12px 15px', background: '#f8f9fa',
        border: '1px solid #e2e4e9', borderRadius: 7, marginBottom: 16,
      }}>
        <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', letterSpacing: '0.06em', marginBottom: 7 }}>
          SETTING
        </div>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: '#3d4350', lineHeight: 1.7, margin: 0 }}>
          {scene.setting}
        </p>
      </div>

      {/* Who's in the room */}
      <div style={{
        padding: '12px 15px', background: '#fff',
        border: '1px solid #e2e4e9', borderRadius: 7, marginBottom: 16,
      }}>
        <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', letterSpacing: '0.06em', marginBottom: 11 }}>
          IN THE ROOM
        </div>
        <CastStrip ids={speakers} active={speakers} />
      </div>

      {/* Dialogue */}
      <div style={{ marginBottom: 18 }}>
        {scene.dialogue.map((d, i) => (
          <DialogueLine key={i} s={d.s} t={d.t} delay={i * 0.12} />
        ))}
      </div>

      {/* Prompt */}
      <div style={{
        padding: '13px 16px', background: '#f3f0ff', border: '1px solid #c4b5fd',
        borderRadius: 8, marginBottom: 14,
        fontFamily: "'Inter', sans-serif", fontSize: 14.5, fontWeight: 500, color: '#3d1a78', lineHeight: 1.6,
      }}>
        {scene.prompt}
      </div>

      {/* Options */}
      <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', letterSpacing: '0.06em', marginBottom: 10 }}>
        YOUR MOVE
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {scene.options.map((opt, i) => (
          <OptionButton key={opt.id} opt={opt} idx={i} selected={selected} revealed={revealed} onPick={pick} />
        ))}
      </div>

      {/* Reaction + feedback */}
      <AnimatePresence>
        {revealed && selected && (
          <motion.div
            initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            style={{ marginTop: 16 }}
          >
            {/* In-character reaction */}
            <div style={{ marginBottom: 12 }}>
              <DialogueLine s={selected.reaction.s} t={selected.reaction.t} />
            </div>

            {/* Coaching feedback */}
            <div style={{
              padding: '14px 16px', borderRadius: 8,
              background: tone.bg, border: `1px solid ${tone.bd}`,
              display: 'flex', gap: 10, alignItems: 'flex-start',
            }}>
              {selected.score === 'best'
                ? <CheckCircle size={16} color={tone.icon} style={{ flexShrink: 0, marginTop: 2 }} />
                : <AlertCircle size={16} color={tone.icon} style={{ flexShrink: 0, marginTop: 2 }} />}
              <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, lineHeight: 1.7, margin: 0, color: tone.fg }}>
                {selected.feedback}
              </p>
            </div>

            {/* Advance / retry */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 14, gap: 8 }}>
              {!canAdvance && (
                <button onClick={retry} style={{
                  display: 'flex', alignItems: 'center', gap: 7,
                  padding: '9px 16px', borderRadius: 7,
                  background: '#fff', border: '1px solid #e2e4e9', color: '#6b7280',
                  fontFamily: "'Inter', sans-serif", fontSize: 13, fontWeight: 600, cursor: 'pointer',
                }}>
                  <RotateCcw size={13} /> Try a different response
                </button>
              )}
              {canAdvance && (
                <button onClick={onAdvance} style={{
                  display: 'flex', alignItems: 'center', gap: 7,
                  padding: '9px 20px', borderRadius: 7,
                  background: '#6d28d9', border: '1px solid #5b21b6', color: '#fff',
                  fontFamily: "'Inter', sans-serif", fontSize: 13, fontWeight: 600, cursor: 'pointer',
                  boxShadow: '0 2px 8px rgba(109,40,217,0.3)',
                }}>
                  Continue <ArrowRight size={14} />
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ── Closing debrief ─────────────────────────────────────────────────────── */
function Debrief({ onDone, alreadyDone }) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
      <div style={{
        padding: '16px 18px', background: '#f0fdf4', border: '1px solid #86efac',
        borderRadius: 9, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 11,
      }}>
        <div style={{
          width: 34, height: 34, borderRadius: 8, flexShrink: 0,
          background: '#dcfce7', border: '1px solid #86efac',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Sparkles size={16} color="#16a34a" />
        </div>
        <div>
          <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 700, fontSize: 15, color: '#166534' }}>
            {SCENARIO_DEBRIEF.title}
          </div>
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: '#4ade80' }}>
            Scenario complete — every decision made the strong call.
          </div>
        </div>
      </div>

      <div style={{ marginBottom: 16 }}>
        {SCENARIO_DEBRIEF.lines.map((d, i) => (
          <DialogueLine key={i} s={d.s} t={d.t} delay={i * 0.12} />
        ))}
      </div>

      <div style={{
        padding: '16px 18px', background: '#fff', border: '1px solid #e2e4e9', borderRadius: 9,
      }}>
        <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', letterSpacing: '0.06em', marginBottom: 12 }}>
          WHAT TO CARRY FORWARD
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {SCENARIO_DEBRIEF.takeaways.map((t, i) => (
            <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
              <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#6d28d9', marginTop: 8, flexShrink: 0 }} />
              <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: '#3d4350', lineHeight: 1.6 }}>{t}</span>
            </div>
          ))}
        </div>
      </div>

      {!alreadyDone && (
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: 16 }}>
          <button onClick={onDone} style={{
            display: 'flex', alignItems: 'center', gap: 8,
            padding: '10px 24px', borderRadius: 8,
            background: '#166534', border: 'none', color: '#fff',
            fontFamily: "'Inter', sans-serif", fontSize: 14, fontWeight: 600, cursor: 'pointer',
          }}>
            <CheckCircle size={15} /> Mark scenario complete
          </button>
        </div>
      )}
    </motion.div>
  );
}

/* ── Exported scenario shell ─────────────────────────────────────────────── */
export default function CharacterScenario({ onDone, done }) {
  const [step, setStep] = useState(0);            // 0..SCENES.length-1, then SCENES.length = debrief
  const total = SCENES.length;
  const atDebrief = step >= total;
  const topRef = useRef(null);

  function advance() {
    setStep(s => Math.min(s + 1, total));
    requestAnimationFrame(() => topRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
  }

  useEffect(() => {
    if (atDebrief && done == null) { /* no-op */ }
  }, [atDebrief, done]);

  const progressPct = Math.round((Math.min(step, total) / total) * 100);

  return (
    <div ref={topRef} style={{
      background: '#fff', border: '1px solid #e2e4e9', borderRadius: 10, overflow: 'hidden',
      boxShadow: '0 1px 4px rgba(0,0,0,0.05)', marginBottom: 8,
    }}>
      {/* Header */}
      <div style={{
        padding: '16px 22px',
        background: 'linear-gradient(90deg, #f3f0ff, #faf8ff)',
        borderBottom: '1px solid #e2e4e9',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8, flexShrink: 0,
            background: '#ede9fe', border: '1px solid #c4b5fd',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <MessageSquare size={15} color="#6d28d9" />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10, color: '#8b5cf6', letterSpacing: '0.07em', marginBottom: 2 }}>
              {SCENARIO_META.kicker.toUpperCase()} · {SCENARIO_META.player.toUpperCase()}
            </div>
            <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 700, fontSize: 17, color: '#0f1117', letterSpacing: '-0.01em' }}>
              {SCENARIO_META.title}
            </div>
          </div>
          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#8b5cf6', flexShrink: 0 }}>
            {atDebrief ? 'Done' : `${Math.min(step + 1, total)} / ${total}`}
          </span>
        </div>

        {/* Act label + progress */}
        {!atDebrief && (
          <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#6b7280', marginBottom: 10 }}>
            {SCENES[step].act} · <span style={{ color: '#0f1117' }}>{SCENES[step].title}</span>
          </div>
        )}
        <div style={{ height: 4, background: '#ede9fe', borderRadius: 4, overflow: 'hidden' }}>
          <motion.div
            animate={{ width: `${progressPct}%` }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            style={{ height: '100%', background: '#6d28d9', borderRadius: 4 }}
          />
        </div>
      </div>

      {/* Body */}
      <div style={{ padding: '20px 22px 24px' }}>
        {step === 0 && (
          <p style={{
            fontFamily: "'Inter', sans-serif", fontSize: 14, color: '#6b7280',
            lineHeight: 1.7, marginBottom: 20, paddingBottom: 18, borderBottom: '1px solid #f0f1f3',
          }}>
            {SCENARIO_META.summary}
          </p>
        )}

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25 }}
          >
            {atDebrief
              ? <Debrief onDone={() => onDone?.()} alreadyDone={done} />
              : <Scene scene={SCENES[step]} onAdvance={advance} />}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
