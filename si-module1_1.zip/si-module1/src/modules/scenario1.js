// ── Character-based scenario — Module 1: Welcome & Why Security Matters Here ───
//
// A multi-scene, cast-driven narrative. The trainee plays a new analyst in
// onboarding week. The shared cast (Elena, Marcus, Priya, David, Hannah) work
// the situation alongside them. Each SCENE presents a setting + in-character
// dialogue, then a decision with branching feedback. Picking the strong option
// advances the story; weak options are explained and can be retried.
//
// Speaker ids MUST be valid cast ids: elena | marcus | priya | david | auditor.
//
// Scene shape:
//   {
//     id, act, title,
//     setting,                       // scene-setting prose (the "where/when")
//     dialogue: [{ s, t }],          // cast lines leading into the decision
//     prompt,                        // the question put to the trainee
//     options: [{ id, text, score, reaction:{s,t}, feedback }],
//        score: 'best' | 'ok' | 'poor'   (best advances; poor must retry)
//   }

export const SCENARIO_META = {
  module: 1,
  kicker: 'Interactive Scenario',
  title: 'Day Two: The Prospect Question',
  player: 'You — Security Analyst, Week 1',
  summary:
    "It is your second day at Security Impossible. Over the next few hours you " +
    "will hit four small, ordinary moments where the right instinct protects the " +
    "firm — and the wrong one quietly puts a client relationship at risk. Work " +
    "through them with the team.",
  cast: ['elena', 'marcus', 'priya', 'david', 'auditor'],
  outcomeThreshold: 0,   // narrative scenario; completion = reaching the end
};

export const SCENES = [
  // ── ACT 1 ───────────────────────────────────────────────────────────────────
  {
    id: 's1',
    act: 'Act 1 — The Welcome',
    title: 'Why any of this matters',
    setting:
      "9:14 AM. You're in a small meeting room for your day-two induction. Elena " +
      "from People & Compliance has your laptop ready; Priya, the CISO, drops in " +
      "for five minutes between meetings.",
    dialogue: [
      { s: 'elena',  t: "Morning. Yesterday was paperwork — today is the part that actually matters. Before any policy, I want you to understand *why* we're strict." },
      { s: 'priya',  t: "Quick version from me, then I'll get out of your way. We're a security firm. Clients hand us their crown jewels — their networks, their weak spots, their people. The only reason they do that is trust." },
      { s: 'priya',  t: "So here's the question I ask every new hire on day two…" },
    ],
    prompt:
      "Priya asks: \"Why do you think a confidentiality slip hurts a firm like us " +
      "more than it would hurt, say, a normal software company?\"",
    options: [
      {
        id: 'a',
        text: "Because we hold more data than most companies do.",
        score: 'poor',
        reaction: { s: 'priya', t: "Volume isn't really it — plenty of firms hold more data than we do. Think about what we *sell*." },
        feedback:
          "Not the core reason. It isn't the quantity of data — it's that our entire product is trust. A security firm that can't keep a secret has nothing to sell.",
      },
      {
        id: 'b',
        text: "Because our whole business is built on clients trusting us to protect them — a slip breaks that premise entirely.",
        score: 'best',
        reaction: { s: 'priya', t: "Exactly. We sell trust. If we can't protect information ourselves, why would anyone let us near theirs? That's existential for us in a way it isn't for most companies." },
        feedback:
          "Right on target. Security Impossible sells trust. A breach doesn't just cause a legal problem — it undermines the reason clients hire us at all. That's why our internal bar is higher than what we recommend to others.",
      },
      {
        id: 'c',
        text: "Because the legal penalties for security firms are higher than for other businesses.",
        score: 'poor',
        reaction: { s: 'priya', t: "The law applies to everyone the same way. The harm to *us* is reputational and commercial — it's about credibility." },
        feedback:
          "Penalties aren't firm-specific. The disproportionate harm is to credibility: our value proposition is that we can be trusted with sensitive things. Lose that and the legal fine is the smaller problem.",
      },
    ],
  },

  // ── ACT 2 ───────────────────────────────────────────────────────────────────
  {
    id: 's2',
    act: 'Act 2 — When Do The Rules Start?',
    title: 'The grace-period myth',
    setting:
      "10:40 AM. Elena is walking you through the policy library. You mention, " +
      "half-joking, that you'll \"properly read all of these once onboarding is " +
      "finished.\" Marcus, Head of IT & Security Ops, overhears from the next desk.",
    dialogue: [
      { s: 'marcus', t: "Ha — sorry to eavesdrop. Just want to flag one thing people get wrong, because it's the one that bites." },
      { s: 'elena',  t: "He's right to. It's the single most common day-one misunderstanding." },
      { s: 'marcus', t: "People assume there's a grace period — that the rules switch on once you've finished the course or passed probation. So when do *you* think your confidentiality obligations actually begin?" },
    ],
    prompt: "Marcus asks: \"When do your obligations around confidentiality and data handling start?\"",
    options: [
      {
        id: 'a',
        text: "Once I've completed all 11 onboarding modules.",
        score: 'poor',
        reaction: { s: 'marcus', t: "That's the myth exactly. If that were true, your first two days would be a free-for-all — and you've already had access to things." },
        feedback:
          "This is the grace-period myth. Finishing the course doesn't switch obligations on — the employment relationship already did, on day one.",
      },
      {
        id: 'b',
        text: "When I first get access to a live client engagement.",
        score: 'ok',
        reaction: { s: 'marcus', t: "Closer — but you don't need to be on an engagement to overhear or see confidential things. You already can." },
        feedback:
          "Partly right in spirit, but too narrow. You don't have to touch a client file to leak one — a hallway conversation or a visible screen counts. Obligations cover everything from day one, not just engagement work.",
      },
      {
        id: 'c',
        text: "On my first day — before the course, before probation, before any client work.",
        score: 'best',
        reaction: { s: 'marcus', t: "That's it. No grace period. The moment you walked in, you were inside the perimeter — and some of these obligations outlast your employment, too." },
        feedback:
          "Correct. Your obligations begin on day one and many continue after you leave. There is no warm-up period — awareness has to start immediately.",
      },
    ],
  },

  // ── ACT 3 ───────────────────────────────────────────────────────────────────
  {
    id: 's3',
    act: 'Act 3 — The Coffee-Shop Question',
    title: 'A friend asks who your clients are',
    setting:
      "6:30 PM. You're at a café after work. A friend from another company is " +
      "genuinely curious about your new job. It's relaxed, friendly, completely " +
      "informal — exactly the setting where slips happen.",
    dialogue: [
      { s: 'auditor', t: "(Hannah, SI's external auditor, happens to be at the next table reviewing files. She isn't watching you — but this is precisely the kind of moment I write up in assessments.)" },
    ],
    prompt:
      "Your friend leans in: \"So what does Security Impossible actually do? Who are " +
      "your big clients — anyone I'd recognise?\" How do you answer?",
    options: [
      {
        id: 'a',
        text: "\"We do work for a couple of big banks and a government department. Last week we found some really critical stuff on one of them.\"",
        score: 'poor',
        reaction: { s: 'auditor', t: "(That just disclosed client sectors, implied identities, *and* a live finding. In an audit, that's a confirmed confidentiality breach — informal setting or not.)" },
        feedback:
          "This names sectors, hints at clients, and reveals an engagement finding. The 'friendly setting' offers no protection — this is exactly the accidental breach the policy is written to prevent.",
      },
      {
        id: 'b',
        text: "\"Between us — mostly finance and government work. Can't say more than that.\"",
        score: 'poor',
        reaction: { s: 'auditor', t: "('Between us' has no legal weight, and a sector hint still narrows the field enough for someone to guess. Still a slip.)" },
        feedback:
          "'Between us' creates no protection, and even a sector hint helps an observer reconstruct our client base. When in doubt, share nothing specific.",
      },
      {
        id: 'c',
        text: "\"We do cybersecurity consulting — assessments and advisory. I can't name clients or describe projects, but there's a good feel for the work on our public website.\"",
        score: 'best',
        reaction: { s: 'auditor', t: "(Textbook. Describes only what's already public, protects client relationships, redirects to a legitimate source. Nothing to write up.)" },
        feedback:
          "Exactly right. You described the firm in already-public terms, protected client identity, and pointed to a legitimate source — warm, professional, and fully compliant.",
      },
    ],
  },

  // ── ACT 4 ───────────────────────────────────────────────────────────────────
  {
    id: 's4',
    act: 'Act 4 — The Stakes, Made Real',
    title: 'What a single slip actually costs',
    setting:
      "Next morning, 8:55 AM. David, the Managing Director, catches you by the " +
      "coffee machine. He's warm but he wants to make one thing land before you " +
      "start real work.",
    dialogue: [
      { s: 'david',  t: "Heard your induction went well — welcome aboard properly. One story before you dive in, because numbers don't stick but this does." },
      { s: 'david',  t: "Years ago, at another firm, someone mentioned a client's name at a conference dinner. Harmless, they thought. That client heard about it, lost confidence, and walked. We lost the account and three referrals that came with it." },
      { s: 'priya',  t: "And that's the part people miss — it's never just one relationship." },
    ],
    prompt:
      "David asks: \"So — in your own words, why does one careless comment carry " +
      "so much weight here?\"",
    options: [
      {
        id: 'a',
        text: "\"Because it could lead to a regulatory fine for the company.\"",
        score: 'ok',
        reaction: { s: 'david', t: "A fine might come, sure. But the thing that actually ended that account wasn't a regulator — it was lost confidence." },
        feedback:
          "Fines are possible but secondary. The deeper cost is reputational: trust is hard to win and instant to lose, and lost trust takes clients and their referrals with it.",
      },
      {
        id: 'b',
        text: "\"Because trust is our whole product — one slip can cost a client, their referrals, and the firm's credibility, far beyond the single careless moment.\"",
        score: 'best',
        reaction: { s: 'david', t: "That's exactly the instinct I want you carrying into every engagement. You've got it. Welcome to the team." },
        feedback:
          "Spot on. The harm is disproportionate because trust is the product. A single slip can cascade into lost clients, lost referrals, and lasting reputational damage — which is why the careful instinct matters from day one.",
      },
      {
        id: 'c',
        text: "\"Because most breaches are deliberate, so we have to assume bad intent everywhere.\"",
        score: 'poor',
        reaction: { s: 'david', t: "Other way round, actually — almost all of them are accidents. That café comment yesterday? Nobody meant harm. That's the whole point." },
        feedback:
          "The opposite is true: most breaches are accidental, not malicious. That's precisely why everyday awareness — not suspicion of everyone — is the real defence.",
      },
    ],
  },
];

// Closing debrief shown after the final scene.
export const SCENARIO_DEBRIEF = {
  title: 'Debrief — You\u2019ve got the instinct',
  lines: [
    { s: 'elena', t: "That's the scenario. Notice none of these were dramatic — a question, a comment, a casual chat. That's where real risk lives." },
    { s: 'priya', t: "You've internalised the four things that matter most: trust is the product, obligations start on day one, client identity is confidential, and the careful instinct beats any checklist." },
    { s: 'david', t: "Carry that into every engagement and you'll do well here. On to Module 2." },
  ],
  takeaways: [
    'Security Impossible sells trust — our own security posture is the proof of our credibility.',
    'Obligations begin on day one and many survive the end of employment.',
    'Client identity — the very fact of who our clients are — is itself confidential.',
    'Most breaches are accidental; everyday awareness is your strongest defence.',
  ],
};
