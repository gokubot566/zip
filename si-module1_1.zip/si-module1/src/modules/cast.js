// ── Shared cast roster ───────────────────────────────────────────────────────
// The five people are constant across every Security Impossible lab — same id,
// same name, same brand colour, same portrait. Only the role/tagline is
// re-tagged per course to fit the scenario. Valid speaker ids are ONLY:
// elena, marcus, priya, david, auditor. (The 5th member's id is `auditor`,
// NOT `hannah`, even though her name is Hannah Wong.)
//
// Brand colours are each person's identity colour and are SEPARATE from the
// app's purple theme accent — never recolour a person to match the theme.

export const CHARACTERS = {
  elena: {
    name: 'Elena Vasquez',
    role: 'People & Compliance Lead',
    color: '#6366f1',                       // indigo
    tagline: 'Runs onboarding. Your first point of contact for "is this okay?"',
  },
  marcus: {
    name: 'Marcus Chen',
    role: 'Head of IT & Security Operations',
    color: '#3b82f6',                       // blue
    tagline: 'Owns the systems, the laptops, and the incident channel.',
  },
  priya: {
    name: 'Priya Patel',
    role: 'CISO',
    color: '#10b981',                       // green
    tagline: 'Accountable to the board for how SI protects client trust.',
  },
  david: {
    name: 'David Okafor',
    role: 'Managing Director',
    color: '#f59e0b',                       // amber
    tagline: 'Carries the client relationships. Knows what a leak costs.',
  },
  auditor: {
    name: 'Hannah Wong',
    role: 'External Auditor',
    color: '#06b6d4',                       // cyan
    tagline: 'Independent assessor. Checks we practise what we sell.',
  },
};

export const VALID_SPEAKERS = Object.keys(CHARACTERS);
