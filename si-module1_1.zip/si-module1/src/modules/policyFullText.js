// ── Full policy text for popup modal display ──────────────────────────────────
// Each policy contains the complete text as it would appear in the actual
// policy document — suitable for legal acknowledgement purposes.

export const FULL_POLICIES = {

  'Data Handling Policy': {
    ref: 'SI-POL-DATA',
    version: '2.1',
    effective: '1 January 2025',
    owner: 'Chief Information Security Officer',
    sections: [
      {
        heading: '1. Purpose',
        body: `This policy establishes the requirements for handling all data within Security Impossible Pty Ltd, including data belonging to clients, employees, contractors, and the company itself. It applies to all personnel and systems that create, receive, store, transmit, or dispose of company or client data.\n\nThe purpose of this policy is to ensure that data is handled in a manner that protects confidentiality, maintains integrity, and supports the company's legal obligations under the Privacy Act 1988, the Australian Privacy Principles (APPs), and applicable contractual commitments to clients.`,
      },
      {
        heading: '2. Scope',
        body: `This policy applies to:\n• All employees, contractors, interns, and third-party personnel working on behalf of Security Impossible\n• All data created, received, or accessed in the course of employment or engagement\n• All devices, systems, and communication channels used to process company or client data\n• Data in all formats — digital, printed, verbal, and handwritten`,
      },
      {
        heading: '3. Data Classification',
        body: `Security Impossible uses a four-tier classification scheme. All data must be classified at the point of creation or receipt:\n\n3.1 PUBLIC — Information approved for public release. No handling restrictions apply. Examples: published blog posts, marketing materials, public job advertisements.\n\n3.2 INTERNAL — Business information not approved for public disclosure. Must remain within the company. Examples: internal process documents, team plans, meeting agendas.\n\n3.3 CONFIDENTIAL — Sensitive information requiring strict access control. Includes all client data, client identity, engagement deliverables, internal IP, methodologies, commercial terms, pricing, and employee personal information. Must be encrypted at rest and in transit. Access limited to those with a legitimate need.\n\n3.4 HIGHLY CONFIDENTIAL — Information whose disclosure could cause critical harm to individuals or the company. Includes all personal information as defined under the Privacy Act 1988, system vulnerabilities discovered during engagements before remediation, credentials, and legally privileged communications. Highest protection required. Encryption mandatory. Access restricted to named individuals only.`,
      },
      {
        heading: '4. Handling Requirements by Classification',
        body: `4.1 Storage\nAll data must be stored only on company-approved systems. CONFIDENTIAL and HIGHLY CONFIDENTIAL data must be encrypted at rest using AES-256 or equivalent. Personal information (HIGHLY CONFIDENTIAL) must not be stored on portable devices unless encrypted and with prior written authorisation.\n\n4.2 Transmission\nCONFIDENTIAL and HIGHLY CONFIDENTIAL data must be encrypted in transit using TLS 1.2 or higher. Unencrypted transmission via email, messaging applications, or other informal channels is prohibited. External transmission requires engagement manager approval.\n\n4.3 Access Control\nAccess to data must be granted on a least-privilege, need-to-know basis. Access rights must be reviewed when an employee's role changes and revoked immediately upon departure. Shared credentials are prohibited.\n\n4.4 Disposal\nDigital data must be securely deleted using approved methods (overwriting or cryptographic erasure). Printed CONFIDENTIAL and HIGHLY CONFIDENTIAL materials must be shredded using a cross-cut shredder. Data must not be disposed of in general waste or recycling.`,
      },
      {
        heading: '5. Prohibited Actions',
        body: `The following are expressly prohibited:\n• Storing company or client data on personal devices, personal cloud storage (Google Drive, Dropbox, iCloud, etc.) or personal email accounts\n• Transmitting CONFIDENTIAL or HIGHLY CONFIDENTIAL data via personal messaging applications (WhatsApp, Signal, Telegram, etc.)\n• Sharing access credentials with any other person\n• Removing HIGHLY CONFIDENTIAL data from company systems without explicit written authorisation\n• Retaining client data beyond the conclusion of an engagement without contractual justification\n• Using client data for any purpose other than the agreed engagement purpose`,
      },
      {
        heading: '6. Breach Reporting',
        body: `Any suspected breach of this policy — including unauthorised access, loss, or disclosure of data — must be reported immediately to the Information Security team and the employee's direct manager. Do not attempt to investigate or remediate a suspected breach independently.\n\nBreaches involving personal information may trigger obligations under the Notifiable Data Breaches scheme, which requires notification to the OAIC and affected individuals within 30 days of assessment. Early reporting is essential to meeting these obligations.`,
      },
      {
        heading: '7. Consequences of Non-Compliance',
        body: `Failure to comply with this policy may result in disciplinary action up to and including termination of employment, and may result in personal legal liability where a breach involves personal information or client data subject to contractual protection. The company may also seek to recover losses caused by wilful or negligent non-compliance.`,
      },
      {
        heading: '8. Review',
        body: `This policy will be reviewed annually by the CISO and updated as required to reflect changes in legal obligations, business operations, or threat environment. All personnel will be notified of material changes.`,
      },
    ],
  },

  'Information Management Policy': {
    ref: 'SI-POL-INFO',
    version: '1.8',
    effective: '1 January 2025',
    owner: 'Chief Information Security Officer',
    sections: [
      {
        heading: '1. Purpose',
        body: `This policy establishes how Security Impossible Pty Ltd creates, organises, stores, accesses, retains, and disposes of information assets. It supports the company's obligations to clients, regulatory requirements under Australian law, and the security of proprietary information that constitutes core commercial value.`,
      },
      {
        heading: '2. Scope',
        body: `This policy applies to all information assets owned, created, or handled by Security Impossible, including lab content, methodologies, client deliverables, employee records, financial data, and all digital and physical documents created in the course of business.`,
      },
      {
        heading: '3. Use of Company Systems',
        body: `All work-related information processing must occur on company-provided systems. This includes:\n• Company-provisioned virtual machines (VMs) for all client-facing work\n• Approved communication platforms for internal and external correspondence\n• Approved cloud storage systems for all file storage and sharing\n\nPersonal computers, personal cloud accounts, personal email, and personal messaging applications must not be used to create, store, transmit, or process company or client information under any circumstances. This rule applies equally when working remotely, at client sites, or in any location outside company offices.`,
      },
      {
        heading: '4. Access Control',
        body: `4.1 Role-Based Access\nAccess to information systems and assets is granted based on role requirements and the principle of least privilege. Employees must not access, copy, or distribute information beyond what their role requires, even if they technically have the ability to do so.\n\n4.2 Access Reviews\nAccess rights are reviewed quarterly and immediately upon any change in employment status or role. Managers are responsible for notifying IT when an employee's information access requirements change.\n\n4.3 Guest and Third-Party Access\nThird parties, contractors, and guests may only be granted access to specific systems or information required for their work, subject to an executed confidentiality agreement. Access must be time-limited and revoked immediately upon completion of the engagement.`,
      },
      {
        heading: '5. Retention and Disposal',
        body: `Information must be retained only for as long as necessary for business purposes or legal requirements. Client engagement data must be disposed of in accordance with the engagement agreement, which typically specifies a retention period following project completion. Employee records are retained in accordance with applicable employment legislation.\n\nDisposal of digital information must use approved secure deletion methods. Physical documents containing CONFIDENTIAL or HIGHLY CONFIDENTIAL information must be shredded.`,
      },
      {
        heading: '6. Intellectual Property',
        body: `All information assets created by employees in the course of their employment are owned by Security Impossible Pty Ltd. This includes lab content, methodologies, scenarios, code, reports, presentations, and any other work product created using company resources or during working hours.\n\nEmployees may not retain copies of company IP upon departure. Copying or transferring company IP to personal storage at any time — and especially in anticipation of departure — constitutes a serious breach with legal consequences.`,
      },
      {
        heading: '7. Monitoring',
        body: `Company-provided systems are subject to monitoring for security purposes. This monitoring is conducted to detect threats, prevent data loss, and ensure compliance with company policies. Employees should have no expectation of privacy when using company systems. Monitoring records may be used in disciplinary or legal proceedings.`,
      },
    ],
  },

  'Intellectual Property Handling Policy': {
    ref: 'SI-POL-IP',
    version: '2.0',
    effective: '1 January 2025',
    owner: 'Chief Executive Officer',
    sections: [
      {
        heading: '1. Purpose',
        body: `This policy governs the creation, ownership, protection, and use of intellectual property (IP) at Security Impossible Pty Ltd. Security Impossible's core commercial assets — including lab content, cybersecurity scenarios, methodologies, software, and training materials — are protected IP. This policy ensures that IP is correctly attributed, protected, and not misused by employees, contractors, or third parties.`,
      },
      {
        heading: '2. Ownership of IP Created During Employment',
        body: `Subject to limited exceptions, all intellectual property created by an employee in the course of their employment with Security Impossible belongs to Security Impossible Pty Ltd. This includes:\n• Lab content, scenarios, walkthroughs, and course materials\n• Software, code, scripts, and tooling\n• Methodologies, frameworks, and assessment templates\n• Reports, documentation, and client deliverables\n• Inventions, discoveries, or improvements related to the company's business\n\nThis ownership applies regardless of whether the work was created during business hours or outside them, provided the work relates to the company's business activities or makes use of company resources or confidential information.\n\nIP created entirely outside working hours, on personal equipment, using no company resources, and unrelated to the company's business remains the employee's property. Where ambiguity exists, the employee must disclose the IP to their manager before using or commercialising it.`,
      },
      {
        heading: '3. Open-Source and Third-Party Licensing',
        body: `3.1 Licence Review Requirement\nBefore incorporating any open-source software, library, framework, or content into company products or client deliverables, the employee must review the applicable licence and confirm that the licence permits the intended use.\n\n3.2 Copyleft Licences\nLicences such as the GNU General Public Licence (GPL) impose share-alike obligations that require derivative works to be distributed under the same licence. This conflicts with Security Impossible's commercial licensing model. GPL-licensed components must not be incorporated into commercial products or client deliverables without prior written approval from the CEO or General Counsel.\n\n3.3 Attribution\nWhere a licence requires attribution, the employee must ensure attribution is correctly applied and documented. Failure to attribute is a breach of the licence and may expose the company to legal liability.\n\n3.4 Prohibited Use\nThe following are prohibited without prior written approval:\n• Incorporating GPL, AGPL, or other copyleft-licensed components into commercial content\n• Using third-party content without confirming licence terms\n• Removing or modifying copyright notices or licence headers`,
      },
      {
        heading: '4. AI Tools and AI-Generated Content',
        body: `4.1 AI IP Ownership\nAI technologies, tools, models, or systems developed by employees during their employment belong to Security Impossible Pty Ltd.\n\n4.2 Third-Party AI Tools\nWhen using third-party AI tools (including but not limited to OpenAI, Google, Anthropic, and Microsoft AI products), employees must:\n• Never input confidential information, client data, personal information, credentials, or proprietary methodologies into any public AI tool\n• Comply with the AI tool's terms of service and licence\n• Verify that AI-generated outputs do not reproduce copyrighted material, infringe third-party IP, or violate applicable laws\n\n4.3 Verification Obligation\nAI-generated outputs may reproduce training data, including copyrighted material, without attribution. The employee is responsible for verifying that all AI-assisted work product is original, accurate, and compliant with this policy before use.\n\n4.4 Reporting\nEmployees who develop significant AI technology or IP in the course of their employment must report it to their manager for proper recording and management.`,
      },
      {
        heading: '5. Departure',
        body: `Upon the termination of employment for any reason, the employee must:\n• Return all company IP, materials, and devices\n• Delete all company IP from personal devices\n• Confirm in writing that no copies of company IP have been retained\n\nRetaining, copying, or misappropriating company IP upon or in anticipation of departure constitutes a serious breach of this policy and the Employee Confidentiality & IP Deed, and may result in civil legal proceedings.`,
      },
    ],
  },

  'Privacy Policy': {
    ref: 'SI-POL-PRIV',
    version: '3.1',
    effective: '1 January 2025',
    owner: 'Privacy Officer',
    sections: [
      {
        heading: '1. Purpose and Legal Framework',
        body: `Security Impossible Pty Ltd is bound by the Privacy Act 1988 (Cth) and the 13 Australian Privacy Principles (APPs). This policy sets out how the company collects, uses, stores, discloses, and disposes of personal information, and the obligations of all personnel when handling personal information in the course of their work.\n\nBreaches of this policy may constitute a breach of the Privacy Act 1988, which can result in regulatory investigation, civil penalties of up to $50 million for serious or repeated breaches (Privacy Act amendments 2023), reputational harm, and client claims.`,
      },
      {
        heading: '2. What is Personal Information',
        body: `Personal information is any information or opinion about an identified individual or an individual who is reasonably identifiable, whether the information is true or not, and whether the information is recorded in a material form or not.\n\nThis includes names, email addresses, phone numbers, employment details, IP addresses, device identifiers, location data, and any other information that could be linked to a specific person.\n\nSensitive information is a subset of personal information that attracts higher protection requirements. It includes:\n• Health information\n• Racial or ethnic origin\n• Political opinions\n• Membership of political associations or trade unions\n• Religious beliefs or affiliations\n• Philosophical beliefs\n• Sexual orientation or gender identity\n• Criminal record\n• Biometric information\n\nSensitive information must only be collected with explicit consent and when strictly necessary for the engagement purpose.`,
      },
      {
        heading: '3. Collection',
        body: `Personal information must only be collected when it is necessary for the specific engagement or business function. The collection must be by lawful and fair means. Where practicable, personal information must be collected directly from the individual.\n\nWhen personal information is encountered during a client engagement (such as employee records, customer lists, or system access logs), it must be treated as HIGHLY CONFIDENTIAL and used only for the engagement purpose. It must not be accessed beyond what is necessary, retained beyond the engagement period, or shared with anyone not authorised on the engagement.`,
      },
      {
        heading: '4. Use and Disclosure',
        body: `4.1 Use Limitation (APP 6)\nPersonal information must only be used or disclosed for the primary purpose for which it was collected, or for a secondary purpose where the individual would reasonably expect such use, or where required or authorised by law.\n\nUsing client employee records accessed during an engagement for any purpose other than that engagement is a breach of APP 6 and this policy.\n\n4.2 Overseas Disclosure\nPersonal information must not be transferred to recipients in foreign countries unless those countries have equivalent privacy protections or the individual has consented to the transfer.\n\n4.3 Third-Party Disclosure\nPersonal information must not be disclosed to third parties — including subcontractors, vendors, or other clients — without explicit authorisation and appropriate data protection agreements in place.`,
      },
      {
        heading: '5. Security (APP 11)',
        body: `APP 11 requires the company to take reasonable steps to protect personal information from misuse, interference, loss, and unauthorised access, modification, or disclosure.\n\nFor all employees, this means:\n• Storing personal information only on approved, encrypted company systems\n• Not transmitting personal information via unencrypted channels\n• Restricting access to personal information to authorised personnel only\n• Reporting any suspected loss or unauthorised access to the Privacy Officer immediately`,
      },
      {
        heading: '6. Notifiable Data Breaches (NDB Scheme)',
        body: `Under the Notifiable Data Breaches scheme (Part IIIC of the Privacy Act), Security Impossible is required to notify the OAIC and affected individuals when an eligible data breach occurs.\n\nAn eligible data breach occurs when:\n(a) there is unauthorised access to, disclosure of, or loss of personal information\n(b) the access, disclosure, or loss is likely to result in serious harm to one or more individuals\n\nThe company has 30 days to complete an assessment once it becomes aware of grounds to suspect an eligible data breach. Notification must occur as soon as practicable once an eligible data breach is confirmed.\n\nAny employee who suspects a data breach has occurred — or that one may have occurred — must report it to the Privacy Officer and Information Security team immediately. Do not attempt to assess or remediate independently.`,
      },
      {
        heading: '7. Individual Rights',
        body: `Individuals have the right to access personal information the company holds about them (APP 12) and to request correction of inaccurate or incomplete information (APP 13). Requests must be directed to the Privacy Officer and responded to within 30 days.`,
      },
    ],
  },

  'Asset Management Policy': {
    ref: 'SI-POL-ASSET',
    version: '2.3',
    effective: '1 January 2025',
    owner: 'IT Manager',
    sections: [
      {
        heading: '1. Purpose',
        body: `This policy establishes the requirements for the management, use, and protection of all hardware, software, and information assets owned by or assigned to Security Impossible Pty Ltd. It ensures that company assets are used appropriately, protected from loss or damage, and returned upon termination of employment.`,
      },
      {
        heading: '2. Asset Assignment',
        body: `Company assets (laptops, virtual machines, mobile devices, software licences) are assigned to individual employees and recorded in the asset register. The assigned employee is responsible for the safekeeping and appropriate use of the asset for the duration of the assignment. Asset assignment does not transfer ownership — all assets remain company property.`,
      },
      {
        heading: '3. Use of Virtual Machines and Personal Devices',
        body: `3.1 Company VMs Only\nAll work-related tasks — including data processing, client communication, report writing, and code development — must be performed exclusively on company-provided virtual machines and systems. This requirement applies in all work environments, including home offices, client sites, and shared workspaces.\n\n3.2 Prohibition on Personal Devices\nPersonal computers, laptops, tablets, smartphones, and external storage devices must not be used for any company or client work. This prohibition is absolute and applies regardless of urgency, technical issues with company devices, or manager approval. No exception to this rule exists.\n\n3.3 No Data Transfer to Personal Storage\nCompany or client data must never be transferred to:\n• Personal email accounts\n• Personal cloud storage (Google Drive, Dropbox, OneDrive personal, iCloud, etc.)\n• Personal messaging applications\n• USB drives or external storage not issued by the company\n• Any location outside company-approved systems`,
      },
      {
        heading: '4. Monitoring',
        body: `Company-provided assets are subject to monitoring to ensure security compliance, detect threats, and prevent data loss. By accepting and using a company asset, employees consent to this monitoring. Monitoring records may be used in disciplinary investigations and legal proceedings. Employees have no expectation of privacy on company systems.`,
      },
      {
        heading: '5. Loss, Theft, and Damage',
        body: `Any loss, theft, suspected theft, or significant damage to a company asset must be reported to the IT team and the employee's direct manager immediately — and in all cases within two hours of discovery. Delay in reporting may allow compromise of company or client data and may be treated as a policy breach.\n\nUpon receiving a report of loss or theft, the IT team will remotely wipe the device where technically possible. Employees must assist with this process.`,
      },
      {
        heading: '6. Credential Management',
        body: `6.1 Password Requirements\nAll passwords must be at least 14 characters, using a combination of upper and lower case letters, numbers, and special characters. Passwords must not be reused across systems.\n\n6.2 Multi-Factor Authentication\nMFA must be enabled on all accounts that support it, and is mandatory for all systems containing CONFIDENTIAL or HIGHLY CONFIDENTIAL data.\n\n6.3 Password Sharing\nSharing credentials with any other person — including colleagues, managers, or IT support staff — is prohibited. IT support will never ask for your password.`,
      },
      {
        heading: '7. Return of Assets',
        body: `All company assets must be returned in good working condition upon termination of employment, regardless of the reason for departure. The IT team will conduct a data wipe and audit upon return. Failure to return assets may result in the cost of replacement being deducted from final pay, subject to applicable employment law.`,
      },
    ],
  },

  'Remote Work Policy': {
    ref: 'SI-POL-REMOTE',
    version: '1.5',
    effective: '1 January 2025',
    owner: 'IT Manager',
    sections: [
      {
        heading: '1. Purpose',
        body: `This policy sets out the security requirements that apply when employees work remotely — whether from home, client sites, shared workspaces, or any location other than company offices. Because we work in a distributed environment, every employee's home or remote work environment is part of the company's security perimeter.`,
      },
      {
        heading: '2. Device Requirements',
        body: `When working remotely, employees must use only company-provided virtual machines and systems. All requirements of the Asset Management Policy apply fully in remote settings. The use of personal devices for company work is prohibited regardless of location.`,
      },
      {
        heading: '3. Network Security',
        body: `3.1 Home Networks\nHome Wi-Fi networks must be secured with WPA2 or WPA3 encryption and a strong, unique password. The router firmware must be kept up to date. Default router credentials must be changed.\n\n3.2 Public Wi-Fi\nPublic Wi-Fi networks (cafés, airports, hotels, libraries) must not be used for company work without the company VPN active. The VPN encrypts traffic and prevents interception by third parties on shared networks.\n\n3.3 VPN Requirement\nThe company VPN must be active whenever accessing company systems from any network other than the employee's home network. The VPN must remain active for the duration of the work session.`,
      },
      {
        heading: '4. Physical Security',
        body: `4.1 Screen Locking\nThe company device must be locked whenever the employee steps away from it. The device must be configured to lock automatically after a maximum of 5 minutes of inactivity.\n\n4.2 Screen Visibility\nWhen working in any shared or public space, the employee must ensure that the screen is not visible to others. A privacy screen is required when working in locations where others may be able to see the display.\n\n4.3 Confidential Conversations\nConversations about client engagements, internal matters, or any CONFIDENTIAL or HIGHLY CONFIDENTIAL information must not take place in public spaces where they can be overheard. Video calls discussing client matters must be conducted from a private location.\n\n4.4 Secure Storage\nWhen not in use, company devices must be stored in a locked location. Devices must not be left unattended in vehicles.`,
      },
      {
        heading: '5. Incident Reporting',
        body: `Any security concern arising in a remote work context — including suspected unauthorised access to the device, loss of the device, or exposure of confidential information in a public space — must be reported to IT and the employee's manager immediately.`,
      },
    ],
  },

  'Incident Response Policy': {
    ref: 'SI-POL-IR',
    version: '2.2',
    effective: '1 January 2025',
    owner: 'Chief Information Security Officer',
    sections: [
      {
        heading: '1. Purpose',
        body: `This policy defines how Security Impossible Pty Ltd identifies, reports, assesses, and responds to security incidents. A security incident is any event that has caused or could cause unauthorised access to, disclosure of, loss of, or damage to company or client information, systems, or assets.\n\nFast, accurate reporting of security incidents is critical. It enables the company to contain damage, meet legal obligations under the Notifiable Data Breaches scheme, and maintain client trust.`,
      },
      {
        heading: '2. What to Report',
        body: `The following must be reported immediately as potential security incidents:\n• Clicking a suspicious link or opening a suspicious attachment\n• Submitting credentials to what may have been a phishing site\n• Receiving an email that appears to be business email compromise\n• Loss or theft of a company device\n• Accidental disclosure of confidential or personal information\n• Suspected unauthorised access to company systems or accounts\n• Receiving requests to bypass normal procedures from unknown or unverified sources\n• Discovery of malware or unexpected software on a company device\n• Any situation that "feels wrong" from a security perspective\n\nWhen in doubt, report. The cost of a false alarm is negligible. The cost of a missed incident is potentially catastrophic.`,
      },
      {
        heading: '3. How to Report',
        body: `Security incidents must be reported immediately to:\n• The Incident Response Team: ir@securityimpossible.com\n• Your direct manager\n\nDo not report security incidents via personal email, personal messaging apps, or channels that may themselves be compromised. If your company email is suspected to be compromised, contact your manager by phone.\n\nWhen reporting, provide:\n• What happened (as much detail as you can)\n• When it happened\n• What systems, data, or people are potentially affected\n• What actions you have already taken`,
      },
      {
        heading: '4. Incident Severity Levels',
        body: `The IR team will classify incidents by severity:\n\nHIGH — Immediate action required. Examples: confirmed data breach, active ransomware, confirmed account compromise, loss of device containing unencrypted CONFIDENTIAL data.\n\nMEDIUM — Investigation required within 24 hours. Examples: phishing attempt received, suspected but unconfirmed account compromise, policy breach with potential data exposure.\n\nLOW — Review required within 72 hours. Examples: policy breach with no data exposure, suspicious email received but not clicked.\n\nYou do not need to determine the severity level yourself — just report quickly and completely.`,
      },
      {
        heading: '5. Do Not Investigate Independently',
        body: `Employees must not attempt to investigate, remediate, or resolve a suspected security incident independently. Independent investigation:\n• May destroy evidence needed for forensic analysis\n• May allow an attacker to cover their tracks\n• May cause the employee to inadvertently take actions that constitute a further breach\n• Delays proper response\n\nUpon reporting, follow the instructions of the IR team. Do not delete anything, do not change passwords unless instructed, and do not discuss the incident outside the authorised response team.`,
      },
      {
        heading: '6. Protection from Reprisal',
        body: `Employees who report security incidents in good faith will not face disciplinary consequences for the underlying mistake. The company recognises that fast reporting — even of self-caused incidents — dramatically limits damage and may be legally required. Deliberate concealment of a security incident, however, is a serious disciplinary matter.`,
      },
      {
        heading: '7. Post-Incident Review',
        body: `Following resolution of any HIGH or MEDIUM severity incident, the IR team will conduct a post-incident review to identify root causes and improve controls. Affected employees may be asked to participate in this review. Participation is mandatory.`,
      },
    ],
  },

  'Acceptable Use Policy': {
    ref: 'SI-POL-AUP',
    version: '2.0',
    effective: '1 January 2025',
    owner: 'Chief Information Security Officer',
    sections: [
      {
        heading: '1. Purpose',
        body: `This policy defines acceptable use of Security Impossible Pty Ltd's technology resources, including company-provided systems, software, internet access, email, and communication tools. It applies to all employees, contractors, and interns who use company technology resources.`,
      },
      {
        heading: '2. Permitted Use',
        body: `Company technology resources are provided to enable effective performance of work duties. Permitted uses include:\n• Performing job-related tasks and responsibilities\n• Communicating with colleagues, clients, and partners for business purposes\n• Accessing information required for work functions\n• Using approved software and services\n\nIncidental personal use of company resources is permitted where it does not interfere with work duties, does not violate this policy, and does not consume significant bandwidth or storage.`,
      },
      {
        heading: '3. Prohibited Use',
        body: `The following uses are expressly prohibited:\n• Accessing, creating, or distributing pornographic, offensive, or illegal content\n• Personal social media use on company devices (incidental personal use excluded — social media during work hours on company devices for personal purposes is prohibited)\n• Downloading or installing unapproved software\n• Circumventing security controls, firewalls, or monitoring systems\n• Using company resources for personal commercial activities\n• Accessing systems or data beyond the scope of authorised access\n• Attempting to access other users' accounts or private communications\n• Participating in or facilitating cyberbullying, harassment, or discrimination\n• Using company systems for any illegal activity`,
      },
      {
        heading: '4. Email Use',
        body: `Company email accounts must be used for business communication. Forwarding company or client emails to personal email accounts is prohibited. Bulk email, chain letters, and unsolicited commercial messages must not be sent from company accounts. Employees must exercise care when opening email attachments and links, and must report suspicious emails to IT.`,
      },
      {
        heading: '5. Secure Coding Practices',
        body: `Employees whose roles involve software development must adhere to the following secure coding standards:\n• OWASP Top 10 — All web application code must address the current OWASP Top 10 vulnerabilities\n• SANS CWE Top 25 — Code must avoid the most dangerous software weaknesses\n• Input validation — All user inputs must be validated and sanitised\n• Authentication — Secure authentication (including MFA where applicable) must be implemented\n• Error handling — System internals must not be revealed in error messages\n• Dependencies — Only actively maintained libraries with known security posture must be used\n• Code review — All code must be reviewed by a qualified peer before deployment\n• Documentation — Secure coding compliance must be documented and available for audit`,
      },
      {
        heading: '6. Monitoring and Privacy',
        body: `Employees using company technology resources have no expectation of privacy. The company monitors network traffic, system activity, email, and application use for security and compliance purposes. Monitoring records may be used in disciplinary investigations and legal proceedings. By using company systems, employees consent to this monitoring.`,
      },
      {
        heading: '7. Consequences',
        body: `Violation of this policy may result in:\n• Immediate suspension of system access\n• Disciplinary action up to and including termination\n• Civil or criminal liability where the violation involves illegal activity\n• Personal liability for losses caused to the company or clients`,
      },
    ],
  },

  'AI Use Policy': {
    ref: 'SI-POL-AI',
    version: '1.2',
    effective: '1 March 2025',
    owner: 'Chief Information Security Officer',
    sections: [
      {
        heading: '1. Purpose',
        body: `This policy governs the use of artificial intelligence (AI) tools — including large language models, generative AI, coding assistants, and AI-powered productivity tools — by Security Impossible Pty Ltd employees. AI tools present significant productivity benefits but also carry specific and serious confidentiality, IP, and accuracy risks that require active management.`,
      },
      {
        heading: '2. The Core Risk',
        body: `When you submit a prompt to a commercial AI service, the content of that prompt is transmitted to and processed by the AI provider's external servers. Depending on the service's terms and your account settings, the prompt content may be:\n• Stored by the provider\n• Used to train or improve the AI model\n• Accessible to the provider's staff\n• Subject to the provider's data retention and deletion policies\n\nThis means submitting confidential, client, or personal information to a public AI tool is equivalent to transmitting that information to an external third party — a breach of confidentiality obligations regardless of the AI tool's specific policies.`,
      },
      {
        heading: '3. Prohibited Inputs',
        body: `The following must never be submitted to any public or consumer AI tool:\n• Client identity or any client-identifying information\n• Client data, code, configurations, or architecture details\n• Personal information about any individual\n• Security credentials, API keys, passwords, tokens, or certificates\n• Proprietary Security Impossible methodologies, lab content, or internal documentation\n• Information classified CONFIDENTIAL or HIGHLY CONFIDENTIAL\n• Information subject to legal professional privilege\n\nThis prohibition applies regardless of whether the AI tool claims not to store or train on user data.`,
      },
      {
        heading: '4. Permitted Use',
        body: `AI tools may be used for:\n• Drafting and editing general content not involving confidential information\n• Generating synthetic or fictional data for testing or demonstration purposes\n• Summarising publicly available information\n• Assisting with code that uses only sanitised, fictional, or publicly available data\n• Research into general cybersecurity topics not involving client specifics\n\nWhen using AI for code assistance, replace all client-specific values (URLs, IP addresses, credentials, system names) with clearly fictional placeholders before submitting.`,
      },
      {
        heading: '5. Verification Obligation',
        body: `AI-generated content must be verified before use. AI tools can:\n• Generate factually incorrect information presented with apparent confidence\n• Reproduce copyrighted material without attribution\n• Produce code containing security vulnerabilities\n• Provide legal, regulatory, or technical guidance that is inaccurate\n\nEmployees are responsible for the accuracy, legality, and security of any AI-assisted work product before it is submitted to a client, published, or used in company systems.`,
      },
      {
        heading: '6. Approved Enterprise AI Tools',
        body: `The company may from time to time approve enterprise AI tools with appropriate data protection agreements. A list of currently approved tools is maintained by the CISO. Only approved tools may be used with CONFIDENTIAL data, subject to the specific terms of their approval. The list of approved tools does not include consumer AI services (ChatGPT, Claude.ai, Gemini, Copilot consumer versions, etc.) for confidential work.`,
      },
      {
        heading: '7. AI IP Ownership',
        body: `AI tools, models, or systems developed by employees during their employment belong to Security Impossible Pty Ltd. Significant AI development work must be reported to the employee's manager for proper IP recording and management.`,
      },
    ],
  },

  'Social Media Sharing Policy': {
    ref: 'SI-POL-SOCIAL',
    version: '1.6',
    effective: '1 January 2025',
    owner: 'Chief Executive Officer',
    sections: [
      {
        heading: '1. Purpose',
        body: `This policy governs how Security Impossible Pty Ltd employees use social media in ways that could affect the company, its clients, its reputation, or its commercial interests. For a security consulting firm, social media presents unique risks: client relationships, engagement details, vulnerability findings, and proprietary methodology can all be inadvertently disclosed through seemingly innocent posts.`,
      },
      {
        heading: '2. Identifying Yourself as a Security Impossible Employee',
        body: `When you publicly identify yourself as an employee of Security Impossible — in a bio, profile, post, or casual mention — you implicitly represent the firm. The standards of professionalism, confidentiality, and ethical conduct that apply in your employment also apply to your online professional presence.\n\nThis does not prevent you from maintaining a personal social media presence or expressing personal opinions. It does mean that your online conduct reflects on the firm and must not breach your confidentiality obligations.`,
      },
      {
        heading: '3. Confidentiality on Social Media',
        body: `The following must never be shared on social media, regardless of privacy settings:\n• Client identity — including any information that could be used to identify a client\n• The existence of a client relationship\n• Details of any engagement, assessment, or finding\n• Proprietary Security Impossible methodologies, lab content, or tools\n• Internal company information, strategy, or financial data\n• Information about colleagues, including personnel matters\n\nSubtle disclosures are as prohibited as explicit ones. "Wrapped up an amazing pentest — big name in finance, found something critical" identifies a client through context even without naming them.`,
      },
      {
        heading: '4. The Limits of "Views Are My Own"',
        body: `Adding "Views are my own" or similar disclaimers to a social media profile or post separates your personal opinions from official company statements. This is good practice.\n\nHowever, a disclaimer does NOT:\n• Authorise disclosure of confidential information\n• Protect the company or you from liability for defamatory statements\n• Permit sharing of client information or engagement details\n• Justify posting proprietary company content\n• Exempt you from the obligations in this policy\n\nA disclaimer is a clarification of attribution, not a waiver of professional obligations.`,
      },
      {
        heading: '5. Protecting Company IP',
        body: `Lab content, scenarios, methodology, tooling, and course materials are Security Impossible's commercial IP. Publishing, sharing, or posting this content — even to demonstrate your own skills — gives away commercial product and competitive advantage.\n\nIf you wish to demonstrate skills publicly, build something personal and entirely unrelated to company IP, on your own time and using your own equipment.`,
      },
      {
        heading: '6. Photography and Video',
        body: `Before posting any photograph or video taken at or related to Security Impossible — including at conferences, client sites, or company events — check for:\n• Visible screens showing confidential content\n• Whiteboards or documents with client information\n• System diagrams, network maps, or architecture drawings\n• Colleague information shared without consent\n\nWhen in doubt, do not post.`,
      },
      {
        heading: '7. Crisis Communication',
        body: `In the event of a security incident, data breach, client issue, or any situation that could attract media attention, all external communication — including social media — must go through designated official channels only. Employees must not speculate, comment, or share information about ongoing incidents or crises on any platform. Failure to follow this requirement during a crisis is a serious disciplinary matter.`,
      },
      {
        heading: '8. Reporting Accidental Disclosures',
        body: `If you become aware that you have accidentally shared confidential or proprietary information on social media, remove the content immediately and report the disclosure to your manager and the CISO. Early reporting enables the company to assess and, where necessary, notify affected parties.`,
      },
    ],
  },

  'Employee Confidentiality & IP Deed': {
    ref: 'SI-DEED',
    version: '3.0',
    effective: '1 January 2025',
    owner: 'Chief Executive Officer',
    sections: [
      {
        heading: 'IMPORTANT LEGAL NOTICE',
        body: `This is a legally binding document. By signing or electronically acknowledging this Deed, you enter into enforceable legal obligations with Security Impossible Pty Ltd (ABN 00 000 000 000). You should read this Deed carefully and seek independent legal advice if you are unsure of any of its terms.`,
      },
      {
        heading: '1. Definitions',
        body: `In this Deed:\n"Company" means Security Impossible Pty Ltd.\n"Confidential Information" means all non-public information you receive or create in the course of your employment, including client data, client identity, methodologies, lab content, commercial information, personnel information, and any other information the Company treats as confidential.\n"Intellectual Property" or "IP" means all intellectual property rights including copyright, patents, trade marks, trade secrets, know-how, and all other proprietary rights.\n"Company IP" means all IP created by you in the course of your employment, whether or not created during business hours.`,
      },
      {
        heading: '2. Confidentiality Obligations',
        body: `2.1 You acknowledge that in the course of your employment you will receive and create Confidential Information.\n\n2.2 You undertake that you will:\n(a) keep all Confidential Information strictly confidential\n(b) not disclose Confidential Information to any person without prior written authorisation\n(c) use Confidential Information only for the purposes of your employment\n(d) take all reasonable steps to prevent unauthorised disclosure of Confidential Information\n(e) immediately report any actual or suspected breach of confidentiality to the CISO\n\n2.3 These obligations apply to all Confidential Information, regardless of whether it is marked as confidential.\n\n2.4 These obligations survive the termination of your employment and continue indefinitely.`,
      },
      {
        heading: '3. Intellectual Property Assignment',
        body: `3.1 You acknowledge that all IP created by you in the course of your employment — including all lab content, methodologies, code, tools, reports, and other work product — is created on behalf of the Company and is owned by the Company from the moment of creation.\n\n3.2 To the extent that ownership does not automatically vest in the Company at the moment of creation, you hereby assign to the Company all IP rights in all work product created in the course of your employment, including all future rights.\n\n3.3 You agree to execute all documents and take all steps reasonably necessary to give effect to the assignment in this clause.\n\n3.4 You waive all moral rights in work product created in the course of your employment, to the extent permitted by law.`,
      },
      {
        heading: '4. Obligations on Departure',
        body: `4.1 Upon the termination of your employment for any reason, you must:\n(a) immediately return all Company property, including all devices, documents, and materials containing Confidential Information or Company IP\n(b) permanently delete all Confidential Information and Company IP from personal devices, personal email accounts, and personal cloud storage\n(c) confirm in writing within 5 business days of departure that you have complied with this clause\n\n4.2 You must not, after termination:\n(a) retain any copy of Confidential Information or Company IP\n(b) use, disclose, or commercialise Confidential Information or Company IP\n(c) use knowledge of Company methodologies, client relationships, or competitive advantage for the benefit of any competitor`,
      },
      {
        heading: '5. Non-Solicitation',
        body: `For a period of 12 months following the termination of your employment, you must not:\n(a) directly or indirectly solicit or induce any employee, contractor, or consultant of the Company to leave the Company\n(b) directly or indirectly solicit any client of the Company with whom you had material involvement during your employment, for the purpose of providing services competitive with those of the Company`,
      },
      {
        heading: '6. Remedies',
        body: `6.1 You acknowledge that a breach or threatened breach of this Deed would cause irreparable harm to the Company for which monetary damages would be an inadequate remedy.\n\n6.2 The Company is entitled to seek injunctive relief and other equitable remedies in addition to any other remedies available at law or in equity.\n\n6.3 The Company may recover from you all losses, damages, and costs (including legal costs on an indemnity basis) arising from any breach of this Deed.`,
      },
      {
        heading: '7. Acknowledgement',
        body: `By signing or electronically acknowledging this Deed, you confirm that:\n(a) you have read and understood this Deed in its entirety\n(b) you have had the opportunity to seek independent legal advice\n(c) you enter into this Deed freely and voluntarily\n(d) you understand that your obligations under this Deed survive the termination of your employment\n(e) you agree to be bound by the terms of this Deed`,
      },
    ],
  },

  'Full Policy Acknowledgement': {
    ref: 'SI-ACK-ALL',
    version: '2.0',
    effective: '1 January 2025',
    owner: 'Chief Executive Officer',
    sections: [
      {
        heading: 'Full Policy Acknowledgement Statement',
        body: `By completing this acknowledgement, you confirm the following:`,
      },
      {
        heading: '1. Policies Read and Understood',
        body: `I confirm that I have read, understood, and agree to comply with each of the following Security Impossible Pty Ltd policies:\n\n• Asset Management Policy (SI-POL-ASSET)\n• Data Handling Policy (SI-POL-DATA)\n• Information Management Policy (SI-POL-INFO)\n• Intellectual Property Handling Policy (SI-POL-IP)\n• Social Media Sharing Policy (SI-POL-SOCIAL)\n• Privacy Policy (SI-POL-PRIV)\n• Acceptable Use Policy (SI-POL-AUP)\n• Incident Response Policy (SI-POL-IR)\n• AI Use Policy (SI-POL-AI)\n• Remote Work Policy (SI-POL-REMOTE)\n• Employee Confidentiality & IP Deed (SI-DEED)`,
      },
      {
        heading: '2. Obligations Understood',
        body: `I understand and accept that:\n\n(a) My obligations under these policies begin on my first day of employment and many continue indefinitely after the termination of my employment.\n\n(b) The confidentiality obligations in these policies — and in the Employee Confidentiality & IP Deed — are legally enforceable and survive my departure from Security Impossible.\n\n(c) All intellectual property I create in the course of my employment belongs to Security Impossible Pty Ltd.\n\n(d) I must report any security incident, suspected breach, or policy violation immediately to the Information Security team.\n\n(e) Failure to comply with these policies may result in disciplinary action up to and including termination of employment, and may result in legal action.`,
      },
      {
        heading: '3. No Retention of Confidential Information',
        body: `I confirm that I understand I must not retain, copy, or remove any Confidential Information or Company IP upon the termination of my employment, and that I must return all company property and confirm deletion of all company data from personal devices within 5 business days of my departure.`,
      },
      {
        heading: '4. Voluntary Acknowledgement',
        body: `I make this acknowledgement freely and voluntarily. I have had the opportunity to read the relevant policies in full and to seek clarification on any terms I did not understand. This acknowledgement forms part of my employment record.`,
      },
    ],
  },

};
