import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, ArrowLeft, ArrowRight, ClipboardList, Check, Lock, ExternalLink } from 'lucide-react';
import Header from './components/Header.jsx';
import Sidebar from './components/Sidebar.jsx';
import ModuleContent from './components/ModuleContent.jsx';
import ByteAssistant from './components/ByteAssistant.jsx';
import PolicyModal from './components/PolicyModal.jsx';
import LoginGate from './components/LoginGate.jsx';
import { ALL_MODULES } from './modules/moduleData.js';

const STORAGE_KEY = 'si_onboarding_v5';
const load = () => { try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); } catch { return {}; } };
const save = s => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(s)); } catch {} };

/* ─── Module hero ─────────────────────────────────────────────────────────── */
function ModuleHero({ mod, isComplete }) {
  const hasPol = mod.policyAck?.length > 0;
  return (
    <div style={{
      background: '#fff',
      border: '1px solid #e2e4e9',
      borderRadius: 10,
      padding: '28px 32px',
      marginBottom: 20,
      boxShadow: '0 1px 4px rgba(0,0,0,0.05)',
    }}>
      {/* Tags */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
        <span className="badge badge-default">Module {String(mod.id).padStart(2, '0')}</span>
        <span className="badge badge-default">{mod.duration}</span>
        {isComplete && <span className="badge badge-green">✓ Complete</span>}
        {hasPol && !isComplete && <span className="badge badge-amber">Acknowledgement required</span>}
      </div>

      {/* Title */}
      <h1 style={{
        fontFamily: "'Inter', sans-serif", fontWeight: 700, fontSize: 26,
        color: '#0f1117', letterSpacing: '-0.025em', lineHeight: 1.2, marginBottom: 6,
      }}>{mod.title}</h1>

      {/* Subtitle — policy mapping */}
      <p style={{
        fontFamily: "'DM Mono', monospace", fontSize: 12,
        color: '#9ca3af', lineHeight: 1.5, marginBottom: 20,
      }}>{mod.subtitle}</p>

      <div style={{ height: 1, background: '#f0f1f3', marginBottom: 20 }}/>

      {/* Learning objectives */}
      <div style={{
        fontFamily: "'DM Mono', monospace", fontSize: 10.5,
        color: '#9ca3af', letterSpacing: '0.07em', marginBottom: 12,
      }}>LEARNING OBJECTIVES</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '9px 28px' }}>
        {mod.keyPoints.map((kp, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 9 }}>
            <div style={{
              width: 5, height: 5, borderRadius: '50%', background: '#6d28d9',
              marginTop: 8, flexShrink: 0,
            }}/>
            <span style={{
              fontFamily: "'Inter', sans-serif", fontSize: 13.5, color: '#3d4350', lineHeight: 1.55,
            }}>{kp}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Complete banner ─────────────────────────────────────────────────────── */
function CompleteBanner({ mod, hasNext, onNext }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16,
      padding: '14px 20px',
      background: '#f0fdf4', border: '1px solid #86efac', borderRadius: 8,
      marginBottom: 20,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          width: 34, height: 34, borderRadius: 7, flexShrink: 0,
          background: '#dcfce7', border: '1px solid #86efac',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Check size={16} color="#16a34a" strokeWidth={2.5}/>
        </div>
        <div>
          <div style={{
            fontFamily: "'Inter', sans-serif", fontWeight: 600,
            fontSize: 14, color: '#166534', marginBottom: 2,
          }}>Module {mod.id} complete</div>
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: '#4ade80' }}>
            {hasNext ? 'Progress saved. Continue when ready.' : 'You have completed all 11 modules.'}
          </div>
        </div>
      </div>
      {hasNext && (
        <button onClick={onNext} style={{
          padding: '8px 18px', borderRadius: 7,
          background: '#166534', border: 'none',
          color: '#fff', fontFamily: "'Inter', sans-serif",
          fontSize: 13, fontWeight: 600, cursor: 'pointer',
          flexShrink: 0, transition: 'background 0.15s',
        }}
          onMouseEnter={e => e.currentTarget.style.background = '#14532d'}
          onMouseLeave={e => e.currentTarget.style.background = '#166534'}
        >
          Next module →
        </button>
      )}
    </div>
  );
}

/* ─── Policy acknowledgement + complete gate ──────────────────────────────── */
function ModuleFooterGate({ mod, isComplete, ackedPolicies, onAck, onComplete, quizDone }) {
  const [openPolicy, setOpenPolicy] = useState(null);
  if (isComplete) return null;

  const hasPol     = mod.policyAck?.length > 0;
  const hasQuiz    = mod.quiz?.length > 0;
  const quizOk     = !hasQuiz || quizDone;
  const allAcked   = !hasPol || mod.policyAck.every(p => ackedPolicies?.includes(`${mod.id}-${p}`));
  const canComplete = allAcked && quizOk;
  const ackedCount = hasPol
    ? mod.policyAck.filter(p => ackedPolicies?.includes(`${mod.id}-${p}`)).length
    : 0;
  const keyFor = p => `${mod.id}-${p}`;

  return (
    <>
      {openPolicy && (
        <PolicyModal
          policyName={openPolicy}
          isAcked={ackedPolicies?.includes(keyFor(openPolicy))}
          onAck={() => onAck(keyFor(openPolicy))}
          onClose={() => setOpenPolicy(null)}
        />
      )}

      <div style={{
        marginTop: 28, background: '#fff',
        border: '1px solid #e2e4e9', borderRadius: 10, overflow: 'hidden',
        boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
      }}>
        <div style={{
          padding: '11px 22px', background: '#f8f9fa',
          borderBottom: '1px solid #e2e4e9',
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <ClipboardList size={13} color="#9ca3af"/>
          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', letterSpacing: '0.07em' }}>
            {hasPol ? 'POLICY ACKNOWLEDGEMENT & COMPLETION' : 'MODULE COMPLETION'}
          </span>
        </div>

        <div style={{ padding: '22px 22px 24px' }}>
          {hasQuiz && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '11px 14px', borderRadius: 8, marginBottom: hasPol ? 18 : 18,
              background: quizDone ? '#f0fdf4' : '#fffbeb',
              border: `1px solid ${quizDone ? '#86efac' : '#fcd34d'}`,
            }}>
              {quizDone
                ? <CheckCircle size={15} color="#16a34a" strokeWidth={2.5} style={{ flexShrink: 0 }}/>
                : <Lock size={14} color="#b45309" style={{ flexShrink: 0 }}/>}
              <span style={{
                fontFamily: "'Inter', sans-serif", fontSize: 13.5, lineHeight: 1.5,
                color: quizDone ? '#166534' : '#92400e',
              }}>
                {quizDone
                  ? 'Knowledge Check passed.'
                  : 'Pass the Knowledge Check above (at least 3 of 4 correct) before you can finish this module.'}
              </span>
            </div>
          )}
          {hasPol && (
            <div style={{ marginBottom: 22 }}>
              <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: '#3d4350', lineHeight: 1.7, marginBottom: 16 }}>
                Please read and acknowledge each of the following{' '}
                <strong style={{ color: '#0f1117' }}>Security Impossible policies</strong>{' '}
                before completing this module. Click <strong>Read policy</strong> to view the full legal text,
                then tick each checkbox to confirm you have read and understood it.
              </p>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 9, marginBottom: 14 }}>
                {mod.policyAck.map(pol => {
                  const key    = keyFor(pol);
                  const ticked = ackedPolicies?.includes(key);
                  return (
                    <div key={pol} style={{
                      display: 'flex', alignItems: 'stretch', borderRadius: 8,
                      border: `1px solid ${ticked ? '#86efac' : '#e2e4e9'}`,
                      background: ticked ? '#f0fdf4' : '#f8f9fa',
                      overflow: 'hidden', transition: 'border-color 0.15s, background 0.15s',
                    }}>
                      {/* Checkbox + label */}
                      <label style={{
                        display: 'flex', alignItems: 'center', gap: 12,
                        padding: '13px 14px 13px 16px',
                        cursor: 'pointer', userSelect: 'none', flex: 1,
                      }}>
                        <div style={{
                          width: 20, height: 20, borderRadius: 5, flexShrink: 0,
                          background: ticked ? '#16a34a' : '#fff',
                          border: `2px solid ${ticked ? '#16a34a' : '#d1d4db'}`,
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          transition: 'all 0.15s', position: 'relative',
                        }}>
                          <input type="checkbox" checked={!!ticked} onChange={() => onAck(key)}
                            style={{ position: 'absolute', inset: 0, opacity: 0, cursor: 'pointer', width: '100%', height: '100%', margin: 0 }}
                          />
                          {ticked && (
                            <svg width="11" height="11" viewBox="0 0 11 11" fill="none">
                              <polyline points="1.5,5.5 4.5,8.5 9.5,2.5" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                            </svg>
                          )}
                        </div>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, fontWeight: 500, color: ticked ? '#166534' : '#0f1117', lineHeight: 1.4, marginBottom: 3 }}>
                            I have read and understood the{' '}
                            <span style={{ color: ticked ? '#166534' : '#6d28d9', fontWeight: 600 }}>{pol}</span>
                          </div>
                          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12.5, color: '#6b7280' }}>
                            I agree to comply with the obligations set out in this policy.
                          </div>
                        </div>
                        {ticked && <Check size={15} color="#16a34a" strokeWidth={2.5} style={{ flexShrink: 0, marginRight: 4 }}/>}
                      </label>

                      {/* Read policy button */}
                      <button
                        onClick={() => setOpenPolicy(pol)}
                        title={`Read full ${pol}`}
                        style={{
                          padding: '0 18px', flexShrink: 0,
                          background: 'transparent', border: 'none',
                          borderLeft: `1px solid ${ticked ? '#a7f3d0' : '#e2e4e9'}`,
                          cursor: 'pointer',
                          display: 'flex', alignItems: 'center', gap: 6,
                          color: ticked ? '#16a34a' : '#6d28d9',
                          fontFamily: "'Inter', sans-serif", fontSize: 12.5, fontWeight: 600,
                          whiteSpace: 'nowrap', transition: 'background 0.12s',
                        }}
                        onMouseEnter={e => e.currentTarget.style.background = ticked ? '#dcfce7' : '#f3f0ff'}
                        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                      >
                        <ExternalLink size={13}/>
                        Read policy
                      </button>
                    </div>
                  );
                })}
              </div>

              {!allAcked && (
                <p style={{ fontFamily: "'DM Mono', monospace", fontSize: 11.5, color: '#9ca3af' }}>
                  {ackedCount} of {mod.policyAck.length} acknowledged
                </p>
              )}
              <div style={{ height: 1, background: '#f0f1f3', marginTop: 18 }}/>
            </div>
          )}

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, marginTop: hasPol ? 18 : 0 }}>
            <div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 15, color: canComplete ? '#0f1117' : '#9ca3af', marginBottom: 3 }}>
                {canComplete
                  ? `Mark Module ${mod.id} as Complete`
                  : !quizOk ? 'Pass the Knowledge Check to continue'
                  : hasPol ? 'Acknowledge all policies above to continue'
                  : `Mark Module ${mod.id} as Complete`}
              </div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: '#6b7280' }}>
                {canComplete ? 'Your progress will be saved and the next module unlocked.'
                  : !quizOk ? 'Score at least 3 of 4 in the Knowledge Check above, then return here.'
                  : hasPol ? 'Click Read policy to view each document, then tick every checkbox.'
                  : 'Work through the content above, then mark this module complete.'}
              </div>
            </div>
            <button
              disabled={!canComplete}
              onClick={canComplete ? onComplete : undefined}
              style={{
                flexShrink: 0, padding: '11px 26px', borderRadius: 8,
                fontFamily: "'Inter', sans-serif", fontSize: 14, fontWeight: 600,
                cursor: canComplete ? 'pointer' : 'not-allowed', transition: 'all 0.15s',
                display: 'flex', alignItems: 'center', gap: 8,
                ...(canComplete
                  ? { background: '#6d28d9', border: '1px solid #5b21b6', color: '#fff', boxShadow: '0 2px 8px rgba(109,40,217,0.35)' }
                  : { background: '#f4f5f7', border: '1px solid #e2e4e9', color: '#c4c9d4' }),
              }}
              onMouseEnter={e => { if (canComplete) e.currentTarget.style.background = '#5b21b6'; }}
              onMouseLeave={e => { if (canComplete) e.currentTarget.style.background = '#6d28d9'; }}
            >
              {canComplete ? <><CheckCircle size={15}/> Mark Complete</>
                : !quizOk ? <><Lock size={13}/> Pass quiz to continue</>
                : <><Lock size={13}/> Acknowledgements required</>}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}


/* ─── Completion certificate ──────────────────────────────────────────────── */
function AllComplete({ onBack }) {
  return (
    <div style={{ maxWidth: 620, margin: '0 auto', padding: '52px 24px' }}>
      <div style={{
        padding: '44px 48px', textAlign: 'center',
        background: '#fff', border: '1px solid #e2e4e9',
        borderRadius: 12, boxShadow: '0 4px 20px rgba(0,0,0,0.06)',
      }}>
        <div style={{
          width: 60, height: 60, borderRadius: 12, margin: '0 auto 24px',
          background: '#f0fdf4', border: '1px solid #86efac',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Check size={28} color="#16a34a" strokeWidth={2}/>
        </div>
        <h1 style={{
          fontFamily: "'Inter', sans-serif", fontWeight: 700, fontSize: 28,
          color: '#0f1117', letterSpacing: '-0.025em', marginBottom: 12,
        }}>Training Complete</h1>
        <p style={{
          fontFamily: "'Inter', sans-serif", fontSize: 15, color: '#6b7280',
          lineHeight: 1.7, maxWidth: 420, margin: '0 auto 28px',
        }}>
          You have completed all 11 modules of the Security Impossible Security &amp;
          Governance Onboarding Course. Your obligations begin now and survive employment.
        </p>
        <div style={{
          padding: '16px 20px', background: '#f8f9fa',
          border: '1px solid #e2e4e9', borderRadius: 8,
          textAlign: 'left', marginBottom: 20,
          fontFamily: "'DM Mono', monospace", fontSize: 12, lineHeight: 2.3,
        }}>
          {[
            ['PROGRAM', 'Security & Governance Onboarding v2'],
            ['MODULES', '11 / 11 Complete'],
            ['DATE',    new Date().toLocaleDateString('en-AU', { day: 'numeric', month: 'long', year: 'numeric' })],
            ['STATUS',  '✓ COMMITTED'],
          ].map(([k, v]) => (
            <div key={k} style={{ display: 'flex', gap: 20 }}>
              <span style={{ color: '#9ca3af', minWidth: 72 }}>{k}</span>
              <span style={{ color: k === 'STATUS' ? '#166534' : '#0f1117' }}>{v}</span>
            </div>
          ))}
        </div>
        <div style={{
          padding: '12px 16px', background: '#f0fdf4',
          border: '1px solid #86efac', borderRadius: 7,
          fontFamily: "'Inter', sans-serif", fontSize: 13,
          color: '#166534', lineHeight: 1.65, marginBottom: 24, textAlign: 'left',
        }}>
          <strong>Onboarding complete.</strong> Your acknowledgements and progress have
          been recorded against your sign-in details.
        </div>
        <button onClick={onBack} style={{
          fontFamily: "'Inter', sans-serif", fontSize: 13, color: '#6b7280',
          background: 'transparent', border: '1px solid #e2e4e9',
          borderRadius: 7, padding: '8px 18px', cursor: 'pointer',
          transition: 'all 0.15s',
        }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = '#6d28d9'; e.currentTarget.style.color = '#6d28d9'; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = '#e2e4e9'; e.currentTarget.style.color = '#6b7280'; }}
        >← Review modules</button>
      </div>
    </div>
  );
}

/* ─── Root App ────────────────────────────────────────────────────────────── */
export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentId,   setCurrentId]   = useState(1);
  const [state,       setState]       = useState(load);
  const [showAll,     setShowAll]     = useState(false);
  const [authUser,    setAuthUser]    = useState(null);  // per-visit sign-in; not persisted

  useEffect(() => { save(state); }, [state]);

  // Require sign-in on every visit before showing any content.
  if (!authUser) {
    return <LoginGate onAuthenticated={setAuthUser} />;
  }

  const mod           = ALL_MODULES.find(m => m.id === currentId);
  const completedSet  = new Set(Object.keys(state.completed || {}).map(Number).filter(id => state.completed[id]));
  const allDone       = completedSet.size === ALL_MODULES.length;
  const isComplete    = completedSet.has(currentId);
  const modState      = state.modules?.[currentId] || {};
  const ackedPolicies = state.ackedPolicies || [];
  const progress      = Math.round((completedSet.size / ALL_MODULES.length) * 100);
  const nextMod       = ALL_MODULES.find(m => m.id === currentId + 1);
  const prevMod       = ALL_MODULES.find(m => m.id === currentId - 1);

  function setModState(key, val) {
    setState(s => ({ ...s, modules: { ...(s.modules || {}), [currentId]: { ...(s.modules?.[currentId] || {}), [key]: val } } }));
  }
  function completeModule(id) {
    setState(s => ({ ...s, completed: { ...(s.completed || {}), [id]: true } }));
  }
  function ackPolicy(key) {
    setState(s => {
      const cur = s.ackedPolicies || [];
      return { ...s, ackedPolicies: cur.includes(key) ? cur.filter(k => k !== key) : [...cur, key] };
    });
  }
  function goTo(id) {
    setCurrentId(id);
    setShowAll(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  if (showAll) {
    return (
      <div style={{ minHeight: '100vh', background: '#f8f9fa' }}>
        <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} progress={progress} user={authUser}/>
        <div style={{ paddingTop: 56 }}><AllComplete onBack={() => setShowAll(false)}/></div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: '#f8f9fa', fontFamily: "'Inter', sans-serif" }}>
      <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} progress={progress} user={authUser}/>
      <Sidebar
        open={sidebarOpen}
        currentModuleId={currentId}
        completedModules={[...completedSet]}
        onNavigate={goTo}
      />

      <motion.main
        animate={{ paddingLeft: sidebarOpen ? 280 : 0 }}
        transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
        style={{ paddingTop: 56, minHeight: '100vh' }}
      >
        {/* Module tab strip */}
        <div style={{
          position: 'sticky', top: 56, zIndex: 100,
          background: '#fff',
          borderBottom: '1px solid #e2e4e9',
          padding: '0 22px',
          display: 'flex', alignItems: 'center',
          overflowX: 'auto',
          boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
        }}>
          {ALL_MODULES.map(m => {
            const isDone   = completedSet.has(m.id);
            const active   = m.id === currentId;
            const unlocked = m.id === 1 || isDone || completedSet.has(m.id - 1);
            return (
              <button key={m.id}
                onClick={() => unlocked && goTo(m.id)}
                title={m.title}
                style={{
                  padding: '0 3px', height: 42, flexShrink: 0,
                  marginRight: 10, border: 'none',
                  borderBottom: `2px solid ${active ? '#6d28d9' : 'transparent'}`,
                  background: 'transparent',
                  fontFamily: "'DM Mono', monospace", fontSize: 11, fontWeight: 500,
                  color: active ? '#6d28d9'
                    : isDone   ? '#9ca3af'
                    : unlocked ? '#6b7280' : '#d1d4db',
                  cursor: unlocked ? 'pointer' : 'default',
                  transition: 'color 0.12s',
                  display: 'flex', alignItems: 'center', gap: 4, paddingBottom: 2,
                }}
                onMouseEnter={e => { if (unlocked && !active) e.currentTarget.style.color = '#6d28d9'; }}
                onMouseLeave={e => {
                  if (!active) e.currentTarget.style.color = isDone ? '#9ca3af' : unlocked ? '#6b7280' : '#d1d4db';
                }}
              >
                {isDone && <Check size={9} color="#16a34a" strokeWidth={2.5}/>}
                {String(m.id).padStart(2, '0')}
              </button>
            );
          })}
          <div style={{ flex: 1 }}/>
          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', flexShrink: 0 }}>
            {completedSet.size}/{ALL_MODULES.length}
          </span>
        </div>

        {/* Page body */}
        <div style={{ maxWidth: 840, margin: '0 auto', padding: '26px 22px 64px' }}>
          <AnimatePresence mode="wait">
            <motion.div
              key={currentId}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.2 }}
            >
              <ModuleHero mod={mod} isComplete={isComplete}/>

              {isComplete && (
                <CompleteBanner
                  mod={mod} hasNext={!!nextMod}
                  onNext={() => nextMod && goTo(nextMod.id)}
                />
              )}

              <ModuleContent
                module={mod}
                scenarioDone={modState.scenarioDone || false}
                quizDone={modState.quizDone || false}
                onScenarioDone={() => setModState('scenarioDone', true)}
                onQuizDone={() => setModState('quizDone', true)}
              />

              <ModuleFooterGate
                mod={mod} isComplete={isComplete}
                ackedPolicies={ackedPolicies} onAck={ackPolicy}
                quizDone={modState.quizDone || false}
                onComplete={() => { completeModule(currentId); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              />

              {/* Prev / Next */}
              <div style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                marginTop: 24, paddingTop: 20, borderTop: '1px solid #e2e4e9',
              }}>
                <div>
                  {prevMod && (
                    <button onClick={() => goTo(prevMod.id)} style={{
                      display: 'flex', alignItems: 'center', gap: 7,
                      padding: '8px 16px', borderRadius: 7,
                      background: '#fff', border: '1px solid #e2e4e9',
                      color: '#6b7280', fontFamily: "'Inter', sans-serif", fontSize: 13,
                      cursor: 'pointer', transition: 'all 0.15s',
                    }}
                      onMouseEnter={e => { e.currentTarget.style.borderColor = '#6d28d9'; e.currentTarget.style.color = '#6d28d9'; }}
                      onMouseLeave={e => { e.currentTarget.style.borderColor = '#e2e4e9'; e.currentTarget.style.color = '#6b7280'; }}
                    >
                      <ArrowLeft size={14}/> Module {prevMod.id}
                    </button>
                  )}
                </div>

                <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#c4c9d4' }}>
                  {mod.id} / {ALL_MODULES.length}
                </span>

                <div style={{ display: 'flex', gap: 8 }}>
                  {nextMod && isComplete && (
                    <button onClick={() => goTo(nextMod.id)} style={{
                      display: 'flex', alignItems: 'center', gap: 7,
                      padding: '8px 16px', borderRadius: 7,
                      background: '#fff', border: '1px solid #e2e4e9',
                      color: '#6b7280', fontFamily: "'Inter', sans-serif", fontSize: 13,
                      cursor: 'pointer', transition: 'all 0.15s',
                    }}
                      onMouseEnter={e => { e.currentTarget.style.borderColor = '#6d28d9'; e.currentTarget.style.color = '#6d28d9'; }}
                      onMouseLeave={e => { e.currentTarget.style.borderColor = '#e2e4e9'; e.currentTarget.style.color = '#6b7280'; }}
                    >
                      Module {nextMod.id} <ArrowRight size={14}/>
                    </button>
                  )}
                  {allDone && !nextMod && (
                    <button onClick={() => setShowAll(true)} style={{
                      padding: '8px 18px', borderRadius: 7,
                      background: '#6d28d9', border: '1px solid #5b21b6',
                      color: '#fff', fontFamily: "'Inter', sans-serif",
                      fontSize: 13, fontWeight: 600, cursor: 'pointer',
                    }}>View certificate →</button>
                  )}
                </div>
              </div>

              {/* All done banner */}
              {allDone && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  style={{
                    marginTop: 18, padding: '16px 20px',
                    background: '#f0fdf4', border: '1px solid #86efac', borderRadius: 8,
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16,
                  }}
                >
                  <div>
                    <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 14, color: '#166534', marginBottom: 2 }}>
                      All 11 modules complete
                    </div>
                    <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: '#4ade80' }}>
                      Your onboarding is complete and has been recorded.
                    </div>
                  </div>
                  <button onClick={() => setShowAll(true)} style={{
                    padding: '8px 16px', borderRadius: 7, flexShrink: 0,
                    background: '#166534', border: 'none',
                    color: '#fff', fontFamily: "'Inter', sans-serif",
                    fontSize: 13, fontWeight: 600, cursor: 'pointer',
                  }}>View certificate →</button>
                </motion.div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </motion.main>

      <ByteAssistant currentSection={`module-${currentId}`}/>
    </div>
  );
}
