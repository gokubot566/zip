# File System Analysis lab — now on Security Impossible OS

This project is the **File System Analysis & Metadata Extraction** scenario
(originally shipped on "Sentinel OS") re-hosted on the newer, more capable
**Security Impossible OS** desktop platform. The scenario is unchanged — only
the operating system around it changed.

## What changed vs. the original File System Analysis zip

- **Operating system → Security Impossible OS.** The whole desktop shell now
  comes from the advanced OS: boot + sign-in, window manager, taskbar, Start
  menu, notifications, Settings (wallpaper/accent/theme), Recycle Bin and the
  generic apps. This replaces the older self-contained Sentinel-OS shell.
- **Scenario → identical.** The investigation content is the original, byte for
  byte: the virtual file system, the suspect `crack.exe` forensic profile, the
  seven guided task gates, the mentor cast, Byte's script, the glossary and the
  triage report. It lives in `src/labs/file-system-analysis/`.
- **Docker → the File System Analysis zip's Docker**, as requested: multi-stage
  Node build → nginx serving on **port 8346** with a `/health` endpoint.

## How it fits together

Security Impossible OS is a generic platform that loads scenarios as **lab
packages**. The File System Analysis scenario is packaged under
`src/labs/file-system-analysis/`:

```
file-system-analysis/
  scenario.js        # the original lab content (unchanged)
  apps.jsx           # the six analysis apps (unchanged)
  Byte.jsx           # the floating guide (unchanged)
  Cast.jsx, ByteAvatar.jsx, ui.jsx, assets/   # unchanged
  bridge.jsx         # adapts the apps to the OS (labState-backed progress)
  AppWrappers.jsx    # hosts each app in an OS window
  Overlay.jsx        # renders Byte above the desktop
  theme.css          # the lab's palette, scoped to .fsa-scope
  index.js           # the lab package (apps, persona, desktop shortcuts)
```

The apps and Byte were written against a small state contract
(`{ lab, patchLab, isTaskDone, ... }`). `bridge.jsx` reproduces that contract on
top of the OS's own persisted `labState`, so the scenario logic is untouched
while progress now saves through the platform. Two tiny platform touch-points:
`src/labs/index.js` registers the lab, and `src/App.jsx` renders the lab's
floating `Overlay` (Byte) once the user signs in.

The six lab apps register under the ids the scenario expects
(`files, terminal, security, intel, pe, report`); `terminal` and `security`
intentionally override the platform defaults so the scenario's scripted Terminal
and OmniGuard are used.

## Run it

Local dev:

```bash
npm install
npm run dev        # http://localhost:8346
```

Production / container (the File System Analysis Docker):

```bash
docker compose up -d --build     # then open http://localhost:8346
docker compose down
```

Tests (platform engine + server-render of every app):

```bash
npm test
```

## Note on naming

The scenario text now refers to the platform as "Security Impossible OS"
throughout (Byte's intro, the Terminal banner, the lab meta and the
disclaimer). The forensic evidence is deliberately left untouched — in
particular the command-and-control domain `sentinel-c2-node[.]duckdns[.]org`
and the extracted PE strings are part of the investigation, not branding.

## Windows filesystem + typography (latest revision)

- **File layout is now Windows**, matching the OS platform. The Files app and
  Terminal browse a `C:\` tree (`C:\Users\analyst`, `C:\Windows`,
  `C:\Program Files`, `C:\ProgramData`) instead of the old Linux tree. The
  suspect file sits at its canonical location, `C:\Windows\Temp\crack.exe`.
- **Terminal is Windows-style.** Prompt `PS C:\Windows\Temp>`, with `dir`, `cd`,
  `type`, `certutil -hashfile <file> SHA256` and `Get-FileHash` (the Unix
  aliases `ls`, `cat`, `sha256sum` still work). Hashing the restored sample with
  SHA-256 still unlocks the fingerprint and the Threat Lookup step, exactly as
  before.
- **Fonts fixed.** The lab's Inter + JetBrains Mono are now loaded in
  `index.html` (they were referenced but never linked after the OS swap), so
  Byte and the terminal render in the intended typefaces throughout.
