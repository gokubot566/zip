import {
  FolderOpen, FileText, Mail, Globe, Activity, ScrollText, ShieldCheck,
  SquareTerminal, Settings, Cpu, Image, Calculator, HelpCircle,
} from 'lucide-react';

import FileExplorer from './FileExplorer.jsx';
import TextEditor from './TextEditor.jsx';
import MailApp from './Mail.jsx';
import Browser from './Browser.jsx';
import TaskManager from './TaskManager.jsx';
import EventViewer from './EventViewer.jsx';
import SecurityCenter from './SecurityCenter.jsx';
import TerminalApp from './Terminal.jsx';
import SettingsApp from './SettingsApp.jsx';
import SystemInfo from './SystemInfo.jsx';
import ImageViewer from './ImageViewer.jsx';
import CalculatorApp from './Calculator.jsx';
import Help from './Help.jsx';
import { getActiveLab } from '../labs/index.js';

// ===========================================================================
// APPLICATION REGISTRY
//
// PLATFORM_APPS are the generic, lab-agnostic apps shipped with the OS. A lab
// package may contribute its own apps (e.g. an Incident Report); those are
// merged in here. Adding a platform app = build the component + one entry.
//
// App descriptor: { id, name, icon, color, category, singleton?, modal?,
//                    defaultSize, startMaximized?, component, hidden? }
// ===========================================================================

const PLATFORM_APPS = [
  { id: 'explorer', name: 'File Explorer', icon: FolderOpen, color: '#ffcf6b', category: 'System', defaultSize: { w: 880, h: 580 }, component: FileExplorer },
  { id: 'mail', name: 'Mail', icon: Mail, color: '#4c8dff', category: 'Productivity', singleton: true, defaultSize: { w: 900, h: 600 }, component: MailApp },
  { id: 'browser', name: 'SI Browser', icon: Globe, color: '#3ea6ff', category: 'Productivity', defaultSize: { w: 900, h: 620 }, component: Browser },
  { id: 'taskmgr', name: 'Task Manager', icon: Activity, color: '#5ed3a0', category: 'Tools', singleton: true, defaultSize: { w: 760, h: 560 }, component: TaskManager },
  { id: 'eventvwr', name: 'Event Viewer', icon: ScrollText, color: '#c489f0', category: 'Tools', singleton: true, defaultSize: { w: 920, h: 600 }, component: EventViewer },
  { id: 'security', name: 'Security Center', icon: ShieldCheck, color: '#5ed3a0', category: 'Tools', singleton: true, defaultSize: { w: 820, h: 600 }, component: SecurityCenter },
  { id: 'terminal', name: 'Terminal', icon: SquareTerminal, color: '#9aa4b5', category: 'Tools', defaultSize: { w: 720, h: 460 }, component: TerminalApp },
  { id: 'texteditor', name: 'Text Editor', icon: FileText, color: '#b6c0d0', category: 'Productivity', defaultSize: { w: 640, h: 520 }, component: TextEditor },
  { id: 'sysinfo', name: 'System Information', icon: Cpu, color: '#7fb7ff', category: 'Tools', singleton: true, defaultSize: { w: 780, h: 560 }, component: SystemInfo },
  { id: 'imageviewer', name: 'Image Viewer', icon: Image, color: '#c489f0', category: 'Productivity', defaultSize: { w: 720, h: 560 }, component: ImageViewer },
  { id: 'settings', name: 'Settings', icon: Settings, color: '#9aa4b5', category: 'System', singleton: true, defaultSize: { w: 820, h: 580 }, component: SettingsApp },
  { id: 'calculator', name: 'Calculator', icon: Calculator, color: '#5ed3a0', category: 'Productivity', singleton: true, defaultSize: { w: 340, h: 520 }, component: CalculatorApp },
  { id: 'help', name: 'Help', icon: HelpCircle, color: '#3ea6ff', category: 'System', singleton: true, defaultSize: { w: 720, h: 560 }, component: Help },
];

// Merge lab-contributed apps (a lab app id may override a platform default).
function buildApps() {
  const labApps = getActiveLab()?.apps ?? [];
  const byId = new Map(PLATFORM_APPS.map((a) => [a.id, a]));
  for (const app of labApps) byId.set(app.id, app);
  return [...byId.values()];
}

export const APPS = buildApps();

const BY_ID = Object.fromEntries(APPS.map((a) => [a.id, a]));

export function getApp(id) {
  return BY_ID[id] ?? null;
}
export function getAppComponent(id) {
  return BY_ID[id]?.component ?? null;
}
