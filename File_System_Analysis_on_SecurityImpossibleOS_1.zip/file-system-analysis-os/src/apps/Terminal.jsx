import React, { useState, useRef, useEffect } from 'react';
import { useOS } from '../core/OSContext.jsx';
import { getNode, listDir, normalizePath, parentPath, toWinPath } from '../core/fs.js';
import { formatBytes, formatDateShort, formatTime } from '../core/utils.js';
import { BRANDING } from '../config/branding.jsx';

const PROMPT_COLOR = '#8de08d';
const OS_LABEL = `${BRANDING.product} [Version ${BRANDING.version}.${BRANDING.build}]`;

export default function Terminal() {
  const { state, recordActivity, recordOpenFile } = useOS();
  const profile = state.profile;
  const network = state.data.network ?? {};
  const processes = state.data.processes ?? [];
  const HOME = `C:/Users/${profile.username}`;
  const [cwd, setCwd] = useState(HOME);
  const [lines, setLines] = useState(() => [
    { t: OS_LABEL },
    { t: `(c) ${BRANDING.company}. Simulated shell for training — type "help".` },
    { t: '' },
  ]);
  const [input, setInput] = useState('');
  const [hist, setHist] = useState([]);
  const [histIdx, setHistIdx] = useState(-1);
  const bodyRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => { bodyRef.current?.scrollTo(0, bodyRef.current.scrollHeight); }, [lines]);

  const print = (out) => setLines((l) => [...l, ...out]);
  const winCwd = () => toWinPath(cwd);

  const run = (raw) => {
    const cmd = raw.trim();
    if (cmd) { setHist((h) => [...h, cmd]); }
    setHistIdx(-1);

    const [name, ...rest] = cmd.split(/\s+/);
    const lname = name.toLowerCase();
    if (lname === 'cls' || lname === 'clear') { setLines([]); return; }

    print([{ t: `${winCwd()}> ${raw}`, prompt: true }]);
    if (!cmd) return;
    const arg = rest.join(' ');
    const out = execute(lname, rest, arg, { state, cwd, setCwd, recordActivity, recordOpenFile, profile, network, processes });
    if (out) print(out);
    print([{ t: '' }]);
  };

  const onKey = (e) => {
    if (e.key === 'Enter') { run(input); setInput(''); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); const i = histIdx < 0 ? hist.length - 1 : Math.max(0, histIdx - 1); if (hist[i] != null) { setHistIdx(i); setInput(hist[i]); } }
    else if (e.key === 'ArrowDown') { e.preventDefault(); if (histIdx >= 0) { const i = histIdx + 1; if (i >= hist.length) { setHistIdx(-1); setInput(''); } else { setHistIdx(i); setInput(hist[i]); } } }
    else if (e.key === 'l' && e.ctrlKey) { e.preventDefault(); setLines([]); }
  };

  return (
    <div
      onMouseDown={() => inputRef.current?.focus()}
      style={{ flex: 1, minHeight: 0, background: '#0c0f17', color: '#d6dbe6', fontFamily: 'var(--mono)', fontSize: 12.5, display: 'flex', flexDirection: 'column' }}
    >
      <div ref={bodyRef} className="scrolly selectable" style={{ flex: 1, padding: 12, whiteSpace: 'pre-wrap', wordBreak: 'break-word', lineHeight: 1.45 }}>
        {lines.map((l, i) => (
          <div key={i} style={{ color: l.prompt ? PROMPT_COLOR : l.color || '#d6dbe6' }}>{l.t}</div>
        ))}
        <div style={{ display: 'flex' }}>
          <span style={{ color: PROMPT_COLOR, whiteSpace: 'nowrap' }}>{winCwd()}&gt;&nbsp;</span>
          <input
            ref={inputRef}
            autoFocus
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={onKey}
            spellCheck={false}
            style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', color: '#fff', fontFamily: 'inherit', fontSize: 'inherit' }}
          />
        </div>
      </div>
    </div>
  );
}

const HELP = `Available commands:
  help            show this help
  cls / clear     clear the screen
  dir [path]      list directory contents
  cd <path>       change directory
  type <file>     print a file's contents
  tree            show directory tree (current folder)
  whoami          current user
  hostname        computer name
  systeminfo      OS / hardware summary
  ipconfig        network adapter configuration
  netstat -ano    active network connections (with PID)
  tasklist        running processes
  ver             OS version
  echo <text>     print text
  date / time     current date / time`;

function resolvePath(cwd, p) {
  if (!p) return cwd;
  let np = p.replace(/"/g, '');
  if (/^[a-z]:/i.test(np)) return normalizePath(np);
  if (np === '..') return parentPath(cwd) || 'C:';
  if (np === '.') return cwd;
  if (np === '\\' || np === '/') return 'C:';
  return normalizePath(`${cwd}/${np}`);
}

function execute(name, rest, arg, ctx) {
  const { state, cwd, setCwd, recordActivity, recordOpenFile, profile, network, processes } = ctx;
  switch (name) {
    case 'help': case '?': return HELP.split('\n').map((t) => ({ t }));
    case 'echo': return [{ t: arg }];
    case 'ver': return [{ t: OS_LABEL }];
    case 'whoami': return [{ t: `${profile.domain}\\${profile.username.toLowerCase()}` }];
    case 'hostname': return [{ t: profile.hostname }];
    case 'date': return [{ t: `The current date is: ${formatDateShort(Date.now())}` }];
    case 'time': return [{ t: `The current time is: ${formatTime(Date.now())}` }];
    case 'cd': case 'chdir': {
      if (!arg) return [{ t: toWinPath(cwd) }];
      const target = resolvePath(cwd, arg);
      const node = getNode(state.fs, target);
      if (node && node.type === 'dir') { setCwd(target); return null; }
      return [{ t: 'The system cannot find the path specified.', color: '#ff8a8a' }];
    }
    case 'dir': {
      const target = resolvePath(cwd, arg);
      const node = getNode(state.fs, target);
      if (!node || node.type !== 'dir') return [{ t: 'File Not Found', color: '#ff8a8a' }];
      const items = listDir(state.fs, target, { showHidden: true });
      const out = [{ t: ` Directory of ${toWinPath(target)}`, color: '#9fb2d6' }, { t: '' }];
      let files = 0, dirs = 0, bytes = 0;
      items.forEach((it) => {
        const stamp = `${formatDateShort(it.modified)}  ${formatTime(it.modified).padStart(8)}`;
        if (it.type === 'dir') { dirs++; out.push({ t: `${stamp}    <DIR>          ${it.name}` }); }
        else { files++; bytes += it.size || 0; out.push({ t: `${stamp}    ${String(it.size || 0).padStart(14)} ${it.name}`, color: it.suspicious ? '#ff8a8a' : undefined }); }
      });
      out.push({ t: `${String(files).padStart(15)} File(s) ${formatBytes(bytes).padStart(14)}` });
      out.push({ t: `${String(dirs).padStart(15)} Dir(s)` });
      return out;
    }
    case 'type': {
      if (!arg) return [{ t: 'The syntax of the command is incorrect.', color: '#ff8a8a' }];
      const target = resolvePath(cwd, arg);
      const node = getNode(state.fs, target);
      if (!node) return [{ t: 'The system cannot find the file specified.', color: '#ff8a8a' }];
      if (node.type === 'dir') return [{ t: 'Access is denied.', color: '#ff8a8a' }];
      recordOpenFile(target);
      return String(node.content).split('\n').map((t) => ({ t, color: node.suspicious ? '#ffd28a' : undefined }));
    }
    case 'tree': {
      const node = getNode(state.fs, cwd);
      if (!node) return [{ t: 'Invalid path' }];
      const out = [{ t: toWinPath(cwd), color: '#9fb2d6' }];
      const rec = (dir, prefix) => {
        const items = listDir(state.fs, dir, { showHidden: true });
        items.forEach((it, i) => {
          const last = i === items.length - 1;
          out.push({ t: `${prefix}${last ? '└──' : '├──'} ${it.name}`, color: it.suspicious ? '#ff8a8a' : undefined });
          if (it.type === 'dir') rec(it.path, `${prefix}${last ? '    ' : '│   '}`);
        });
      };
      rec(cwd, '');
      return out;
    }
    case 'ipconfig': {
      if (!network.ipv4) return [{ t: 'No network adapters configured.', color: '#ffd28a' }];
      return [
        { t: `${BRANDING.productShort} IP Configuration`, color: '#9fb2d6' }, { t: '' },
        { t: 'Ethernet adapter Ethernet:' }, { t: '' },
        { t: `   Connection-specific DNS Suffix  . : ${network.domain ?? ''}` },
        { t: `   IPv4 Address. . . . . . . . . . . : ${network.ipv4}` },
        { t: `   Subnet Mask . . . . . . . . . . . : ${network.subnet ?? ''}` },
        { t: `   Default Gateway . . . . . . . . . : ${network.gateway ?? ''}` },
        { t: `   DNS Servers . . . . . . . . . . . : ${(network.dns ?? []).join(', ')}` },
        { t: `   Physical Address. . . . . . . . . : ${network.mac ?? ''}` },
      ];
    }
    case 'netstat': {
      recordActivity('netstat');
      const conns = network.connections ?? [];
      if (conns.length === 0) return [{ t: 'No active connections.', color: '#ffd28a' }];
      const out = [{ t: '' }, { t: 'Active Connections', color: '#9fb2d6' }, { t: '' }, { t: '  Proto  Local Address          Foreign Address        State           PID' }];
      conns.forEach((c) => {
        out.push({ t: `  ${c.proto.padEnd(5)}  ${c.local.padEnd(21)}  ${c.remote.padEnd(21)}  ${(c.state || '').padEnd(14)}  ${c.pid}`, color: c.suspicious ? '#ff8a8a' : undefined });
      });
      const flagged = conns.find((c) => c.suspicious);
      if (flagged) { out.push({ t: '' }); out.push({ t: `Note: PID ${flagged.pid} (${flagged.remote}) is an unrecognised external host.`, color: '#ffd28a' }); }
      return out;
    }
    case 'tasklist': {
      const out = [{ t: 'Image Name                     PID    Mem Usage' }, { t: '========================= ======== ============' }];
      processes.filter((p) => !state.activity.killedProcesses.includes(p.pid)).forEach((p) => {
        out.push({ t: `${p.name.padEnd(25)} ${String(p.pid).padStart(6)}   ${formatBytes(p.mem * 1024).padStart(9)}`, color: p.suspicious ? '#ff8a8a' : undefined });
      });
      return out;
    }
    case 'systeminfo': {
      return [
        { t: `Host Name:                 ${profile.hostname}` },
        { t: `OS Name:                   ${BRANDING.product}` },
        { t: `OS Version:                ${BRANDING.version}.${BRANDING.build}` },
        { t: `Registered Owner:          ${profile.name}` },
        { t: `Domain:                    ${network.domain ?? profile.domain}` },
        { t: `System Manufacturer:       ${BRANDING.company} (virtual)` },
        { t: `Processor:                 Intel64 Family 6 — 8 logical` },
        { t: `Total Physical Memory:     16,384 MB` },
        { t: `Network Card(s):           ${network.adapter ?? 'n/a'}${network.ipv4 ? ` (${network.ipv4})` : ''}` },
      ];
    }
    case 'ping': {
      const host = rest[0] || '';
      if (!host) return [{ t: 'Usage: ping <host>' }];
      return [{ t: `Pinging ${host} with 32 bytes of data:` }, { t: 'Request timed out.', color: '#ffd28a' }, { t: 'Request timed out.', color: '#ffd28a' }, { t: `Ping statistics for ${host}: Sent = 4, Received = 0, Lost = 4 (100% loss)` }];
    }
    case 'exit': return [{ t: '(use the window close button to exit)' }];
    default: return [{ t: `'${name}' is not recognized as an internal or external command.`, color: '#ff8a8a' }, { t: 'Type "help" for a list of commands.' }];
  }
}
