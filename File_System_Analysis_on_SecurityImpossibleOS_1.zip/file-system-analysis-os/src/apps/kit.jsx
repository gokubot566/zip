import React from 'react';

// Shared building blocks for app windows. Keeps every app visually consistent
// and the app files short.

export function Tabs({ tabs, active, onChange, right }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 2, padding: '6px 8px', borderBottom: '1px solid var(--border)', background: 'var(--surface-1)', flexShrink: 0 }}>
      {tabs.map((t) => {
        const on = t.id === active;
        return (
          <button
            key={t.id}
            onClick={() => onChange(t.id)}
            style={{
              display: 'flex', alignItems: 'center', gap: 7, padding: '7px 12px', fontSize: 12.5,
              border: 'none', borderRadius: 'var(--radius-sm)', background: on ? 'var(--active)' : 'transparent',
              color: on ? 'var(--text-primary)' : 'var(--text-secondary)', fontWeight: on ? 600 : 500,
            }}
            onMouseEnter={(e) => { if (!on) e.currentTarget.style.background = 'var(--hover)'; }}
            onMouseLeave={(e) => { if (!on) e.currentTarget.style.background = 'transparent'; }}
          >
            {t.icon}
            {t.label}
            {t.badge != null && (
              <span style={{ minWidth: 16, height: 16, padding: '0 4px', borderRadius: 999, fontSize: 10, fontWeight: 700, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: t.badgeColor || 'var(--danger)', color: '#fff' }}>
                {t.badge}
              </span>
            )}
          </button>
        );
      })}
      {right && <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>{right}</div>}
    </div>
  );
}

export function Toolbar({ children, style }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', borderBottom: '1px solid var(--border)', background: 'var(--surface-1)', flexShrink: 0, ...style }}>
      {children}
    </div>
  );
}

export function Empty({ icon, title, sub }) {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: 'var(--text-tertiary)', gap: 10, padding: 40, textAlign: 'center' }}>
      {icon}
      <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-secondary)' }}>{title}</div>
      {sub && <div style={{ fontSize: 12.5, maxWidth: 360, lineHeight: 1.5 }}>{sub}</div>}
    </div>
  );
}

export function Field({ label, children, hint }) {
  return (
    <label style={{ display: 'block', marginBottom: 14 }}>
      <div style={{ fontSize: 12.5, fontWeight: 600, marginBottom: 6, color: 'var(--text-secondary)' }}>{label}</div>
      {children}
      {hint && <div style={{ fontSize: 11.5, color: 'var(--text-tertiary)', marginTop: 4 }}>{hint}</div>}
    </label>
  );
}

export function Banner({ variant = 'info', children, icon }) {
  const color = variant === 'error' ? 'danger' : variant === 'warning' ? 'warning' : variant === 'success' ? 'success' : 'info';
  return (
    <div style={{
      display: 'flex', gap: 10, alignItems: 'flex-start', padding: '10px 12px', margin: '0 0 12px',
      background: `var(--${color}-bg)`, border: `1px solid var(--${color})`, borderRadius: 'var(--radius-sm)',
      fontSize: 12.5, color: 'var(--text-primary)', lineHeight: 1.5,
    }}>
      {icon && <span style={{ flexShrink: 0, marginTop: 1 }}>{icon}</span>}
      <div>{children}</div>
    </div>
  );
}

export function severityClass(sev) {
  return `badge sev-${(sev || '').toLowerCase()}`;
}
