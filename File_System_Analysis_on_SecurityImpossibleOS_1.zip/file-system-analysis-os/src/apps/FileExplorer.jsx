import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft, ArrowRight, ArrowUp, Search, FolderPlus, Trash2, RotateCcw,
  Eye, EyeOff, LayoutGrid, List, Monitor, Home, Download, FileText, Image as ImageIcon, HardDrive, Folder,
} from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import {
  getNode, listDir, parentPath, baseName, normalizePath, searchFs, dirSize, countItems,
} from '../core/fs.js';
import { formatBytes, formatDateTime } from '../core/utils.js';
import { fileIconFor, openPathFor } from './fileIcons.jsx';
import { openContextMenu, openDialog, confirmDialog } from '../shell/ui.js';
import { Toolbar, Empty } from './kit.jsx';

const BIN = '$recycle-bin';

export default function FileExplorer({ win, args }) {
  const os = useOS();
  const { state, setWindowTitle, deletePath, mkdir, renamePath, recordOpenFile, restoreFromBin, removeFromBin, emptyBin, movePath } = os;
  const HOME = `C:/Users/${state.profile.username}`;
  const QUICK = [
    { label: 'Desktop', path: `${HOME}/Desktop`, icon: Monitor },
    { label: 'Downloads', path: `${HOME}/Downloads`, icon: Download },
    { label: 'Documents', path: `${HOME}/Documents`, icon: FileText },
    { label: 'Pictures', path: `${HOME}/Pictures`, icon: ImageIcon },
  ];
  const [path, setPath] = useState(args?.path ?? `${HOME}/Desktop`);
  const [history, setHistory] = useState([args?.path ?? `${HOME}/Desktop`]);
  const [hIndex, setHIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [query, setQuery] = useState('');
  const [view, setView] = useState('details');

  const showHidden = state.settings.showHidden;
  const inBin = path === BIN;
  const isThisPc = path === 'C:' || path === 'This PC';

  const navigate = (p) => {
    const np = p === BIN || p === 'This PC' ? p : normalizePath(p);
    setPath(np);
    setQuery('');
    setSelected(null);
    const trimmed = history.slice(0, hIndex + 1);
    setHistory([...trimmed, np]);
    setHIndex(trimmed.length);
  };
  const back = () => { if (hIndex > 0) { setHIndex(hIndex - 1); setPath(history[hIndex - 1]); setSelected(null); } };
  const forward = () => { if (hIndex < history.length - 1) { setHIndex(hIndex + 1); setPath(history[hIndex + 1]); setSelected(null); } };
  const up = () => { if (!inBin && !isThisPc) { const pp = parentPath(path); navigate(pp && pp.length >= 2 ? pp : 'This PC'); } };

  useEffect(() => {
    const title = inBin ? 'Recycle Bin' : isThisPc ? 'This PC' : baseName(path) || path;
    setWindowTitle(win.id, `${title} — File Explorer`);
  }, [win.id, path]);

  // items to show
  const items = useMemo(() => {
    if (inBin) return state.recycleBin.map((e) => ({ ...e.node, path: e.originalPath, binId: e.id, deletedAt: e.deletedAt, originalPath: e.originalPath }));
    if (isThisPc) return [];
    if (query.trim()) {
      return searchFs(state.fs, query, { rootPath: path, showHidden, limit: 150 }).map((r) => ({ ...r.node, path: r.path }));
    }
    return listDir(state.fs, path, { showHidden });
  }, [state.fs, state.recycleBin, path, query, showHidden, inBin, isThisPc]);

  const node = getNode(state.fs, path);
  const invalid = !inBin && !isThisPc && (!node || node.type !== 'dir');

  const openItem = (item) => {
    if (inBin) return;
    if (item.type === 'dir') navigate(item.path);
    else { recordOpenFile(item.path); openPathFor(item, os.openApp); }
  };

  const doDelete = async (item) => {
    if (await confirmDialog(`Move "${item.name}" to the Recycle Bin?`, { confirmLabel: 'Delete', danger: true })) deletePath(item.path);
  };
  const doRename = async (item) => {
    const name = await promptText('Rename', 'New name:', item.name);
    if (name && name !== item.name) renamePath(item.path, name);
  };
  const newFolder = async () => {
    const name = await promptText('New folder', 'Folder name:', 'New folder');
    if (name) mkdir(`${path}/${name}`);
  };
  const properties = (item) => showProperties(item, state.fs);

  const itemContext = (e, item) => {
    setSelected(item.path);
    if (inBin) {
      openContextMenu(e, [
        { label: 'Restore', icon: <RotateCcw size={15} />, onClick: () => restoreFromBin(item.binId) },
        { label: 'Delete permanently', icon: <Trash2 size={15} />, danger: true, onClick: () => removeFromBin(item.binId) },
        { separator: true },
        { label: 'Properties', onClick: () => properties(item) },
      ]);
      return;
    }
    openContextMenu(e, [
      { label: 'Open', onClick: () => openItem(item) },
      ...(item.type === 'file' ? [{ label: 'Open in Notepad', icon: <FileText size={15} />, onClick: () => os.openApp('notepad', { path: item.path }) }] : []),
      { separator: true },
      { label: 'Rename', onClick: () => doRename(item) },
      { label: 'Delete', icon: <Trash2 size={15} />, danger: true, onClick: () => doDelete(item) },
      { separator: true },
      { label: 'Properties', onClick: () => properties(item) },
    ]);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0 }}>
      {/* toolbar */}
      <Toolbar>
        <IconBtn onClick={back} disabled={hIndex === 0} title="Back"><ArrowLeft size={17} /></IconBtn>
        <IconBtn onClick={forward} disabled={hIndex >= history.length - 1} title="Forward"><ArrowRight size={17} /></IconBtn>
        <IconBtn onClick={up} disabled={inBin || isThisPc} title="Up"><ArrowUp size={17} /></IconBtn>
        <Breadcrumb path={path} inBin={inBin} isThisPc={isThisPc} onNavigate={navigate} />
        <div style={{ position: 'relative', width: 180 }}>
          <Search size={14} style={{ position: 'absolute', left: 9, top: 9, color: 'var(--text-tertiary)' }} />
          <input className="os-input" style={{ paddingLeft: 30, height: 32, fontSize: 12 }} placeholder="Search" value={query} onChange={(e) => setQuery(e.target.value)} disabled={inBin || isThisPc} />
        </div>
      </Toolbar>
      {/* secondary toolbar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '5px 10px', borderBottom: '1px solid var(--border)', background: 'var(--surface-0)' }}>
        {inBin ? (
          <button className="os-btn ghost" style={btnSm} onClick={() => emptyBin()} disabled={state.recycleBin.length === 0}>
            <Trash2 size={14} /> Empty Recycle Bin
          </button>
        ) : (
          <button className="os-btn ghost" style={btnSm} onClick={newFolder} disabled={isThisPc}>
            <FolderPlus size={14} /> New folder
          </button>
        )}
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
          <button className="os-btn ghost" style={btnSm} onClick={() => os.setSetting('showHidden', !showHidden)} title="Hidden items">
            {showHidden ? <Eye size={14} /> : <EyeOff size={14} />} {showHidden ? 'Hidden: on' : 'Hidden: off'}
          </button>
          <IconBtn onClick={() => setView(view === 'details' ? 'grid' : 'details')} title="Toggle view">
            {view === 'details' ? <LayoutGrid size={16} /> : <List size={16} />}
          </IconBtn>
        </div>
      </div>

      <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
        {/* sidebar */}
        <div className="scrolly" style={{ width: 190, flexShrink: 0, borderRight: '1px solid var(--border)', background: 'var(--surface-0)', padding: 8, fontSize: 12.5 }}>
          <SideItem icon={<Home size={15} />} label="Quick access" bold onClick={() => navigate(`${HOME}/Desktop`)} />
          {QUICK.map((q) => (
            <SideItem key={q.path} indent icon={<q.icon size={15} color="var(--accent)" />} label={q.label} active={path === q.path} onClick={() => navigate(q.path)} />
          ))}
          <div style={{ height: 8 }} />
          <SideItem icon={<Monitor size={15} />} label="This PC" bold active={isThisPc} onClick={() => navigate('This PC')} />
          <SideItem indent icon={<HardDrive size={15} color="var(--text-secondary)" />} label="Local Disk (C:)" active={path === 'C:'} onClick={() => navigate('C:')} />
          <div style={{ height: 8 }} />
          <SideItem icon={<Trash2 size={15} color={state.recycleBin.length ? 'var(--warning)' : 'var(--text-secondary)'} />} label={`Recycle Bin${state.recycleBin.length ? ` (${state.recycleBin.length})` : ''}`} active={inBin} onClick={() => navigate(BIN)} />
        </div>

        {/* main */}
        <div className="scrolly" style={{ flex: 1, minWidth: 0 }} onMouseDown={() => setSelected(null)}
          onContextMenu={(e) => { if (!inBin && !isThisPc) { e.preventDefault(); openContextMenu(e, [{ label: 'New folder', icon: <FolderPlus size={15} />, onClick: newFolder }, { label: 'Refresh', onClick: () => {} }]); } }}>
          {isThisPc ? (
            <ThisPc fs={state.fs} onOpen={navigate} />
          ) : invalid ? (
            <Empty icon={<Folder size={40} />} title="This location is empty or unavailable" />
          ) : items.length === 0 ? (
            <Empty icon={inBin ? <Trash2 size={40} /> : <Folder size={40} />} title={inBin ? 'Recycle Bin is empty' : query ? 'No results' : 'This folder is empty'} />
          ) : view === 'details' ? (
            <DetailsView items={items} inBin={inBin} selected={selected} onSelect={setSelected} onOpen={openItem} onContext={itemContext} onRestore={restoreFromBin} />
          ) : (
            <GridView items={items} selected={selected} onSelect={setSelected} onOpen={openItem} onContext={itemContext} inBin={inBin} />
          )}
        </div>
      </div>

      {/* status bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 12px', borderTop: '1px solid var(--border)', background: 'var(--surface-1)', fontSize: 11, color: 'var(--text-tertiary)' }}>
        <span>{isThisPc ? '1 drive' : `${items.length} item${items.length === 1 ? '' : 's'}`}{selected ? ' · 1 selected' : ''}</span>
        {node && !inBin && !isThisPc && <span>{formatBytes(dirSize(node))}</span>}
      </div>
    </div>
  );
}

/* ---- subcomponents ------------------------------------------------------- */

const btnSm = { fontSize: 12, padding: '5px 9px' };

function IconBtn({ children, onClick, disabled, title }) {
  return (
    <button onClick={onClick} disabled={disabled} title={title} className="os-btn ghost"
      style={{ padding: 6, opacity: disabled ? 0.4 : 1 }}>
      {children}
    </button>
  );
}

function SideItem({ icon, label, onClick, active, bold, indent }) {
  return (
    <button onClick={onClick} className={`list-row ${active ? 'selected' : ''}`}
      style={{ width: '100%', border: 'none', padding: '6px 8px', paddingLeft: indent ? 24 : 8, fontWeight: bold ? 600 : 400 }}>
      {icon}<span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{label}</span>
    </button>
  );
}

function Breadcrumb({ path, inBin, isThisPc, onNavigate }) {
  const parts = inBin ? ['Recycle Bin'] : isThisPc ? ['This PC'] : path.split('/').filter(Boolean);
  let acc = '';
  return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 2, height: 32, padding: '0 10px', background: 'var(--surface-solid)', border: '1px solid var(--border-strong)', borderRadius: 'var(--radius-sm)', overflow: 'hidden', fontSize: 12.5 }}>
      {parts.map((p, i) => {
        acc = i === 0 ? p : `${acc}/${p}`;
        const target = acc;
        const clickable = !inBin && !isThisPc;
        return (
          <React.Fragment key={i}>
            {i > 0 && <span style={{ color: 'var(--text-tertiary)' }}>›</span>}
            <button
              onClick={() => clickable && onNavigate(target)}
              style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', padding: '2px 5px', borderRadius: 4, whiteSpace: 'nowrap', cursor: clickable ? 'pointer' : 'default' }}
              onMouseEnter={(e) => clickable && (e.currentTarget.style.background = 'var(--hover)')}
              onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}
            >
              {p}
            </button>
          </React.Fragment>
        );
      })}
    </div>
  );
}

function ThisPc({ fs, onOpen }) {
  const c = getNode(fs, 'C:');
  const used = dirSize(c);
  const total = 512 * 1024 * 1024 * 1024;
  const pct = Math.min(96, Math.max(20, Math.round((used / total) * 100) + 62));
  return (
    <div style={{ padding: 20 }}>
      <div style={{ fontSize: 12, color: 'var(--text-tertiary)', fontWeight: 600, marginBottom: 12 }}>Devices and drives</div>
      <button onClick={() => onOpen('C:')} style={{ display: 'flex', gap: 14, alignItems: 'center', width: 320, padding: 14, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', textAlign: 'left' }}>
        <HardDrive size={38} color="var(--text-secondary)" />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Local Disk (C:)</div>
          <div style={{ height: 7, background: 'var(--surface-solid)', borderRadius: 4, overflow: 'hidden' }}>
            <div style={{ width: `${pct}%`, height: '100%', background: pct > 90 ? 'var(--danger)' : 'var(--accent)' }} />
          </div>
          <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 5 }}>{formatBytes(total - used)} free of 512 GB</div>
        </div>
      </button>
    </div>
  );
}

function DetailsView({ items, inBin, selected, onSelect, onOpen, onContext, onRestore }) {
  return (
    <table className="data">
      <thead>
        <tr>
          <th style={{ width: '42%' }}>Name</th>
          <th>{inBin ? 'Original location' : 'Date modified'}</th>
          <th>Type</th>
          <th style={{ textAlign: 'right' }}>Size</th>
        </tr>
      </thead>
      <tbody>
        {items.map((item) => (
          <tr
            key={item.path + (item.binId || '')}
            className={`${item.suspicious ? 'suspicious-row' : ''} ${selected === item.path ? 'selected' : ''}`}
            onMouseDown={(e) => { e.stopPropagation(); onSelect(item.path); }}
            onDoubleClick={() => (inBin ? onRestore(item.binId) : onOpen(item))}
            onContextMenu={(e) => onContext(e, item)}
            style={{ cursor: 'default' }}
          >
            <td style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              {fileIconFor(item.name, 17, item.type === 'dir')}
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: item.hidden ? 'var(--text-tertiary)' : 'var(--text-primary)' }}>{item.name}</span>
              {item.suspicious && <span title="Flagged">⚠️</span>}
            </td>
            <td style={{ color: 'var(--text-tertiary)', whiteSpace: 'nowrap' }}>{inBin ? parentPath(item.originalPath) : formatDateTime(item.modified)}</td>
            <td style={{ color: 'var(--text-tertiary)' }}>{item.type === 'dir' ? 'File folder' : (item.name.split('.').pop() || 'File').toUpperCase() + ' file'}</td>
            <td style={{ textAlign: 'right', color: 'var(--text-tertiary)' }}>{item.type === 'dir' ? '' : formatBytes(item.size)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function GridView({ items, selected, onSelect, onOpen, onContext, inBin }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(104px, 1fr))', gap: 6, padding: 12 }}>
      {items.map((item) => (
        <button
          key={item.path + (item.binId || '')}
          onMouseDown={(e) => { e.stopPropagation(); onSelect(item.path); }}
          onDoubleClick={() => onOpen(item)}
          onContextMenu={(e) => onContext(e, item)}
          className={selected === item.path ? 'selected' : ''}
          style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, padding: '14px 6px', border: '1px solid transparent', background: selected === item.path ? 'var(--selected)' : 'transparent', borderRadius: 'var(--radius-sm)', color: 'var(--text-primary)' }}
        >
          <div style={{ position: 'relative' }}>
            {fileIconFor(item.name, 40, item.type === 'dir')}
            {item.suspicious && <span style={{ position: 'absolute', bottom: -2, right: -6, fontSize: 12 }}>⚠️</span>}
          </div>
          <span style={{ fontSize: 11.5, textAlign: 'center', wordBreak: 'break-word', lineHeight: 1.25, maxHeight: 30, overflow: 'hidden' }}>{item.name}</span>
        </button>
      ))}
    </div>
  );
}

/* ---- helpers ------------------------------------------------------------- */

function promptText(title, label, initial) {
  return new Promise((resolve) => {
    const id = `prompt-${Date.now()}`;
    openDialog({
      title,
      html: `<div style="margin-bottom:8px">${label}</div><input id="${id}" class="os-input" value="${(initial || '').replace(/"/g, '&quot;')}" />`,
      buttons: [
        { label: 'Cancel', value: null },
        { label: 'OK', value: '__ok__', variant: 'primary' },
      ],
    }).then((res) => {
      const el = document.getElementById(id);
      resolve(res === '__ok__' ? (el?.value ?? initial) : null);
    });
    setTimeout(() => { const el = document.getElementById(id); el?.focus(); el?.select(); }, 60);
  });
}

function showProperties(item, fs) {
  const node = item.type ? item : getNode(fs, item.path);
  const isDir = node.type === 'dir';
  openDialog({
    title: `${item.name} Properties`,
    html: `
      <table style="width:100%;font-size:12.5px;line-height:1.9">
        <tr><td style="color:var(--text-tertiary);width:120px">Type</td><td>${isDir ? 'File folder' : (item.name.split('.').pop() || '').toUpperCase() + ' File'}</td></tr>
        <tr><td style="color:var(--text-tertiary)">Location</td><td class="mono" style="word-break:break-all">${parentPath(item.path)}</td></tr>
        <tr><td style="color:var(--text-tertiary)">Size</td><td>${isDir ? `${countItems(node)} items` : formatBytes(node.size)}</td></tr>
        <tr><td style="color:var(--text-tertiary)">Created</td><td>${node.created ? formatDateTime(node.created) : '—'}</td></tr>
        <tr><td style="color:var(--text-tertiary)">Modified</td><td>${node.modified ? formatDateTime(node.modified) : '—'}</td></tr>
        <tr><td style="color:var(--text-tertiary)">Attributes</td><td>${[node.hidden && 'Hidden', node.system && 'System', node.suspicious && 'Flagged ⚠'].filter(Boolean).join(', ') || 'Normal'}</td></tr>
      </table>`,
    buttons: [{ label: 'OK', value: true, variant: 'primary' }],
  });
}
