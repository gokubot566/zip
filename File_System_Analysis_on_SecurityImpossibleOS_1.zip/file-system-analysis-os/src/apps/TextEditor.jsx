import React, { useEffect, useState } from 'react';
import { Save, Globe, AlertTriangle } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { getNode, baseName, extension } from '../core/fs.js';
import { Toolbar, Banner } from './kit.jsx';

// Generic text/source viewer & editor. It records that a file was opened
// (a normal OS "recently opened" fact); any lab derives meaning from that.
export default function TextEditor({ win, args }) {
  const { state, writeFile, setWindowTitle, recordOpenFile, openApp } = useOS();
  const path = args?.path ?? null;
  const node = path ? getNode(state.fs, path) : null;
  const initial = node?.content ?? args?.content ?? '';

  const [text, setText] = useState(initial);
  const [dirty, setDirty] = useState(false);
  const ext = path ? extension(path) : 'txt';
  const isHtml = ext === 'html' || ext === 'htm';
  const name = path ? baseName(path) : 'Untitled';

  useEffect(() => {
    setWindowTitle(win.id, `${name} — Text Editor`);
    if (path) recordOpenFile(path);
  }, [win.id, name, path]);

  const save = () => {
    if (!path) return;
    writeFile(path, text, { modified: Date.now() });
    setDirty(false);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0 }}>
      <Toolbar>
        <button className="os-btn ghost" onClick={save} disabled={!path || !dirty} style={{ fontSize: 12.5 }}>
          <Save size={15} /> Save
        </button>
        {isHtml && (
          <button className="os-btn ghost" style={{ fontSize: 12.5 }} onClick={() => openApp('browser', { render: text, title: name })}>
            <Globe size={15} /> Open in browser
          </button>
        )}
        <div style={{ marginLeft: 'auto', fontSize: 11.5, color: 'var(--text-tertiary)' }}>
          {node?.suspicious ? <span className="danger-text" style={{ fontWeight: 600 }}>⚠ Flagged file</span> : `${text.length} chars`}
        </div>
      </Toolbar>

      <div style={{ padding: '10px 12px 0', flexShrink: 0 }}>
        {node?.suspicious && (
          <Banner variant="error" icon={<AlertTriangle size={16} />}>
            This file is flagged as a potential indicator of compromise. Its contents are shown for analysis only.
          </Banner>
        )}
        {isHtml && (
          <Banner variant="warning" icon={<Globe size={16} />}>
            You're viewing the <strong>source</strong> of an HTML file. Read it here safely, or render it in the sandboxed browser.
          </Banner>
        )}
      </div>

      <textarea
        className="selectable"
        value={text}
        onChange={(e) => { setText(e.target.value); setDirty(true); }}
        spellCheck={false}
        style={{
          flex: 1, resize: 'none', border: 'none', outline: 'none', padding: '10px 14px',
          background: 'var(--window-bg)', color: 'var(--text-primary)',
          fontFamily: ext === 'txt' || ext === 'docx' ? 'var(--font)' : 'var(--mono)',
          fontSize: 13, lineHeight: 1.6, whiteSpace: 'pre', overflow: 'auto',
        }}
      />
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 12px', borderTop: '1px solid var(--border)', background: 'var(--surface-1)', fontSize: 11, color: 'var(--text-tertiary)' }}>
        <span>{path || 'Not saved'}</span>
        <span>{dirty ? 'Modified' : 'Saved'} · {ext.toUpperCase()}</span>
      </div>
    </div>
  );
}
