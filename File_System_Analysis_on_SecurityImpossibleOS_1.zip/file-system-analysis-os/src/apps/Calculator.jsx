import React, { useState, useCallback, useEffect } from 'react';

// A small standard calculator — everyday app that makes the desktop feel real.
export default function Calculator() {
  const [display, setDisplay] = useState('0');
  const [prev, setPrev] = useState(null);
  const [op, setOp] = useState(null);
  const [fresh, setFresh] = useState(true);

  const inputDigit = useCallback((d) => {
    setDisplay((cur) => {
      if (fresh) { setFresh(false); return d === '.' ? '0.' : d; }
      if (d === '.' && cur.includes('.')) return cur;
      if (cur === '0' && d !== '.') return d;
      return cur + d;
    });
  }, [fresh]);

  const compute = (a, b, o) => {
    switch (o) {
      case '+': return a + b;
      case '−': return a - b;
      case '×': return a * b;
      case '÷': return b === 0 ? NaN : a / b;
      default: return b;
    }
  };

  const applyOp = (nextOp) => {
    const val = parseFloat(display);
    if (prev == null) setPrev(val);
    else if (!fresh) { const r = compute(prev, val, op); setPrev(r); setDisplay(fmt(r)); }
    setOp(nextOp);
    setFresh(true);
  };

  const equals = () => {
    if (op == null || prev == null) return;
    const val = parseFloat(display);
    const r = compute(prev, val, op);
    setDisplay(fmt(r));
    setPrev(null); setOp(null); setFresh(true);
  };

  const clearAll = () => { setDisplay('0'); setPrev(null); setOp(null); setFresh(true); };
  const negate = () => setDisplay((c) => fmt(parseFloat(c) * -1));
  const percent = () => setDisplay((c) => fmt(parseFloat(c) / 100));
  const back = () => setDisplay((c) => (c.length <= 1 || (c.length === 2 && c.startsWith('-')) ? '0' : c.slice(0, -1)));

  useEffect(() => {
    const onKey = (e) => {
      if (e.key >= '0' && e.key <= '9') inputDigit(e.key);
      else if (e.key === '.') inputDigit('.');
      else if (e.key === '+') applyOp('+');
      else if (e.key === '-') applyOp('−');
      else if (e.key === '*') applyOp('×');
      else if (e.key === '/') { e.preventDefault(); applyOp('÷'); }
      else if (e.key === 'Enter' || e.key === '=') equals();
      else if (e.key === 'Backspace') back();
      else if (e.key === 'Escape') clearAll();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  const keys = [
    ['%', 'CE', 'C', '⌫'],
    ['¹⁄ₓ', 'x²', '√', '÷'],
    ['7', '8', '9', '×'],
    ['4', '5', '6', '−'],
    ['1', '2', '3', '+'],
    ['±', '0', '.', '='],
  ];

  const press = (k) => {
    if (k >= '0' && k <= '9') return inputDigit(k);
    switch (k) {
      case '.': return inputDigit('.');
      case '+': case '−': case '×': case '÷': return applyOp(k);
      case '=': return equals();
      case 'C': return clearAll();
      case 'CE': return setDisplay('0');
      case '⌫': return back();
      case '±': return negate();
      case '%': return percent();
      case 'x²': return setDisplay((c) => fmt(parseFloat(c) ** 2));
      case '√': return setDisplay((c) => fmt(Math.sqrt(parseFloat(c))));
      case '¹⁄ₓ': return setDisplay((c) => fmt(1 / parseFloat(c)));
      default: return undefined;
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'var(--window-bg)', padding: 10 }}>
      <div style={{ padding: '18px 12px', textAlign: 'right', minHeight: 70, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
        <div style={{ fontSize: 12, color: 'var(--text-tertiary)', height: 16 }}>{prev != null ? `${fmt(prev)} ${op ?? ''}` : ''}</div>
        <div style={{ fontSize: 38, fontWeight: 300, overflow: 'hidden', textOverflow: 'ellipsis' }}>{display}</div>
      </div>
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
        {keys.flat().map((k, i) => {
          const isOp = ['÷', '×', '−', '+', '='].includes(k);
          const isEq = k === '=';
          return (
            <button
              key={i}
              onClick={() => press(k)}
              style={{
                border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', fontSize: 17,
                background: isEq ? 'var(--accent)' : isOp ? 'var(--surface-3)' : 'var(--surface-2)',
                color: isEq ? 'var(--accent-contrast)' : 'var(--text-primary)', fontWeight: isEq ? 700 : 400,
                transition: 'filter 0.1s',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(1.15)')}
              onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
            >
              {k}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function fmt(n) {
  if (!isFinite(n)) return 'Error';
  const r = Math.round((n + Number.EPSILON) * 1e10) / 1e10;
  return String(r);
}
