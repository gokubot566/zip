import React, { useState } from 'react';
import { HelpCircle, Compass, Keyboard, Info, GraduationCap } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { BRANDING, LogoLockup, copyrightLine } from '../config/branding.jsx';
import { getActiveLab } from '../labs/index.js';
import { Banner } from './kit.jsx';

const NAV = [
  { id: 'welcome', label: 'Welcome', icon: Compass },
  { id: 'shortcuts', label: 'Tips & shortcuts', icon: Keyboard },
  { id: 'about', label: 'About', icon: Info },
];

// Generic help/about app. Shows platform info from branding, and — if a lab is
// loaded — surfaces whatever metadata the lab provides (without knowing its
// content). Contains no lab-specific logic.
export default function Help() {
  const { state, openApp } = useOS();
  const [nav, setNav] = useState('welcome');
  const lab = getActiveLab();

  return (
    <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
      <div style={{ width: 190, flexShrink: 0, borderRight: '1px solid var(--border)', background: 'var(--surface-0)', padding: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 8px 12px' }}>
          <HelpCircle size={18} color="var(--accent)" /><span style={{ fontSize: 13, fontWeight: 700 }}>Help</span>
        </div>
        {NAV.map((n) => (
          <button key={n.id} onClick={() => setNav(n.id)} className={`list-row ${nav === n.id ? 'selected' : ''}`} style={{ width: '100%', border: 'none' }}>
            <n.icon size={15} color={nav === n.id ? 'var(--accent)' : 'var(--text-secondary)'} /><span style={{ fontSize: 12.5 }}>{n.label}</span>
          </button>
        ))}
        {lab && (
          <button onClick={() => setNav('lab')} className={`list-row ${nav === 'lab' ? 'selected' : ''}`} style={{ width: '100%', border: 'none' }}>
            <GraduationCap size={15} color={nav === 'lab' ? 'var(--accent)' : 'var(--text-secondary)'} /><span style={{ fontSize: 12.5 }}>Current lab</span>
          </button>
        )}
      </div>

      <div className="scrolly" style={{ flex: 1, padding: 24 }}>
        {nav === 'welcome' && (
          <div>
            <LogoLockup size={40} subtitle={`${BRANDING.edition} · v${BRANDING.version}`} />
            <p style={{ fontSize: 13.5, color: 'var(--text-secondary)', lineHeight: 1.6, marginTop: 18 }}>
              Welcome to {BRANDING.product}. {BRANDING.tagline}
            </p>
            <h3 style={{ fontSize: 14, marginTop: 20 }}>Getting around</h3>
            <ul style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.8, paddingLeft: 18 }}>
              <li>Use the <strong>Start menu</strong> (bottom-left) to launch apps and search files.</li>
              <li>Windows can be <strong>dragged, resized, minimized and maximized</strong>.</li>
              <li><strong>Right-click</strong> the desktop or files for context menus.</li>
              <li>Open <strong>Settings</strong> to change wallpaper, accent color and theme.</li>
              <li>The <strong>notification bell</strong> (bottom-right) opens the notification center.</li>
            </ul>
            <button className="os-btn primary" style={{ marginTop: 8 }} onClick={() => openApp('explorer')}>Open File Explorer</button>
          </div>
        )}

        {nav === 'shortcuts' && (
          <div>
            <h2 style={{ fontSize: 17, marginTop: 0 }}>Tips & shortcuts</h2>
            {[
              ['Double-click a title bar', 'Maximize / restore a window'],
              ['Drag a title bar', 'Move a window'],
              ['Drag a window edge or corner', 'Resize a window'],
              ['Right-click desktop / files', 'Context menu'],
              ['Start menu → type', 'Search apps and files'],
              ['Settings → System', 'Show hidden files'],
            ].map(([k, v]) => (
              <div key={k} style={{ display: 'flex', gap: 16, padding: '9px 0', borderBottom: '1px solid var(--border)' }}>
                <span className="chip" style={{ minWidth: 210, justifyContent: 'flex-start' }}>{k}</span>
                <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{v}</span>
              </div>
            ))}
          </div>
        )}

        {nav === 'about' && (
          <div>
            <h2 style={{ fontSize: 17, marginTop: 0 }}>About {BRANDING.product}</h2>
            <table style={{ fontSize: 12.5, lineHeight: 1.9 }}>
              <tbody>
                <tr><td style={{ color: 'var(--text-tertiary)', paddingRight: 20 }}>Product</td><td>{BRANDING.product}</td></tr>
                <tr><td style={{ color: 'var(--text-tertiary)' }}>Edition</td><td>{BRANDING.edition}</td></tr>
                <tr><td style={{ color: 'var(--text-tertiary)' }}>Version</td><td>{BRANDING.version} (Build {BRANDING.build})</td></tr>
                <tr><td style={{ color: 'var(--text-tertiary)' }}>Publisher</td><td>{BRANDING.company}</td></tr>
                <tr><td style={{ color: 'var(--text-tertiary)' }}>Device</td><td>{state.profile.hostname}</td></tr>
                <tr><td style={{ color: 'var(--text-tertiary)' }}>Signed-in user</td><td>{state.profile.name}</td></tr>
              </tbody>
            </table>
            <p style={{ fontSize: 11.5, color: 'var(--text-tertiary)', marginTop: 18 }}>{copyrightLine()}</p>
          </div>
        )}

        {nav === 'lab' && lab && (
          <div>
            <h2 style={{ fontSize: 17, marginTop: 0 }}>{lab.meta?.name ?? 'Training lab'}</h2>
            <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
              {lab.meta?.category && <span className="chip">{lab.meta.category}</span>}
              {lab.meta?.difficulty && <span className="chip">{lab.meta.difficulty}</span>}
            </div>
            <p style={{ fontSize: 13.5, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{lab.meta?.summary}</p>
            <Banner variant="info" icon={<GraduationCap size={15} />}>
              This workstation is running a training lab. Explore the tools to complete the objectives.
            </Banner>
          </div>
        )}
      </div>
    </div>
  );
}
