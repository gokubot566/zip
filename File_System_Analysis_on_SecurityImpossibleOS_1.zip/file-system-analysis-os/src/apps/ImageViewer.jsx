import React, { useEffect, useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Image as ImageIcon } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { getNode, listDir, parentPath, baseName } from '../core/fs.js';
import { isImage } from './fileIcons.jsx';
import { Empty } from './kit.jsx';

// There are no real bitmaps in the virtual FS, so we render a deterministic
// generated preview from the filename — enough to make Pictures feel populated.
export default function ImageViewer({ win, args }) {
  const { state, setWindowTitle } = useOS();
  const [path, setPath] = useState(args?.path ?? null);

  const dir = path ? parentPath(path) : `C:/Users/${state.profile.username}/Pictures`;
  const siblings = useMemo(
    () => listDir(state.fs, dir).filter((n) => n.type === 'file' && isImage(n.name)),
    [state.fs, dir],
  );
  const index = siblings.findIndex((s) => s.path === path);
  const node = path ? getNode(state.fs, path) : null;

  useEffect(() => {
    setWindowTitle(win.id, node ? `${baseName(path)} — Image Viewer` : 'Image Viewer');
  }, [win.id, path]);

  const go = (delta) => {
    if (siblings.length === 0) return;
    const next = (index + delta + siblings.length) % siblings.length;
    setPath(siblings[next].path);
  };

  if (siblings.length === 0 && !node) {
    return <Empty icon={<ImageIcon size={40} />} title="No pictures" sub="Open an image from File Explorer to view it here." />;
  }

  const current = node ?? siblings[0];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0, background: '#0b0e16' }}>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', minHeight: 0, padding: 20 }}>
        {siblings.length > 1 && (
          <NavBtn side="left" onClick={() => go(-1)}><ChevronLeft size={22} /></NavBtn>
        )}
        <GeneratedPhoto name={current?.name ?? ''} />
        {siblings.length > 1 && (
          <NavBtn side="right" onClick={() => go(1)}><ChevronRight size={22} /></NavBtn>
        )}
      </div>

      {/* filmstrip */}
      <div style={{ display: 'flex', gap: 8, padding: 10, overflowX: 'auto', borderTop: '1px solid var(--border)', background: 'var(--surface-1)' }}>
        {siblings.map((s) => (
          <button
            key={s.path}
            onClick={() => setPath(s.path)}
            title={s.name}
            style={{
              flexShrink: 0, width: 72, height: 52, borderRadius: 6, overflow: 'hidden', padding: 0,
              border: `2px solid ${s.path === (path ?? siblings[0]?.path) ? 'var(--accent)' : 'transparent'}`,
            }}
          >
            <GeneratedPhoto name={s.name} thumb />
          </button>
        ))}
      </div>
      <div style={{ padding: '6px 12px', fontSize: 11.5, color: 'var(--text-tertiary)', background: 'var(--surface-1)', borderTop: '1px solid var(--border)' }}>
        {current?.name} · {index >= 0 ? index + 1 : 1} of {siblings.length}
      </div>
    </div>
  );
}

function NavBtn({ side, onClick, children }) {
  return (
    <button
      onClick={onClick}
      style={{
        position: 'absolute', [side]: 12, top: '50%', transform: 'translateY(-50%)', zIndex: 2,
        width: 40, height: 40, borderRadius: '50%', border: 'none',
        background: 'rgba(0,0,0,0.5)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}
    >
      {children}
    </button>
  );
}

// Deterministic gradient + label placeholder derived from the file name.
function GeneratedPhoto({ name, thumb }) {
  const hue = useMemo(() => {
    let h = 0;
    for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) % 360;
    return h;
  }, [name]);
  const bg = `linear-gradient(135deg, hsl(${hue} 55% 42%), hsl(${(hue + 60) % 360} 55% 30%))`;
  if (thumb) return <div style={{ width: '100%', height: '100%', background: bg }} />;
  return (
    <div style={{
      maxWidth: '100%', maxHeight: '100%', width: 480, height: 320, borderRadius: 10, background: bg,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12,
      boxShadow: 'var(--shadow-md)', color: 'rgba(255,255,255,0.9)',
    }}>
      <ImageIcon size={56} strokeWidth={1.2} />
      <div style={{ fontSize: 14, fontWeight: 500, textShadow: '0 1px 4px rgba(0,0,0,0.5)' }}>{name}</div>
      <div style={{ fontSize: 11, opacity: 0.7 }}>Simulated preview</div>
    </div>
  );
}
