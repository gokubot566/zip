import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck, ShieldAlert, ShieldX, Bug, Flame, Activity, ScanLine, Loader2,
  CheckCircle2, Trash2, WifiOff, Wifi, History,
} from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { BRANDING } from '../config/branding.jsx';
import { Banner, severityClass } from './kit.jsx';
import { confirmDialog } from '../shell/ui.js';

const NAV = [
  { id: 'overview', label: 'Home', icon: ShieldCheck },
  { id: 'virus', label: 'Virus & threat protection', icon: Bug },
  { id: 'firewall', label: 'Firewall & network', icon: Flame },
  { id: 'history', label: 'Protection history', icon: History },
];

export default function SecurityCenter({ args }) {
  const { state, quarantineThreats, setNetworkIsolated, recordScan, notify } = useOS();
  const [nav, setNav] = useState(args?.section ?? 'overview');

  const THREATS = state.data.threats ?? [];
  const quarantined = state.activity.quarantined;
  const activeThreats = THREATS.filter((t) => !quarantined.includes(t.id));
  const protectedNow = activeThreats.length === 0;

  return (
    <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
      <div style={{ width: 210, flexShrink: 0, borderRight: '1px solid var(--border)', background: 'var(--surface-0)', padding: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 8px 12px' }}>
          <ShieldCheck size={20} color="var(--accent)" />
          <span style={{ fontSize: 13, fontWeight: 700 }}>Security Center</span>
        </div>
        {NAV.map((n) => (
          <button key={n.id} onClick={() => setNav(n.id)} className={`list-row ${nav === n.id ? 'selected' : ''}`} style={{ width: '100%', border: 'none' }}>
            <n.icon size={16} color={nav === n.id ? 'var(--accent)' : 'var(--text-secondary)'} />
            <span style={{ fontSize: 12.5, textAlign: 'left' }}>{n.label}</span>
          </button>
        ))}
      </div>

      <div className="scrolly" style={{ flex: 1, padding: 20 }}>
        {nav === 'overview' && <Overview protectedNow={protectedNow} activeThreats={activeThreats} onGo={setNav} isolated={state.activity.networkIsolated} />}
        {nav === 'virus' && <VirusProtection threats={THREATS} activeThreats={activeThreats} quarantined={quarantined} quarantineThreats={quarantineThreats} recordScan={recordScan} notify={notify} />}
        {nav === 'firewall' && <Firewall isolated={state.activity.networkIsolated} setNetworkIsolated={setNetworkIsolated} notify={notify} />}
        {nav === 'history' && <ProtectionHistory threats={THREATS} quarantined={quarantined} />}
      </div>
    </div>
  );
}

function StatusCard({ ok, title, desc, icon, onClick }) {
  return (
    <button onClick={onClick} style={{ textAlign: 'left', display: 'flex', gap: 12, padding: 16, background: 'var(--surface-1)', border: `1px solid ${ok ? 'var(--border)' : 'var(--danger)'}`, borderRadius: 'var(--radius-md)', width: '100%' }}>
      <div style={{ position: 'relative' }}>
        {icon}
        <div style={{ position: 'absolute', bottom: -3, right: -3, background: ok ? 'var(--success)' : 'var(--danger)', borderRadius: '50%', width: 15, height: 15, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {ok ? <CheckCircle2 size={11} color="#fff" /> : <span style={{ color: '#fff', fontWeight: 900, fontSize: 11, lineHeight: 1 }}>!</span>}
        </div>
      </div>
      <div>
        <div style={{ fontSize: 13, fontWeight: 600 }}>{title}</div>
        <div style={{ fontSize: 11.5, color: ok ? 'var(--text-tertiary)' : 'var(--danger)', marginTop: 2 }}>{desc}</div>
      </div>
    </button>
  );
}

function Overview({ protectedNow, activeThreats, onGo, isolated }) {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 20 }}>
        {protectedNow ? <ShieldCheck size={40} color="var(--success)" /> : <ShieldAlert size={40} color="var(--danger)" />}
        <div>
          <h2 style={{ fontSize: 18, margin: 0 }}>{protectedNow ? 'Your device is protected' : 'Actions recommended'}</h2>
          <div style={{ fontSize: 12.5, color: 'var(--text-tertiary)' }}>
            {protectedNow ? 'No current threats. All detections have been quarantined.' : `${activeThreats.length} active threat${activeThreats.length === 1 ? '' : 's'} need attention.`}
          </div>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <StatusCard ok={protectedNow} onClick={() => onGo('virus')} icon={<Bug size={26} color="var(--text-secondary)" />} title="Virus & threat protection" desc={protectedNow ? 'No action needed' : `${activeThreats.length} threats found`} />
        <StatusCard ok={isolated} onClick={() => onGo('firewall')} icon={<Flame size={26} color="var(--text-secondary)" />} title="Firewall & network" desc={isolated ? 'Host isolated from network' : 'Outbound C2 traffic observed'} />
        <StatusCard ok icon={<Activity size={26} color="var(--text-secondary)" />} title="Device performance" desc="Reporting available" />
        <StatusCard ok icon={<ShieldCheck size={26} color="var(--text-secondary)" />} title="Account protection" desc="No action needed" />
      </div>
    </div>
  );
}

function VirusProtection({ threats, activeThreats, quarantined, quarantineThreats, recordScan, notify }) {
  const [phase, setPhase] = useState(quarantined.length > 0 ? 'done' : 'idle'); // idle | scanning | done
  const [progress, setProgress] = useState(0);
  const [scanned, setScanned] = useState(0);
  const timer = useRef(null);

  const startScan = () => {
    setPhase('scanning');
    setProgress(0);
    recordScan();
    let p = 0;
    timer.current = setInterval(() => {
      p += Math.max(2, 8 - p / 15);
      setProgress(Math.min(100, p));
      setScanned(Math.round((Math.min(100, p) / 100) * 214731));
      if (p >= 100) { clearInterval(timer.current); setPhase('done'); }
    }, 120);
  };
  useEffect(() => () => clearInterval(timer.current), []);

  const quarantine = (t) => quarantineThreats([t.id]);
  const quarantineAll = async () => {
    const ok = await confirmDialog(`Quarantine all ${activeThreats.length} detected threats?`, { title: 'Security Center', confirmLabel: 'Quarantine all', variant: 'warning' });
    if (!ok) return;
    quarantineThreats(activeThreats.map((t) => t.id));
    notify({ title: 'Security Center', body: `${activeThreats.length} threats quarantined.`, variant: 'success', appId: 'security' });
  };

  const showResults = phase === 'done';

  return (
    <div>
      <h2 style={{ fontSize: 17, marginTop: 0 }}>Virus & threat protection</h2>

      {!showResults && activeThreats.length > 0 && (
        <Banner variant="error" icon={<ShieldAlert size={15} />}>
          Real-time protection logged a detection yesterday but <strong>quarantine failed</strong> (the file was locked by a running process). Run a full scan to enumerate everything on disk.
        </Banner>
      )}

      {/* scan box */}
      <div style={{ background: 'var(--surface-1)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: 18, marginBottom: 16 }}>
        {phase === 'scanning' ? (
          <>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Loader2 size={20} className="spin" color="var(--accent)" />
              <span style={{ fontSize: 13, fontWeight: 600 }}>Full scan in progress… {progress.toFixed(0)}%</span>
            </div>
            <div style={{ height: 8, background: 'var(--surface-solid)', borderRadius: 4, overflow: 'hidden', margin: '12px 0 6px' }}>
              <div style={{ width: `${progress}%`, height: '100%', background: 'var(--accent)', transition: 'width 0.12s' }} />
            </div>
            <div className="mono" style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{scanned.toLocaleString()} items scanned…</div>
          </>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <ScanLine size={26} color="var(--accent)" />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600 }}>{showResults ? `Scan complete — ${threats.length} threat${threats.length === 1 ? '' : 's'} found` : 'Full scan'}</div>
              <div style={{ fontSize: 11.5, color: 'var(--text-tertiary)' }}>{showResults ? 'Review and quarantine the detections below.' : 'Check every file and running program on this PC.'}</div>
            </div>
            <button className="os-btn primary" onClick={startScan}>{showResults ? 'Scan again' : 'Quick scan'}</button>
          </div>
        )}
      </div>

      {/* results */}
      {showResults && (
        <>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: 10 }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>Current threats {activeThreats.length === 0 && '· all clear'}</span>
            {activeThreats.length > 0 && <button className="os-btn danger" style={{ marginLeft: 'auto', fontSize: 12 }} onClick={quarantineAll}><Trash2 size={14} /> Quarantine all</button>}
          </div>
          {activeThreats.length === 0 ? (
            <Banner variant="success" icon={<CheckCircle2 size={16} />}>{threats.length === 0 ? 'No threats found. Your device is protected.' : 'All detected threats have been quarantined. Remember to remove persistence and reset any exposed credentials.'}</Banner>
          ) : (
            threats.map((t) => {
              const done = quarantined.includes(t.id);
              return (
                <div key={t.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, marginBottom: 8, borderRadius: 'var(--radius-md)', border: `1px solid ${done ? 'var(--border)' : 'var(--danger)'}`, background: done ? 'var(--surface-1)' : 'var(--danger-bg)', opacity: done ? 0.65 : 1 }}>
                  {done ? <CheckCircle2 size={20} color="var(--success)" /> : <Bug size={20} color="var(--danger)" />}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 600 }}>{t.name} <span className={severityClass(t.severity)} style={{ marginLeft: 6 }}>{t.severity}</span></div>
                    <div className="mono" style={{ fontSize: 11, color: 'var(--text-tertiary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.category} · {t.path}</div>
                  </div>
                  {done ? <span style={{ fontSize: 11.5, color: 'var(--success)', fontWeight: 600 }}>Quarantined</span>
                    : <button className="os-btn" style={{ fontSize: 12 }} onClick={() => quarantine(t)}>Quarantine</button>}
                </div>
              );
            })
          )}
        </>
      )}
    </div>
  );
}

function Firewall({ isolated, setNetworkIsolated, notify }) {
  const toggle = () => {
    const next = !isolated;
    setNetworkIsolated(next);
    notify({ title: 'Firewall', body: next ? 'Host isolated — all network adapters disabled.' : 'Network reconnected.', variant: next ? 'warning' : 'success', appId: 'security' });
  };
  return (
    <div>
      <h2 style={{ fontSize: 17, marginTop: 0 }}>Firewall & network protection</h2>
      <Banner variant={isolated ? 'success' : 'info'} icon={isolated ? <WifiOff size={15} /> : <Flame size={15} />}>
        {isolated
          ? 'This host is isolated from the network. Isolation stops any command-and-control communication and data exfiltration while an incident is investigated.'
          : 'The firewall is active. If you suspect the host is compromised, isolate it from the network to cut off any command-and-control channel.'}
      </Banner>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 16, background: 'var(--surface-1)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)' }}>
        {isolated ? <WifiOff size={26} color="var(--warning)" /> : <Wifi size={26} color="var(--success)" />}
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600 }}>Network isolation</div>
          <div style={{ fontSize: 11.5, color: 'var(--text-tertiary)' }}>{isolated ? 'Disconnected (containment active)' : 'Connected'}</div>
        </div>
        <button className={`os-btn ${isolated ? '' : 'danger'}`} onClick={toggle}>{isolated ? 'Reconnect' : 'Isolate this host'}</button>
      </div>
      <div style={{ marginTop: 16, fontSize: 12.5, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
        <div>Domain profile: <strong className="success-text">On</strong></div>
        <div>Private profile: <strong className="success-text">On</strong></div>
        <div>Public profile: <strong className="success-text">On</strong></div>
      </div>
    </div>
  );
}

function ProtectionHistory({ threats, quarantined }) {
  const rows = threats.map((t) => ({ ...t, quarantined: quarantined.includes(t.id) }));
  return (
    <div>
      <h2 style={{ fontSize: 17, marginTop: 0 }}>Protection history</h2>
      {rows.length === 0 && <Banner variant="success" icon={<CheckCircle2 size={16} />}>No detections recorded.</Banner>}
      {rows.map((t) => (
        <div key={t.id} className="list-row" style={{ border: '1px solid var(--border)', marginBottom: 6 }}>
          {t.quarantined ? <CheckCircle2 size={16} color="var(--success)" /> : <ShieldAlert size={16} color="var(--danger)" />}
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12.5, fontWeight: 600 }}>{t.name}</div>
            <div className="mono" style={{ fontSize: 11, color: 'var(--text-tertiary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.path}</div>
          </div>
          <span className={severityClass(t.severity)}>{t.severity}</span>
          <span style={{ fontSize: 11, color: t.quarantined ? 'var(--success)' : 'var(--danger)', width: 90, textAlign: 'right' }}>{t.quarantined ? 'Quarantined' : 'Active'}</span>
        </div>
      ))}
    </div>
  );
}
