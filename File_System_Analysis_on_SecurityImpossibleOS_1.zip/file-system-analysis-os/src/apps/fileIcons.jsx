import React from 'react';
import {
  Folder, FileText, FileCode2, FileImage, FileSpreadsheet, FileType2,
  Cog, Terminal, Link2, FileArchive, File, Database, Shield,
} from 'lucide-react';
import { extension } from '../core/fs.js';
import { openDialog } from '../shell/ui.js';
import { BRANDING } from '../config/brand.js';

const IMAGE = ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'svg'];

export function fileIconFor(name, size = 18, isDir = false) {
  if (isDir) return <Folder size={size} color="var(--accent)" fill="rgba(76,194,255,0.18)" />;
  const ext = extension(name);
  const c = size;
  switch (ext) {
    case 'html': case 'htm': return <FileCode2 size={c} color="#e6704b" />;
    case 'exe': case 'msi': case 'dll': case 'scr': return <Cog size={c} color="#9aa4b5" />;
    case 'bat': case 'cmd': case 'ps1': case 'sh': return <Terminal size={c} color="#8de08d" />;
    case 'pdf': return <FileType2 size={c} color="#ff6b6b" />;
    case 'doc': case 'docx': return <FileText size={c} color="#4c8dff" />;
    case 'xls': case 'xlsx': case 'csv': return <FileSpreadsheet size={c} color="#3fbf7f" />;
    case 'png': case 'jpg': case 'jpeg': case 'gif': case 'bmp': case 'webp': return <FileImage size={c} color="#c489f0" />;
    case 'lnk': return <Link2 size={c} color="#ffb020" />;
    case 'zip': case 'rar': case '7z': return <FileArchive size={c} color="#ffc95c" />;
    case 'dat': case 'db': return <Database size={c} color="#9aa4b5" />;
    case 'pf': return <Shield size={c} color="#7d8798" />;
    case 'txt': case 'log': case 'ini': case 'json': case 'md': return <FileText size={c} color="#b6c0d0" />;
    default: return <File size={c} color="#9aa4b5" />;
  }
}

export function isImage(name) {
  return IMAGE.includes(extension(name));
}

// Decide which app opens a filesystem node (used by Explorer, Desktop, Search).
export function openPathFor(node, openApp) {
  if (node.type === 'dir') {
    openApp('explorer', { path: node.path });
    return;
  }
  const ext = extension(node.name);
  if (IMAGE.includes(ext)) {
    openApp('imageviewer', { path: node.path });
    return;
  }
  if (['exe', 'msi', 'dll', 'scr', 'com'].includes(ext)) {
    openDialog({
      title: node.suspicious ? 'Security Center' : BRANDING.product,
      variant: node.suspicious ? 'error' : 'warning',
      message: node.suspicious
        ? `${node.name}\n\nThis file is flagged as malicious. Running it is blocked in this environment.\n\nInspect it instead: check Task Manager for a matching process, review the Event Viewer, and quarantine it in the Security Center.`
        : `${node.name}\n\nInstallers and executables can't be launched in this environment. You can still inspect the file's details.`,
      buttons: [{ label: 'OK', value: true, variant: 'primary' }],
    });
    return;
  }
  // Everything else opens in the Text Editor (text/source viewer & editor).
  openApp('texteditor', { path: node.path });
}
