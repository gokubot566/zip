import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft, ArrowRight, RotateCw, Lock, Search, History, Download, Home, Star, ShieldAlert, Globe,
} from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { getNode } from '../core/fs.js';
import { formatFriendly, formatBytes } from '../core/utils.js';
import { BRANDING } from '../config/branding.jsx';
import { Toolbar, Banner } from './kit.jsx';

const HOME_URL = 'si://home';

export default function Browser({ win, args }) {
  const { state, recordActivity, recordOpenFile, setWindowTitle, notify } = useOS();
  const browser = state.data.browser ?? { history: [], downloads: [], pages: {} };
  const BROWSER_HISTORY = browser.history ?? [];
  const BROWSER_DOWNLOADS = browser.downloads ?? [];
  const WEB_PAGES = browser.pages ?? {};
  const [tab, setTab] = useState('page'); // page | history | downloads
  const [url, setUrl] = useState(HOME_URL);
  const [input, setInput] = useState('');
  const [view, setView] = useState(null); // { kind, title, html, suspicious }
  const [history, setHistory] = useState([HOME_URL]);
  const [hIdx, setHIdx] = useState(0);

  // Resolve initial args (render raw HTML, open a saved path, or a URL).
  useEffect(() => {
    if (args?.render != null) {
      setView({ kind: 'html', title: args.title || 'Local file', html: args.render, suspicious: true });
      setUrl(`file:///${args.title || 'document.html'}`);
      setInput(`file:///${args.title || 'document.html'}`);
    } else if (args?.openPath) {
      const node = getNode(state.fs, args.openPath);
      if (node) {
        setView({ kind: 'html', title: node.name, html: node.content, suspicious: node.suspicious });
        setUrl(`file:///${args.openPath}`);
        setInput(`file:///${args.openPath}`);
        recordOpenFile(args.openPath);
      }
    } else if (args?.url) {
      go(args.url);
    }
  }, []); // eslint-disable-line

  useEffect(() => { setWindowTitle(win.id, `${view?.title || 'New tab'} — ${BRANDING.productShort} Browser`); }, [win.id, view]);

  const go = (raw, pushHist = true) => {
    let u = (raw || '').trim();
    if (!u) return;
    if (u === HOME_URL || u === 'home') { setUrl(HOME_URL); setInput(''); setView(null); setTab('page'); commit(HOME_URL, pushHist); return; }
    if (!/^[a-z]+:\/\//i.test(u) && !u.startsWith('file:///')) u = `https://${u}`;
    setUrl(u);
    setInput(u);
    setTab('page');
    recordActivity(`url:${u}`);

    // File source view.
    if (u.startsWith('file:///')) {
      const p = u.replace('file:///', '');
      const node = getNode(state.fs, p);
      if (node) recordOpenFile(p);
      setView(node ? { kind: 'html', title: node.name, html: node.content, suspicious: node.suspicious } : { kind: 'error', title: 'Not found' });
      commit(u, pushHist);
      return;
    }

    const known = WEB_PAGES[u];
    if (known?.kind === 'download') {
      setView({ kind: 'download', title: known.title || 'download', suspicious: !!known.suspicious, url: u });
      if (known.suspicious) notify({ title: 'Downloads', body: `${known.title} — flagged by SmartScreen as malicious.`, variant: 'error', appId: 'browser' });
    } else if (known?.kind === 'page') {
      setView({ kind: 'html', title: known.title, html: known.html, suspicious: !!known.suspicious });
    } else {
      setView({ kind: 'generic', title: hostOf(u), url: u });
    }
    commit(u, pushHist);
  };

  const commit = (u, push) => {
    if (!push) return;
    const trimmed = history.slice(0, hIdx + 1);
    setHistory([...trimmed, u]);
    setHIdx(trimmed.length);
  };
  const back = () => { if (hIdx > 0) { const u = history[hIdx - 1]; setHIdx(hIdx - 1); go(u, false); } };
  const forward = () => { if (hIdx < history.length - 1) { const u = history[hIdx + 1]; setHIdx(hIdx + 1); go(u, false); } };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0 }}>
      <Toolbar style={{ gap: 6 }}>
        <IconBtn onClick={back} disabled={hIdx === 0}><ArrowLeft size={17} /></IconBtn>
        <IconBtn onClick={forward} disabled={hIdx >= history.length - 1}><ArrowRight size={17} /></IconBtn>
        <IconBtn onClick={() => go(url, false)}><RotateCw size={15} /></IconBtn>
        <IconBtn onClick={() => go(HOME_URL)}><Home size={16} /></IconBtn>
        <form style={{ flex: 1 }} onSubmit={(e) => { e.preventDefault(); go(input); }}>
          <div style={{ position: 'relative' }}>
            {url.startsWith('https') ? <Lock size={13} style={addrIcon} /> : <Globe size={13} style={addrIcon} />}
            <input className="os-input" style={{ paddingLeft: 32, height: 34, borderRadius: 999, fontSize: 12.5 }}
              value={input} onChange={(e) => setInput(e.target.value)} placeholder="Search or enter address" />
          </div>
        </form>
        <IconBtn onClick={() => setTab('history')} title="History" active={tab === 'history'}><History size={16} /></IconBtn>
        <IconBtn onClick={() => setTab('downloads')} title="Downloads" active={tab === 'downloads'}>
          <span style={{ position: 'relative' }}>
            <Download size={16} />
            {BROWSER_DOWNLOADS.some((d) => d.suspicious) && <span style={{ position: 'absolute', top: -4, right: -4, width: 7, height: 7, borderRadius: 999, background: 'var(--danger)' }} />}
          </span>
        </IconBtn>
      </Toolbar>

      <div className="scrolly" style={{ flex: 1, minHeight: 0, background: 'var(--window-bg)' }}>
        {tab === 'history' ? (
          <HistoryView items={BROWSER_HISTORY} onOpen={(u) => go(u)} />
        ) : tab === 'downloads' ? (
          <DownloadsView items={BROWSER_DOWNLOADS} onOpen={(u) => go(u)} />
        ) : url === HOME_URL ? (
          <StartPage onGo={go} />
        ) : (
          <PageView view={view} />
        )}
      </div>
    </div>
  );
}

const addrIcon = { position: 'absolute', left: 12, top: 11, color: 'var(--text-tertiary)' };

function IconBtn({ children, onClick, disabled, title, active }) {
  return (
    <button onClick={onClick} disabled={disabled} title={title} className="os-btn ghost"
      style={{ padding: 6, opacity: disabled ? 0.4 : 1, background: active ? 'var(--active)' : 'transparent' }}>
      {children}
    </button>
  );
}

function PageView({ view }) {
  if (!view) return null;
  if (view.kind === 'download') {
    return (
      <div style={{ padding: 30, maxWidth: 620, margin: '0 auto' }}>
        {view.suspicious && (
          <Banner variant="error" icon={<ShieldAlert size={16} />}>
            <strong>SmartScreen blocked this download.</strong> <span className="mono">{view.title}</span> from
            {' '}<span className="mono">{hostOf(view.url)}</span> is reported as malicious.
          </Banner>
        )}
        <div style={{ padding: 20, border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', background: 'var(--surface-1)' }}>
          <div style={{ fontSize: 13, fontWeight: 600 }}>{view.title}</div>
          <div className="mono" style={{ fontSize: 11.5, color: 'var(--text-tertiary)', marginTop: 4, wordBreak: 'break-all' }}>{view.url}</div>
          <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 12, lineHeight: 1.5 }}>
            Downloading files is disabled in this environment.
          </div>
        </div>
      </div>
    );
  }
  if (view.kind === 'html') {
    return (
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 14px', background: view.suspicious ? 'var(--danger-bg)' : 'var(--surface-1)', borderBottom: '1px solid var(--border)', fontSize: 12 }}>
          <ShieldAlert size={15} color={view.suspicious ? 'var(--danger)' : 'var(--text-tertiary)'} />
          <span>Sandboxed viewer — scripts are <strong>disabled</strong>. This content is inert.</span>
        </div>
        <iframe title={view.title} sandbox="" srcDoc={view.html}
          style={{ width: '100%', height: 'calc(100% - 40px)', minHeight: 480, border: 'none', background: '#fff' }} />
      </div>
    );
  }
  if (view.kind === 'generic') {
    return (
      <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-tertiary)' }}>
        <Globe size={40} style={{ opacity: 0.5 }} />
        <div style={{ marginTop: 12, fontSize: 14, color: 'var(--text-secondary)' }}>{view.title}</div>
        <div style={{ fontSize: 12, marginTop: 6 }}>This external site isn't available in the training environment.</div>
      </div>
    );
  }
  return <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-tertiary)' }}>Page not found.</div>;
}

function StartPage({ onGo }) {
  const tiles = [
    { label: 'Intranet', url: 'https://intranet.securityimpossible.local', color: '#3ea6ff' },
    { label: 'Webmail', url: 'https://mail.securityimpossible.local', color: '#5ed3a0' },
    { label: 'Support', url: 'https://securityimpossible.local/support', color: '#c489f0' },
    { label: 'Search', url: 'https://www.google.com', color: '#ffb020' },
  ];
  return (
    <div style={{ padding: '48px 30px', maxWidth: 720, margin: '0 auto' }}>
      <div style={{ textAlign: 'center', marginBottom: 28 }}>
        <Globe size={44} color="var(--accent)" />
        <h1 style={{ fontSize: 24, fontWeight: 300, marginTop: 12 }}>{BRANDING.productShort} Browser</h1>
      </div>
      <form onSubmit={(e) => { e.preventDefault(); onGo(e.target.q.value); }} style={{ marginBottom: 30 }}>
        <div style={{ position: 'relative', maxWidth: 520, margin: '0 auto' }}>
          <Search size={17} style={{ position: 'absolute', left: 16, top: 13, color: 'var(--text-tertiary)' }} />
          <input name="q" className="os-input" style={{ paddingLeft: 44, height: 44, borderRadius: 999, fontSize: 14 }} placeholder="Search the web or type a URL" />
        </div>
      </form>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {tiles.map((t) => (
          <button key={t.url} onClick={() => onGo(t.url)} style={{ padding: '18px 10px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 40, height: 40, borderRadius: '50%', background: t.color, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700 }}>{t.label[0]}</div>
            <span style={{ fontSize: 12 }}>{t.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function HistoryView({ items = [], onOpen }) {
  const sorted = [...items].sort((a, b) => b.ts - a.ts);
  return (
    <div style={{ padding: 16, maxWidth: 760, margin: '0 auto' }}>
      <h3 style={{ fontSize: 15, margin: '4px 0 14px' }}>History</h3>
      {sorted.length === 0 && <div style={{ color: 'var(--text-tertiary)', fontSize: 13 }}>No browsing history.</div>}
      {sorted.map((h, i) => (
        <button key={i} onClick={() => onOpen(h.url)} className="list-row" style={{ width: '100%', border: 'none', borderBottom: '1px solid var(--border)', borderRadius: 0 }}>
          {h.suspicious ? <ShieldAlert size={15} color="var(--danger)" /> : <Globe size={15} color="var(--text-tertiary)" />}
          <div style={{ flex: 1, minWidth: 0, textAlign: 'left' }}>
            <div style={{ fontSize: 12.5, color: h.suspicious ? 'var(--danger)' : 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{h.title}</div>
            <div className="mono" style={{ fontSize: 11, color: 'var(--text-tertiary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{h.url}</div>
          </div>
          <span style={{ fontSize: 11, color: 'var(--text-tertiary)', flexShrink: 0 }}>{formatFriendly(h.ts)}</span>
        </button>
      ))}
    </div>
  );
}

function DownloadsView({ items = [], onOpen }) {
  const sorted = [...items].sort((a, b) => b.ts - a.ts);
  return (
    <div style={{ padding: 16, maxWidth: 760, margin: '0 auto' }}>
      <h3 style={{ fontSize: 15, margin: '4px 0 14px' }}>Downloads</h3>
      {sorted.length === 0 && <div style={{ color: 'var(--text-tertiary)', fontSize: 13 }}>No downloads.</div>}
      {sorted.map((d, i) => (
        <div key={i} className="list-row" style={{ border: '1px solid var(--border)', marginBottom: 8, background: d.suspicious ? 'var(--danger-bg)' : 'var(--surface-1)' }}>
          {d.suspicious ? <ShieldAlert size={17} color="var(--danger)" /> : <Download size={17} color="var(--text-secondary)" />}
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: d.suspicious ? 'var(--danger)' : 'var(--text-primary)' }}>{d.name} {d.suspicious && '⚠'}</div>
            <button onClick={() => onOpen(d.url)} className="mono" style={{ fontSize: 11, color: 'var(--accent)', background: 'none', border: 'none', padding: 0, textAlign: 'left', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '100%', display: 'block' }}>{d.url}</button>
          </div>
          <span style={{ fontSize: 11, color: 'var(--text-tertiary)', flexShrink: 0 }}>{formatBytes(d.size)} · {formatFriendly(d.ts)}</span>
        </div>
      ))}
    </div>
  );
}

function hostOf(u) {
  try { return new URL(u).host; } catch { return u; }
}
