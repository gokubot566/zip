import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Activity, Cpu, Rocket, AlertTriangle, X, ChevronDown, Clock } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { formatBytes } from '../core/utils.js';
import { Tabs, Banner, Empty } from './kit.jsx';
import { confirmDialog } from '../shell/ui.js';

// Deterministic-ish jitter driven by a tick counter (Math.random avoided so
// the numbers are stable enough to read but still "live").
function jitter(base, tick, pid, amp) {
  const n = Math.sin(tick * 0.9 + pid) * 0.5 + Math.sin(tick * 0.37 + pid * 2) * 0.5;
  return Math.max(0, base + n * amp);
}

export default function TaskManager({ args }) {
  const { state, killProcess, toggleStartup, recordActivity, notify } = useOS();
  const PROCESSES = state.data.processes ?? [];
  const STARTUP_ITEMS = state.data.startupItems ?? [];
  const SCHEDULED_TASKS = state.data.scheduledTasks ?? [];
  const [tab, setTab] = useState(args?.tab ?? 'processes');
  const [tick, setTick] = useState(0);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 1500);
    return () => clearInterval(t);
  }, []);

  const killed = state.activity.killedProcesses;
  const procs = useMemo(() => {
    return PROCESSES.filter((p) => !killed.includes(p.pid)).map((p) => ({
      ...p,
      cpu: p.suspicious ? jitter(p.baseCpu, tick, p.pid, 6) : jitter(p.baseCpu, tick, p.pid, p.baseCpu * 0.4 + 0.3),
    }));
  }, [tick, killed, PROCESSES]);

  const totalCpu = Math.min(100, procs.reduce((s, p) => s + p.cpu, 0));
  const totalMem = procs.reduce((s, p) => s + p.mem, 0);

  const endTask = async (p) => {
    const ok = await confirmDialog(
      `End "${p.name}" (PID ${p.pid})?\n\nUnsaved data will be lost. ${p.suspicious ? 'This looks like a malicious process — ending it is a valid containment step.' : ''}`,
      { title: 'Task Manager', confirmLabel: 'End task', danger: true },
    );
    if (!ok) return;
    killProcess(p.pid);
    if (p.suspicious) {
      notify({ title: 'Task Manager', body: `${p.name} terminated. If persistence remains, it may respawn on reboot — remove autoruns too.`, variant: 'success', appId: 'taskmgr' });
    }
  };

  const selectProc = (p) => { setSelected(p.pid); recordActivity(`proc:${p.pid}`); };

  const tabs = [
    { id: 'processes', label: 'Processes', icon: <Activity size={15} />, badge: procs.some((p) => p.suspicious) ? procs.filter((p) => p.suspicious).length : null },
    { id: 'performance', label: 'Performance', icon: <Cpu size={15} /> },
    { id: 'startup', label: 'Startup & Tasks', icon: <Rocket size={15} />, badge: STARTUP_ITEMS.filter((s) => s.suspicious && !state.activity.disabledStartup.includes(s.id)).length || null },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0 }}>
      <Tabs tabs={tabs} active={tab} onChange={setTab} />
      <div className="scrolly" style={{ flex: 1, minHeight: 0 }}>
        {tab === 'processes' && (
          procs.length === 0
            ? <Empty icon={<Activity size={38} />} title="No processes" sub="No process data is available." />
            : <ProcessTab procs={procs} totalCpu={totalCpu} totalMem={totalMem} selected={selected} onSelect={selectProc} onEnd={endTask} />
        )}
        {tab === 'performance' && <PerformanceTab tick={tick} totalCpu={totalCpu} totalMem={totalMem} malwareGone={!procs.some((p) => p.suspicious)} />}
        {tab === 'startup' && (
          <StartupTab
            startupItems={STARTUP_ITEMS}
            scheduledTasks={SCHEDULED_TASKS}
            disabled={state.activity.disabledStartup}
            onToggle={toggleStartup}
            onInspect={recordActivity}
          />
        )}
      </div>
    </div>
  );
}

function ProcessTab({ procs, totalCpu, totalMem, selected, onSelect, onEnd }) {
  const sorted = [...procs].sort((a, b) => b.cpu - a.cpu);
  const sel = procs.find((p) => p.pid === selected);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {procs.some((p) => p.suspicious) && (
        <div style={{ padding: '10px 12px 0' }}>
          <Banner variant="warning" icon={<AlertTriangle size={15} />}>
            One or more processes are running from unusual locations with elevated CPU. Select a row to inspect it, then <strong>End task</strong> to contain it.
          </Banner>
        </div>
      )}
      <div style={{ display: 'flex', gap: 10, padding: '4px 14px 8px', fontSize: 11.5, color: 'var(--text-tertiary)' }}>
        <span>CPU total: <strong style={{ color: totalCpu > 50 ? 'var(--danger)' : 'var(--text-secondary)' }}>{totalCpu.toFixed(0)}%</strong></span>
        <span>Memory: <strong style={{ color: 'var(--text-secondary)' }}>{formatBytes(totalMem * 1024)}</strong></span>
      </div>
      <div className="scrolly" style={{ flex: 1 }}>
        <table className="data">
          <thead>
            <tr><th style={{ width: '38%' }}>Name</th><th>PID</th><th>User</th><th style={{ textAlign: 'right' }}>CPU</th><th style={{ textAlign: 'right' }}>Memory</th></tr>
          </thead>
          <tbody>
            {sorted.map((p) => (
              <tr key={p.pid} className={`${p.suspicious ? 'suspicious-row' : ''} ${selected === p.pid ? 'selected' : ''}`}
                onMouseDown={() => onSelect(p)} onDoubleClick={() => onEnd(p)} style={{ cursor: 'default' }}>
                <td style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  {p.suspicious && <AlertTriangle size={13} color="var(--danger)" />}
                  <span style={{ fontWeight: p.suspicious ? 600 : 400 }}>{p.name}</span>
                </td>
                <td className="mono">{p.pid}</td>
                <td style={{ color: 'var(--text-tertiary)' }}>{p.user}</td>
                <td style={{ textAlign: 'right', color: p.cpu > 12 ? 'var(--danger)' : 'var(--text-secondary)' }}>{p.cpu.toFixed(1)}%</td>
                <td style={{ textAlign: 'right', color: 'var(--text-tertiary)' }}>{formatBytes(p.mem * 1024)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* detail + end task footer */}
      <div style={{ borderTop: '1px solid var(--border)', background: 'var(--surface-1)', padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 12, minHeight: 58 }}>
        {sel ? (
          <>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12.5, fontWeight: 600 }}>{sel.name} <span className="muted" style={{ fontWeight: 400 }}>· {sel.desc}</span></div>
              <div className="mono" style={{ fontSize: 11, color: sel.suspicious ? 'var(--danger)' : 'var(--text-tertiary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {sel.cmdline || sel.path || '—'}{sel.parent ? `   (parent: ${sel.parent})` : ''}
              </div>
            </div>
            <button className="os-btn danger" onClick={() => onEnd(sel)} style={{ fontSize: 12 }}><X size={14} /> End task</button>
          </>
        ) : (
          <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>Select a process to see its command line and end it.</span>
        )}
      </div>
    </div>
  );
}

function PerformanceTab({ tick, totalCpu, totalMem, malwareGone }) {
  const cpuHist = useRef([]);
  const memHist = useRef([]);
  const memPct = Math.min(96, 42 + totalMem / 40000);
  useEffect(() => {
    cpuHist.current = [...cpuHist.current, totalCpu].slice(-50);
    memHist.current = [...memHist.current, memPct].slice(-50);
  }, [tick]); // eslint-disable-line

  return (
    <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 16 }}>
      {!malwareGone && (
        <Banner variant="warning" icon={<AlertTriangle size={15} />}>
          Sustained high CPU with an unfamiliar process at the top is a classic malware symptom. Compare against the Processes tab.
        </Banner>
      )}
      <Graph title="CPU" value={`${totalCpu.toFixed(0)}%`} data={cpuHist.current} color="var(--accent)" max={100} sub="Intel Core i7-11700 @ 2.50GHz" />
      <Graph title="Memory" value={`${memPct.toFixed(0)}%`} data={memHist.current} color="#c489f0" max={100} sub="16.0 GB DDR4" />
    </div>
  );
}

function Graph({ title, value, data, color, max, sub }) {
  const W = 100, H = 40;
  const pts = data.length > 1
    ? data.map((v, i) => `${(i / (data.length - 1)) * W},${H - (Math.min(v, max) / max) * H}`).join(' ')
    : `0,${H} ${W},${H}`;
  return (
    <div style={{ background: 'var(--surface-1)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: 14 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
        <span style={{ fontSize: 13, fontWeight: 600 }}>{title}</span>
        <span style={{ fontSize: 18, fontWeight: 300, color }}>{value}</span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ width: '100%', height: 90, background: 'var(--surface-solid)', borderRadius: 6 }}>
        <defs>
          <linearGradient id={`g-${title}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={color} stopOpacity="0.4" />
            <stop offset="1" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        <polygon points={`0,${H} ${pts} ${W},${H}`} fill={`url(#g-${title})`} />
        <polyline points={pts} fill="none" stroke={color} strokeWidth="1.2" vectorEffect="non-scaling-stroke" />
      </svg>
      <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 6 }}>{sub}</div>
    </div>
  );
}

function StartupTab({ startupItems, scheduledTasks, disabled, onToggle, onInspect }) {
  return (
    <div style={{ padding: 16 }}>
      <Banner variant="info" icon={<Rocket size={15} />}>
        Programs and scheduled tasks that launch automatically. Malware commonly adds itself here for <strong>persistence</strong> so it survives reboots. Disable anything unsigned or pointing into a Temp folder.
      </Banner>

      <SectionLabel>Startup apps</SectionLabel>
      <table className="data">
        <thead><tr><th style={{ width: '30%' }}>Name</th><th>Publisher</th><th>Location</th><th>Impact</th><th style={{ textAlign: 'right' }}>Status</th></tr></thead>
        <tbody>
          {startupItems.map((s) => {
            const isOff = disabled.includes(s.id);
            return (
              <tr key={s.id} className={s.suspicious ? 'suspicious-row' : ''} onMouseDown={() => onInspect(`startup:${s.id}`)}>
                <td style={{ display: 'flex', alignItems: 'center', gap: 8 }}>{s.suspicious && <AlertTriangle size={13} color="var(--danger)" />}{s.name}</td>
                <td style={{ color: s.publisher.includes('Unknown') ? 'var(--danger)' : 'var(--text-tertiary)' }}>{s.publisher}</td>
                <td className="mono" style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{s.location}</td>
                <td><span className={`badge sev-${s.impact === 'High' ? 'severe' : s.impact === 'Medium' ? 'medium' : 'low'}`}>{s.impact}</span></td>
                <td style={{ textAlign: 'right' }}>
                  <button className={`os-btn ${isOff ? '' : 'ghost'}`} style={{ fontSize: 11.5, padding: '4px 10px' }} onClick={() => onToggle(s.id)}>
                    {isOff ? 'Disabled' : 'Enabled'}
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <SectionLabel style={{ marginTop: 20 }}><Clock size={13} style={{ verticalAlign: -2 }} /> Scheduled tasks</SectionLabel>
      <table className="data">
        <thead><tr><th style={{ width: '26%' }}>Name</th><th>Trigger</th><th>Action</th><th>Author</th></tr></thead>
        <tbody>
          {scheduledTasks.map((t) => (
            <tr key={t.id} className={t.suspicious ? 'suspicious-row' : ''} onMouseDown={() => onInspect(`task:${t.id}`)}>
              <td style={{ display: 'flex', alignItems: 'center', gap: 8 }}>{t.suspicious && <AlertTriangle size={13} color="var(--danger)" />}{t.name}</td>
              <td style={{ color: 'var(--text-tertiary)' }}>{t.trigger}</td>
              <td className="mono" style={{ fontSize: 11, color: t.suspicious ? 'var(--danger)' : 'var(--text-tertiary)', maxWidth: 240, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.action}</td>
              <td style={{ color: t.author.includes('unsigned') ? 'var(--danger)' : 'var(--text-tertiary)' }}>{t.author}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function SectionLabel({ children, style }) {
  return <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)', margin: '4px 2px 8px', ...style }}>{children}</div>;
}
