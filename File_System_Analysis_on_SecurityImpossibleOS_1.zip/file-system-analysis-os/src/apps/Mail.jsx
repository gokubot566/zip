import React, { useState, useMemo } from 'react';
import { Inbox, Send, Paperclip, AlertTriangle, ShieldAlert, Search, Star, Reply } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { formatFriendly } from '../core/utils.js';
import { Empty, Banner } from './kit.jsx';
import { confirmDialog } from '../shell/ui.js';

const FOLDERS = [
  { id: 'inbox', label: 'Inbox', icon: Inbox },
  { id: 'sent', label: 'Sent Items', icon: Send },
];

export default function Mail({ args }) {
  const { state, recordActivity, recordOpenFile, notify, openApp } = useOS();
  const MAIL = state.data.mail ?? [];
  const [folder, setFolder] = useState('inbox');
  const [selectedId, setSelectedId] = useState(args?.emailId ?? null);
  const [query, setQuery] = useState('');
  const [read, setRead] = useState(() => new Set(MAIL.filter((e) => e.read).map((e) => e.id)));
  const [revealedHeader, setRevealedHeader] = useState(false);

  const messages = useMemo(() => {
    const q = query.trim().toLowerCase();
    return MAIL.filter((e) => e.folder === folder)
      .filter((e) => !q || e.subject.toLowerCase().includes(q) || e.from.toLowerCase().includes(q))
      .sort((a, b) => b.date - a.date);
  }, [folder, query, MAIL]);

  const selected = MAIL.find((e) => e.id === selectedId) || null;
  const unread = MAIL.filter((e) => e.folder === 'inbox' && !read.has(e.id)).length;

  const openEmail = (email) => {
    setSelectedId(email.id);
    setRevealedHeader(false);
    setRead((s) => new Set(s).add(email.id));
    recordActivity(`mail:${email.id}`);
  };

  const analyzeHeader = () => {
    setRevealedHeader(true);
    recordActivity(`mail:header:${selected.id}`);
  };

  const openAttachment = async (att) => {
    const ok = await confirmDialog(
      `Open "${att.name}"?\n\nThis file came from an external email. Opening files from untrusted senders can be dangerous. In this environment it opens in a sandboxed viewer.`,
      { title: 'Security Warning', variant: 'warning', confirmLabel: 'Open in sandbox', danger: false },
    );
    if (!ok) return;
    if (att.savePath) recordOpenFile(att.savePath);
    openApp('browser', { openPath: att.savePath });
    notify({ title: 'Sandbox', body: `${att.name} opened in an isolated viewer. No code was executed.`, variant: 'info', appId: 'browser' });
  };

  return (
    <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
      {/* folders */}
      <div style={{ width: 180, flexShrink: 0, borderRight: '1px solid var(--border)', background: 'var(--surface-0)', padding: 10 }}>
        <div style={{ fontSize: 12.5, fontWeight: 700, padding: '4px 8px 10px', overflow: 'hidden', textOverflow: 'ellipsis' }}>{state.profile.email}</div>
        {FOLDERS.map((f) => (
          <button key={f.id} onClick={() => { setFolder(f.id); setSelectedId(null); }} className={`list-row ${folder === f.id ? 'selected' : ''}`} style={{ width: '100%', border: 'none' }}>
            <f.icon size={16} />
            <span style={{ flex: 1, textAlign: 'left' }}>{f.label}</span>
            {f.id === 'inbox' && unread > 0 && <span className="badge sev-medium">{unread}</span>}
          </button>
        ))}
      </div>

      {/* list */}
      <div style={{ width: 300, flexShrink: 0, borderRight: '1px solid var(--border)', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <div style={{ padding: 8, borderBottom: '1px solid var(--border)', position: 'relative' }}>
          <Search size={14} style={{ position: 'absolute', left: 17, top: 17, color: 'var(--text-tertiary)' }} />
          <input className="os-input" style={{ paddingLeft: 30, height: 32, fontSize: 12 }} placeholder="Search mail" value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <div className="scrolly" style={{ flex: 1 }}>
          {messages.map((m) => {
            const isUnread = !read.has(m.id);
            return (
              <button
                key={m.id}
                onClick={() => openEmail(m)}
                style={{
                  display: 'block', width: '100%', textAlign: 'left', padding: '10px 12px',
                  border: 'none', borderBottom: '1px solid var(--border)', borderLeft: `3px solid ${selectedId === m.id ? 'var(--accent)' : 'transparent'}`,
                  background: selectedId === m.id ? 'var(--selected)' : 'transparent',
                }}
                onMouseEnter={(e) => { if (selectedId !== m.id) e.currentTarget.style.background = 'var(--hover)'; }}
                onMouseLeave={(e) => { if (selectedId !== m.id) e.currentTarget.style.background = 'transparent'; }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, marginBottom: 3 }}>
                  <span style={{ fontSize: 12.5, fontWeight: isUnread ? 700 : 500, color: m.suspicious ? 'var(--danger)' : 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {folder === 'sent' ? `To: ${m.to}` : m.from}
                  </span>
                  <span style={{ fontSize: 10.5, color: 'var(--text-tertiary)', flexShrink: 0 }}>{formatFriendly(m.date)}</span>
                </div>
                <div style={{ fontSize: 12, fontWeight: isUnread ? 600 : 400, color: 'var(--text-secondary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'flex', alignItems: 'center', gap: 5 }}>
                  {m.suspicious && <ShieldAlert size={13} color="var(--danger)" style={{ flexShrink: 0 }} />}
                  {m.attachments?.length > 0 && <Paperclip size={12} style={{ flexShrink: 0 }} />}
                  {m.subject}
                </div>
              </button>
            );
          })}
          {messages.length === 0 && <Empty icon={<Inbox size={32} />} title="No messages" />}
        </div>
      </div>

      {/* reading pane */}
      <div className="scrolly" style={{ flex: 1, minWidth: 0 }}>
        {!selected ? (
          <Empty icon={<Inbox size={40} />} title="Select a message" sub="Choose a message from the list to read it." />
        ) : (
          <div style={{ padding: 20 }}>
            {selected.suspicious && (
              <Banner variant="error" icon={<AlertTriangle size={16} />}>
                <strong>Caution:</strong> this message shows classic phishing traits — urgency, a spoofed sender, and an executable-bearing attachment. Analyze it; don't act on it.
              </Banner>
            )}
            <h2 style={{ fontSize: 18, margin: '4px 0 14px', fontWeight: 600 }}>{selected.subject}</h2>

            <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', paddingBottom: 14, borderBottom: '1px solid var(--border)', marginBottom: 16 }}>
              <div style={{ width: 42, height: 42, borderRadius: '50%', flexShrink: 0, background: selected.suspicious ? 'var(--danger)' : 'linear-gradient(160deg, var(--accent), #6a49d8)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700 }}>
                {selected.from[0]}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13.5, fontWeight: 600 }}>{selected.from}</div>
                <div className="selectable" style={{ fontSize: 12, color: selected.suspicious ? 'var(--danger)' : 'var(--text-tertiary)' }}>
                  &lt;{selected.fromEmail}&gt;
                </div>
                <div style={{ fontSize: 11.5, color: 'var(--text-tertiary)', marginTop: 2 }}>to {selected.toEmail} · {formatFriendly(selected.date)}</div>
              </div>
              {selected.suspicious && (
                <button className="os-btn ghost" style={{ fontSize: 11.5 }} onClick={analyzeHeader}>Analyze header</button>
              )}
            </div>

            {revealedHeader && (
              <Banner variant="warning" icon={<AlertTriangle size={16} />}>
                {selected.headerAnalysis
                  ? <span dangerouslySetInnerHTML={{ __html: selected.headerAnalysis }} />
                  : <>The sender's address doesn't match its display name or the expected corporate domain — a common sign of a <strong>spoofed sender</strong>. Verify unexpected senders before acting.</>}
              </Banner>
            )}

            <div className="selectable" style={{ fontSize: 13.5, lineHeight: 1.65, color: 'var(--text-secondary)' }} dangerouslySetInnerHTML={{ __html: selected.body }} />

            {selected.attachments?.length > 0 && (
              <div style={{ marginTop: 20, paddingTop: 14, borderTop: '1px solid var(--border)' }}>
                <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 8, color: 'var(--text-secondary)' }}>
                  {selected.attachments.length} attachment{selected.attachments.length > 1 ? 's' : ''}
                </div>
                {selected.attachments.map((att) => (
                  <div key={att.name} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: 10, background: att.suspicious ? 'var(--danger-bg)' : 'var(--surface-2)', border: `1px solid ${att.suspicious ? 'var(--danger)' : 'var(--border)'}`, borderRadius: 'var(--radius-md)' }}>
                    <Paperclip size={18} color={att.suspicious ? 'var(--danger)' : 'var(--text-secondary)'} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 12.5, fontWeight: 600 }}>{att.name}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{(att.size / 1024).toFixed(0)} KB · {att.type.toUpperCase()}{att.suspicious ? ' · ⚠ flagged' : ''}</div>
                    </div>
                    <button className="os-btn" style={{ fontSize: 12 }} onClick={() => openAttachment(att)}>Open</button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
