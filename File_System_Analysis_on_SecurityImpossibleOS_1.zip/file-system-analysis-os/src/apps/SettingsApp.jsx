import React, { useState } from 'react';
import { Palette, Monitor, AppWindow, Info, RotateCcw, Check, Trash2 } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { WALLPAPERS, ACCENTS } from '../config/platform.js';
import { BRANDING, copyrightLine } from '../config/branding.jsx';
import { Banner } from './kit.jsx';
import { confirmDialog } from '../shell/ui.js';

const NAV = [
  { id: 'personalization', label: 'Personalization', icon: Palette },
  { id: 'apps', label: 'Apps', icon: AppWindow },
  { id: 'system', label: 'System', icon: Monitor },
  { id: 'about', label: 'About', icon: Info },
];

// Generic installed programs. A lab may add its own via data.installedApps.
const BASE_INSTALLED = [
  { name: `${BRANDING.productShort} Browser`, publisher: BRANDING.company, size: '284 MB', version: BRANDING.version },
  { name: 'SI Office Suite', publisher: BRANDING.company, size: '1.8 GB', version: '3.2' },
  { name: 'SI Connect', publisher: BRANDING.company, size: '146 MB', version: '4.2' },
  { name: '7-Zip', publisher: 'Igor Pavlov', size: '5 MB', version: '23.01' },
  { name: 'VLC media player', publisher: 'VideoLAN', size: '178 MB', version: '3.0.20' },
];

export default function SettingsApp({ args }) {
  const { state, setSetting, resetSession } = useOS();
  const [nav, setNav] = useState(args?.section ?? 'personalization');
  const installed = [...BASE_INSTALLED, ...(state.data.installedApps ?? [])];

  return (
    <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
      <div style={{ width: 200, flexShrink: 0, borderRight: '1px solid var(--border)', background: 'var(--surface-0)', padding: 10 }}>
        <div style={{ padding: '6px 8px 12px', fontSize: 13, fontWeight: 700 }}>Settings</div>
        {NAV.map((n) => (
          <button key={n.id} onClick={() => setNav(n.id)} className={`list-row ${nav === n.id ? 'selected' : ''}`} style={{ width: '100%', border: 'none' }}>
            <n.icon size={15} color={nav === n.id ? 'var(--accent)' : 'var(--text-secondary)'} /><span style={{ fontSize: 12.5 }}>{n.label}</span>
          </button>
        ))}
      </div>

      <div className="scrolly" style={{ flex: 1, padding: 22 }}>
        {nav === 'personalization' && <Personalization state={state} setSetting={setSetting} />}
        {nav === 'apps' && <Apps installed={installed} />}
        {nav === 'system' && <SystemSection state={state} setSetting={setSetting} />}
        {nav === 'about' && <About profile={state.profile} resetSession={resetSession} />}
      </div>
    </div>
  );
}

function Personalization({ state, setSetting }) {
  return (
    <div>
      <h2 style={{ fontSize: 18, marginTop: 0 }}>Personalization</h2>

      <SectionTitle>Background</SectionTitle>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))', gap: 10 }}>
        {WALLPAPERS.map((w) => (
          <button key={w.id} onClick={() => setSetting('wallpaperId', w.id)}
            style={{ padding: 0, border: `2px solid ${state.settings.wallpaperId === w.id ? 'var(--accent)' : 'transparent'}`, borderRadius: 'var(--radius-md)', overflow: 'hidden', position: 'relative' }}>
            <div style={{ height: 74, background: w.css }} />
            <div style={{ fontSize: 11, padding: '6px 8px', background: 'var(--surface-2)', textAlign: 'left' }}>{w.name}</div>
            {state.settings.wallpaperId === w.id && <div style={{ position: 'absolute', top: 6, right: 6, background: 'var(--accent)', borderRadius: '50%', width: 18, height: 18, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Check size={12} color="var(--accent-contrast)" /></div>}
          </button>
        ))}
      </div>

      <SectionTitle>Accent color</SectionTitle>
      <div style={{ display: 'flex', gap: 10 }}>
        {ACCENTS.map((a) => (
          <button key={a.id} onClick={() => setSetting('accentId', a.id)} title={a.name}
            style={{ width: 40, height: 40, borderRadius: '50%', background: a.color, border: `3px solid ${state.settings.accentId === a.id ? 'var(--text-primary)' : 'transparent'}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {state.settings.accentId === a.id && <Check size={16} color="#05264a" />}
          </button>
        ))}
      </div>

      <SectionTitle>Theme</SectionTitle>
      <div style={{ display: 'flex', gap: 10 }}>
        {['dark', 'light'].map((t) => (
          <button key={t} onClick={() => setSetting('theme', t)} className={`os-btn ${state.settings.theme === t ? 'primary' : ''}`} style={{ textTransform: 'capitalize', minWidth: 110, justifyContent: 'center' }}>{t}</button>
        ))}
      </div>
    </div>
  );
}

function Apps({ installed }) {
  return (
    <div>
      <h2 style={{ fontSize: 18, marginTop: 0 }}>Installed apps</h2>
      <Banner variant="info" icon={<AppWindow size={15} />}>Programs installed on this workstation. Look for anything unfamiliar or unsigned.</Banner>
      {installed.map((a) => (
        <div key={a.name} className="list-row" style={{ border: '1px solid var(--border)', marginBottom: 6, background: a.suspicious ? 'var(--danger-bg)' : 'transparent' }}>
          <div style={{ width: 34, height: 34, borderRadius: 8, background: 'var(--surface-3)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{a.name[0]}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: a.suspicious ? 'var(--danger)' : 'var(--text-primary)' }}>{a.name}{a.suspicious && ' ⚠'}</div>
            <div style={{ fontSize: 11, color: a.publisher.includes('Unknown') ? 'var(--danger)' : 'var(--text-tertiary)' }}>{a.publisher} · v{a.version}</div>
          </div>
          <span style={{ fontSize: 11.5, color: 'var(--text-tertiary)' }}>{a.size}</span>
        </div>
      ))}
    </div>
  );
}

function SystemSection({ state, setSetting }) {
  return (
    <div>
      <h2 style={{ fontSize: 18, marginTop: 0 }}>System</h2>
      <SectionTitle>File Explorer</SectionTitle>
      <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13 }}>
        <input type="checkbox" checked={state.settings.showHidden} onChange={(e) => setSetting('showHidden', e.target.checked)} style={{ accentColor: 'var(--accent)', width: 16, height: 16 }} />
        Show hidden files and folders
      </label>
      <div style={{ fontSize: 11.5, color: 'var(--text-tertiary)', marginTop: 6 }}>Reveals hidden and system files across File Explorer.</div>
    </div>
  );
}

function About({ profile, resetSession }) {
  const reset = async () => {
    if (await confirmDialog('Reset this workspace to its initial state? Saved progress will be cleared.', { danger: true, confirmLabel: 'Reset' })) resetSession();
  };
  return (
    <div>
      <h2 style={{ fontSize: 18, marginTop: 0 }}>About</h2>
      <table style={{ fontSize: 12.5, lineHeight: 1.7, marginBottom: 20 }}>
        <tbody>
          <tr><td style={{ color: 'var(--text-tertiary)', paddingRight: 16 }}>Product</td><td>{BRANDING.product}</td></tr>
          <tr><td style={{ color: 'var(--text-tertiary)' }}>Edition</td><td>{BRANDING.edition}</td></tr>
          <tr><td style={{ color: 'var(--text-tertiary)' }}>Version</td><td>{BRANDING.version} (Build {BRANDING.build})</td></tr>
          <tr><td style={{ color: 'var(--text-tertiary)' }}>Publisher</td><td>{BRANDING.company}</td></tr>
          <tr><td style={{ color: 'var(--text-tertiary)' }}>Device name</td><td>{profile.hostname}</td></tr>
          <tr><td style={{ color: 'var(--text-tertiary)' }}>User</td><td>{profile.name}</td></tr>
        </tbody>
      </table>
      <p style={{ fontSize: 11.5, color: 'var(--text-tertiary)', marginBottom: 20 }}>{copyrightLine()}</p>

      <SectionTitle>Reset</SectionTitle>
      <Banner variant="warning" icon={<RotateCcw size={15} />}>Resetting restores the initial state and erases saved progress on this device.</Banner>
      <button className="os-btn danger" onClick={reset}><Trash2 size={15} /> Reset workspace & clear progress</button>
    </div>
  );
}

function SectionTitle({ children }) {
  return <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text-secondary)', margin: '20px 0 10px' }}>{children}</div>;
}
