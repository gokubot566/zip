import React, { useState } from 'react';
import { Cpu, Network, Database, Info } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { BRANDING } from '../config/branding.jsx';
import { Banner, Empty } from './kit.jsx';

const NAV = [
  { id: 'summary', label: 'System Summary', icon: Info },
  { id: 'network', label: 'Network', icon: Network },
  { id: 'registry', label: 'Registry (Run keys)', icon: Database },
];

export default function SystemInfo() {
  const { state, recordActivity } = useOS();
  const [nav, setNav] = useState('summary');
  const profile = state.profile;
  const network = state.data.network ?? {};
  const registry = state.data.registry ?? [];

  return (
    <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
      <div style={{ width: 200, flexShrink: 0, borderRight: '1px solid var(--border)', background: 'var(--surface-0)', padding: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 8px 12px' }}>
          <Cpu size={18} color="var(--accent)" /><span style={{ fontSize: 13, fontWeight: 700 }}>System Information</span>
        </div>
        {NAV.map((n) => (
          <button key={n.id} onClick={() => setNav(n.id)} className={`list-row ${nav === n.id ? 'selected' : ''}`} style={{ width: '100%', border: 'none' }}>
            <n.icon size={15} color={nav === n.id ? 'var(--accent)' : 'var(--text-secondary)'} /><span style={{ fontSize: 12.5 }}>{n.label}</span>
          </button>
        ))}
      </div>
      <div className="scrolly" style={{ flex: 1, padding: 20 }}>
        {nav === 'summary' && <Summary profile={profile} network={network} />}
        {nav === 'network' && <NetworkView network={network} isolated={state.activity.networkIsolated} killed={state.activity.killedProcesses} onView={() => recordActivity('net:view')} />}
        {nav === 'registry' && <RegistryView registry={registry} onView={() => recordActivity('reg:view')} />}
      </div>
    </div>
  );
}

function Row({ k, v, danger }) {
  return (
    <tr>
      <td style={{ color: 'var(--text-tertiary)', padding: '5px 12px 5px 0', verticalAlign: 'top', width: 200 }}>{k}</td>
      <td className="selectable" style={{ padding: '5px 0', color: danger ? 'var(--danger)' : 'var(--text-primary)' }}>{v}</td>
    </tr>
  );
}

function Summary({ profile, network }) {
  return (
    <div>
      <h2 style={{ fontSize: 17, marginTop: 0 }}>System Summary</h2>
      <table style={{ fontSize: 12.5, lineHeight: 1.5 }}>
        <tbody>
          <Row k="OS Name" v={BRANDING.product} />
          <Row k="Version" v={`${BRANDING.version} (Build ${BRANDING.build})`} />
          <Row k="System Type" v="x64-based PC" />
          <Row k="Host Name" v={profile.hostname} />
          <Row k="Domain" v={network.domain ?? profile.domain} />
          <Row k="Registered User" v={`${profile.name} (${profile.role})`} />
          <Row k="Processor" v="Intel(R) Core(TM) i7-11700 @ 2.50GHz, 8 Cores" />
          <Row k="Installed RAM" v="16.0 GB" />
          <Row k="BIOS Mode" v="UEFI" />
          <Row k="Boot Device" v="\\Device\\HarddiskVolume1" />
        </tbody>
      </table>
    </div>
  );
}

function NetworkView({ network, isolated, killed, onView }) {
  React.useEffect(() => { onView(); }, []); // eslint-disable-line
  const conns = (network.connections ?? []).filter((c) => !(c.suspicious && killed.includes(c.pid)));
  const flagged = conns.find((c) => c.suspicious);
  if (!network.ipv4) return <Empty icon={<Network size={38} />} title="No network information" sub="No adapter data is available." />;
  return (
    <div>
      <h2 style={{ fontSize: 17, marginTop: 0 }}>Network</h2>
      {isolated && <Banner variant="success" icon={<Network size={15} />}>Host is isolated. Live connections below reflect the last known state before isolation.</Banner>}
      <table style={{ fontSize: 12.5, lineHeight: 1.5, marginBottom: 18 }}>
        <tbody>
          <Row k="Adapter" v={network.adapter} />
          <Row k="IPv4 Address" v={network.ipv4} />
          <Row k="Subnet Mask" v={network.subnet} />
          <Row k="Default Gateway" v={network.gateway} />
          <Row k="DNS Servers" v={(network.dns ?? []).join(', ')} />
          <Row k="MAC Address" v={network.mac} />
          <Row k="DHCP Enabled" v={network.dhcp ? 'Yes' : 'No'} />
        </tbody>
      </table>

      <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>Active connections</div>
      <table className="data">
        <thead><tr><th>Proto</th><th>Local</th><th>Remote</th><th>State</th><th>PID</th><th>Process</th></tr></thead>
        <tbody>
          {conns.map((c, i) => (
            <tr key={i} className={c.suspicious ? 'suspicious-row' : ''}>
              <td>{c.proto}</td><td className="mono">{c.local}</td><td className="mono">{c.remote}</td>
              <td>{c.state}</td><td className="mono">{c.pid}</td>
              <td style={{ color: c.suspicious ? 'var(--danger)' : 'var(--text-tertiary)' }}>{c.process}{c.suspicious && ' ⚠'}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {flagged && (
        <div style={{ fontSize: 11.5, color: 'var(--text-tertiary)', marginTop: 8 }}>
          The connection to <span className="mono danger-text">{flagged.remote}</span> from PID {flagged.pid} is to an unrecognised external host.
        </div>
      )}
    </div>
  );
}

function RegistryView({ registry, onView }) {
  React.useEffect(() => { onView(); }, []); // eslint-disable-line
  return (
    <div>
      <h2 style={{ fontSize: 17, marginTop: 0 }}>Registry — auto-run keys</h2>
      <Banner variant="info" icon={<Database size={15} />}>
        A simulated view of the <span className="mono">Run</span> keys — where programs register to start automatically. Malware frequently adds an entry here.
      </Banner>
      {registry.length === 0 && <div style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>No registry data available.</div>}
      <table className="data">
        <thead><tr><th style={{ width: '34%' }}>Key</th><th>Value</th><th>Data</th></tr></thead>
        <tbody>
          {registry.map((r, i) => (
            <tr key={i} className={r.suspicious ? 'suspicious-row' : ''}>
              <td className="mono" style={{ fontSize: 11 }}>{r.key}</td>
              <td style={{ color: r.suspicious ? 'var(--danger)' : 'var(--text-primary)', fontWeight: r.suspicious ? 600 : 400 }}>{r.value}{r.suspicious && ' ⚠'}</td>
              <td className="mono" style={{ fontSize: 11, color: 'var(--text-tertiary)', wordBreak: 'break-all' }}>{r.data}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
