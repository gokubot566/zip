import React, { useMemo, useState } from 'react';
import { ScrollText, Search, AlertTriangle, Info, XCircle, ShieldAlert, Filter } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { formatDateTime } from '../core/utils.js';
import { Toolbar, Banner } from './kit.jsx';

const CATEGORIES = ['All', 'Security', 'System', 'Application'];
const LEVELS = ['All', 'Error', 'Warning', 'Information'];

const LEVEL_ICON = {
  Error: <XCircle size={14} color="var(--danger)" />,
  Warning: <AlertTriangle size={14} color="var(--warning)" />,
  Information: <Info size={14} color="var(--info)" />,
};

export default function EventViewer() {
  const { state, recordActivity } = useOS();
  const EVENTS = state.data.events ?? [];
  const [cat, setCat] = useState('All');
  const [level, setLevel] = useState('All');
  const [query, setQuery] = useState('');
  const [suspiciousOnly, setSuspiciousOnly] = useState(false);
  const [selected, setSelected] = useState(null);

  const events = useMemo(() => {
    const q = query.trim().toLowerCase();
    return [...EVENTS]
      .filter((e) => cat === 'All' || e.category === cat)
      .filter((e) => level === 'All' || e.level === level)
      .filter((e) => !suspiciousOnly || e.suspicious)
      .filter((e) => !q || e.message.toLowerCase().includes(q) || e.source.toLowerCase().includes(q) || String(e.eventId).includes(q))
      .sort((a, b) => b.ts - a.ts);
  }, [cat, level, query, suspiciousOnly, EVENTS]);

  const sel = events.find((e) => e.id === selected) || null;
  const suspiciousCount = EVENTS.filter((e) => e.suspicious).length;

  // Inspecting an event records generic activity; the lab derives meaning.
  const select = (e) => { setSelected(e.id); recordActivity(`event:${e.id}`); };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0 }}>
      <Toolbar>
        <ScrollText size={16} color="var(--accent)" />
        <span style={{ fontSize: 13, fontWeight: 600 }}>Event Viewer</span>
        <div style={{ position: 'relative', marginLeft: 8, width: 200 }}>
          <Search size={14} style={{ position: 'absolute', left: 9, top: 9, color: 'var(--text-tertiary)' }} />
          <input className="os-input" style={{ paddingLeft: 30, height: 32, fontSize: 12 }} placeholder="Filter events" value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <button className={`os-btn ${suspiciousOnly ? 'primary' : 'ghost'}`} style={{ fontSize: 12, marginLeft: 'auto' }} onClick={() => setSuspiciousOnly((v) => !v)}>
          <Filter size={14} /> Flagged only ({suspiciousCount})
        </button>
      </Toolbar>

      <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
        {/* filters sidebar */}
        <div style={{ width: 150, flexShrink: 0, borderRight: '1px solid var(--border)', background: 'var(--surface-0)', padding: 10, fontSize: 12.5 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-tertiary)', margin: '2px 6px 6px' }}>LOG</div>
          {CATEGORIES.map((c) => (
            <button key={c} onClick={() => setCat(c)} className={`list-row ${cat === c ? 'selected' : ''}`} style={{ width: '100%', border: 'none', padding: '6px 8px' }}>
              {c}{c !== 'All' && <span style={{ marginLeft: 'auto', fontSize: 10.5, color: 'var(--text-tertiary)' }}>{EVENTS.filter((e) => e.category === c).length}</span>}
            </button>
          ))}
          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-tertiary)', margin: '14px 6px 6px' }}>LEVEL</div>
          {LEVELS.map((l) => (
            <button key={l} onClick={() => setLevel(l)} className={`list-row ${level === l ? 'selected' : ''}`} style={{ width: '100%', border: 'none', padding: '6px 8px' }}>
              {LEVEL_ICON[l] || <span style={{ width: 14 }} />}<span>{l}</span>
            </button>
          ))}
        </div>

        {/* list + detail */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          <div className="scrolly" style={{ flex: 1, minHeight: 0 }}>
            <table className="data">
              <thead><tr><th style={{ width: 30 }}></th><th style={{ width: 150 }}>Date & time</th><th style={{ width: 70 }}>Event ID</th><th>Source / message</th></tr></thead>
              <tbody>
                {events.map((e) => (
                  <tr key={e.id} className={`${e.suspicious ? 'suspicious-row' : ''} ${selected === e.id ? 'selected' : ''}`} onMouseDown={() => select(e)} style={{ cursor: 'default' }}>
                    <td style={{ textAlign: 'center' }}>{LEVEL_ICON[e.level]}</td>
                    <td style={{ whiteSpace: 'nowrap', color: 'var(--text-tertiary)' }}>{formatDateTime(e.ts)}</td>
                    <td className="mono">{e.eventId}</td>
                    <td>
                      <span style={{ color: 'var(--text-tertiary)', fontSize: 11 }}>{e.source}</span>
                      <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: e.suspicious ? 'var(--text-primary)' : 'var(--text-secondary)' }}>{e.message}</div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* detail pane */}
          <div style={{ height: sel ? 200 : 44, borderTop: '1px solid var(--border)', background: 'var(--surface-1)', overflow: 'auto', flexShrink: 0, transition: 'height 0.15s' }}>
            {sel ? (
              <div style={{ padding: 14 }} className="selectable">
                {sel.suspicious && (
                  <Banner variant={sel.level === 'Error' ? 'error' : 'warning'} icon={<ShieldAlert size={15} />}>
                    This event has been flagged for review.
                  </Banner>
                )}
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                  {LEVEL_ICON[sel.level]}
                  <strong style={{ fontSize: 13 }}>{sel.source}</strong>
                  <span className="chip" style={{ fontSize: 11 }}>Event {sel.eventId}</span>
                  <span className="chip" style={{ fontSize: 11 }}>{sel.category}</span>
                  <span style={{ marginLeft: 'auto', fontSize: 11.5, color: 'var(--text-tertiary)' }}>{formatDateTime(sel.ts)}</span>
                </div>
                <div style={{ fontSize: 12.5, color: 'var(--text-primary)', marginBottom: 8, lineHeight: 1.5 }}>{sel.message}</div>
                {sel.detail && (
                  <pre className="mono" style={{ fontSize: 11.5, color: 'var(--text-secondary)', background: 'var(--surface-solid)', padding: 10, borderRadius: 6, whiteSpace: 'pre-wrap', margin: 0 }}>{sel.detail}</pre>
                )}
              </div>
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', height: '100%', padding: '0 14px', fontSize: 12, color: 'var(--text-tertiary)' }}>
                Select an event to see the full details.{suspiciousCount > 0 ? ` ${suspiciousCount} events are flagged for review.` : ''}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
