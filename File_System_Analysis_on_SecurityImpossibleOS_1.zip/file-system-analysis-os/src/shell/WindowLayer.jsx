import React from 'react';
import { AnimatePresence } from 'framer-motion';
import { useOS } from '../core/OSContext.jsx';
import Window from './Window.jsx';
import { TASKBAR_HEIGHT } from '../config/platform.js';

// The layer spans the desktop but is click-through (pointerEvents:none);
// each Window re-enables pointer events on its own rectangle so clicks in
// empty space still reach the desktop (icons, context menu).
export default function WindowLayer() {
  const { state } = useOS();
  return (
    <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: TASKBAR_HEIGHT, pointerEvents: 'none' }}>
      <AnimatePresence>
        {state.windows.map((win) => (
          <Window key={win.id} win={win} />
        ))}
      </AnimatePresence>
    </div>
  );
}
