import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, Info, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { dialogStore, closeDialog } from './ui.js';

const ICONS = {
  info: <Info size={26} color="var(--info)" />,
  warning: <AlertTriangle size={26} color="var(--warning)" />,
  error: <ShieldAlert size={26} color="var(--danger)" />,
  success: <CheckCircle2 size={26} color="var(--success)" />,
};

export default function DialogHost() {
  const [dialog, setDialog] = useState(dialogStore.get());
  useEffect(() => dialogStore.subscribe(setDialog), []);

  useEffect(() => {
    if (!dialog) return;
    const onKey = (e) => {
      if (e.key === 'Escape') closeDialog(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [dialog]);

  return (
    <AnimatePresence>
      {dialog && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onMouseDown={() => closeDialog(false)}
          style={{
            position: 'fixed', inset: 0, zIndex: 100000,
            background: 'rgba(0,0,0,0.45)', backdropFilter: 'blur(2px)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
        >
          <motion.div
            initial={{ scale: 0.9, y: 10, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 320, damping: 26 }}
            onMouseDown={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 'min(440px, 92vw)',
              background: 'var(--surface-2)',
              border: '1px solid var(--border-strong)',
              borderRadius: 'var(--radius-lg)',
              boxShadow: 'var(--shadow-lg)',
              overflow: 'hidden',
            }}
          >
            <div style={{ padding: '20px 22px 12px', display: 'flex', gap: 14 }}>
              <div style={{ flexShrink: 0, marginTop: 2 }}>{ICONS[dialog.variant] ?? ICONS.info}</div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6 }}>{dialog.title}</div>
                {dialog.html ? (
                  <div className="selectable" style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.55 }}
                    dangerouslySetInnerHTML={{ __html: dialog.html }} />
                ) : (
                  <div style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.55, whiteSpace: 'pre-wrap' }}>
                    {dialog.message}
                  </div>
                )}
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, padding: '12px 18px', background: 'var(--surface-1)', borderTop: '1px solid var(--border)' }}>
              {dialog.buttons.map((b, i) => (
                <button
                  key={i}
                  autoFocus={i === dialog.buttons.length - 1}
                  className={`os-btn ${b.variant === 'primary' ? 'primary' : b.variant === 'danger' ? 'danger' : ''}`}
                  onClick={() => closeDialog(b.value)}
                >
                  {b.label}
                </button>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
