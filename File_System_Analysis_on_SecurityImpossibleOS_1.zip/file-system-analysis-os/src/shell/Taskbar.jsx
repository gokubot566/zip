import React from 'react';
import { motion } from 'framer-motion';
import { Search, Wifi, Volume2, ShieldAlert, ShieldCheck, Bell, ChevronUp, WifiOff } from 'lucide-react';
import { useOS, useClock } from '../core/OSContext.jsx';
import { getApp } from '../apps/registry.js';
import { DEFAULT_TASKBAR_PINS } from '../config/platform.js';
import { formatTime, formatDateShort } from '../core/utils.js';
import { openContextMenu } from './ui.js';

const PINNED = DEFAULT_TASKBAR_PINS.filter((id) => getApp(id));

export default function Taskbar({ onToggleStart, startOpen, onToggleNotifications, onToggleTray, trayOpen }) {
  const { state, openApp, toggleMinimize, closeWindow } = useOS();
  const now = useClock();

  const running = state.windows;
  const pinnedShown = new Set(PINNED);
  const extraRunning = running.filter((w) => !pinnedShown.has(w.appId)).map((w) => w.appId);
  const buttons = [...PINNED, ...Array.from(new Set(extraRunning))];

  const unread = state.notifications.filter((n) => !n.read).length;
  // Generic security indicator: any known threat not yet quarantined.
  const threats = state.data.threats ?? [];
  const threatsActive = threats.length > 0 && state.activity.quarantined.length < threats.length;
  const isolated = state.activity.networkIsolated;

  const iconFor = (appId) => getApp(appId)?.icon;

  const onTaskClick = (appId) => {
    const wins = running.filter((w) => w.appId === appId);
    if (wins.length === 0) openApp(appId);
    else toggleMinimize(wins.sort((a, b) => b.z - a.z)[0].id);
  };

  const taskContext = (e, appId) => {
    const wins = running.filter((w) => w.appId === appId);
    const items = [
      { label: getApp(appId)?.name, disabled: true },
      { separator: true },
      { label: 'Open new window', onClick: () => openApp(appId) },
    ];
    if (wins.length) items.push({ label: 'Close window', danger: true, onClick: () => wins.forEach((w) => closeWindow(w.id)) });
    openContextMenu(e, items);
  };

  return (
    <div
      style={{
        position: 'fixed', left: 0, right: 0, bottom: 0, height: 'var(--taskbar-h)', zIndex: 6000,
        background: 'var(--surface-glass)', backdropFilter: 'blur(22px)',
        borderTop: '1px solid var(--border)',
        display: 'flex', alignItems: 'center', padding: '0 8px', gap: 6,
      }}
    >
      {/* Start */}
      <TaskbarButton active={startOpen} onClick={onToggleStart} title="Start" wide>
        <StartLogo />
      </TaskbarButton>

      {/* Search pill */}
      <button
        onClick={onToggleStart}
        style={{
          display: 'flex', alignItems: 'center', gap: 8, height: 34, padding: '0 14px 0 12px',
          background: 'var(--surface-1)', border: '1px solid var(--border)', borderRadius: 999,
          color: 'var(--text-tertiary)', fontSize: 12.5, minWidth: 150,
        }}
      >
        <Search size={15} /> Search
      </button>

      {/* pinned + running */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 3, marginLeft: 4 }}>
        {buttons.map((appId) => {
          const Icon = iconFor(appId);
          const app = getApp(appId);
          if (!Icon) return null;
          const wins = running.filter((w) => w.appId === appId);
          const active = wins.some((w) => w.id === state.focusedId && !w.minimized);
          return (
            <div key={appId} style={{ position: 'relative' }} onContextMenu={(e) => taskContext(e, appId)}>
              <TaskbarButton active={active} onClick={() => onTaskClick(appId)} title={app.name}>
                <Icon size={19} color={active ? (app.color || 'var(--accent)') : 'var(--text-secondary)'} />
              </TaskbarButton>
              {wins.length > 0 && (
                <div style={{
                  position: 'absolute', bottom: 2, left: '50%', transform: 'translateX(-50%)',
                  width: active ? 16 : 6, height: 3, borderRadius: 2,
                  background: active ? (app.color || 'var(--accent)') : 'var(--text-tertiary)',
                  transition: 'width 0.18s',
                }} />
              )}
            </div>
          );
        })}
      </div>

      <div style={{ flex: 1 }} />

      {/* system tray */}
      <button title="Hidden icons" className="tray-btn" onClick={onToggleTray}
        style={trayBtnStyle}>
        <ChevronUp size={16} />
      </button>
      <div className="tray-group" style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
        <button title={isolated ? 'Network disconnected (isolated)' : 'Network connected'} style={trayBtnStyle} onClick={() => openApp('sysinfo')}>
          {isolated ? <WifiOff size={16} color="var(--warning)" /> : <Wifi size={16} />}
        </button>
        <button title="Volume" style={trayBtnStyle}><Volume2 size={16} /></button>
        <button
          title={threatsActive ? 'Security Center: action needed' : 'Security Center: protected'}
          style={trayBtnStyle}
          onClick={() => openApp('security')}
        >
          {threatsActive ? <ShieldAlert size={16} color="var(--danger)" /> : <ShieldCheck size={16} color="var(--success)" />}
        </button>
      </div>

      {/* clock + notifications */}
      <button
        onClick={onToggleNotifications}
        style={{
          display: 'flex', alignItems: 'center', gap: 10, height: 38, padding: '0 12px',
          background: 'transparent', border: '1px solid transparent', borderRadius: 'var(--radius-sm)',
          color: 'var(--text-primary)',
        }}
        onMouseEnter={(e) => (e.currentTarget.style.background = 'var(--hover)')}
        onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}
        title="Notifications"
      >
        <div style={{ textAlign: 'right', lineHeight: 1.25 }}>
          <div style={{ fontSize: 12 }}>{formatTime(now)}</div>
          <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{formatDateShort(now)}</div>
        </div>
        <div style={{ position: 'relative' }}>
          <Bell size={16} />
          {unread > 0 && (
            <motion.span
              initial={{ scale: 0 }} animate={{ scale: 1 }}
              style={{
                position: 'absolute', top: -6, right: -7, minWidth: 15, height: 15, padding: '0 3px',
                borderRadius: 999, background: 'var(--danger)', color: '#fff', fontSize: 9.5,
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700,
              }}
            >
              {unread}
            </motion.span>
          )}
        </div>
      </button>
    </div>
  );
}

const trayBtnStyle = {
  width: 32, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center',
  background: 'transparent', border: 'none', borderRadius: 'var(--radius-sm)', color: 'var(--text-secondary)',
};

function TaskbarButton({ children, active, onClick, title, wide }) {
  return (
    <button
      onClick={onClick}
      title={title}
      style={{
        height: 38, minWidth: wide ? 44 : 40, padding: '0 8px',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: active ? 'var(--active)' : 'transparent',
        border: '1px solid transparent', borderRadius: 'var(--radius-sm)',
        transition: 'background 0.12s',
      }}
      onMouseEnter={(e) => { if (!active) e.currentTarget.style.background = 'var(--hover)'; }}
      onMouseLeave={(e) => { if (!active) e.currentTarget.style.background = 'transparent'; }}
    >
      {children}
    </button>
  );
}

function StartLogo() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden>
      <defs>
        <linearGradient id="sl" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--accent)" />
          <stop offset="1" stopColor="#6a49d8" />
        </linearGradient>
      </defs>
      <rect x="3" y="3" width="8" height="8" rx="1.5" fill="url(#sl)" />
      <rect x="13" y="3" width="8" height="8" rx="1.5" fill="url(#sl)" opacity="0.8" />
      <rect x="3" y="13" width="8" height="8" rx="1.5" fill="url(#sl)" opacity="0.8" />
      <rect x="13" y="13" width="8" height="8" rx="1.5" fill="url(#sl)" opacity="0.6" />
    </svg>
  );
}
