// Tiny pub/sub stores for app-agnostic UI: modal dialogs and context menus.
// Apps call openDialog(...) / openContextMenu(...) imperatively; host
// components (mounted once in Desktop) subscribe and render them.
import { BRANDING } from '../config/brand.js';

function createStore(initial) {
  let state = initial;
  const listeners = new Set();
  return {
    get: () => state,
    set: (next) => {
      state = next;
      listeners.forEach((l) => l(state));
    },
    subscribe: (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
  };
}

// --- dialogs ---------------------------------------------------------------
export const dialogStore = createStore(null);

let dialogId = 0;
/**
 * openDialog({ title, message, icon, variant, buttons: [{label, value, variant}] })
 * Resolves with the chosen button's `value` (or true/false for ok/cancel).
 */
export function openDialog(opts) {
  return new Promise((resolve) => {
    dialogId += 1;
    dialogStore.set({
      id: dialogId,
      title: opts.title ?? BRANDING.product,
      message: opts.message ?? '',
      html: opts.html ?? null,
      icon: opts.icon ?? null,
      variant: opts.variant ?? 'info',
      buttons: opts.buttons ?? [
        { label: 'Cancel', value: false },
        { label: 'OK', value: true, variant: 'primary' },
      ],
      resolve,
    });
  });
}

export function confirmDialog(message, opts = {}) {
  return openDialog({
    message,
    title: opts.title ?? 'Confirm',
    variant: opts.variant ?? 'warning',
    icon: opts.icon,
    buttons: [
      { label: opts.cancelLabel ?? 'Cancel', value: false },
      { label: opts.confirmLabel ?? 'OK', value: true, variant: opts.danger ? 'danger' : 'primary' },
    ],
  });
}

export function closeDialog(value) {
  const d = dialogStore.get();
  if (d) {
    d.resolve(value);
    dialogStore.set(null);
  }
}

// --- context menus ---------------------------------------------------------
export const contextMenuStore = createStore(null);

/**
 * openContextMenu(event, items)
 * items: [{ label, icon, onClick, danger, disabled } | { separator: true }]
 */
export function openContextMenu(event, items) {
  event.preventDefault();
  event.stopPropagation();
  contextMenuStore.set({ x: event.clientX, y: event.clientY, items });
}

export function closeContextMenu() {
  contextMenuStore.set(null);
}
