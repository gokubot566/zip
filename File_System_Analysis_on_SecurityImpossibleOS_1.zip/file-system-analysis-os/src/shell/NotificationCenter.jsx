import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Info, AlertTriangle, ShieldAlert, CheckCircle2, X, BellOff, Settings as SettingsIcon } from 'lucide-react';
import { useOS, useClock } from '../core/OSContext.jsx';
import { formatFriendly, formatTime, formatLongDate } from '../core/utils.js';
import { TASKBAR_HEIGHT } from '../config/platform.js';

const ICONS = {
  info: <Info size={16} color="var(--info)" />,
  warning: <AlertTriangle size={16} color="var(--warning)" />,
  error: <ShieldAlert size={16} color="var(--danger)" />,
  success: <CheckCircle2 size={16} color="var(--success)" />,
};

export default function NotificationCenter({ open, onClose }) {
  const { state, openApp, removeNotification, clearNotifications } = useOS();
  const now = useClock(1000 * 20);
  const notes = state.notifications;

  return (
    <AnimatePresence>
      {open && (
        <>
          <div onClick={onClose} style={{ position: 'fixed', inset: 0, zIndex: 8000 }} />
          <motion.div
            initial={{ x: 380, opacity: 0.4 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 380, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 340, damping: 34 }}
            style={{
              position: 'fixed', top: 8, right: 8, bottom: TASKBAR_HEIGHT + 8, width: 372, zIndex: 8500,
              background: 'var(--surface-glass)', backdropFilter: 'blur(22px)',
              border: '1px solid var(--border-strong)', borderRadius: 'var(--radius-lg)',
              boxShadow: 'var(--shadow-lg)', display: 'flex', flexDirection: 'column', overflow: 'hidden',
            }}
          >
            {/* clock + calendar header */}
            <div style={{ padding: '18px 18px 14px', borderBottom: '1px solid var(--border)' }}>
              <div style={{ fontSize: 40, fontWeight: 200, lineHeight: 1 }}>{formatTime(now)}</div>
              <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>{formatLongDate(now)}</div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px 4px' }}>
              <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>Notifications</span>
              {notes.length > 0 && (
                <button className="os-btn ghost" style={{ fontSize: 11.5, padding: '4px 8px' }} onClick={clearNotifications}>
                  Clear all
                </button>
              )}
            </div>

            <div className="scrolly" style={{ flex: 1, padding: '4px 12px 12px', display: 'flex', flexDirection: 'column', gap: 8 }}>
              {notes.length === 0 ? (
                <div style={{ textAlign: 'center', color: 'var(--text-tertiary)', marginTop: 40 }}>
                  <BellOff size={30} style={{ opacity: 0.5 }} />
                  <div style={{ marginTop: 10, fontSize: 13 }}>No new notifications</div>
                </div>
              ) : (
                <AnimatePresence initial={false}>
                  {notes.map((n) => (
                    <motion.div
                      key={n.id}
                      layout
                      initial={{ opacity: 0, y: -6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: 60 }}
                      onClick={() => { if (n.appId) { openApp(n.appId); onClose(); } }}
                      style={{
                        background: 'var(--surface-2)', border: '1px solid var(--border)',
                        borderRadius: 'var(--radius-md)', padding: 12, cursor: n.appId ? 'pointer' : 'default',
                        position: 'relative',
                      }}
                    >
                      <div style={{ display: 'flex', gap: 9, alignItems: 'flex-start' }}>
                        <div style={{ marginTop: 1 }}>{ICONS[n.variant] ?? ICONS.info}</div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: 12.5, fontWeight: 600 }}>{n.title}</div>
                          <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 2, lineHeight: 1.45 }}>{n.body}</div>
                          <div style={{ fontSize: 10.5, color: 'var(--text-tertiary)', marginTop: 6 }}>{formatFriendly(n.time, now)}</div>
                        </div>
                        <button
                          onClick={(e) => { e.stopPropagation(); removeNotification(n.id); }}
                          className="os-btn ghost" style={{ padding: 2, height: 20 }}
                        >
                          <X size={12} />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              )}
            </div>

            <button
              onClick={() => { openApp('settings'); onClose(); }}
              className="os-btn"
              style={{ margin: 12, justifyContent: 'center' }}
            >
              <SettingsIcon size={15} /> Open Settings
            </button>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
