import React, { useMemo, useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Power, Lock, LogOut, RotateCcw, User, FileText, Folder } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { APPS, getApp } from '../apps/registry.js';
import { DEFAULT_START_PINS } from '../config/platform.js';
import { searchFs, extension } from '../core/fs.js';
import { confirmDialog } from './ui.js';
import { fileIconFor } from '../apps/fileIcons.jsx';

export default function StartMenu({ open, onClose }) {
  const { state, openApp, lock, logout, resetSession } = useOS();
  const USER = state.profile;
  const [query, setQuery] = useState('');
  const inputRef = useRef(null);

  // Pinned = configured pins that actually exist, plus any lab apps.
  const pinned = useMemo(() => {
    const existing = DEFAULT_START_PINS.filter((id) => getApp(id));
    const labExtras = APPS.filter((a) => a.category === 'Lab' && !existing.includes(a.id)).map((a) => a.id);
    return [...existing, ...labExtras];
  }, []);

  useEffect(() => {
    if (open) {
      setQuery('');
      setTimeout(() => inputRef.current?.focus(), 60);
    }
  }, [open]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return null;
    const apps = APPS.filter((a) => !a.hidden && a.name.toLowerCase().includes(q)).map((a) => ({ kind: 'app', app: a }));
    const files = searchFs(state.fs, q, { rootPath: `C:/Users/${USER.username}`, showHidden: false, limit: 8 }).map((r) => ({ kind: 'file', ...r }));
    return [...apps, ...files].slice(0, 12);
  }, [query, state.fs, USER.username]);

  const launch = (id, args) => { openApp(id, args); onClose(); };

  const power = async (fn, msg) => {
    onClose();
    if (await confirmDialog(msg, { confirmLabel: 'Yes' })) fn();
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          <div onMouseDown={onClose} style={{ position: 'fixed', inset: 0, zIndex: 7000 }} />
          <motion.div
            initial={{ opacity: 0, y: 16, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 400, damping: 30 }}
            onMouseDown={(e) => e.stopPropagation()}
            style={{
              position: 'fixed', left: '50%', transform: 'translateX(-50%)',
              bottom: 'calc(var(--taskbar-h) + 10px)', width: 'min(600px, 96vw)', maxHeight: '72vh', zIndex: 7500,
              background: 'var(--surface-glass)', backdropFilter: 'blur(26px)',
              border: '1px solid var(--border-strong)', borderRadius: 'var(--radius-lg)',
              boxShadow: 'var(--shadow-lg)', display: 'flex', flexDirection: 'column', overflow: 'hidden',
            }}
          >
            {/* search */}
            <div style={{ padding: 16, paddingBottom: 8 }}>
              <div style={{ position: 'relative' }}>
                <Search size={16} style={{ position: 'absolute', left: 12, top: 11, color: 'var(--text-tertiary)' }} />
                <input
                  ref={inputRef}
                  className="os-input"
                  style={{ paddingLeft: 36 }}
                  placeholder="Search apps and files"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
              </div>
            </div>

            <div className="scrolly" style={{ flex: 1, padding: '4px 16px 8px' }}>
              {results ? (
                <SearchResults results={results} onLaunch={launch} />
              ) : (
                <>
                  <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', margin: '6px 4px 10px' }}>Pinned</div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 6 }}>
                    {pinned.map((id) => {
                      const app = getApp(id);
                      if (!app) return null;
                      const Icon = app.icon;
                      return (
                        <button
                          key={id}
                          onClick={() => launch(id)}
                          title={app.name}
                          style={{
                            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                            padding: '14px 6px', border: '1px solid transparent', background: 'transparent',
                            borderRadius: 'var(--radius-md)', color: 'var(--text-primary)',
                          }}
                          onMouseEnter={(e) => (e.currentTarget.style.background = 'var(--hover)')}
                          onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}
                        >
                          <Icon size={26} color={app.color || 'var(--accent)'} />
                          <span style={{ fontSize: 11, textAlign: 'center', lineHeight: 1.2 }}>{app.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </>
              )}
            </div>

            {/* footer */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px', borderTop: '1px solid var(--border)', background: 'var(--surface-1)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 30, height: 30, borderRadius: '50%', background: 'linear-gradient(160deg, var(--accent), #6a49d8)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <User size={17} color="#fff" />
                </div>
                <div>
                  <div style={{ fontSize: 12.5, fontWeight: 600 }}>{USER.name}</div>
                  <div style={{ fontSize: 10.5, color: 'var(--text-tertiary)' }}>{USER.role}</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 2 }}>
                <FooterBtn title="Reset workspace" onClick={() => power(resetSession, 'Reset the workspace? This clears saved progress and restores the initial state.')}><RotateCcw size={16} /></FooterBtn>
                <FooterBtn title="Lock" onClick={() => { onClose(); lock(); }}><Lock size={16} /></FooterBtn>
                <FooterBtn title="Sign out" onClick={() => power(logout, 'Sign out of this session?')}><LogOut size={16} /></FooterBtn>
                <FooterBtn title="Power" onClick={() => power(logout, 'Shut down the workstation? (this signs you out)')}><Power size={16} /></FooterBtn>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

function FooterBtn({ children, onClick, title }) {
  return (
    <button className="os-btn ghost" title={title} onClick={onClick} style={{ padding: 8, borderRadius: 'var(--radius-sm)' }}>
      {children}
    </button>
  );
}

function SearchResults({ results, onLaunch }) {
  if (results.length === 0) {
    return <div style={{ padding: 24, textAlign: 'center', color: 'var(--text-tertiary)', fontSize: 13 }}>No matches</div>;
  }
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {results.map((r, i) =>
        r.kind === 'app' ? (
          <button key={`a${i}`} className="list-row" style={{ border: 'none', width: '100%' }} onClick={() => onLaunch(r.app.id)}>
            <r.app.icon size={18} color={r.app.color || 'var(--accent)'} />
            <span style={{ fontSize: 13 }}>{r.app.name}</span>
            <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text-tertiary)' }}>App</span>
          </button>
        ) : (
          <button
            key={`f${i}`}
            className="list-row"
            style={{ border: 'none', width: '100%' }}
            onClick={() => onLaunch(r.node.type === 'dir' ? 'explorer' : fileAppFor(r.node.name), r.node.type === 'dir' ? { path: r.path } : { path: r.path })}
          >
            {r.node.type === 'dir' ? <Folder size={18} color="var(--accent)" /> : fileIconFor(r.node.name, 18)}
            <span style={{ fontSize: 13, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.node.name}</span>
            <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text-tertiary)' }}>{r.matchedContent ? 'In file' : 'File'}</span>
          </button>
        ),
      )}
    </div>
  );
}

function fileAppFor(name) {
  const ext = extension(name);
  if (['png', 'jpg', 'jpeg', 'gif', 'bmp'].includes(ext)) return 'imageviewer';
  return 'texteditor';
}
