import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Monitor, Trash2, RotateCcw, Image as ImageIcon, Grid3x3 } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { getApp } from '../apps/registry.js';
import { listDir } from '../core/fs.js';
import { DEFAULT_DESKTOP_ICONS } from '../config/platform.js';
import { getActiveLab } from '../labs/index.js';
import { openContextMenu } from './ui.js';
import { fileIconFor, openPathFor } from '../apps/fileIcons.jsx';
import WindowLayer from './WindowLayer.jsx';
import Taskbar from './Taskbar.jsx';
import StartMenu from './StartMenu.jsx';
import NotificationCenter from './NotificationCenter.jsx';
import Toasts from './Toasts.jsx';
import DialogHost from './DialogHost.jsx';
import ContextMenuHost from './ContextMenuHost.jsx';
import SystemTrayPopup from './SystemTrayPopup.jsx';

const SPECIAL_ICONS = { 'this-pc': Monitor, 'recycle-bin': Trash2 };

export default function Desktop({ wallpaper }) {
  const { state, openApp, setSetting } = useOS();
  const [startOpen, setStartOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [trayOpen, setTrayOpen] = useState(false);
  const [selected, setSelected] = useState(null);

  const HOME = `C:/Users/${state.profile.username}`;
  const desktopFiles = listDir(state.fs, `${HOME}/Desktop`, { showHidden: state.settings.showHidden });

  // Desktop shortcuts = platform defaults + any the active lab contributes,
  // filtered to icons whose target app actually exists.
  const shortcuts = [...DEFAULT_DESKTOP_ICONS, ...(getActiveLab()?.desktopShortcuts ?? [])]
    .filter((s) => s.type !== 'app' || getApp(s.appId));

  const openShortcut = (s) => {
    if (s.type === 'special') {
      if (s.special === 'this-pc') openApp('explorer', { path: 'C:' });
      else if (s.special === 'recycle-bin') openApp('explorer', { path: '$recycle-bin' });
    } else if (s.type === 'app') {
      openApp(s.appId, s.args);
    }
  };

  const closeAll = () => { setStartOpen(false); setNotifOpen(false); setTrayOpen(false); };

  const desktopContext = (e) => {
    openContextMenu(e, [
      { label: 'View', disabled: true },
      { label: 'Open File Explorer', icon: <Grid3x3 size={15} />, onClick: () => openApp('explorer') },
      { separator: true },
      { label: 'Change background', icon: <ImageIcon size={15} />, onClick: () => openApp('settings', { section: 'personalization' }) },
      { label: 'Refresh', icon: <RotateCcw size={15} />, onClick: () => {} },
    ]);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 1.02 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
      style={{ position: 'absolute', inset: 0, background: wallpaper.css }}
      onMouseDown={() => { setSelected(null); closeAll(); }}
      onContextMenu={desktopContext}
    >
      {/* desktop icons */}
      <div
        style={{
          position: 'absolute', top: 12, left: 12, bottom: 'calc(var(--taskbar-h) + 8px)',
          display: 'flex', flexDirection: 'column', flexWrap: 'wrap', gap: 4, alignContent: 'flex-start',
        }}
        onMouseDown={(e) => e.stopPropagation()}
      >
        {shortcuts.map((s) => {
          const app = s.type === 'app' ? getApp(s.appId) : null;
          const Icon = SPECIAL_ICONS[s.special] || app?.icon || Monitor;
          const color = s.special ? 'var(--text-secondary)' : (app?.color || 'var(--accent)');
          return (
            <DesktopIcon
              key={s.id}
              selected={selected === s.id}
              onSelect={() => setSelected(s.id)}
              onOpen={() => openShortcut(s)}
              label={s.label}
              icon={<Icon size={30} color={color} />}
            />
          );
        })}

        {desktopFiles.map((f) => (
          <DesktopIcon
            key={f.path}
            selected={selected === f.path}
            onSelect={() => setSelected(f.path)}
            onOpen={() => openPathFor(f, openApp)}
            onContextMenu={(e) =>
              openContextMenu(e, [
                { label: 'Open', onClick: () => openPathFor(f, openApp) },
                { label: 'Show in File Explorer', onClick: () => openApp('explorer', { path: `${HOME}/Desktop` }) },
              ])
            }
            label={f.name}
            icon={f.type === 'dir' ? fileIconFor('', 30, true) : fileIconFor(f.name, 30)}
            suspicious={f.suspicious}
          />
        ))}
      </div>

      <WindowLayer />

      <StartMenu open={startOpen} onClose={() => setStartOpen(false)} />
      <NotificationCenter open={notifOpen} onClose={() => setNotifOpen(false)} />
      <SystemTrayPopup open={trayOpen} onClose={() => setTrayOpen(false)} />

      <Taskbar
        startOpen={startOpen}
        onToggleStart={() => { setStartOpen((v) => !v); setNotifOpen(false); setTrayOpen(false); }}
        onToggleNotifications={() => { setNotifOpen((v) => !v); setStartOpen(false); setTrayOpen(false); }}
        onToggleTray={() => { setTrayOpen((v) => !v); setStartOpen(false); setNotifOpen(false); }}
        trayOpen={trayOpen}
      />

      <Toasts />
      <ContextMenuHost />
      <DialogHost />
    </motion.div>
  );
}

function DesktopIcon({ label, icon, selected, onSelect, onOpen, onContextMenu, suspicious }) {
  return (
    <button
      onMouseDown={(e) => { e.stopPropagation(); onSelect(); }}
      onDoubleClick={onOpen}
      onContextMenu={onContextMenu}
      style={{
        width: 88, minHeight: 84, padding: '8px 4px 6px', border: '1px solid transparent',
        background: selected ? 'var(--selected)' : 'transparent',
        boxShadow: selected ? 'inset 0 0 0 1px var(--selected-border)' : 'none',
        borderRadius: 'var(--radius-sm)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
        color: '#fff', textShadow: '0 1px 3px rgba(0,0,0,0.7)',
      }}
      onMouseEnter={(e) => { if (!selected) e.currentTarget.style.background = 'rgba(255,255,255,0.08)'; }}
      onMouseLeave={(e) => { if (!selected) e.currentTarget.style.background = 'transparent'; }}
    >
      <div style={{ position: 'relative' }}>
        {icon}
        {suspicious && (
          <span style={{ position: 'absolute', bottom: -3, right: -6, fontSize: 12 }} title="Flagged">⚠️</span>
        )}
      </div>
      <span style={{ fontSize: 11.5, textAlign: 'center', lineHeight: 1.25, wordBreak: 'break-word', maxWidth: '100%' }}>
        {label}
      </span>
    </button>
  );
}
