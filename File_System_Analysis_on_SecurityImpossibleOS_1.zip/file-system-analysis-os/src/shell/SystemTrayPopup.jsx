import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Wifi, WifiOff, Bluetooth, Plane, Moon, Sun, Volume2 } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { TASKBAR_HEIGHT } from '../config/platform.js';

// The "quick settings" flyout (Wi-Fi, theme, volume) — a small nod to the
// Windows action-center tray. Toggling network isolation here is also a
// legitimate containment action for the lab.
export default function SystemTrayPopup({ open, onClose }) {
  const { state, setSetting, setNetworkIsolated, notify } = useOS();
  const isolated = state.activity.networkIsolated;
  const light = state.settings.theme === 'light';

  const toggleNet = () => {
    const next = !isolated;
    setNetworkIsolated(next);
    notify({
      title: 'Network',
      body: next ? 'Disconnected from the network (host isolated).' : 'Reconnected to the network.',
      variant: next ? 'warning' : 'success',
      appId: 'sysinfo',
    });
  };

  const Tile = ({ on, onClick, icon, label, sub }) => (
    <button
      onClick={onClick}
      style={{
        display: 'flex', alignItems: 'center', gap: 12, padding: 12, textAlign: 'left',
        background: on ? 'var(--accent)' : 'var(--surface-2)',
        color: on ? 'var(--accent-contrast)' : 'var(--text-primary)',
        border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', flex: 1,
      }}
    >
      <span style={{ display: 'inline-flex' }}>{icon}</span>
      <span>
        <div style={{ fontSize: 12.5, fontWeight: 600 }}>{label}</div>
        {sub && <div style={{ fontSize: 11, opacity: 0.8 }}>{sub}</div>}
      </span>
    </button>
  );

  return (
    <AnimatePresence>
      {open && (
        <>
          <div onMouseDown={onClose} style={{ position: 'fixed', inset: 0, zIndex: 8000 }} />
          <motion.div
            initial={{ opacity: 0, y: 16, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 400, damping: 30 }}
            onMouseDown={(e) => e.stopPropagation()}
            style={{
              position: 'fixed', right: 8, bottom: TASKBAR_HEIGHT + 8, width: 320, zIndex: 8500,
              background: 'var(--surface-glass)', backdropFilter: 'blur(24px)',
              border: '1px solid var(--border-strong)', borderRadius: 'var(--radius-lg)',
              boxShadow: 'var(--shadow-lg)', padding: 14,
            }}
          >
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', gap: 8 }}>
                <Tile
                  on={!isolated}
                  onClick={toggleNet}
                  icon={isolated ? <WifiOff size={18} /> : <Wifi size={18} />}
                  label={isolated ? 'Disconnected' : (state.data.network?.domain ?? state.profile.domain)}
                  sub={isolated ? 'Host isolated' : 'Connected'}
                />
                <Tile
                  on={light}
                  onClick={() => setSetting('theme', light ? 'dark' : 'light')}
                  icon={light ? <Sun size={18} /> : <Moon size={18} />}
                  label={light ? 'Light' : 'Dark'}
                  sub="Theme"
                />
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <Tile on={false} onClick={() => {}} icon={<Bluetooth size={18} />} label="Bluetooth" sub="Off" />
                <Tile on={false} onClick={() => {}} icon={<Plane size={18} />} label="Airplane" sub="Off" />
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 4px' }}>
                <Volume2 size={18} color="var(--text-secondary)" />
                <input type="range" defaultValue={65} style={{ flex: 1, accentColor: 'var(--accent)' }} />
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
