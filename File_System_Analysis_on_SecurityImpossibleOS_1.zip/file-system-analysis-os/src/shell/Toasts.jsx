import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Info, AlertTriangle, ShieldAlert, CheckCircle2, X } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { TASKBAR_HEIGHT } from '../config/platform.js';
import { formatTime } from '../core/utils.js';

const ICONS = {
  info: <Info size={18} color="var(--info)" />,
  warning: <AlertTriangle size={18} color="var(--warning)" />,
  error: <ShieldAlert size={18} color="var(--danger)" />,
  success: <CheckCircle2 size={18} color="var(--success)" />,
};

function Toast({ toast }) {
  const { dismissToast } = useOS();
  useEffect(() => {
    if (!toast.duration) return;
    const t = setTimeout(() => dismissToast(toast.id), toast.duration);
    return () => clearTimeout(t);
  }, [toast.id, toast.duration, dismissToast]);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: 340 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 340, transition: { duration: 0.2 } }}
      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
      style={{
        width: 330,
        background: 'var(--surface-2)',
        border: '1px solid var(--border-strong)',
        borderLeft: `3px solid var(--${toast.variant === 'error' ? 'danger' : toast.variant === 'warning' ? 'warning' : toast.variant === 'success' ? 'success' : 'info'})`,
        borderRadius: 'var(--radius-md)',
        boxShadow: 'var(--shadow-md)',
        padding: 12,
        display: 'flex',
        gap: 10,
      }}
    >
      <div style={{ flexShrink: 0, marginTop: 1 }}>{ICONS[toast.variant] ?? ICONS.info}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
          <span style={{ fontSize: 12.5, fontWeight: 600 }}>{toast.title}</span>
          <span style={{ fontSize: 10.5, color: 'var(--text-tertiary)' }}>{formatTime(toast.time)}</span>
        </div>
        <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 3, lineHeight: 1.45 }}>{toast.body}</div>
      </div>
      <button onClick={() => dismissToast(toast.id)} className="os-btn ghost" style={{ padding: 3, height: 22 }}>
        <X size={13} />
      </button>
    </motion.div>
  );
}

export default function Toasts() {
  const { state } = useOS();
  return (
    <div
      style={{
        position: 'fixed', right: 12, bottom: TASKBAR_HEIGHT + 12, zIndex: 90000,
        display: 'flex', flexDirection: 'column', gap: 10, alignItems: 'flex-end',
      }}
    >
      <AnimatePresence>
        {state.toasts.map((t) => (
          <Toast key={t.id} toast={t} />
        ))}
      </AnimatePresence>
    </div>
  );
}
