import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { User, Power, ArrowRight, Lock } from 'lucide-react';
import { useOS, useClock } from '../core/OSContext.jsx';
import { formatTime, formatLongDate } from '../core/utils.js';

export default function LoginScreen({ mode }) {
  const { state, login, unlock } = useOS();
  const USER = state.profile;
  const hint = USER.password || '';
  const now = useClock(1000 * 15);
  const [pw, setPw] = useState('');
  const [error, setError] = useState('');
  const [entering, setEntering] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    const t = setTimeout(() => inputRef.current?.focus(), 300);
    return () => clearTimeout(t);
  }, []);

  const submit = (e) => {
    e.preventDefault();
    // Accept the hinted password, or blank (kiosk-friendly for training).
    if (pw === hint || pw === '') {
      setEntering(true);
      setTimeout(() => (mode === 'lock' ? unlock() : login()), 450);
    } else {
      setError(`That password is incorrect.${hint ? ` Hint: ${hint}` : ''}`);
      setPw('');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.04 }}
      transition={{ duration: 0.4 }}
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        backdropFilter: 'blur(2px)',
        background: 'rgba(4, 8, 16, 0.35)',
      }}
    >
      {/* clock header (visible on lock, fades before the credential card) */}
      <motion.div
        initial={{ y: -10, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.1 }}
        style={{ position: 'absolute', top: '14%', textAlign: 'center', textShadow: '0 2px 20px rgba(0,0,0,0.6)' }}
      >
        <div style={{ fontSize: 68, fontWeight: 200, lineHeight: 1 }}>{formatTime(now)}</div>
        <div style={{ fontSize: 18, marginTop: 8, color: 'var(--text-secondary)' }}>{formatLongDate(now)}</div>
      </motion.div>

      <motion.form
        onSubmit={submit}
        animate={entering ? { opacity: 0, y: 12 } : { opacity: 1, y: 0 }}
        style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16, width: 320 }}
      >
        <div
          style={{
            width: 128, height: 128, borderRadius: '50%',
            background: 'linear-gradient(160deg, var(--accent), #6a49d8)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: 'var(--shadow-md)', border: '3px solid rgba(255,255,255,0.15)',
          }}
        >
          <User size={64} color="#fff" strokeWidth={1.4} />
        </div>
        <div style={{ fontSize: 22, fontWeight: 500 }}>{USER.name}</div>
        <div style={{ fontSize: 12.5, color: 'var(--text-tertiary)', marginTop: -10, display: 'flex', alignItems: 'center', gap: 6 }}>
          {mode === 'lock' ? <><Lock size={12} /> Locked</> : USER.role}
        </div>

        <div style={{ display: 'flex', gap: 8, width: '100%' }}>
          <input
            ref={inputRef}
            type="password"
            className="os-input"
            placeholder={mode === 'lock' ? 'Enter password to unlock' : 'Password'}
            value={pw}
            onChange={(e) => { setPw(e.target.value); setError(''); }}
            style={{ textAlign: 'center' }}
          />
          <button type="submit" className="os-btn primary" aria-label="Sign in" style={{ padding: '9px 14px' }}>
            <ArrowRight size={18} />
          </button>
        </div>

        <div style={{ height: 18, fontSize: 12.5, color: error ? 'var(--danger)' : 'var(--text-tertiary)' }}>
          {error || (hint ? `Password hint: ${hint}  ·  (or leave blank)` : 'Press Enter to sign in')}
        </div>
      </motion.form>

      <div style={{ position: 'absolute', bottom: 28, right: 32 }}>
        <button className="os-btn ghost" title="Power" style={{ padding: 10, borderRadius: '50%' }}>
          <Power size={20} />
        </button>
      </div>
    </motion.div>
  );
}
