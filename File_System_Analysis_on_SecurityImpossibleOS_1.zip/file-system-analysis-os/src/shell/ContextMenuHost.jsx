import React, { useEffect, useState, useLayoutEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { contextMenuStore, closeContextMenu } from './ui.js';

export default function ContextMenuHost() {
  const [menu, setMenu] = useState(contextMenuStore.get());
  const ref = useRef(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });

  useEffect(() => contextMenuStore.subscribe(setMenu), []);

  useEffect(() => {
    if (!menu) return;
    const close = () => closeContextMenu();
    const onKey = (e) => e.key === 'Escape' && close();
    window.addEventListener('mousedown', close);
    window.addEventListener('resize', close);
    window.addEventListener('blur', close);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('mousedown', close);
      window.removeEventListener('resize', close);
      window.removeEventListener('blur', close);
      window.removeEventListener('keydown', onKey);
    };
  }, [menu]);

  // Keep the menu on-screen.
  useLayoutEffect(() => {
    if (!menu || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    let x = menu.x;
    let y = menu.y;
    if (x + rect.width > window.innerWidth - 6) x = window.innerWidth - rect.width - 6;
    if (y + rect.height > window.innerHeight - 6) y = window.innerHeight - rect.height - 6;
    setPos({ x: Math.max(6, x), y: Math.max(6, y) });
  }, [menu]);

  return (
    <AnimatePresence>
      {menu && (
        <motion.div
          ref={ref}
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.96 }}
          transition={{ duration: 0.1 }}
          onMouseDown={(e) => e.stopPropagation()}
          onContextMenu={(e) => e.preventDefault()}
          style={{
            position: 'fixed', left: pos.x, top: pos.y, zIndex: 99000,
            minWidth: 210, padding: 6,
            background: 'var(--surface-2)',
            border: '1px solid var(--border-strong)',
            borderRadius: 'var(--radius-md)',
            boxShadow: 'var(--shadow-md)',
            backdropFilter: 'blur(12px)',
          }}
        >
          {menu.items.map((item, i) =>
            item.separator ? (
              <div key={i} style={{ height: 1, background: 'var(--border)', margin: '5px 8px' }} />
            ) : (
              <button
                key={i}
                disabled={item.disabled}
                onClick={() => {
                  closeContextMenu();
                  item.onClick?.();
                }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 10, width: '100%',
                  padding: '8px 10px', border: 'none', background: 'transparent',
                  borderRadius: 'var(--radius-sm)', textAlign: 'left', fontSize: 13,
                  color: item.disabled ? 'var(--text-disabled)' : item.danger ? 'var(--danger)' : 'var(--text-primary)',
                  cursor: item.disabled ? 'default' : 'pointer',
                }}
                onMouseEnter={(e) => { if (!item.disabled) e.currentTarget.style.background = 'var(--hover)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; }}
              >
                {item.icon && <span style={{ display: 'inline-flex', width: 16 }}>{item.icon}</span>}
                <span style={{ flex: 1 }}>{item.label}</span>
                {item.shortcut && <span style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{item.shortcut}</span>}
              </button>
            ),
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
