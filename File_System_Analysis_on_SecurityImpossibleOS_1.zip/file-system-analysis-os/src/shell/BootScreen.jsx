import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useOS } from '../core/OSContext.jsx';
import { BRANDING, LogoMark } from '../config/branding.jsx';

const LINES = [
  'Initializing secure boot…',
  'Loading virtual file system…',
  'Starting window manager…',
  'Mounting user profile…',
  'Starting desktop services…',
];

export default function BootScreen() {
  const { bootDone } = useOS();
  const [line, setLine] = useState(0);

  useEffect(() => {
    const stepMs = 420;
    const interval = setInterval(() => setLine((l) => Math.min(l + 1, LINES.length)), stepMs);
    const done = setTimeout(bootDone, stepMs * (LINES.length + 1.4));
    return () => {
      clearInterval(interval);
      clearTimeout(done);
    };
  }, [bootDone]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'radial-gradient(circle at 50% 40%, #10203a, #05080f 70%)',
        color: 'var(--text-primary)',
      }}
    >
      <motion.div
        initial={{ scale: 0.85, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18 }}
      >
        <div style={{ position: 'relative' }}>
          <LogoMark size={76} glow />
          <motion.div
            animate={{ opacity: [0.3, 1, 0.3] }}
            transition={{ duration: 2, repeat: Infinity }}
            style={{ position: 'absolute', inset: -8, borderRadius: '50%', boxShadow: `0 0 40px 8px ${BRANDING.colors.glow}` }}
          />
        </div>
        <div style={{ fontSize: 26, fontWeight: 300, letterSpacing: 1 }}>{BRANDING.product}</div>
        <div style={{ fontSize: 12.5, color: 'var(--text-tertiary)', marginTop: -8 }}>{BRANDING.tagline}</div>
      </motion.div>

      <div style={{ marginTop: 56, height: 96, display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'center' }}>
        {LINES.slice(0, line).map((l, i) => (
          <motion.div
            key={l}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: i === line - 1 ? 1 : 0.5, y: 0 }}
            style={{ fontSize: 12.5, color: 'var(--text-tertiary)', fontFamily: 'var(--mono)' }}
          >
            {l}
          </motion.div>
        ))}
      </div>

      <div style={{ position: 'absolute', bottom: 80 }}>
        <motion.div
          style={{ width: 34, height: 34, borderRadius: '50%', border: '3px solid rgba(255,255,255,0.15)', borderTopColor: 'var(--accent)' }}
          animate={{ rotate: 360 }}
          transition={{ duration: 0.9, repeat: Infinity, ease: 'linear' }}
        />
      </div>
    </motion.div>
  );
}
