import React, { useCallback, useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Minus, Square, X, Copy as Restore } from 'lucide-react';
import { useOS } from '../core/OSContext.jsx';
import { getAppComponent, getApp } from '../apps/registry.js';
import { clamp } from '../core/utils.js';
import { TASKBAR_HEIGHT } from '../config/platform.js';

const MIN_W = 320;
const MIN_H = 200;

export default function Window({ win }) {
  const { state, focusWindow, closeWindow, minimizeWindow, toggleMaximize, setBounds } = useOS();
  const app = getApp(win.appId);
  const AppComponent = getAppComponent(win.appId);
  const Icon = app?.icon;

  const [local, setLocal] = useState({ x: win.x, y: win.y, w: win.w, h: win.h });
  const drag = useRef(null);
  const focused = state.focusedId === win.id;

  // Sync local geometry when the store changes it (and we're not mid-drag).
  useEffect(() => {
    if (!drag.current) setLocal({ x: win.x, y: win.y, w: win.w, h: win.h });
  }, [win.x, win.y, win.w, win.h]);

  const beginDrag = useCallback(
    (e, mode) => {
      if (e.button !== 0) return;
      if (win.maximized && mode === 'move') return;
      e.preventDefault();
      focusWindow(win.id);
      const start = { mx: e.clientX, my: e.clientY, ...local, mode };
      drag.current = start;

      const onMove = (ev) => {
        const dx = ev.clientX - start.mx;
        const dy = ev.clientY - start.my;
        const maxY = window.innerHeight - TASKBAR_HEIGHT;
        if (mode === 'move') {
          setLocal({
            ...start,
            x: clamp(start.x + dx, -start.w + 120, window.innerWidth - 120),
            y: clamp(start.y + dy, 0, maxY - 40),
          });
        } else {
          let { x, y, w, h } = start;
          if (mode.includes('e')) w = clamp(start.w + dx, MIN_W, window.innerWidth - start.x - 4);
          if (mode.includes('s')) h = clamp(start.h + dy, MIN_H, maxY - start.y - 4);
          if (mode.includes('w')) {
            w = clamp(start.w - dx, MIN_W, start.x + start.w - 4);
            x = start.x + (start.w - w);
          }
          if (mode.includes('n')) {
            h = clamp(start.h - dy, MIN_H, start.y + start.h - 4);
            y = start.y + (start.h - h);
          }
          setLocal({ x, y, w, h });
        }
      };
      const onUp = () => {
        window.removeEventListener('pointermove', onMove);
        window.removeEventListener('pointerup', onUp);
        const final = drag.current;
        drag.current = null;
        setLocal((l) => {
          setBounds(win.id, l);
          return l;
        });
        // Drag to top edge → maximize (Windows Aero Snap style).
        if (final?.mode === 'move') {
          // handled by caller via double-click; keep simple here
        }
      };
      window.addEventListener('pointermove', onMove);
      window.addEventListener('pointerup', onUp);
    },
    [win.id, win.maximized, local, focusWindow, setBounds],
  );

  const geom = win.maximized
    ? { left: 0, top: 0, width: '100%', height: `calc(100% - ${TASKBAR_HEIGHT}px)` }
    : { left: local.x, top: local.y, width: local.w, height: local.h };

  return (
    <motion.div
      role="dialog"
      aria-label={win.title}
      initial={{ opacity: 0, scale: 0.96, y: 8 }}
      animate={{
        opacity: win.minimized ? 0 : 1,
        scale: win.minimized ? 0.9 : 1,
        y: win.minimized ? 40 : 0,
        pointerEvents: win.minimized ? 'none' : 'auto',
      }}
      exit={{ opacity: 0, scale: 0.96, transition: { duration: 0.12 } }}
      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
      onMouseDown={() => focusWindow(win.id)}
      style={{
        position: 'absolute',
        ...geom,
        zIndex: win.z,
        display: 'flex',
        flexDirection: 'column',
        background: 'var(--window-bg)',
        border: `1px solid ${focused ? 'var(--border-strong)' : 'var(--window-border)'}`,
        borderRadius: win.maximized ? 0 : 'var(--radius-lg)',
        boxShadow: focused ? 'var(--shadow-lg)' : 'var(--shadow-sm)',
        overflow: 'hidden',
        pointerEvents: 'auto',
      }}
    >
      {/* title bar */}
      <div
        onPointerDown={(e) => beginDrag(e, 'move')}
        onDoubleClick={() => toggleMaximize(win.id)}
        style={{
          display: 'flex', alignItems: 'center', gap: 8,
          height: 40, paddingLeft: 12, flexShrink: 0,
          background: 'var(--window-header)',
          borderBottom: '1px solid var(--border)',
          cursor: win.maximized ? 'default' : 'grab',
          userSelect: 'none',
        }}
      >
        {Icon && <Icon size={15} color={app.color || 'var(--accent)'} style={{ flexShrink: 0 }} />}
        <span style={{ fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', flex: 1 }}>
          {win.title}
        </span>
        <div style={{ display: 'flex' }} onPointerDown={(e) => e.stopPropagation()}>
          <WinBtn onClick={() => minimizeWindow(win.id)} title="Minimize"><Minus size={15} /></WinBtn>
          <WinBtn onClick={() => toggleMaximize(win.id)} title={win.maximized ? 'Restore' : 'Maximize'}>
            {win.maximized ? <Restore size={13} /> : <Square size={12} />}
          </WinBtn>
          <WinBtn onClick={() => closeWindow(win.id)} title="Close" danger><X size={16} /></WinBtn>
        </div>
      </div>

      {/* app content */}
      <div style={{ flex: 1, minHeight: 0, position: 'relative', display: 'flex', flexDirection: 'column' }}>
        {AppComponent ? (
          <AppComponent win={win} args={win.args} />
        ) : (
          <div style={{ padding: 20 }}>Unknown application: {win.appId}</div>
        )}
      </div>

      {/* resize handles */}
      {!win.maximized && <ResizeHandles onBegin={beginDrag} />}
    </motion.div>
  );
}

function WinBtn({ children, onClick, title, danger }) {
  return (
    <button
      onClick={onClick}
      title={title}
      style={{
        width: 46, height: 40, border: 'none', background: 'transparent',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: 'var(--text-secondary)', transition: 'background 0.12s, color 0.12s',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.background = danger ? 'var(--danger)' : 'var(--hover)';
        e.currentTarget.style.color = danger ? '#fff' : 'var(--text-primary)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.background = 'transparent';
        e.currentTarget.style.color = 'var(--text-secondary)';
      }}
    >
      {children}
    </button>
  );
}

function ResizeHandles({ onBegin }) {
  const H = 7;
  const edges = [
    { m: 'n', style: { top: 0, left: H, right: H, height: H, cursor: 'ns-resize' } },
    { m: 's', style: { bottom: 0, left: H, right: H, height: H, cursor: 'ns-resize' } },
    { m: 'e', style: { top: H, bottom: H, right: 0, width: H, cursor: 'ew-resize' } },
    { m: 'w', style: { top: H, bottom: H, left: 0, width: H, cursor: 'ew-resize' } },
    { m: 'nw', style: { top: 0, left: 0, width: H, height: H, cursor: 'nwse-resize' } },
    { m: 'ne', style: { top: 0, right: 0, width: H, height: H, cursor: 'nesw-resize' } },
    { m: 'sw', style: { bottom: 0, left: 0, width: H, height: H, cursor: 'nesw-resize' } },
    { m: 'se', style: { bottom: 0, right: 0, width: H + 3, height: H + 3, cursor: 'nwse-resize' } },
  ];
  return (
    <>
      {edges.map((e) => (
        <div key={e.m} onPointerDown={(ev) => onBegin(ev, e.m)} style={{ position: 'absolute', ...e.style, zIndex: 5 }} />
      ))}
    </>
  );
}
