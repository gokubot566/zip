import React, { useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import { useOS } from './core/OSContext.jsx';
import { WALLPAPERS, ACCENTS } from './config/platform.js';
import BootScreen from './shell/BootScreen.jsx';
import LoginScreen from './shell/LoginScreen.jsx';
import Desktop from './shell/Desktop.jsx';
import { getActiveLab } from './labs/index.js';

// Apply theme + accent to the document root so CSS variables cascade globally.
function useThemeVars(settings) {
  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = settings.theme;
    const accent = ACCENTS.find((a) => a.id === settings.accentId) ?? ACCENTS[0];
    root.style.setProperty('--accent', accent.color);
  }, [settings.theme, settings.accentId]);
}

export default function App() {
  const { state } = useOS();
  const { session, settings } = state;
  useThemeVars(settings);

  const wallpaper = WALLPAPERS.find((w) => w.id === settings.wallpaperId) ?? WALLPAPERS[0];

  // A lab may contribute a floating overlay (e.g. a guided assistant) that sits
  // above the desktop once the user is signed in. The platform stays unaware of
  // what it contains.
  const signedIn = session.booted && session.loggedIn && !session.locked;
  const LabOverlay = getActiveLab()?.Overlay ?? null;

  return (
    <div
      style={{ position: 'fixed', inset: 0, overflow: 'hidden', background: wallpaper.css }}
    >
      <AnimatePresence mode="wait">
        {!session.booted ? (
          <BootScreen key="boot" />
        ) : !session.loggedIn || session.locked ? (
          <LoginScreen key="login" mode={session.loggedIn && session.locked ? 'lock' : 'login'} />
        ) : (
          <Desktop key="desktop" wallpaper={wallpaper} />
        )}
      </AnimatePresence>
      {signedIn && LabOverlay ? <LabOverlay /> : null}
    </div>
  );
}
