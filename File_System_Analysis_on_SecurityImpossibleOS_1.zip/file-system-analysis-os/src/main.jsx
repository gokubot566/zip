import React from 'react';
import { createRoot } from 'react-dom/client';
import { OSProvider } from './core/OSContext.jsx';
import App from './App.jsx';
import './index.css';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <OSProvider>
      <App />
    </OSProvider>
  </React.StrictMode>,
);
