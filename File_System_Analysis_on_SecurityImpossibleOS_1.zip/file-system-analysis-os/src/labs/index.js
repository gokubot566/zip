// ===========================================================================
// LAB REGISTRY — the platform's extension point for training labs.
//
// This deployment ships the File System Analysis & Metadata Extraction lab
// (originally the Sentinel OS forensics scenario), hosted on the Security
// Impossible OS platform. The platform itself stays lab-agnostic; everything
// scenario-specific lives under src/labs/file-system-analysis/.
// ===========================================================================

import fileSystemAnalysis from './file-system-analysis/index.js';

export const LABS = [fileSystemAnalysis];

// Which lab this deployment runs. `null` → generic, lab-free desktop.
export const ACTIVE_LAB_ID = 'file-system-analysis';

export function getActiveLab() {
  return LABS.find((l) => l.id === ACTIVE_LAB_ID) ?? null;
}

export function getLab(id) {
  return LABS.find((l) => l.id === id) ?? null;
}
