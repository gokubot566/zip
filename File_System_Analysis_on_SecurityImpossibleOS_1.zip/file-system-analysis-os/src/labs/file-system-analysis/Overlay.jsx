import React from 'react';
import { useFsaLab } from './bridge.jsx';
import Byte from './Byte.jsx';

/* =============================================================================
   Byte overlay
   The floating lab guide. Security Impossible OS renders `getActiveLab().Overlay`
   above the desktop once the user is signed in (see src/App.jsx). We wrap Byte
   in a full-viewport `.fsa-scope` that is pointer-events:none, so the desktop
   stays fully usable and only Byte's own launcher/panel capture clicks.
   ============================================================================= */
export default function FsaOverlay() {
  const { lab, patchLab, resetLab, isTaskDone, openApp, allDone } = useFsaLab();
  return (
    <div className="fsa-scope fsa-overlay-scope">
      <Byte
        lab={lab}
        patchLab={patchLab}
        resetLab={resetLab}
        isTaskDone={isTaskDone}
        openApp={openApp}
        allDone={allDone}
      />
    </div>
  );
}
