import { FolderOpen, TerminalSquare, ShieldCheck, Globe, ScanLine, FileText } from 'lucide-react';
import './theme.css';
import { LAB_META, SUSPECT } from './scenario.js';
import {
  FilesAppW, TerminalAppW, SecurityAppW, IntelAppW, PEAppW, ReportAppW,
} from './AppWrappers.jsx';
import FsaOverlay from './Overlay.jsx';

/* =============================================================================
   LAB PACKAGE — File System Analysis & Metadata Extraction
   The original Sentinel-OS scenario, hosted inside Security Impossible OS.
   The scenario content (scenario.js) and the six analysis apps are unchanged;
   only the surrounding operating system is the newer SI OS platform.
   ============================================================================= */

// Six lab apps. Their ids match the scenario's task.app values and the openApp
// calls inside the ported components, so Byte's nudges and cross-app links work.
// `terminal` and `security` intentionally override the platform defaults so the
// lab's scripted Terminal and OmniGuard are used for this scenario.
const apps = [
  { id: 'files',    name: 'Files',         icon: FolderOpen,    color: '#3b82f6', category: 'Lab', defaultSize: { w: 760, h: 520 }, component: FilesAppW },
  { id: 'terminal', name: 'Terminal',      icon: TerminalSquare, color: '#22d3b3', category: 'Lab', defaultSize: { w: 680, h: 440 }, component: TerminalAppW },
  { id: 'security', name: 'OmniGuard',     icon: ShieldCheck,   color: '#7c6cf0', category: 'Lab', singleton: true, defaultSize: { w: 720, h: 500 }, component: SecurityAppW },
  { id: 'intel',    name: 'Threat Lookup', icon: Globe,         color: '#06b6d4', category: 'Lab', defaultSize: { w: 720, h: 560 }, component: IntelAppW },
  { id: 'pe',       name: 'PE Inspector',  icon: ScanLine,      color: '#f59e0b', category: 'Lab', defaultSize: { w: 720, h: 560 }, component: PEAppW },
  { id: 'report',   name: 'Triage Report', icon: FileText,      color: '#34d399', category: 'Lab', singleton: true, defaultSize: { w: 680, h: 620 }, component: ReportAppW },
];

const desktopShortcuts = [
  { id: 'd-files',    type: 'app', appId: 'files',    label: 'Files' },
  { id: 'd-security', type: 'app', appId: 'security', label: 'OmniGuard' },
  { id: 'd-terminal', type: 'app', appId: 'terminal', label: 'Terminal' },
  { id: 'd-intel',    type: 'app', appId: 'intel',    label: 'Threat Lookup' },
  { id: 'd-pe',       type: 'app', appId: 'pe',       label: 'PE Inspector' },
  { id: 'd-report',   type: 'app', appId: 'report',   label: 'Triage Report' },
];

// A small on-desktop brief so the platform feels lab-aware. The investigation
// itself runs entirely inside the lab apps, which read the scenario directly.
function seed(fs, { writeFile, now }) {
  const home = 'C:/Users/analyst/Desktop';
  return writeFile(
    fs,
    `${home}/Case brief.txt`,
    `${LAB_META.title}\n${LAB_META.subtitle}\n\n` +
    `Host: ${LAB_META.host}    Analyst: ${LAB_META.analyst}    Est. time: ${LAB_META.duration}\n\n` +
    `The SOC flagged odd activity on this workstation. Something was dropped\n` +
    `into a temporary folder. Follow Byte (the floating guide) through the\n` +
    `seven stages: locate it, collect it safely, examine it, fingerprint it,\n` +
    `check threat intel, prove intent, and record your verdict.\n\n` +
    `Suspicious artefact under investigation: ${SUSPECT.name}\n`,
    { now },
  );
}

const lab = {
  id: 'file-system-analysis',
  storeKey: 'si-os.file-system-analysis.v1',
  meta: {
    name: LAB_META.title,
    subtitle: LAB_META.subtitle,
    unit: LAB_META.unit,
    duration: LAB_META.duration,
  },
  // Persona for this workstation.
  profile: {
    name: 'Security Analyst',
    username: 'analyst',
    role: 'Security Analyst',
    hostname: LAB_META.host,          // WORKSTATION-07
    domain: 'securityimpossible.local',
    password: '',
  },
  data: {},
  notifications: [],
  seed,
  desktopShortcuts,
  apps,
  // Rendered above the desktop by the shell when signed in.
  Overlay: FsaOverlay,
};

export default lab;
