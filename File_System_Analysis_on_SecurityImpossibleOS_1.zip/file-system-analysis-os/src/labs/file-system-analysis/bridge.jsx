import { useCallback, useRef } from 'react';
import { useOS } from '../../core/OSContext.jsx';
import { TASKS, TASK_ORDER } from './scenario.js';

/* =============================================================================
   Lab bridge
   The ported Sentinel-OS apps and the Byte guide were written to a tiny state
   contract from their original App.jsx:  { lab, patchLab, isTaskDone, allDone,
   openApp, resetLab }.  Rather than rewrite those components, we reproduce that
   exact contract on top of Security Impossible OS:
     - the investigation object lives in the host OS `labState.fsa`
       (persisted by the platform across refreshes, per-lab store key),
     - patchLab writes back through the platform reducer,
     - openApp drives the real OS window manager,
     - resetLab restarts the whole session cleanly.
   ============================================================================= */

// The investigation + guide state (identical shape to the original lab).
export const FRESH = {
  // investigation flags (set by the apps as the student acts)
  foundFile: false,
  restored: false,
  inspected: false,
  hashed: false,
  intelDone: false,
  staticDone: false,
  verdict: null,
  iocsConfirmed: false,
  // guide state
  introSeen: false,
  currentTask: 0,
  byteOpen: true,
};

export function useFsaLab() {
  const { state, setLabState, openApp, resetSession } = useOS();

  // Keep the freshest investigation object in a ref so several patchLab() calls
  // fired synchronously in one handler compose instead of clobbering each other
  // (the original lab relied on functional setState for this).
  const ref = useRef(FRESH);
  ref.current = { ...FRESH, ...(state.labState?.fsa ?? {}) };
  const lab = ref.current;

  const patchLab = useCallback((p) => {
    const cur = ref.current;
    const next = typeof p === 'function' ? p(cur) : p;
    const merged = { ...cur, ...next };
    ref.current = merged;           // visible to a second synchronous patch
    setLabState('fsa', merged);
  }, [setLabState]);

  const isTaskDone = useCallback((task, s = ref.current) => {
    const c = task.check;
    switch (c.type) {
      case 'foundFile': return s.foundFile;
      case 'restored': return s.restored;
      case 'inspected': return s.inspected;
      case 'command': return s.hashed;
      case 'intelLookup': return s.intelDone;
      case 'staticAnalysis': return s.staticDone;
      case 'verdict': return s.verdict === 'malicious' && s.iocsConfirmed;
      default: return false;
    }
  }, []);

  const allDone = TASK_ORDER.every((_, i) => isTaskDone(TASKS[i], lab));

  const resetLab = useCallback(() => { resetSession(); }, [resetSession]);

  return { lab, patchLab, isTaskDone, allDone, openApp, resetLab };
}
