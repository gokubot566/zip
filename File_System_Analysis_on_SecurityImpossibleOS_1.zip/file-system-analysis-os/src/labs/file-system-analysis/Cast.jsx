import React from 'react';
import { CHARACTERS } from './scenario.js';

// Professional illustrated portraits (Adobe Stock, licensed) for the mentor
// cast. Imported so Vite fingerprints + bundles them. This map is the single
// source of truth for character art and is reused across all labs.
import elenaPhoto from './assets/cast/character-5.png';
import marcusPhoto from './assets/cast/character-4.png';
import priyaPhoto from './assets/cast/character-1.png';
import davidPhoto from './assets/cast/character-2.png';
import auditorPhoto from './assets/cast/character-3.png';

export const CAST_PHOTOS = {
  elena: elenaPhoto,
  marcus: marcusPhoto,
  priya: priyaPhoto,
  david: davidPhoto,
  auditor: auditorPhoto,
};

// A circular, brand-ringed portrait. Bobs + glows when `speaking`.
export function CastPhoto({ id, size = 84, speaking = false }) {
  const c = CHARACTERS[id];
  if (!c) return null;
  return (
    <span
      className={`cast-photo ${speaking ? 'speaking' : ''}`}
      style={{ width: size, height: size, '--cloth': c.color }}
      title={`${c.name} \u2014 ${c.role}`}
    >
      <img src={CAST_PHOTOS[id]} alt={c.name} draggable="false" />
    </span>
  );
}
