import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  TASKS, TASK_ORDER, CHARACTERS, BYTE_INTRO, GLOSSARY, LAB_META,
  SUMMARY, LEARNING_OUTCOMES, DISCLAIMER,
} from './scenario.js';
import { CastPhoto } from './Cast.jsx';
import { ByteAvatar } from './ByteAvatar.jsx';
import {
  Check, Lock, Lightbulb, ArrowRight, ArrowLeft, X, RotateCcw, Trophy,
  GripHorizontal, Play, ListChecks, BookOpen, Info, ChevronDown, ExternalLink,
  RefreshCw,
} from 'lucide-react';

const GAP = 16;
const LAUNCHER = 62;

/* Byte — the floating lab guide. Freely draggable (drop anywhere: left, right,
   middle). Page 1 = Byte (robot) intro; page 2 = the team; then gated task
   steps + a glossary. Advancing is gated on the live lab state satisfying each
   task's check (owned by App.jsx via isTaskDone). */
export default function Byte({ lab, patchLab, resetLab, isTaskDone, openApp, allDone }) {
  const open = lab.byteOpen;
  const [tab, setTab] = useState('guide'); // guide | glossary
  const [showSteps, setShowSteps] = useState(true);

  const activeTask = TASKS[lab.currentTask] || null;
  const activeDone = activeTask ? isTaskDone(activeTask) : false;
  const doneCount = TASK_ORDER.filter((_, i) => isTaskDone(TASKS[i])).length;
  const speaker = allDone ? 'elena' : (activeTask?.speaker || 'elena');

  const canGoBack = lab.currentTask > 0;
  const canGoNext = activeDone;

  const advance = () => {
    if (lab.currentTask < TASKS.length - 1) patchLab({ currentTask: lab.currentTask + 1 });
  };
  const goBack = () => { if (canGoBack) patchLab({ currentTask: lab.currentTask - 1 }); };

  useEffect(() => { setShowSteps(true); }, [activeTask?.id]);

  // ---- free-position dragging ----
  const wRef = useRef(null);
  const posRef = useRef(null); // last placed {left, top}; null = default corner
  const [winSize, setWinSize] = useState({ w: window.innerWidth, h: window.innerHeight });
  const dragging = useRef(false);
  const animRef = useRef(false);
  const dragData = useRef(null);

  const place = useCallback((animate) => {
    const w = wRef.current; if (!w) return;
    const vw = window.innerWidth, vh = window.innerHeight;
    const wW = w.offsetWidth || (open ? 384 : LAUNCHER);
    const wH = w.offsetHeight || (open ? 520 : LAUNCHER);
    const maxLeft = Math.max(GAP, vw - wW - GAP);
    const maxTop = Math.max(GAP + 40, vh - wH - GAP - 66); // keep above the dock
    const def = { left: maxLeft, top: Math.max(GAP + 40, vh * 0.16) };
    const want = posRef.current || def;
    const left = Math.max(GAP, Math.min(want.left, maxLeft));
    const top = Math.max(GAP + 40, Math.min(want.top, maxTop));
    posRef.current = { left, top };
    w.style.transition = animate ? 'left .26s ease, top .26s ease' : 'none';
    w.style.left = left + 'px';
    w.style.top = top + 'px';
    w.style.right = 'auto'; w.style.bottom = 'auto';
  }, [open]);

  useEffect(() => {
    const onResize = () => setWinSize({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  useEffect(() => {
    if (dragging.current) return;
    const a = animRef.current; animRef.current = false;
    place(a);
  }, [open, winSize, place, lab.introSeen, lab.currentTask, allDone, tab, showSteps]);

  const onDragStart = (e) => {
    const w = wRef.current; if (!w) return;
    const pt = e.touches ? e.touches[0] : e;
    const rect = w.getBoundingClientRect();
    dragging.current = true;
    dragData.current = { offX: pt.clientX - rect.left, offY: pt.clientY - rect.top };
    w.style.transition = 'none';
    document.addEventListener('mousemove', onDragMove);
    document.addEventListener('mouseup', onDragEnd);
    document.addEventListener('touchmove', onDragMove, { passive: false });
    document.addEventListener('touchend', onDragEnd);
    e.preventDefault();
  };
  const onDragMove = (e) => {
    const w = wRef.current; if (!w || !dragging.current) return;
    if (e.cancelable) e.preventDefault();
    const pt = e.touches ? e.touches[0] : e;
    w.style.left = (pt.clientX - dragData.current.offX) + 'px';
    w.style.top = (pt.clientY - dragData.current.offY) + 'px';
    w.style.right = 'auto'; w.style.bottom = 'auto';
  };
  const onDragEnd = () => {
    const w = wRef.current;
    document.removeEventListener('mousemove', onDragMove);
    document.removeEventListener('mouseup', onDragEnd);
    document.removeEventListener('touchmove', onDragMove);
    document.removeEventListener('touchend', onDragEnd);
    if (!w) { dragging.current = false; return; }
    const rect = w.getBoundingClientRect();
    posRef.current = { left: rect.left, top: rect.top };
    dragging.current = false;
    place(true);
  };

  return (
    <>
      <style>{BYTE_CSS}</style>
      <div className="byte-root" ref={wRef}>
        {!open && (
          <button className="byte-launcher" onMouseDown={onDragStart} onTouchStart={onDragStart}
            onClick={() => { if (!dragging.current) { animRef.current = true; patchLab({ byteOpen: true }); } }}
            title="Open Byte (drag to move)">
            <ByteAvatar size={52} speaking />
            {!allDone && <span className="byte-launch-badge">{doneCount}/{TASK_ORDER.length}</span>}
          </button>
        )}

        {open && (
          <div className="byte-panel">
            <div className="byte-head" onMouseDown={onDragStart} onTouchStart={onDragStart}>
              <ByteAvatar size={38} speaking />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="byte-title">Byte · Lab Guide</div>
                <div className="byte-sub">{allDone ? 'Lab complete' : `Task ${activeTask?.n} of ${TASK_ORDER.length} · ${CHARACTERS[speaker].name}`}</div>
              </div>
              <span className="byte-grip" title="Drag to move"><GripHorizontal size={16} /></span>
              <button className="byte-x" onClick={() => { animRef.current = true; patchLab({ byteOpen: false }); }}><X size={17} /></button>
            </div>

            <div className="byte-progress">
              {TASK_ORDER.map((id, i) => {
                const done = isTaskDone(TASKS[i]);
                const cur = !allDone && i === lab.currentTask;
                return <span key={id} className={`byte-pip ${done ? 'done' : cur ? 'cur' : ''}`} />;
              })}
            </div>

            {!lab.introSeen ? (
              <Intro onStart={() => patchLab({ introSeen: true })} />
            ) : allDone ? (
              <Summary resetLab={resetLab} />
            ) : (
              <>
                <div className="byte-tabs">
                  <button className={tab === 'guide' ? 'on' : ''} onClick={() => setTab('guide')}><ListChecks size={13} /> Current task</button>
                  <button className={tab === 'glossary' ? 'on' : ''} onClick={() => setTab('glossary')}><BookOpen size={13} /> Glossary</button>
                </div>

                <div className="byte-body">
                  {tab === 'guide' && activeTask && (
                    <div className="byte-fade">
                      <div className="byte-area">Task {activeTask.n} · {activeTask.area}</div>
                      {activeTask.stage && <div className="byte-stage">{activeTask.stage}</div>}
                      <div className="byte-speaker">
                        <CastPhoto id={activeTask.speaker} size={30} speaking />
                        <span>{CHARACTERS[activeTask.speaker].name} · {CHARACTERS[activeTask.speaker].role}</span>
                      </div>
                      <p className="byte-brief" dangerouslySetInnerHTML={{ __html: activeTask.brief }} />

                      {activeTask.tool && (
                        <div className="byte-tool">
                          <div className="byte-tool-h"><BookOpen size={12} /> About the {activeTask.tool.name}</div>
                          <div className="byte-tool-t">{activeTask.tool.what}</div>
                        </div>
                      )}

                      <div className="byte-goal">
                        <div className="byte-goal-label">Your task</div>
                        {activeTask.goal}
                      </div>

                      <button className="byte-open-app" onClick={() => openApp(activeTask.app)}>
                        <ExternalLink size={13} /> Open the {appName(activeTask.app)}
                      </button>

                      <button className="byte-hint-toggle" onClick={() => setShowSteps((s) => !s)}>
                        <Lightbulb size={14} /> {showSteps ? 'Hide steps' : 'Show the steps'}
                      </button>
                      {showSteps && (
                        <>
                          <p className="byte-tip">
                            <Info size={13} /> Tap the <b>ⓘ</b> on any step to see what it does and why it matters.
                          </p>
                          <div className="byte-steps">
                            {activeTask.steps.map((s, i) => <StepRow key={i} step={s} num={i + 1} />)}
                          </div>
                        </>
                      )}

                      <div className={`byte-status ${activeDone ? 'ok' : ''}`}>
                        {activeDone
                          ? <><Check size={16} /> {activeTask.successNote}</>
                          : <><Lock size={15} /> Do this in the app to unlock the next task.</>}
                      </div>

                      <div className="byte-nav">
                        {canGoBack && <button className="byte-back" onClick={goBack}><ArrowLeft size={16} /> Back</button>}
                        <button className="byte-next" disabled={!canGoNext} onClick={advance} style={canGoBack ? { marginTop: 0 } : undefined}>
                          {canGoNext ? <>Next task <ArrowRight size={16} /></> : <>Locked <Lock size={15} /></>}
                        </button>
                      </div>
                    </div>
                  )}

                  {tab === 'glossary' && (
                    <div className="byte-fade">
                      <p className="byte-gloss-intro">Plain-word meanings for the jargon in this lab. The tag is the quick idea; the line under it is the fuller explanation.</p>
                      {GLOSSARY.map((g) => (
                        <div key={g.term} className="byte-gterm">
                          <div className="byte-gterm-h"><b>{g.term}</b> <span>{g.one}</span></div>
                          <div className="byte-gterm-d">{g.long}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </>
            )}

            <div className="byte-foot">
              <button className="byte-foot-btn" onClick={resetLab} title="Restart the whole lab from the beginning">
                <RefreshCw size={13} /> Restart lab
              </button>
              <span className="byte-foot-host">{LAB_META.host}</span>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

function appName(app) {
  return ({ files: 'Files app', terminal: 'Terminal', security: 'OmniGuard',
    intel: 'Threat Lookup', pe: 'PE Inspector', report: 'Triage Report' })[app] || 'app';
}

/* A collapsible step: command always visible, ⓘ reveals what/why. */
function StepRow({ step, num }) {
  const [open, setOpen] = useState(false);
  const hasDetail = !!(step.what || step.why);
  return (
    <div className={`byte-step ${open ? 'open' : ''}`}>
      <div className="byte-step-num">{num}</div>
      <div className="byte-step-main">
        <div className="byte-step-cmdrow">
          <span className="byte-step-cmd"><Play size={11} /> {step.cmd}</span>
          {hasDetail && (
            <button className="byte-cmd-info" onClick={() => setOpen((o) => !o)} aria-expanded={open}
              title={open ? 'Hide explanation' : 'What does this do?'}>
              <Info size={14} /><ChevronDown size={13} className="byte-cmd-chev" />
            </button>
          )}
        </div>
        {open && hasDetail && (
          <div className="byte-fade" style={{ display: 'flex', flexDirection: 'column', gap: 7, marginTop: 7 }}>
            {step.what && <p className="byte-step-what"><span className="byte-step-tag">What it does</span> {step.what}</p>}
            {step.why && <p className="byte-step-why"><span className="byte-step-tag why">Why it matters</span> {step.why}</p>}
          </div>
        )}
      </div>
    </div>
  );
}

/* Two-page intro: Byte (robot) then the team. */
function Intro({ onStart }) {
  const [page, setPage] = useState(0);
  return page === 0
    ? <ByteIntroPage onNext={() => setPage(1)} />
    : <TeamIntroPage onBack={() => setPage(0)} onStart={onStart} />;
}

function ByteIntroPage({ onNext }) {
  const [shown, setShown] = useState(1);
  const lines = BYTE_INTRO.byteLines;
  const endRef = useRef(null);
  const allShown = shown >= lines.length;
  useEffect(() => {
    if (shown >= lines.length) return;
    const t = setTimeout(() => setShown((n) => n + 1), 900);
    return () => clearTimeout(t);
  }, [shown, lines.length]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, [shown]);
  return (
    <div className="byte-body">
      <div className="byte-area">👋 Meet Byte, your guide</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, margin: '4px 0 14px' }}>
        {lines.slice(0, shown).map((t, i) => (
          <div key={i} className="byte-fade" style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <ByteAvatar size={30} speaking={i === shown - 1} />
            <div>
              <div className="byte-line-name" style={{ color: 'var(--accent)' }}>Byte</div>
              <div className="byte-line-bubble" dangerouslySetInnerHTML={{ __html: t }} />
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>
      {!allShown && <button className="byte-hint-toggle" onClick={() => setShown(lines.length)}>Skip ahead</button>}
      {allShown && <button className="byte-next byte-fade" onClick={onNext} style={{ marginTop: 8 }}>Meet the team <ArrowRight size={16} /></button>}
    </div>
  );
}

function TeamIntroPage({ onBack, onStart }) {
  const [shown, setShown] = useState(1);
  const team = BYTE_INTRO.team;
  const endRef = useRef(null);
  const allShown = shown >= team.length;
  useEffect(() => {
    if (shown >= team.length) return;
    const t = setTimeout(() => setShown((n) => n + 1), 760);
    return () => clearTimeout(t);
  }, [shown, team.length]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, [shown]);
  return (
    <div className="byte-body byte-fade">
      <div className="byte-area">🧑‍💻 Meet your team</div>
      <p className="byte-brief">The colleagues you’ll work with on this case — each owns part of the investigation.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, margin: '4px 0 14px' }}>
        {team.slice(0, shown).map((ln, i) => (
          <div key={i} className="byte-fade" style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <CastPhoto id={ln.s} size={34} speaking={i === shown - 1} />
            <div>
              <div className="byte-line-name" style={{ color: CHARACTERS[ln.s].color }}>
                {CHARACTERS[ln.s].name} · <span style={{ color: 'var(--txt-3)', fontWeight: 600 }}>{CHARACTERS[ln.s].role}</span>
              </div>
              <div className="byte-line-bubble">{ln.t}</div>
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>
      {!allShown && <button className="byte-hint-toggle" onClick={() => setShown(team.length)}>Show everyone</button>}
      {allShown && (
        <div className="byte-nav byte-fade">
          <button className="byte-back" onClick={onBack}><ArrowLeft size={16} /> Back</button>
          <button className="byte-next" onClick={onStart} style={{ marginTop: 0 }}>Start the investigation <ArrowRight size={16} /></button>
        </div>
      )}
    </div>
  );
}

function Summary({ resetLab }) {
  return (
    <div className="byte-body byte-fade">
      <div className="byte-trophy"><Trophy size={28} color="#04140f" /></div>
      <div className="byte-area" style={{ textAlign: 'center', color: 'var(--good)' }}>Investigation complete</div>
      <h3 className="byte-summary-title">{SUMMARY.passTitle}</h3>
      <p className="byte-summary-body">{SUMMARY.passBody}</p>

      <div className="byte-report">
        <div className="byte-report-head">Indicators of Compromise</div>
        {SUMMARY.iocs.map((i) => (
          <div key={i.k} className="byte-report-row">
            <div className="byte-report-k">{i.k}</div>
            <div className="byte-report-v">{i.v}</div>
          </div>
        ))}
      </div>

      <div className="byte-outcomes-title">{SUMMARY.outcomesTitle}</div>
      <ul className="byte-outcomes">
        {LEARNING_OUTCOMES.map((o, i) => <li key={i}><Check size={13} color="var(--good)" /> {o}</li>)}
      </ul>

      <div className="byte-cast-row">
        {['elena', 'marcus', 'priya', 'david', 'auditor'].map((id) => <CastPhoto key={id} id={id} size={34} />)}
      </div>
      <p className="byte-team-note">Your incident-response team — nicely done.</p>

      <button className="byte-next ghost" onClick={resetLab}><RotateCcw size={15} /> Restart lab</button>
      <p className="byte-disclaimer">{DISCLAIMER}</p>
    </div>
  );
}

const BYTE_CSS = `
.byte-root{position:fixed;left:auto;right:16px;top:16vh;bottom:auto;z-index:600;width:auto}
.byte-launcher{position:relative;border:none;background:transparent;cursor:grab;padding:0;border-radius:50%;filter:drop-shadow(0 8px 24px rgba(0,0,0,.5));touch-action:none}
.byte-launcher:active{cursor:grabbing}
.byte-launch-badge{position:absolute;bottom:-2px;right:-4px;background:var(--accent-2);color:#fff;font-size:11px;font-weight:800;border-radius:999px;padding:2px 7px;border:2px solid var(--bg-0)}
.byte-panel{position:relative;width:384px;max-width:calc(100vw - 32px);max-height:min(78vh,720px);display:flex;flex-direction:column;background:var(--glass-2);backdrop-filter:blur(20px);border:1px solid var(--line-2);border-radius:16px;box-shadow:0 24px 70px rgba(0,0,0,.6);overflow:hidden;animation:byteIn .2s ease}
@keyframes byteIn{from{opacity:0;transform:translateY(16px) scale(.98)}to{opacity:1;transform:none}}
.byte-head{display:flex;align-items:center;gap:11px;padding:12px 14px;background:linear-gradient(135deg,rgba(124,108,240,.22),rgba(34,211,179,.06));border-bottom:1px solid var(--line);cursor:grab;user-select:none;touch-action:none}
.byte-head:active{cursor:grabbing}
.byte-grip{color:var(--txt-3);display:grid;place-items:center;flex-shrink:0}
.byte-title{font-size:13.5px;font-weight:800}
.byte-sub{font-size:11.5px;color:var(--txt-2);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.byte-x{border:none;background:transparent;color:var(--txt-2);cursor:pointer;width:30px;height:30px;border-radius:8px;display:grid;place-items:center}
.byte-x:hover{background:var(--bg-3s);color:var(--txt-0)}
.byte-progress{display:flex;gap:4px;padding:11px 14px 0}
.byte-pip{flex:1;height:5px;border-radius:999px;background:var(--bg-4)}
.byte-pip.done{background:var(--good)}
.byte-pip.cur{background:var(--accent)}
.byte-tabs{display:flex;gap:4px;padding:12px 14px 0}
.byte-tabs button{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;padding:8px;border:none;border-radius:8px;background:var(--bg-3s);color:var(--txt-2);font-weight:700;font-size:12.5px;cursor:pointer}
.byte-tabs button.on{background:var(--accent-soft);color:var(--txt-0)}
.byte-body{padding:14px;overflow-y:auto;flex:1 1 auto;min-height:0}
.byte-fade{animation:fadeUp .25s ease both}
.byte-area{font-size:11px;font-weight:800;letter-spacing:.8px;text-transform:uppercase;color:var(--accent);margin-bottom:8px}
.byte-speaker{display:flex;align-items:center;gap:9px;font-size:12px;color:var(--txt-2);margin-bottom:10px}
.byte-brief{font-size:13.5px;line-height:1.6;color:var(--txt-1);margin:0 0 12px}
.byte-brief b{color:var(--txt-0);font-weight:700}
.byte-brief i{color:var(--accent);font-style:normal;font-weight:600}
.byte-stage{font-size:11.5px;line-height:1.5;color:var(--txt-2);background:var(--violet-soft);border:1px solid rgba(124,108,240,.28);border-radius:8px;padding:8px 11px;margin-bottom:12px}
.byte-tool{background:var(--bg-2);border:1px solid var(--line);border-radius:9px;padding:10px 12px;margin:0 0 12px}
.byte-tool-h{display:flex;align-items:center;gap:7px;font-size:10.5px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;color:var(--accent-2);margin-bottom:5px}
.byte-tool-h svg{flex-shrink:0}
.byte-tool-t{font-size:12px;line-height:1.55;color:var(--txt-2)}
.byte-goal{background:var(--bg-3s);border:1px solid var(--line);border-left:3px solid var(--accent);border-radius:8px;padding:11px 13px;font-size:13px;color:var(--txt-1);line-height:1.5}
.byte-goal-label{font-size:10.5px;font-weight:800;letter-spacing:.6px;text-transform:uppercase;color:var(--accent);margin-bottom:4px}
.byte-open-app{display:inline-flex;align-items:center;gap:7px;margin-top:12px;width:100%;justify-content:center;padding:9px;border:1px solid rgba(124,108,240,.4);border-radius:9px;background:var(--violet-soft);color:#b3a9f7;font-weight:700;font-size:12.5px;cursor:pointer}
.byte-open-app:hover{background:rgba(124,108,240,.24)}
.byte-hint-toggle{display:inline-flex;align-items:center;gap:7px;margin-top:11px;background:transparent;border:none;color:var(--accent);font-weight:600;font-size:12.5px;cursor:pointer;padding:0}
.byte-tip{display:flex;align-items:flex-start;gap:8px;font-size:11.5px;line-height:1.5;color:var(--txt-2);background:var(--accent-soft);border:1px solid rgba(34,211,179,.25);border-radius:8px;padding:9px 11px;margin:10px 0 0}
.byte-tip svg{color:var(--accent);flex-shrink:0;margin-top:1px}
.byte-tip b{color:var(--txt-0)}
.byte-steps{margin-top:10px;display:flex;flex-direction:column;gap:8px}
.byte-step{display:flex;gap:10px;align-items:flex-start;background:var(--bg-2);border:1px solid var(--line);border-radius:10px;padding:10px 11px}
.byte-step.open{border-color:var(--line-2)}
.byte-step-num{flex-shrink:0;width:20px;height:20px;border-radius:50%;background:var(--accent);color:#04140f;font-size:11.5px;font-weight:800;display:grid;place-items:center;margin-top:1px}
.byte-step-main{flex:1;min-width:0}
.byte-step-cmdrow{display:flex;align-items:stretch;gap:6px}
.byte-step-cmd{flex:1;display:inline-flex;align-items:center;gap:7px;font-family:var(--mono);font-size:12px;color:#8fe0d2;background:rgba(0,0,0,.3);border:1px solid rgba(255,255,255,.07);border-radius:6px;padding:7px 9px;line-height:1.4;word-break:break-word}
.byte-step-cmd svg{color:var(--accent);flex-shrink:0}
.byte-cmd-info{flex-shrink:0;display:inline-flex;align-items:center;gap:2px;padding:0 8px;border-radius:6px;border:1px solid var(--line);background:var(--bg-2);color:var(--txt-2);cursor:pointer;transition:border-color .14s,color .14s,background .14s}
.byte-cmd-info:hover{border-color:var(--accent);color:var(--accent);background:var(--bg-3s)}
.byte-cmd-chev{transition:transform .18s ease}
.byte-step.open .byte-cmd-info{border-color:var(--accent);color:var(--accent);background:var(--accent-soft)}
.byte-step.open .byte-cmd-chev{transform:rotate(180deg)}
.byte-step-what,.byte-step-why{margin:0;font-size:12px;line-height:1.5;color:var(--txt-1)}
.byte-step-why{color:var(--txt-2)}
.byte-step-tag{display:inline-block;font-size:9.5px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;color:var(--accent);background:var(--accent-soft);border-radius:4px;padding:1px 6px;margin-right:6px;vertical-align:1px}
.byte-step-tag.why{color:var(--warn);background:rgba(245,158,11,.12)}
.byte-status{display:flex;align-items:flex-start;gap:8px;margin-top:14px;padding:11px 13px;border-radius:8px;font-size:12.5px;line-height:1.5;background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.22);color:var(--warn)}
.byte-status.ok{background:rgba(52,211,153,.08);border-color:rgba(52,211,153,.25);color:var(--good)}
.byte-status svg{flex-shrink:0;margin-top:1px}
.byte-nav{display:flex;gap:8px;margin-top:14px;align-items:stretch}
.byte-next{flex:1;display:flex;align-items:center;justify-content:center;gap:8px;padding:12px;border:none;border-radius:10px;background:var(--accent);color:#04140f;font-weight:800;font-size:14px;cursor:pointer}
.byte-next:hover:not(:disabled){filter:brightness(1.07)}
.byte-next:disabled{background:var(--bg-4);color:var(--txt-3);cursor:not-allowed}
.byte-next.ghost{background:transparent;border:1px solid var(--line-2);color:var(--txt-1);margin-top:14px}
.byte-back{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:12px 14px;border:1px solid var(--line-2);border-radius:10px;background:var(--bg-3s);color:var(--txt-1);font-weight:700;font-size:14px;cursor:pointer;flex-shrink:0}
.byte-back:hover{background:var(--bg-4);border-color:var(--accent);color:var(--txt-0)}
.byte-back svg{color:var(--accent)}
.byte-line-name{font-size:11.5px;font-weight:700;margin-bottom:3px}
.byte-line-bubble{font-size:13px;line-height:1.5;color:var(--txt-1);background:var(--bg-3s);border:1px solid var(--line);border-radius:3px 11px 11px 11px;padding:9px 12px;display:inline-block}
.byte-line-bubble b{color:var(--txt-0)}
.byte-gloss-intro{font-size:12px;color:var(--txt-2);line-height:1.6;margin:0 0 12px}
.byte-gterm{border-bottom:1px solid var(--line);padding:10px 0}
.byte-gterm:last-child{border-bottom:none}
.byte-gterm-h{font-size:13px;color:var(--txt-0)}
.byte-gterm-h b{font-weight:700}
.byte-gterm-h span{font-size:10.5px;font-weight:700;color:var(--accent);background:var(--accent-soft);border-radius:5px;padding:1px 7px;margin-left:8px}
.byte-gterm-d{font-size:12px;color:var(--txt-2);line-height:1.5;margin-top:4px}
.byte-trophy{width:54px;height:54px;border-radius:50%;background:var(--good);display:grid;place-items:center;margin:4px auto 12px}
.byte-summary-title{font-size:17px;font-weight:800;text-align:center;margin:0 0 8px}
.byte-summary-body{font-size:12.5px;color:var(--txt-2);line-height:1.6;text-align:center;margin:0 0 16px}
.byte-report{background:var(--bg-2);border:1px solid var(--line);border-radius:10px;overflow:hidden;margin-bottom:16px}
.byte-report-head{font-size:11px;font-weight:800;letter-spacing:.6px;text-transform:uppercase;color:var(--txt-3);padding:10px 13px;border-bottom:1px solid var(--line)}
.byte-report-row{display:flex;gap:10px;padding:9px 13px;border-bottom:1px solid var(--line);font-size:12px}
.byte-report-row:last-child{border-bottom:none}
.byte-report-k{color:var(--txt-2);width:120px;flex-shrink:0}
.byte-report-v{color:var(--txt-0);font-family:var(--mono);font-size:11.5px;word-break:break-all}
.byte-outcomes-title{font-size:12.5px;font-weight:700;margin-bottom:8px}
.byte-outcomes{list-style:none;padding:0;margin:0 0 16px;display:flex;flex-direction:column;gap:6px}
.byte-outcomes li{display:flex;gap:8px;align-items:flex-start;font-size:12.5px;color:var(--txt-1);line-height:1.5}
.byte-outcomes li svg{flex-shrink:0;margin-top:3px}
.byte-cast-row{display:flex;justify-content:center;gap:7px;margin-top:6px}
.byte-team-note{text-align:center;font-size:11.5px;color:var(--txt-3);margin:8px 0 12px}
.byte-disclaimer{font-size:10.5px;color:var(--txt-3);line-height:1.5;text-align:center;margin-top:14px;border-top:1px solid var(--line);padding-top:12px}
.byte-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 14px;border-top:1px solid var(--line);background:var(--bg-0)}
.byte-foot-btn{display:inline-flex;align-items:center;gap:7px;background:var(--bg-3s);border:1px solid var(--line-2);color:var(--txt-1);font-size:12px;font-weight:600;padding:7px 12px;border-radius:8px;cursor:pointer}
.byte-foot-btn:hover{background:var(--bg-4);color:var(--txt-0)}
.byte-foot-btn svg{color:var(--accent)}
.byte-foot-host{font-family:var(--mono);font-size:10.5px;color:var(--txt-3)}
`;
