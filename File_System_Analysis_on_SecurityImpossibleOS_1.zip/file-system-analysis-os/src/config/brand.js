// Brand *data* (no JSX) — kept separate from branding.jsx so plain-JS modules
// (platform config, reducer, tests) can import it without pulling in React.

export const BRANDING = {
  company: 'Security Impossible',
  product: 'Security Impossible OS',
  productShort: 'SI OS',
  edition: 'Enterprise Workstation',
  version: '1.0',
  build: '2026.7',
  tagline: 'Engineered secure. Impossible to compromise.',
  supportUrl: 'https://securityimpossible.local/support',
  colors: {
    primary: '#3ea6ff',
    secondary: '#7c5cff',
    glow: 'rgba(62, 166, 255, 0.28)',
  },
};

export function copyrightLine() {
  const year = new Date().getFullYear();
  return `© ${year} ${BRANDING.company}. All rights reserved.`;
}
