import * as FS from '../core/fs.js';
import { BRANDING } from './brand.js';

// ===========================================================================
// PLATFORM CONFIG — the default, lab-agnostic configuration of the OS.
//
// A lab package can override any of these (profile, settings, desktop icons,
// taskbar, extra apps, files). With NO lab loaded, these values alone produce
// a clean, usable Security Impossible OS desktop.
// ===========================================================================

// Default persistence key. A lab MUST define its own `storeKey` so progress
// from different labs never collides; this is only the fallback.
export const PLATFORM_STORE_KEY = 'security-impossible-os.platform.v1';

export const TASKBAR_HEIGHT = 48;

// Default user profile (a lab may override this to present a persona).
export const DEFAULT_PROFILE = {
  name: 'SI User',
  username: 'SIUser',
  role: 'Security Analyst',
  email: 'analyst@securityimpossible.com',
  hostname: 'SI-WS-0001',
  domain: 'securityimpossible.local',
  // Lock-screen hint; blank also accepted (kiosk-friendly for training).
  password: 'si',
};

export const WALLPAPERS = [
  {
    id: 'si-aurora',
    name: 'SI Aurora (default)',
    css: `radial-gradient(120% 90% at 15% 90%, rgba(62, 166, 255, 0.5) 0%, transparent 55%),
          radial-gradient(110% 80% at 85% 15%, rgba(124, 92, 255, 0.42) 0%, transparent 55%),
          radial-gradient(90% 70% at 70% 85%, rgba(6, 182, 212, 0.28) 0%, transparent 50%),
          linear-gradient(160deg, #0b1220 0%, #101a30 45%, #0a0f1e 100%)`,
  },
  {
    id: 'midnight',
    name: 'Midnight',
    css: `radial-gradient(100% 80% at 80% 80%, rgba(219, 39, 119, 0.32) 0%, transparent 55%),
          radial-gradient(100% 90% at 20% 20%, rgba(79, 70, 229, 0.5) 0%, transparent 60%),
          linear-gradient(200deg, #140b22 0%, #1a1030 50%, #0d0a1a 100%)`,
  },
  {
    id: 'ember',
    name: 'Ember',
    css: `radial-gradient(110% 85% at 20% 85%, rgba(234, 88, 12, 0.4) 0%, transparent 55%),
          radial-gradient(100% 80% at 85% 20%, rgba(190, 24, 93, 0.35) 0%, transparent 55%),
          linear-gradient(170deg, #190d0d 0%, #221018 55%, #120a0e 100%)`,
  },
  {
    id: 'graphite',
    name: 'Graphite',
    css: `radial-gradient(120% 90% at 50% 0%, rgba(100, 116, 139, 0.28) 0%, transparent 60%),
          linear-gradient(180deg, #16181d 0%, #101216 100%)`,
  },
  {
    id: 'sentinel',
    name: 'Sentinel',
    css: `radial-gradient(110% 85% at 80% 85%, rgba(5, 150, 105, 0.36) 0%, transparent 55%),
          radial-gradient(100% 80% at 15% 15%, rgba(13, 148, 136, 0.32) 0%, transparent 55%),
          linear-gradient(165deg, #071410 0%, #0c1c17 55%, #060f0c 100%)`,
  },
];

export const ACCENTS = [
  { id: 'sky', name: 'Sky', color: BRANDING.colors.primary },
  { id: 'violet', name: 'Violet', color: '#a78bfa' },
  { id: 'emerald', name: 'Emerald', color: '#34d399' },
  { id: 'amber', name: 'Amber', color: '#fbbf24' },
  { id: 'rose', name: 'Rose', color: '#fb7185' },
];

export const DEFAULT_SETTINGS = {
  wallpaperId: 'si-aurora',
  accentId: 'sky',
  theme: 'dark',
  showHidden: false,
};

// Desktop icons rendered by the shell. `special` items are handled by the
// desktop (This PC / Recycle Bin); `app` items launch an app. Labs can append
// their own via `desktopShortcuts`.
export const DEFAULT_DESKTOP_ICONS = [
  { id: 'this-pc', type: 'special', special: 'this-pc', label: 'This PC' },
  { id: 'recycle-bin', type: 'special', special: 'recycle-bin', label: 'Recycle Bin' },
  { id: 'd-explorer', type: 'app', appId: 'explorer', label: 'File Explorer' },
  { id: 'd-help', type: 'app', appId: 'help', label: 'Help' },
];

// Default taskbar pins and Start-menu pins (app ids). Anything present in the
// app registry can be pinned; unknown ids are ignored.
export const DEFAULT_TASKBAR_PINS = ['explorer', 'browser', 'texteditor', 'taskmgr', 'settings'];
export const DEFAULT_START_PINS = [
  'explorer', 'browser', 'texteditor', 'calculator', 'taskmgr',
  'eventvwr', 'security', 'terminal', 'sysinfo', 'imageviewer', 'settings', 'help',
];

// Builds the standard Windows-like folder tree + a couple of welcome files for
// the given profile. Labs receive the resulting tree and add their own files.
export function buildBaseFs(profile, now = 0) {
  let fs = FS.createRoot();
  const home = `C:/Users/${profile.username}`;
  const mk = (p, meta) => { fs = FS.mkdir(fs, p, { now, ...meta }); };
  const w = (p, content, meta) => { fs = FS.writeFile(fs, p, content, { now, ...meta }); };

  [
    'C:', 'C:/Windows', 'C:/Windows/System32', 'C:/Windows/System32/drivers/etc',
    'C:/Windows/System32/config', 'C:/Windows/Temp', 'C:/Program Files',
    'C:/Program Files/Security Impossible', 'C:/Users',
    home, `${home}/Desktop`, `${home}/Documents`, `${home}/Downloads`,
    `${home}/Pictures`, `${home}/Music`, `${home}/Videos`,
    `${home}/AppData`, `${home}/AppData/Local`, `${home}/AppData/Local/Temp`, `${home}/AppData/Roaming`,
  ].forEach((p) => mk(p, { system: p.startsWith('C:/Windows') || p.startsWith('C:/Program Files') }));

  w(`${home}/Desktop/Welcome.txt`,
    `Welcome to ${BRANDING.product}.\n\n${BRANDING.tagline}\n\n` +
    `This is your workspace. Explore the Start menu, open File Explorer, and\n` +
    `use the built-in tools. Open Help for a quick tour.`,
    { now });
  w(`${home}/Documents/Getting Started.txt`,
    `${BRANDING.product} — Getting Started\n\n` +
    `• Start menu (bottom-left) launches apps and searches files.\n` +
    `• Windows can be dragged, resized, minimized and maximized.\n` +
    `• Right-click the desktop or files for context menus.\n` +
    `• Settings lets you change wallpaper, accent and theme.\n`,
    { now });

  return fs;
}
