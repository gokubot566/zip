import React from 'react';
import { BRANDING, copyrightLine } from './brand.js';

// ===========================================================================
// BRANDING — the Security Impossible identity (logo components + re-exports).
//
// Brand *data* lives in brand.js (no JSX) so non-React modules can read it.
// This file adds the logo artwork and re-exports the data for convenience, so
// existing `import { BRANDING } from './branding.jsx'` keeps working.
// ===========================================================================

export { BRANDING, copyrightLine };

// --- logo marks (original artwork — an interlocked "impossible" shield) ----

export function LogoMark({ size = 28, glow = false }) {
  const id = React.useId();
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden style={glow ? { filter: `drop-shadow(0 0 10px ${BRANDING.colors.glow})` } : undefined}>
      <defs>
        <linearGradient id={`si-${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={BRANDING.colors.primary} />
          <stop offset="1" stopColor={BRANDING.colors.secondary} />
        </linearGradient>
      </defs>
      {/* shield */}
      <path
        d="M24 3 L41 9 V23 C41 34 33 41.5 24 45 C15 41.5 7 34 7 23 V9 Z"
        fill={`url(#si-${id})`}
        opacity="0.16"
        stroke={`url(#si-${id})`}
        strokeWidth="1.6"
      />
      {/* interlocked S / I forming an "impossible" knot */}
      <path
        d="M30 16 C30 13.5 27.5 12 24 12 C20 12 17.5 14 17.5 17 C17.5 20.5 21 21.5 24 22.5 C27 23.5 30.5 24.5 30.5 28 C30.5 31.5 27.5 33.5 23.5 33.5 C20 33.5 17.5 32 17.5 29.5"
        stroke={`url(#si-${id})`}
        strokeWidth="3"
        strokeLinecap="round"
        fill="none"
      />
      <circle cx="24" cy="23" r="2.4" fill={BRANDING.colors.primary} />
    </svg>
  );
}

// Full lockup: mark + wordmark, used on boot / login / about.
export function LogoLockup({ size = 34, subtitle }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <LogoMark size={size} glow />
      <div style={{ lineHeight: 1.1 }}>
        <div style={{ fontSize: size * 0.5, fontWeight: 600, letterSpacing: 0.3 }}>
          Security<span style={{ color: BRANDING.colors.primary }}>Impossible</span>
        </div>
        {subtitle && <div style={{ fontSize: size * 0.3, color: 'var(--text-tertiary)', marginTop: 2 }}>{subtitle}</div>}
      </div>
    </div>
  );
}
