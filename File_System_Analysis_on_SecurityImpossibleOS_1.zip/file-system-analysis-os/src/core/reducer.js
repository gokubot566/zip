import * as FS from './fs.js';
import { uid, clamp } from './utils.js';
import { TASKBAR_HEIGHT } from '../config/platform.js';

// ===========================================================================
// The OS state engine. It is entirely lab-agnostic.
//
// A `seed` (built by OSContext from the platform config + the active lab)
// provides the initial profile, file tree, and generic `data` bag. The reducer
// never interprets lab meaning — it only tracks generic OS facts:
//   • data     : read-only content surfaced to apps (mail, processes, events…)
//   • activity : generic record of what the user did (opened files, ended
//                processes, ran scans, isolated the network…). Labs read this
//                to derive their own progress; the OS assigns it no meaning.
//   • labState : an opaque bag a lab's own apps can persist into.
// ===========================================================================

export function createInitialState(seed) {
  return {
    session: { booted: false, loggedIn: false, locked: false },
    profile: seed.profile,
    fs: seed.fs,
    data: seed.data ?? {},
    windows: [],
    zTop: 10,
    focusedId: null,
    toasts: [],
    notifications: seed.notifications ?? [],
    settings: { ...seed.settings },
    recycleBin: [], // [{ id, node, originalPath, deletedAt }]
    // Generic usage telemetry — labs derive progress from this.
    activity: {
      openedFiles: [],
      openedApps: [],
      viewed: [],
      killedProcesses: [],
      disabledStartup: [],
      quarantined: [],
      networkIsolated: false,
      scans: 0,
    },
    labState: {}, // opaque per-lab app state
    meta: { startedAt: seed.now ?? 0, labId: seed.labId ?? null },
  };
}

// Slices safe/useful to persist across refreshes. `data` and `profile` are
// re-derived from the active lab on load, so they are intentionally omitted.
export function serialize(state) {
  return {
    v: 2,
    labId: state.meta.labId,
    session: state.session,
    fs: state.fs,
    settings: state.settings,
    recycleBin: state.recycleBin,
    notifications: state.notifications,
    activity: state.activity,
    labState: state.labState,
    windows: state.windows,
    zTop: state.zTop,
    focusedId: state.focusedId,
    meta: state.meta,
  };
}

export function hydrate(seed, saved) {
  const base = createInitialState(seed);
  // Only restore a save that belongs to the same lab (store keys already
  // separate labs, but this guards a stale/foreign payload).
  if (!saved || saved.v !== 2 || saved.labId !== base.meta.labId) return base;
  return {
    ...base,
    session: { ...base.session, ...saved.session },
    fs: saved.fs ?? base.fs,
    settings: { ...base.settings, ...saved.settings },
    recycleBin: saved.recycleBin ?? [],
    notifications: saved.notifications ?? base.notifications,
    activity: { ...base.activity, ...saved.activity },
    labState: saved.labState ?? {},
    windows: saved.windows ?? [],
    zTop: saved.zTop ?? base.zTop,
    focusedId: saved.focusedId ?? null,
    meta: saved.meta ?? base.meta,
  };
}

// --- window geometry -------------------------------------------------------

function cascadeOffset(count) {
  return (count % 8) * 28;
}

function defaultBounds(app, index, viewport) {
  const vw = viewport?.w ?? 1280;
  const vh = (viewport?.h ?? 800) - TASKBAR_HEIGHT;
  const w = clamp(app.defaultSize?.w ?? 820, 320, vw - 40);
  const h = clamp(app.defaultSize?.h ?? 560, 240, vh - 20);
  const off = cascadeOffset(index);
  const x = clamp(80 + off, 8, Math.max(8, vw - w - 8));
  const y = clamp(48 + off, 8, Math.max(8, vh - h - 8));
  return { x, y, w, h };
}

// --- reducer ---------------------------------------------------------------

export function reducer(state, action) {
  switch (action.type) {
    // session
    case 'BOOT_DONE': return { ...state, session: { ...state.session, booted: true } };
    case 'LOGIN': return { ...state, session: { ...state.session, loggedIn: true, locked: false } };
    case 'LOCK': return { ...state, session: { ...state.session, locked: true } };
    case 'UNLOCK': return { ...state, session: { ...state.session, locked: false } };
    case 'LOGOUT': return { ...state, session: { ...state.session, loggedIn: false, locked: false }, windows: [], focusedId: null };

    // windows
    case 'OPEN_WINDOW': {
      const { app, args, viewport } = action;
      if (app.singleton) {
        const existing = state.windows.find((w) => w.appId === app.id);
        if (existing) return focus(unminimize(state, existing.id), existing.id);
      }
      const z = state.zTop + 1;
      const win = {
        id: uid('win'),
        appId: app.id,
        title: app.name,
        args: args ?? null,
        ...defaultBounds(app, state.windows.length, viewport),
        z,
        minimized: false,
        maximized: !!app.startMaximized,
        modal: !!app.modal,
      };
      const openedApps = [app.id, ...state.activity.openedApps.filter((a) => a !== app.id)].slice(0, 12);
      return { ...state, windows: [...state.windows, win], zTop: z, focusedId: win.id, activity: { ...state.activity, openedApps } };
    }
    case 'CLOSE_WINDOW': {
      const windows = state.windows.filter((w) => w.id !== action.id);
      const focusedId = state.focusedId === action.id
        ? windows.filter((w) => !w.minimized).sort((a, b) => b.z - a.z)[0]?.id ?? null
        : state.focusedId;
      return { ...state, windows, focusedId };
    }
    case 'FOCUS_WINDOW': return focus(state, action.id);
    case 'MINIMIZE_WINDOW': {
      const windows = state.windows.map((w) => (w.id === action.id ? { ...w, minimized: true } : w));
      const focusedId = windows.filter((w) => !w.minimized).sort((a, b) => b.z - a.z)[0]?.id ?? null;
      return { ...state, windows, focusedId };
    }
    case 'TOGGLE_MINIMIZE': {
      const win = state.windows.find((w) => w.id === action.id);
      if (!win) return state;
      if (win.minimized) return focus(unminimize(state, action.id), action.id);
      if (state.focusedId === action.id) {
        const windows = state.windows.map((w) => (w.id === action.id ? { ...w, minimized: true } : w));
        const focusedId = windows.filter((w) => !w.minimized).sort((a, b) => b.z - a.z)[0]?.id ?? null;
        return { ...state, windows, focusedId };
      }
      return focus(state, action.id);
    }
    case 'TOGGLE_MAXIMIZE':
      return { ...state, windows: state.windows.map((w) => (w.id === action.id ? { ...w, maximized: !w.maximized } : w)) };
    case 'SET_BOUNDS':
      return { ...state, windows: state.windows.map((w) => (w.id === action.id ? { ...w, ...action.bounds } : w)) };
    case 'SET_WINDOW_TITLE':
      return { ...state, windows: state.windows.map((w) => (w.id === action.id ? { ...w, title: action.title } : w)) };
    case 'SET_WINDOW_ARGS':
      return { ...state, windows: state.windows.map((w) => (w.id === action.id ? { ...w, args: action.args } : w)) };

    // filesystem
    case 'FS_WRITE': return { ...state, fs: FS.writeFile(state.fs, action.path, action.content, action.meta) };
    case 'FS_MKDIR': return { ...state, fs: FS.mkdir(state.fs, action.path, action.meta) };
    case 'FS_RENAME': return { ...state, fs: FS.renameNode(state.fs, action.path, action.newName) };
    case 'FS_MOVE': return { ...state, fs: FS.moveNode(state.fs, action.from, action.toDir) };
    case 'FS_COPY': {
      const node = FS.getNode(state.fs, action.path);
      if (!node) return state;
      return { ...state, fs: FS.insertNode(state.fs, action.toDir, node) };
    }
    case 'FS_DELETE': {
      const { root, removed } = FS.removeNode(state.fs, action.path);
      if (!removed) return state;
      return {
        ...state,
        fs: root,
        recycleBin: [{ id: uid('bin'), node: removed, originalPath: FS.normalizePath(action.path), deletedAt: action.now ?? 0 }, ...state.recycleBin],
      };
    }
    case 'FS_RESTORE': {
      const entry = state.recycleBin.find((e) => e.id === action.id);
      if (!entry) return state;
      const fs = FS.insertNode(state.fs, FS.parentPath(entry.originalPath), entry.node, { rename: entry.node.name });
      return { ...state, fs, recycleBin: state.recycleBin.filter((e) => e.id !== action.id) };
    }
    case 'FS_BIN_DELETE': return { ...state, recycleBin: state.recycleBin.filter((e) => e.id !== action.id) };
    case 'FS_EMPTY_BIN': return { ...state, recycleBin: [] };

    // notifications
    case 'NOTIFY': {
      const note = {
        id: uid('note'),
        title: action.title ?? 'Notification',
        body: action.body ?? '',
        appId: action.appId ?? null,
        variant: action.variant ?? 'info',
        time: action.now ?? 0,
        read: false,
      };
      return {
        ...state,
        toasts: [{ ...note, duration: action.duration ?? 6000 }, ...state.toasts].slice(0, 4),
        notifications: [note, ...state.notifications].slice(0, 60),
      };
    }
    case 'DISMISS_TOAST': return { ...state, toasts: state.toasts.filter((t) => t.id !== action.id) };
    case 'MARK_NOTIFICATIONS_READ': return { ...state, notifications: state.notifications.map((n) => ({ ...n, read: true })) };
    case 'REMOVE_NOTIFICATION': return { ...state, notifications: state.notifications.filter((n) => n.id !== action.id) };
    case 'CLEAR_NOTIFICATIONS': return { ...state, notifications: [] };

    // settings
    case 'SET_SETTING': return { ...state, settings: { ...state.settings, [action.key]: action.value } };

    // --- generic activity / OS operations (labs interpret these) ----------
    case 'RECORD_OPEN_FILE':
      return withActivity(state, { openedFiles: addUnique(state.activity.openedFiles, action.path, 40) });
    case 'RECORD_ACTIVITY':
      return withActivity(state, { viewed: addUnique(state.activity.viewed, action.token, 200) });
    case 'KILL_PROCESS':
      return withActivity(state, { killedProcesses: addUnique(state.activity.killedProcesses, action.pid) });
    case 'TOGGLE_STARTUP': {
      const set = new Set(state.activity.disabledStartup);
      set.has(action.id) ? set.delete(action.id) : set.add(action.id);
      return withActivity(state, { disabledStartup: [...set] });
    }
    case 'QUARANTINE_THREATS': {
      const ids = Array.isArray(action.ids) ? action.ids : [action.ids];
      return withActivity(state, { quarantined: [...new Set([...state.activity.quarantined, ...ids])] });
    }
    case 'SET_NETWORK_ISOLATED': return withActivity(state, { networkIsolated: action.value });
    case 'RECORD_SCAN': return withActivity(state, { scans: state.activity.scans + 1 });

    // --- opaque lab-app state ---------------------------------------------
    case 'SET_LAB_STATE': return { ...state, labState: { ...state.labState, [action.key]: action.value } };
    case 'MERGE_LAB_STATE': return { ...state, labState: { ...state.labState, ...action.patch } };

    case 'REPLACE_STATE': return action.state;
    default: return state;
  }
}

function withActivity(state, patch) {
  return { ...state, activity: { ...state.activity, ...patch } };
}
function addUnique(list, value, cap) {
  if (list.includes(value)) return list;
  const next = [...list, value];
  return cap ? next.slice(-cap) : next;
}

function focus(state, id) {
  if (state.focusedId === id && state.windows.find((w) => w.id === id && w.z === state.zTop)) return state;
  const z = state.zTop + 1;
  return { ...state, zTop: z, focusedId: id, windows: state.windows.map((w) => (w.id === id ? { ...w, z, minimized: false } : w)) };
}
function unminimize(state, id) {
  return { ...state, windows: state.windows.map((w) => (w.id === id ? { ...w, minimized: false } : w)) };
}
