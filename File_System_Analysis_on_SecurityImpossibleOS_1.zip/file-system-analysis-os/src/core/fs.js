// Virtual Windows-style file system.
//
// The tree is a plain serializable object so it can live inside the reducer
// state and be persisted to localStorage. All mutating operations are pure:
// they return a NEW tree with structural sharing along the changed path.
//
// Node shape:
//   dir:  { type: 'dir',  name, children: { [lowercaseName]: node } }
//   file: { type: 'file', name, content, size, created, modified,
//           hidden?, suspicious?, system? }
//
// Paths are 'C:/Users/SIUser/...' — backslashes are normalized, lookups
// are case-insensitive (like Windows), display names keep their casing.

export function normalizePath(path) {
  if (!path) return '';
  let p = String(path).replace(/\\/g, '/').replace(/\/+/g, '/');
  if (p.endsWith('/') && p.length > 3) p = p.slice(0, -1);
  if (/^[a-z]:/i.test(p)) p = p[0].toUpperCase() + p.slice(1);
  return p;
}

export function pathParts(path) {
  return normalizePath(path).split('/').filter(Boolean);
}

export function parentPath(path) {
  const parts = pathParts(path);
  parts.pop();
  return parts.join('/');
}

export function baseName(path) {
  const parts = pathParts(path);
  return parts[parts.length - 1] || '';
}

export function extension(name) {
  const idx = name.lastIndexOf('.');
  return idx > 0 ? name.slice(idx + 1).toLowerCase() : '';
}

export function toWinPath(path) {
  return normalizePath(path).replace(/\//g, '\\');
}

export function createRoot() {
  return { type: 'dir', name: '', children: {} };
}

export function getNode(root, path) {
  const parts = pathParts(path);
  let node = root;
  for (const part of parts) {
    if (!node || node.type !== 'dir') return null;
    node = node.children[part.toLowerCase()];
    if (!node) return null;
  }
  return node || null;
}

export function exists(root, path) {
  return getNode(root, path) !== null;
}

export function isDir(root, path) {
  const n = getNode(root, path);
  return !!n && n.type === 'dir';
}

export function readFile(root, path) {
  const n = getNode(root, path);
  return n && n.type === 'file' ? n.content : null;
}

// List entries of a directory, folders first, alphabetical.
export function listDir(root, path, { showHidden = false } = {}) {
  const node = getNode(root, path);
  if (!node || node.type !== 'dir') return [];
  const base = normalizePath(path);
  const items = Object.values(node.children)
    .filter((n) => showHidden || !n.hidden)
    .map((n) => ({ ...n, path: `${base}/${n.name}` }));
  items.sort((a, b) => {
    if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
    return a.name.localeCompare(b.name, undefined, { sensitivity: 'base' });
  });
  return items;
}

// --- pure mutation helpers -------------------------------------------------

function cloneDir(dir) {
  return { ...dir, children: { ...dir.children } };
}

// Rebuild the chain root→path applying fn to the final node's parent.
// fn(parentClone, key, existingNode) mutates parentClone.children.
function withParent(root, path, fn, { createParents = false, now = 0 } = {}) {
  const parts = pathParts(path);
  if (parts.length === 0) return root;
  const key = parts[parts.length - 1].toLowerCase();
  const name = parts[parts.length - 1];

  const newRoot = cloneDir(root);
  let cursor = newRoot;
  for (let i = 0; i < parts.length - 1; i++) {
    const k = parts[i].toLowerCase();
    let child = cursor.children[k];
    if (!child || child.type !== 'dir') {
      if (!createParents) return root; // path missing → no-op
      child = { type: 'dir', name: parts[i], children: {}, created: now, modified: now };
    }
    const cloned = cloneDir(child);
    cursor.children[k] = cloned;
    cursor = cloned;
  }
  fn(cursor, key, cursor.children[key], name);
  return newRoot;
}

export function writeFile(root, path, content, meta = {}) {
  const now = meta.now ?? Date.now();
  return withParent(
    root,
    path,
    (parent, key, existing, name) => {
      const size = meta.size ?? (content ? content.length : 0);
      parent.children[key] = {
        type: 'file',
        name: meta.name ?? existing?.name ?? name,
        content: content ?? existing?.content ?? '',
        size,
        created: existing?.created ?? meta.created ?? now,
        modified: meta.modified ?? now,
        ...(meta.hidden !== undefined ? { hidden: meta.hidden } : existing?.hidden ? { hidden: true } : {}),
        ...(meta.suspicious !== undefined ? { suspicious: meta.suspicious } : existing?.suspicious ? { suspicious: true } : {}),
        ...(meta.system !== undefined ? { system: meta.system } : existing?.system ? { system: true } : {}),
      };
    },
    { createParents: true, now },
  );
}

export function mkdir(root, path, meta = {}) {
  const now = meta.now ?? Date.now();
  return withParent(
    root,
    path,
    (parent, key, existing, name) => {
      if (existing && existing.type === 'dir') return;
      parent.children[key] = {
        type: 'dir',
        name,
        children: {},
        created: meta.created ?? now,
        modified: meta.modified ?? now,
        ...(meta.hidden ? { hidden: true } : {}),
        ...(meta.system ? { system: true } : {}),
      };
    },
    { createParents: true, now },
  );
}

// Remove a node; returns { root, removed }.
export function removeNode(root, path) {
  let removed = null;
  const newRoot = withParent(root, path, (parent, key, existing) => {
    if (existing) {
      removed = existing;
      delete parent.children[key];
    }
  });
  return { root: removed ? newRoot : root, removed };
}

// Insert a detached node at a directory path (used by restore/move/paste).
export function insertNode(root, dirPath, node, { rename } = {}) {
  const target = normalizePath(dirPath) + '/' + (rename ?? node.name);
  return withParent(
    root,
    target,
    (parent, key, existing, name) => {
      let finalKey = key;
      let finalName = rename ?? node.name;
      // De-duplicate like Windows: "name - Copy", "name - Copy (2)"
      let n = 2;
      while (parent.children[finalKey]) {
        const dot = finalName.lastIndexOf('.');
        const stem = dot > 0 ? finalName.slice(0, dot) : finalName;
        const ext = dot > 0 ? finalName.slice(dot) : '';
        finalName = n === 2 ? `${stem} - Copy${ext}` : `${stem} - Copy (${n - 1})${ext}`;
        finalKey = finalName.toLowerCase();
        n += 1;
        if (n > 50) break;
      }
      parent.children[finalKey] = { ...node, name: finalName };
    },
    { createParents: true },
  );
}

export function renameNode(root, path, newName) {
  const dir = parentPath(path);
  const { root: without, removed } = removeNode(root, path);
  if (!removed) return root;
  return insertNode(without, dir, removed, { rename: newName });
}

export function moveNode(root, fromPath, toDirPath) {
  const from = normalizePath(fromPath);
  const toDir = normalizePath(toDirPath);
  if (toDir === parentPath(from)) return root;
  if (toDir.toLowerCase().startsWith(from.toLowerCase() + '/')) return root; // can't move into itself
  const { root: without, removed } = removeNode(root, from);
  if (!removed) return root;
  return insertNode(without, toDir, removed);
}

// Recursive search by name/content. Returns [{path, node, matchedContent}]
export function searchFs(root, query, { rootPath = 'C:', showHidden = true, limit = 200 } = {}) {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const start = getNode(root, rootPath);
  if (!start) return [];
  const results = [];
  const walk = (node, path) => {
    if (results.length >= limit) return;
    if (!showHidden && node.hidden) return;
    if (path && node.name.toLowerCase().includes(q)) {
      results.push({ path, node, matchedContent: false });
    } else if (node.type === 'file' && typeof node.content === 'string' && node.content.toLowerCase().includes(q)) {
      results.push({ path, node, matchedContent: true });
    }
    if (node.type === 'dir') {
      for (const child of Object.values(node.children)) {
        walk(child, path ? `${path}/${child.name}` : child.name);
      }
    }
  };
  walk(start, normalizePath(rootPath));
  return results;
}

export function dirSize(node) {
  if (!node) return 0;
  if (node.type === 'file') return node.size || 0;
  return Object.values(node.children).reduce((sum, c) => sum + dirSize(c), 0);
}

export function countItems(node) {
  if (!node || node.type !== 'dir') return 0;
  return Object.keys(node.children).length;
}
