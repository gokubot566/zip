// Headless logic test for the platform engine (no lab loaded — this is an
// empty template). These modules are plain ESM (no JSX) so Node imports them
// directly. Validates the reusable OS: file system, window manager, generic
// activity, settings, and persistence.
import assert from 'assert';
import { reducer, createInitialState, serialize, hydrate } from '../src/core/reducer.js';
import * as FS from '../src/core/fs.js';
import { buildBaseFs, DEFAULT_PROFILE, DEFAULT_SETTINGS } from '../src/config/platform.js';

let n = 0;
const ok = (name, cond) => { assert.ok(cond, name); console.log(`  ok   ${name}`); n++; };
const run = (state, ...actions) => actions.reduce((s, a) => reducer(s, a), state);

// Build a lab-free seed exactly like OSContext does with no active lab.
function buildSeed() {
  const now = 0;
  const profile = { ...DEFAULT_PROFILE };
  return { now, profile, fs: buildBaseFs(profile, now), data: {}, notifications: [], settings: { ...DEFAULT_SETTINGS }, labId: null };
}
const HOME = `C:/Users/${DEFAULT_PROFILE.username}`;

// --- clean base desktop ---------------------------------------------------
{
  const s = createInitialState(buildSeed());
  ok('seed: standard user folders exist', FS.isDir(s.fs, `${HOME}/Desktop`) && FS.isDir(s.fs, `${HOME}/Documents`) && FS.isDir(s.fs, `${HOME}/Downloads`));
  ok('seed: welcome file present', FS.exists(s.fs, `${HOME}/Desktop/Welcome.txt`));
  ok('seed: no lab data', Object.keys(s.data).length === 0 && s.meta.labId === null);
  ok('seed: default profile', s.profile.username === 'SIUser');
}

// --- filesystem ops -------------------------------------------------------
{
  let fs = buildBaseFs(DEFAULT_PROFILE, 0);
  fs = FS.writeFile(fs, `${HOME}/Documents/note.txt`, 'hello', { now: 1 });
  ok('fs: write + read', FS.readFile(fs, `${HOME}/Documents/note.txt`) === 'hello');
  fs = FS.mkdir(fs, `${HOME}/Documents/Sub`, { now: 1 });
  fs = FS.moveNode(fs, `${HOME}/Documents/note.txt`, `${HOME}/Documents/Sub`);
  ok('fs: move', FS.exists(fs, `${HOME}/Documents/Sub/note.txt`) && !FS.exists(fs, `${HOME}/Documents/note.txt`));
  fs = FS.renameNode(fs, `${HOME}/Documents/Sub/note.txt`, 'renamed.txt');
  ok('fs: rename', FS.exists(fs, `${HOME}/Documents/Sub/renamed.txt`));
  const { root, removed } = FS.removeNode(fs, `${HOME}/Documents/Sub/renamed.txt`);
  ok('fs: remove returns node', removed && removed.name === 'renamed.txt' && !FS.exists(root, `${HOME}/Documents/Sub/renamed.txt`));
  ok('fs: search by content', FS.searchFs(fs, 'Getting Started', { rootPath: 'C:' }).length >= 1);
}

// --- recycle bin ----------------------------------------------------------
{
  let s = createInitialState(buildSeed());
  s = reducer(s, { type: 'FS_DELETE', path: `${HOME}/Desktop/Welcome.txt`, now: 5 });
  ok('bin: delete moves to recycle bin', !FS.exists(s.fs, `${HOME}/Desktop/Welcome.txt`) && s.recycleBin.length === 1);
  const id = s.recycleBin[0].id;
  s = reducer(s, { type: 'FS_RESTORE', id });
  ok('bin: restore', FS.exists(s.fs, `${HOME}/Desktop/Welcome.txt`) && s.recycleBin.length === 0);
}

// --- window manager -------------------------------------------------------
{
  let s = createInitialState(buildSeed());
  const app = { id: 'explorer', name: 'File Explorer', defaultSize: { w: 880, h: 580 } };
  const single = { id: 'settings', name: 'Settings', singleton: true, defaultSize: { w: 820, h: 580 } };
  s = reducer(s, { type: 'OPEN_WINDOW', app, viewport: { w: 1280, h: 800 } });
  s = reducer(s, { type: 'OPEN_WINDOW', app, viewport: { w: 1280, h: 800 } });
  ok('win: multiple non-singleton windows', s.windows.length === 2);
  s = reducer(s, { type: 'OPEN_WINDOW', app: single, viewport: { w: 1280, h: 800 } });
  s = reducer(s, { type: 'OPEN_WINDOW', app: single, viewport: { w: 1280, h: 800 } });
  ok('win: singleton not duplicated', s.windows.filter((w) => w.appId === 'settings').length === 1);
  ok('win: openedApps recorded', s.activity.openedApps.includes('explorer') && s.activity.openedApps.includes('settings'));
  const top = s.windows[0].id;
  s = reducer(s, { type: 'FOCUS_WINDOW', id: top });
  ok('win: focus raises z + sets focus', s.focusedId === top && s.windows.find((w) => w.id === top).z === s.zTop);
  s = reducer(s, { type: 'TOGGLE_MAXIMIZE', id: top });
  ok('win: maximize', s.windows.find((w) => w.id === top).maximized);
  s = reducer(s, { type: 'CLOSE_WINDOW', id: top });
  ok('win: close', !s.windows.find((w) => w.id === top));
}

// --- generic activity + settings + notifications --------------------------
{
  let s = createInitialState(buildSeed());
  s = run(s,
    { type: 'RECORD_OPEN_FILE', path: `${HOME}/Desktop/Welcome.txt` },
    { type: 'RECORD_ACTIVITY', token: 'proc:1234' },
    { type: 'KILL_PROCESS', pid: 1234 },
    { type: 'TOGGLE_STARTUP', id: 'x1' },
    { type: 'QUARANTINE_THREATS', ids: ['a', 'b'] },
    { type: 'SET_NETWORK_ISOLATED', value: true },
    { type: 'RECORD_SCAN' },
  );
  const a = s.activity;
  ok('activity: file/token/kill/startup/quarantine/isolate/scan recorded',
    a.openedFiles.includes(`${HOME}/Desktop/Welcome.txt`) && a.viewed.includes('proc:1234') &&
    a.killedProcesses.includes(1234) && a.disabledStartup.includes('x1') &&
    a.quarantined.length === 2 && a.networkIsolated === true && a.scans === 1);
  ok('activity: dedupes', reducer(s, { type: 'KILL_PROCESS', pid: 1234 }).activity.killedProcesses.length === 1);

  s = reducer(s, { type: 'SET_SETTING', key: 'theme', value: 'light' });
  ok('settings: update', s.settings.theme === 'light');
  s = reducer(s, { type: 'NOTIFY', title: 'Hi', body: 'there', now: 10 });
  ok('notify: toast + notification', s.toasts.length === 1 && s.notifications.length === 1);
}

// --- persistence round-trip -----------------------------------------------
{
  let s = createInitialState(buildSeed());
  s = run(s,
    { type: 'RECORD_ACTIVITY', token: 'proc:1' },
    { type: 'SET_SETTING', key: 'accentId', value: 'violet' },
    { type: 'MERGE_LAB_STATE', patch: { foo: 'bar' } },
    { type: 'FS_WRITE', path: `${HOME}/Documents/keep.txt`, content: 'x' },
  );
  const saved = JSON.parse(JSON.stringify(serialize(s)));
  const restored = hydrate(buildSeed(), saved);
  ok('persist: activity survives', restored.activity.viewed.includes('proc:1'));
  ok('persist: settings survive', restored.settings.accentId === 'violet');
  ok('persist: labState survives', restored.labState.foo === 'bar');
  ok('persist: fs edits survive', FS.readFile(restored.fs, `${HOME}/Documents/keep.txt`) === 'x');
  ok('persist: fresh when no save', hydrate(buildSeed(), null).activity.viewed.length === 0);
}

console.log(`\n${n} assertions passed`);
