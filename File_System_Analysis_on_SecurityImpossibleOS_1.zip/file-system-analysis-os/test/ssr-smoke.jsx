// Headless render smoke test: mounts the full shell and every app through
// react-dom/server to catch throw-on-render bugs without a browser.
// Effects don't run under renderToStaticMarkup, so this validates the pure
// render path (the most common place for crashes).
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { OSProvider } from '../src/core/OSContext.jsx';
import App from '../src/App.jsx';
import { APPS } from '../src/apps/registry.js';

function tryRender(name, el) {
  try {
    const html = renderToStaticMarkup(el);
    console.log(`  ok   ${name.padEnd(22)} (${html.length} bytes)`);
    return true;
  } catch (e) {
    console.log(`  FAIL ${name.padEnd(22)} ${e.message}`);
    console.log(e.stack.split('\n').slice(1, 4).join('\n'));
    return false;
  }
}

let pass = 0, fail = 0;

// 1) full app tree (boot screen state)
(tryRender('App (shell)', <OSProvider><App /></OSProvider>) ? pass++ : fail++);

// 2) each app component, inside the provider, with representative args
const argsFor = {
  explorer: { path: 'C:/Users/SIUser/Documents' },
  texteditor: { path: 'C:/Users/SIUser/Desktop/Welcome.txt' },
  imageviewer: {},
  browser: {},
  mail: {},
};
for (const app of APPS) {
  const Comp = app.component;
  const win = { id: `win-${app.id}`, appId: app.id, args: argsFor[app.id] ?? null };
  (tryRender(app.id, <OSProvider><Comp win={win} args={argsFor[app.id] ?? null} /></OSProvider>) ? pass++ : fail++);
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
