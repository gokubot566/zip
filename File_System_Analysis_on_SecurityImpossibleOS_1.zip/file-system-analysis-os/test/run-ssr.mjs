// Bundle the JSX smoke test with esbuild, stub browser globals, then execute.
import { build } from 'esbuild';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';

const dir = path.dirname(fileURLToPath(import.meta.url));

// --- stub the browser globals the shell touches during render ---
const store = new Map();
globalThis.window = globalThis;
globalThis.innerWidth = 1280;
globalThis.innerHeight = 820;
globalThis.addEventListener = () => {};
globalThis.removeEventListener = () => {};
globalThis.matchMedia = () => ({ matches: false, addEventListener() {}, removeEventListener() {} });
// framer-motion's layout projection touches these browser globals during render.
globalThis.SVGElement = class SVGElement {};
globalThis.HTMLElement = class HTMLElement {};
globalThis.Element = class Element {};
globalThis.Node = class Node {};
globalThis.localStorage = {
  getItem: (k) => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: (k) => store.delete(k),
};
globalThis.document = {
  documentElement: { style: { setProperty() {} }, dataset: {} },
  getElementById: () => null,
  addEventListener: () => {},
};

import { writeFileSync } from 'fs';

const outFile = path.join(dir, '.smoke-bundle.mjs');
await build({
  entryPoints: [path.join(dir, 'ssr-smoke.jsx')],
  bundle: true,
  format: 'esm',
  platform: 'node',
  jsx: 'automatic',
  outfile: outFile,
  logLevel: 'error',
  // Lab packages may import static assets (png/svg/css). Vite handles these in
  // the real build; for the headless SSR bundle we only need them not to break
  // the graph, so map assets to harmless stubs.
  loader: {
    '.png': 'dataurl', '.jpg': 'dataurl', '.jpeg': 'dataurl',
    '.gif': 'dataurl', '.webp': 'dataurl', '.svg': 'text', '.css': 'empty',
  },
  // Let the bundled react-dom/server reach node builtins (stream, util...).
  banner: { js: "import { createRequire as __cr } from 'module'; const require = __cr(import.meta.url);" },
});

try {
  await import(pathToFileURL(outFile).href);
} catch (e) {
  console.error('MODULE THREW AT EVAL:', e.message);
  console.error(e.stack.split('\n').slice(0, 6).join('\n'));
  process.exit(1);
}
