# Security Impossible OS

A **browser-based, Windows-like desktop operating system** built with React 18 + Vite —
a reusable platform for interactive cybersecurity, IT and digital-forensics training
labs, developed under the fictional brand **Security Impossible**.

The operating system is the **platform**. It contains **no lab-specific logic**, and
**this repository ships as an empty template** — it boots straight to a clean, generic
Security Impossible OS desktop with no scenario loaded. Labs are self-contained packages
(files, data, apps, objectives) that the platform loads at runtime; you create one by
adding a package under `src/labs/` and pointing the platform at it, without modifying
the core OS.

Everything runs client-side: the desktop, virtual file system, windows and apps are
simulated in memory and persisted to `localStorage`. There is no backend.

---

## Quick start

```bash
npm install
npm run dev        # dev server on http://0.0.0.0:3000
npm run build      # static production build → build/
npm run preview    # serve build/ on http://0.0.0.0:3000
npm test           # headless engine + render tests (no browser needed)
```

Port defaults to `3000`; override with `LAB_PORT=xxxx`.

### Docker

Multi-stage build — Node exists only in the build stage; the final image is pure nginx.

```bash
docker compose up -d --build      # recommended → http://localhost:3000
docker compose down
# override the published port without editing the file:
LAB_PORT=8080 docker compose up -d
```

Or plain Docker: `docker build -t si-os . && docker run --rm -p 3000:3000 si-os`.

---

## The platform / lab model

```
Platform (src/config, src/core, src/shell, src/apps)   ← generic, never lab-aware
        │  loads
        ▼
Active lab (src/labs/<id>)  →  profile · files · data · apps · objectives
```

- The **platform** provides the desktop, window manager, virtual file system,
  notifications, theme, settings, and a set of generic apps. It records only
  **generic activity** — which files you opened, which processes you ended, whether you
  ran a scan or isolated the network — and assigns that activity no meaning.
- A **lab** supplies the persona, the file/data content, any lab-only apps, and the
  *interpretation* of your activity (evidence found, objectives complete, report
  grading). The platform imports none of that logic.

This separation is what makes the OS reusable: drop a package into `src/labs/` and the
same desktop hosts a completely different scenario, with nothing else changed.

**Sign in:** password hint `si` — or just leave the field blank.

### Built-in (generic) apps

File Explorer · Text Editor · Mail · Browser · Task Manager · Event Viewer ·
Security Center · Terminal · System Information · Image Viewer · Settings · Calculator ·
Help. With no lab loaded they show empty states; when a lab is active they render
whatever data it provides.

---

## Architecture

```
src/
  config/          platform configuration (no lab knowledge)
    brand.js         Security Impossible identity — DATA (name, colors, version)
    branding.jsx     logo components + re-export of brand data
    platform.js      default profile, wallpapers, accents, settings, desktop/taskbar
                     layout, base file-system builder, PLATFORM_STORE_KEY
  core/            the reusable engine
    fs.js            pure immutable virtual file system (C:\... tree)
    reducer.js       all state transitions; generic `data` / `activity` / `labState`
    OSContext.jsx    provider: loads the active lab → seed, persistence, actions
    utils.js         formatting / id helpers
  shell/           the desktop UI (boot, login, desktop, taskbar, start menu, windows,
                   notifications, dialogs, context menus) — driven by config + branding
  apps/            the 13 generic apps + registry.js (+ merges lab apps) + kit.jsx
  labs/
    index.js         lab registry — EMPTY in this template (LABS: [], ACTIVE_LAB_ID: null).
                     Add lab packages here to load a scenario.
```

> This template contains no lab package. A lab is a folder under `src/labs/` exporting
> `{ id, storeKey, meta, profile, seed, data, desktopShortcuts, apps }` — see
> "Create a new lab" below.

### Core systems (reusable modules)

Window Manager · Desktop Manager · Virtual File System · Application Registry ·
Notification System · Theme Manager · Settings · Storage/Save-Restore ·
Configuration Loader · Context-menu & Dialog managers · Search.

### How progress tracking stays lab-agnostic

Generic apps emit **activity tokens** as you use them (e.g. `recordOpenFile(path)`,
`recordActivity('proc:6666')`, `recordScan()`, `killProcess(pid)`,
`setNetworkIsolated(true)`). The platform just stores these in `state.activity`. The
lab's `investigation.js` reads that activity to decide what evidence/objectives are
complete. The apps never mention "evidence".

---

## Extending the platform

### Add an application

1. Build a component in `src/apps/` that reads state via `useOS()`.
2. Add one descriptor to `PLATFORM_APPS` in `src/apps/registry.js`
   (`{ id, name, icon, color, category, singleton?, defaultSize, component }`).

It appears automatically in the Start menu, search, and (if pinned in
`config/platform.js`) the taskbar/desktop.

### Create a new lab

1. Create `src/labs/<your-lab>/index.js` exporting a default lab object:
   ```js
   export default {
     id: 'your-lab',
     storeKey: 'security-impossible-os.lab.your-lab.v1', // unique per lab
     meta: { name, category, difficulty, summary },
     profile: { name, username, role, email, hostname, domain, password }, // persona
     seed(fs, { writeFile, mkdir, now }) { /* add files, return fs */ },
     data: { mail, processes, events, threats, startupItems, scheduledTasks,
             network, registry, browser, installedApps, iocs }, // all optional
     desktopShortcuts: [ { id, type: 'app', appId, label } ],
     apps: [ /* optional lab-only app descriptors { id, name, icon, component } */ ],
   };
   ```
2. Keep any scenario logic (progress, grading) in the lab's own modules. Generic apps
   emit activity via `useOS()` (`recordOpenFile`, `recordActivity('<token>')`,
   `killProcess`, `quarantineThreats`, `recordScan`, `setNetworkIsolated`); your lab
   reads `state.activity` / `state.labState` to interpret it.
3. Register it in `src/labs/index.js` (`import` it, add to `LABS`, set `ACTIVE_LAB_ID`).

The platform (`config`, `core`, `shell`, `apps`) is never touched.

### Rebrand

Edit `src/config/brand.js` (name, company, colors, version) and the logo in
`src/config/branding.jsx`. No application code hard-codes brand strings.

---

## Tech

React 18 · Vite 6 (`outDir: build`, host `0.0.0.0`) · framer-motion · lucide-react ·
pure CSS with variables (dark theme default) in `index.css` · SPA with **no router**
(navigation is React state) · localStorage persistence (per-lab `STORE_KEY`) ·
multi-stage Docker (`node:22-alpine` → `nginx:1.27-alpine`).
