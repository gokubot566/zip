# CLAUDE.md

Guidance for Claude Code (claude.ai/code) when working in this repository.

## What this is

**Security Impossible OS** — a fully client-side, browser-based **Windows-like desktop
platform** (React 18 + Vite) that hosts interactive cybersecurity training labs. There
is no backend; the desktop, virtual file system, processes, logs and apps are simulated
in memory and persisted to `localStorage`.

The guiding rule: **the OS is a generic platform and contains no lab-specific logic.**
All scenario content lives in swappable lab packages under `src/labs/`. **This repo
ships as an empty template**: `src/labs/index.js` registers no labs, so it boots to a
clean generic desktop. Adding a lab package is the intended way to build a scenario.

> An earlier vanilla-JS prototype lives in `legacy/` (root-owned, read-only, not built).
> Ignore it unless explicitly asked.

## Running & checking

```bash
npm install
npm run dev        # host 0.0.0.0, port 3000 (override: LAB_PORT=xxxx)
npm run build      # → build/
npm run preview
npm test           # node test/logic.mjs (engine + lab derivation) + test/run-ssr.mjs (renders all apps)
node -c <file>     # syntax check (no linter)

docker compose up -d --build     # multi-stage build; final image is pure nginx
```

Tests are headless (no browser). `test/logic.mjs` runs in plain Node over the pure-JS
module graph and exercises the platform engine with no lab loaded (fs, recycle bin,
window manager, generic activity, settings, persistence); `test/run-ssr.mjs`
esbuild-bundles + server-renders the shell and every app (stubbing browser globals).
Run both after any change.

## Architecture — platform vs lab

**Platform** = `src/config` + `src/core` + `src/shell` + `src/apps`. Never lab-aware.
**Lab** = `src/labs/<id>` = profile + files + data + optional apps + investigation logic.

- `src/config/`
  - `brand.js` — Security Impossible identity as **plain data** (name, colors, version).
    Non-React modules import from here. `branding.jsx` adds logo components and
    re-exports the data (so `import { BRANDING } from './branding.jsx'` also works).
  - `platform.js` — `PLATFORM_STORE_KEY`, `DEFAULT_PROFILE`, `WALLPAPERS`, `ACCENTS`,
    `DEFAULT_SETTINGS`, desktop/taskbar/start layout, `buildBaseFs(profile)`.
- `src/core/`
  - `fs.js` — **pure, immutable** virtual file system. All mutators return a new tree.
  - `reducer.js` — every state transition. State slices: `profile`, `fs`, `data`
    (read-only lab content surfaced to apps), `activity` (generic usage telemetry),
    `labState` (opaque per-lab app state), plus windows/notifications/settings/recycle.
    `serialize`/`hydrate` persist everything **except** `data`/`profile` (re-derived
    from the lab each load); a save is only restored if its `labId` matches.
  - `OSContext.jsx` — builds the seed from platform config + `getActiveLab()`, wires
    persistence, exposes `useOS()` (state + actions + `branding`).
- `src/shell/` — desktop UI, all branding/layout driven by config. `ui.js` = imperative
  `openDialog`/`confirmDialog`/`openContextMenu`.
- `src/apps/` — 13 generic apps + `registry.js` (merges `PLATFORM_APPS` with the active
  lab's `apps`) + `kit.jsx` + `fileIcons.jsx`.
- `src/labs/`
  - `index.js` — the extension point: `LABS` (empty in this template),
    `ACTIVE_LAB_ID` (null → clean desktop), `getActiveLab()`/`getLab()`. Everything
    else touches labs only through these, so an empty registry Just Works.
  - (no lab packages ship in this template — add `src/labs/<id>/index.js` to create one)

### The key abstraction: generic activity, lab interpretation

Apps NEVER track "evidence" or "objectives". As the user works, generic apps dispatch
generic actions: `recordOpenFile(path)`, `recordActivity('<token>')`, `killProcess(pid)`,
`toggleStartup(id)`, `quarantineThreats(ids)`, `setNetworkIsolated(bool)`, `recordScan()`.
These land in `state.activity`. The lab's `investigation.js` reads `state.activity` +
`state.labState` to derive its evidence/objectives and grade the report. Activity-token
conventions (e.g. `mail:<id>`, `proc:<pid>`, `event:<id>`, `netstat`, `net:view`,
`startup:<id>`, `task:<id>`, `url:<url>`) are documented at the top of that file — keep
apps and the lab in sync on them.

## Conventions

- **Never put lab/scenario content in the platform.** Apps read `state.data.*`
  (`mail`, `processes`, `events`, `threats`, `startupItems`, `scheduledTasks`,
  `network`, `registry`, `browser`, `installedApps`, `iocs`) and default to empty when
  absent. `state.profile` gives user/host. Brand strings come from `BRANDING`.
- **Add an app:** component in `src/apps/` + one entry in `PLATFORM_APPS`
  (`registry.js`). It appears in Start/search/taskbar automatically.
- **Add a lab:** create `src/labs/<id>/index.js` exporting
  `{ id, storeKey (unique), meta, profile, seed(fs,helpers), data, desktopShortcuts,
  apps }`; import it in `src/labs/index.js`, add to `LABS`, set `ACTIVE_LAB_ID`. Put
  scenario logic in the lab's own modules. Don't touch `config`/`core`/`shell`/`apps`.
- **Never mutate the fs tree** — go through `fs.js` helpers / reducer actions
  (`writeFile`, `deletePath`, `renamePath`, `movePath`, `copyPath`, `restoreFromBin`).
- Use the shared kit (`Tabs`, `Toolbar`, `Empty`, `Field`, `Banner`) and CSS classes
  (`os-btn`, `os-input`, `badge`, `list-row`, `table.data`, `.mono`, `.selectable`).
  Colors via `var(--...)` — dark theme default, `[data-theme='light']` override.
- **Module-eval order matters for plain ESM** (Node runs `logic.mjs` without a bundler):
  declare module-level `let`/`const` counters and helper functions **before** the arrays
  that call them, or you hit a temporal-dead-zone `ReferenceError`. Keep `brand.js`
  JSX-free so the pure-JS graph (platform → reducer → tests) stays Node-importable.
- Bump a lab's `storeKey` after breaking changes to its saved state.

## Note on lab content

This template ships no lab, so it contains no scenario/malware content. Any lab you add
under `src/labs/` should keep its content **fictional and inert** (fake process names,
sample emails, log lines and IOCs as plain strings) — nothing executable. The Browser
renders HTML in a `sandbox=""` iframe and the OS refuses to "run" executables, so lab
artifacts stay safe training data.
