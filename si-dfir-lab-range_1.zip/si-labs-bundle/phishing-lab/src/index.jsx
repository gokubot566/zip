import React from 'react'
import ReactDOM from 'react-dom/client'
// Bundled locally (no CDN dependency) — fonts + professional icon set
import '@fontsource/inter/400.css'
import '@fontsource/inter/500.css'
import '@fontsource/inter/600.css'
import '@fontsource/inter/700.css'
import '@fontsource/jetbrains-mono/400.css'
import '@fontsource/jetbrains-mono/500.css'
import '@fontsource/jetbrains-mono/700.css'
import '@tabler/icons-webfont/dist/tabler-icons.min.css'
import App from './App'

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
)
