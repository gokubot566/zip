const pup=require("puppeteer-core");const C="/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome";
const sl=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const b=await pup.launch({executablePath:C,headless:"new",args:["--no-sandbox","--disable-setuid-sandbox","--disable-dev-shm-usage"]});
 const p=await b.newPage(); const errs=[];
 p.on("pageerror",e=>errs.push(e.message));
 await p.goto("http://localhost:9082/",{waitUntil:"networkidle0"});
 await sl(2500);
 const r=await p.evaluate(()=>({children:(document.getElementById("root")||{}).children?.length||0, text:(document.body.innerText||"").slice(0,80), btns:[...document.querySelectorAll("button")].length}));
 console.log("PIR after fix: root children=",r.children,"buttons=",r.btns,"errors=",errs.length, errs.slice(0,2));
 console.log("text:",JSON.stringify(r.text));
 await p.close(); await b.close();
})().catch(e=>console.log("ERR",e.message));
