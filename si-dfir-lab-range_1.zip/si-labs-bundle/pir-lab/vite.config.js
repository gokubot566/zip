import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
export default defineConfig({
  plugins: [react()],
  build: { outDir: 'build', chunkSizeWarningLimit: 3000 },
  server: { port: 8082, host: '0.0.0.0' },
  preview: { port: 8082, host: '0.0.0.0' }
})
