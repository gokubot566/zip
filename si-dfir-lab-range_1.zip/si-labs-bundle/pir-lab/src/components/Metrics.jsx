import { useState } from "react";
import { INCIDENT } from "../data/incident.js";
import { RadialBarChart, RadialBar, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from "recharts";

const METRICS_DEF = [
  {
    id:"mttd", name:"MTTD", full:"Mean Time to Detect",
    formula:"Detection Time − Initial Compromise",
    t0:"2026-11-14T02:11:03Z", t1:"2026-11-14T02:19:00Z",
    answer: 9.3, unit:"min", color:"var(--green)",
    benchmark:"Industry avg: 24h | Excellent: <15min",
    interpretation:"Time from when the threat began to when the SOC became aware. FIM detection within 3s was excellent; SIEM escalation adds ~9 minutes total.",
    hint:"Subtract T0 (execution) from T1 (FIM alert → escalation). Convert seconds to minutes.",
  },
  {
    id:"mttc", name:"MTTC", full:"Mean Time to Contain",
    formula:"Containment Time − Detection/Escalation Time",
    t0:"2026-11-14T02:19:00Z", t1:"2026-11-14T02:44:00Z",
    answer: 25, unit:"min", color:"var(--amber)",
    benchmark:"Industry avg: 2h | Target for ransomware: <15min",
    interpretation:"25 minutes is unacceptable for active ransomware. Encryption completed at 02:18 — containment arrived 25 minutes too late. Governance gap in firewall access caused this delay.",
    hint:"Subtract escalation time from when isolation was confirmed. Network team needed approval chain.",
  },
  {
    id:"mttr", name:"MTTR", full:"Mean Time to Recover",
    formula:"Full Recovery − Initial Compromise",
    t0:"2026-11-14T02:11:03Z", t1:"2026-11-14T20:32:00Z",
    answer: 1100.9, unit:"min", color:"var(--red)",
    benchmark:"Industry avg: 24h | This incident: 18.4h",
    interpretation:"18.4 hours total recovery time. Finance and HR restored within 6 hours. Legal and Trading took longer. Compliance share required manual reconstruction due to backup failure.",
    hint:"Full recovery − initial compromise. Convert hours and minutes to total minutes.",
  },
  {
    id:"downtime", name:"Downtime", full:"Total Business Impact Hours",
    formula:"FILESVR-01 offline from 02:14 to 06:00 (Finance), 08:30 (HR)",
    t0:"2026-11-14T02:14:19Z", t1:"2026-11-14T06:00:00Z",
    answer: 228.7, unit:"min (Finance)", color:"var(--purple)",
    benchmark:"Direct cost estimate: $127K/hour for financial services",
    interpretation:"Trading floor downtime: 3h 46m. At $127K/hr industry estimate = $478K direct cost. Add recovery, investigation, and regulatory costs for total $2.34M.",
    hint:"Calculate per-share downtime. Finance was highest priority and restored first.",
  },
];

function MetricCalculator({ metric, onCorrect, solved }) {
  const [userVal, setUserVal] = useState("");
  const [checked, setChecked] = useState(false);
  const [correct, setCorrect] = useState(false);
  const [showHint, setShowHint] = useState(false);

  function check() {
    const v = parseFloat(userVal);
    const diff = Math.abs(v - metric.answer);
    const threshold = metric.answer * 0.05;
    const ok = diff <= threshold || diff <= 2;
    setChecked(true);
    setCorrect(ok);
    if (ok && !solved) onCorrect();
  }

  return (
    <div className="card" style={{
      border:`1px solid ${solved ? "rgba(0,230,118,.3)" : "var(--line)"}`,
      transition:"border-color .3s",
    }}>
      <div className="card-head" style={{ borderLeftColor: metric.color, borderLeft:`3px solid ${metric.color}` }}>
        <div>
          <div style={{ display:"flex", gap:8, alignItems:"center" }}>
            <span style={{ fontSize:18, fontWeight:800, color:metric.color, fontFamily:"var(--mono)" }}>{metric.name}</span>
            <span style={{ fontSize:11, fontWeight:600, color:"var(--t2)" }}>{metric.full}</span>
            {solved && <span style={{ fontSize:10, color:"var(--green)", fontFamily:"var(--mono)" }}>✓ SOLVED</span>}
          </div>
          <div style={{ fontSize:10, color:"var(--t3)", fontFamily:"var(--mono)", marginTop:2 }}>{metric.formula}</div>
        </div>
      </div>
      <div style={{ padding:"14px 16px" }}>
        {/* Timestamps */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:14 }}>
          <div style={{ background:"var(--s3)", borderRadius:6, padding:"10px 12px", border:"1px solid var(--line)" }}>
            <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", marginBottom:4 }}>T0 — Start Event</div>
            <div style={{ fontSize:11, color:"var(--cyan)", fontFamily:"var(--mono)" }}>{metric.t0.replace("T"," ").replace("Z"," UTC")}</div>
          </div>
          <div style={{ background:"var(--s3)", borderRadius:6, padding:"10px 12px", border:"1px solid var(--line)" }}>
            <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", marginBottom:4 }}>T1 — End Event</div>
            <div style={{ fontSize:11, color:"var(--amber)", fontFamily:"var(--mono)" }}>{metric.t1.replace("T"," ").replace("Z"," UTC")}</div>
          </div>
        </div>

        {/* Input */}
        <div style={{ display:"flex", gap:8, marginBottom:10 }}>
          <input
            type="number" step="0.1" value={userVal}
            onChange={e => { setUserVal(e.target.value); setChecked(false); }}
            placeholder={`Calculate ${metric.name} in ${metric.unit}...`}
            style={{ flex:1 }}
          />
          <button className="btn btn-cyan" onClick={check} disabled={!userVal}>Check</button>
          <button className="btn btn-ghost" onClick={() => setShowHint(v => !v)}>
            {showHint ? "Hide" : "Hint"}
          </button>
        </div>

        {showHint && (
          <div style={{ background:"rgba(0,229,255,.05)", border:"1px solid rgba(0,229,255,.15)", borderRadius:6, padding:"8px 12px", marginBottom:10 }}>
            <div style={{ fontSize:10, color:"var(--t3)", fontFamily:"var(--mono)", lineHeight:1.6 }}>{metric.hint}</div>
          </div>
        )}

        {checked && (
          <div style={{
            padding:"10px 12px", borderRadius:6, marginBottom:10,
            background: correct ? "rgba(0,230,118,.08)" : "rgba(255,61,87,.08)",
            border: `1px solid ${correct ? "rgba(0,230,118,.25)" : "rgba(255,61,87,.25)"}`,
          }}>
            <div style={{ fontSize:11, fontWeight:600, color: correct ? "var(--green)" : "var(--red)", marginBottom:4 }}>
              {correct ? "✓ Correct!" : `✗ Not quite. Accepted range: ${(metric.answer * 0.95).toFixed(1)}–${(metric.answer * 1.05).toFixed(1)} ${metric.unit}`}
            </div>
            <div style={{ fontSize:11, color:"var(--t2)", lineHeight:1.6 }}>{metric.interpretation}</div>
            {!correct && (
              <div style={{ fontSize:10, color:"var(--amber)", fontFamily:"var(--mono)", marginTop:6 }}>
                Expected: ~{metric.answer.toFixed(1)} {metric.unit}
              </div>
            )}
          </div>
        )}

        {/* Benchmark */}
        <div style={{ fontSize:10, color:"var(--t4)", fontFamily:"var(--mono)" }}>
          📊 {metric.benchmark}
        </div>
      </div>
    </div>
  );
}

export default function Metrics({ trackProgress, progress, addXP }) {
  const [solved, setSolved] = useState(new Set());

  function handleCorrect(id) {
    setSolved(p => {
      const n = new Set([...p, id]);
      if (n.size === METRICS_DEF.length) {
        trackProgress("metrics_done");
      }
      addXP(100, "Metric solved");
      return n;
    });
  }

  const gaugeData = [
    { name: "MTTD", value: 100 - Math.min((9.3/60)*100, 100), fill: "#00e676" },
    { name: "MTTC", value: 100 - Math.min((25/60)*100, 100), fill: "#ffb830" },
    { name: "MTTR", value: 100 - Math.min((1100/1440)*100, 100), fill: "#ff3d57" },
  ];

  const trendData = [
    { metric:"MTTD", this: 9.3, industry: 1440, target: 15 },
    { metric:"MTTC", this: 25, industry: 120, target: 15 },
    { metric:"MTTR", this: 1101, industry: 1440, target: 480 },
  ];

  return (
    <div style={{ padding:"20px 24px", maxWidth:1100, margin:"0 auto" }}>
      <div style={{ marginBottom:16 }}>
        <h2 style={{ fontSize:20, fontWeight:800, color:"var(--t1)", marginBottom:4 }}>Metrics Center</h2>
        <p style={{ fontSize:12, color:"var(--t3)" }}>
          Calculate IR metrics from incident timestamps. {solved.size}/{METRICS_DEF.length} solved
          {solved.size === METRICS_DEF.length && <span style={{ color:"var(--green)", marginLeft:8 }}>✓ All metrics calculated!</span>}
        </p>
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"2fr 1fr", gap:16, marginBottom:16 }}>
        {/* Calculators */}
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          {METRICS_DEF.map(m => (
            <MetricCalculator key={m.id} metric={m} solved={solved.has(m.id)} onCorrect={() => handleCorrect(m.id)} />
          ))}
        </div>

        {/* Charts */}
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          {/* Comparison chart */}
          <div className="card">
            <div className="card-head">
              <span style={{ fontSize:11, fontWeight:600, color:"var(--t2)" }}>vs Industry Benchmark</span>
            </div>
            <div style={{ padding:"12px 8px" }}>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={trendData} layout="vertical" barSize={10}>
                  <XAxis type="number" tick={{ fontSize:9, fill:"#4a6a88", fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} />
                  <YAxis dataKey="metric" type="category" tick={{ fontSize:10, fill:"#4a6a88", fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} width={40} />
                  <Tooltip contentStyle={{ background:"#0e1620", border:"1px solid #1a2535", borderRadius:6, fontSize:10, fontFamily:"JetBrains Mono" }} />
                  <Bar dataKey="industry" name="Industry Avg" fill="#1a2535" radius={[0,3,3,0]} />
                  <Bar dataKey="target" name="Target" fill="#00e5ff" radius={[0,3,3,0]} opacity={0.5} />
                  <Bar dataKey="this" name="This Incident" fill="#ff3d57" radius={[0,3,3,0]} />
                </BarChart>
              </ResponsiveContainer>
              <div style={{ display:"flex", gap:10, justifyContent:"center", flexWrap:"wrap" }}>
                {[["Industry",  "#1a2535"],["Target","#00e5ff"],["Incident","#ff3d57"]].map(([l,c])=>(
                  <div key={l} style={{ display:"flex", gap:4, alignItems:"center", fontSize:9, color:"var(--t3)" }}>
                    <div style={{ width:8, height:8, borderRadius:2, background:c }} />
                    {l}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Maturity score */}
          <div className="card">
            <div className="card-head">
              <span style={{ fontSize:11, fontWeight:600, color:"var(--t2)" }}>Response Maturity Score</span>
            </div>
            <div style={{ padding:14, textAlign:"center" }}>
              <div style={{ fontSize:48, fontWeight:800, color:"var(--amber)", fontFamily:"var(--mono)", lineHeight:1 }}>6.2</div>
              <div style={{ fontSize:11, color:"var(--t3)", marginTop:4 }}>out of 10.0</div>
              <div style={{ margin:"12px 0", height:4, background:"var(--line)", borderRadius:2, overflow:"hidden" }}>
                <div style={{ height:"100%", width:"62%", background:"linear-gradient(90deg,var(--red),var(--amber))", transition:"width .8s ease-out" }} />
              </div>
              <div style={{ fontSize:10, color:"var(--t3)", lineHeight:1.7 }}>
                Detection: <span style={{ color:"var(--green)" }}>Excellent</span><br/>
                Containment: <span style={{ color:"var(--red)" }}>Poor (25m delay)</span><br/>
                Communication: <span style={{ color:"var(--amber)" }}>Needs Improvement</span><br/>
                Evidence: <span style={{ color:"var(--red)" }}>Critical failure</span><br/>
                Recovery: <span style={{ color:"var(--amber)" }}>Adequate</span>
              </div>
            </div>
          </div>

          {/* Progress */}
          <div className="card">
            <div className="card-head">
              <span style={{ fontSize:11, fontWeight:600, color:"var(--t2)" }}>Calculations Progress</span>
            </div>
            <div style={{ padding:12 }}>
              {METRICS_DEF.map(m => (
                <div key={m.id} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8 }}>
                  <span style={{ fontSize:10, fontFamily:"var(--mono)", color:m.color, width:48 }}>{m.name}</span>
                  <div style={{ flex:1, height:4, background:"var(--line)", borderRadius:2, overflow:"hidden" }}>
                    <div style={{ height:"100%", width: solved.has(m.id) ? "100%" : "0%", background:m.color, transition:"width .6s ease-out" }} />
                  </div>
                  <span style={{ fontSize:10, color: solved.has(m.id) ? "var(--green)" : "var(--t4)", fontFamily:"var(--mono)" }}>
                    {solved.has(m.id) ? "✓" : "—"}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
