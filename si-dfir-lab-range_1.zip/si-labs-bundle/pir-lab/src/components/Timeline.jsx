import { useState } from "react";
import { TIMELINE_EVENTS } from "../data/incident.js";

const PHASE_COLORS = {
  "Initial Access": "#ff3d57",
  "Execution": "#ff6b35",
  "C2": "#a78bfa",
  "Defense Evasion": "#00b8cc",
  "Persistence": "#ffb830",
  "Privilege Escalation": "#ff3d57",
  "Lateral Movement": "#a78bfa",
  "Impact": "#ff3d57",
  "Detection": "#00e676",
  "Response": "#00e5ff",
  "Containment": "#ffb830",
  "Management": "#ffb830",
  "Recovery": "#60a5fa",
};

const SEV_COLORS = { critical:"var(--red)", high:"var(--amber)", medium:"#60a5fa", low:"var(--green)" };

function EventCard({ event, expanded, onToggle, viewed }) {
  const phaseColor = PHASE_COLORS[event.phase] || "#4a6a88";
  const sevColor = SEV_COLORS[event.severity] || "#4a6a88";
  const isFailure = event.flags.includes("RESPONSE_FAILURE");

  return (
    <div style={{
      display:"flex", gap:14, marginBottom:8,
      animation:"fadeIn .25s ease-out both",
    }}>
      {/* Timeline connector */}
      <div style={{ display:"flex", flexDirection:"column", alignItems:"center", width:20, flexShrink:0 }}>
        <div style={{
          width:12, height:12, borderRadius:"50%", flexShrink:0,
          background: isFailure ? "var(--red)" : phaseColor,
          border:`2px solid var(--bg)`, zIndex:1, marginTop:14,
          boxShadow: isFailure ? `0 0 8px rgba(255,61,87,.6)` : `0 0 6px ${phaseColor}60`,
        }} />
        <div style={{ flex:1, width:1, background:"var(--line)", minHeight:20 }} />
      </div>

      {/* Card */}
      <div style={{
        flex:1, background: isFailure ? "rgba(255,61,87,.05)" : "var(--s2)",
        border: `1px solid ${isFailure ? "rgba(255,61,87,.3)" : "var(--line)"}`,
        borderRadius:8, overflow:"hidden", cursor:"pointer",
        transition:"border-color .15s, box-shadow .15s",
      }}
      onClick={onToggle}
      onMouseEnter={e => { e.currentTarget.style.borderColor = isFailure ? "rgba(255,61,87,.5)" : "var(--line2)"; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = isFailure ? "rgba(255,61,87,.3)" : "var(--line)"; }}
      >
        {/* Header */}
        <div style={{ padding:"10px 14px", display:"flex", gap:10, alignItems:"center" }}>
          <div style={{
            fontSize:9, fontFamily:"var(--mono)", padding:"2px 7px", borderRadius:3,
            background:"var(--s3)", color:"var(--t2)", fontWeight:700,
            border:"1px solid var(--line2)", flexShrink:0, letterSpacing:".04em",
          }}>{event.id}</div>

          <div style={{
            fontSize:9, fontFamily:"var(--mono)", padding:"2px 7px", borderRadius:3,
            background:`${phaseColor}18`, color:phaseColor, fontWeight:700,
            border:`1px solid ${phaseColor}30`, textTransform:"uppercase", letterSpacing:".06em",
            flexShrink:0,
          }}>{event.phase}</div>

          <span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--t4)", flexShrink:0 }}>
            {event.time.split("T")[1]?.slice(0,8)} UTC
          </span>

          {isFailure && (
            <span style={{
              fontSize:9, fontFamily:"var(--mono)", padding:"2px 8px", borderRadius:3,
              background:"rgba(255,61,87,.15)", color:"var(--red)", border:"1px solid rgba(255,61,87,.3)",
              fontWeight:700, letterSpacing:".06em", flexShrink:0,
            }}>⚠ RESPONSE FAILURE</span>
          )}

          <span style={{ flex:1, fontSize:12, fontWeight:600, color: viewed ? "var(--t3)" : "var(--t1)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
            {event.title}
          </span>

          <div style={{ display:"flex", gap:6, alignItems:"center", flexShrink:0 }}>
            <span style={{
              fontSize:9, fontFamily:"var(--mono)", padding:"1px 6px", borderRadius:10,
              background:`${sevColor}12`, color:sevColor, border:`1px solid ${sevColor}25`,
            }}>{event.severity.toUpperCase()}</span>
            <span style={{ fontSize:10, color:"var(--t4)", transition:"transform .15s", transform: expanded ? "rotate(180deg)" : "rotate(0)" }}>▼</span>
          </div>
        </div>

        {/* Expanded content */}
        {expanded && (
          <div style={{ borderTop:"1px solid var(--line)", padding:"14px 16px", animation:"fadeIn .2s ease-out" }}>
            {/* Description */}
            <p style={{ fontSize:12, color:"var(--t2)", lineHeight:1.75, marginBottom:12 }}>{event.description}</p>

            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
              {/* System */}
              <div>
                <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", letterSpacing:".08em", marginBottom:4 }}>Affected System</div>
                <code style={{ fontSize:11, color:"var(--cyan)", background:"var(--s3)", padding:"4px 8px", borderRadius:4, display:"block" }}>{event.system}</code>
              </div>

              {/* MITRE */}
              {event.mitre && (
                <div>
                  <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", letterSpacing:".08em", marginBottom:4 }}>MITRE ATT&CK</div>
                  <code style={{ fontSize:11, color:"var(--amber)", background:"var(--s3)", padding:"4px 8px", borderRadius:4, display:"block" }}>{event.mitre}</code>
                </div>
              )}
            </div>

            {/* Evidence */}
            {event.evidence.length > 0 && (
              <div style={{ marginTop:12 }}>
                <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", letterSpacing:".08em", marginBottom:6 }}>Evidence Artifacts</div>
                <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                  {event.evidence.map(e => (
                    <span key={e} style={{
                      fontSize:10, fontFamily:"var(--mono)", padding:"3px 8px", borderRadius:4,
                      background:"var(--s3)", border:"1px solid var(--line)", color:"var(--cyan)",
                    }}>{e}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Tags */}
            <div style={{ display:"flex", gap:5, flexWrap:"wrap", marginTop:10 }}>
              {event.tags.map(tag => (
                <span key={tag} style={{
                  fontSize:9, fontFamily:"var(--mono)", padding:"1px 6px", borderRadius:10,
                  background:"var(--s3)", border:"1px solid var(--line2)", color:"var(--t3)",
                }}>{tag}</span>
              ))}
            </div>

            {/* Analyst note */}
            {event.notes && (
              <div style={{
                marginTop:12, background: isFailure ? "rgba(255,61,87,.06)" : "var(--s3)",
                border:`1px solid ${isFailure ? "rgba(255,61,87,.2)" : "var(--line)"}`,
                borderRadius:6, padding:"10px 12px",
              }}>
                <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", letterSpacing:".08em", marginBottom:4 }}>Analyst Note</div>
                <p style={{ fontSize:11, color: isFailure ? "#ff8888" : "var(--t2)", lineHeight:1.65, fontFamily:"var(--mono)" }}>{event.notes}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default function Timeline({ trackProgress, progress, addXP }) {
  const [expanded, setExpanded] = useState(new Set(["T09"]));
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");

  function toggle(id) {
    setExpanded(p => {
      const n = new Set(p);
      if (n.has(id)) n.delete(id); else n.add(id);
      return n;
    });
    if (!progress.timelineViewed.has(id)) {
      trackProgress("timeline", id);
    }
  }

  const phases = ["all", ...new Set(TIMELINE_EVENTS.map(e => e.phase))];
  const filtered = TIMELINE_EVENTS.filter(e => {
    const matchPhase = filter === "all" || e.phase === filter;
    const matchSearch = !search || e.title.toLowerCase().includes(search.toLowerCase()) || e.description.toLowerCase().includes(search.toLowerCase());
    return matchPhase && matchSearch;
  });

  const failureCount = TIMELINE_EVENTS.filter(e => e.flags.includes("RESPONSE_FAILURE")).length;

  return (
    <div style={{ padding:"20px 24px", maxWidth:1000, margin:"0 auto" }}>
      {/* Header */}
      <div style={{ marginBottom:16 }}>
        <h2 style={{ fontSize:20, fontWeight:800, color:"var(--t1)", marginBottom:4 }}>Incident Timeline</h2>
        <p style={{ fontSize:12, color:"var(--t3)" }}>
          {TIMELINE_EVENTS.length} events · {failureCount} response failures · Click any event to expand details
          · <span style={{ color:"var(--cyan)" }}>{progress.timelineViewed.size}/{TIMELINE_EVENTS.length} reviewed</span>
        </p>
      </div>

      {/* Controls */}
      <div style={{ display:"flex", gap:10, marginBottom:16, flexWrap:"wrap" }}>
        <input
          value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Search events..." style={{ maxWidth:240 }}
        />
        <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
          {["all","Detection","Containment","Recovery"].map(f => (
            <button key={f} onClick={() => setFilter(f)} className="btn" style={{
              background: filter===f ? "var(--cyan-dim)" : "transparent",
              border: `1px solid ${filter===f ? "rgba(0,229,255,.3)" : "var(--line2)"}`,
              color: filter===f ? "var(--cyan)" : "var(--t3)",
              padding:"5px 12px", fontSize:11,
            }}>{f === "all" ? "All Phases" : f}</button>
          ))}
          <button onClick={() => setFilter("failures")} className="btn" style={{
            background: filter==="failures" ? "var(--red-dim)" : "transparent",
            border: `1px solid ${filter==="failures" ? "rgba(255,61,87,.3)" : "var(--line2)"}`,
            color: filter==="failures" ? "var(--red)" : "var(--t3)",
            padding:"5px 12px", fontSize:11,
          }}>⚠ Failures Only</button>
        </div>
        <button className="btn btn-ghost" style={{ marginLeft:"auto", fontSize:11 }}
          onClick={() => { const all = new Set(TIMELINE_EVENTS.map(e=>e.id)); setExpanded(all); TIMELINE_EVENTS.forEach(e=>trackProgress("timeline",e.id)); }}>
          Expand All
        </button>
      </div>

      {/* Stats row */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(5,1fr)", gap:8, marginBottom:16 }}>
        {[
          ["Initial Compromise", "2026-11-14 02:11", "var(--red)"],
          ["Detection", "02:19 UTC (+9.3m)", "var(--green)"],
          ["Containment", "02:44 UTC (+34.6m)", "var(--amber)"],
          ["Recovery Start", "06:00 UTC", "var(--cyan)"],
          ["Full Recovery", "20:32 UTC (+18.4h)", "var(--purple)"],
        ].map(([l,v,c]) => (
          <div key={l} style={{ background:"var(--s2)", border:"1px solid var(--line)", borderRadius:6, padding:"8px 10px" }}>
            <div style={{ fontSize:8, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", letterSpacing:".08em", marginBottom:3 }}>{l}</div>
            <div style={{ fontSize:11, color:c, fontFamily:"var(--mono)", fontWeight:600 }}>{v}</div>
          </div>
        ))}
      </div>

      {/* Timeline */}
      <div>
        {(filter === "failures"
          ? TIMELINE_EVENTS.filter(e => e.flags.includes("RESPONSE_FAILURE"))
          : filtered
        ).map(event => (
          <EventCard
            key={event.id}
            event={event}
            expanded={expanded.has(event.id)}
            onToggle={() => toggle(event.id)}
            viewed={progress.timelineViewed.has(event.id)}
          />
        ))}
      </div>
    </div>
  );
}
