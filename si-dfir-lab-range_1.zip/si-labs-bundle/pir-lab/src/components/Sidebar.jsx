export default function Sidebar({ items, active, onSelect, collapsed, onToggle, progress }) {
  const getItemStatus = (id) => {
    if (id === "timeline") return progress.timelineViewed.size > 0 ? "partial" : "none";
    if (id === "evidence") return progress.evidenceOpened.size > 0 ? "partial" : "none";
    if (id === "gaps") return progress.gapsDone ? "done" : "none";
    if (id === "metrics") return progress.metricsCalcDone ? "done" : "none";
    if (id === "report") return progress.reportGenerated ? "done" : "none";
    return "none";
  };

  return (
    <aside style={{
      width: collapsed ? 52 : 210,
      flexShrink: 0,
      background: "var(--s1)",
      borderRight: "1px solid var(--line)",
      display: "flex",
      flexDirection: "column",
      transition: "width .2s ease",
      overflow: "hidden",
    }}>
      {/* Toggle */}
      <button onClick={onToggle} style={{
        display:"flex", alignItems:"center", justifyContent: collapsed ? "center" : "flex-end",
        padding: "10px 12px", background:"transparent", color:"var(--t4)", fontSize:14,
        borderBottom:"1px solid var(--line)",
      }}>
        {collapsed ? "▶" : "◀"}
      </button>

      {/* Nav items */}
      <nav style={{ flex:1, padding:"8px 6px", overflow:"auto" }}>
        {items.map((item, i) => {
          const isActive = active === item.id;
          const status = getItemStatus(item.id);
          return (
            <button key={item.id} onClick={() => onSelect(item.id)} style={{
              display:"flex", alignItems:"center", gap:9,
              width:"100%", padding: collapsed ? "9px 0" : "9px 10px",
              borderRadius:6, marginBottom:2,
              background: isActive ? "rgba(0,229,255,.08)" : "transparent",
              border: `1px solid ${isActive ? "rgba(0,229,255,.2)" : "transparent"}`,
              color: isActive ? "var(--cyan)" : "var(--t3)",
              fontSize:12, fontWeight: isActive ? 600 : 400,
              textAlign:"left", transition:"all .12s",
              justifyContent: collapsed ? "center" : "flex-start",
              animation: `slideRight .2s ${i * 0.04}s both`,
              position:"relative",
            }}
            onMouseEnter={e => { if(!isActive) e.currentTarget.style.background="var(--s3)"; e.currentTarget.style.color="var(--t2)"; }}
            onMouseLeave={e => { if(!isActive) { e.currentTarget.style.background="transparent"; e.currentTarget.style.color="var(--t3)"; } }}
            >
              <span style={{ fontSize:14, flexShrink:0 }}>{item.icon}</span>
              {!collapsed && (
                <>
                  <span style={{ flex:1, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{item.label}</span>
                  {item.badge && (
                    <span style={{
                      fontSize:9, padding:"1px 5px", borderRadius:10,
                      background: isActive ? "rgba(0,229,255,.15)" : "var(--s3)",
                      color: isActive ? "var(--cyan)" : "var(--t4)",
                      fontFamily:"var(--mono)", fontWeight:700,
                    }}>{item.badge}</span>
                  )}
                  {status === "done" && <span style={{ fontSize:10, color:"var(--green)" }}>✓</span>}
                  {status === "partial" && <span style={{ width:6, height:6, borderRadius:"50%", background:"var(--amber)", flexShrink:0 }} />}
                </>
              )}
            </button>
          );
        })}
      </nav>

      {/* Lab info */}
      {!collapsed && (
        <div style={{ padding:"12px 10px", borderTop:"1px solid var(--line)" }}>
          <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", letterSpacing:".08em", marginBottom:6 }}>Lab 9 of 12</div>
          <div style={{ height:2, background:"var(--line)", borderRadius:1, overflow:"hidden" }}>
            <div style={{ height:"100%", width:"75%", background:"linear-gradient(90deg,var(--cyan),var(--purple))" }} />
          </div>
          <div style={{ fontSize:9, color:"var(--t3)", marginTop:4 }}>Post-Incident Review</div>
        </div>
      )}
    </aside>
  );
}
