// ─── TOP NAV ─────────────────────────────────────────────────────────────────
import { useState } from "react";
import { ACHIEVEMENTS } from "../data/incident.js";

export default function TopNav({ page, xp, rank, completionPct, unlockedAch }) {
  const [showAch, setShowAch] = useState(false);
  const timeLeft = Math.max(0, Math.round((100 - completionPct) * 0.6));

  return (
    <header style={{
      height: 52, flexShrink: 0,
      background: "var(--s1)", borderBottom: "1px solid var(--line)",
      display: "flex", alignItems: "center", padding: "0 16px", gap: 12,
      position: "relative", zIndex: 100,
    }}>
      {/* Logo */}
      <div style={{ display:"flex", alignItems:"center", gap:9, marginRight:8 }}>
        <div style={{
          width:30, height:30, borderRadius:7,
          background: "linear-gradient(135deg, rgba(0,229,255,.15), rgba(167,139,250,.1))",
          border: "1px solid rgba(0,229,255,.3)",
          display:"flex", alignItems:"center", justifyContent:"center",
          fontSize:14, boxShadow:"0 0 12px rgba(0,229,255,.15)",
        }}>⚔</div>
        <div>
          <div style={{ fontSize:13, fontWeight:800, color:"var(--t1)", letterSpacing:".04em", fontFamily:"var(--ui)", lineHeight:1 }}>NexusIR</div>
          <div style={{ fontSize:8, color:"var(--t4)", letterSpacing:".12em", textTransform:"uppercase", fontFamily:"var(--mono)" }}>DFIR Platform</div>
        </div>
      </div>

      {/* Divider */}
      <div style={{ width:1, height:24, background:"var(--line)" }} />

      {/* Lab title */}
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:12, fontWeight:600, color:"var(--t1)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
          Lab 9: Post-Incident Review &amp; Lessons Learned
        </div>
        <div style={{ fontSize:10, color:"var(--t3)", fontFamily:"var(--mono)" }}>INC-2026-0447 · BlackMatter Ransomware · Meridian Financial Services</div>
      </div>

      {/* Severity badge */}
      <div style={{
        padding:"3px 10px", borderRadius:20,
        background:"rgba(255,61,87,.12)", border:"1px solid rgba(255,61,87,.3)",
        fontSize:10, fontWeight:700, color:"var(--red)", fontFamily:"var(--mono)",
        letterSpacing:".06em",
      }}>P1 CRITICAL</div>

      {/* Completion */}
      <div style={{ display:"flex", alignItems:"center", gap:8, background:"var(--s3)", border:"1px solid var(--line)", borderRadius:20, padding:"5px 14px" }}>
        <div style={{ fontSize:10, color:"var(--t3)", fontFamily:"var(--mono)" }}>Progress</div>
        <div style={{ width:80, height:3, background:"var(--line)", borderRadius:2, overflow:"hidden" }}>
          <div style={{ height:"100%", width:`${completionPct}%`, background:"linear-gradient(90deg,var(--cyan),var(--purple))", transition:"width .5s" }} />
        </div>
        <div style={{ fontSize:10, color:"var(--cyan)", fontFamily:"var(--mono)", fontWeight:700 }}>{completionPct}%</div>
      </div>

      {/* Time estimate */}
      <div style={{ fontSize:10, color:"var(--t3)", fontFamily:"var(--mono)", whiteSpace:"nowrap" }}>
        ~{timeLeft}m remaining
      </div>

      {/* Achievements */}
      <div style={{ position:"relative" }}>
        <button onClick={() => setShowAch(v => !v)} style={{
          background:"var(--s3)", border:"1px solid var(--line)",
          borderRadius:6, padding:"5px 12px",
          color:"var(--t2)", fontSize:11, display:"flex", alignItems:"center", gap:6,
        }}>
          🏆 <span style={{ fontFamily:"var(--mono)", color:"var(--amber)" }}>{unlockedAch.size}</span>/{ACHIEVEMENTS.length}
        </button>
        {showAch && (
          <div style={{
            position:"absolute", right:0, top:"calc(100% + 8px)",
            background:"var(--s2)", border:"1px solid var(--line)",
            borderRadius:10, padding:12, width:260,
            boxShadow:"0 12px 40px rgba(0,0,0,.7)", zIndex:200,
          }}>
            <div style={{ fontSize:10, color:"var(--t4)", fontFamily:"var(--mono)", marginBottom:10, textTransform:"uppercase", letterSpacing:".08em" }}>Achievements</div>
            {ACHIEVEMENTS.map(a => (
              <div key={a.id} style={{ display:"flex", gap:8, padding:"6px 0", borderBottom:"1px solid var(--line)", opacity: unlockedAch.has(a.id) ? 1 : 0.35 }}>
                <span style={{ fontSize:18 }}>{a.icon}</span>
                <div>
                  <div style={{ fontSize:11, fontWeight:600, color: unlockedAch.has(a.id) ? "var(--t1)" : "var(--t4)" }}>{a.name}</div>
                  <div style={{ fontSize:10, color:"var(--t3)" }}>{a.desc}</div>
                </div>
                <div style={{ marginLeft:"auto", fontSize:10, color:"var(--amber)", fontFamily:"var(--mono)", whiteSpace:"nowrap" }}>+{a.xp}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Analyst */}
      <div style={{ display:"flex", alignItems:"center", gap:8, background:"var(--s3)", border:"1px solid var(--line)", borderRadius:6, padding:"5px 12px" }}>
        <div style={{ width:24, height:24, borderRadius:"50%", background:"rgba(0,229,255,.12)", border:"1px solid rgba(0,229,255,.2)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:12 }}>◈</div>
        <div>
          <div style={{ fontSize:11, fontWeight:600, color:"var(--t1)", lineHeight:1 }}>Alex Rivera</div>
          <div style={{ fontSize:9, color:rank.color, fontFamily:"var(--mono)" }}>{rank.name}</div>
        </div>
        <div style={{ marginLeft:4 }}>
          <div style={{ fontSize:10, color:"var(--cyan)", fontFamily:"var(--mono)", fontWeight:700 }}>{xp.toLocaleString()} XP</div>
        </div>
      </div>
    </header>
  );
}
