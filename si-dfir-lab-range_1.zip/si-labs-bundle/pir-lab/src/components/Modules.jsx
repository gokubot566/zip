import { useState } from "react";
import { GAPS, RECOMMENDATIONS, ASSESSMENT_QUESTIONS, XP_EVENTS } from "../data/incident.js";

// ─── GAP ANALYSIS ─────────────────────────────────────────────────────────────
export function GapAnalysis({ trackProgress, progress, addXP }) {
  const [classified, setClassified] = useState({ worked: new Set(), improve: new Set() });
  const [expanded, setExpanded] = useState(null);
  const [notes, setNotes] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [result, setResult] = useState(null); // frozen { correct, total } at submit time

  const allItems = [
    ...GAPS.workedWell.map(g => ({ ...g, expected: "worked" })),
    ...GAPS.needsImprovement.map(g => ({ ...g, expected: "improve" })),
  ];

  function classify(id, bucket) {
    if (submitted) return; // lock after submission so the score can't be gamed
    setClassified(p => {
      const n = { ...p };
      n.worked = new Set(p.worked); n.improve = new Set(p.improve);
      n.worked.delete(id); n.improve.delete(id);
      n[bucket].add(id);
      return n;
    });
  }

  function submit() {
    const c = allItems.filter(i =>
      (i.expected === "worked" && classified.worked.has(i.id)) ||
      (i.expected === "improve" && classified.improve.has(i.id))
    ).length;
    setResult({ correct: c, total: allItems.length });
    setSubmitted(true);
    // Award XP proportional to accuracy; only mark the module complete when fully correct
    const earned = Math.round(XP_EVENTS.gapAnalysisCompleted * (c / allItems.length));
    addXP(earned, `Gap analysis (${c}/${allItems.length} correct)`);
    if (c === allItems.length) trackProgress("gaps_done");
  }

  const total = allItems.length;
  const done = classified.worked.size + classified.improve.size;
  const correct = allItems.filter(i =>
    (i.expected === "worked" && classified.worked.has(i.id)) ||
    (i.expected === "improve" && classified.improve.has(i.id))
  ).length;

  return (
    <div style={{ padding:"20px 24px", maxWidth:1100, margin:"0 auto" }}>
      <div style={{ marginBottom:16 }}>
        <h2 style={{ fontSize:20, fontWeight:800, color:"var(--t1)", marginBottom:4 }}>Gap Analysis</h2>
        <p style={{ fontSize:12, color:"var(--t3)" }}>
          Classify each action as "Worked Well" or "Needs Improvement". {done}/{total} classified.
          {submitted && result && <span style={{ color: result.correct===result.total?"var(--green)":"var(--amber)", marginLeft:8 }}>Score: {result.correct}/{result.total} correct</span>}
        </p>
      </div>

      {/* Progress */}
      <div style={{ height:4, background:"var(--line)", borderRadius:2, overflow:"hidden", marginBottom:16 }}>
        <div style={{ height:"100%", width:`${(done/total)*100}%`, background:"linear-gradient(90deg,var(--cyan),var(--purple))", transition:"width .4s" }} />
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
        {/* Worked Well */}
        <div>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:10, padding:"8px 12px", background:"rgba(0,230,118,.06)", border:"1px solid rgba(0,230,118,.2)", borderRadius:7 }}>
            <span style={{ fontSize:16 }}>✅</span>
            <div>
              <div style={{ fontSize:12, fontWeight:700, color:"var(--green)" }}>Worked Well</div>
              <div style={{ fontSize:10, color:"var(--t3)" }}>{classified.worked.size} items classified</div>
            </div>
          </div>
          {[...classified.worked].map(id => {
            const item = allItems.find(i => i.id === id);
            if (!item) return null;
            return (
              <div key={id} style={{ background:"rgba(0,230,118,.05)", border:"1px solid rgba(0,230,118,.2)", borderRadius:7, padding:"10px 12px", marginBottom:6 }}>
                <div style={{ fontSize:12, fontWeight:600, color:"var(--green)", marginBottom:3 }}>{item.title}</div>
                <div style={{ fontSize:10, color:"var(--t3)", lineHeight:1.5 }}>{item.detail?.slice(0,100)}...</div>
                {submitted && item.expected === "worked" && <div style={{ fontSize:9, color:"var(--green)", fontFamily:"var(--mono)", marginTop:4 }}>✓ CORRECT</div>}
                {submitted && item.expected !== "worked" && <div style={{ fontSize:9, color:"var(--red)", fontFamily:"var(--mono)", marginTop:4 }}>✗ Incorrect — this belongs in "Needs Improvement"</div>}
                <button onClick={() => classify(id, "improve")} style={{ marginTop:6, fontSize:9, color:"var(--t3)", background:"transparent", border:"1px solid var(--line)", borderRadius:4, padding:"2px 8px", cursor:"pointer" }}>Move →</button>
              </div>
            );
          })}
        </div>

        {/* Needs Improvement */}
        <div>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:10, padding:"8px 12px", background:"rgba(255,61,87,.06)", border:"1px solid rgba(255,61,87,.2)", borderRadius:7 }}>
            <span style={{ fontSize:16 }}>⚠</span>
            <div>
              <div style={{ fontSize:12, fontWeight:700, color:"var(--red)" }}>Needs Improvement</div>
              <div style={{ fontSize:10, color:"var(--t3)" }}>{classified.improve.size} items classified</div>
            </div>
          </div>
          {[...classified.improve].map(id => {
            const item = allItems.find(i => i.id === id);
            if (!item) return null;
            return (
              <div key={id} style={{ background:"rgba(255,61,87,.05)", border:"1px solid rgba(255,61,87,.2)", borderRadius:7, padding:"10px 12px", marginBottom:6 }}>
                <div style={{ fontSize:12, fontWeight:600, color:"var(--red)", marginBottom:3 }}>{item.title}</div>
                <div style={{ fontSize:10, color:"var(--t3)", lineHeight:1.5 }}>{item.detail?.slice(0,100)}...</div>
                {submitted && item.expected === "improve" && <div style={{ fontSize:9, color:"var(--green)", fontFamily:"var(--mono)", marginTop:4 }}>✓ CORRECT</div>}
                {submitted && item.expected !== "improve" && <div style={{ fontSize:9, color:"var(--red)", fontFamily:"var(--mono)", marginTop:4 }}>✗ Incorrect — this belongs in "Worked Well"</div>}
                <button onClick={() => classify(id, "worked")} style={{ marginTop:6, fontSize:9, color:"var(--t3)", background:"transparent", border:"1px solid var(--line)", borderRadius:4, padding:"2px 8px", cursor:"pointer" }}>← Move</button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Unclassified items */}
      <div style={{ marginTop:16 }}>
        <div style={{ fontSize:11, fontWeight:600, color:"var(--t2)", marginBottom:10 }}>Unclassified Items — Drag or click to classify</div>
        <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
          {allItems.filter(i => !classified.worked.has(i.id) && !classified.improve.has(i.id)).map(item => (
            <div key={item.id} className="card" style={{ padding:"12px 14px" }}>
              <div style={{ display:"flex", gap:10, alignItems:"flex-start" }}>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:12, fontWeight:600, color:"var(--t1)", marginBottom:3 }}>{item.title}</div>
                  <div style={{ fontSize:11, color:"var(--t3)", lineHeight:1.5 }}>{item.detail}</div>
                  {item.recommendation && (
                    <div style={{ fontSize:10, color:"var(--amber)", marginTop:6, fontFamily:"var(--mono)", lineHeight:1.5 }}>
                      💡 {item.recommendation?.slice(0,120)}...
                    </div>
                  )}
                </div>
                <div style={{ display:"flex", gap:6, flexShrink:0 }}>
                  <button className="btn btn-green" style={{ fontSize:10, padding:"5px 12px" }} onClick={() => classify(item.id, "worked")}>✅ Worked Well</button>
                  <button className="btn btn-red" style={{ fontSize:10, padding:"5px 12px" }} onClick={() => classify(item.id, "improve")}>⚠ Needs Improvement</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {done === total && !submitted && (
        <div style={{ marginTop:20, display:"flex", justifyContent:"center" }}>
          <button className="btn btn-cyan" style={{ padding:"10px 32px", fontSize:13 }} onClick={submit}>
            Submit Gap Analysis (+{XP_EVENTS.gapAnalysisCompleted} XP)
          </button>
        </div>
      )}

      {submitted && result && (
        <div style={{ marginTop:16, background: result.correct===result.total?"rgba(0,230,118,.06)":"rgba(255,184,48,.06)", border:`1px solid ${result.correct===result.total?"rgba(0,230,118,.2)":"rgba(255,184,48,.25)"}`, borderRadius:8, padding:"14px 16px", textAlign:"center" }}>
          <div style={{ fontSize:16, fontWeight:700, color: result.correct===result.total?"var(--green)":"var(--amber)", marginBottom:4 }}>
            {result.correct===result.total ? "Gap Analysis Complete!" : "Review Your Classifications"}
          </div>
          <div style={{ fontSize:13, color:"var(--t2)" }}>Score: {result.correct}/{result.total} · {Math.round(result.correct/result.total*100)}% accuracy</div>
          {result.correct !== result.total && (
            <>
              <div style={{ fontSize:11, color:"var(--t3)", marginTop:6 }}>Some items are in the wrong bucket — incorrect ones are marked with ✗ above. Fix them to score 100% and complete the module.</div>
              <button className="btn btn-cyan" style={{ marginTop:10, padding:"7px 22px", fontSize:12 }} onClick={() => { setSubmitted(false); setResult(null); }}>Try Again</button>
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ─── RECOMMENDATIONS ENGINE ───────────────────────────────────────────────────
const PRIORITY_COLORS = { CRITICAL:"var(--red)", HIGH:"var(--amber)", MEDIUM:"#60a5fa", LOW:"var(--green)" };
const STATUS_COLORS = { OPEN:"var(--amber)", IN_PROGRESS:"var(--cyan)", CLOSED:"var(--green)" };

export function Recommendations({ addXP }) {
  const [recs, setRecs] = useState(RECOMMENDATIONS);
  const [showForm, setShowForm] = useState(false);
  const [earnedXP, setEarnedXP] = useState(0);
  const [flash, setFlash] = useState(false);
  const [form, setForm] = useState({ priority:"HIGH", title:"", issue:"", plan:"", team:"", impact:"", effort:"Medium", framework:"" });

  function addRec() {
    if (!form.title || !form.issue) return;
    setRecs(p => [...p, { ...form, id:`R${p.length+1}`, status:"OPEN", preventive:"Medium" }]);
    setForm({ priority:"HIGH", title:"", issue:"", plan:"", team:"", impact:"", effort:"Medium", framework:"" });
    setShowForm(false);
    addXP(XP_EVENTS.recommendationAdded, "Recommendation added");
    setEarnedXP(x => x + XP_EVENTS.recommendationAdded);
    setFlash(true);
    setTimeout(() => setFlash(false), 1200);
  }

  return (
    <div style={{ padding:"20px 24px", maxWidth:1100, margin:"0 auto" }}>
      <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:16 }}>
        <div>
          <h2 style={{ fontSize:20, fontWeight:800, color:"var(--t1)", marginBottom:4 }}>Recommendations Engine</h2>
          <p style={{ fontSize:12, color:"var(--t3)" }}>{recs.length} recommendations · Prioritised by risk impact</p>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div style={{
            fontSize:11, fontFamily:"var(--mono)", color: flash ? "var(--green)" : "var(--cyan)",
            background:"var(--s3)", border:`1px solid ${flash?"rgba(0,230,118,.4)":"var(--line2)"}`,
            borderRadius:6, padding:"6px 12px", transition:"all .2s",
            transform: flash ? "scale(1.06)" : "scale(1)",
          }} title="XP earned from adding recommendations (+75 each)">
            +{earnedXP} XP earned
          </div>
          <button className="btn btn-cyan" onClick={() => setShowForm(v => !v)}>
            {showForm ? "Cancel" : `+ Add Recommendation (+${XP_EVENTS.recommendationAdded} XP)`}
          </button>
        </div>
      </div>

      {/* Add form */}
      {showForm && (
        <div className="card" style={{ padding:16, marginBottom:16, border:"1px solid rgba(0,229,255,.2)" }}>
          <div style={{ fontSize:12, fontWeight:700, color:"var(--cyan)", marginBottom:12 }}>New Recommendation</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
            {[
              ["title","Recommendation Title","text"],
              ["team","Responsible Team","text"],
              ["issue","Issue Identified","text"],
              ["impact","Expected Impact","text"],
              ["plan","Implementation Plan","text"],
              ["framework","Framework Mapping (optional)","text"],
            ].map(([k,ph,t]) => (
              <div key={k}>
                <label style={{ fontSize:10, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", marginBottom:4, display:"block" }}>{ph}</label>
                <input value={form[k]} onChange={e => setForm(p => ({...p,[k]:e.target.value}))} placeholder={ph} type={t} />
              </div>
            ))}
            <div>
              <label style={{ fontSize:10, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", marginBottom:4, display:"block" }}>Priority</label>
              <select value={form.priority} onChange={e => setForm(p => ({...p,priority:e.target.value}))} style={{ width:"100%", background:"var(--s3)", border:"1px solid var(--line2)", color:"var(--t1)", padding:"8px 12px", borderRadius:6, fontFamily:"var(--mono)", fontSize:12 }}>
                {["CRITICAL","HIGH","MEDIUM","LOW"].map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize:10, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", marginBottom:4, display:"block" }}>Implementation Effort</label>
              <select value={form.effort} onChange={e => setForm(p => ({...p,effort:e.target.value}))} style={{ width:"100%", background:"var(--s3)", border:"1px solid var(--line2)", color:"var(--t1)", padding:"8px 12px", borderRadius:6, fontFamily:"var(--mono)", fontSize:12 }}>
                {["Low","Medium","High","Very High"].map(e => <option key={e} value={e}>{e}</option>)}
              </select>
            </div>
          </div>
          <button className="btn btn-cyan" style={{ marginTop:12 }} onClick={addRec}>Add Recommendation (+{XP_EVENTS.recommendationAdded} XP)</button>
        </div>
      )}

      {/* Priority summary */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8, marginBottom:14 }}>
        {["CRITICAL","HIGH","MEDIUM","LOW"].map(p => {
          const count = recs.filter(r => r.priority === p).length;
          const c = PRIORITY_COLORS[p];
          return (
            <div key={p} style={{ background:"var(--s2)", border:`1px solid ${c}25`, borderRadius:6, padding:"10px 12px" }}>
              <div style={{ fontSize:9, fontFamily:"var(--mono)", color:c, textTransform:"uppercase", marginBottom:3 }}>{p}</div>
              <div style={{ fontSize:22, fontWeight:800, color:c, fontFamily:"var(--mono)" }}>{count}</div>
            </div>
          );
        })}
      </div>

      {/* Rec cards */}
      <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
        {recs.map((rec, i) => {
          const pc = PRIORITY_COLORS[rec.priority] || "var(--t3)";
          const sc = STATUS_COLORS[rec.status] || "var(--t3)";
          return (
            <div key={rec.id} className="card" style={{
              borderLeft:`3px solid ${pc}`,
              animation:`fadeIn .25s ${i*.05}s both`,
            }}>
              <div style={{ padding:"12px 16px" }}>
                <div style={{ display:"flex", gap:8, alignItems:"flex-start", marginBottom:10 }}>
                  <div style={{ flex:1 }}>
                    <div style={{ display:"flex", gap:8, alignItems:"center", marginBottom:4, flexWrap:"wrap" }}>
                      <span style={{ fontSize:9, fontFamily:"var(--mono)", color:pc, background:`${pc}15`, padding:"1px 8px", borderRadius:3, fontWeight:700, border:`1px solid ${pc}30`, textTransform:"uppercase" }}>{rec.priority}</span>
                      <span style={{ fontSize:9, fontFamily:"var(--mono)", color:sc, background:`${sc}10`, padding:"1px 8px", borderRadius:10, border:`1px solid ${sc}25` }}>{rec.status}</span>
                      <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--t4)" }}>{rec.id}</span>
                    </div>
                    <div style={{ fontSize:13, fontWeight:700, color:"var(--t1)", marginBottom:4 }}>{rec.title}</div>
                    <div style={{ fontSize:11, color:"var(--red)", lineHeight:1.5, marginBottom:8 }}>
                      <strong>Issue:</strong> {rec.issue}
                    </div>
                    <div style={{ fontSize:11, color:"var(--t2)", lineHeight:1.6, marginBottom:8 }}>
                      <strong style={{ color:"var(--t3)" }}>Plan:</strong> {rec.plan}
                    </div>
                    <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:8 }}>
                      {[
                        ["Team", rec.team, "var(--cyan)"],
                        ["Effort", rec.effort, "var(--amber)"],
                        ["Framework", rec.framework || "—", "var(--purple)"],
                      ].map(([l,v,c]) => (
                        <div key={l} style={{ background:"var(--s3)", borderRadius:5, padding:"6px 10px", border:"1px solid var(--line)" }}>
                          <div style={{ fontSize:8, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", marginBottom:2 }}>{l}</div>
                          <div style={{ fontSize:10, color:c, fontFamily:"var(--mono)" }}>{v}</div>
                        </div>
                      ))}
                    </div>
                    {rec.impact && (
                      <div style={{ marginTop:8, fontSize:11, color:"var(--green)", lineHeight:1.5 }}>
                        <strong style={{ color:"var(--t3)" }}>Expected Impact:</strong> {rec.impact}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── FINAL REPORT ──────────────────────────────────────────────────────────────
export function FinalReport({ trackProgress, progress, addXP }) {
  const [printed, setPrinted] = useState(false);

  function generate() {
    trackProgress("report_done");
    setPrinted(true);
  }

  return (
    <div style={{ padding:"20px 24px", maxWidth:960, margin:"0 auto" }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:16 }}>
        <div>
          <h2 style={{ fontSize:20, fontWeight:800, color:"var(--t1)", marginBottom:4 }}>Post-Incident Review Report</h2>
          <p style={{ fontSize:12, color:"var(--t3)" }}>Lessons Learned — INC-2026-0447 — BlackMatter Ransomware</p>
        </div>
        <div style={{ display:"flex", gap:8 }}>
          {!printed && <button className="btn btn-cyan" onClick={generate}>Generate Report (+150 XP)</button>}
          {printed && <button className="btn btn-green" onClick={() => window.print()}>🖨 Print / Export PDF</button>}
        </div>
      </div>

      <div style={{ background:"var(--s2)", border:"1px solid var(--line)", borderRadius:8, overflow:"hidden" }}>
        {/* Report header */}
        <div style={{ background:"linear-gradient(135deg,rgba(0,229,255,.08),rgba(167,139,250,.06))", borderBottom:"1px solid var(--line)", padding:"24px 28px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
            <div>
              <div style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--cyan)", letterSpacing:".14em", textTransform:"uppercase", marginBottom:6 }}>POST-INCIDENT REVIEW REPORT · CONFIDENTIAL</div>
              <h1 style={{ fontSize:22, fontWeight:800, color:"var(--t1)", marginBottom:4 }}>BlackMatter Ransomware Incident</h1>
              <div style={{ fontSize:12, color:"var(--t2)" }}>Meridian Financial Services · INC-2026-0447 · 14 November 2026</div>
            </div>
            <div style={{ textAlign:"right" }}>
              <div style={{ fontSize:36, fontWeight:800, color:"var(--amber)", fontFamily:"var(--mono)" }}>6.2/10</div>
              <div style={{ fontSize:10, color:"var(--t3)" }}>Maturity Score</div>
            </div>
          </div>
        </div>

        <div style={{ padding:"24px 28px" }}>
          {/* Executive summary */}
          <Section title="1. Executive Summary">
            <p style={{ fontSize:12, color:"var(--t2)", lineHeight:1.85 }}>
              On 14 November 2026, Meridian Financial Services experienced a ransomware attack by BlackMatter Pro v4.2 initiated via a spear-phishing email. The malware encrypted 84,721 files across 14 network shares, causing 18.4 hours of operational disruption and an estimated $2.34M in total business impact. Recovery was achieved through cloud backups, though the Compliance share suffered permanent data loss due to a 4-day silent backup failure.
            </p>
            <p style={{ fontSize:12, color:"var(--t2)", lineHeight:1.85, marginTop:10 }}>
              The incident response demonstrated strong detection capability (MTTD: 9.3 minutes) but was significantly hampered by a 25-minute containment delay, premature destruction of forensic evidence, delayed executive notification, and a critical backup monitoring gap. Six process failures were identified requiring immediate remediation.
            </p>
          </Section>

          {/* Metrics table */}
          <Section title="2. Incident Metrics">
            <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12 }}>
              <thead>
                <tr style={{ background:"var(--s3)" }}>
                  {["Metric","Value","Benchmark","Assessment"].map(h => (
                    <th key={h} style={{ padding:"8px 12px", textAlign:"left", fontSize:9, fontFamily:"var(--mono)", color:"var(--t4)", borderBottom:"1px solid var(--line)", textTransform:"uppercase", letterSpacing:".08em" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[
                  ["MTTD","9.3 minutes","<15m target","Excellent","var(--green)"],
                  ["MTTC","25.0 minutes","<15m for ransomware","Poor — 25m delay","var(--red)"],
                  ["MTTR","18.4 hours","<24h target","Acceptable","var(--amber)"],
                  ["Files Encrypted","84,721","0","Full encryption completed","var(--red)"],
                  ["Systems Affected","23","0","Critical infrastructure impacted","var(--amber)"],
                  ["Data Loss","Compliance share (4d)","None acceptable","Critical backup failure","var(--red)"],
                  ["Financial Impact","$2.34M","$0","Significant cost incurred","var(--red)"],
                ].map(([m,v,b,a,c]) => (
                  <tr key={m} style={{ borderBottom:"1px solid var(--line)" }}>
                    <td style={{ padding:"9px 12px", fontFamily:"var(--mono)", fontSize:11, color:"var(--t1)", fontWeight:600 }}>{m}</td>
                    <td style={{ padding:"9px 12px", fontFamily:"var(--mono)", fontSize:11, color:c }}>{v}</td>
                    <td style={{ padding:"9px 12px", fontSize:11, color:"var(--t3)" }}>{b}</td>
                    <td style={{ padding:"9px 12px", fontSize:11, color:c }}>{a}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Section>

          {/* Strengths */}
          <Section title="3. Operational Strengths">
            {GAPS.workedWell.map((g, i) => (
              <div key={g.id} style={{ display:"flex", gap:10, padding:"8px 0", borderBottom:"1px solid var(--line)" }}>
                <span style={{ color:"var(--green)", flexShrink:0, fontSize:12 }}>✓</span>
                <div>
                  <div style={{ fontSize:12, fontWeight:600, color:"var(--t1)" }}>{g.title}</div>
                  <div style={{ fontSize:11, color:"var(--t3)", lineHeight:1.5 }}>{g.detail}</div>
                </div>
              </div>
            ))}
          </Section>

          {/* Process gaps */}
          <Section title="4. Process Gaps & Failures">
            {GAPS.needsImprovement.map((g, i) => (
              <div key={g.id} style={{ background:"rgba(255,61,87,.05)", border:"1px solid rgba(255,61,87,.15)", borderRadius:6, padding:"12px 14px", marginBottom:8 }}>
                <div style={{ display:"flex", gap:8, alignItems:"center", marginBottom:5 }}>
                  <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--red)", background:"rgba(255,61,87,.15)", padding:"1px 7px", borderRadius:3, fontWeight:700 }}>FAILURE</span>
                  <span style={{ fontSize:12, fontWeight:700, color:"var(--t1)" }}>{g.title}</span>
                  <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--red)", marginLeft:"auto" }}>Score: {g.score}/10</span>
                </div>
                <div style={{ fontSize:11, color:"var(--t2)", lineHeight:1.6, marginBottom:6 }}>{g.detail}</div>
                <div style={{ fontSize:11, color:"var(--amber)", lineHeight:1.5 }}>
                  <strong style={{ color:"var(--t3)" }}>Recommendation: </strong>{g.recommendation}
                </div>
              </div>
            ))}
          </Section>

          {/* Top recommendations */}
          <Section title="5. Top Recommendations">
            {RECOMMENDATIONS.filter(r => r.priority === "CRITICAL" || r.priority === "HIGH").map((r, i) => (
              <div key={r.id} style={{ display:"flex", gap:10, padding:"10px 0", borderBottom:"1px solid var(--line)" }}>
                <span style={{ fontSize:10, fontFamily:"var(--mono)", color:PRIORITY_COLORS[r.priority]||"var(--t3)", fontWeight:700, flexShrink:0, background:`${PRIORITY_COLORS[r.priority]||"var(--t3)"}15`, padding:"1px 8px", borderRadius:3, border:`1px solid ${PRIORITY_COLORS[r.priority]||"var(--t3)"}30`, height:"fit-content" }}>{r.priority}</span>
                <div>
                  <div style={{ fontSize:12, fontWeight:600, color:"var(--t1)", marginBottom:3 }}>{r.title}</div>
                  <div style={{ fontSize:11, color:"var(--t3)", marginBottom:3 }}>{r.plan}</div>
                  <div style={{ fontSize:10, fontFamily:"var(--mono)", color:"var(--purple)" }}>{r.framework}</div>
                </div>
              </div>
            ))}
          </Section>

          {/* Maturity score */}
          <Section title="6. Response Maturity Assessment">
            <div style={{ display:"grid", gridTemplateColumns:"repeat(5,1fr)", gap:10, marginBottom:16 }}>
              {[
                ["Detection","9.0","var(--green)"],
                ["Containment","4.0","var(--red)"],
                ["Communication","5.5","var(--amber)"],
                ["Evidence","2.0","var(--red)"],
                ["Recovery","7.5","var(--amber)"],
              ].map(([d,s,c]) => (
                <div key={d} style={{ background:"var(--s3)", borderRadius:6, padding:"12px", textAlign:"center", border:"1px solid var(--line)" }}>
                  <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", marginBottom:6 }}>{d}</div>
                  <div style={{ fontSize:24, fontWeight:800, color:c, fontFamily:"var(--mono)" }}>{s}</div>
                  <div style={{ fontSize:8, color:"var(--t4)" }}>/ 10.0</div>
                </div>
              ))}
            </div>
            <div style={{ background:"var(--s3)", borderRadius:6, padding:"14px", border:"1px solid var(--line)" }}>
              <div style={{ fontSize:12, fontWeight:600, color:"var(--t2)", marginBottom:6 }}>Overall Response Maturity: <span style={{ color:"var(--amber)" }}>6.2/10 — Developing</span></div>
              <div style={{ fontSize:11, color:"var(--t3)", lineHeight:1.7 }}>
                The Meridian Financial response demonstrated a detection capability that meets best-practice benchmarks. However, critical failures in evidence preservation, containment governance, and backup monitoring significantly reduced the overall maturity score. Immediate implementation of the Critical-priority recommendations is required before this maturity level can be raised to "Established" (7.0+).
              </div>
            </div>
          </Section>
        </div>
      </div>

      {!printed && (
        <div style={{ marginTop:16, textAlign:"center" }}>
          <button className="btn btn-cyan" style={{ padding:"10px 40px", fontSize:13 }} onClick={generate}>
            Generate & Finalise Report (+150 XP)
          </button>
        </div>
      )}
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div style={{ marginBottom:24 }}>
      <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:12 }}>
        <h3 style={{ fontSize:13, fontWeight:700, color:"var(--cyan)", fontFamily:"var(--mono)" }}>{title}</h3>
        <div style={{ flex:1, height:1, background:"var(--line)" }} />
      </div>
      {children}
    </div>
  );
}

// ─── ASSESSMENT HUB ───────────────────────────────────────────────────────────
export function Assessment({ addXP, trackProgress }) {
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState({});
  const [written, setWritten] = useState({});
  const [totalScore, setTotalScore] = useState(0);
  const [done, setDone] = useState(new Set());

  function submitMCQ(qid, chosen, correct) {
    setSubmitted(p => ({...p,[qid]:{chosen,correct}}));
    const q = ASSESSMENT_QUESTIONS.find(q => q.id === qid);
    const isCorrect = chosen === correct;
    if (isCorrect) {
      addXP(q.points, "Correct answer");
      setTotalScore(p => p + q.points);
    }
    const newDone = new Set([...done, qid]);
    setDone(newDone);
    trackProgress("question_result", { qid, correct: isCorrect, totalQuestions: ASSESSMENT_QUESTIONS.length });
  }

  function submitWritten(qid) {
    if (!written[qid] || written[qid].length < 30) return;
    addXP(XP_EVENTS.writtenSubmitted, "Written response");
    setSubmitted(p => ({...p,[qid]:{written:true}}));
    const newDone = new Set([...done, qid]);
    setDone(newDone);
    // Written responses are accepted as correct once a substantive answer is given
    trackProgress("question_result", { qid, correct: true, totalQuestions: ASSESSMENT_QUESTIONS.length });
  }

  const maxScore = ASSESSMENT_QUESTIONS.reduce((s, q) => s + q.points, 0);

  return (
    <div style={{ padding:"20px 24px", maxWidth:860, margin:"0 auto" }}>
      <div style={{ marginBottom:16 }}>
        <h2 style={{ fontSize:20, fontWeight:800, color:"var(--t1)", marginBottom:4 }}>Assessment Hub</h2>
        <div style={{ display:"flex", gap:12, alignItems:"center" }}>
          <p style={{ fontSize:12, color:"var(--t3)" }}>{ASSESSMENT_QUESTIONS.length} questions · {done.size} completed</p>
          <div style={{ flex:1, height:3, background:"var(--line)", borderRadius:2, overflow:"hidden" }}>
            <div style={{ height:"100%", width:`${(done.size/ASSESSMENT_QUESTIONS.length)*100}%`, background:"linear-gradient(90deg,var(--cyan),var(--purple))", transition:"width .4s" }} />
          </div>
          <span style={{ fontSize:12, fontFamily:"var(--mono)", color:"var(--cyan)", fontWeight:700 }}>{totalScore}/{maxScore} pts</span>
        </div>
      </div>

      {ASSESSMENT_QUESTIONS.map((q, qi) => {
        const sub = submitted[q.id];
        const isWritten = q.type === "written";

        return (
          <div key={q.id} className="card" style={{ marginBottom:14, borderLeft:`3px solid ${sub ? (sub.correct !== undefined ? (sub.chosen === q.correct ? "var(--green)" : "var(--red)") : "var(--cyan)") : "var(--line)"}` }}>
            <div style={{ padding:"14px 16px" }}>
              <div style={{ display:"flex", gap:8, alignItems:"center", marginBottom:10 }}>
                <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--t4)", background:"var(--s3)", padding:"1px 7px", borderRadius:3, border:"1px solid var(--line2)" }}>Q{qi+1}</span>
                <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--cyan)", background:"var(--cyan-dim)", padding:"1px 7px", borderRadius:10, border:"1px solid rgba(0,229,255,.2)" }}>{q.points} pts</span>
                <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--t4)", textTransform:"uppercase" }}>{q.type}</span>
                {sub && <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--green)", marginLeft:"auto" }}>✓ Submitted</span>}
              </div>

              <p style={{ fontSize:13, fontWeight:600, color:"var(--t1)", lineHeight:1.6, marginBottom:14 }}>{q.question}</p>

              {/* MCQ */}
              {!isWritten && q.options && (
                <div style={{ display:"flex", flexDirection:"column", gap:6, marginBottom:12 }}>
                  {q.options.map((opt, oi) => {
                    const sel = answers[q.id] === oi;
                    const isCorrect = oi === q.correct;
                    const showResult = !!sub;
                    let bg = sel ? "rgba(0,229,255,.08)" : "transparent";
                    let border = sel ? "rgba(0,229,255,.3)" : "var(--line)";
                    let color = sel ? "var(--cyan)" : "var(--t2)";
                    if (showResult && isCorrect) { bg = "rgba(0,230,118,.08)"; border = "rgba(0,230,118,.3)"; color = "var(--green)"; }
                    if (showResult && sel && !isCorrect) { bg = "rgba(255,61,87,.08)"; border = "rgba(255,61,87,.3)"; color = "var(--red)"; }

                    return (
                      <button key={oi} onClick={() => !sub && setAnswers(p => ({...p,[q.id]:oi}))} style={{
                        display:"flex", alignItems:"flex-start", gap:10, padding:"10px 12px",
                        background:bg, border:`1px solid ${border}`, borderRadius:7,
                        color, fontSize:12, textAlign:"left", lineHeight:1.5, cursor: sub ? "default" : "pointer",
                        transition:"all .12s",
                      }}>
                        <span style={{ width:18, height:18, borderRadius:"50%", border:`1.5px solid ${border}`, flexShrink:0, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, marginTop:1 }}>
                          {sel && !showResult ? "●" : showResult && isCorrect ? "✓" : showResult && sel ? "✗" : String.fromCharCode(65+oi)}
                        </span>
                        <span>{opt}</span>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Written */}
              {isWritten && (
                <div style={{ marginBottom:12 }}>
                  <textarea
                    value={written[q.id] || ""}
                    onChange={e => setWritten(p => ({...p,[q.id]:e.target.value}))}
                    placeholder="Write your response here..."
                    rows={6} disabled={!!sub}
                    style={{ marginBottom:6 }}
                  />
                  {q.rubric && (
                    <div style={{ background:"var(--s3)", borderRadius:6, padding:"10px 12px", border:"1px solid var(--line)", marginBottom:8 }}>
                      <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", marginBottom:6 }}>Marking Rubric</div>
                      {q.rubric.map((r, i) => (
                        <div key={i} style={{ display:"flex", gap:6, fontSize:11, color:"var(--t3)", lineHeight:1.5, marginBottom:3 }}>
                          <span style={{ color:"var(--cyan)", flexShrink:0 }}>›</span> {r}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Submit / result */}
              {!sub ? (
                <div style={{ display:"flex", gap:10 }}>
                  {!isWritten ? (
                    <button className="btn btn-cyan" onClick={() => answers[q.id] !== undefined && submitMCQ(q.id, answers[q.id], q.correct)} disabled={answers[q.id] === undefined}>
                      Submit Answer
                    </button>
                  ) : (
                    <button className="btn btn-cyan" onClick={() => submitWritten(q.id)} disabled={!written[q.id] || written[q.id].length < 30}>
                      Submit Response (+{XP_EVENTS.writtenSubmitted} XP)
                    </button>
                  )}
                </div>
              ) : (
                <div style={{
                  padding:"10px 12px", borderRadius:6,
                  background: sub.chosen === q.correct ? "rgba(0,230,118,.08)" : sub.written ? "rgba(0,229,255,.08)" : "rgba(255,61,87,.08)",
                  border: `1px solid ${sub.chosen === q.correct ? "rgba(0,230,118,.25)" : sub.written ? "rgba(0,229,255,.25)" : "rgba(255,61,87,.25)"}`,
                }}>
                  {!isWritten && (
                    <>
                      <div style={{ fontSize:11, fontWeight:600, color: sub.chosen === q.correct ? "var(--green)" : "var(--red)", marginBottom:5 }}>
                        {sub.chosen === q.correct ? `✓ Correct! +${q.points} pts` : "✗ Incorrect"}
                      </div>
                      {q.explanation && <div style={{ fontSize:11, color:"var(--t2)", lineHeight:1.6 }}>{q.explanation}</div>}
                    </>
                  )}
                  {isWritten && (
                    <>
                      <div style={{ fontSize:11, fontWeight:600, color:"var(--cyan)", marginBottom:8 }}>✓ Response submitted. Sample answer below for self-assessment.</div>
                      <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", marginBottom:4 }}>Sample Answer</div>
                      <div style={{ fontSize:11, color:"var(--t3)", lineHeight:1.7, fontStyle:"italic" }}>{q.sampleAnswer}</div>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        );
      })}

      {done.size === ASSESSMENT_QUESTIONS.length && (
        <div style={{ textAlign:"center", padding:"24px 16px", background:"rgba(0,229,255,.06)", border:"1px solid rgba(0,229,255,.2)", borderRadius:10 }}>
          <div style={{ fontSize:36, marginBottom:8 }}>🏆</div>
          <div style={{ fontSize:20, fontWeight:700, color:"var(--cyan)", marginBottom:4 }}>Assessment Complete!</div>
          <div style={{ fontSize:13, color:"var(--t2)" }}>Score: {totalScore}/{maxScore} pts ({Math.round(totalScore/maxScore*100)}%)</div>
        </div>
      )}
    </div>
  );
}
