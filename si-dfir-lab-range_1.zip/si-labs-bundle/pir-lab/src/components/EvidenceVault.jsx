import { useState } from "react";
import { EVIDENCE_ITEMS } from "../data/incident.js";

const TYPE_ICONS = { email:"✉", alert:"🔔", log:"📋", fim:"📁", network:"🌐", forensics:"🔍", ransom:"☠", backup:"💾" };
const TYPE_COLORS = { email:"var(--amber)", alert:"var(--red)", log:"var(--cyan)", fim:"var(--red)", network:"var(--purple)", forensics:"var(--red)", ransom:"var(--red)", backup:"var(--amber)" };
const SEV_COLORS = { critical:"var(--red)", high:"var(--amber)", medium:"#60a5fa", low:"var(--green)" };

function EvidenceCard({ item, opened, onOpen }) {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  const tc = TYPE_COLORS[item.type] || "var(--t3)";

  function toggle() {
    setExpanded(v => !v);
    if (!opened) onOpen(item.id);
  }

  function copy() {
    navigator.clipboard?.writeText(item.contents).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="card" style={{
      marginBottom: 8,
      border:`1px solid ${item.type==="forensics"?"rgba(255,61,87,.3)":"var(--line)"}`,
      cursor:"pointer",
      transition:"border-color .15s",
    }}
    onMouseEnter={e => { if (!expanded) e.currentTarget.style.borderColor = tc.replace("var(","").replace(")","") + "40" || "var(--line2)"; }}
    onMouseLeave={e => { if (!expanded) e.currentTarget.style.borderColor = item.type==="forensics"?"rgba(255,61,87,.3)":"var(--line)"; }}
    >
      {/* Header */}
      <div style={{ padding:"10px 14px", display:"flex", gap:10, alignItems:"center" }} onClick={toggle}>
        <div style={{
          width:34, height:34, borderRadius:7, flexShrink:0,
          background:`${tc}12`, border:`1px solid ${tc}25`,
          display:"flex", alignItems:"center", justifyContent:"center", fontSize:16,
        }}>{TYPE_ICONS[item.type]}</div>

        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:"flex", gap:8, alignItems:"center", marginBottom:3 }}>
            <span style={{ fontFamily:"var(--mono)", fontSize:10, color:tc, fontWeight:700 }}>
              [{item.type.toUpperCase()}]
            </span>
            <span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--t4)" }}>{item.id}</span>
            {!opened && <span style={{ width:6, height:6, borderRadius:"50%", background:"var(--cyan)", flexShrink:0 }} />}
          </div>
          <div style={{ fontSize:12, fontWeight:600, color:"var(--t1)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{item.name}</div>
          <div style={{ fontSize:10, color:"var(--t3)", fontFamily:"var(--mono)", marginTop:1 }}>
            {item.file} · {item.size} · {item.timestamp.replace("T"," ").replace("Z"," UTC")}
          </div>
        </div>

        <div style={{ display:"flex", gap:6, alignItems:"center", flexShrink:0 }}>
          <span style={{
            fontSize:9, fontFamily:"var(--mono)", padding:"2px 7px", borderRadius:10,
            background:`${SEV_COLORS[item.severity]}12`, color:SEV_COLORS[item.severity],
            border:`1px solid ${SEV_COLORS[item.severity]}25`,
          }}>{item.severity.toUpperCase()}</span>
          <span style={{ fontSize:10, color:"var(--t4)", transition:"transform .15s", transform: expanded ? "rotate(180deg)" : "none" }}>▼</span>
        </div>
      </div>

      {/* Expanded */}
      {expanded && (
        <div style={{ borderTop:"1px solid var(--line)", animation:"fadeIn .2s ease-out" }}>
          {/* Tags */}
          <div style={{ padding:"8px 14px", display:"flex", gap:5, flexWrap:"wrap", borderBottom:"1px solid var(--line)" }}>
            {item.tags.map(t => (
              <span key={t} style={{ fontSize:9, fontFamily:"var(--mono)", padding:"1px 6px", borderRadius:10, background:"var(--s3)", border:"1px solid var(--line2)", color:"var(--t3)" }}>{t}</span>
            ))}
            <span style={{ marginLeft:"auto", fontSize:9, fontFamily:"var(--mono)", color:"var(--t4)" }}>
              SHA-256: {item.hash}
            </span>
          </div>

          {/* File viewer */}
          <div style={{ padding:"12px 14px" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:8 }}>
              <span style={{ fontSize:10, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", letterSpacing:".08em" }}>
                File Contents — {item.file}
              </span>
              <button className="btn btn-ghost" style={{ fontSize:10, padding:"3px 10px" }} onClick={copy}>
                {copied ? "✓ Copied" : "Copy"}
              </button>
            </div>
            <pre style={{
              background:"#050810", border:"1px solid var(--line)", borderRadius:6,
              padding:"12px 14px", fontFamily:"var(--mono)", fontSize:11,
              color: item.type === "forensics" ? "#ff8888" : "var(--t2)",
              lineHeight:1.7, overflowX:"auto", whiteSpace:"pre-wrap",
              wordBreak:"break-word", maxHeight:280, overflowY:"auto",
            }}>{item.contents}</pre>
          </div>
        </div>
      )}
    </div>
  );
}

export default function EvidenceVault({ trackProgress, progress, addXP }) {
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [sevFilter, setSevFilter] = useState("all");

  const filtered = EVIDENCE_ITEMS.filter(e => {
    const matchType = typeFilter === "all" || e.type === typeFilter;
    const matchSev = sevFilter === "all" || e.severity === sevFilter;
    const matchSearch = !search || e.name.toLowerCase().includes(search.toLowerCase()) || e.tags.some(t => t.includes(search.toLowerCase()));
    return matchType && matchSev && matchSearch;
  });

  const types = ["all", ...new Set(EVIDENCE_ITEMS.map(e => e.type))];

  return (
    <div style={{ padding:"20px 24px", maxWidth:960, margin:"0 auto" }}>
      <div style={{ marginBottom:16 }}>
        <h2 style={{ fontSize:20, fontWeight:800, color:"var(--t1)", marginBottom:4 }}>Evidence Vault</h2>
        <p style={{ fontSize:12, color:"var(--t3)" }}>
          {EVIDENCE_ITEMS.length} artifacts collected · {progress.evidenceOpened.size} reviewed ·
          Click any item to inspect contents
        </p>
      </div>

      {/* Stats */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8, marginBottom:14 }}>
        {[
          ["Total Evidence",`${EVIDENCE_ITEMS.length} items`,"var(--cyan)"],
          ["Critical Items",`${EVIDENCE_ITEMS.filter(e=>e.severity==="critical").length} items`,"var(--red)"],
          ["Reviewed",`${progress.evidenceOpened.size}/${EVIDENCE_ITEMS.length}`,"var(--green)"],
          ["Forensics Gap","1 critical loss","var(--red)"],
        ].map(([l,v,c]) => (
          <div key={l} style={{ background:"var(--s2)", border:"1px solid var(--line)", borderRadius:6, padding:"10px 12px" }}>
            <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", letterSpacing:".08em", marginBottom:3 }}>{l}</div>
            <div style={{ fontSize:14, fontWeight:700, color:c, fontFamily:"var(--mono)" }}>{v}</div>
          </div>
        ))}
      </div>

      {/* Forensics warning */}
      <div style={{
        background:"rgba(255,61,87,.07)", border:"1px solid rgba(255,61,87,.25)",
        borderRadius:7, padding:"10px 14px", marginBottom:14,
        display:"flex", gap:10, alignItems:"flex-start",
      }}>
        <span style={{ fontSize:16, flexShrink:0 }}>⚠</span>
        <div>
          <div style={{ fontSize:12, fontWeight:700, color:"var(--red)", marginBottom:3 }}>Forensic Evidence Gap — EV-006</div>
          <div style={{ fontSize:11, color:"var(--t2)", lineHeight:1.6 }}>
            WKSTN-SC-04 was reimaged at 02:22 UTC without DFIR team approval. Original malware binary, memory contents, and encryption key material were permanently destroyed.
            This violated IR Playbook Section 4.2. Review EV-006 for full impact assessment.
          </div>
        </div>
      </div>

      {/* Filters */}
      <div style={{ display:"flex", gap:10, marginBottom:14, flexWrap:"wrap" }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search evidence..." style={{ maxWidth:200 }} />
        <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
          {types.map(t => (
            <button key={t} className="btn" onClick={() => setTypeFilter(t)} style={{
              padding:"4px 10px", fontSize:10,
              background: typeFilter===t ? "var(--cyan-dim)" : "transparent",
              border:`1px solid ${typeFilter===t?"rgba(0,229,255,.3)":"var(--line2)"}`,
              color: typeFilter===t ? "var(--cyan)" : "var(--t3)",
            }}>{t === "all" ? "All Types" : `${TYPE_ICONS[t]||""} ${t}`}</button>
          ))}
        </div>
        <div style={{ display:"flex", gap:4 }}>
          {["all","critical","high","medium"].map(s => (
            <button key={s} className="btn" onClick={() => setSevFilter(s)} style={{
              padding:"4px 10px", fontSize:10,
              background: sevFilter===s ? "var(--s3)" : "transparent",
              border:`1px solid ${sevFilter===s?"var(--line2)":"transparent"}`,
              color:`${SEV_COLORS[s]||"var(--t3)"}`,
            }}>{s === "all" ? "All Sev" : s}</button>
          ))}
        </div>
      </div>

      {/* Evidence list */}
      <div>
        {filtered.map(item => (
          <EvidenceCard
            key={item.id} item={item}
            opened={progress.evidenceOpened.has(item.id)}
            onOpen={id => trackProgress("evidence", id)}
          />
        ))}
        {filtered.length === 0 && (
          <div style={{ textAlign:"center", padding:40, color:"var(--t4)", fontSize:12 }}>No evidence matches your filters</div>
        )}
      </div>
    </div>
  );
}
