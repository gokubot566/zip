import { useState, useEffect, useCallback } from "react";
import { INCIDENT, XP_EVENTS, ACHIEVEMENTS } from "./data/incident.js";
import TopNav from "./components/TopNav.jsx";
import Sidebar from "./components/Sidebar.jsx";
import Overview from "./components/Overview.jsx";
import Timeline from "./components/Timeline.jsx";
import Metrics from "./components/Metrics.jsx";
import EvidenceVault from "./components/EvidenceVault.jsx";
import GapAnalysis from "./components/GapAnalysis.jsx";
import Recommendations from "./components/Recommendations.jsx";
import FinalReport from "./components/FinalReport.jsx";
import Assessment from "./components/Assessment.jsx"; // eslint-disable-line no-unused-vars
import ByteAssistant from "./components/ByteAssistant.jsx";

const CSS = `
@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
@keyframes slideRight{from{opacity:0;transform:translateX(-16px)}to{opacity:1;transform:translateX(0)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes glow{0%,100%{box-shadow:0 0 8px rgba(0,229,255,.3)}50%{box-shadow:0 0 20px rgba(0,229,255,.6)}}
@keyframes countUp{from{transform:scale(.8);opacity:0}to{transform:scale(1);opacity:1}}
@keyframes popIn{0%{transform:scale(0) rotate(-10deg);opacity:0}60%{transform:scale(1.1) rotate(2deg)}100%{transform:scale(1) rotate(0);opacity:1}}
@keyframes shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}
@keyframes ticker{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}

:root{
  --bg:#060a0f;--s1:#0a1018;--s2:#0e1620;--s3:#131d2a;--s4:#192435;
  --line:#1a2535;--line2:#243344;
  --cyan:#00e5ff;--cyan2:#00b8cc;--cyan-dim:rgba(0,229,255,.08);
  --amber:#ffb830;--amber-dim:rgba(255,184,48,.08);
  --red:#ff3d57;--red-dim:rgba(255,61,87,.08);
  --green:#00e676;--green-dim:rgba(0,230,118,.08);
  --purple:#a78bfa;--purple-dim:rgba(167,139,250,.08);
  --t1:#e8f4ff;--t2:#8bacc8;--t3:#4a6a88;--t4:#2a3f54;
  --mono:'JetBrains Mono',monospace;
  --ui:'Outfit',sans-serif;
}

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;overflow:hidden;background:var(--bg)}
body{font-family:var(--ui);color:var(--t1);font-size:13px;line-height:1.5}
::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--line2);border-radius:2px}
::-webkit-scrollbar-thumb:hover{background:var(--t4)}

button{cursor:pointer;font-family:var(--ui);border:none;outline:none;transition:all .15s}
input,textarea{font-family:var(--mono);background:var(--s3);border:1px solid var(--line2);border-radius:6px;color:var(--t1);padding:8px 12px;font-size:12px;outline:none;width:100%;transition:border-color .15s}
input:focus,textarea:focus{border-color:var(--cyan)}
textarea{resize:vertical;line-height:1.7;min-height:100px}

.btn{display:inline-flex;align-items:center;gap:6px;padding:7px 16px;border-radius:6px;font-size:12px;font-weight:600;font-family:var(--ui);transition:all .15s;white-space:nowrap;cursor:pointer}
.btn-cyan{background:var(--cyan-dim);border:1px solid rgba(0,229,255,.25);color:var(--cyan)}
.btn-cyan:hover{background:rgba(0,229,255,.14);border-color:rgba(0,229,255,.5)}
.btn-red{background:var(--red-dim);border:1px solid rgba(255,61,87,.25);color:var(--red)}
.btn-red:hover{background:rgba(255,61,87,.14)}
.btn-amber{background:var(--amber-dim);border:1px solid rgba(255,184,48,.25);color:var(--amber)}
.btn-amber:hover{background:rgba(255,184,48,.18)}
.btn-ghost{background:transparent;border:1px solid var(--line2);color:var(--t2)}
.btn-ghost:hover{background:var(--s3);color:var(--t1)}
.btn-green{background:var(--green-dim);border:1px solid rgba(0,230,118,.25);color:var(--green)}

.tag{display:inline-flex;align-items:center;gap:4px;font-family:var(--mono);font-size:9px;font-weight:700;padding:2px 7px;border-radius:3px;letter-spacing:.06em;white-space:nowrap;text-transform:uppercase}
.dot{width:5px;height:5px;border-radius:50%;flex-shrink:0}

.card{background:var(--s2);border:1px solid var(--line);border-radius:8px;overflow:hidden}
.card-head{display:flex;align-items:center;gap:8px;padding:12px 16px;border-bottom:1px solid var(--line);background:var(--s3)}

.fade-in{animation:fadeIn .3s ease-out both}
.slide-right{animation:slideRight .25s ease-out both}

.sev-critical{color:var(--red)}
.sev-high{color:var(--amber)}
.sev-medium{color:#60a5fa}
.sev-low{color:var(--green)}

.flag-failure{background:rgba(255,61,87,.12);border-left:3px solid var(--red)}

.mono{font-family:var(--mono)}

.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}

.achievement-popup{position:fixed;bottom:24px;right:24px;z-index:9999;background:linear-gradient(135deg,var(--s3),var(--s2));border:1px solid rgba(0,229,255,.3);border-radius:12px;padding:16px 20px;min-width:280px;box-shadow:0 8px 40px rgba(0,0,0,.6),0 0 20px rgba(0,229,255,.15);animation:popIn .5s cubic-bezier(.34,1.56,.64,1) both}

.xp-bar{height:3px;background:var(--line);border-radius:2px;overflow:hidden}
.xp-fill{height:100%;background:linear-gradient(90deg,var(--cyan),var(--purple));transition:width .6s ease-out}

.ticker-wrap{overflow:hidden;width:100%}
.ticker-inner{display:inline-flex;white-space:nowrap;animation:ticker 40s linear infinite}
.ticker-inner:hover{animation-play-state:paused}

.glass{background:rgba(14,22,32,.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)}
`;

function useStyles() {
  useEffect(() => {
    const id = "pir-styles";
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id; el.textContent = CSS;
    document.head.insertBefore(el, document.head.firstChild);
  }, []);
}

const NAV_ITEMS = [
  { id: "overview",       icon: "◈", label: "Overview",          badge: null },
  { id: "timeline",       icon: "⊞", label: "Incident Timeline",  badge: "19" },
  { id: "metrics",        icon: "◉", label: "Metrics Center",     badge: null },
  { id: "evidence",       icon: "⊟", label: "Evidence Vault",     badge: "12" },
  { id: "gaps",           icon: "⊕", label: "Gap Analysis",       badge: null },
  { id: "recommendations",icon: "▸", label: "Recommendations",    badge: "6" },
  { id: "report",         icon: "◻", label: "Final Report",       badge: null },
];

const RANKS = [
  { name: "Trainee Analyst",    minXP: 0,    color: "#8bacc8" },
  { name: "Junior Analyst",     minXP: 200,  color: "#60a5fa" },
  { name: "SOC Analyst II",     minXP: 500,  color: "#00e676" },
  { name: "Senior Analyst",     minXP: 900,  color: "#00e5ff" },
  { name: "IR Specialist",      minXP: 1400, color: "#a78bfa" },
  { name: "IR Commander",       minXP: 2000, color: "#ffb830" },
];

function getRank(xp) {
  let rank = RANKS[0];
  for (const r of RANKS) { if (xp >= r.minXP) rank = r; }
  const next = RANKS[RANKS.findIndex(r => r === rank) + 1];
  const progress = next ? Math.round(((xp - rank.minXP) / (next.minXP - rank.minXP)) * 100) : 100;
  return { ...rank, next, progress };
}

export default function App() {
  useStyles();
  const [page, setPage]       = useState("overview");
  const [xp, setXP]           = useState(0);
  const [unlockedAch, setUnlocked] = useState(new Set());
  const [popup, setPopup]     = useState(null);
  const [sideCollapsed, setSideCollapsed] = useState(false);
  const [progress, setProgress] = useState({
    timelineViewed: new Set(),
    evidenceOpened: new Set(),
    questionsAnswered: new Set(),
    questionsCorrect: new Set(),
    gapsDone: false,
    reportGenerated: false,
    metricsCalcDone: false,
  });

  const addXP = useCallback((amount, reason) => {
    setXP(p => p + amount);
  }, []);

  const unlock = useCallback((achId) => {
    if (unlockedAch.has(achId)) return;
    const ach = ACHIEVEMENTS.find(a => a.id === achId);
    if (!ach) return;
    setUnlocked(p => new Set([...p, achId]));
    setXP(p => p + ach.xp);
    setPopup(ach);
    setTimeout(() => setPopup(null), 3500);
  }, [unlockedAch]);

  const trackProgress = useCallback((type, id) => {
    setProgress(p => {
      const next = { ...p };
      if (type === "timeline") {
        next.timelineViewed = new Set([...p.timelineViewed, id]);
        if (next.timelineViewed.size === 19) unlock("timeline_master");
      }
      if (type === "evidence") {
        next.evidenceOpened = new Set([...p.evidenceOpened, id]);
        if (next.evidenceOpened.size === 1) unlock("first_blood");
        addXP(XP_EVENTS.evidenceOpened, "Evidence opened");
      }
      if (type === "question") {
        // Record that a question was answered. Correctness is tracked separately.
        next.questionsAnswered = new Set([...(p.questionsAnswered||[]), id]);
      }
      if (type === "question_result") {
        next.questionsAnswered = new Set([...(p.questionsAnswered||[]), id.qid]);
        next.questionsCorrect = new Set(p.questionsCorrect || []);
        if (id.correct) next.questionsCorrect.add(id.qid);
        const totalQ = id.totalQuestions || 5;
        // Perfect score only when every question is answered AND every one is correct
        if (next.questionsAnswered.size === totalQ && next.questionsCorrect.size === totalQ) {
          unlock("perfect_score");
        }
      }
      if (type === "gaps_done") { next.gapsDone = true; unlock("gap_hunter"); }
      if (type === "report_done") { next.reportGenerated = true; unlock("report_ready"); addXP(XP_EVENTS.reportGenerated, "Report generated"); }
      if (type === "metrics_done") { next.metricsCalcDone = true; unlock("metric_wizard"); addXP(XP_EVENTS.metricsCalculated, "Metrics calculated"); }
      return next;
    });
  }, [unlock, addXP]);

  const rank = getRank(xp);
  const totalEvents = 19;
  const completionPct = Math.round(
    ((progress.timelineViewed.size / totalEvents) * 20 +
    (progress.evidenceOpened.size / 8) * 20 +
    (progress.gapsDone ? 20 : 0) +
    (progress.metricsCalcDone ? 20 : 0) +
    (progress.reportGenerated ? 20 : 0))
  );

  const pageProps = { addXP, unlock, trackProgress, progress, xp, rank };

  const pages = {
    overview:        <Overview {...pageProps} />,
    timeline:        <Timeline {...pageProps} />,
    metrics:         <Metrics {...pageProps} />,
    evidence:        <EvidenceVault {...pageProps} />,
    gaps:            <GapAnalysis {...pageProps} />,
    recommendations: <Recommendations {...pageProps} />,
    report:          <FinalReport {...pageProps} />,
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", height:"100dvh", background:"var(--bg)", overflow:"hidden" }}>
      <TopNav
        page={page} xp={xp} rank={rank}
        completionPct={completionPct}
        unlockedAch={unlockedAch}
        onThemeToggle={() => {}}
      />
      <div style={{ flex:1, display:"flex", overflow:"hidden" }}>
        <Sidebar
          items={NAV_ITEMS} active={page}
          onSelect={setPage}
          collapsed={sideCollapsed}
          onToggle={() => setSideCollapsed(v => !v)}
          progress={progress}
        />
        <main style={{ flex:1, overflow:"auto", background:"var(--bg)", position:"relative" }}>
          <div key={page} style={{ animation:"fadeIn .25s ease-out both", height:"100%" }}>
            {pages[page]}
          </div>
        </main>
      </div>

      {/* Achievement popup */}
      {popup && (
        <div className="achievement-popup">
          <div style={{ display:"flex", gap:12, alignItems:"center" }}>
            <div style={{ fontSize:32 }}>{popup.icon}</div>
            <div>
              <div style={{ fontSize:10, color:"var(--cyan)", fontFamily:"var(--mono)", letterSpacing:".1em", textTransform:"uppercase", marginBottom:3 }}>Achievement Unlocked</div>
              <div style={{ fontSize:14, fontWeight:700, color:"var(--t1)", marginBottom:2 }}>{popup.name}</div>
              <div style={{ fontSize:11, color:"var(--t2)" }}>{popup.desc}</div>
              <div style={{ fontSize:11, color:"var(--cyan)", marginTop:4, fontFamily:"var(--mono)", fontWeight:600 }}>+{popup.xp} XP</div>
            </div>
          </div>
        </div>
      )}

      {/* Byte Assistant */}
      <ByteAssistant activePage={page} onNavigate={setPage} />
    </div>
  );
}
