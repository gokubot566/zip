export { BytePanel as default } from "./Panels.jsx";
