export { ProcessMonitor as default } from "./Panels.jsx";
