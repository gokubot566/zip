export { EvidenceLog as default } from "./Panels.jsx";
