import { useState, useRef, useEffect, useCallback } from "react";
import { COMMANDS, WORKSTATION } from "../data/lab.js";

const WELCOME = `ForensicOS v2.0 — Digital Forensics & Incident Response Lab
Simulated Ubuntu 22.04.3 LTS — ubuntu-ws-047
═══════════════════════════════════════════════════════════════
⚠  ACTIVE COMPROMISE DETECTED — INC-2026-C2-0312
    C2 Beacon: 185.220.101.93:4444 (BlackMatter infrastructure)
    Malware:   /tmp/.cache/syslogd-helper [PID 1887]
═══════════════════════════════════════════════════════════════
INSTRUCTIONS:
  1. Collect volatile evidence IN ORDER (RFC 3227 — most volatile first)
  2. Type commands below — use 'save [filename]' after any output
  3. Evidence is automatically hashed on save
  4. Do NOT contain/kill until all volatile evidence is collected
  Type 'help' for guidance, 'volatility' for collection order
`;

const HELP_TEXT = `Available commands:
  date                          — System timestamp (collect FIRST)
  ps aux                        — Running processes
  ss -tulpn                     — Socket statistics
  netstat -antp                 — Network connections with PIDs
  who / w                       — Logged-in users
  arp -a                        — ARP cache
  ip route                      — Routing table
  last                          — Login history
  lsof -i                       — Open network files
  lsof -p 1887                  — Files opened by malware PID
  ls -la /tmp/.cache            — Malware staging directory
  crontab -l                    — User crontab (persistence)
  cat /etc/cron.hourly/sys-update — Root persistence script
  sha256sum /tmp/.cache/syslogd-helper — Hash malware binary
  uname -a                      — OS/kernel version
  ifconfig                      — Network interfaces
  dmesg | tail -20              — Kernel audit messages
  cat /etc/resolv.conf          — DNS config

Evidence collection:
  save <filename>               — Save last output to evidence file
  evidence list                 — Show collected evidence

Containment (ONLY after evidence collected):
  contain                       — Run containment actions

Other:
  clear                         — Clear terminal
  volatility                    — Show RFC 3227 collection order
  help                          — This help text
`;

const VOLATILITY_TEXT = `RFC 3227 — Evidence Collection Order (Most → Least Volatile)
══════════════════════════════════════════════════════════════
1.  CPU registers, ARP cache, routing tables  [MOST VOLATILE]
2.  Running processes                          → ps aux
3.  Network connections / open sockets        → ss, netstat, lsof
4.  Logged-in users / login history           → who, w, last
5.  Open files and file handles               → lsof
6.  System date/time (document as T0)         → date
7.  Disk contents / filesystem                → ls, sha256sum
8.  Remote logging / SIEM data                [LEAST VOLATILE]
══════════════════════════════════════════════════════════════
RULE: Collect RAM/network/process data BEFORE any containment.
      Once you kill the process or reboot, it's gone forever.
`;

const CONTAINMENT_OUTPUT = `[ForensicOS] ══ CONTAINMENT SEQUENCE INITIATED ══
[09:22:11] Killing malware PID 1887... done
[09:22:11] Killing worker PID 1892... done
[09:22:12] Removing crontab entry... done
[09:22:12] Removing /etc/cron.hourly/sys-update... done
[09:22:13] Blocking 185.220.101.93 via iptables... done
[09:22:13] Isolating network interface ens160... done
[09:22:14] Preserving /tmp/.cache/ as evidence... done
[09:22:14] Notifying SOC — INC-2026-C2-0312 contained

[✓] CONTAINMENT COMPLETE — Host isolated from network
[!] Forensic copy of /tmp/.cache/ preserved at /evidence/tmp_cache.tar.gz
[!] Submit to malware analysis: sha256 3a7f9c2e4b8d1f6a...
`;

function generateHash(text) {
  let h = 0;
  for (let i = 0; i < text.length; i++) {
    h = ((h << 5) - h + text.charCodeAt(i)) >>> 0;
  }
  const chars = "0123456789abcdef";
  let hex = "";
  for (let i = 0; i < 64; i++) {
    hex += chars[(h * (i + 1) * 6364136223846793005 + 1442695040888963407) & 15];
    h = (h * 1664525 + 1013904223) >>> 0;
  }
  return hex;
}

export default function Terminal({ onAddEvidence, collected, containmentDone, onContain }) {
  const [lines,    setLines]  = useState([{ type:"banner", text:WELCOME }]);
  const [input,    setInput]  = useState("");
  const [history,  setHistory]= useState([]);
  const [histIdx,  setHistIdx]= useState(-1);
  const [lastOutput, setLastOutput] = useState(null);
  const [lastCmd,    setLastCmd]    = useState(null);
  const [saving,   setSaving] = useState(false);
  const [saveFilename, setSaveFilename] = useState("");
  const endRef   = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior:"smooth" }); }, [lines]);

  const addLine = useCallback((type, text) => {
    setLines(p => [...p, { type, text, id: Date.now() + Math.random() }]);
  }, []);

  function runCommand(raw) {
    const cmd = raw.trim();
    if (!cmd) return;

    setHistory(p => [cmd, ...p.slice(0, 49)]);
    setHistIdx(-1);

    // Show prompt + command
    addLine("prompt", `j.hartley@ubuntu-ws-047:~$ ${cmd}`);

    if (cmd === "clear") { setLines([]); return; }
    if (cmd === "help")  { setLastOutput(null); addLine("output", HELP_TEXT); return; }
    if (cmd === "volatility") { setLastOutput(null); addLine("output", VOLATILITY_TEXT); return; }
    if (cmd === "evidence list") {
      if (collected.size === 0) {
        addLine("error", "No evidence collected yet.");
      } else {
        addLine("output", `Collected evidence (${collected.size} items):\n` + [...collected].map((c, i) => `  ${i+1}. ${c}`).join("\n"));
      }
      setLastOutput(null);
      return;
    }

    if (cmd === "contain" || cmd === "containment") {
      if (!containmentDone) {
        const reqCmds = ["date","ps aux","ss -tulpn","who","arp -a","ip route","last","lsof -i","ls -la /tmp/.cache","crontab -l","sha256sum /tmp/.cache/syslogd-helper"];
        const missing = reqCmds.filter(c => !collected.has(c));
        if (missing.length > 0) {
          addLine("warning", `⚠ CONTAINMENT BLOCKED — Collect volatile evidence first!\nMissing: ${missing.slice(0,3).join(", ")}${missing.length > 3 ? ` +${missing.length-3} more` : ""}`);
          setLastOutput(null);
          return;
        }
        addLine("success", CONTAINMENT_OUTPUT);
        onContain();
      } else {
        addLine("output", "[✓] Containment already complete.");
      }
      setLastOutput(null);
      return;
    }

    // save command
    if (cmd.startsWith("save ")) {
      const filename = cmd.slice(5).trim() || "evidence.txt";
      if (!lastOutput) {
        addLine("error", "No command output to save. Run a command first.");
        return;
      }
      const hash = generateHash(lastOutput);
      const ts = new Date().toISOString().replace("T"," ").slice(0,19);
      onAddEvidence(lastCmd, lastOutput, filename, hash);
      addLine("success", `[✓] Evidence saved: ${filename}\n    Timestamp: ${ts} UTC\n    SHA256: ${hash}\n    Size: ${lastOutput.length} bytes`);
      setLastOutput(null);
      return;
    }

    // Look up in COMMANDS
    const cmdData = COMMANDS[cmd];
    if (cmdData) {
      const suspiciousIdx = cmdData.suspiciousLines || [];
      const lines_arr = cmdData.output.split("\n");
      const highlighted = lines_arr.map((line, i) => {
        if (suspiciousIdx.some(s => line.includes(String(s)) || (cmd === "ps aux" && (line.includes("syslogd-helper") || line.includes("tmux") || line.includes("sys-update"))) || (cmd === "ss -tulpn" && line.includes("185.220.101.93")) || (cmd === "netstat -antp" && line.includes("185.220.101.93")) || (cmd === "last" && line.includes("185.220.101.93")))) {
          return { text: line, suspicious: true };
        }
        return { text: line, suspicious: false };
      });

      addLine("cmd_output", { lines: highlighted, raw: cmdData.output, cmd, desc: cmdData.description });
      setLastOutput(cmdData.output);
      setLastCmd(cmd);

      // Auto-suggest save
      if (cmdData.volatile) {
        addLine("hint", `↑ Volatile data — save immediately: save ${cmd.replace(/ /g,"_").replace(/\//g,"-").replace(/[^a-z0-9_-]/gi,"")}_${Date.now()}.txt`);
      }
    } else {
      // Handle partial matches and common variations
      const similar = Object.keys(COMMANDS).filter(k => k.startsWith(cmd.split(" ")[0]));
      if (similar.length > 0) {
        addLine("error", `bash: ${cmd}: command not found\nDid you mean: ${similar[0]}?`);
      } else {
        addLine("error", `bash: ${cmd}: command not found\nType 'help' for available commands`);
      }
      setLastOutput(null);
    }
  }

  function handleKey(e) {
    if (e.key === "Enter") {
      e.preventDefault();
      runCommand(input);
      setInput("");
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      const next = Math.min(histIdx + 1, history.length - 1);
      setHistIdx(next);
      if (history[next]) setInput(history[next]);
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      const next = Math.max(histIdx - 1, -1);
      setHistIdx(next);
      setInput(next === -1 ? "" : history[next]);
    } else if (e.key === "Tab") {
      e.preventDefault();
      const cmds = Object.keys(COMMANDS).filter(c => c.startsWith(input));
      if (cmds.length === 1) setInput(cmds[0]);
    }
  }

  const sevColors = { banner:"#4db84d", prompt:"var(--green)", output:"var(--t2)", error:"var(--red)", warning:"var(--amber)", success:"var(--green)", hint:"#5a8a5a" };

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", background:"#030806", overflow:"hidden", position:"relative" }} onClick={() => inputRef.current?.focus()}>
      {/* Terminal output */}
      <div style={{ flex:1, overflow:"auto", padding:"12px 14px" }}>
        {lines.map((line, i) => {
          if (line.type === "cmd_output") {
            return (
              <div key={line.id || i} style={{ marginBottom:8, animation:"fadeIn .2s ease-out" }}>
                {line.text.lines.map((l, li) => (
                  <div key={li} style={{
                    fontFamily:"var(--term)", fontSize:"10.5px", lineHeight:1.65,
                    color: l.suspicious ? "var(--red)" : "var(--t2)",
                    background: l.suspicious ? "rgba(255,51,85,.06)" : "transparent",
                    whiteSpace:"pre",
                  }}>{l.text}</div>
                ))}
                <div style={{ fontSize:9, color:"var(--t3)", fontFamily:"var(--mono)", marginTop:4, padding:"2px 6px", background:"rgba(57,255,110,.04)", borderRadius:3, borderLeft:"2px solid var(--green3)" }}>
                  ℹ {line.text.desc}
                </div>
              </div>
            );
          }
          return (
            <div key={line.id || i} style={{
              fontFamily: line.type === "prompt" ? "var(--term)" : "var(--term)",
              fontSize: "10.5px", lineHeight:1.65, marginBottom:2,
              color: sevColors[line.type] || "var(--t2)",
              whiteSpace:"pre-wrap", wordBreak:"break-word",
              animation:"fadeIn .15s ease-out",
            }}>{line.text}</div>
          );
        })}
        <div ref={endRef} />
      </div>

      {/* Input line */}
      <div style={{ borderTop:"1px solid var(--line)", padding:"8px 14px", display:"flex", alignItems:"center", gap:8, background:"var(--s1)", flexShrink:0 }}>
        <span style={{ color:"var(--green)", fontFamily:"var(--term)", fontSize:11, flexShrink:0, whiteSpace:"nowrap" }}>
          j.hartley@ubuntu-ws-047:~$
        </span>
        <input
          ref={inputRef} value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKey}
          autoFocus
          style={{ flex:1, background:"transparent", border:"none", color:"var(--green)", fontFamily:"var(--term)", fontSize:11, padding:0, caretColor:"var(--green)" }}
          placeholder="Type a command (try 'help' or 'date')..."
          spellCheck={false} autoComplete="off"
        />
        <span style={{ color:"var(--green)", animation:"blink 1s step-end infinite", fontSize:12 }}>█</span>
      </div>

      {/* Quick command bar */}
      <div style={{ borderTop:"1px solid var(--line)", padding:"6px 14px", display:"flex", gap:6, flexWrap:"wrap", background:"var(--s2)", flexShrink:0 }}>
        {["date","ps aux","ss -tulpn","who","arp -a","ip route","last","lsof -i","crontab -l","sha256sum /tmp/.cache/syslogd-helper"].map(cmd => (
          <button key={cmd} onClick={() => { setInput(cmd); inputRef.current?.focus(); }}
            className="btn btn-ghost" style={{ fontSize:9, padding:"3px 8px", fontFamily:"var(--mono)", opacity: collected.has(cmd) ? .4 : 1 }}>
            {collected.has(cmd) ? "✓" : ""}{cmd.length > 22 ? cmd.slice(0,22)+"…" : cmd}
          </button>
        ))}
      </div>
    </div>
  );
}
