import { useState, useEffect, useRef } from "react";
import { ALERTS, BYTE_RESPONSES, VOLATILITY_ORDER } from "../data/lab.js";

// ─── EVIDENCE LOG ────────────────────────────────────────────────────────────
export function EvidenceLog({ evidence }) {
  const [selected, setSelected] = useState(null);

  if (evidence.length === 0) {
    return (
      <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:12, color:"var(--t4)", padding:40 }}>
        <span style={{ fontSize:40 }}>📂</span>
        <div style={{ fontSize:12, textAlign:"center" }}>
          No evidence collected yet.<br/>
          <span style={{ color:"var(--t3)" }}>Run a command in the terminal, then type <code style={{ fontFamily:"var(--mono)", color:"var(--green3)" }}>save filename.txt</code></span>
        </div>
      </div>
    );
  }

  return (
    <div style={{ flex:1, display:"flex", overflow:"hidden" }}>
      {/* List */}
      <div style={{ width:380, borderRight:"1px solid var(--line)", overflowY:"auto", flexShrink:0 }}>
        <div style={{ padding:"8px 14px", background:"var(--s2)", borderBottom:"1px solid var(--line)", display:"flex", alignItems:"center", gap:8 }}>
          <span style={{ fontSize:10, color:"var(--green)", fontFamily:"var(--mono)", flex:1 }}>CHAIN OF CUSTODY LOG</span>
          <span style={{ fontSize:9, color:"var(--t3)", fontFamily:"var(--mono)" }}>{evidence.length} items</span>
        </div>
        {evidence.map((ev, i) => (
          <div key={ev.id} className="evidence-row"
            style={{ background: selected?.id === ev.id ? "var(--s3)" : "transparent", cursor:"pointer", animationDelay:`${i*.04}s` }}
            onClick={() => setSelected(ev)}>
            <div style={{ display:"flex", gap:6, marginBottom:3 }}>
              <span style={{ fontSize:9, color:"var(--amber)", background:"var(--amber-dim)", padding:"1px 6px", borderRadius:3, fontWeight:700 }}>
                {ev.timestamp.split(" ")[1]}
              </span>
              <span style={{ fontSize:10, color:"var(--green)", fontWeight:600 }}>{ev.filename}</span>
            </div>
            <div style={{ fontSize:9, color:"var(--t3)" }}>{ev.cmd}</div>
            <div style={{ fontSize:8, color:"var(--t4)", marginTop:2, fontFamily:"var(--mono)" }}>{ev.hash.slice(0,32)}…</div>
          </div>
        ))}
      </div>

      {/* Detail */}
      <div style={{ flex:1, overflow:"auto", padding:16 }}>
        {selected ? (
          <div>
            <div style={{ marginBottom:12 }}>
              <div style={{ fontSize:14, fontWeight:700, color:"var(--green)", marginBottom:4 }}>{selected.filename}</div>
              <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                {[["Timestamp", selected.timestamp + " UTC"], ["Command", selected.cmd], ["Size", selected.size]].map(([k,v]) => (
                  <div key={k} style={{ background:"var(--s3)", borderRadius:5, padding:"5px 10px", border:"1px solid var(--line)" }}>
                    <div style={{ fontSize:8, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase" }}>{k}</div>
                    <div style={{ fontSize:10, color:"var(--t1)", fontFamily:"var(--mono)" }}>{v}</div>
                  </div>
                ))}
              </div>
            </div>
            <div style={{ marginBottom:10 }}>
              <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", marginBottom:4 }}>SHA256 HASH</div>
              <code style={{ fontSize:9, color:"var(--cyan)", background:"var(--s3)", padding:"6px 10px", borderRadius:5, display:"block", wordBreak:"break-all", fontFamily:"var(--mono)", border:"1px solid var(--line)" }}>{selected.hash}</code>
            </div>
            <div>
              <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", marginBottom:4 }}>FILE CONTENTS</div>
              <pre style={{ fontSize:10, color:"var(--t2)", background:"#030806", padding:"12px 14px", borderRadius:6, fontFamily:"var(--term)", lineHeight:1.65, overflowX:"auto", maxHeight:300, overflowY:"auto", border:"1px solid var(--line)" }}>
                {selected.output}
              </pre>
            </div>
          </div>
        ) : (
          <div style={{ height:"100%", display:"flex", alignItems:"center", justifyContent:"center", color:"var(--t4)", fontSize:12 }}>
            Select an evidence item to view
          </div>
        )}
      </div>
    </div>
  );
}

// ─── ALERTS PANEL ─────────────────────────────────────────────────────────────

export function AlertsPanel({ alerts, acked, onAck }) {
  const [selected, setSelected] = useState(null);
  const sevColors = { critical:"var(--red)", high:"var(--amber)", medium:"#60a5fa", low:"var(--green2)" };

  return (
    <div style={{ flex:1, display:"flex", overflow:"hidden" }}>
      {/* Alert list */}
      <div style={{ width:380, borderRight:"1px solid var(--line)", overflowY:"auto", flexShrink:0 }}>
        <div style={{ padding:"8px 14px", background:"var(--s2)", borderBottom:"1px solid var(--line)" }}>
          <span style={{ fontSize:10, color:"var(--amber)", fontFamily:"var(--mono)" }}>
            SIEM ALERT QUEUE — {alerts.filter(a => !acked.has(a.id)).length} OPEN
          </span>
        </div>
        {alerts.map((alert, i) => {
          const isAcked = acked.has(alert.id);
          const sc = sevColors[alert.sev] || "var(--t3)";
          return (
            <div key={alert.id}
              style={{
                padding:"10px 14px", borderBottom:"1px solid var(--line)",
                borderLeft:`2px solid ${selected?.id === alert.id ? sc : "transparent"}`,
                background: selected?.id === alert.id ? "var(--s3)" : "transparent",
                cursor:"pointer", opacity: isAcked ? .5 : 1,
                animation:`alertSlide .2s ${i*.05}s both`,
              }}
              onClick={() => setSelected(alert)}>
              <div style={{ display:"flex", gap:6, alignItems:"center", marginBottom:4 }}>
                <span style={{ fontSize:9, fontFamily:"var(--mono)", color:sc, background:`${sc}18`, padding:"1px 6px", borderRadius:3, fontWeight:700, textTransform:"uppercase" }}>{alert.sev}</span>
                <span style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)" }}>{alert.time} UTC</span>
                {isAcked && <span style={{ marginLeft:"auto", fontSize:9, color:"var(--green)", fontFamily:"var(--mono)" }}>ACK</span>}
              </div>
              <div style={{ fontSize:11, color: isAcked ? "var(--t4)" : "var(--t1)", fontWeight:600 }}>{alert.title}</div>
              <div style={{ fontSize:9, color:"var(--t3)", marginTop:2 }}>{alert.host} · {alert.rule}</div>
            </div>
          );
        })}
      </div>

      {/* Detail */}
      <div style={{ flex:1, padding:20, overflowY:"auto" }}>
        {selected ? (
          <div>
            <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:14 }}>
              <span style={{ fontSize:9, fontFamily:"var(--mono)", color:sevColors[selected.sev], background:`${sevColors[selected.sev]}15`, padding:"2px 8px", borderRadius:3, fontWeight:700, textTransform:"uppercase", border:`1px solid ${sevColors[selected.sev]}30` }}>{selected.sev}</span>
              <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--cyan)", background:"var(--cyan-dim)", padding:"2px 8px", borderRadius:10, border:"1px solid rgba(0,232,208,.2)" }}>{selected.rule}</span>
            </div>
            <div style={{ fontSize:15, fontWeight:700, color:"var(--t1)", marginBottom:10 }}>{selected.title}</div>
            <p style={{ fontSize:12, color:"var(--t2)", lineHeight:1.75, marginBottom:16 }}>{selected.detail}</p>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:16 }}>
              {[["Alert ID", selected.id], ["Host", selected.host], ["Rule", selected.rule], ["Time", selected.time + " UTC"]].map(([k,v]) => (
                <div key={k} style={{ background:"var(--s3)", borderRadius:6, padding:"8px 12px", border:"1px solid var(--line)" }}>
                  <div style={{ fontSize:8, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", marginBottom:2 }}>{k}</div>
                  <div style={{ fontSize:11, color:"var(--t1)", fontFamily:"var(--mono)" }}>{v}</div>
                </div>
              ))}
            </div>
            {!acked.has(selected.id) && (
              <button className="btn btn-green" onClick={() => onAck(selected.id)}>✓ Acknowledge Alert (+25 XP)</button>
            )}
          </div>
        ) : (
          <div style={{ height:"100%", display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:8, color:"var(--t4)" }}>
            <span style={{ fontSize:32 }}>🔔</span>
            <span style={{ fontSize:12 }}>Select an alert to view details</span>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── PROCESS MONITOR ─────────────────────────────────────────────────────────
export function ProcessMonitor() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const iv = setInterval(() => setTick(p => p + 1), 2000);
    return () => clearInterval(iv);
  }, []);

  const processes = [
    { pid:1887, user:"j.hartley", cpu: (2.1 + Math.sin(tick/3)*0.4).toFixed(1), mem:"0.4", name:"/tmp/.cache/syslogd-helper -c 185.220.101.93 -p 4444 -d", suspicious:true },
    { pid:1892, user:"j.hartley", cpu: (0.2 + Math.abs(Math.sin(tick/5))*0.1).toFixed(1), mem:"0.2", name:"/tmp/.cache/syslogd-helper -c 185.220.101.93 -p 4444 -d [worker]", suspicious:true },
    { pid:2241, user:"j.hartley", cpu:"0.1", mem:"0.3", name:"tmux: server", suspicious:true },
    { pid:612,  user:"root",      cpu:"0.0", mem:"0.1", name:"/usr/sbin/sshd -D", suspicious:false },
    { pid:614,  user:"root",      cpu:"0.0", mem:"0.3", name:"/usr/sbin/rsyslogd -n -iNONE", suspicious:false },
    { pid:1441, user:"j.hartley", cpu:"0.0", mem:"0.1", name:"-bash", suspicious:false },
    { pid:3302, user:"root",      cpu:"0.0", mem:"0.1", name:"/bin/bash /etc/cron.hourly/sys-update", suspicious:true },
  ];

  return (
    <div style={{ flex:1, overflow:"hidden", display:"flex", flexDirection:"column" }}>
      <div style={{ padding:"8px 14px", background:"var(--s2)", borderBottom:"1px solid var(--line)", display:"flex", gap:12, alignItems:"center" }}>
        <span style={{ fontSize:10, color:"var(--green)", fontFamily:"var(--mono)" }}>PROCESS MONITOR — LIVE</span>
        <span style={{ width:7, height:7, borderRadius:"50%", background:"var(--green)", animation:"pulse 1.5s infinite", display:"inline-block" }} />
        <span style={{ fontSize:9, color:"var(--red)", marginLeft:"auto", fontFamily:"var(--mono)" }}>⚠ 3 suspicious processes</span>
      </div>
      <div style={{ flex:1, overflow:"auto" }}>
        <table style={{ width:"100%", borderCollapse:"collapse" }}>
          <thead>
            <tr style={{ background:"var(--s2)" }}>
              {["PID","USER","CPU%","MEM%","COMMAND"].map(h => (
                <th key={h} style={{ padding:"6px 12px", textAlign:"left", fontSize:9, fontFamily:"var(--mono)", color:"var(--t4)", borderBottom:"1px solid var(--line)", textTransform:"uppercase", letterSpacing:".08em" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {processes.map(p => (
              <tr key={p.pid} style={{ borderBottom:"1px solid var(--line)", background: p.suspicious ? "rgba(255,51,85,.04)" : "transparent" }}>
                <td style={{ padding:"7px 12px", fontFamily:"var(--mono)", fontSize:10, color: p.suspicious ? "var(--red)" : "var(--t3)" }}>{p.pid}</td>
                <td style={{ padding:"7px 12px", fontFamily:"var(--mono)", fontSize:10, color:"var(--t2)" }}>{p.user}</td>
                <td style={{ padding:"7px 12px", fontFamily:"var(--mono)", fontSize:10, color: parseFloat(p.cpu) > 1 ? "var(--red)" : "var(--green3)" }}>{p.cpu}</td>
                <td style={{ padding:"7px 12px", fontFamily:"var(--mono)", fontSize:10, color:"var(--t3)" }}>{p.mem}</td>
                <td style={{ padding:"7px 12px", fontFamily:"var(--mono)", fontSize:10, color: p.suspicious ? "var(--red)" : "var(--t2)", maxWidth:500, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                  {p.suspicious && <span style={{ marginRight:6, fontSize:9 }}>⚠</span>}
                  {p.name}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── NETWORK MONITOR ─────────────────────────────────────────────────────────
export function NetworkMonitor() {
  const [packets, setPackets] = useState([]);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const iv = setInterval(() => {
      setTick(p => p + 1);
      setPackets(prev => {
        const newPkt = {
          id: Date.now(),
          time: new Date().toISOString().slice(11, 23),
          src: tick % 3 === 0 ? "10.10.4.47" : "185.220.101.93",
          dst: tick % 3 === 0 ? "185.220.101.93" : "10.10.4.47",
          proto: tick % 4 === 0 ? "HTTPS" : "TCP",
          port: tick % 4 === 0 ? "443" : "4444",
          bytes: Math.floor(Math.random() * 1400 + 40),
          flags: tick % 5 === 0 ? "PSH ACK" : "ACK",
          suspicious: true,
        };
        return [newPkt, ...prev.slice(0, 29)];
      });
    }, 1500);
    return () => clearInterval(iv);
  }, [tick]);

  const connections = [
    { local:"10.10.4.47:52841", remote:"185.220.101.93:4444",  proto:"TCP", state:"ESTABLISHED", pid:"1887/syslogd-helper", suspicious:true, bytes:"142.8 MB TX" },
    { local:"10.10.4.47:52843", remote:"185.220.101.93:443",   proto:"TCP", state:"ESTABLISHED", pid:"1892/syslogd-helper", suspicious:true, bytes:"38.2 MB TX" },
    { local:"10.10.4.47:54129", remote:"10.10.4.1:22",         proto:"TCP", state:"ESTABLISHED", pid:"612/sshd",             suspicious:false, bytes:"normal" },
  ];

  return (
    <div style={{ flex:1, overflow:"hidden", display:"flex", flexDirection:"column" }}>
      {/* Active connections */}
      <div style={{ padding:"8px 14px", background:"var(--s2)", borderBottom:"1px solid var(--line)" }}>
        <span style={{ fontSize:10, color:"var(--amber)", fontFamily:"var(--mono)" }}>ACTIVE CONNECTIONS — LIVE</span>
      </div>
      <div style={{ flexShrink:0 }}>
        <table style={{ width:"100%", borderCollapse:"collapse" }}>
          <thead>
            <tr style={{ background:"var(--s2)" }}>
              {["Local","Remote","Proto","State","Process","Traffic"].map(h => (
                <th key={h} style={{ padding:"6px 12px", textAlign:"left", fontSize:9, fontFamily:"var(--mono)", color:"var(--t4)", borderBottom:"1px solid var(--line)", textTransform:"uppercase" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {connections.map((c, i) => (
              <tr key={i} style={{ borderBottom:"1px solid var(--line)", background: c.suspicious ? "rgba(255,51,85,.05)" : "transparent" }}>
                <td style={{ padding:"7px 12px", fontFamily:"var(--mono)", fontSize:10, color:"var(--t2)" }}>{c.local}</td>
                <td style={{ padding:"7px 12px", fontFamily:"var(--mono)", fontSize:10, color: c.suspicious ? "var(--red)" : "var(--t2)", fontWeight: c.suspicious ? 700 : 400 }}>{c.remote}</td>
                <td style={{ padding:"7px 12px", fontFamily:"var(--mono)", fontSize:10, color:"var(--t3)" }}>{c.proto}</td>
                <td style={{ padding:"7px 12px" }}>
                  <span style={{ fontSize:9, padding:"1px 6px", borderRadius:10, background:"rgba(57,255,110,.1)", color:"var(--green3)", fontFamily:"var(--mono)" }}>{c.state}</span>
                </td>
                <td style={{ padding:"7px 12px", fontFamily:"var(--mono)", fontSize:10, color: c.suspicious ? "var(--amber)" : "var(--t3)" }}>{c.pid}</td>
                <td style={{ padding:"7px 12px", fontFamily:"var(--mono)", fontSize:10, color: c.suspicious ? "var(--red)" : "var(--t3)" }}>{c.bytes}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Live packet stream */}
      <div style={{ padding:"6px 14px", background:"var(--s2)", borderTop:"1px solid var(--line)", borderBottom:"1px solid var(--line)" }}>
        <span style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)" }}>
          ⚡ LIVE TRAFFIC — C2 beacon active · {packets.length} packets captured
        </span>
      </div>
      <div style={{ flex:1, overflow:"auto", background:"#030806", padding:"8px 14px" }}>
        {packets.map(pkt => (
          <div key={pkt.id} style={{ fontFamily:"var(--term)", fontSize:10, lineHeight:1.6, color:"var(--red)", animation:"fadeIn .1s ease-out" }}>
            {pkt.time} {pkt.src.padEnd(18)} → {pkt.dst.padEnd(18)} {pkt.proto}/{pkt.port} [{pkt.flags}] {pkt.bytes}B
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── BYTE PANEL ───────────────────────────────────────────────────────────────

export function BytePanel({ onClose, collected }) {
  const [msgs,  setMsgs]  = useState([{ role:"bot", html: BYTE_RESPONSES.welcome, id: 1 }]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [tab, setTab] = useState("chat");
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior:"smooth" }); }, [msgs]);

  function getBotResponse(userMsg) {
    const msg = userMsg.toLowerCase();
    if (msg.includes("volatil") || msg.includes("order") || msg.includes("rfc")) return BYTE_RESPONSES["order of volatility"];
    if (msg.includes("c2") || msg.includes("command") || msg.includes("beacon")) return BYTE_RESPONSES["what is c2"];
    if (msg.includes("malware") || msg.includes("binary") || msg.includes("where")) return BYTE_RESPONSES["where is malware"];
    if (msg.includes("first") || msg.includes("start") || msg.includes("begin") || msg.includes("collect")) return BYTE_RESPONSES["what to collect first"];
    if (msg.includes("persist") || msg.includes("cron") || msg.includes("startup")) return BYTE_RESPONSES.persistence;
    if (msg.includes("hash") || msg.includes("sha") || msg.includes("integrity")) return BYTE_RESPONSES["how to hash"];
    if (msg.includes("tmux") || msg.includes("session")) return BYTE_RESPONSES["tmux sessions"];
    return BYTE_RESPONSES.default;
  }

  function send() {
    if (!input.trim()) return;
    const userMsg = input.trim();
    setInput("");
    setMsgs(p => [...p, { role:"user", text: userMsg, id: Date.now() }]);
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setMsgs(p => [...p, { role:"bot", html: getBotResponse(userMsg), id: Date.now() + 1 }]);
    }, 800 + Math.random() * 400);
  }

  const QUICK = ["what to collect first","order of volatility","where is malware","persistence","how to hash","tmux sessions"];

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
      {/* Header */}
      <div className="panel-head" style={{ justifyContent:"space-between" }}>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          <span style={{ fontSize:16 }}>🤖</span>
          <span style={{ fontSize:12, fontWeight:700, color:"var(--green)", fontFamily:"var(--mono)" }}>Byte Assistant</span>
          <span style={{ width:7, height:7, borderRadius:"50%", background:"var(--green)", animation:"pulse 2s infinite" }} />
        </div>
        <button onClick={onClose} style={{ background:"transparent", border:"none", color:"var(--t4)", fontSize:16, cursor:"pointer" }}>×</button>
      </div>

      {/* Tabs */}
      <div style={{ display:"flex", borderBottom:"1px solid var(--line)", background:"var(--s2)", padding:"0 14px" }}>
        {[["chat","Chat"],["volatility","RFC 3227"],["progress","Progress"]].map(([id,label]) => (
          <button key={id} className={`tab ${tab===id?"active":""}`} style={{ fontSize:10 }} onClick={() => setTab(id)}>{label}</button>
        ))}
      </div>

      {/* Tab: Chat */}
      {tab === "chat" && (
        <>
          <div style={{ flex:1, overflow:"auto", padding:14 }}>
            {msgs.map(msg => (
              <div key={msg.id} style={{ marginBottom:12, display:"flex", justifyContent: msg.role === "user" ? "flex-end" : "flex-start" }}>
                <div style={{
                  maxWidth:"90%", padding:"8px 12px", borderRadius:8,
                  background: msg.role === "user" ? "rgba(57,255,110,.08)" : "var(--s3)",
                  border: `1px solid ${msg.role === "user" ? "rgba(57,255,110,.2)" : "var(--line)"}`,
                  fontSize:11, lineHeight:1.7, animation:"fadeIn .2s ease-out",
                }}>
                  {msg.role === "bot"
                    ? <div style={{ color:"var(--t2)" }} dangerouslySetInnerHTML={{ __html: msg.html }} />
                    : <span style={{ color:"var(--green)" }}>{msg.text}</span>
                  }
                </div>
              </div>
            ))}
            {typing && (
              <div style={{ display:"flex", gap:4, padding:"4px 0" }}>
                {[0,1,2].map(i => <div key={i} style={{ width:6, height:6, borderRadius:"50%", background:"rgba(57,255,110,.4)", animation:`pulse 1.2s ${i*.2}s ease-in-out infinite` }} />)}
              </div>
            )}
            <div ref={endRef} />
          </div>

          {/* Quick buttons */}
          <div style={{ padding:"8px 14px", borderTop:"1px solid var(--line)", display:"flex", gap:5, flexWrap:"wrap" }}>
            {QUICK.map(q => (
              <button key={q} onClick={() => { setInput(q); }} style={{ fontSize:9, padding:"3px 8px", background:"var(--green-dim)", border:"1px solid rgba(57,255,110,.2)", borderRadius:4, color:"var(--green)", cursor:"pointer", fontFamily:"var(--mono)" }}>{q}</button>
            ))}
          </div>

          {/* Input */}
          <div style={{ padding:"10px 14px", borderTop:"1px solid var(--line)", display:"flex", gap:8, background:"var(--s2)" }}>
            <input value={input} onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && send()}
              placeholder="Ask Byte anything about DFIR..." style={{ flex:1, fontSize:11 }} />
            <button className="btn btn-green" onClick={send} style={{ padding:"5px 14px" }}>Send</button>
          </div>
        </>
      )}

      {/* Tab: Volatility Order */}
      {tab === "volatility" && (
        <div style={{ flex:1, overflow:"auto", padding:14 }}>
          <div style={{ fontSize:11, fontWeight:700, color:"var(--green)", marginBottom:12, fontFamily:"var(--mono)" }}>RFC 3227 — ORDER OF VOLATILITY</div>
          {VOLATILITY_ORDER.map((item, i) => (
            <div key={i} style={{ display:"flex", gap:10, padding:"8px 10px", borderBottom:"1px solid var(--line)", borderLeft:`2px solid ${i < 4 ? "var(--red)" : i < 7 ? "var(--amber)" : "var(--green3)"}` }}>
              <div style={{ fontSize:11, fontFamily:"var(--mono)", color:"var(--t4)", width:20, flexShrink:0 }}>{item.level}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:11, fontWeight:600, color:"var(--t1)" }}>{item.label}</div>
                <div style={{ fontSize:9, color:"var(--green3)", fontFamily:"var(--mono)" }}>{item.example}</div>
                <div style={{ fontSize:9, color:"var(--t4)" }}>{item.note}</div>
              </div>
              <div style={{ flexShrink:0 }}>
                <span style={{ fontSize:8, padding:"1px 6px", borderRadius:10, background: i < 4 ? "var(--red-dim)" : i < 7 ? "var(--amber-dim)" : "var(--green-dim)", color: i < 4 ? "var(--red)" : i < 7 ? "var(--amber)" : "var(--green)", fontFamily:"var(--mono)" }}>
                  {i < 4 ? "CRITICAL" : i < 7 ? "HIGH" : "LOW"}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab: Progress */}
      {tab === "progress" && (
        <div style={{ flex:1, overflow:"auto", padding:14 }}>
          <div style={{ fontSize:11, fontWeight:700, color:"var(--green)", marginBottom:12, fontFamily:"var(--mono)" }}>
            EVIDENCE COLLECTION PROGRESS — {collected.size} items
          </div>
          {[
            { label:"System Timestamp", cmd:"date", desc:"Investigation T0" },
            { label:"Running Processes", cmd:"ps aux", desc:"Capture malware PID" },
            { label:"Network Connections", cmd:"ss -tulpn", desc:"Confirm C2 beacon" },
            { label:"Logged-in Users", cmd:"who", desc:"Document sessions" },
            { label:"ARP Cache", cmd:"arp -a", desc:"Local network map" },
            { label:"Routing Table", cmd:"ip route", desc:"Default gateway" },
            { label:"Login History", cmd:"last", desc:"C2 IP login at 03:41" },
            { label:"Open Files", cmd:"lsof -i", desc:"File handles" },
            { label:"Malware Directory", cmd:"ls -la /tmp/.cache", desc:"Staging area" },
            { label:"Persistence Cron", cmd:"crontab -l", desc:"Persistence mechanism" },
            { label:"Malware Hash", cmd:"sha256sum /tmp/.cache/syslogd-helper", desc:"SHA256 for TI sharing" },
          ].map((item, i) => {
            const done = collected.has(item.cmd);
            return (
              <div key={i} style={{ display:"flex", gap:10, padding:"7px 0", borderBottom:"1px solid var(--line)", alignItems:"center" }}>
                <span style={{ color: done ? "var(--green)" : "var(--t4)", fontSize:14, flexShrink:0 }}>{done ? "✓" : "○"}</span>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:11, color: done ? "var(--green2)" : "var(--t2)", fontWeight:600 }}>{item.label}</div>
                  <code style={{ fontSize:9, color:"var(--t3)", fontFamily:"var(--mono)" }}>{item.cmd}</code>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
