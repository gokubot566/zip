import { useState, useEffect } from "react";
import { WORKSTATION } from "../data/lab.js";

export default function SOCHeader({ xp, rank, completionPct, reqCollected, reqTotal, onByteToggle, byteOpen, containmentDone, unackAlerts }) {
  const [clock, setClock] = useState(new Date().toUTCString().slice(0, 25));
  useEffect(() => {
    const iv = setInterval(() => setClock(new Date().toUTCString().slice(0, 25)), 1000);
    return () => clearInterval(iv);
  }, []);

  return (
    <header style={{
      height: 50, flexShrink: 0,
      background: "var(--s1)", borderBottom: "1px solid var(--line)",
      display: "flex", alignItems: "center", padding: "0 16px", gap: 12,
      position: "relative", zIndex: 100,
    }}>
      {/* Logo */}
      <div style={{ display:"flex", alignItems:"center", gap:8, marginRight:6 }}>
        <div style={{
          width:28, height:28, borderRadius:6,
          background:"var(--green-dim)", border:"1px solid rgba(57,255,110,.3)",
          display:"flex", alignItems:"center", justifyContent:"center", fontSize:13,
          boxShadow:"0 0 12px rgba(57,255,110,.15)",
        }}>🔬</div>
        <div>
          <div style={{ fontSize:13, fontWeight:800, color:"var(--green)", letterSpacing:".04em", fontFamily:"var(--mono)", lineHeight:1, animation:"glow 3s ease-in-out infinite" }}>ForensicOS</div>
          <div style={{ fontSize:8, color:"var(--t4)", letterSpacing:".1em", textTransform:"uppercase", fontFamily:"var(--mono)" }}>DFIR Lab v2.0</div>
        </div>
      </div>

      <div style={{ width:1, height:24, background:"var(--line)" }} />

      {/* Incident */}
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:11, fontWeight:600, color:"var(--t1)" }}>
          Evidence Preservation Lab — C2 Beacon Investigation
        </div>
        <div style={{ fontSize:9, color:"var(--t3)", fontFamily:"var(--mono)" }}>
          {WORKSTATION.incident} · {WORKSTATION.hostname} ({WORKSTATION.ip}) · {WORKSTATION.user}
        </div>
      </div>

      {/* Status */}
      <div style={{
        padding:"3px 10px", borderRadius:20, fontSize:9, fontWeight:700,
        fontFamily:"var(--mono)", letterSpacing:".06em",
        background: containmentDone ? "rgba(57,255,110,.1)" : "rgba(255,51,85,.1)",
        border: `1px solid ${containmentDone ? "rgba(57,255,110,.3)" : "rgba(255,51,85,.3)"}`,
        color: containmentDone ? "var(--green)" : "var(--red)",
        animation: !containmentDone ? "pulse 2s infinite" : "none",
      }}>
        {containmentDone ? "✓ CONTAINED" : "● LIVE COMPROMISE"}
      </div>

      {/* Progress */}
      <div style={{ display:"flex", alignItems:"center", gap:8, background:"var(--s2)", border:"1px solid var(--line)", borderRadius:20, padding:"5px 14px" }}>
        <div style={{ fontSize:9, color:"var(--t3)", fontFamily:"var(--mono)" }}>Evidence</div>
        <div style={{ width:70, height:3, background:"var(--line)", borderRadius:2, overflow:"hidden" }}>
          <div style={{ height:"100%", width:`${completionPct}%`, background:"linear-gradient(90deg,var(--green3),var(--green))", transition:"width .5s" }} />
        </div>
        <div style={{ fontSize:9, color:"var(--green)", fontFamily:"var(--mono)", fontWeight:700 }}>{reqCollected}/{reqTotal}</div>
      </div>

      {/* Alerts */}
      {unackAlerts > 0 && (
        <div style={{ display:"flex", alignItems:"center", gap:5, fontSize:9, fontFamily:"var(--mono)", color:"var(--amber)", animation:"pulse 1.5s infinite" }}>
          🔔 {unackAlerts} OPEN
        </div>
      )}

      {/* Clock */}
      <div style={{ fontSize:10, color:"var(--t3)", fontFamily:"var(--mono)", flexShrink:0 }}>{clock}</div>

      {/* XP + Rank */}
      <div style={{ display:"flex", alignItems:"center", gap:8, background:"var(--s2)", border:"1px solid var(--line)", borderRadius:6, padding:"5px 12px" }}>
        <div>
          <div style={{ fontSize:9, fontWeight:700, color:rank.color, fontFamily:"var(--mono)", lineHeight:1 }}>{rank.name}</div>
          <div style={{ fontSize:9, color:"var(--green)", fontFamily:"var(--mono)", marginTop:1 }}>{xp.toLocaleString()} XP</div>
        </div>
        <div>
          <div style={{ fontSize:8, color:"var(--t4)", fontFamily:"var(--mono)", marginBottom:2 }}>
            {rank.next ? `→ ${rank.next.name}` : "MAX"}
          </div>
          <div className="xp-bar" style={{ width:60 }}>
            <div className="xp-fill" style={{ width:`${rank.prog}%` }} />
          </div>
        </div>
      </div>

      {/* Byte toggle */}
      <button onClick={onByteToggle} style={{
        background: byteOpen ? "var(--green-mid)" : "var(--green-dim)",
        border:`1px solid ${byteOpen ? "rgba(57,255,110,.5)" : "rgba(57,255,110,.2)"}`,
        borderRadius:6, padding:"5px 12px", color:"var(--green)", fontSize:11, fontWeight:600,
        display:"flex", alignItems:"center", gap:6,
      }}>
        🤖 Byte {byteOpen ? "▸" : "▹"}
      </button>
    </header>
  );
}
