export { NetworkMonitor as default } from "./Panels.jsx";
