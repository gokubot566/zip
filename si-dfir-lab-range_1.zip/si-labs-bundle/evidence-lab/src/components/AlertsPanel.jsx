export { AlertsPanel as default } from "./Panels.jsx";
