import { useState, useEffect, useRef, useCallback } from "react";
import ByteAssistant from "./components/ByteAssistant.jsx";

const GLOBAL_CSS = `
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg:#0d1117; --surface:#161b22; --surface2:#1c2333; --surface3:#21262d;
    --border:#30363d; --border2:#3d444d;
    --t1:#e6edf3; --t2:#9198a1; --t3:#656d76; --t4:#3d444d;
    --blue:#388bfd; --blue-dim:rgba(56,139,253,.12);
    --green:#3fb950; --green-dim:rgba(63,185,80,.12);
    --red:#f85149; --red-dim:rgba(248,81,73,.12);
    --orange:#d29922; --orange-dim:rgba(210,153,34,.12);
    --purple:#8957e5; --cyan:#39d353;
    --mono:'IBM Plex Mono',monospace; --sans:'IBM Plex Sans',sans-serif;
  }
  html,body,#root{height:100%;font-family:var(--sans);background:var(--bg);color:var(--t1);overflow:hidden;}
  ::-webkit-scrollbar{width:5px;height:5px;}
  ::-webkit-scrollbar-track{background:transparent;}
  ::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px;}
  button{cursor:pointer;font-family:var(--sans);}
  code,pre{font-family:var(--mono);}
  .term-line{display:flex;line-height:1.6;}
  .term-prompt{color:var(--green);flex-shrink:0;margin-right:.5ch;}
  .term-output{color:#b8c4cc;padding:1px 0;white-space:pre-wrap;word-break:break-all;}
  .term-err{color:var(--red);}
  .term-warn{color:var(--orange);}
  .term-sus{background:rgba(248,81,73,.08);color:#ff7070;border-left:2px solid var(--red);padding-left:6px;margin:1px 0;}
  .term-ok{color:var(--green);}
  .term-cursor{display:inline-block;width:9px;height:14px;background:var(--green);animation:blink 1.2s step-end infinite;vertical-align:middle;}
  .tab-bar{display:flex;border-bottom:1px solid var(--border);background:var(--surface);}
  .tab-btn{padding:8px 16px;font-size:12px;font-weight:500;border:none;background:transparent;color:var(--t3);border-bottom:2px solid transparent;transition:all .15s;cursor:pointer;font-family:var(--sans);}
  .tab-btn:hover{color:var(--t2);background:var(--surface3);}
  .tab-btn.active{color:var(--t1);border-bottom-color:var(--blue);}
  .badge{font-size:10px;font-weight:600;padding:1px 7px;border-radius:10px;font-family:var(--mono);}
  .badge-red{background:var(--red-dim);color:var(--red);border:1px solid rgba(248,81,73,.3);}
  .badge-orange{background:var(--orange-dim);color:var(--orange);border:1px solid rgba(210,153,34,.3);}
  .badge-green{background:var(--green-dim);color:var(--green);border:1px solid rgba(63,185,80,.3);}
  .badge-blue{background:var(--blue-dim);color:var(--blue);border:1px solid rgba(56,139,253,.3);}
  .badge-gray{background:var(--surface3);color:var(--t2);border:1px solid var(--border);}
  .btn{padding:6px 14px;border-radius:6px;font-size:12px;font-weight:600;border:none;transition:all .15s;font-family:var(--sans);}
  .btn-primary{background:var(--blue);color:#fff;}
  .btn-primary:hover{background:#58a6ff;}
  .btn-green{background:var(--green);color:#000;}
  .btn-green:hover{background:#4fc461;}
  .btn-ghost{background:var(--surface3);color:var(--t2);border:1px solid var(--border);}
  .btn-ghost:hover{background:var(--surface2);color:var(--t1);}
  .btn:disabled{opacity:.4;cursor:not-allowed;}
  .alert-banner{background:rgba(248,81,73,.08);border:1px solid rgba(248,81,73,.22);border-radius:6px;padding:8px 14px;font-size:12px;color:var(--red);display:flex;align-items:center;gap:8px;}
  .card{background:var(--surface);border:1px solid var(--border);border-radius:8px;}
  .proc-threat{background:rgba(248,81,73,.05);}
  .proc-warn{background:rgba(210,153,34,.05);}
  @keyframes blink{50%{opacity:0;}}
  @keyframes fadeIn{from{opacity:0;transform:translateY(4px);}to{opacity:1;transform:translateY(0);}}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
  .fade-in{animation:fadeIn .2s ease-out both;}
`;

const HOSTNAME="ubuntu-ws-047", USER="j.hartley", C2_IP="185.220.101.93", MAL_PID="1887", MAL_PATH="/tmp/.cache/syslogd-helper";

const COMMANDS={
  "date":{output:`Tue 14 Nov 2026 02:34:18 UTC`,volatile:true,sus:[],hint:"Always record the exact system time first — this anchors every evidence item in the chain of custody."},
  "hostname":{output:`ubuntu-ws-047`,volatile:false,sus:[],hint:"Confirms host identity on the evidence record."},
  "uname -a":{output:`Linux ubuntu-ws-047 5.15.0-89-generic #99-Ubuntu SMP Mon Oct 30 20:42:41 UTC 2023 x86_64 x86_64 x86_64 GNU/Linux`,volatile:false,sus:[],hint:"Kernel version and architecture — important for later exploitation analysis."},
  "ps aux":{
    output:`USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root           1  0.0  0.1 169012 13448 ?        Ss   01:12   0:01 /sbin/init
root         591  0.0  0.1  45736  9112 ?        Ss   01:12   0:00 /usr/lib/systemd/systemd-udevd
syslog       842  0.0  0.0 224936  5260 ?        Ssl  01:12   0:00 /usr/sbin/rsyslogd -n -iNONE
root         901  0.0  0.1 102360 10432 ?        Ss   01:12   0:00 /usr/sbin/sshd -D
root        1012  0.0  0.0  55996  4356 ?        Ss   01:13   0:00 /usr/sbin/cron -f
j.hartley   1441  0.0  0.0  13208  3456 pts/0    Ss   02:01   0:00 -bash
j.hartley   1556  0.0  0.0  16452  2344 ?        Ss   02:01   0:00 tmux: server
j.hartley   1557  0.0  0.0  13208  3212 pts/1    Ss   02:01   0:00 -bash (tmux)
j.hartley   1887  3.7  1.4 128456 58344 ?        Sl   02:03   4:33 /tmp/.cache/syslogd-helper
j.hartley   1889  0.0  0.0   4292  1024 ?        S    02:03   0:00 /tmp/.cache/syslogd-helper (worker)
root        1902  0.0  0.1  88956 10344 ?        S    02:03   0:00 /usr/sbin/sshd: j.hartley@notty
root        2001  0.0  0.0  13208  2100 pts/2    S+   02:34   0:00 ps aux`,
    volatile:true,
    sus:["j.hartley   1887  3.7  1.4 128456 58344 ?        Sl   02:03   4:33 /tmp/.cache/syslogd-helper","j.hartley   1889  0.0  0.0   4292  1024 ?        S    02:03   0:00 /tmp/.cache/syslogd-helper (worker)","j.hartley   1556  0.0  0.0  16452  2344 ?        Ss   02:01   0:00 tmux: server"],
    hint:"PID 1887 in /tmp/.cache is highly suspicious — /tmp is world-writable, not a valid location for system daemons. The tmux server at PID 1556 may be an attacker maintaining a persistent interactive session."
  },
  "ss -tulpn":{
    output:`Netid  State   Recv-Q  Send-Q  Local Address:Port   Peer Address:Port  Process
tcp    LISTEN  0       128     0.0.0.0:22          0.0.0.0:*          users:(("sshd",pid=901,fd=3))
tcp    LISTEN  0       5       127.0.0.1:631        0.0.0.0:*
tcp    ESTAB   0       0       10.10.4.47:42317    185.220.101.93:4444  users:(("syslogd-helper",pid=1887,fd=5))
tcp    ESTAB   0       18432   10.10.4.47:55891    185.220.101.93:443   users:(("syslogd-helper",pid=1887,fd=7))
tcp    ESTAB   0       0       10.10.4.47:22       10.10.4.1:54312      users:(("sshd",pid=1902,fd=4))`,
    volatile:true,
    sus:["tcp    ESTAB   0       0       10.10.4.47:42317    185.220.101.93:4444  users:((\"syslogd-helper\",pid=1887,fd=5))","tcp    ESTAB   0       18432   10.10.4.47:55891    185.220.101.93:443   users:((\"syslogd-helper\",pid=1887,fd=7))"],
    hint:"Two ESTABLISHED connections to 185.220.101.93 — port 4444 is a classic reverse shell port, port 443 is used to disguise exfiltration as HTTPS. The 18432 bytes in Send-Q means data is being sent right now."
  },
  "netstat -antp":{
    output:`Active Internet connections (servers and established)
Proto Recv-Q Send-Q Local Address           Foreign Address         State       PID/Program name
tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN      901/sshd
tcp        0      0 127.0.0.1:631           0.0.0.0:*               LISTEN      -
tcp        0      0 10.10.4.47:42317        185.220.101.93:4444     ESTABLISHED 1887/syslogd-helper
tcp        0  18432 10.10.4.47:55891        185.220.101.93:443      ESTABLISHED 1887/syslogd-helper
tcp        0      0 10.10.4.47:22           10.10.4.1:54312         ESTABLISHED 1902/sshd`,
    volatile:true,
    sus:["tcp        0      0 10.10.4.47:42317        185.220.101.93:4444     ESTABLISHED 1887/syslogd-helper","tcp        0  18432 10.10.4.47:55891        185.220.101.93:443      ESTABLISHED 1887/syslogd-helper"],
    hint:"Confirms the same C2 connections. Note the 18432 bytes in Send-Q for the :443 session — active data exfiltration in progress."
  },
  "who":{
    output:`j.hartley pts/0        2026-11-14 02:01 (10.10.4.1)
j.hartley pts/1        2026-11-14 02:01 (:tmux session)`,
    volatile:true,sus:["j.hartley pts/1        2026-11-14 02:01 (:tmux session)"],
    hint:"Two sessions — normal TTY plus a tmux session started at the same time as the malware. The tmux session may be an attacker's persistent shell."
  },
  "w":{
    output:` 02:34:18 up  1:22,  2 users,  load average: 0.87, 0.91, 0.84
USER     TTY      FROM             LOGIN@   IDLE JCPU   PCPU WHAT
j.hartley pts/0    10.10.4.1        02:01    0.00s  0.12s  0.01s w
j.hartley pts/1    :tmux            02:01   33:17   0.04s  0.04s -bash`,
    volatile:true,sus:["j.hartley pts/1    :tmux            02:01   33:17   0.04s  0.04s -bash"],
    hint:"Load average 0.87 is elevated for a workstation — consistent with the malware's CPU usage. tmux session idle 33 minutes but still active."
  },
  "arp -a":{
    output:`? (10.10.4.1) at 00:1a:2b:3c:4d:5e [ether] on ens3
? (10.10.4.254) at 00:50:56:9f:1a:2b [ether] on ens3
? (10.10.4.10) at 00:0c:29:de:ad:01 [ether] on ens3
? (10.10.4.20) at 00:0c:29:de:ad:02 [ether] on ens3`,
    volatile:true,sus:[],hint:"ARP cache shows recently contacted LAN hosts — 10.10.4.10 and 10.10.4.20 may have been probed during lateral movement reconnaissance."
  },
  "ip route":{
    output:`default via 10.10.4.254 dev ens3 proto dhcp src 10.10.4.47 metric 100
10.10.4.0/24 dev ens3 proto kernel scope link src 10.10.4.47
169.254.0.0/16 dev ens3 scope link metric 1000`,
    volatile:true,sus:[],hint:"Standard routing table — no suspicious static routes injected by the malware. All traffic uses the default gateway."
  },
  "last":{
    output:`j.hartley pts/0        10.10.4.1        Tue Nov 14 02:01   still logged in
j.hartley pts/2        10.10.4.1        Mon Nov 13 17:44 - 18:22  (00:38)
j.hartley pts/0        10.10.4.1        Mon Nov 13 08:12 - 17:43  (09:31)
reboot   system boot  5.15.0-89-generic Tue Nov 14 01:12   still running
wtmp begins Mon Nov  6 08:00:18 2026`,
    volatile:false,sus:[],hint:"Login history — j.hartley logged in at 02:01 after the system rebooted at 01:12. The reboot itself is worth investigating."
  },
  "lsof -i":{
    output:`COMMAND          PID      USER   FD   TYPE DEVICE SIZE/OFF NODE NAME
sshd            1902  j.hartley    4u  IPv4  31227      0t0  TCP ubuntu-ws-047:ssh->10.10.4.1:54312 (ESTABLISHED)
syslogd-h       1887  j.hartley    5u  IPv4  32441      0t0  TCP ubuntu-ws-047:42317->185.220.101.93:4444 (ESTABLISHED)
syslogd-h       1887  j.hartley    7u  IPv4  32447      0t0  TCP ubuntu-ws-047:55891->185.220.101.93:443 (ESTABLISHED)`,
    volatile:true,
    sus:["syslogd-h       1887  j.hartley    5u  IPv4  32441      0t0  TCP ubuntu-ws-047:42317->185.220.101.93:4444 (ESTABLISHED)","syslogd-h       1887  j.hartley    7u  IPv4  32447      0t0  TCP ubuntu-ws-047:55891->185.220.101.93:443 (ESTABLISHED)"],
    hint:"Confirms syslogd-helper holds both C2 connections on file descriptors 5 and 7. These are the sockets you block during containment."
  },
  "ls -la /tmp/.cache":{
    output:`total 248
drwxr-xr-x 2 j.hartley j.hartley  4096 Nov 14 02:03 .
drwxrwxrwt 9 root      root       4096 Nov 14 02:03 ..
-rwxr-xr-x 1 j.hartley j.hartley 237568 Nov 14 02:03 syslogd-helper`,
    volatile:false,sus:["-rwxr-xr-x 1 j.hartley j.hartley 237568 Nov 14 02:03 syslogd-helper"],
    hint:"Malware binary is 237KB in /tmp/.cache — hidden directory in /tmp. Executable in /tmp is always suspicious. Note the timestamp 02:03 matches the SIEM alert."
  },
  "crontab -l":{
    output:`# Cron version 3.0pl1
*/5 * * * * /tmp/.cache/syslogd-helper --silent --check >/dev/null 2>&1`,
    volatile:false,sus:["*/5 * * * * /tmp/.cache/syslogd-helper --silent --check >/dev/null 2>&1"],
    hint:"Persistence confirmed — crontab re-launches syslogd-helper every 5 minutes. If you kill the process without removing this, it restarts automatically."
  },
  "cat /etc/cron.hourly/sys-update":{
    output:`#!/bin/bash
# System maintenance script - do not remove
/tmp/.cache/syslogd-helper --daemon 2>/dev/null &`,
    volatile:false,sus:["# System maintenance script - do not remove","/tmp/.cache/syslogd-helper --daemon 2>/dev/null &"],
    hint:"Second persistence mechanism — a system-wide cron script. This one could run with elevated privileges depending on how cron is configured."
  },
  "sha256sum /tmp/.cache/syslogd-helper":{
    output:`3a7f9c2e4b8d1f6a5e8c9b2d4f1e7a3c6b9e2d5f8a1c4e7b2d5f8a1c4e7b2d5  /tmp/.cache/syslogd-helper`,
    volatile:false,sus:[],hint:"SHA-256 hash — submit to VirusTotal or your threat intel platform. This hash uniquely identifies this malware binary and may link it to known campaigns."
  },
  "id":{
    output:`uid=1001(j.hartley) gid=1001(j.hartley) groups=1001(j.hartley),4(adm),24(cdrom),27(sudo),30(dip),46(plugdev)`,
    volatile:false,sus:["groups=1001(j.hartley),4(adm),24(cdrom),27(sudo)"],
    hint:"j.hartley is in the sudo group — malware running as this user can potentially escalate to root."
  },
  "uptime":{
    output:` 02:34:18 up  1:22,  2 users,  load average: 0.87, 0.91, 0.84`,
    volatile:true,sus:[],hint:"System up 1h22m since 01:12 reboot. Load 0.87 is elevated — consistent with malware CPU usage."
  },
  "help":{
    output:`ForensicOS DFIR Terminal — Available Commands
──────────────────────────────────────────────
Evidence Collection:
  date                          System timestamp (start here)
  hostname / uname -a           System identity
  ps aux                        All running processes
  ss -tulpn                     Active network connections
  netstat -antp                 Network connections (alt)
  who / w                       Logged-in users & activity
  arp -a                        ARP cache (Layer 2 hosts)
  ip route                      Routing table
  last                          Login history
  lsof -i                       Open network file descriptors
  id / uptime                   User privs & system load

Investigation:
  ls -la /tmp/.cache            Malware directory
  crontab -l                    User persistence (cron)
  cat /etc/cron.hourly/sys-update  System persistence
  sha256sum /tmp/.cache/syslogd-helper  Hash malware binary

Evidence Management:
  save <filename>               Save last output + auto-hash
  contain                       Isolate host (evidence required first)
  clear                         Clear terminal`,
    volatile:false,sus:[],hint:"Start with 'date' to anchor your timeline, then collect volatile data (processes, network, users) before static data."
  },
  "clear":{output:null,volatile:false,sus:[],hint:""},
};

const REQUIRED_CMDS=["date","ps aux","ss -tulpn","who","arp -a","ip route","last","lsof -i","ls -la /tmp/.cache","crontab -l","sha256sum /tmp/.cache/syslogd-helper"];

const SIEM_ALERTS=[
  {id:"ALT-001",sev:"CRITICAL",time:"02:03:17",host:"ubuntu-ws-047",title:"C2 Outbound Beacon — Port 4444",tech:"T1071",detail:"syslogd-helper (PID 1887) established TCP ESTABLISHED to 185.220.101.93:4444. Classic reverse-shell port. Process path: /tmp/.cache/syslogd-helper.",acked:false},
  {id:"ALT-002",sev:"CRITICAL",time:"02:03:19",host:"ubuntu-ws-047",title:"Data Exfiltration Suspected — Port 443",tech:"T1041",detail:"Sustained 18KB/s upload from PID 1887 to 185.220.101.93:443 (HTTPS). Anomalous volume for workstation. TLS fingerprint does not match known browser patterns.",acked:false},
  {id:"ALT-003",sev:"HIGH",time:"02:03:21",host:"ubuntu-ws-047",title:"Executable Created in /tmp",tech:"T1059.004",detail:"New ELF executable: /tmp/.cache/syslogd-helper (237KB). Execution from /tmp is a strong malware indicator. File created at 02:03:21 UTC, executed immediately.",acked:false},
  {id:"ALT-004",sev:"HIGH",time:"02:03:25",host:"ubuntu-ws-047",title:"Persistence — Crontab Modified",tech:"T1053.003",detail:"j.hartley crontab modified at 02:03:23 UTC. New entry schedules syslogd-helper every 5 minutes. Classic persistence mechanism.",acked:false},
  {id:"ALT-005",sev:"HIGH",time:"02:03:28",host:"ubuntu-ws-047",title:"Unauthorised tmux Session Active",tech:"T1059.004",detail:"tmux server spawned by j.hartley at 02:01 UTC — 2 minutes before malware execution. Attacker maintaining persistent interactive shell.",acked:false},
  {id:"ALT-006",sev:"MEDIUM",time:"02:01:44",host:"ubuntu-ws-047",title:"Off-Hours SSH Login",tech:"T1078",detail:"j.hartley authenticated via SSH from 10.10.4.1 at 02:01 UTC. Outside normal hours (08:00-18:00 local). This login directly preceded malware deployment.",acked:false},
];

const PROC_LIVE=[
  {pid:1,user:"root",cpu:"0.0",mem:"0.1",cmd:"/sbin/init",threat:false},
  {pid:591,user:"root",cpu:"0.0",mem:"0.1",cmd:"/usr/lib/systemd/systemd-udevd",threat:false},
  {pid:842,user:"syslog",cpu:"0.0",mem:"0.0",cmd:"/usr/sbin/rsyslogd -n",threat:false},
  {pid:901,user:"root",cpu:"0.0",mem:"0.1",cmd:"/usr/sbin/sshd -D",threat:false},
  {pid:1012,user:"root",cpu:"0.0",mem:"0.0",cmd:"/usr/sbin/cron -f",threat:false},
  {pid:1441,user:"j.hartley",cpu:"0.0",mem:"0.0",cmd:"-bash",threat:false},
  {pid:1556,user:"j.hartley",cpu:"0.0",mem:"0.0",cmd:"tmux: server",threat:"warn"},
  {pid:1557,user:"j.hartley",cpu:"0.0",mem:"0.0",cmd:"-bash (tmux)",threat:"warn"},
  {pid:1887,user:"j.hartley",cpu:"3.7",mem:"1.4",cmd:"/tmp/.cache/syslogd-helper",threat:true},
  {pid:1889,user:"j.hartley",cpu:"0.0",mem:"0.0",cmd:"/tmp/.cache/syslogd-helper (worker)",threat:true},
  {pid:1902,user:"j.hartley",cpu:"0.0",mem:"0.1",cmd:"/usr/sbin/sshd: j.hartley@notty",threat:false},
];

const NET_LIVE=[
  {proto:"TCP",local:"10.10.4.47:42317",remote:"185.220.101.93:4444",state:"ESTABLISHED",pid:"1887",prog:"syslogd-helper",threat:true},
  {proto:"TCP",local:"10.10.4.47:55891",remote:"185.220.101.93:443", state:"ESTABLISHED",pid:"1887",prog:"syslogd-helper",threat:true},
  {proto:"TCP",local:"10.10.4.47:22",   remote:"10.10.4.1:54312",    state:"ESTABLISHED",pid:"1902",prog:"sshd",threat:false},
  {proto:"TCP",local:"0.0.0.0:22",      remote:"*:*",                state:"LISTEN",     pid:"901", prog:"sshd",threat:false},
];

function sha256sim(s){let h=0;for(let i=0;i<s.length;i++){h=(Math.imul(31,h)+s.charCodeAt(i))|0;}const b=Math.abs(h).toString(16).padStart(8,'0');return(b+'c4e7b2d5f8a1c4e7b2d5f8a1c4e7b2d5f8a1c4e7b2d5f8a1c4e7b2d5f8a1c4').substring(0,64);}
function nowUTC(){return new Date().toISOString().replace('T',' ').substring(0,19)+' UTC';}

// ─── TopNav ───────────────────────────────────────────────────────────────────
function TopNav({tab,setTab,alertCount,evidenceCount,xp,rank,contained}){
  const[clock,setClock]=useState(nowUTC());
  useEffect(()=>{const t=setInterval(()=>setClock(nowUTC()),1000);return()=>clearInterval(t);},[]);
  const tabs=[
    {id:"alerts",label:"Security Alerts",badge:alertCount},
    {id:"terminal",label:"Terminal"},
    {id:"processes",label:"Processes"},
    {id:"network",label:"Network"},
    {id:"evidence",label:"Evidence Log",badge:evidenceCount},
  ];
  return(
    <div style={{background:"var(--surface)",borderBottom:"1px solid var(--border)",flexShrink:0}}>
      <div style={{display:"flex",alignItems:"center",gap:14,padding:"0 14px",height:44,borderBottom:"1px solid var(--border)"}}>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <div style={{width:9,height:9,borderRadius:"50%",background:contained?"var(--red)":"var(--green)",animation:"pulse 2s ease-in-out infinite"}}/>
          <span style={{fontFamily:"var(--mono)",fontSize:13,fontWeight:600}}>ForensicOS DFIR</span>
          <span style={{fontFamily:"var(--mono)",fontSize:10,color:"var(--t3)"}}>v2.1</span>
        </div>
        <span className="badge badge-red">INC-2026-C2-0312</span>
        {contained&&<span className="badge badge-orange">HOST ISOLATED</span>}
        <div style={{flex:1}}/>
        <div style={{fontFamily:"var(--mono)",fontSize:11,color:"var(--t3)"}}>
          <span style={{color:"var(--t2)"}}>{USER}@{HOSTNAME}</span>
          <span style={{margin:"0 8px",color:"var(--border2)"}}>|</span>
          <span style={{color:"var(--orange)"}}>{clock}</span>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:6,padding:"3px 10px",background:"var(--surface2)",borderRadius:6,border:"1px solid var(--border)"}}>
          <span style={{fontSize:10,color:"var(--t3)",fontFamily:"var(--mono)"}}>ANALYST</span>
          <span style={{fontSize:12,fontWeight:600}}>{rank}</span>
          <span style={{fontSize:11,color:"var(--blue)",fontFamily:"var(--mono)"}}>+{xp}XP</span>
        </div>
      </div>
      <div style={{height:3,background:"var(--surface3)"}}>
        <div style={{height:"100%",width:`${Math.min(100,(evidenceCount/11)*100)}%`,background:"linear-gradient(90deg,var(--blue),var(--green))",transition:"width .6s ease-out"}}/>
      </div>
      <div className="tab-bar" style={{paddingLeft:6}}>
        {tabs.map(t=>(
          <button key={t.id} className={`tab-btn ${tab===t.id?"active":""}`} onClick={()=>setTab(t.id)}>
            {t.label}
            {t.badge>0&&<span style={{marginLeft:5,background:t.id==="alerts"?"var(--red)":"var(--blue)",color:"#fff",borderRadius:10,padding:"0 5px",fontSize:9,fontWeight:700}}>{t.badge}</span>}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Terminal ─────────────────────────────────────────────────────────────────
function Terminal({onEvidenceSaved,evidence,setContained,onXP}){
  const[hist,setHist]=useState([]);
  const[inp,setInp]=useState("");
  const[lastOut,setLastOut]=useState(null);
  const[lastCmd,setLastCmd]=useState("");
  const[collected,setCollected]=useState(new Set());
  const[ranCmds,setRanCmds]=useState(new Set());
  const[cmdHist,setCmdHist]=useState([]);
  const[histIdx,setHistIdx]=useState(-1);
  const botRef=useRef(null);const inpRef=useRef(null);
  useEffect(()=>{botRef.current?.scrollIntoView({behavior:"smooth"});},[hist]);
  useEffect(()=>{inpRef.current?.focus();},[]);
  const add=l=>setHist(h=>[...h,l]);

  const run=raw=>{
    const cmd=raw.trim();if(!cmd)return;
    setCmdHist(h=>[cmd,...h.slice(0,49)]);setHistIdx(-1);
    if(cmd==="clear"){setHist([]);setLastOut(null);return;}

    if(cmd.startsWith("save ")){
      const fname=cmd.slice(5).trim();
      if(!lastOut||!lastCmd){add({t:"err",v:"No output to save. Run a command first."});return;}
      const hash=sha256sim(lastOut+fname+Date.now());
      const entry={id:Date.now(),timestamp:nowUTC(),cmd:lastCmd,filename:fname,hash,output:lastOut,size:`${lastOut.length} bytes`};
      onEvidenceSaved(entry);
      if(!collected.has(lastCmd)){setCollected(s=>new Set([...s,lastCmd]));onXP(50);}
      add({t:"prompt",v:`save ${fname}`});
      add({t:"ok",v:`[+] Saved: ${fname}`});
      add({t:"ok",v:`[+] SHA-256: ${hash.substring(0,32)}...`});
      add({t:"ok",v:`[+] Chain of custody updated.`});
      setLastOut(null);setLastCmd("");return;
    }

    if(cmd==="contain"){
      const evCmds=evidence.map(e=>e.cmd);
      const isSaved=r=>collected.has(r)||evCmds.includes(r);
      const missing=REQUIRED_CMDS.filter(r=>!isSaved(r));
      add({t:"prompt",v:cmd});
      if(missing.length>0){
        // Separate "not yet run" from "run but not saved" so the student knows the exact next step
        const notRun=missing.filter(r=>!ranCmds.has(r));
        const runNotSaved=missing.filter(r=>ranCmds.has(r));
        add({t:"err",v:`[!] CONTAINMENT BLOCKED — ${missing.length} of ${REQUIRED_CMDS.length} evidence items not yet preserved.`});
        add({t:"warn",v:"    Containment destroys live evidence, so every volatile item must be SAVED first."});
        if(runNotSaved.length>0){
          add({t:"warn",v:"  These were run but NOT saved — run 'save <filename>' right after each:"});
          runNotSaved.slice(0,6).forEach(m=>add({t:"warn",v:`    • ${m}   →  ${m} ; save ${m.split(" ")[0]}.txt`}));
        }
        if(notRun.length>0){
          add({t:"warn",v:"  Not yet collected — run the command, then save its output:"});
          notRun.slice(0,8).forEach(m=>add({t:"warn",v:`    • ${m}`}));
        }
        add({t:"warn",v:"  Tip: run 'evidence' to see what you've already saved."});
        return;
      }
      add({t:"ok",v:"[+] Evidence collection verified — executing containment..."});
      setTimeout(()=>add({t:"ok",v:"[+] Blocking outbound to 185.220.101.93..."}),600);
      setTimeout(()=>add({t:"ok",v:"[+] Terminating PID 1887, 1889..."}),1200);
      setTimeout(()=>{add({t:"ok",v:"[+] Removing crontab persistence..."});add({t:"ok",v:"[+] Host isolated. INC-2026-C2-0312: CONTAINED"});setContained(true);onXP(200);},2000);
      return;
    }

    if(cmd==="evidence"||cmd==="evidence list"){
      add({t:"prompt",v:cmd});
      const have=new Set([...collected, ...evidence.map(e=>e.cmd)]);
      add({t:"ok",v:`[+] Evidence preserved: ${have.size} / ${REQUIRED_CMDS.length} required items`});
      REQUIRED_CMDS.forEach(r=>add({t:have.has(r)?"ok":"warn",v:`    ${have.has(r)?"✓":"·"} ${r}`}));
      if(have.size>=REQUIRED_CMDS.length) add({t:"ok",v:"[+] All required evidence collected — you may now run 'contain'."});
      return;
    }

    const def=COMMANDS[cmd];
    add({t:"prompt",v:cmd});
    if(!def){add({t:"err",v:`bash: ${cmd.split(" ")[0]}: command not found`});setLastOut(null);setLastCmd("");return;}
    if(def.output===null)return;
    setLastOut(def.output);setLastCmd(cmd);
    setRanCmds(s=>new Set([...s,cmd]));
    def.output.split("\n").forEach(line=>{
      const isSus=def.sus.some(s=>line.includes(s.substring(0,35)));
      add({t:isSus?"sus":"output",v:line});
    });
    if(def.volatile)add({t:"warn",v:"[!] VOLATILE — Save immediately: save <filename>"});
    if(def.sus.length>0)add({t:"warn",v:`[!] ${def.sus.length} suspicious indicator(s) found`});
  };

  const onKey=e=>{
    if(e.key==="Enter"){run(inp);setInp("");}
    else if(e.key==="ArrowUp"){e.preventDefault();const ni=Math.min(histIdx+1,cmdHist.length-1);setHistIdx(ni);setInp(cmdHist[ni]||"");}
    else if(e.key==="ArrowDown"){e.preventDefault();const ni=Math.max(histIdx-1,-1);setHistIdx(ni);setInp(ni===-1?"":cmdHist[ni]||"");}
  };

  const QUICK=["date","ps aux","ss -tulpn","who","arp -a","ip route","lsof -i","sha256sum /tmp/.cache/syslogd-helper"];
  return(
    <div style={{display:"flex",flexDirection:"column",height:"100%",overflow:"hidden"}}>
      <div style={{padding:"5px 10px",background:"var(--surface2)",borderBottom:"1px solid var(--border)",display:"flex",gap:5,flexWrap:"wrap",flexShrink:0}}>
        <span style={{fontSize:10,color:"var(--t3)",alignSelf:"center",fontFamily:"var(--mono)",marginRight:4}}>Quick:</span>
        {QUICK.map(q=><button key={q} className="btn btn-ghost" style={{fontSize:10,padding:"2px 7px",fontFamily:"var(--mono)"}} onClick={()=>{setInp(q);inpRef.current?.focus();}}>{q}</button>)}
      </div>
      <div style={{flex:1,overflowY:"auto",padding:"12px 14px",fontFamily:"var(--mono)",fontSize:12,lineHeight:1.7,cursor:"text"}} onClick={()=>inpRef.current?.focus()}>
        <div style={{marginBottom:14,padding:"9px 12px",background:"var(--surface2)",border:"1px solid var(--border)",borderRadius:6}}>
          <div style={{color:"var(--green)",fontWeight:600,marginBottom:3}}>ForensicOS DFIR Terminal</div>
          <div style={{color:"var(--t3)",fontSize:11}}>Session: <span style={{color:"var(--t1)"}}>{USER}@{HOSTNAME}</span> · Incident: <span style={{color:"var(--red)"}}>INC-2026-C2-0312</span></div>
          <div style={{color:"var(--t3)",fontSize:11,marginTop:1}}>Type <span style={{color:"var(--cyan)"}}>help</span> for commands. Use <span style={{color:"var(--cyan)"}}>save &lt;filename&gt;</span> to preserve evidence.</div>
        </div>
        {hist.map((item,i)=>{
          if(item.t==="prompt")return<div key={i} className="term-line"><span className="term-prompt">{USER}@{HOSTNAME}</span><span style={{color:"var(--t3)",marginRight:".5ch"}}>:~$</span><span style={{color:"var(--t1)"}}>{item.v}</span></div>;
          if(item.t==="sus")return<div key={i} className="term-sus">{item.v}</div>;
          if(item.t==="err")return<div key={i} className="term-err">{item.v}</div>;
          if(item.t==="warn")return<div key={i} className="term-warn">{item.v}</div>;
          if(item.t==="ok")return<div key={i} className="term-ok">{item.v}</div>;
          return<div key={i} className="term-output">{item.v}</div>;
        })}
        <div className="term-line" style={{marginTop:4}}>
          <span className="term-prompt">{USER}@{HOSTNAME}</span>
          <span style={{color:"var(--t3)",marginRight:".5ch"}}>:~$</span>
          <input value={inp} onChange={e=>setInp(e.target.value)} onKeyDown={onKey} ref={inpRef}
            style={{flex:1,background:"transparent",border:"none",outline:"none",color:"var(--t1)",fontFamily:"var(--mono)",fontSize:12,caretColor:"var(--green)"}}
            spellCheck={false} autoComplete="off"/>
          <span className="term-cursor"/>
        </div>
        <div ref={botRef}/>
      </div>
    </div>
  );
}

// ─── Alerts ───────────────────────────────────────────────────────────────────
function AlertsPanel({alerts,onAck,onXP}){
  const[exp,setExp]=useState(null);
  const sc={CRITICAL:"var(--red)",HIGH:"var(--orange)",MEDIUM:"var(--blue)"};
  return(
    <div style={{padding:14,overflowY:"auto",height:"100%"}}>
      <div style={{marginBottom:12}}>
        <div style={{fontSize:14,fontWeight:700,marginBottom:3}}>Azure Sentinel — Alert Queue</div>
        <div style={{fontSize:12,color:"var(--t3)"}}>INC-2026-C2-0312 · ubuntu-ws-047 · {alerts.filter(a=>!a.acked).length} unacknowledged</div>
      </div>
      <div style={{display:"flex",gap:8,marginBottom:14}}>
        {["CRITICAL","HIGH","MEDIUM"].map(s=>(
          <div key={s} style={{flex:1,padding:"7px 10px",background:"var(--surface)",border:"1px solid var(--border)",borderRadius:6,textAlign:"center"}}>
            <div style={{fontSize:17,fontWeight:700,color:sc[s]}}>{alerts.filter(a=>a.sev===s).length}</div>
            <div style={{fontSize:10,color:"var(--t3)",marginTop:1}}>{s}</div>
          </div>
        ))}
      </div>
      {alerts.map(a=>(
        <div key={a.id} style={{marginBottom:8,background:"var(--surface)",border:`1px solid ${a.acked?"var(--border)":"rgba(248,81,73,.2)"}`,borderRadius:6,overflow:"hidden"}}>
          <div style={{padding:"9px 12px",cursor:"pointer",display:"flex",alignItems:"center",gap:8}} onClick={()=>setExp(exp===a.id?null:a.id)}>
            <span className={`badge badge-${a.sev==="CRITICAL"?"red":a.sev==="HIGH"?"orange":"blue"}`}>{a.sev}</span>
            <span style={{fontFamily:"var(--mono)",fontSize:10,color:"var(--t3)",flexShrink:0}}>{a.time}</span>
            <span style={{flex:1,fontSize:12,fontWeight:500,color:a.acked?"var(--t3)":"var(--t1)"}}>{a.title}</span>
            <span className="badge badge-gray">{a.tech}</span>
            {a.acked&&<span style={{fontSize:10,color:"var(--green)"}}>✓</span>}
          </div>
          {exp===a.id&&(
            <div style={{padding:"0 12px 10px",borderTop:"1px solid var(--border)",paddingTop:10}}>
              <div style={{fontSize:12,color:"var(--t2)",lineHeight:1.6,marginBottom:8}}>{a.detail}</div>
              <div style={{display:"flex",gap:8}}>
                <span style={{fontSize:10,color:"var(--t3)",fontFamily:"var(--mono)"}}>{a.id} · {a.host}</span>
                <div style={{flex:1}}/>
                {!a.acked&&<button className="btn btn-ghost" style={{fontSize:11,padding:"3px 10px"}} onClick={()=>{onAck(a.id);onXP(25);}}>Acknowledge (+25 XP)</button>}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// ─── Processes ────────────────────────────────────────────────────────────────
function ProcessMonitor(){
  const[tick,setTick]=useState(0);
  useEffect(()=>{const t=setInterval(()=>setTick(v=>v+1),2000);return()=>clearInterval(t);},[]);
  return(
    <div style={{padding:14,overflowY:"auto",height:"100%"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
        <div>
          <div style={{fontSize:14,fontWeight:700}}>Process Monitor</div>
          <div style={{fontSize:12,color:"var(--t3)",marginTop:2}}>Live · ubuntu-ws-047 · refreshes every 2s</div>
        </div>
        <div style={{display:"flex",gap:12}}>
          {[["2","THREAT","var(--red)"],["2","SUSPECT","var(--orange)"]].map(([n,l,c])=>(
            <div key={l} style={{textAlign:"center"}}>
              <div style={{fontSize:16,fontWeight:700,color:c}}>{n}</div>
              <div style={{fontSize:10,color:"var(--t3)"}}>{l}</div>
            </div>
          ))}
        </div>
      </div>
      <div className="alert-banner" style={{marginBottom:12}}>⚠ PID 1887 (syslogd-helper) actively communicating with C2 at {C2_IP}</div>
      <table style={{width:"100%",borderCollapse:"collapse",fontSize:11,fontFamily:"var(--mono)"}}>
        <thead>
          <tr style={{borderBottom:"1px solid var(--border)"}}>
            {["PID","USER","%CPU","%MEM","COMMAND","STATUS"].map(h=>(
              <th key={h} style={{padding:"5px 8px",textAlign:"left",color:"var(--t3)",fontWeight:600,fontSize:10}}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {PROC_LIVE.map(p=>{
            const cpu=p.threat?(parseFloat(p.cpu)+(Math.random()*.4-.2)).toFixed(1):p.cpu;
            return(
              <tr key={p.pid} className={p.threat?"proc-threat":p.threat==="warn"?"proc-warn":""} style={{borderBottom:"1px solid var(--border)"}}>
                <td style={{padding:"5px 8px",color:p.threat?"var(--red)":p.threat==="warn"?"var(--orange)":"var(--t2)"}}>{p.pid}</td>
                <td style={{padding:"5px 8px",color:"var(--t2)"}}>{p.user}</td>
                <td style={{padding:"5px 8px",color:parseFloat(cpu)>1?"var(--orange)":"var(--t3)"}}>{cpu}</td>
                <td style={{padding:"5px 8px",color:"var(--t3)"}}>{p.mem}</td>
                <td style={{padding:"5px 8px",color:p.threat?"var(--red)":p.threat==="warn"?"var(--orange)":"var(--t1)"}}>{p.cmd}</td>
                <td style={{padding:"5px 8px"}}>
                  {p.threat?<span className="badge badge-red">MALICIOUS</span>:p.threat==="warn"?<span className="badge badge-orange">SUSPECT</span>:<span style={{fontSize:10,color:"var(--t3)"}}>OK</span>}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ─── Network ─────────────────────────────────────────────────────────────────
function NetworkMonitor(){
  const[pkts,setPkts]=useState([]);
  useEffect(()=>{
    const t=setInterval(()=>{
      const isThreat=Math.random()>.3;
      const sz=isThreat?Math.floor(Math.random()*1400+400):Math.floor(Math.random()*200+30);
      setPkts(p=>[{id:Date.now(),time:new Date().toISOString().substr(11,12),src:isThreat?"10.10.4.47":`10.10.4.${Math.floor(Math.random()*10)+1}`,dst:isThreat?C2_IP:"8.8.8.8",port:isThreat?(Math.random()>.5?"4444":"443"):"53",proto:isThreat?"TCP":"UDP",sz,threat:isThreat},...p].slice(0,50));
    },700);
    return()=>clearInterval(t);
  },[]);
  const txKB=(pkts.filter(p=>p.threat).reduce((a,b)=>a+b.sz,0)/1024).toFixed(1);
  return(
    <div style={{padding:14,overflowY:"auto",height:"100%"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
        <div>
          <div style={{fontSize:14,fontWeight:700}}>Network Monitor</div>
          <div style={{fontSize:12,color:"var(--t3)",marginTop:2}}>Live packet stream · ubuntu-ws-047</div>
        </div>
        <div style={{display:"flex",gap:14}}>
          <div style={{textAlign:"center"}}><div style={{fontSize:16,fontWeight:700,color:"var(--red)",fontFamily:"var(--mono)"}}>{txKB}KB</div><div style={{fontSize:10,color:"var(--t3)"}}>C2 TX (session)</div></div>
          <div style={{textAlign:"center"}}><div style={{fontSize:16,fontWeight:700,color:"var(--orange)"}}>2</div><div style={{fontSize:10,color:"var(--t3)"}}>C2 Connections</div></div>
        </div>
      </div>
      <div style={{marginBottom:14}}>
        <div style={{fontSize:12,fontWeight:600,color:"var(--t2)",marginBottom:6}}>Active Connections</div>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:11,fontFamily:"var(--mono)"}}>
          <thead><tr style={{borderBottom:"1px solid var(--border)"}}>{["Proto","Local","Remote","State","PID/Prog"].map(h=><th key={h} style={{padding:"5px 8px",textAlign:"left",color:"var(--t3)",fontSize:10,fontWeight:600}}>{h}</th>)}</tr></thead>
          <tbody>
            {NET_LIVE.map((n,i)=>(
              <tr key={i} style={{borderBottom:"1px solid var(--border)",background:n.threat?"rgba(248,81,73,.05)":"transparent"}}>
                <td style={{padding:"5px 8px",color:"var(--t2)"}}>{n.proto}</td>
                <td style={{padding:"5px 8px",color:"var(--t2)"}}>{n.local}</td>
                <td style={{padding:"5px 8px",color:n.threat?"var(--red)":"var(--t2)"}}>{n.remote}</td>
                <td style={{padding:"5px 8px"}}><span className={`badge badge-${n.state==="ESTABLISHED"?"green":"gray"}`}>{n.state}</span></td>
                <td style={{padding:"5px 8px",color:n.threat?"var(--red)":"var(--t2)"}}>{n.pid}/{n.prog}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div>
        <div style={{fontSize:12,fontWeight:600,color:"var(--t2)",marginBottom:6}}>Packet Stream</div>
        <div style={{fontFamily:"var(--mono)",fontSize:10,maxHeight:260,overflowY:"auto"}}>
          {pkts.map(pkt=>(
            <div key={pkt.id} className="fade-in" style={{padding:"2px 6px",color:pkt.threat?"var(--red)":"var(--t3)",borderLeft:pkt.threat?"2px solid var(--red)":"2px solid transparent",marginBottom:1}}>
              <span style={{color:"var(--t4)",marginRight:8}}>{pkt.time}</span>
              <span style={{marginRight:6}}>{pkt.proto}</span>
              <span style={{color:"var(--t2)",marginRight:4}}>{pkt.src}</span>
              <span style={{color:"var(--t3)",marginRight:4}}>→</span>
              <span style={{color:pkt.threat?"var(--red)":"var(--t2)",marginRight:8}}>{pkt.dst}:{pkt.port}</span>
              <span style={{color:"var(--t4)"}}>{pkt.sz}B</span>
              {pkt.threat&&<span style={{marginLeft:8,color:"var(--red)",fontWeight:700}}>C2</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Evidence Log ─────────────────────────────────────────────────────────────
function EvidenceLog({evidence}){
  const[sel,setSel]=useState(null);
  return(
    <div style={{display:"flex",height:"100%",overflow:"hidden"}}>
      <div style={{width:300,flexShrink:0,borderRight:"1px solid var(--border)",overflowY:"auto",padding:12}}>
        <div style={{fontSize:14,fontWeight:700,marginBottom:3}}>Evidence Log</div>
        <div style={{fontSize:12,color:"var(--t3)",marginBottom:12}}>Chain of custody · INC-2026-C2-0312</div>
        {evidence.length===0&&<div style={{padding:20,textAlign:"center",color:"var(--t3)",fontSize:12}}>No evidence yet.<br/>Run commands + <code style={{color:"var(--cyan)"}}>save &lt;name&gt;</code></div>}
        {evidence.map((e,i)=>(
          <div key={e.id} style={{marginBottom:8,padding:"9px 10px",background:sel?.id===e.id?"var(--surface2)":"var(--surface)",border:"1px solid var(--border)",borderRadius:6,cursor:"pointer"}} onClick={()=>setSel(e)}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
              <span style={{fontSize:10,fontWeight:700,color:"var(--blue)",fontFamily:"var(--mono)"}}>EV-{String(i+1).padStart(3,"0")}</span>
              <span className="badge badge-green" style={{fontSize:9}}>✓ HASH OK</span>
            </div>
            <div style={{fontSize:11,fontWeight:600,fontFamily:"var(--mono)",marginBottom:2}}>{e.filename}</div>
            <div style={{fontSize:10,color:"var(--t3)"}}>{e.timestamp}</div>
            <div style={{fontSize:10,color:"var(--t3)",fontFamily:"var(--mono)"}}>{e.cmd}</div>
          </div>
        ))}
      </div>
      <div style={{flex:1,overflowY:"auto",padding:14}}>
        {!sel?<div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"100%",color:"var(--t3)",fontSize:12}}>Select evidence item to view</div>:(
          <div>
            <div style={{fontSize:15,fontWeight:700,marginBottom:3}}>{sel.filename}</div>
            <div style={{fontSize:12,color:"var(--t3)",marginBottom:14}}>Chain of custody record</div>
            {[["Timestamp",sel.timestamp],["Command",sel.cmd],["File Size",sel.size],["SHA-256",sel.hash]].map(([k,v])=>(
              <div key={k} style={{padding:"8px 12px",background:"var(--surface)",border:"1px solid var(--border)",borderRadius:6,marginBottom:8}}>
                <div style={{fontSize:10,color:"var(--t3)",marginBottom:2}}>{k}</div>
                <div style={{fontSize:12,fontFamily:"var(--mono)",wordBreak:"break-all"}}>{v}</div>
              </div>
            ))}
            <div style={{fontSize:12,fontWeight:600,color:"var(--t2)",marginBottom:6}}>File Contents</div>
            <pre style={{padding:12,background:"var(--surface)",border:"1px solid var(--border)",borderRadius:6,fontSize:11,fontFamily:"var(--mono)",color:"#b8c4cc",overflowX:"auto",whiteSpace:"pre-wrap"}}>{sel.output}</pre>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App(){
  const[tab,setTab]=useState("terminal");
  const[evidence,setEvidence]=useState([]);
  const[alerts,setAlerts]=useState(SIEM_ALERTS);
  const[contained,setContained]=useState(false);
  const[xp,setXp]=useState(0);
  const RANKS=[[0,"L1 Analyst"],[200,"L2 Analyst"],[500,"DFIR Analyst"],[900,"Senior Analyst"],[1400,"IR Lead"]];
  const rank=RANKS.filter(([n])=>xp>=n).pop()[1];
  const onEvidenceSaved=useCallback(e=>setEvidence(ev=>[...ev,e]),[]);
  const onAck=useCallback(id=>setAlerts(a=>a.map(x=>x.id===id?{...x,acked:true}:x)),[]);
  const onXP=useCallback(v=>setXp(x=>x+v),[]);
  return(
    <>
      <style>{GLOBAL_CSS}</style>
      <div style={{display:"flex",flexDirection:"column",height:"100dvh",overflow:"hidden"}}>
        <TopNav tab={tab} setTab={setTab} alertCount={alerts.filter(a=>!a.acked).length} evidenceCount={evidence.length} xp={xp} rank={rank} contained={contained}/>
        <div style={{flex:1,overflow:"hidden"}}>
          {tab==="alerts"&&<AlertsPanel alerts={alerts} onAck={onAck} onXP={onXP}/>}
          {tab==="terminal"&&<Terminal onEvidenceSaved={onEvidenceSaved} evidence={evidence} setContained={setContained} onXP={onXP}/>}
          {tab==="processes"&&<ProcessMonitor/>}
          {tab==="network"&&<NetworkMonitor/>}
          {tab==="evidence"&&<EvidenceLog evidence={evidence}/>}
        </div>
      </div>
      <ByteAssistant activePage={tab} onNavigate={setTab}/>
    </>
  );
}
