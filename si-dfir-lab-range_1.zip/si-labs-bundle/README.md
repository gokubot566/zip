# Security Impossible — DFIR Training Lab Range

Six self-contained, browser-based DFIR labs, deployable with a **single command**.
Every lab runs in its own nginx container with `restart: always`.

| Port | Lab                          | Folder            |
|------|------------------------------|-------------------|
| 8080 | Phishing Lab (Vantara SOC)   | `phishing-lab`    |
| 8081 | Ransomware Lab (Meridian)    | `ransomware-lab`  |
| 8082 | Post-Incident Review Lab     | `pir-lab`         |
| 8083 | Evidence Preservation Lab    | `evidence-lab`    |
| 8084 | Malware Outbreak Lab         | `malware-lab`     |

## Run everything

From this folder:

```bash
docker compose up -d --build
```

That builds and starts all six labs. Then browse to:

- http://YOUR_SERVER_IP:8080  (Phishing)
- http://YOUR_SERVER_IP:8081  (Ransomware)
- http://YOUR_SERVER_IP:8082  (Post-Incident Review)
- http://YOUR_SERVER_IP:8083  (Evidence Preservation)
- http://YOUR_SERVER_IP:8084  (Malware Outbreak)

## Common operations

```bash
docker compose ps                 # status of all labs
docker compose logs -f phishing-lab   # follow one lab's logs
docker compose up -d --build pir-lab  # rebuild + restart just one lab
docker compose down               # stop and remove all labs
docker compose restart            # restart all labs
```

`restart: always` means the labs come back automatically after a reboot or
container crash. To make them start on host boot, ensure the Docker daemon is
enabled (`systemctl enable docker`).

## Notes

- Fonts and icons are now **bundled into each image** — no external CDN is
  required at runtime, so icons render correctly even on locked-down networks.
- Each lab is independent; you can run a subset, e.g.
  `docker compose up -d --build phishing-lab ransomware-lab`.
- Ports are configurable in `docker-compose.yml` (left side of each `ports`
  mapping). The right side / container port matches the lab's internal nginx
  port and should not be changed without also editing that lab's `nginx.conf`.

---

## What changed in this revision

### All labs
- Replaced CDN-loaded fonts/icons with locally bundled packages (fixes
  "default icons" appearing when the CDN was blocked).
- Assistant panel now clamps and repositions correctly on window resize.
- More professional iconography in the guided assistant.

### Phishing Lab (8080)
- Markdown rendering fixed — bullets on separate lines, callouts, stray
  markdown markers no longer leak into the panel.
- Strict action-gating: Next stays locked until the required action is done
  (pause ticker, expand alerts, open email, quarantine, create case, navigate).
- Scrolling ticker now has a "View all" expandable, readable event list.
- Step 5 rewritten for clarity.
- Action Tracker is now case-specific (INC-2025-0312 vs the second case are no
  longer identical).
- Added an end-of-lab knowledge-check quiz.

### Ransomware Lab (8081)
- Fixed the "5 phases / 6 items" mismatch on the briefing screen.
- Action-gating with real completion detection (run the .exe, block IOCs,
  restore backups, save notes, file report, open each app).
- The current step's target app is highlighted on the taskbar.

### Post-Incident Review Lab (8082)
- Response-failure count corrected from 6 to 8 (and the two missing failures
  added to the assistant's list).
- Gap Analysis no longer reports a perfect score when answers are wrong; the
  score freezes at submission, classification locks, and the module only
  completes at 100% (with a "Try Again" path).
- The "100% on assessment" achievement now requires every answer to be correct.
- MTTD / MTTC / MTTR now have plain-language definitions on hover.
- KPI cards have a clear hover response.
- Timeline cards now show each event's ID.
- Adding a recommendation now visibly increments earned XP.

### Evidence Preservation Lab (8083)
- Containment now gives clear, specific guidance on what still needs to be
  collected (run vs save), plus an `evidence` checklist command, so the
  `contain` step works reliably once evidence is preserved.

### Malware Outbreak Lab (8084)
- Added the missing inbound SMB lateral-movement connection
  (10.10.1.14 → 10.10.1.22:445) to WKST-NC-22's Network tab.

