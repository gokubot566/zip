import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'build',
    sourcemap: false,
    chunkSizeWarningLimit: 2000,
    rollupOptions: {
      output: {
        manualChunks: { vendor: ['react','react-dom'] }
      }
    }
  },
  server: { port: 8081, host: '0.0.0.0' },
  preview: { port: 8081, host: '0.0.0.0' }
})
