import { useLab } from './hooks/useLab.js'
import TopBar from './components/TopBar.jsx'
import FolderRail from './components/FolderRail.jsx'
import MailList from './components/MailList.jsx'
import Reader from './components/Reader.jsx'
import SourceWindow from './components/SourceWindow.jsx'
import Analyzer from './components/Analyzer.jsx'
import BytePanel from './components/BytePanel.jsx'

export default function App() {
  const lab = useLab()

  const clientClass =
    'client' +
    (lab.foldersHidden ? ' nofolders' : '') +
    (lab.reading ? ' reading' : '')

  return (
    <div id="app">
      <TopBar onToggleFolders={lab.toggleFolders} />

      <div className="stage">
        <div className="mailarea" id="mailarea">
          <div className={clientClass} id="client">
            <FolderRail folder={lab.folder} onSwitch={lab.switchFolder} />
            <MailList folder={lab.folder} selected={lab.selected} pulse={lab.pulse} onOpen={lab.openEmail} />
            <Reader selected={lab.selected} pulse={lab.pulse} onBack={lab.backList} onViewSource={lab.chooseViewSource} />
          </div>

          <SourceWindow
            open={lab.srcOpen}
            email={lab.srcEmail}
            torchEnabled={lab.torchEnabled}
            canAnalyze={lab.canAnalyze}
            onReveal={lab.onSourceReveal}
            onHover={lab.onSourceHover}
            onAllRevealed={lab.onSourceAllRevealed}
            onClose={lab.closeSource}
            onAnalyze={lab.openAnalyzer}
          />

          <Analyzer
            open={lab.analyzerOpen}
            email={lab.srcEmail || null}
            analyzed={lab.analyzed}
            onRun={lab.runAnalysis}
            onClose={lab.closeAnalyzer}
          />
        </div>

        <BytePanel {...lab} />
      </div>
    </div>
  )
}
