import { useState, useEffect, useRef, useCallback } from 'react'
import { ByteAvatar } from './ByteAvatar.jsx'
import { CHARACTERS, LAB_META, AUTH_REFERENCE } from '../data/scenario.js'
import { CAST_PHOTOS } from '../data/cast.js'

const GAP = 16
const LAUNCHER = 64

/* ---- small helpers ---- */
function CastPhoto({ id, size = 30, speaking = false }) {
  const c = CHARACTERS[id]
  if (!c) return <ByteAvatar size={size} speaking={speaking} />
  const photo = CAST_PHOTOS[id]
  return (
    <span className={'cast-photo' + (speaking ? ' speaking' : '')}
      style={{ width: size, height: size, '--cloth': c.color, fontSize: size * 0.38 }}
      title={`${c.name} — ${c.role}`}>
      {photo ? <img src={photo} alt={c.name} draggable="false" /> : (c.initials || c.name.slice(0, 1))}
    </span>
  )
}
function GripIcon() {
  return (<svg viewBox="0 0 24 24" width="16" height="16" fill="none"><circle cx="8" cy="7" r="1.4" fill="currentColor" /><circle cx="12" cy="7" r="1.4" fill="currentColor" /><circle cx="16" cy="7" r="1.4" fill="currentColor" /><circle cx="8" cy="12" r="1.4" fill="currentColor" /><circle cx="12" cy="12" r="1.4" fill="currentColor" /><circle cx="16" cy="12" r="1.4" fill="currentColor" /></svg>)
}
function XIcon() { return (<svg viewBox="0 0 24 24" width="17" height="17" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>) }

function flagLabel(flag) { return flag === 'bad' ? 'Fails a check' : flag === 'warn' ? 'Worth checking' : 'Aligned' }
function parseAuth(val) {
  const g = (re) => { const m = String(val).match(re); return m ? m[1].toLowerCase() : null }
  return { spf: g(/spf=(\w+)/i), dkim: g(/dkim=(\w+)/i), dmarc: g(/dmarc=(\w+)/i) }
}
function resultClass(r) { return r === 'pass' ? 'good' : (r === 'none' || r === 'softfail' || r === 'neutral') ? 'warn' : 'bad' }

/* ---- current header teaching card (shown during the "read headers" step) ---- */
function HeaderTeach({ h }) {
  const isAuth = h.name === 'Authentication-Results'
  const auth = isAuth ? parseAuth(h.val) : null
  return (
    <div className="byte-fade byte-headcard">
      <div className="byte-headcard-top">
        <span className="hn">{h.name}</span>
        <span className={'fchip ' + h.flag}>{flagLabel(h.flag)}</span>
      </div>
      <div className="byte-headcard-expl" dangerouslySetInnerHTML={{ __html: h.expl }} />
      <div className="byte-headcard-val">{h.val}</div>
      {isAuth && (
        <div className="byte-auth">
          <div className="byte-auth-intro" dangerouslySetInnerHTML={{ __html: AUTH_REFERENCE.intro }} />
          {AUTH_REFERENCE.items.map((it) => {
            const r = auth[it.k.toLowerCase()]
            return (
              <div key={it.k} className="byte-auth-row">
                <div className="byte-auth-head">
                  <span className="byte-auth-k">{it.k}</span>
                  <span className="byte-auth-full">{it.full}</span>
                  {r && <span className={'auth-badge ' + resultClass(r)}>{it.k.toLowerCase()}={r}</span>}
                </div>
                <div className="byte-auth-body" dangerouslySetInnerHTML={{ __html: it.body + ' ' + it.results }} />
              </div>
            )
          })}
        </div>
      )}
      {!isAuth && h.note && <div className={'note ' + h.note.type} dangerouslySetInnerHTML={{ __html: h.note.txt }} />}
    </div>
  )
}

/* ---- intro screen (welcome + scenario + creative mission; no slides) ---- */
function Intro({ onStart }) {
  const phase1 = LAB_META.introChat
  const phase2 = LAB_META.teamChat
  const [stage, setStage] = useState('intro')  // 'intro' (auto) → 'gate' → 'team' (auto) → 'ready'
  const [n1, setN1] = useState(0)              // revealed lines in phase 1
  const [n2, setN2] = useState(0)              // revealed lines in phase 2
  const [typing, setTyping] = useState(false)
  const endRef = useRef(null)

  const pace = (text) => Math.min(1700, Math.max(650, 500 + (text?.length || 0) * 8))

  // auto-play phase 1 (Byte intro) — no clicking
  useEffect(() => {
    if (stage !== 'intro') return
    if (n1 >= phase1.length) { setStage('gate'); return }
    setTyping(true)
    const t = setTimeout(() => { setTyping(false); setN1((n) => n + 1) }, pace(phase1[n1].text))
    return () => clearTimeout(t)
  }, [stage, n1, phase1])

  // auto-play phase 2 (team) — no clicking
  useEffect(() => {
    if (stage !== 'team') return
    if (n2 >= phase2.length) { setStage('ready'); return }
    setTyping(true)
    const t = setTimeout(() => { setTyping(false); setN2((n) => n + 1) }, pace(phase2[n2].text))
    return () => clearTimeout(t)
  }, [stage, n2, phase2])

  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }) }, [n1, n2, typing, stage])

  const lines = [...phase1.slice(0, n1), ...(stage === 'team' || stage === 'ready' ? phase2.slice(0, n2) : [])]
  const typingWho = typing
    ? (stage === 'intro' ? phase1[n1]?.who : stage === 'team' ? phase2[n2]?.who : null)
    : null

  const Bubble = ({ ln, live }) => (
    <div className="byte-scene-line byte-fade">
      {ln.who === 'byte' ? <ByteAvatar size={26} speaking={live} /> : <CastPhoto id={ln.who} size={26} speaking={live} />}
      <div>
        <div className="byte-line-name" style={{ color: ln.who === 'byte' ? 'var(--accent)' : CHARACTERS[ln.who]?.color }}>
          {ln.who === 'byte' ? 'Byte' : CHARACTERS[ln.who]?.name}
        </div>
        <div className="byte-line-bubble" dangerouslySetInnerHTML={{ __html: ln.text }} />
      </div>
    </div>
  )

  return (
    <div className="byte-body byte-fade">
      <div className="byte-lab-title">{LAB_META.title}</div>
      <div className="byte-scene">
        {lines.map((ln, i) => <Bubble key={i} ln={ln} live={i === lines.length - 1 && !typing} />)}
        {typingWho && (
          <div className="byte-scene-line byte-fade">
            {typingWho === 'byte' ? <ByteAvatar size={26} speaking /> : <CastPhoto id={typingWho} size={26} speaking />}
            <div className="byte-typing"><span /><span /><span /></div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {stage === 'gate' && (
        <button className="byte-next" onClick={() => setStage('team')} style={{ marginTop: 14 }}>{LAB_META.meetCta} ▸</button>
      )}
      {stage === 'ready' && (
        <>
          <div className="byte-explore" dangerouslySetInnerHTML={{ __html: LAB_META.explore }} />
          <button className="byte-next" onClick={onStart} style={{ marginTop: 14 }}>{LAB_META.cta} →</button>
        </>
      )}
    </div>
  )
}

/* ---- reference tab: header primer + auth protocols ---- */
function GuideTab() {
  return (
    <div className="byte-body byte-fade">
      <div className="byte-area">Header quick-reference</div>
      <p className="byte-brief">An email's <b>headers</b> are a logbook the mail servers add as the message travels. Read the <b>Received</b> chain bottom-to-top to see where it started, and check the <b>Authentication-Results</b> to see whether the sender is who they claim.</p>
      <div className="byte-area" style={{ marginTop: 14 }}>Authentication protocols</div>
      <p className="byte-brief" dangerouslySetInnerHTML={{ __html: AUTH_REFERENCE.intro }} />
      {AUTH_REFERENCE.items.map((it) => (
        <div key={it.k} className="byte-def" style={{ marginTop: 10 }}>
          <div className="byte-def-title">{it.k} — {it.full}</div>
          <p className="byte-def-body" dangerouslySetInnerHTML={{ __html: it.body }} />
          <p className="byte-def-body" style={{ marginTop: 6 }} dangerouslySetInnerHTML={{ __html: it.results }} />
        </div>
      ))}
    </div>
  )
}

/* ---- summary (all tasks done) ---- */
function Summary({ onBack }) {
  return (
    <div className="byte-body byte-fade">
      <div className="byte-trophy">✓</div>
      <div className="byte-area" style={{ textAlign: 'center', color: 'var(--good)' }}>Lab complete</div>
      <h3 className="byte-summary-title">Mission accomplished</h3>
      <p className="byte-summary-body">You opened the message, viewed its raw source, torched every header, and ran it through the analyzer.</p>

      <div className="byte-area" style={{ marginTop: 4 }}>What you learned</div>
      <ul className="byte-outcomes">
        {LAB_META.outcomes.map((o, i) => (
          <li key={i} className="byte-outcome"><span className="byte-outcome-tick">✓</span><span>{o}</span></li>
        ))}
      </ul>

      <p className="byte-team-note">Reusable routine: open → view source → read headers → analyze. Nicely done. 🎉</p>
      <button className="byte-back" onClick={onBack} style={{ marginTop: 4 }}>← Back</button>
    </div>
  )
}

export default function BytePanel(props) {
  const {
    introSeen, startLab, tasks, currentTask, activeTask, activeDone, allDone, completed,
    advance, goBack, goToScreen, currentHeader, headersRevealed, headersTotal, srcEmail,
  } = props

  const [open, setOpen] = useState(true)
  const [tab, setTab] = useState('step')
  const [showHint, setShowHint] = useState(false)
  useEffect(() => { setShowHint(false) }, [activeTask?.id])

  const wRef = useRef(null)
  const bodyRef = useRef(null)
  const [pos, setPos] = useState(null)
  const [winSize, setWinSize] = useState({ w: window.innerWidth, h: window.innerHeight })
  const dragging = useRef(false)
  const shouldAnimateRef = useRef(false)
  const dragData = useRef(null)
  const didDrag = useRef(false)

  const placeWidget = useCallback((animate) => {
    const w = wRef.current; if (!w) return
    const vw = window.innerWidth, vh = window.innerHeight
    const ww = w.offsetWidth || (open ? 390 : LAUNCHER)
    const wh = w.offsetHeight || (open ? 520 : LAUNCHER)
    const maxLeft = Math.max(GAP, vw - ww - GAP), maxTop = Math.max(GAP, vh - wh - GAP)
    let left, top
    if (pos) { left = pos.xr * vw; top = pos.yr * vh } else { left = maxLeft; top = Math.max(GAP, vh * 0.5 - wh / 2) }
    left = Math.max(GAP, Math.min(left, maxLeft)); top = Math.max(GAP, Math.min(top, maxTop))
    w.style.transition = animate ? 'left .24s ease, top .24s ease' : 'none'
    w.style.left = left + 'px'; w.style.top = top + 'px'; w.style.right = 'auto'; w.style.bottom = 'auto'
  }, [pos, open])

  useEffect(() => {
    const onResize = () => setWinSize({ w: window.innerWidth, h: window.innerHeight })
    window.addEventListener('resize', onResize); return () => window.removeEventListener('resize', onResize)
  }, [])
  // keep the panel fully on-screen when its content height changes (e.g. the
  // intro conversation growing as lines are revealed)
  useEffect(() => {
    const el = wRef.current
    if (!el || typeof ResizeObserver === 'undefined') return
    const ro = new ResizeObserver(() => { if (!dragging.current) placeWidget(false) })
    ro.observe(el)
    return () => ro.disconnect()
  }, [placeWidget])
  useEffect(() => {
    if (dragging.current) return
    const a = shouldAnimateRef.current; shouldAnimateRef.current = false; placeWidget(a)
  }, [open, pos, winSize, placeWidget, introSeen, currentTask, tab, activeDone, showHint, currentHeader])

  const onDragMove = useCallback((e) => {
    const w = wRef.current; if (!w || !dragging.current) return
    if (e.cancelable) e.preventDefault()
    const pt = e.touches ? e.touches[0] : e; didDrag.current = true
    w.style.left = (pt.clientX - dragData.current.offX) + 'px'; w.style.top = (pt.clientY - dragData.current.offY) + 'px'
    w.style.right = 'auto'; w.style.bottom = 'auto'
  }, [])
  const onDragEnd = useCallback(() => {
    const w = wRef.current
    document.removeEventListener('mousemove', onDragMove); document.removeEventListener('mouseup', onDragEnd)
    document.removeEventListener('touchmove', onDragMove); document.removeEventListener('touchend', onDragEnd)
    if (!w) { dragging.current = false; return }
    const vw = window.innerWidth, vh = window.innerHeight, rect = w.getBoundingClientRect()
    const maxLeft = Math.max(GAP, vw - rect.width - GAP), maxTop = Math.max(GAP, vh - rect.height - GAP)
    const left = Math.max(GAP, Math.min(rect.left, maxLeft)), top = Math.max(GAP, Math.min(rect.top, maxTop))
    dragging.current = false; setPos({ xr: left / vw, yr: top / vh })
  }, [onDragMove])
  const onDragStart = useCallback((e) => {
    const w = wRef.current; if (!w) return
    const pt = e.touches ? e.touches[0] : e, rect = w.getBoundingClientRect()
    dragging.current = true; didDrag.current = false
    dragData.current = { offX: pt.clientX - rect.left, offY: pt.clientY - rect.top }
    w.style.transition = 'none'
    document.addEventListener('mousemove', onDragMove); document.addEventListener('mouseup', onDragEnd)
    document.addEventListener('touchmove', onDragMove, { passive: false }); document.addEventListener('touchend', onDragEnd)
    e.preventDefault()
  }, [onDragMove, onDragEnd])

  const speaker = activeTask ? CHARACTERS[activeTask.speaker] : null
  const subLine = !introSeen ? 'Introduction' : allDone ? 'Lab complete' : activeTask ? `Task ${activeTask.n} of ${tasks.length} · ${speaker ? speaker.name : 'Byte'}` : 'Introduction'
  const onHeaders = activeTask && activeTask.id === 'headers'

  return (
    <div className={`byte-root ${open ? 'is-open' : ''}`} ref={wRef}>
      {!open && (
        <button className="byte-launcher" onMouseDown={onDragStart} onTouchStart={onDragStart}
          onClick={() => { if (!didDrag.current) { shouldAnimateRef.current = true; setOpen(true) } }} title="Open Byte (drag to move)">
          <ByteAvatar size={54} speaking />
          {!allDone && <span className="byte-launch-badge">{Object.values(completed).filter(Boolean).length}/{tasks.length}</span>}
        </button>
      )}

      {open && (
        <div className="byte-panel">
          <div className="byte-head" onMouseDown={onDragStart} onTouchStart={onDragStart}>
            <ByteAvatar size={40} speaking />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="byte-title">Byte · Lab Guide</div>
              <div className="byte-sub">{subLine}</div>
            </div>
            <span className="byte-grip" title="Drag to move"><GripIcon /></span>
            <button className="byte-x" onClick={() => { shouldAnimateRef.current = true; setOpen(false) }} title="Minimise"><XIcon /></button>
          </div>

          {/* progress rail */}
          <div className="byte-progress">
            {tasks.map((t, i) => (
              <span key={t.id} className={'byte-pip ' + (completed[t.id] ? 'done' : (!allDone && i === currentTask ? 'cur' : ''))} />
            ))}
          </div>

          {!introSeen ? (
            <Intro onStart={() => { startLab() }} />
          ) : allDone ? (
            <Summary onBack={goBack} />
          ) : (
            <>
              <div className="byte-tabs">
                <button className={tab === 'step' ? 'on' : ''} onClick={() => setTab('step')}>Current step</button>
                <button className={tab === 'guide' ? 'on' : ''} onClick={() => setTab('guide')}>Guide</button>
              </div>

              {tab === 'guide' ? <GuideTab /> : (
                <div className="byte-body" ref={bodyRef}>
                  {activeTask && (
                    <div className="byte-fade">
                      <div className="byte-area">Task {activeTask.n} · {activeTask.title}</div>
                      <div className="byte-speaker">
                        {activeTask.speaker === 'byte' ? <ByteAvatar size={30} speaking /> : <CastPhoto id={activeTask.speaker} size={30} speaking />}
                        <span>{speaker ? `${speaker.name} · ${speaker.role}` : 'Byte · Lab Guide'}</span>
                      </div>
                      <p className="byte-brief" dangerouslySetInnerHTML={{ __html: activeTask.brief }} />

                      <div className="byte-goal">
                        <div className="byte-goal-label">Your task</div>
                        <span dangerouslySetInnerHTML={{ __html: activeTask.task }} />
                      </div>

                      {/* what the automatic analysis does (analyze step) */}
                      {activeTask.does && (
                        <div className="byte-does">
                          <div className="byte-does-head">What the analysis does</div>
                          {activeTask.does.map((d, i) => (
                            <div key={i} className="byte-does-item">
                              <span className="byte-does-ico">{d.icon}</span>
                              <div><b>{d.label}</b> — <span dangerouslySetInnerHTML={{ __html: d.text }} /></div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* live header teaching during the "read headers" step */}
                      {onHeaders && (
                        <div className="byte-headprog">
                          <span>{headersRevealed}/{headersTotal || '·'} headers</span>
                        </div>
                      )}
                      {onHeaders && currentHeader && <HeaderTeach h={currentHeader} />}

                      <button className="byte-hint-toggle" onClick={() => setShowHint((h) => !h)}>
                        💡 {showHint ? 'Hide hint' : 'Need a hint?'}
                      </button>
                      {showHint && <div className="byte-hint" dangerouslySetInnerHTML={{ __html: activeTask.hint }} />}

                      <div className={'byte-status ' + (activeDone ? 'ok' : '')}>
                        {activeDone
                          ? <span dangerouslySetInnerHTML={{ __html: '✓ ' + activeTask.successNote }} />
                          : '🔒 Do this on the screen to unlock the next step.'}
                      </div>

                      <div className="byte-nav">
                        <button className="byte-back" onClick={goBack}>← Back</button>
                        <button className="byte-next" disabled={!activeDone} onClick={advance}>
                          {activeDone ? (currentTask === tasks.length - 1 ? 'Finish →' : 'Next step →') : 'Locked 🔒'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  )
}
