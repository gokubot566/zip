const FOLDERS = [
  { id: 'inbox', label: 'Inbox', count: '6', icon: (<svg viewBox="0 0 24 24" fill="none"><path d="M3 13l3-8h12l3 8v6H3v-6z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" /><path d="M3 13h5l2 3h4l2-3h5" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" /></svg>) },
  { id: 'starred', label: 'Starred', icon: (<svg viewBox="0 0 24 24" fill="none"><path d="M12 3l2.7 5.5 6 .9-4.3 4.2 1 6L12 17l-5.4 2.6 1-6L3.3 9.4l6-.9L12 3z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" /></svg>) },
  { id: 'sent', label: 'Sent', icon: (<svg viewBox="0 0 24 24" fill="none"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" /></svg>) },
  { id: 'drafts', label: 'Drafts', count: '1', icon: (<svg viewBox="0 0 24 24" fill="none"><path d="M4 20h4L18 10l-4-4L4 16v4z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" /></svg>) },
  { sep: true },
  { id: 'spam', label: 'Spam', count: '3', countBad: true, icon: (<svg viewBox="0 0 24 24" fill="none"><path d="M12 3l9 16H3L12 3z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" /><path d="M12 10v4M12 17h.01" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" /></svg>) },
  { id: 'trash', label: 'Trash', icon: (<svg viewBox="0 0 24 24" fill="none"><path d="M5 7h14M9 7V5h6v2m-8 0v13h10V7" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" /></svg>) },
  { id: 'archive', label: 'Archive', icon: (<svg viewBox="0 0 24 24" fill="none"><path d="M3 7h18v4H3V7zm1 4h16v9H4v-9zm5 3h6" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" /></svg>) },
]

export default function FolderRail({ folder, onSwitch }) {
  return (
    <nav className="folders" id="folders">
      <div className="acct">
        <span className="av">DR</span>
        <div><div className="nm">Jordan Blake</div><div className="em">jordan.blake@arclight-logistics.com</div></div>
      </div>
      <button className="compose">
        <svg viewBox="0 0 24 24" fill="none"><path d="M4 20h4L18 10l-4-4L4 16v4z" stroke="#fff" strokeWidth="1.7" strokeLinejoin="round" /><path d="M14 6l4 4" stroke="#fff" strokeWidth="1.7" /></svg>
        Compose
      </button>
      {FOLDERS.map((f, i) =>
        f.sep ? (
          <div className="fold-sep" key={`sep${i}`} />
        ) : (
          <div
            key={f.id}
            className={'fold' + (folder === f.id ? ' active' : '')}
            onClick={() => onSwitch(f.id)}
          >
            {f.icon} {f.label}
            {f.count && <span className={'fcnt' + (f.countBad ? ' bad' : '')}>{f.count}</span>}
          </div>
        )
      )}
    </nav>
  )
}
