import { useEffect, useRef, useState } from 'react'
import { EMAILS } from '../data/emails.js'
import { domainOf } from '../utils.js'

export default function Reader({ selected, pulse, onBack, onViewSource }) {
  const [menuOpen, setMenuOpen] = useState(false)
  const kebabRef = useRef(null)

  // close the kebab menu on any outside click (matches original document listener)
  useEffect(() => {
    const onDoc = () => setMenuOpen(false)
    document.addEventListener('click', onDoc)
    return () => document.removeEventListener('click', onDoc)
  }, [])

  // reset menu when switching messages
  useEffect(() => { setMenuOpen(false) }, [selected])

  if (!selected) {
    return (
      <div className="reader" id="reader">
        <div className="reader-empty">
          <div>
            <svg viewBox="0 0 24 24" fill="none"><path d="M3 7l9 6 9-6M4 5h16a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V6a1 1 0 011-1z" stroke="currentColor" strokeWidth="1.5" /></svg>
            <div>Byte will guide you — start on the right.</div>
          </div>
        </div>
      </div>
    )
  }

  const e = EMAILS.find((x) => x.id === selected)

  return (
    <div className="reader" id="reader">
      <div className="rd">
        <button className="vbtn legit back-m" style={{ marginBottom: 12 }} onClick={onBack}>‹ Inbox</button>
        <div className="rd-head">
          <h2>{e.subject}</h2>
          <div className="kebab" ref={kebabRef}>
            <button
              className={'kbtn' + (pulse === 'kebab' ? ' pulse' : '')}
              id="kebabBtn" title="More actions" aria-label="More actions"
              onClick={(ev) => { ev.stopPropagation(); setMenuOpen((o) => !o) }}
            >
              <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="5" r="1.6" fill="currentColor" /><circle cx="12" cy="12" r="1.6" fill="currentColor" /><circle cx="12" cy="19" r="1.6" fill="currentColor" /></svg>
            </button>
            <div className={'kmenu' + (menuOpen ? ' open' : '')} id="kmenu">
              <button className="kitem disabled"><svg viewBox="0 0 24 24" fill="none"><path d="M3 10l9-6 9 6v10H3V10z" stroke="currentColor" strokeWidth="1.5" /></svg> Reply</button>
              <button className="kitem disabled"><svg viewBox="0 0 24 24" fill="none"><path d="M4 12h13m0 0l-5-5m5 5l-5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg> Forward</button>
              <button className="kitem src" onClick={() => { setMenuOpen(false); onViewSource() }}>
                <svg viewBox="0 0 24 24" fill="none"><path d="M8 6l-5 6 5 6M16 6l5 6-5 6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg> View source
              </button>
              <button className="kitem disabled"><svg viewBox="0 0 24 24" fill="none"><path d="M5 7h14M9 7V5h6v2m-8 0v13h10V7" stroke="currentColor" strokeWidth="1.5" /></svg> Delete</button>
            </div>
          </div>
        </div>

        <div className="rd-meta">
          <div className="meta-row"><span className="k">From</span><span className="v"><span className="disp">{e.fromName}</span> &lt;<span className="addr">{e.fromAddr}</span>&gt;</span></div>
          <div className="meta-row"><span className="k">To</span><span className="v"><span className="addr">{e.to}</span></span></div>
          <div className="meta-row"><span className="k">Date</span><span className="v"><span className="addr">{e.date}</span></span></div>
          <div className="meta-row"><span className="k">Domain</span><span className="v"><span className="addr">{domainOf(e.fromAddr)}</span></span></div>
        </div>

        <div className="rd-body" dangerouslySetInnerHTML={{ __html: e.body }} />
      </div>
    </div>
  )
}
