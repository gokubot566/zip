import { useEffect, useMemo, useRef, useState } from 'react'
import { HORDER } from '../data/emails.js'

/**
 * "View source" window: a dark stage lit by a torch.
 *
 *  - Walkthrough: sweep the torch down and each header lights up in order
 *    (only the current one shows; the previous disappears). No markers, no
 *    "reveal" button — you find them in the dark.
 *  - After every header has been seen once, the torch becomes free: whatever
 *    section it passes over becomes visible again, so you can re-check anything.
 *  - "Lights" is a toggle switch, disabled until the walkthrough is complete;
 *    flipped on it reveals the whole source at once.
 */
export default function SourceWindow({ open, email, torchEnabled = true, canAnalyze = true, onReveal, onHover, onAllRevealed, onClose, onAnalyze }) {
  const stageRef = useRef(null)
  const rawRef = useRef(null)
  const rowRefs = useRef([])

  const [revIdx, setRevIdx] = useState(0)
  const [lightsOn, setLightsOn] = useState(false)
  const [swept, setSwept] = useState(false)
  const [hoverIdx, setHoverIdx] = useState(-1) // section under the torch once finished

  const revealOrder = useMemo(() => {
    if (!email) return []
    return [...email.headers].sort((a, b) => (HORDER[a.name] || 50) - (HORDER[b.name] || 50))
  }, [email])
  const len = revealOrder.length
  const finished = revIdx >= len

  const setTorch = (x, y) => {
    const s = stageRef.current
    if (!s) return
    s.style.setProperty('--tx', x + 'px')
    s.style.setProperty('--ty', y + 'px')
  }

  // (re)build when the window opens with an email
  useEffect(() => {
    if (!open || !email) return
    rowRefs.current = []
    setRevIdx(0)
    setLightsOn(false)
    setSwept(false)
    setHoverIdx(-1)
    setTorch(-300, -300)
    // start at the very top so the first header (From) is where the torch begins
    if (rawRef.current) rawRef.current.scrollTop = 0
  }, [open, email])

  // esc closes
  useEffect(() => {
    if (!open) return
    const onKey = (e) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open, onClose])

  // which header row (index) is at vertical position y within the stage
  const rowIndexAt = (y) => {
    const raw = rawRef.current
    if (!raw) return -1
    for (let i = 0; i < len; i++) {
      const el = rowRefs.current[i]
      if (!el) continue
      const top = el.offsetTop - raw.scrollTop
      const bot = top + el.offsetHeight
      if (y >= top - 6 && y <= bot + 6) return i
    }
    return -1
  }

  const reveal = (idx) => {
    if (idx >= len) return
    const h = revealOrder[idx]
    onReveal(h, idx + 1, len)
    setHoverIdx(idx)
    const el = rowRefs.current[idx]
    if (el) el.scrollIntoView({ block: 'nearest' })
    const next = idx + 1
    setRevIdx(next)
    if (next >= len) onAllRevealed(email)
  }

  const onMove = (cx, cy) => {
    if (!torchEnabled || lightsOn) return
    const stage = stageRef.current
    if (!stage) return
    const r = stage.getBoundingClientRect()
    const x = cx - r.left, y = cy - r.top
    setTorch(x, y)
    if (!swept) setSwept(true)
    // reveal the next header when the torch passes over it (in order)
    if (!finished) {
      const idx = revIdx
      const el = rowRefs.current[idx]
      const raw = rawRef.current
      if (el && raw) {
        const top = el.offsetTop - raw.scrollTop
        const bot = top + el.offsetHeight
        if (y >= top - 14 && y <= bot + 14) reveal(idx)
      }
    }
    // only the header directly under the torch stays visible — the rest hide
    const hi = rowIndexAt(y)
    setHoverIdx(hi)
    const maxRevealed = (finished ? len : revIdx) - 1
    if (onHover) onHover(hi >= 0 && hi <= maxRevealed ? revealOrder[hi] : null)
  }

  const toggleLights = () => {
    if (!finished) return
    setLightsOn((v) => !v)
  }

  // a header is visible only while the torch is directly over it (once revealed)
  const rowLit = (i) => (lightsOn ? true : (i === hoverIdx && i <= revIdx - 1))

  // the header currently under the light — drives the in-source explanation caption
  const litIdx = lightsOn ? -1 : (hoverIdx >= 0 && hoverIdx <= revIdx - 1 ? hoverIdx : -1)
  const litHeader = litIdx >= 0 ? revealOrder[litIdx] : null
  const flagText = (f) => (f === 'bad' ? '⚑ mismatch' : f === 'warn' ? '! check' : '✓ aligned')

  return (
    <div className={'srcwin' + (open ? ' open' : '')} id="srcwin" role="dialog" aria-label="Raw message source">
      <div className="sw-bar">
        <span className="dot3"><i /><i /><i /></span>
        <span className="sw-title">view-source: <b id="swName">{email ? email.id + '.eml' : 'message.eml'}</b></span>
        <button className="sw-close" onClick={onClose}>Close ✕</button>
      </div>

      <div className="sw-legend">
        <span className="sw-legend-label">Flags:</span>
        <span className="sw-leg ok"><b>✓ aligned</b> — matches / passes</span>
        <span className="sw-leg warn"><b>! check</b> — worth a closer look</span>
        <span className="sw-leg bad"><b>⚑ mismatch</b> — fails / doesn't line up</span>
      </div>

      <div
        className={'sw-stage' + (lightsOn ? ' lit' : '') + (swept ? ' swept' : '')}
        id="swStage"
        ref={stageRef}
        onMouseMove={(e) => onMove(e.clientX, e.clientY)}
        onTouchStart={(e) => { const t = e.touches[0]; if (t) onMove(t.clientX, t.clientY) }}
        onTouchMove={(e) => { const t = e.touches[0]; if (t) onMove(t.clientX, t.clientY) }}
      >
        <div className="sw-raw" id="swRaw" ref={rawRef}>
          {revealOrder.map((h, i) => {
            const mk = h.flag === 'bad' ? '⚑ mismatch' : h.flag === 'warn' ? '! check' : '✓ aligned'
            const valHtml = String(h.val).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>&nbsp;&nbsp;')
            return (
              <span
                key={i}
                id={'srch-' + i}
                ref={(el) => { rowRefs.current[i] = el }}
                className={'srch ' + h.flag + (rowLit(i) ? ' lit' : '')}
                dangerouslySetInnerHTML={{ __html: `<span class="mk">${mk}</span><span class="k">${h.name}:</span> <span class="v">${valHtml}</span>` }}
              />
            )
          })}
          <div id="srcsep" style={{ color: '#3a465e', padding: '12px 20px', fontSize: 11, opacity: (finished || lightsOn) ? 1 : 0 }}>
            — message body follows (omitted) —
          </div>
        </div>

        <div className="sw-dim" id="swDim" />
        <div className="sw-torch" id="swTorch" />
        <div className="sw-torchico" id="swTorchIco">
          <svg viewBox="0 0 46 24" fill="none">
            <rect x="3" y="7.5" width="21" height="9" rx="2.5" fill="#241a06" stroke="var(--accent)" strokeWidth="1.7" />
            <path d="M9 7.5v9M14 7.5v9M19 7.5v9" stroke="var(--accent)" strokeWidth="1" opacity="0.45" />
            <path d="M24 5 L31 3 L31 21 L24 19 Z" fill="var(--accent)" />
            <path d="M32 6.5 L44 2 L44 22 L32 17.5 Z" fill="var(--accent)" opacity="0.25" />
          </svg>
        </div>

        {torchEnabled ? (
          <div className="sw-hint" id="swHint">
            <svg viewBox="0 0 24 24" fill="none"><path d="M6 6l3.5 3.5M6 18l3.5-3.5M18 6l-3.5 3.5M18 18l-3.5-3.5" stroke="var(--accent)" strokeWidth="1.4" strokeLinecap="round" /><circle cx="12" cy="12" r="3.2" stroke="var(--accent)" strokeWidth="1.4" /></svg>
            It's dark — use the torch to find a way out.
          </div>
        ) : (
          <div className="sw-locked">
            <div className="sw-locked-box">
              🔒 The torch switches on at the <b>“Read the headers”</b> step.<br />
              For now, this is just a preview of the raw source — continue with <b>Next step</b> in Byte to begin.
            </div>
          </div>
        )}
      </div>

      <div className="sw-caption" aria-live="polite">
        {litHeader ? (
          <>
            <span className={'sw-cap-flag ' + litHeader.flag}>{flagText(litHeader.flag)}</span>
            <b className="sw-cap-name">{litHeader.name}</b>
            <span className="sw-cap-expl" dangerouslySetInnerHTML={{ __html: litHeader.expl }} />
          </>
        ) : (
          <span className="sw-cap-idle">{lightsOn ? 'Lights on — the full source is shown.' : 'Sweep the torch over a header to read what it means.'}</span>
        )}
      </div>

      <div className="sw-foot">
        <span className="prog"><b id="swDone">{revIdx}</b> / <span id="swTotal">{len}</span> headers revealed</span>
        <span className="grow" />
        {finished && canAnalyze && (
          <button className="sw-analyze" onClick={onAnalyze} title="Parse these headers in the analyzer">
            🧰 Open Header Analyzer →
          </button>
        )}
        {finished && !lightsOn && (
          <span className="sw-lights-hint">Reveal the whole message ▸</span>
        )}
        <button
          className={'sw-toggle' + (lightsOn ? ' on' : '')}
          id="lightsBtn"
          role="switch"
          aria-checked={lightsOn}
          disabled={!finished}
          onClick={toggleLights}
          title={finished ? 'Lights: show every header at once' : 'Unlocks once you have read every header'}
        >
          <span className="sw-toggle-track"><span className="sw-toggle-knob" /></span>
          <span className="sw-toggle-label">Lights {lightsOn ? 'on' : 'off'}</span>
        </button>
      </div>
    </div>
  )
}
