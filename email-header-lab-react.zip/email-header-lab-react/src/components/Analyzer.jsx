import { useMemo } from 'react'

const domOf = (s) => { const m = String(s).match(/@([\w.-]+)/); return m ? m[1] : (String(s).match(/([\w-]+\.[\w.-]+)/)?.[1] || '—') }
const authVal = (v, re) => { const m = String(v).match(re); return m ? m[1].toLowerCase() : 'n/a' }
const badge = (r) => r === 'pass' ? 'good' : (r === 'none' || r === 'softfail' || r === 'neutral' || r === 'n/a') ? 'warn' : 'bad'

// Plain-language meaning for each authentication result.
const MEANING = {
  spf: { pass: 'Sent by a server the domain authorises.', fail: 'Sent by a server the domain does NOT authorise.', softfail: 'Probably not an authorised server.', neutral: 'Domain expresses no opinion.', none: 'No SPF record to check against.', 'n/a': 'Not present.' },
  dkim: { pass: 'Valid signature — content untampered and from the domain.', fail: 'A signature was present but did not verify.', none: 'The message was not signed.', 'n/a': 'Not present.' },
  dmarc: { pass: 'The visible From domain is backed by an aligned, passing check.', fail: 'The From domain is not authenticated — apply the domain policy.', none: 'No DMARC policy is published for the domain.', 'n/a': 'Not present.' },
}

/**
 * Email Header Analyzer — an educational tool that parses a message's headers
 * into header fields, relay hops, authentication results and identity checks,
 * with a plain-language explanation of each. Vendor-neutral (no external service).
 */
export default function Analyzer({ open, email, analyzed, onRun, onClose }) {
  const data = useMemo(() => {
    if (!email) return null
    const by = (n) => email.headers.find((h) => h.name === n)
    const raw = [
      `From: ${by('From')?.val || ''}`,
      `To: ${email.to}`,
      `Subject: ${email.subject}`,
      `Date: ${email.date}`,
      `Reply-To: ${by('Reply-To')?.val || '(none)'}`,
      `Return-Path: ${by('Return-Path')?.val || '(none)'}`,
      `Message-ID: ${by('Message-ID')?.val || '(none)'}`,
      ...email.headers.filter((h) => h.name === 'Received').map((h) => `Received: ${h.val}`),
      `Authentication-Results: ${by('Authentication-Results')?.val || '(none)'}`,
    ].join('\n')

    const fields = [
      { k: 'From', v: by('From')?.val || email.fromAddr },
      { k: 'To', v: email.to },
      { k: 'Subject', v: email.subject },
      { k: 'Date', v: email.date },
    ]

    const hops = email.headers.filter((h) => h.name === 'Received').map((h) => ({
      from: h.val.match(/from\s+([^\s(]+)/i)?.[1] || '—',
      ip: h.val.match(/\(([\d.]+)\)/)?.[1] || '—',
      by: h.val.match(/by\s+([^\s]+)/i)?.[1] || '—',
    }))

    const av = by('Authentication-Results')?.val || ''
    const auth = { spf: authVal(av, /spf=(\w+)/i), dkim: authVal(av, /dkim=(\w+)/i), dmarc: authVal(av, /dmarc=(\w+)/i) }

    const fromDom = domOf(by('From')?.val || email.fromAddr)
    const identity = [
      { k: 'From', v: by('From')?.val || email.fromAddr, d: fromDom },
      { k: 'Reply-To', v: by('Reply-To')?.val || '(none)', d: domOf(by('Reply-To')?.val || '') },
      { k: 'Return-Path', v: by('Return-Path')?.val || '(none)', d: domOf(by('Return-Path')?.val || '') },
      { k: 'Message-ID', v: by('Message-ID')?.val || '(none)', d: domOf(by('Message-ID')?.val || '') },
    ].map((r) => ({ ...r, mismatch: r.k !== 'From' && r.d !== '—' && r.d !== fromDom }))

    const passes = ['spf', 'dkim', 'dmarc'].filter((k) => auth[k] === 'pass').length
    const ok = passes === 3
    const mismatches = identity.filter((r) => r.mismatch).length
    return { raw, fields, hops, auth, identity, fromDom, ok, mismatches }
  }, [email])

  if (!data) return <div className={'anwin' + (open ? ' open' : '')} />

  return (
    <div className={'anwin' + (open ? ' open' : '')} role="dialog" aria-label="Email header analyzer">
      <div className="an-bar">
        <span className="an-title">🧰 Email Header Analyzer <span className="an-sub">· header fields · relay path · authentication · identity</span></span>
        <button className="sw-close" onClick={onClose}>Close ✕</button>
      </div>

      <div className="an-body">
        <div className="an-label">Raw header (from the sample message)</div>
        <pre className="an-raw">{data.raw}</pre>

        {!analyzed ? (
          <>
            <p className="an-how">Paste any email's headers into a tool like this and it does the parsing for you — breaking the header block into the fields below and checking each one. Press <b>Analyze</b> to parse this message.</p>
            <button className="an-run" onClick={onRun}>Analyze header ▸</button>
          </>
        ) : (
          <>
            <div className={'an-verdict ' + (data.ok ? 'ok' : 'bad')}>
              {data.ok
                ? 'All three authentication checks passed and the identity headers are consistent — the sending domain is verified and aligned.'
                : `Authentication did not fully pass for the From domain (${data.fromDom}): SPF=${data.auth.spf}, DKIM=${data.auth.dkim}, DMARC=${data.auth.dmarc}${data.mismatches ? `, with ${data.mismatches} identity header(s) pointing to a different domain` : ''}. On this evidence the sender is unverified.`}
            </div>

            <div className="an-sec">Header fields</div>
            <table className="an-table">
              <tbody>
                {data.fields.map((f) => (
                  <tr key={f.k}><td style={{ width: 110 }}>{f.k}</td><td className="an-mono">{f.v}</td></tr>
                ))}
              </tbody>
            </table>

            <div className="an-sec">Authentication</div>
            <table className="an-table">
              <thead><tr><th>Check</th><th>Result</th><th>What it means</th></tr></thead>
              <tbody>
                {[['SPF', 'spf'], ['DKIM', 'dkim'], ['DMARC', 'dmarc']].map(([label, k]) => (
                  <tr key={k}>
                    <td><b>{label}</b></td>
                    <td><span className={'auth-badge ' + badge(data.auth[k])}>{data.auth[k]}</span></td>
                    <td>{MEANING[k][data.auth[k]] || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="an-sec">Relay information (origin → your server, read bottom-to-top)</div>
            <table className="an-table">
              <thead><tr><th>Hop</th><th>From (origin host)</th><th>IP</th><th>Received by</th></tr></thead>
              <tbody>
                {data.hops.length === 0 && <tr><td colSpan={4} style={{ color: 'var(--text-mute)' }}>No Received hops present.</td></tr>}
                {data.hops.map((h, i) => (
                  <tr key={i}><td>{i + 1}</td><td className="an-mono">{h.from}</td><td className="an-mono">{h.ip}</td><td className="an-mono">{h.by}</td></tr>
                ))}
              </tbody>
            </table>

            <div className="an-sec">Identity headers (should all share the From domain)</div>
            <table className="an-table">
              <thead><tr><th>Header</th><th>Value</th><th>Domain</th></tr></thead>
              <tbody>
                {data.identity.map((r) => (
                  <tr key={r.k} className={r.mismatch ? 'an-mismatch' : ''}>
                    <td>{r.k}</td>
                    <td className="an-mono">{r.v}</td>
                    <td>{r.d}{r.mismatch && <span className="an-tag">differs from From</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}
      </div>
    </div>
  )
}
