// Reusable inline SVG icons. The robot is Byte's avatar, reused in the panel
// header and in every Byte chat bubble.
export function RobotIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none">
      <rect x="4" y="7" width="16" height="12" rx="3" stroke="#fff" strokeWidth="1.6" />
      <circle cx="9" cy="13" r="1.4" fill="#fff" />
      <circle cx="15" cy="13" r="1.4" fill="#fff" />
      <path d="M12 7V3M9 3h6M8 19v2M16 19v2" stroke="#fff" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  )
}

export function ShieldIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M12 2l8 4v6c0 5-3.5 8-8 10-4.5-2-8-5-8-10V6l8-4z" stroke="#fff" strokeWidth="1.6" />
      <path d="M9 12l2 2 4-4" stroke="#fff" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function HamburgerIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  )
}
