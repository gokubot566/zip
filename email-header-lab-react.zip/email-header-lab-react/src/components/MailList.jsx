import { EMAILS } from '../data/emails.js'

function EmptyFolder({ label }) {
  return (
    <div className="folder-empty">
      <svg viewBox="0 0 24 24" fill="none"><path d="M3 7l9 6 9-6M4 5h16a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V6a1 1 0 011-1z" stroke="currentColor" strokeWidth="1.5" /></svg>
      <div>No messages in {label}.<br />
        <span style={{ fontSize: 12, color: 'var(--text-mute)' }}>
          The sample message is in the <b style={{ color: 'var(--text-dim)' }}>Inbox</b>.
        </span>
      </div>
    </div>
  )
}

export default function MailList({ folder, selected, pulse, onOpen }) {
  const isInbox = folder === 'inbox'
  const label = folder.charAt(0).toUpperCase() + folder.slice(1)

  return (
    <div className="list">
      <div className="owner">
        <span className="av">📥</span>
        <div>
          <div className="nm">{isInbox ? 'Inbox' : label}</div>
          <div className="em">{isInbox ? "Jordan Blake · 6 messages" : ''}</div>
        </div>
      </div>
      <div className="list-scroll" id="mailList">
        {isInbox
          ? EMAILS.map((e) => (
              <div
                key={e.id}
                id={'row-' + e.id}
                tabIndex={0}
                className={'mrow' + (selected === e.id ? ' sel' : '') + (pulse === 'row-' + e.id ? ' pulse' : '')}
                onClick={() => onOpen(e.id)}
                onKeyDown={(ev) => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); onOpen(e.id) } }}
              >
                <div className="mr-top">
                  <span className="mr-from">{e.fromName}</span>
                  <span className="mr-time">{e.time}</span>
                </div>
                <div className="mr-subj">{e.subject}</div>
                <div className="mr-prev">{e.preview}</div>
              </div>
            ))
          : <EmptyFolder label={label} />}
      </div>
    </div>
  )
}
