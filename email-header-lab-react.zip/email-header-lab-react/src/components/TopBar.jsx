import { ShieldIcon, HamburgerIcon } from './icons.jsx'

export default function TopBar({ onToggleFolders }) {
  return (
    <div className="topbar">
      <button className="icon-btn" id="foldToggle" title="Show/hide mailbox folders" aria-label="Toggle folders" onClick={onToggleFolders}>
        <HamburgerIcon />
      </button>
      <span className="mk"><ShieldIcon /></span>
      <span className="bt"><b>Cyber Academy</b><small>Introduction to Email Header Analysis · Interactive Lab</small></span>
      <span className="spacer" />
      <span className="case">Lab · Email Headers</span>
    </div>
  )
}
