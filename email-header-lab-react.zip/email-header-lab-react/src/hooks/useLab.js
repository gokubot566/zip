import { useCallback, useMemo, useRef, useState } from 'react'
import { EMAILS } from '../data/emails.js'
import { TASKS, TARGET } from '../data/scenario.js'

/**
 * Task-gated lab controller. The lab is a sequence of steps; the next step's
 * "Next" button stays LOCKED until the current step's action is actually done
 * in the UI. Byte guides each step. No incident-response framing.
 */
export function useLab() {
  // intro / task progression
  const [introSeen, setIntroSeen] = useState(false)
  const [currentTask, setCurrentTask] = useState(0)
  const [completed, setCompleted] = useState({ open: false, source: false, headers: false, analyze: false })

  // mail client
  const [selected, setSelected] = useState(null)
  const [reading, setReading] = useState(false)
  const [folder, setFolder] = useState('inbox')
  const [foldersHidden, setFoldersHidden] = useState(false)

  // source window + torch
  const [srcOpen, setSrcOpen] = useState(false)
  const [srcEmail, setSrcEmail] = useState(null)
  const [currentHeader, setCurrentHeader] = useState(null)
  const [headersRevealed, setHeadersRevealed] = useState(0)
  const [headersTotal, setHeadersTotal] = useState(0)

  // analyzer
  const [analyzerOpen, setAnalyzerOpen] = useState(false)
  const [analyzed, setAnalyzed] = useState(false)

  // guidance highlight
  const [pulse, setPulse] = useState(null) // 'row-m2' | 'kebab' | null

  const markDone = useCallback((id) => setCompleted((c) => (c[id] ? c : { ...c, [id]: true })), [])

  const tasks = TASKS
  const activeTask = currentTask < tasks.length ? tasks[currentTask] : null
  const activeDone = activeTask ? completed[activeTask.id] : true
  const allDone = currentTask >= tasks.length
  // the torch only works once the learner reaches the "Read the headers" step
  const headersIdx = tasks.findIndex((t) => t.id === 'headers')
  const torchEnabled = introSeen && currentTask >= headersIdx
  // the "Open Header Analyzer" button only appears on the analyze step (task 4)
  const analyzeIdx = tasks.findIndex((t) => t.id === 'analyze')
  const canAnalyze = introSeen && currentTask >= analyzeIdx

  // ---- intro ----
  const startLab = useCallback(() => {
    setIntroSeen(true)
    setCurrentTask(0)
    setPulse('row-' + TARGET)
  }, [])

  // ---- advance (only when the current step is done) ----
  const advance = useCallback(() => {
    setCurrentTask((i) => {
      const t = tasks[i]
      if (t && !completed[t.id]) return i // locked
      const next = i + 1
      // guidance for the next step
      if (tasks[next]) {
        if (tasks[next].id === 'open') setPulse('row-' + TARGET)
        else if (tasks[next].id === 'source') setPulse('kebab')
        else setPulse(null)
      } else setPulse(null)
      return next
    })
  }, [tasks, completed])

  // ---- go back to the previous section (always allowed) ----
  const goBack = useCallback(() => {
    setCurrentTask((i) => {
      if (i >= tasks.length) return tasks.length - 1 // from summary → last task
      if (i > 0) {
        const prev = tasks[i - 1]
        if (prev.id === 'open') setPulse('row-' + TARGET)
        else if (prev.id === 'source') setPulse('kebab')
        else setPulse(null)
        return i - 1
      }
      // from first task → back to the intro
      setIntroSeen(false)
      return 0
    })
  }, [tasks])

  // ---- inbox / reader ----
  const openEmail = useCallback((id) => {
    setSelected(id)
    setReading(true)
    if (id === TARGET) { markDone('open'); setPulse(null) }
  }, [markDone])

  const backList = useCallback(() => setReading(false), [])
  const toggleFolders = useCallback(() => setFoldersHidden((v) => !v), [])
  const switchFolder = useCallback((f) => { setFolder(f); setReading(false) }, [])

  // ---- source window ----
  const openSource = useCallback((id) => {
    const e = EMAILS.find((x) => x.id === id)
    setSrcEmail(e)
    setSrcOpen(true)
    setCurrentHeader(null)
    setHeadersRevealed(0)
    setPulse(null)
    if (id === TARGET) markDone('source')
  }, [markDone])

  const chooseViewSource = useCallback(() => { if (selected) openSource(selected) }, [selected, openSource])

  const onSourceReveal = useCallback((h, n, total) => {
    setCurrentHeader(h); setHeadersRevealed(n); setHeadersTotal(total)
  }, [])

  // torch hovering a section (after all revealed) — update the explained header only
  const onSourceHover = useCallback((h) => {
    setCurrentHeader((c) => (h ? h : c))
  }, [])

  const onSourceAllRevealed = useCallback((email) => {
    if (email && email.id === TARGET) markDone('headers')
  }, [markDone])

  const closeSource = useCallback(() => setSrcOpen(false), [])

  // ---- analyzer ----
  const openAnalyzer = useCallback(() => { setAnalyzerOpen(true); setPulse(null) }, [])
  const closeAnalyzer = useCallback(() => setAnalyzerOpen(false), [])
  const runAnalysis = useCallback(() => { setAnalyzed(true); markDone('analyze') }, [markDone])

  // ---- "go to the right screen" helper for the task card ----
  const goToScreen = useCallback((taskId) => {
    if (taskId === 'open') { setFolder('inbox'); setReading(false); setPulse('row-' + TARGET) }
    else if (taskId === 'source') {
      if (selected !== TARGET) openEmail(TARGET)
      setPulse('kebab')
    }
    else if (taskId === 'headers') { if (!srcOpen) openSource(TARGET) }
    else if (taskId === 'analyze') { openAnalyzer() }
  }, [selected, srcOpen, openEmail, openSource, openAnalyzer])

  const target = TARGET

  return {
    // tasks / byte
    introSeen, startLab, tasks, currentTask, activeTask, activeDone, allDone, completed, advance, goBack, goToScreen,
    currentHeader, headersRevealed, headersTotal,
    // mail
    selected, reading, folder, foldersHidden, openEmail, backList, toggleFolders, switchFolder, target,
    // source
    chooseViewSource, srcOpen, srcEmail, closeSource, onSourceReveal, onSourceHover, onSourceAllRevealed, torchEnabled, canAnalyze,
    // analyzer
    analyzerOpen, analyzed, openAnalyzer, closeAnalyzer, runAnalysis,
    // guidance
    pulse,
  }
}
