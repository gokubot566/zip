// Escape a string for safe insertion into innerHTML (matches the original esc()).
export function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

// "@" + domain part of an address.
export function domainOf(a) {
  return '@' + (a.split('@')[1] || '')
}
