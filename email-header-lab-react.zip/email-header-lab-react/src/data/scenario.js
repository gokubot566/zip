// ── Scenario / content for "Introduction to Email Header Analysis" ──
// Educational framing (no incident-response / "reported email" angle). Byte is
// the guide; Priya is the trainer character. The mailbox is a normal user's.

export const TARGET = 'm2' // the sample message we analyse together

export const MAILBOX = {
  owner: 'Jordan Blake',
  email: 'jordan.blake@arclight-logistics.com',
  role: 'Marketing Coordinator, Arclight Logistics',
}

export const CHARACTERS = {
  marcus: { name: 'Marcus Chen', role: 'Service Desk Team Lead', color: '#3b82f6' },
  elena: { name: 'Elena Vasquez', role: 'Security Awareness Trainer', color: '#6366f1' },
}

export const LAB_META = {
  title: 'Introduction to Email Header Analysis',
  // Section 1 plays as a real-time conversation. Phase 1 (Byte's intro + phishing
  // primer) auto-plays with no clicking. One button then reveals phase 2 (the team
  // introducing themselves + scenario), which also auto-plays. The same button then
  // becomes "Start the lab".
  introChat: [
    { who: 'byte', text: `Hey — welcome to <b>Introduction to Email Header Analysis</b>. I'm <b>Byte</b>, your guide.` },
    { who: 'byte', text: `Quick primer first. <b>Phishing</b> is when an attacker sends an email pretending to be someone you trust — your bank, IT, a supplier — to trick you into clicking a link, opening an attachment, or handing over a password.` },
    { who: 'byte', text: `Here's the catch: the friendly <b>“From”</b> name and the message body are trivially easy to fake. What's much harder to fake is the <b>envelope</b> — the hidden <b>headers</b> every mail server stamps on as the message travels.` },
    { who: 'byte', text: `So we don't guess. We read the headers and check the evidence: where the mail <i>really</i> came from, and whether it passed <b>SPF, DKIM and DMARC</b>. Let me introduce the team you'll work with 👇` },
  ],
  meetCta: 'Meet the team',
  teamChat: [
    { who: 'marcus', text: `Welcome to the team. I run the <b>service desk</b> at Arclight Logistics. We get emails like this every day — and before we act on any of them, we read the headers. It's the first thing I teach every new analyst.` },
    { who: 'elena', text: `I'm Elena, from security awareness. I'll walk you through the method. You'll practise on a <b>sample mailbox</b> — a copy of a real employee's inbox — so it's completely safe to poke around and get it wrong.` },
    { who: 'marcus', text: `Here's the scenario: one message in <b>Jordan Blake's</b> inbox looks like a routine account notice. Your job is to read its headers and let the evidence decide whether it's genuine. We'll do it together, step by step.` },
    { who: 'byte', text: `And I'll be right here the whole way. Ready? Let's get you familiar with the inbox first.` },
  ],
  // Invitation to explore the mailbox freely before the guided part (shown after the chat).
  explore: `<b>First, get comfortable.</b> This is a live sample inbox — click around <b>Jordan Blake's mailbox</b>, open a couple of messages, and see what a normal inbox looks like. Nothing here can harm you. When you're ready, hit <b>Start</b> and we'll pick one message to analyse together.`,
  cta: 'Start the lab',
  // Shown at the END (the outcome / what you learned).
  outcomes: [
    `Open an email's raw source and read its hidden headers`,
    `Follow the Received chain to find where a message really started`,
    `Read SPF, DKIM and DMARC results and say what each means`,
    `Spot identity mismatches between From, Reply-To and Return-Path`,
    `Run any header through an analyzer for the full picture`,
  ],
}

// Gated tasks. `id` maps to completion tracked in useLab.
export const TASKS = [
  {
    id: 'open', n: 1, title: 'Open the message', area: 'Inbox', speaker: 'marcus', where: 'inbox',
    brief: `Have a look around <b>Jordan's inbox</b> first — open a few messages if you like. When you're ready, we'll practise on the one titled <b>“Your password expires in 24 hours”</b>; it looks like a routine account notice.`,
    task: `Explore the inbox, then open the “Your password expires in 24 hours” message.`,
    hint: `It's the one from “Microsoft 365 Security”. Click the row to open it.`,
    successNote: `Message open. First impressions are fine — now let's look under the hood.`,
  },
  {
    id: 'source', n: 2, title: 'View the raw source', area: 'Message', speaker: 'byte', where: 'reader',
    brief: `What you see in the reader is the <b>rendered</b> email. The real information lives in the <b>raw source</b> — the headers the mail servers stamped on.`,
    task: `Open the message's ⋮ menu (top-right) and choose <b>View source</b>.`,
    hint: `The ⋮ (three-dots) button is at the top-right of the open message.`,
    successNote: `That's the raw source. It's dark — you'll use the torch next.`,
  },
  {
    id: 'headers', n: 3, title: 'Read the headers', area: 'Raw source', speaker: 'byte', where: 'source',
    brief: `Use the <b>torch</b> to sweep the dark source. Each header lights up one at a time and I'll explain what it means — including the all-important <b>authentication</b> line.`,
    task: `Reveal every header by moving the torch down the source.`,
    hint: `Move slowly from the top. When you reach <b>Authentication-Results</b>, I'll break down SPF, DKIM and DMARC.`,
    successNote: `Nice — every header read. Try the <b>Lights</b> switch (bottom-right of the source) to light up the whole message at once. When you're done, press <b>Next step</b> to analyse it.`,
  },
  {
    id: 'analyze', n: 4, title: 'Analyze the header', area: 'Header Analyzer', speaker: 'elena', where: 'analyzer',
    brief: `Reading raw headers by eye is slow. A <b>header analyzer</b> parses the whole header block for you and lays out the evidence in one view. Here's exactly what it does 👇`,
    does: [
      { icon: '🧾', label: 'Header fields', text: `pulls out From, To, Subject and Date so you're not scanning raw text` },
      { icon: '🛡️', label: 'Authentication', text: `checks <b>SPF, DKIM and DMARC</b> and explains each pass/fail in plain language` },
      { icon: '🗺️', label: 'Relay path', text: `lists every <b>Received</b> hop (origin host → your mail server) so you can see where it really started` },
      { icon: '🔀', label: 'Identity checks', text: `compares the From domain against <b>Reply-To, Return-Path and Message-ID</b> and flags any mismatch` },
      { icon: '✅', label: 'Verdict', text: `sums it all up as a clear <b>verified / unverified</b> read` },
    ],
    task: `Open the <b>Header Analyzer</b> and run the analysis.`,
    hint: `Use “Open Header Analyzer” at the bottom of the source window, then press <b>Analyze</b>.`,
    successNote: `That's the full picture — header fields, relay path, SPF/DKIM/DMARC and identity checks, all in one view.`,
  },
]

// Detailed reference on the three authentication protocols (used in the Guide tab
// and when the Authentication-Results header is revealed).
export const AUTH_REFERENCE = {
  intro: `When a mail server receives a message it runs three checks and records the result in the <b>Authentication-Results</b> header:`,
  items: [
    {
      k: 'SPF', full: 'Sender Policy Framework',
      body: `Was this message sent by a server the domain <b>authorises</b>? Domains publish a list of allowed sending servers in DNS; the receiver checks the sending IP against it.`,
      results: `<b>pass</b> = sent by an authorised server · <b>fail</b> = not authorised · <b>softfail</b> = probably not authorised.`,
    },
    {
      k: 'DKIM', full: 'DomainKeys Identified Mail',
      body: `Was the message <b>signed</b> by the domain and <b>untampered</b> in transit? The sender adds a cryptographic signature; the receiver verifies it with the domain's public key in DNS.`,
      results: `<b>pass</b> = valid signature · <b>none</b> = not signed · <b>fail</b> = signature invalid/altered.`,
    },
    {
      k: 'DMARC', full: 'Domain-based Message Authentication, Reporting & Conformance',
      body: `Do SPF/DKIM actually line up with the <b>visible From domain</b>, and what should happen if not? The domain owner sets a policy — <code>p=none</code>, <code>quarantine</code> or <code>reject</code>.`,
      results: `<b>pass</b> = From domain is backed by an aligned, passing SPF or DKIM · <b>fail</b> = it isn't (apply the policy).`,
    },
  ],
}
