// Email dataset for the SOC lab (ported verbatim from the original single-file app).

export const EMAILS = [
  {
    id:"m1", verdict:"legit",
    fromName:"Arclight IT Helpdesk", fromAddr:"helpdesk@arclight-logistics.com",
    to:"jordan.blake@arclight-logistics.com", time:"08:12", date:"Mon, 3 Mar 2025 08:12:04 +0000",
    subject:"Scheduled maintenance — mailbox brief outage Saturday",
    preview:"Our mail platform will be updated this Saturday between 22:00 and 23:00…",
    body:`<p>Hi team,</p><p>Our mail platform will receive a scheduled update this <b>Saturday between 22:00 and 23:00 UTC</b>. During this window you may notice a brief interruption when sending or receiving.</p><p>No action is required. If you still see issues on Monday morning, log a ticket through the usual portal.</p><p class="sig">— Arclight IT Helpdesk<br>Internal Systems Team</p>`,
    checks:[
      {t:"Sender domain is our own company domain (arclight-logistics.com).", hit:false},
      {t:"Display name matches the real address.", hit:false},
      {t:"No urgency, no links asking for credentials.", hit:false}
    ],
    headers:[
      {name:"Delivered-To", val:"jordan.blake@arclight-logistics.com", flag:"ok",
       expl:"The mailbox this copy was actually delivered to. Confirms who received it."},
      {name:"Received", val:"from mx01.arclight-logistics.com (10.20.4.11)\n  by mail.arclight-logistics.com with ESMTPS\n  Mon, 03 Mar 2025 08:12:05 +0000", flag:"ok",
       expl:"The relay chain, read bottom-to-top: each server that handled the message stamps a line. Here the path stays inside Arclight's own mail infrastructure — exactly what you'd expect for internal mail.",
       note:{type:"ok", txt:"Origin is an internal, trusted host. No surprise external hops."}},
      {name:"Authentication-Results", val:"mail.arclight-logistics.com;\n  spf=pass (sender IP is authorised) smtp.mailfrom=arclight-logistics.com;\n  dkim=pass header.d=arclight-logistics.com;\n  dmarc=pass (p=reject) header.from=arclight-logistics.com", flag:"ok",
       expl:"The receiving server's verdict on three checks. SPF: was the sending server allowed to send for this domain? DKIM: is the message cryptographically signed and unaltered? DMARC: do SPF/DKIM line up with the From domain?",
       note:{type:"ok", txt:"<b>SPF pass · DKIM pass · DMARC pass</b> — all aligned to arclight-logistics.com. Strong signal the sender is who they claim."}},
      {name:"Return-Path", val:"<helpdesk@arclight-logistics.com>", flag:"ok",
       expl:"The envelope sender — where bounce/error messages go. This is the 'real' sender the servers used, separate from the visible From line.",
       note:{type:"ok", txt:"Return-Path domain matches the From domain. Consistent."}},
      {name:"From", val:"Arclight IT Helpdesk <helpdesk@arclight-logistics.com>", flag:"ok",
       expl:"What the message claims about its sender: a display name (free text, easily faked) plus the real address. Always read the part inside the angle brackets."},
      {name:"To", val:"jordan.blake@arclight-logistics.com", flag:"ok",
       expl:"The intended recipient shown to the reader."},
      {name:"Message-ID", val:"<20250303081204.9f21@arclight-logistics.com>", flag:"ok",
       expl:"A unique ID stamped by the originating mail server. Its domain normally matches the sender's domain.",
       note:{type:"ok", txt:"Message-ID domain matches the sender. Nothing odd."}},
      {name:"Subject", val:"Scheduled maintenance — mailbox brief outage Saturday", flag:"ok",
       expl:"The subject line. Informational, no pressure or lure."}
    ]
  },
  {
    id:"m2", verdict:"phish",
    fromName:"Microsoft 365 Security", fromAddr:"account-security@micros0ft-support.com",
    to:"jordan.blake@arclight-logistics.com", time:"03:47", date:"Mon, 3 Mar 2025 03:47:51 +0000",
    subject:"[Action Required] Your password expires in 24 hours",
    preview:"To keep access to your account, verify your password now…",
    body:`<p>Dear User,</p><p>Our records show your <b>Microsoft 365 password will expire in 24 hours</b>. To avoid losing access to email and files, you must verify your password immediately.</p><p><a class="btn-fake" href="#">Keep My Current Password</a></p><p>Failure to act will result in permanent account suspension.</p><p class="sig">Microsoft 365 Security Team</p>`,
    checks:[
      {t:"Sender domain is 'micros0ft-support.com' — a look-alike using a zero, not microsoft.com.", hit:true},
      {t:"Manufactured urgency and a threat of suspension.", hit:true},
      {t:"Button links away to verify a password — classic credential harvest.", hit:true}
    ],
    headers:[
      {name:"Delivered-To", val:"jordan.blake@arclight-logistics.com", flag:"ok",
       expl:"The mailbox this copy landed in."},
      {name:"Received", val:"from vps-4471.hostwind-cloud.ru (185.220.101.42)\n  by mx01.arclight-logistics.com with ESMTP\n  Mon, 03 Mar 2025 03:47:52 +0000", flag:"bad",
       expl:"Read the chain bottom-to-top to find where the message actually came from. The originating host here is a random VPS on an unrelated hosting provider — nothing to do with Microsoft.",
       note:{type:"bad", txt:"Genuine Microsoft mail originates from Microsoft's own infrastructure. A message 'from Microsoft' that starts life on an unrelated cloud VPS is a strong spoofing indicator."}},
      {name:"Authentication-Results", val:"mx01.arclight-logistics.com;\n  spf=fail (sender IP not authorised) smtp.mailfrom=micros0ft-support.com;\n  dkim=none;\n  dmarc=fail", flag:"bad",
       expl:"The receiver's checks. SPF fail = the sending server is not on the domain's authorised list. DKIM none = no valid signature. DMARC fail = the identity does not hold together.",
       note:{type:"bad", txt:"<b>SPF fail · DKIM none · DMARC fail.</b> The three authentication checks all reject this message. This is the clearest technical evidence of spoofing."}},
      {name:"Return-Path", val:"<bounce@sendmail.micros0ft-support.com>", flag:"bad",
       expl:"The envelope sender / where bounces go. This is the address the servers really used.",
       note:{type:"bad", txt:"The envelope domain is the look-alike 'micros0ft-support.com' — the impersonation is baked in at the envelope level, not just the display name."}},
      {name:"From", val:"Microsoft 365 Security <account-security@micros0ft-support.com>", flag:"bad",
       expl:"The visible sender. The display name says 'Microsoft 365 Security', but the real address is the giveaway.",
       note:{type:"bad", txt:"Look at the address inside the brackets: <b>micros0ft-support.com</b> uses a zero instead of the letter 'o', and isn't microsoft.com at all. Display names are free text — never trust them alone."}},
      {name:"Reply-To", val:"recovery@mail-verify-portal.com", flag:"bad",
       expl:"Where your reply is sent if you hit Reply — which can differ from the From address.",
       note:{type:"bad", txt:"Reply-To points to yet another unrelated domain. Attackers do this so your replies reach them, not the impersonated brand."}},
      {name:"Message-ID", val:"<a7f3c1@mail-verify-portal.com>", flag:"warn",
       expl:"Unique ID from the originating server; its domain usually matches the sender.",
       note:{type:"warn", txt:"The Message-ID domain matches neither Microsoft nor the From domain — another inconsistency in an already-failing message."}},
      {name:"Subject", val:"[Action Required] Your password expires in 24 hours", flag:"warn",
       expl:"The subject. Urgency + a deadline is a classic pressure tactic to make you skip your checks.",
       note:{type:"warn", txt:"Deadlines and 'action required' brackets are social-engineering pressure, not proof of anything — but combined with the failed auth, the intent is clear."}}
    ]
  },
  {
    id:"m3", verdict:"legit",
    fromName:"Contoso Supplies — Billing", fromAddr:"billing@contoso-supplies.com",
    to:"jordan.blake@arclight-logistics.com", time:"Fri 14:20", date:"Fri, 28 Feb 2025 14:20:33 +0000",
    subject:"Invoice #CS-40188 for February deliveries",
    preview:"Please find attached your monthly statement for February…",
    body:`<p>Hello Dana,</p><p>Attached is invoice <b>#CS-40188</b> covering February deliveries under our existing supply agreement. Payment terms are Net 30 as usual.</p><p>Any questions on line items, just reply to this email and Accounts will help.</p><p class="sig">Contoso Supplies — Billing Department</p>`,
    checks:[
      {t:"Known, established vendor you already do business with.", hit:false},
      {t:"Normal invoice, standard terms, no pressure.", hit:false},
      {t:"Reply-To stays on the vendor's own domain.", hit:false}
    ],
    headers:[
      {name:"Delivered-To", val:"jordan.blake@arclight-logistics.com", flag:"ok",
       expl:"The mailbox this copy was delivered to."},
      {name:"Received", val:"from smtp.contoso-supplies.com (203.0.113.24)\n  by mx01.arclight-logistics.com with ESMTPS\n  Fri, 28 Feb 2025 14:20:34 +0000", flag:"ok",
       expl:"The origin server. Here it's the vendor's own published mail server — consistent with the From domain.",
       note:{type:"ok", txt:"The sending host belongs to the same domain the mail claims to be from. No mismatch."}},
      {name:"Authentication-Results", val:"mx01.arclight-logistics.com;\n  spf=pass smtp.mailfrom=contoso-supplies.com;\n  dkim=pass header.d=contoso-supplies.com;\n  dmarc=pass (p=quarantine) header.from=contoso-supplies.com", flag:"ok",
       expl:"The three authentication checks, aligned to the vendor domain.",
       note:{type:"ok", txt:"<b>SPF pass · DKIM pass · DMARC pass.</b> The vendor's identity checks out cryptographically."}},
      {name:"Return-Path", val:"<billing@contoso-supplies.com>", flag:"ok",
       expl:"Envelope sender — matches the From domain here.",
       note:{type:"ok", txt:"Return-Path and From agree. Consistent."}},
      {name:"From", val:"Contoso Supplies — Billing <billing@contoso-supplies.com>", flag:"ok",
       expl:"Visible sender. Display name and real address point to the same known vendor."},
      {name:"To", val:"jordan.blake@arclight-logistics.com", flag:"ok",
       expl:"Intended recipient."},
      {name:"Message-ID", val:"<CS40188.20250228@contoso-supplies.com>", flag:"ok",
       expl:"Origin server ID; domain matches the sender.",
       note:{type:"ok", txt:"Message-ID domain matches the vendor domain."}},
      {name:"Subject", val:"Invoice #CS-40188 for February deliveries", flag:"ok",
       expl:"Routine, specific, references a real ongoing relationship. No pressure."}
    ]
  },
  {
    id:"m4", verdict:"phish",
    fromName:"Michael Torres (CEO)", fromAddr:"m.torres.ceo.office@gmail.com",
    to:"jordan.blake@arclight-logistics.com", time:"07:58", date:"Mon, 3 Mar 2025 07:58:10 +0000",
    subject:"Quick favour — need this handled discreetly",
    preview:"Dana, are you at your desk? I need a payment processed today…",
    body:`<p>Dana,</p><p>Are you at your desk? I'm in back-to-back meetings and can't take calls. I need you to process an <b>urgent vendor payment of $18,400 today</b> — it's time-sensitive and I'd rather keep it between us until it's done.</p><p>Reply here and I'll send the account details. Don't loop in anyone else yet.</p><p class="sig">Sent from my iPhone<br>Michael</p>`,
    checks:[
      {t:"Display name is our CEO, but the real address is a personal @gmail.com account.", hit:true},
      {t:"Urgency + secrecy ('keep it between us', 'don't loop in anyone').", hit:true},
      {t:"Unusual request to move money outside the normal process.", hit:true}
    ],
    headers:[
      {name:"Delivered-To", val:"jordan.blake@arclight-logistics.com", flag:"ok",
       expl:"The mailbox this landed in."},
      {name:"Received", val:"from mail-sor-f41.google.com (209.85.220.41)\n  by mx01.arclight-logistics.com with ESMTPS\n  Mon, 03 Mar 2025 07:58:11 +0000", flag:"warn",
       expl:"The origin. This genuinely came from Google's mail servers — because it really was sent from a Gmail account.",
       note:{type:"warn", txt:"The catch: a real Gmail send will pass authentication for gmail.com. The problem isn't that auth fails — it's that a company CEO is 'emailing' from an anonymous personal Gmail, not the corporate domain."}},
      {name:"Authentication-Results", val:"mx01.arclight-logistics.com;\n  spf=pass smtp.mailfrom=gmail.com;\n  dkim=pass header.d=gmail.com;\n  dmarc=pass header.from=gmail.com", flag:"warn",
       expl:"The checks pass — but read carefully what they pass FOR.",
       note:{type:"warn", txt:"<b>SPF/DKIM/DMARC all pass — for gmail.com.</b> Authentication only proves the message really is from a Gmail account. It does <b>not</b> prove the person is your CEO. Passing auth ≠ legitimate."}},
      {name:"Return-Path", val:"<m.torres.ceo.office@gmail.com>", flag:"bad",
       expl:"Envelope sender.",
       note:{type:"bad", txt:"The real sender is a personal Gmail address — not m.torres@arclight-logistics.com. This is business-email-compromise (BEC): impersonating an executive from an outside account."}},
      {name:"From", val:"Michael Torres (CEO) <m.torres.ceo.office@gmail.com>", flag:"bad",
       expl:"The display name is engineered to read as the CEO. The address tells the truth.",
       note:{type:"bad", txt:"Display name 'Michael Torres (CEO)' + a random personal Gmail = impersonation. Our CEO would send from the company domain."}},
      {name:"Reply-To", val:"m.torres.finance.now@gmail.com", flag:"bad",
       expl:"Where replies go if you respond.",
       note:{type:"bad", txt:"Reply-To is a second throwaway Gmail — set so the conversation continues straight to the attacker."}},
      {name:"Message-ID", val:"<CAF9x2b@mail.gmail.com>", flag:"ok",
       expl:"Origin ID from Google — normal for a real Gmail message.",
       note:{type:"warn", txt:"This looks like a normal Gmail Message-ID. The technical envelope is 'clean' — which is exactly why BEC slips past filters. The tell is the context, not a failed check."}},
      {name:"Subject", val:"Quick favour — need this handled discreetly", flag:"warn",
       expl:"Vague, urgent, secretive — the hallmark opener of a payment-fraud lure.",
       note:{type:"warn", txt:"'Discreet', 'urgent', 'don't loop anyone in' — pressure + isolation. Always verify money requests through a known channel (call the person directly)."}}
    ]
  },
  {
    id:"m5", verdict:"phish",
    fromName:"DocuSign", fromAddr:"no-reply@docusign.net.secure-sign-docs.com",
    to:"jordan.blake@arclight-logistics.com", time:"05:31", date:"Mon, 3 Mar 2025 05:31:19 +0000",
    subject:"You have a document to review and sign",
    preview:"A contract has been shared with you and requires your signature…",
    body:`<p>A document titled <b>"AP_Agreement_2025.pdf"</b> has been shared with you and is waiting for your signature.</p><p><a class="btn-fake" href="#">Review Document</a></p><p>This link will expire in 48 hours. Sign in with your email password to access the document.</p><p class="sig">Powered by DocuSign</p>`,
    checks:[
      {t:"'docusign.net' appears only as a sub-label of the real domain 'secure-sign-docs.com'.", hit:true},
      {t:"Asks you to sign in with your EMAIL password to view a file — brands never do this.", hit:true},
      {t:"Expiry pressure + a vague shared document you weren't expecting.", hit:true}
    ],
    headers:[
      {name:"Delivered-To", val:"jordan.blake@arclight-logistics.com", flag:"ok",
       expl:"The mailbox this copy reached."},
      {name:"Received", val:"from mailer.secure-sign-docs.com (91.203.145.7)\n  by mx01.arclight-logistics.com with ESMTP\n  Mon, 03 Mar 2025 05:31:20 +0000", flag:"bad",
       expl:"The origin host. Real DocuSign mail comes from docusign.net infrastructure.",
       note:{type:"bad", txt:"Origin server is 'secure-sign-docs.com', not DocuSign. The brand name only appears as decoration in the address."}},
      {name:"Authentication-Results", val:"mx01.arclight-logistics.com;\n  spf=softfail smtp.mailfrom=secure-sign-docs.com;\n  dkim=fail;\n  dmarc=none", flag:"bad",
       expl:"The three checks. Softfail = probably not authorised. DKIM fail = signature invalid or altered. DMARC none = no protective policy published.",
       note:{type:"bad", txt:"<b>SPF softfail · DKIM fail · DMARC none.</b> Authentication does not support this sender."}},
      {name:"Return-Path", val:"<bounce@secure-sign-docs.com>", flag:"bad",
       expl:"Envelope sender.",
       note:{type:"bad", txt:"Envelope domain is the attacker's domain — DocuSign appears nowhere in the real routing."}},
      {name:"From", val:"DocuSign <no-reply@docusign.net.secure-sign-docs.com>", flag:"bad",
       expl:"The address uses a sub-domain trick: read a domain right-to-left. The real registered domain is the LAST two labels.",
       note:{type:"bad", txt:"<b>docusign.net.secure-sign-docs.com</b> — the actual domain is <b>secure-sign-docs.com</b>. 'docusign.net' is just a sub-label the attacker added to look convincing."}},
      {name:"Message-ID", val:"<sd-88213@secure-sign-docs.com>", flag:"warn",
       expl:"Origin ID; domain matches the attacker's domain, not DocuSign.",
       note:{type:"warn", txt:"Message-ID confirms the true origin domain — the look-alike, not the brand."}},
      {name:"Subject", val:"You have a document to review and sign", flag:"warn",
       expl:"Generic lure. Real signing requests usually name the sender and document specifically.",
       note:{type:"warn", txt:"Combined with 'sign in with your email password', this is a credential-harvesting page dressed up as DocuSign."}}
    ]
  },
  {
    id:"m6", verdict:"legit",
    fromName:"Arclight People Team", fromAddr:"hr@arclight-logistics.com",
    to:"all-staff@arclight-logistics.com", time:"Sat", date:"Sat, 1 Mar 2025 09:00:00 +0000",
    subject:"March benefits open-enrolment reminder",
    preview:"Open enrolment closes on 15 March. Review your selections in the portal…",
    body:`<p>Hi everyone,</p><p>A quick reminder that <b>benefits open enrolment closes on 15 March</b>. If you're happy with your current selections, there's nothing to do — they'll roll over automatically.</p><p>To make changes, use the HR portal you normally sign in to (bookmark it; we never send sign-in links by email).</p><p class="sig">— The Arclight People Team</p>`,
    checks:[
      {t:"From our own HR on the company domain.", hit:false},
      {t:"Explicitly tells you NOT to expect sign-in links by email.", hit:false},
      {t:"No pressure beyond a normal, well-known deadline.", hit:false}
    ],
    headers:[
      {name:"Delivered-To", val:"jordan.blake@arclight-logistics.com", flag:"ok",
       expl:"Delivered to Dana as part of the all-staff list."},
      {name:"Received", val:"from mail.arclight-logistics.com (10.20.4.12)\n  by mx01.arclight-logistics.com with ESMTPS\n  Sat, 01 Mar 2025 09:00:01 +0000", flag:"ok",
       expl:"Origin is Arclight's internal mail host.",
       note:{type:"ok", txt:"Internal origin, consistent with an all-staff HR notice."}},
      {name:"Authentication-Results", val:"mx01.arclight-logistics.com;\n  spf=pass smtp.mailfrom=arclight-logistics.com;\n  dkim=pass header.d=arclight-logistics.com;\n  dmarc=pass (p=reject) header.from=arclight-logistics.com", flag:"ok",
       expl:"Authentication aligned to the company domain.",
       note:{type:"ok", txt:"<b>SPF pass · DKIM pass · DMARC pass</b> under a strict p=reject policy. Trusted internal sender."}},
      {name:"Return-Path", val:"<hr-bounces@arclight-logistics.com>", flag:"ok",
       expl:"Envelope sender on the company domain — normal for a bulk internal list.",
       note:{type:"ok", txt:"Return-Path stays on arclight-logistics.com. Consistent with the From."}},
      {name:"From", val:"Arclight People Team <hr@arclight-logistics.com>", flag:"ok",
       expl:"Company HR on the company domain."},
      {name:"Reply-To", val:"hr@arclight-logistics.com", flag:"ok",
       expl:"Replies go back to HR on the same domain.",
       note:{type:"ok", txt:"Reply-To matches the From domain — no redirection."}},
      {name:"Message-ID", val:"<hr-openenrol-0301@arclight-logistics.com>", flag:"ok",
       expl:"Origin ID on the company domain.",
       note:{type:"ok", txt:"Message-ID domain matches the sender."}},
      {name:"Subject", val:"March benefits open-enrolment reminder", flag:"ok",
       expl:"Routine HR reminder with a normal deadline."}
    ]
  }
];

// Teaching order for revealing headers in the source viewer (From first).
export const HORDER = { From:1, To:2, Subject:3, 'Reply-To':4, 'Return-Path':5, Received:6, 'Authentication-Results':7, 'Message-ID':8, 'Delivered-To':9 };

// The guided / flagged suspicious message.
export const FLAGGED = 'm2';
