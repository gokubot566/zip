// Character portraits (illustrated) reused from the shared course cast, so the
// mentors look consistent across labs. Imported so Vite fingerprints + bundles.
import marcusPhoto from '../assets/cast/character-4.png'
import elenaPhoto from '../assets/cast/character-5.png'

export const CAST_PHOTOS = {
  marcus: marcusPhoto,
  elena: elenaPhoto,
}
