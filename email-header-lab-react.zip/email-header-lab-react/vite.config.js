import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// base: './' emits relative asset paths so the built app works from any path
// (file://, a sub-folder, or behind nginx) — handy for isolated lab hosting.
export default defineConfig({
  base: './',
  plugins: [react()],
})
