# Introduction to Email Header Analysis — Interactive Lab (React 18 + Vite)

A guided, **task-gated** training lab. Byte (the lab guide) walks the learner through
reading an email's headers on a sample mailbox, then analysing them with a built-in
vendor-neutral header analyzer. Educational framing — no incident-response / "reported email"
angle.

## Stack
- React 18 + Vite 5, plain global CSS (no framework)
- No runtime dependencies beyond React

## Run it
```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build → dist/
npm run preview  # preview the build
```

## The flow (4 gated tasks)
Byte guides one step at a time; **the next step stays locked until the current one is
actually done** in the UI (progress pips show where you are):

1. **Open the message** — open the sample email in Jordan Blake's inbox.
2. **View the raw source** — ⋮ → View source.
3. **Read the headers** — sweep the torch to reveal each header; Byte explains every one,
   and gives a detailed **SPF / DKIM / DMARC** breakdown when the Authentication-Results
   line appears.
4. **Analyze the header** — open the **Header Analyzer** and run it (relay hops,
   authentication results, and identity-header mismatches — a generic, vendor-neutral analyzer).

A **Guide** tab in Byte holds a standing reference on headers and the three
authentication protocols.

## Project structure
```
src/
├── App.jsx                  # composes mail client + source window + analyzer + Byte
├── index.css                # full stylesheet (lab + Byte task panel + analyzer)
├── data/
│   ├── emails.js            # sample mailbox dataset
│   └── scenario.js          # characters, gated TASKS, lab intro copy, SPF/DKIM/DMARC reference
├── hooks/
│   └── useLab.js            # task-gated controller (completion detection + guidance)
└── components/
    ├── TopBar / FolderRail / MailList / Reader   # the mail client (neutral, no "reported" tags)
    ├── SourceWindow.jsx     # torch "view source" (reveal headers; Lights toggle; analyzer launch)
    ├── Analyzer.jsx         # generic email header analyzer (vendor-neutral)
    ├── BytePanel.jsx        # task-gated Byte: intro, pips, Current step / Guide, locked Next, summary
    └── ByteAvatar.jsx       # Byte's SVG robot mascot
```

## Notes
- Byte's palette (indigo/cyan) is scoped to `.byte-root` so it never overrides the
  torch's amber accent.
- Byte is a draggable, minimisable window (robot launcher when closed).
- The sample message's headers drive both the torch teaching and the analyzer, so the
  analysis is real rather than hard-coded.

## Deploy with Docker (nginx)

Production image is a multi-stage build: Node compiles the app, then nginx serves the
static `dist/`. Nothing but the built files ship in the final image.

**One command (compose):**
```bash
docker compose up -d --build
# → http://localhost:7333   (change the port in docker-compose.yml)
```

**Or plain Docker:**
```bash
docker build -t email-header-lab .
docker run -d --name email-header-lab --restart always -p 7333:80 email-header-lab
# → http://localhost:7333
```

Then put it behind your normal domain / reverse proxy. Other machines reach it at
`http://<server-ip>:7333`. The app is fully client-side (no backend, no data stored),
and all assets are bundled locally — so it also works on isolated/air-gapped networks.
