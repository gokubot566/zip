import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, CheckCircle, ArrowLeft, ArrowRight, Award } from 'lucide-react';
import Header from './components/Header.jsx';
import Sidebar from './components/Sidebar.jsx';
import ModuleContent from './components/ModuleContent.jsx';
import ByteAssistant from './components/ByteAssistant.jsx';
import { ALL_MODULES } from './modules/moduleData.js';

const STORAGE_KEY = 'si_onboarding_v3';

function loadState() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
  } catch { return {}; }
}

function saveState(state) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {}
}

// ── Module hero header ────────────────────────────────────────────────────────
function ModuleHero({ module, isComplete }) {
  const c = module.color;
  const rgb = hexRgb(c);
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      style={{
        position: 'relative', borderRadius: 18, overflow: 'hidden', marginBottom: 24,
        background: `linear-gradient(135deg, rgba(${rgb},0.1) 0%, rgba(0,0,0,0) 60%), rgba(255,255,255,0.02)`,
        border: `1px solid rgba(${rgb},0.22)`, padding: '32px 36px',
      }}
    >
      {/* Glow */}
      <div style={{ position: 'absolute', top: -80, right: -80, width: 280, height: 280, borderRadius: '50%', background: `radial-gradient(circle,rgba(${rgb},0.15) 0%,transparent 70%)`, pointerEvents: 'none' }} />
      {/* Grid */}
      <div style={{ position: 'absolute', inset: 0, opacity: 0.03, backgroundImage: `linear-gradient(rgba(${rgb},1) 1px,transparent 1px),linear-gradient(90deg,rgba(${rgb},1) 1px,transparent 1px)`, backgroundSize: '40px 40px', pointerEvents: 'none' }} />
      {/* Big icon bg */}
      <div style={{ position: 'absolute', right: 36, top: '50%', transform: 'translateY(-50%)', fontSize: 72, opacity: 0.07, pointerEvents: 'none' }}>{module.icon}</div>

      <div style={{ position: 'relative' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
          <div style={{ padding: '3px 9px', borderRadius: 16, background: `rgba(${rgb},0.12)`, border: `1px solid rgba(${rgb},0.25)`, fontFamily: "'JetBrains Mono', monospace", fontSize: 9.5, color: c, letterSpacing: '0.1em', fontWeight: 700 }}>MODULE {String(module.id).padStart(2,'0')}</div>
          <div style={{ padding: '3px 9px', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', fontFamily: "'JetBrains Mono', monospace", fontSize: 9.5, color: '#475569', letterSpacing: '0.06em' }}>~{module.duration}</div>
          {isComplete && <div style={{ padding: '3px 9px', borderRadius: 16, background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.25)', fontFamily: "'JetBrains Mono', monospace", fontSize: 9.5, color: '#10b981', letterSpacing: '0.06em', display: 'flex', alignItems: 'center', gap: 4 }}><CheckCircle size={10} />COMPLETE</div>}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
          <span style={{ fontSize: 28 }}>{module.icon}</span>
          <h1 style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 26, color: '#f1f5f9', lineHeight: 1.2, background: 'linear-gradient(135deg,#f1f5f9 0%,#94a3b8 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>{module.title}</h1>
        </div>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13.5, color: '#475569', marginBottom: 20 }}>{module.subtitle}</p>

        {/* Key points */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
          {module.keyPoints.map((kp, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 7 }}>
              <div style={{ width: 5, height: 5, borderRadius: '50%', background: c, marginTop: 6, flexShrink: 0 }} />
              <span style={{ fontSize: 12.5, color: '#64748b', fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.5 }}>{kp}</span>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

// ── Module complete banner ────────────────────────────────────────────────────
function CompleteBanner({ module, onNext, hasNext }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
      style={{
        padding: '24px 28px', borderRadius: 16, marginBottom: 24,
        background: 'rgba(16,185,129,0.07)', border: '1px solid rgba(16,185,129,0.22)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{ fontSize: 32 }}>✅</div>
        <div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 16, color: '#10b981', marginBottom: 3 }}>Module {module.id} Complete!</div>
          <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13, color: '#64748b' }}>Your progress has been saved. {hasNext ? 'Continue to the next module when you are ready.' : 'You have completed all 11 modules!'}</div>
        </div>
      </div>
      {hasNext && (
        <button onClick={onNext} style={{ padding: '10px 20px', borderRadius: 10, background: 'linear-gradient(135deg,#059669,#10b981)', border: 'none', color: '#fff', fontFamily: "'Space Grotesk', sans-serif", fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 7, flexShrink: 0, boxShadow: '0 0 20px rgba(16,185,129,0.25)' }}>
          Next Module <ArrowRight size={15} />
        </button>
      )}
    </motion.div>
  );
}

// ── Complete module CTA ───────────────────────────────────────────────────────
function ModuleCTA({ module, onComplete, completed }) {
  const rgb = hexRgb(module.color);
  if (completed) return null;
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2, duration: 0.4 }}
      style={{
        padding: '22px 26px', borderRadius: 14, marginTop: 24,
        background: `rgba(${rgb},0.06)`, border: `1px solid rgba(${rgb},0.18)`,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16,
      }}
    >
      <div>
        <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 14.5, color: '#e2e8f0', marginBottom: 4 }}>Ready to mark Module {module.id} as complete?</div>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 12.5, color: '#475569', margin: 0 }}>Work through the content above, then click to save your progress and unlock the next module.</p>
      </div>
      <button onClick={onComplete} style={{ padding: '11px 22px', borderRadius: 10, background: `linear-gradient(135deg,${module.color},rgba(${rgb},0.8))`, border: 'none', color: '#fff', fontFamily: "'Space Grotesk', sans-serif", fontSize: 13, fontWeight: 700, cursor: 'pointer', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 7, boxShadow: `0 0 20px rgba(${rgb},0.25)` }}>
        ✓ Mark Complete <ChevronRight size={14} />
      </button>
    </motion.div>
  );
}

// ── All complete screen ───────────────────────────────────────────────────────
function AllCompleteScreen({ onReset }) {
  return (
    <div style={{ maxWidth: 700, margin: '0 auto', padding: '48px 28px', textAlign: 'center' }}>
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }}
        style={{ background: 'linear-gradient(135deg,rgba(16,185,129,0.1),rgba(16,185,129,0.04)), rgba(255,255,255,0.02)', border: '1px solid rgba(16,185,129,0.25)', borderRadius: 24, padding: '52px 44px' }}>
        <div style={{ fontSize: 64, marginBottom: 18 }}>🏆</div>
        <h1 style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 30, color: '#10b981', marginBottom: 12 }}>Training Complete!</h1>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 15, color: '#64748b', lineHeight: 1.75, maxWidth: 480, margin: '0 auto 28px' }}>You have completed all 11 modules of the Security Impossible Security & Governance Onboarding Program. Your commitment to these obligations starts now.</p>
        <div style={{ background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(16,185,129,0.18)', borderRadius: 12, padding: '22px 26px', textAlign: 'left', maxWidth: 440, margin: '0 auto 24px', fontFamily: "'JetBrains Mono', monospace", fontSize: 11, lineHeight: 2.2, color: '#475569' }}>
          <div><span style={{ color: '#334155' }}>PROGRAM:</span> Security & Governance Onboarding</div>
          <div><span style={{ color: '#334155' }}>MODULES:</span> 11 / 11 Complete</div>
          <div><span style={{ color: '#334155' }}>DATE:</span> {new Date().toLocaleDateString('en-AU', { day: 'numeric', month: 'long', year: 'numeric' })}</div>
          <div><span style={{ color: '#334155' }}>STATUS:</span> <span style={{ color: '#10b981' }}>✓ COMMITTED</span></div>
        </div>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 12.5, color: '#334155' }}>Forward this screen to your manager or HR contact to finalise your onboarding.</p>
      </motion.div>
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentId, setCurrentId] = useState(1);
  const [state, setState] = useState(loadState);

  useEffect(() => { saveState(state); }, [state]);

  const module = ALL_MODULES.find(m => m.id === currentId);
  const completedModules = Object.keys(state.completed || {}).map(Number).filter(id => state.completed[id]);
  const isComplete = !!(state.completed?.[currentId]);
  const modState = state.modules?.[currentId] || {};
  const allDone = completedModules.length === ALL_MODULES.length;

  // Overall progress 0-100
  const progress = Math.round((completedModules.length / ALL_MODULES.length) * 100);

  function setModState(key, val) {
    setState(s => ({ ...s, modules: { ...(s.modules || {}), [currentId]: { ...(s.modules?.[currentId] || {}), [key]: val } } }));
  }

  function completeModule(id) {
    setState(s => ({ ...s, completed: { ...(s.completed || {}), [id]: true } }));
  }

  function goToModule(id) {
    setCurrentId(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  const nextModule = ALL_MODULES.find(m => m.id === currentId + 1);
  const prevModule = ALL_MODULES.find(m => m.id === currentId - 1);

  return (
    <div style={{ minHeight: '100vh', background: '#060a12', fontFamily: "'Space Grotesk', sans-serif", overflowX: 'hidden' }}>
      {/* Background */}
      <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0, backgroundImage: 'linear-gradient(rgba(30,55,100,0.055) 1px,transparent 1px),linear-gradient(90deg,rgba(30,55,100,0.055) 1px,transparent 1px)', backgroundSize: '60px 60px' }} />
      <div style={{ position: 'fixed', top: '8%', right: '12%', width: 400, height: 400, borderRadius: '50%', background: 'radial-gradient(circle,rgba(26,86,219,0.07) 0%,transparent 70%)', pointerEvents: 'none', zIndex: 0 }} />
      <div style={{ position: 'fixed', bottom: '18%', left: '4%', width: 280, height: 280, borderRadius: '50%', background: `radial-gradient(circle,rgba(${hexRgb(module?.color || '#1a56db')},0.06) 0%,transparent 70%)`, pointerEvents: 'none', zIndex: 0, transition: 'background 0.5s' }} />

      <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} progress={progress} />

      <Sidebar
        open={sidebarOpen}
        currentModuleId={currentId}
        completedModules={completedModules}
        onNavigate={goToModule}
      />

      <motion.main
        animate={{ paddingLeft: sidebarOpen ? 280 : 0 }}
        transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
        style={{ paddingTop: 60, minHeight: '100vh', position: 'relative', zIndex: 1 }}
      >
        {/* Section tabs */}
        <div style={{ position: 'sticky', top: 60, zIndex: 100, background: 'rgba(6,10,18,0.92)', backdropFilter: 'blur(16px)', borderBottom: '1px solid rgba(255,255,255,0.05)', padding: '0 30px', display: 'flex', alignItems: 'center', gap: 0 }}>
          {ALL_MODULES.map((m, i) => {
            const done = !!(state.completed?.[m.id]);
            const active = m.id === currentId;
            const unlocked = m.id === 1 || done || !!(state.completed?.[m.id - 1]);
            return (
              <button
                key={m.id}
                onClick={() => unlocked && goToModule(m.id)}
                style={{
                  padding: '11px 2px', marginRight: 18, borderBottom: `2px solid ${active ? m.color : 'transparent'}`,
                  background: 'transparent', border: 'none', borderBottom: `2px solid ${active ? m.color : 'transparent'}`,
                  color: active ? '#e2e8f0' : done ? '#3d4a5c' : unlocked ? '#2d3a4d' : '#1a2333',
                  fontSize: 11, fontFamily: "'JetBrains Mono', monospace", fontWeight: 700,
                  cursor: unlocked ? 'pointer' : 'not-allowed', transition: 'all 0.15s',
                  display: 'flex', alignItems: 'center', gap: 4, paddingBottom: 10, paddingTop: 11,
                }}
              >
                {done ? <CheckCircle size={9} color="#10b981" /> : null}
                {String(m.id).padStart(2,'0')}
              </button>
            );
          })}
          <div style={{ flex: 1 }} />
          <div style={{ fontSize: 10, color: '#1e293b', fontFamily: "'JetBrains Mono', monospace' " }}>
            {completedModules.length}/{ALL_MODULES.length} complete
          </div>
        </div>

        {/* Page content */}
        <div style={{ maxWidth: 860, margin: '0 auto', padding: '32px 28px 56px' }}>
          <AnimatePresence mode="wait">
            {allDone && currentId > ALL_MODULES.length ? (
              <AllCompleteScreen key="done" />
            ) : (
              <motion.div key={currentId} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.35 }}>
                {/* Module hero */}
                <ModuleHero module={module} isComplete={isComplete} />

                {/* Complete banner */}
                {isComplete && (
                  <CompleteBanner
                    module={module}
                    hasNext={!!nextModule}
                    onNext={() => nextModule && goToModule(nextModule.id)}
                  />
                )}

                {/* Module body */}
                <ModuleContent
                  module={module}
                  scenarioDone={modState.scenarioDone || false}
                  quizDone={modState.quizDone || false}
                  onScenarioDone={() => setModState('scenarioDone', true)}
                  onQuizDone={() => setModState('quizDone', true)}
                />

                {/* Complete CTA */}
                <ModuleCTA
                  module={module}
                  completed={isComplete}
                  onComplete={() => {
                    completeModule(currentId);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />

                {/* Bottom nav */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 32, paddingTop: 24, borderTop: '1px solid rgba(255,255,255,0.05)' }}>
                  <div>
                    {prevModule && (
                      <button onClick={() => goToModule(prevModule.id)} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 18px', borderRadius: 9, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', color: '#64748b', fontSize: 13, fontFamily: "'Space Grotesk', sans-serif", cursor: 'pointer' }}>
                        <ArrowLeft size={14} /> Module {prevModule.id}
                      </button>
                    )}
                  </div>
                  <div style={{ fontSize: 11, color: '#1e293b', fontFamily: "'JetBrains Mono', monospace", textAlign: 'center' }}>
                    {module.id} of {ALL_MODULES.length}
                  </div>
                  <div>
                    {nextModule && (isComplete || allDone) && (
                      <button onClick={() => goToModule(nextModule.id)} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 18px', borderRadius: 9, background: `rgba(${hexRgb(nextModule.color)},0.1)`, border: `1px solid rgba(${hexRgb(nextModule.color)},0.25)`, color: nextModule.color, fontSize: 13, fontFamily: "'Space Grotesk', sans-serif", fontWeight: 600, cursor: 'pointer' }}>
                        Module {nextModule.id} <ArrowRight size={14} />
                      </button>
                    )}
                  </div>
                </div>

                {/* All done screen at bottom */}
                {allDone && (
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.4 }}
                    style={{ marginTop: 32, padding: '24px 28px', borderRadius: 16, background: 'linear-gradient(135deg,rgba(16,185,129,0.08),rgba(16,185,129,0.03))', border: '1px solid rgba(16,185,129,0.2)', textAlign: 'center' }}>
                    <div style={{ fontSize: 32, marginBottom: 8 }}>🏆</div>
                    <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 18, color: '#10b981', marginBottom: 6 }}>All 11 Modules Complete!</div>
                    <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13.5, color: '#64748b', marginBottom: 16 }}>You have completed the Security Impossible onboarding program. Forward this to your manager to finalise onboarding.</div>
                    <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#334155', lineHeight: 2 }}>
                      <span style={{ color: '#1e293b' }}>Completed: </span>{new Date().toLocaleDateString('en-AU', { day: 'numeric', month: 'long', year: 'numeric' })}
                    </div>
                  </motion.div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.main>

      <ByteAssistant currentSection={`module-${currentId}`} />
    </div>
  );
}

function hexRgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex || '#1a56db');
  return r ? `${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}` : '26,86,219';
}
