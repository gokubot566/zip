import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, X, ChevronRight, Lightbulb, Shield, AlertCircle, BookOpen, Send } from 'lucide-react';

const TIPS = [
  { icon: '🛡️', type: 'hint', text: "Security at SI isn't just a policy — it's how we earn every client engagement. Your first obligation starts now, before you touch a single client file." },
  { icon: '🎯', type: 'hint', text: "Remember: we're a high-value target. Attackers don't just want our data — they want access to our clients' data through us. This is called a supply chain attack." },
  { icon: '🔐', type: 'reminder', text: "Confidentiality begins on Day 1. There's no grace period. Even casual mentions of client names or sectors in social settings can constitute a breach." },
  { icon: '📱', type: 'tip', text: "The Friday evening scenario is real. Friends will ask about your work. Practice a natural, professional way to deflect: 'It's all confidential, but I love the work!'" },
  { icon: '⚠️', type: 'warning', text: "Most breaches aren't dramatic. Leaving a screen unlocked, forwarding a file to personal email, or sharing a client name in a café — these are the real risks." },
  { icon: '🧠', type: 'tip', text: "For the quiz: think about WHY each answer is correct, not just what the answer is. Understanding the principle means you'll make the right call in novel situations." },
  { icon: '🏆', type: 'hint', text: "Great work getting this far! Security culture is built by people who care — and the fact you're reading this carefully already shows the right attitude." },
];

const QUICK_TIPS = [
  "Why are we a target?",
  "What counts as confidential?",
  "What if I'm unsure?",
  "How do I handle scenarios?",
];

const ANSWERS = {
  "Why are we a target?": "Security consulting firms are prime targets because we hold detailed knowledge of our clients' vulnerabilities. A single breach of our systems could expose multiple client organisations simultaneously — that's exponentially more valuable than attacking one company.",
  "What counts as confidential?": "Almost everything client-related: their identity, the fact we work with them, engagement findings, system details, internal processes, and personnel. Also firm data: methodologies, pricing, proposals, financial data, and personnel information.",
  "What if I'm unsure?": "Always ask before acting. The cost of asking is zero. The cost of assuming and getting it wrong can be catastrophic. Contact the security team at security@securityimpossible.com.au.",
  "How do I handle scenarios?": "Read carefully, choose the most professionally cautious option, and review the explanation even if you get it right. The reasoning matters as much as the answer.",
};

export default function ByteAssistant({ currentSection }) {
  const [open, setOpen] = useState(false);
  const [tipIdx, setTipIdx] = useState(0);
  const [inputVal, setInputVal] = useState('');
  const [messages, setMessages] = useState([
    { from: 'byte', text: "Hi! I'm Byte 👋 Your AI guide for this module. I can help explain concepts, give hints, and remind you of key obligations. What would you like to know?" }
  ]);
  const [typing, setTyping] = useState(false);
  const [pulse, setPulse] = useState(true);
  const msgEndRef = useRef(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setPulse(p => !p);
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    msgEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  function sendMessage(text) {
    const q = text || inputVal.trim();
    if (!q) return;
    setInputVal('');
    setMessages(prev => [...prev, { from: 'user', text: q }]);
    setTyping(true);
    setTimeout(() => {
      const answer = ANSWERS[q] || findAnswer(q);
      setMessages(prev => [...prev, { from: 'byte', text: answer }]);
      setTyping(false);
    }, 900);
  }

  function findAnswer(q) {
    const lower = q.toLowerCase();
    if (lower.includes('confiden')) return ANSWERS["What counts as confidential?"];
    if (lower.includes('target') || lower.includes('attack')) return ANSWERS["Why are we a target?"];
    if (lower.includes('unsure') || lower.includes('sure') || lower.includes('help')) return ANSWERS["What if I'm unsure?"];
    if (lower.includes('scenario')) return ANSWERS["How do I handle scenarios?"];
    if (lower.includes('day 1') || lower.includes('start') || lower.includes('begin')) return "Your obligations begin immediately on Day 1. There's no grace period. Even before completing this training, you're bound by your employment contract's confidentiality provisions.";
    if (lower.includes('breach') || lower.includes('incident')) return "If you suspect a breach or incident, report it immediately to security@securityimpossible.com.au. Don't try to investigate or fix it yourself. Speed of reporting is the most important factor in limiting damage.";
    return "That's a great question for your manager or the security team. The safest approach when uncertain is always to ask before acting. Reach out to security@securityimpossible.com.au for guidance on your specific situation.";
  }

  const currentTip = TIPS[tipIdx % TIPS.length];

  return (
    <>
      {/* Floating button */}
      <motion.button
        onClick={() => setOpen(!open)}
        animate={{ scale: open ? 1 : pulse ? 1.05 : 1 }}
        transition={{ duration: 0.5, ease: 'easeInOut' }}
        style={{
          position: 'fixed', bottom: 28, right: 28, zIndex: 1000,
          width: 58, height: 58, borderRadius: '50%',
          background: open ? 'linear-gradient(135deg,#1e293b,#0f172a)' : 'linear-gradient(135deg,#1a56db,#0ea5e9)',
          border: open ? '1px solid rgba(255,255,255,0.1)' : 'none',
          cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: open
            ? '0 4px 20px rgba(0,0,0,0.5)'
            : '0 0 0 0 rgba(14,165,233,0.4), 0 8px 32px rgba(26,86,219,0.5)',
          animation: !open ? 'byteRipple 2s infinite' : 'none',
        }}
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.2 }}>
              <X size={22} color="#94a3b8" />
            </motion.div>
          ) : (
            <motion.div key="bot" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }} transition={{ duration: 0.2 }}>
              <Bot size={24} color="#fff" />
            </motion.div>
          )}
        </AnimatePresence>
        {/* Unread dot */}
        {!open && (
          <div style={{
            position: 'absolute', top: 2, right: 2, width: 14, height: 14, borderRadius: '50%',
            background: '#10b981', border: '2px solid #060a12',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 8, color: '#fff', fontWeight: 800,
          }}>!</div>
        )}
      </motion.button>

      {/* Panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95, originX: 1, originY: 1 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            style={{
              position: 'fixed', bottom: 100, right: 28, zIndex: 999,
              width: 380, borderRadius: 20,
              background: 'rgba(8,13,23,0.97)',
              backdropFilter: 'blur(24px)',
              border: '1px solid rgba(99,179,237,0.18)',
              boxShadow: '0 24px 64px rgba(0,0,0,0.8), 0 0 0 1px rgba(99,179,237,0.06)',
              overflow: 'hidden',
              display: 'flex', flexDirection: 'column', maxHeight: 560,
            }}
          >
            {/* Header */}
            <div style={{
              padding: '16px 18px',
              background: 'linear-gradient(90deg,rgba(26,86,219,0.15),rgba(14,165,233,0.08))',
              borderBottom: '1px solid rgba(255,255,255,0.06)',
              display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0,
            }}>
              <div style={{
                width: 36, height: 36, borderRadius: 10,
                background: 'linear-gradient(135deg,#1a56db,#0ea5e9)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                boxShadow: '0 0 16px rgba(14,165,233,0.3)',
              }}>
                <Bot size={18} color="#fff" />
              </div>
              <div>
                <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 14, color: '#e2e8f0' }}>Byte</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                  <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#10b981', boxShadow: '0 0 6px #10b981' }} />
                  <span style={{ fontSize: 10, color: '#10b981', fontFamily: "'JetBrains Mono', monospace" }}>Online — Module 1 Guide</span>
                </div>
              </div>
            </div>

            {/* Current tip */}
            <div style={{
              padding: '10px 14px', margin: '10px 14px 0',
              borderRadius: 10, flexShrink: 0,
              background: 'rgba(14,165,233,0.06)', border: '1px solid rgba(14,165,233,0.14)',
              display: 'flex', alignItems: 'flex-start', gap: 8,
            }}>
              <span style={{ fontSize: 14, flexShrink: 0 }}>{currentTip.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 10, fontFamily: "'JetBrains Mono', monospace", color: '#0ea5e9', marginBottom: 2, letterSpacing: '0.06em' }}>
                  {currentTip.type.toUpperCase()}
                </div>
                <div style={{ fontSize: 12, color: '#64748b', fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.5 }}>{currentTip.text}</div>
              </div>
              <button
                onClick={() => setTipIdx(t => t + 1)}
                style={{ background: 'transparent', border: 'none', color: '#334155', cursor: 'pointer', flexShrink: 0 }}
              >
                <ChevronRight size={14} />
              </button>
            </div>

            {/* Quick actions */}
            <div style={{ padding: '8px 14px', flexShrink: 0 }}>
              <div style={{ fontSize: 10, color: '#1e293b', fontFamily: "'JetBrains Mono', monospace", marginBottom: 6, letterSpacing: '0.06em' }}>QUICK HELP</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {QUICK_TIPS.map((tip, i) => (
                  <button
                    key={i}
                    onClick={() => sendMessage(tip)}
                    style={{
                      padding: '5px 10px', borderRadius: 16,
                      background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)',
                      color: '#64748b', fontSize: 11, fontFamily: "'Space Grotesk', sans-serif",
                      cursor: 'pointer', transition: 'all 0.15s',
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background = 'rgba(14,165,233,0.08)'; e.currentTarget.style.color = '#7dd3fc'; e.currentTarget.style.borderColor = 'rgba(14,165,233,0.2)'; }}
                    onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; e.currentTarget.style.color = '#64748b'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.07)'; }}
                  >
                    {tip}
                  </button>
                ))}
              </div>
            </div>

            {/* Messages */}
            <div style={{
              flex: 1, overflowY: 'auto', padding: '8px 14px',
              display: 'flex', flexDirection: 'column', gap: 8,
              scrollbarWidth: 'thin', scrollbarColor: '#1e293b transparent',
            }}>
              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25 }}
                  style={{ display: 'flex', justifyContent: msg.from === 'user' ? 'flex-end' : 'flex-start' }}
                >
                  <div style={{
                    maxWidth: '85%', padding: '9px 12px', borderRadius: msg.from === 'user' ? '12px 4px 12px 12px' : '4px 12px 12px 12px',
                    background: msg.from === 'user' ? 'rgba(26,86,219,0.2)' : 'rgba(255,255,255,0.05)',
                    border: msg.from === 'user' ? '1px solid rgba(26,86,219,0.3)' : '1px solid rgba(255,255,255,0.07)',
                    fontSize: 12.5, color: msg.from === 'user' ? '#93c5fd' : '#94a3b8',
                    fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.6,
                  }}>
                    {msg.text}
                  </div>
                </motion.div>
              ))}
              {typing && (
                <div style={{ display: 'flex', gap: 4, padding: '10px 12px', background: 'rgba(255,255,255,0.04)', borderRadius: '4px 12px 12px 12px', width: 56 }}>
                  {[0, 1, 2].map(i => (
                    <motion.div key={i} animate={{ y: [0, -4, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: i * 0.12 }}
                      style={{ width: 6, height: 6, borderRadius: '50%', background: '#334155' }} />
                  ))}
                </div>
              )}
              <div ref={msgEndRef} />
            </div>

            {/* Input */}
            <div style={{
              padding: '10px 14px 14px', flexShrink: 0,
              borderTop: '1px solid rgba(255,255,255,0.05)',
              display: 'flex', gap: 8,
            }}>
              <input
                value={inputVal}
                onChange={e => setInputVal(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendMessage()}
                placeholder="Ask Byte anything..."
                style={{
                  flex: 1, padding: '9px 12px', borderRadius: 10,
                  background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)',
                  color: '#e2e8f0', fontSize: 12.5, fontFamily: "'Space Grotesk', sans-serif",
                  outline: 'none',
                }}
              />
              <button
                onClick={() => sendMessage()}
                disabled={!inputVal.trim()}
                style={{
                  width: 36, height: 36, borderRadius: 9,
                  background: inputVal.trim() ? 'linear-gradient(135deg,#1a56db,#0ea5e9)' : 'rgba(255,255,255,0.04)',
                  border: 'none', cursor: inputVal.trim() ? 'pointer' : 'default',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0,
                }}
              >
                <Send size={14} color={inputVal.trim() ? '#fff' : '#334155'} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        @keyframes byteRipple {
          0% { box-shadow: 0 0 0 0 rgba(14,165,233,0.4), 0 8px 32px rgba(26,86,219,0.5); }
          70% { box-shadow: 0 0 0 12px rgba(14,165,233,0), 0 8px 32px rgba(26,86,219,0.5); }
          100% { box-shadow: 0 0 0 0 rgba(14,165,233,0), 0 8px 32px rgba(26,86,219,0.5); }
        }
      `}</style>
    </>
  );
}
