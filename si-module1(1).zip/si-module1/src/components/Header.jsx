import { motion } from 'framer-motion';
import { Shield, Bell, User, ChevronRight, Menu, X } from 'lucide-react';

export default function Header({ sidebarOpen, setSidebarOpen, progress }) {
  return (
    <motion.header
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 200,
        background: 'rgba(6,10,18,0.92)',
        backdropFilter: 'blur(20px)',
        borderBottom: '1px solid rgba(99,179,237,0.12)',
        height: 60,
        display: 'flex', alignItems: 'center',
        padding: '0 20px', gap: 16,
      }}
    >
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        style={{
          width: 36, height: 36, borderRadius: 8,
          background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)',
          color: '#94a3b8', display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', flexShrink: 0, transition: 'all 0.2s',
        }}
        onMouseEnter={e => { e.currentTarget.style.background = 'rgba(99,179,237,0.12)'; e.currentTarget.style.color = '#63b3ed'; }}
        onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; e.currentTarget.style.color = '#94a3b8'; }}
      >
        {sidebarOpen ? <X size={16} /> : <Menu size={16} />}
      </button>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
        <div style={{
          width: 32, height: 32, borderRadius: 8,
          background: 'linear-gradient(135deg, #1a56db 0%, #0ea5e9 100%)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 0 20px rgba(14,165,233,0.35)',
        }}>
          <Shield size={17} color="#fff" />
        </div>
        <div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 13, color: '#e2e8f0', lineHeight: 1 }}>Security Impossible</div>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, color: '#475569', letterSpacing: '0.08em', marginTop: 1 }}>ONBOARDING PORTAL</div>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginLeft: 8 }}>
        <div style={{ width: 1, height: 20, background: 'rgba(255,255,255,0.08)' }} />
        <span style={{ fontSize: 11, color: '#475569', fontFamily: "'JetBrains Mono', monospace" }}>Onboarding</span>
        <ChevronRight size={12} color="#334155" />
        <span style={{ fontSize: 11, color: '#63b3ed', fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>Module 1</span>
      </div>

      <div style={{ flex: 1 }} />

      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '5px 12px',
        background: 'rgba(99,179,237,0.07)', border: '1px solid rgba(99,179,237,0.18)',
        borderRadius: 20,
      }}>
        <div style={{ fontSize: 11, color: '#64748b', fontFamily: "'JetBrains Mono', monospace" }}>Progress</div>
        <div style={{ width: 56, height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden' }}>
          <motion.div
            initial={{ width: 0 }} animate={{ width: `${progress}%` }}
            transition={{ duration: 1, delay: 0.5, ease: 'easeOut' }}
            style={{ height: '100%', background: 'linear-gradient(90deg,#1a56db,#0ea5e9)', borderRadius: 2 }}
          />
        </div>
        <div style={{ fontSize: 11, color: '#0ea5e9', fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, minWidth: 28 }}>{progress}%</div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <button style={{
          width: 32, height: 32, borderRadius: 8, background: 'rgba(255,255,255,0.04)',
          border: '1px solid rgba(255,255,255,0.06)', color: '#64748b',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}>
          <Bell size={14} />
        </button>
        <div style={{
          width: 32, height: 32, borderRadius: 8,
          background: 'linear-gradient(135deg, #1e3a5f, #1a56db)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}>
          <User size={14} color="#93c5fd" />
        </div>
      </div>
    </motion.header>
  );
}
