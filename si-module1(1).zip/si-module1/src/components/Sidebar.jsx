import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, Lock, Clock, ChevronRight, Shield, Play } from 'lucide-react';
import { ALL_MODULES } from '../modules/moduleData.js';

export default function Sidebar({ open, currentModuleId, completedModules, onNavigate }) {
  const completedSet = new Set(completedModules || []);
  const totalDone = completedSet.size;

  return (
    <AnimatePresence>
      {open && (
        <motion.aside
          initial={{ x: -280, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -280, opacity: 0 }}
          transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
          style={{
            position: 'fixed', top: 60, left: 0, bottom: 0, zIndex: 150,
            width: 280, overflowY: 'auto',
            background: 'rgba(8,13,23,0.98)',
            backdropFilter: 'blur(20px)',
            borderRight: '1px solid rgba(255,255,255,0.06)',
            padding: '16px 0 20px',
            scrollbarWidth: 'thin', scrollbarColor: '#1e293b transparent',
          }}
        >
          {/* Header */}
          <div style={{ padding: '0 18px 14px', borderBottom: '1px solid rgba(255,255,255,0.05)', marginBottom: 10 }}>
            <div style={{ fontSize: 10, color: '#334155', fontFamily: "'JetBrains Mono', monospace", letterSpacing: '0.1em', marginBottom: 4 }}>TRAINING PROGRAM</div>
            <div style={{ fontSize: 13, color: '#e2e8f0', fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700 }}>Security & Governance</div>
            {/* Progress */}
            <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ flex: 1, height: 3, background: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{ width: `${(totalDone / ALL_MODULES.length) * 100}%`, height: '100%', background: 'linear-gradient(90deg,#1a56db,#0ea5e9)', transition: 'width 0.5s ease', borderRadius: 2 }} />
              </div>
              <span style={{ fontSize: 10, color: '#475569', fontFamily: "'JetBrains Mono', monospace", flexShrink: 0 }}>{totalDone}/{ALL_MODULES.length}</span>
            </div>
          </div>

          {/* Module list */}
          <div style={{ padding: '0 8px' }}>
            {ALL_MODULES.map((mod, i) => {
              const isActive = mod.id === currentModuleId;
              const isDone = completedSet.has(mod.id);
              const isUnlocked = mod.id === 1 || isDone || completedSet.has(mod.id - 1);
              const moduleColor = mod.color || '#1a56db';

              return (
                <motion.button
                  key={mod.id}
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03, duration: 0.28 }}
                  onClick={() => isUnlocked && onNavigate(mod.id)}
                  style={{
                    width: '100%', textAlign: 'left',
                    display: 'flex', alignItems: 'flex-start', gap: 9,
                    padding: '9px 10px', borderRadius: 9, marginBottom: 2,
                    background: isActive ? `rgba(${hexRgb(moduleColor)},0.14)` : 'transparent',
                    border: isActive ? `1px solid rgba(${hexRgb(moduleColor)},0.3)` : '1px solid transparent',
                    cursor: isUnlocked ? 'pointer' : 'not-allowed',
                    opacity: isUnlocked ? 1 : 0.38,
                    transition: 'all 0.18s',
                    position: 'relative',
                  }}
                  onMouseEnter={e => { if (isUnlocked && !isActive) e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; }}
                  onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = 'transparent'; }}
                >
                  {isActive && (
                    <div style={{ position: 'absolute', left: 0, top: '18%', bottom: '18%', width: 2, background: `linear-gradient(180deg,${moduleColor},rgba(${hexRgb(moduleColor)},0.4))`, borderRadius: 1 }} />
                  )}
                  {/* Status icon */}
                  <div style={{
                    width: 26, height: 26, borderRadius: 7, flexShrink: 0, marginTop: 1,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: isDone ? 'rgba(16,185,129,0.15)' : isActive ? `rgba(${hexRgb(moduleColor)},0.2)` : 'rgba(255,255,255,0.04)',
                    border: isDone ? '1px solid rgba(16,185,129,0.3)' : isActive ? `1px solid rgba(${hexRgb(moduleColor)},0.35)` : '1px solid rgba(255,255,255,0.07)',
                    fontSize: 11,
                  }}>
                    {isDone ? <CheckCircle size={12} color="#10b981" /> : isActive ? <Play size={11} color={moduleColor} fill={moduleColor} /> : isUnlocked ? <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, color: '#334155', fontWeight: 700 }}>{String(mod.id).padStart(2,'0')}</span> : <Lock size={10} color="#1e293b" />}
                  </div>

                  {/* Text */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 2 }}>
                      <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, fontWeight: 700, color: isDone ? '#10b981' : isActive ? moduleColor : '#2d3748' }}>
                        {String(mod.id).padStart(2,'0')}
                      </span>
                      {isDone && <span style={{ fontSize: 8, color: '#10b981', background: 'rgba(16,185,129,0.1)', padding: '0 4px', borderRadius: 3, fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>DONE</span>}
                      {isActive && !isDone && <span style={{ fontSize: 8, color: moduleColor, background: `rgba(${hexRgb(moduleColor)},0.1)`, padding: '0 4px', borderRadius: 3, fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>ACTIVE</span>}
                    </div>
                    <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 11.5, fontWeight: isActive ? 600 : 400, color: isActive ? '#e2e8f0' : isDone ? '#64748b' : '#3d4a5c', lineHeight: 1.35, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {mod.title}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 2 }}>
                      <Clock size={9} color="#1e293b" />
                      <span style={{ fontSize: 9.5, color: '#1e293b', fontFamily: "'JetBrains Mono', monospace" }}>{mod.duration}</span>
                    </div>
                  </div>
                  {isActive && <ChevronRight size={11} color="#334155" style={{ marginTop: 7, flexShrink: 0 }} />}
                </motion.button>
              );
            })}
          </div>

          {/* Help footer */}
          <div style={{ padding: '12px 18px', marginTop: 8, borderTop: '1px solid rgba(255,255,255,0.04)' }}>
            <div style={{ fontSize: 10, color: '#1e293b', fontFamily: "'JetBrains Mono', monospace", lineHeight: 2 }}>
              <div>Questions?</div>
              <div style={{ color: '#1a56db' }}>security@securityimpossible.com.au</div>
            </div>
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  );
}

function hexRgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return r ? `${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}` : '26,86,219';
}
