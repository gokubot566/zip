import React from "react";
import { createRoot } from "react-dom/client";
import AuroraOS from "./AuroraOS.jsx";
createRoot(document.getElementById("root")).render(<AuroraOS />);
