import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import {
  Search, Wifi, Volume2, BatteryFull, ChevronUp, X, Minus, Square, Copy as CopyIcon,
  Folder, FileText, Calculator as CalcIcon, Terminal as TermIcon, Globe, Settings as SettingsIcon,
  Activity, Image as ImageIcon, Power, Lock, User, Sun, Moon, ChevronRight, ChevronLeft,
  HardDrive, Download, Trash2, Plus, RotateCw, Cpu, MemoryStick, Palette,
  Monitor, Bell, Calendar as CalIcon, FolderPlus, ArrowUp, Wallpaper as WallpaperIcon,
} from "lucide-react";

/* ============================================================
   Aurora OS — a Windows‑like desktop, in the browser.
   Single‑file React. State is in‑memory (resets on reload).
   ============================================================ */

// ---- Wallpapers (CSS gradients so nothing has to load) ----
const WALLPAPERS = [
  { id: "bloom",  name: "Bloom",   css: "radial-gradient(120% 120% at 20% 10%, #2b5876 0%, #1b3a4b 40%, #0e2233 100%)" },
  { id: "aurora", name: "Aurora",  css: "linear-gradient(135deg,#1a2980 0%,#26d0ce 100%)" },
  { id: "dusk",   name: "Dusk",    css: "linear-gradient(160deg,#3a1c71 0%,#d76d77 55%,#ffaf7b 100%)" },
  { id: "forest", name: "Forest",  css: "linear-gradient(160deg,#0f2027 0%,#203a43 50%,#2c5364 100%)" },
  { id: "slate",  name: "Slate",   css: "linear-gradient(160deg,#232526 0%,#414345 100%)" },
  { id: "rose",   name: "Rose",    css: "linear-gradient(160deg,#42275a 0%,#734b6d 100%)" },
];

const ACCENTS = [
  { id: "blue",   v: "#3b82f6" }, { id: "teal", v: "#14b8a6" }, { id: "violet", v: "#8b5cf6" },
  { id: "rose",   v: "#f43f5e" }, { id: "amber", v: "#f59e0b" }, { id: "green", v: "#22c55e" },
];

// ---- Seed virtual file system ----
const initialFS = () => ({
  "This PC": {
    type: "folder",
    children: {
      "Desktop":   { type: "folder", children: {} },
      "Documents": { type: "folder", children: {
        "Welcome.txt": { type: "file", content: "Welcome to Aurora OS!\n\nThis is a Windows‑like desktop running entirely in your browser.\nTry the Start menu, drag windows around, snap them to the screen edges,\nopen the Terminal, or change your wallpaper in Settings." },
        "Notes.txt":   { type: "file", content: "- Buy milk\n- Ship the release\n- Touch grass" },
      } },
      "Pictures":  { type: "folder", children: {} },
      "Downloads": { type: "folder", children: {} },
    },
  },
});

let WIN_SEQ = 1;

/* ============================================================
   ROOT
   ============================================================ */
export default function AuroraOS() {
  const [phase, setPhase] = useState("boot"); // boot | login | desktop | lock
  const [theme, setTheme] = useState("dark");
  const [accent, setAccent] = useState(ACCENTS[0].v);
  const [wallpaper, setWallpaper] = useState(WALLPAPERS[0]);
  const [iconSize, setIconSize] = useState(72);
  const [taskbarPos, setTaskbarPos] = useState("bottom"); // bottom | top
  const [fs, setFs] = useState(initialFS);
  const [windows, setWindows] = useState([]);
  const [startOpen, setStartOpen] = useState(false);
  const [actionOpen, setActionOpen] = useState(false);
  const [calOpen, setCalOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [toasts, setToasts] = useState([]);
  const [topZ, setTopZ] = useState(10);
  const [clock, setClock] = useState(new Date());

  useEffect(() => { const t = setInterval(() => setClock(new Date()), 1000); return () => clearInterval(t); }, []);
  useEffect(() => { if (phase === "boot") { const t = setTimeout(() => setPhase("login"), 2600); return () => clearTimeout(t); } }, [phase]);

  const notify = useCallback((title, body, icon) => {
    const n = { id: Date.now() + Math.random(), title, body, icon, time: new Date() };
    setNotifications(p => [n, ...p].slice(0, 30));
    setToasts(p => [...p, n]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== n.id)), 4200);
  }, []);

  const focusWindow = useCallback((id) => {
    setTopZ(z => { const nz = z + 1; setWindows(ws => ws.map(w => w.id === id ? { ...w, z: nz, minimized: false } : w)); return nz; });
  }, []);

  const openApp = useCallback((appId, opts = {}) => {
    const def = APP_DEFS[appId];
    if (!def) return;
    setStartOpen(false);
    // single‑instance apps: focus existing
    if (def.single) {
      const existing = windowsRef.current.find(w => w.appId === appId);
      if (existing) { focusWindow(existing.id); return; }
    }
    const id = WIN_SEQ++;
    const nz = topZRef.current + 1; setTopZ(nz);
    const w = def.w || 760, h = def.h || 520;
    const x = 120 + (windowsRef.current.length % 6) * 36;
    const y = 80 + (windowsRef.current.length % 6) * 30;
    setWindows(ws => [...ws, {
      id, appId, title: def.title, icon: def.icon,
      x, y, w, h, z: nz, minimized: false, maximized: false,
      prev: null, props: opts,
    }]);
  }, [focusWindow]);

  // keep refs so callbacks read fresh values
  const windowsRef = useRef(windows); useEffect(() => { windowsRef.current = windows; }, [windows]);
  const topZRef = useRef(topZ); useEffect(() => { topZRef.current = topZ; }, [topZ]);

  const closeWindow = (id) => setWindows(ws => ws.filter(w => w.id !== id));
  const minimizeWindow = (id) => setWindows(ws => ws.map(w => w.id === id ? { ...w, minimized: true } : w));
  const toggleMax = (id) => setWindows(ws => ws.map(w => {
    if (w.id !== id) return w;
    if (w.maximized) return { ...w, maximized: false, ...(w.prev || {}) };
    return { ...w, maximized: true, prev: { x: w.x, y: w.y, w: w.w, h: w.h } };
  }));
  const snapWindow = (id, side) => setWindows(ws => ws.map(w => {
    if (w.id !== id) return w;
    const W = window.innerWidth, H = window.innerHeight - 48;
    const off = taskbarPos === "top" ? 48 : 0;
    if (side === "left")  return { ...w, maximized: false, x: 0,   y: off, w: W/2, h: H };
    if (side === "right") return { ...w, maximized: false, x: W/2, y: off, w: W/2, h: H };
    if (side === "max")   return { ...w, maximized: true, prev: { x: w.x, y: w.y, w: w.w, h: w.h } };
    return w;
  }));
  const updateWindow = (id, patch) => setWindows(ws => ws.map(w => w.id === id ? { ...w, ...patch } : w));

  // keyboard shortcuts
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Meta" || (e.ctrlKey && e.key === "Escape")) { e.preventDefault(); setStartOpen(s => !s); }
      if (e.altKey && e.key === "F4") {
        e.preventDefault();
        const top = [...windowsRef.current].filter(w => !w.minimized).sort((a,b)=>b.z-a.z)[0];
        if (top) closeWindow(top.id);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const sys = {
    theme, setTheme, accent, setAccent, wallpaper, setWallpaper, wallpapers: WALLPAPERS,
    accents: ACCENTS, iconSize, setIconSize, taskbarPos, setTaskbarPos,
    fs, setFs, openApp, notify, lock: () => setPhase("lock"), signOut: () => { setWindows([]); setPhase("login"); },
  };

  const dark = theme === "dark";
  const ui = {
    text: dark ? "#f3f4f6" : "#1f2937",
    sub: dark ? "rgba(255,255,255,.6)" : "rgba(0,0,0,.55)",
    glass: dark ? "rgba(30,33,42,.72)" : "rgba(255,255,255,.72)",
    glassSolid: dark ? "rgba(32,35,44,.96)" : "rgba(250,250,252,.96)",
    border: dark ? "rgba(255,255,255,.10)" : "rgba(0,0,0,.08)",
    hover: dark ? "rgba(255,255,255,.08)" : "rgba(0,0,0,.05)",
    accent,
  };

  return (
    <div style={{
      position: "fixed", inset: 0, overflow: "hidden", fontFamily:
        "'Segoe UI Variable','Segoe UI',system-ui,-apple-system,sans-serif",
      background: wallpaper.css, color: ui.text, userSelect: "none",
    }}>
      <style>{`
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 10px; height: 10px; }
        ::-webkit-scrollbar-thumb { background: ${dark?'rgba(255,255,255,.18)':'rgba(0,0,0,.18)'}; border-radius: 8px; border: 2px solid transparent; background-clip: content-box; }
        @keyframes fadeUp { from { opacity:0; transform: translateY(12px) scale(.98);} to {opacity:1; transform: none;} }
        @keyframes fadeIn { from { opacity:0 } to { opacity:1 } }
        @keyframes spin { to { transform: rotate(360deg) } }
        @keyframes popIn { from { opacity:0; transform: scale(.9) translateY(20px);} to { opacity:1; transform:none;} }
        .aos-btn { transition: background .12s ease, transform .08s ease; }
        .aos-btn:hover { background: ${ui.hover}; }
        .aos-btn:active { transform: scale(.96); }
        .tb-item { transition: background .14s ease; position: relative; }
        .tb-item:hover { background: ${ui.hover}; }
        input, textarea { font-family: inherit; }
      `}</style>

      {phase === "boot" && <BootScreen accent={accent} />}
      {phase === "login" && <LoginScreen ui={ui} wallpaper={wallpaper} onLogin={() => setPhase("desktop")} clock={clock} />}
      {phase === "lock" && <LoginScreen ui={ui} wallpaper={wallpaper} locked onLogin={() => setPhase("desktop")} clock={clock} />}

      {phase === "desktop" && (
        <>
          {/* Desktop icons */}
          <Desktop ui={ui} iconSize={iconSize} openApp={openApp} onContext={() => {}} taskbarPos={taskbarPos} />

          {/* Windows */}
          {windows.map(w => (
            <Window key={w.id} w={w} ui={ui} taskbarPos={taskbarPos}
              onFocus={() => focusWindow(w.id)} onClose={() => closeWindow(w.id)}
              onMin={() => minimizeWindow(w.id)} onMax={() => toggleMax(w.id)}
              onSnap={(s) => snapWindow(w.id, s)} onUpdate={(p) => updateWindow(w.id, p)}>
              <AppHost appId={w.appId} sys={sys} ui={ui} win={w} openApp={openApp} />
            </Window>
          ))}

          {/* Start menu */}
          {startOpen && <StartMenu ui={ui} openApp={openApp} sys={sys} onClose={() => setStartOpen(false)} clock={clock} taskbarPos={taskbarPos} />}
          {/* Action center */}
          {actionOpen && <ActionCenter ui={ui} sys={sys} notifications={notifications} clearAll={() => setNotifications([])} onClose={() => setActionOpen(false)} taskbarPos={taskbarPos} />}
          {calOpen && <CalendarFlyout ui={ui} clock={clock} onClose={() => setCalOpen(false)} taskbarPos={taskbarPos} />}

          {/* Taskbar */}
          <Taskbar ui={ui} clock={clock} windows={windows} openApp={openApp}
            startOpen={startOpen} setStartOpen={setStartOpen}
            actionOpen={actionOpen} setActionOpen={setActionOpen}
            calOpen={calOpen} setCalOpen={setCalOpen}
            onTaskClick={(id) => { const w = windows.find(x => x.id === id); if (w?.minimized) focusWindow(id); else { const tops=[...windows].sort((a,b)=>b.z-a.z); if(tops[0]?.id===id) minimizeWindow(id); else focusWindow(id);} }}
            taskbarPos={taskbarPos} />

          {/* Toasts */}
          <div style={{ position: "fixed", right: 16, bottom: taskbarPos === "bottom" ? 64 : 16, top: taskbarPos==="top"?64:"auto", display: "flex", flexDirection: "column", gap: 10, zIndex: 9999 }}>
            {toasts.map(t => (
              <div key={t.id} style={{ width: 320, background: ui.glassSolid, backdropFilter: "blur(20px)", border: `1px solid ${ui.border}`, borderRadius: 12, padding: 14, boxShadow: "0 12px 40px rgba(0,0,0,.4)", animation: "fadeUp .25s ease" }}>
                <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 4 }}>
                  <div style={{ width: 26, height: 26, borderRadius: 7, background: accent, display: "grid", placeItems: "center", color: "#fff" }}>{t.icon || <Bell size={15} />}</div>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{t.title}</div>
                </div>
                <div style={{ fontSize: 12.5, color: ui.sub, paddingLeft: 36 }}>{t.body}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

/* ============================================================
   BOOT + LOGIN
   ============================================================ */
function BootScreen({ accent }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "#0a0c10", display: "grid", placeItems: "center", animation: "fadeIn .4s ease" }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ width: 64, height: 64, margin: "0 auto 28px", borderRadius: 16, background: `conic-gradient(from 0deg, ${accent}, #22d3ee, #a78bfa, ${accent})`, boxShadow: `0 0 40px ${accent}66` }} />
        <div style={{ color: "#fff", fontSize: 22, fontWeight: 300, letterSpacing: 4, marginBottom: 36 }}>AURORA OS</div>
        <div style={{ width: 28, height: 28, margin: "0 auto", border: "3px solid rgba(255,255,255,.15)", borderTopColor: "#fff", borderRadius: "50%", animation: "spin .9s linear infinite" }} />
      </div>
    </div>
  );
}

function LoginScreen({ ui, wallpaper, onLogin, locked, clock }) {
  const [pw, setPw] = useState("");
  const time = clock.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const date = clock.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" });
  return (
    <div style={{ position: "fixed", inset: 0, background: wallpaper.css, display: "grid", placeItems: "center", animation: "fadeIn .5s ease" }}
      onClick={() => locked && null}>
      <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,.35)", backdropFilter: locked ? "none" : "blur(4px)" }} />
      {locked ? (
        <div style={{ position: "relative", textAlign: "center", color: "#fff", cursor: "pointer" }} onClick={onLogin}>
          <div style={{ fontSize: 84, fontWeight: 200 }}>{time}</div>
          <div style={{ fontSize: 22, fontWeight: 300, opacity: .9 }}>{date}</div>
          <div style={{ marginTop: 40, fontSize: 13, opacity: .7 }}>Click to unlock</div>
        </div>
      ) : (
        <div style={{ position: "relative", textAlign: "center", color: "#fff", animation: "fadeUp .4s ease" }}>
          <div style={{ width: 110, height: 110, borderRadius: "50%", margin: "0 auto 18px", background: "rgba(255,255,255,.14)", display: "grid", placeItems: "center", border: "1px solid rgba(255,255,255,.2)" }}>
            <User size={56} strokeWidth={1.4} />
          </div>
          <div style={{ fontSize: 26, fontWeight: 500, marginBottom: 22 }}>Alex Carter</div>
          <form onSubmit={(e) => { e.preventDefault(); onLogin(); }}>
            <input autoFocus type="password" value={pw} onChange={e => setPw(e.target.value)} placeholder="Enter password (or just press →)"
              style={{ width: 260, padding: "10px 14px", borderRadius: 24, border: "1px solid rgba(255,255,255,.3)", background: "rgba(255,255,255,.12)", color: "#fff", outline: "none", textAlign: "center", fontSize: 14 }} />
            <button type="submit" style={{ display: "block", margin: "16px auto 0", padding: "8px 26px", borderRadius: 20, border: "none", background: ui.accent, color: "#fff", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>Sign in →</button>
          </form>
        </div>
      )}
    </div>
  );
}

/* ============================================================
   DESKTOP ICONS
   ============================================================ */
function Desktop({ ui, iconSize, openApp, taskbarPos }) {
  const icons = [
    { appId: "explorer", label: "File Explorer" },
    { appId: "notepad",  label: "Notepad" },
    { appId: "terminal", label: "Terminal" },
    { appId: "browser",  label: "Aurora Edge" },
    { appId: "settings", label: "Settings" },
    { appId: "calc",     label: "Calculator" },
  ];
  const [sel, setSel] = useState(null);
  return (
    <div style={{ position: "absolute", top: taskbarPos === "top" ? 60 : 12, left: 12, bottom: taskbarPos === "bottom" ? 60 : 12,
      display: "flex", flexDirection: "column", flexWrap: "wrap", alignContent: "flex-start", gap: 6 }}
      onMouseDown={() => setSel(null)}>
      {icons.map(ic => {
        const def = APP_DEFS[ic.appId];
        const Icon = def.iconCmp;
        return (
          <div key={ic.appId} onMouseDown={(e) => { e.stopPropagation(); setSel(ic.appId); }}
            onDoubleClick={() => openApp(ic.appId)}
            style={{ width: iconSize + 24, padding: 8, borderRadius: 8, display: "flex", flexDirection: "column", alignItems: "center", gap: 6, cursor: "pointer",
              background: sel === ic.appId ? "rgba(120,160,255,.25)" : "transparent", border: sel === ic.appId ? "1px solid rgba(140,170,255,.5)" : "1px solid transparent" }}>
            <div style={{ width: iconSize * .62, height: iconSize * .62, borderRadius: 12, background: def.bg, display: "grid", placeItems: "center", color: "#fff", boxShadow: "0 4px 14px rgba(0,0,0,.3)" }}>
              <Icon size={iconSize * .34} />
            </div>
            <span style={{ fontSize: 12, color: "#fff", textShadow: "0 1px 3px rgba(0,0,0,.7)", textAlign: "center", lineHeight: 1.2 }}>{ic.label}</span>
          </div>
        );
      })}
    </div>
  );
}

/* ============================================================
   WINDOW
   ============================================================ */
function Window({ w, ui, children, onFocus, onClose, onMin, onMax, onSnap, onUpdate, taskbarPos }) {
  const drag = useRef(null);
  const resize = useRef(null);
  const [snapHint, setSnapHint] = useState(null);

  const onTitleDown = (e) => {
    if (e.target.closest("[data-nodrag]")) return;
    onFocus();
    if (w.maximized) return;
    drag.current = { sx: e.clientX, sy: e.clientY, ox: w.x, oy: w.y };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };
  const onMove = (e) => {
    if (!drag.current) return;
    const nx = drag.current.ox + (e.clientX - drag.current.sx);
    const ny = Math.max(taskbarPos === "top" ? 48 : 0, drag.current.oy + (e.clientY - drag.current.sy));
    onUpdate({ x: nx, y: ny });
    if (e.clientX < 8) setSnapHint("left");
    else if (e.clientX > window.innerWidth - 8) setSnapHint("right");
    else if (e.clientY < (taskbarPos === "top" ? 56 : 8)) setSnapHint("max");
    else setSnapHint(null);
  };
  const onUp = () => {
    window.removeEventListener("mousemove", onMove);
    window.removeEventListener("mouseup", onUp);
    if (snapHint) onSnap(snapHint);
    setSnapHint(null);
    drag.current = null;
  };

  const onResizeDown = (e, dir) => {
    e.stopPropagation(); onFocus();
    resize.current = { sx: e.clientX, sy: e.clientY, ow: w.w, oh: w.h, ox: w.x, oy: w.y, dir };
    window.addEventListener("mousemove", onResizeMove);
    window.addEventListener("mouseup", onResizeUp);
  };
  const onResizeMove = (e) => {
    if (!resize.current) return;
    const r = resize.current; const dx = e.clientX - r.sx, dy = e.clientY - r.sy;
    let patch = {};
    if (r.dir.includes("e")) patch.w = Math.max(360, r.ow + dx);
    if (r.dir.includes("s")) patch.h = Math.max(240, r.oh + dy);
    if (r.dir.includes("w")) { patch.w = Math.max(360, r.ow - dx); patch.x = r.ox + dx; }
    if (r.dir.includes("n")) { patch.h = Math.max(240, r.oh - dy); patch.y = r.oy + dy; }
    onUpdate(patch);
  };
  const onResizeUp = () => { window.removeEventListener("mousemove", onResizeMove); window.removeEventListener("mouseup", onResizeUp); resize.current = null; };

  if (w.minimized) return null;
  const tb = taskbarPos === "bottom";
  const geo = w.maximized
    ? { left: 0, top: taskbarPos === "top" ? 48 : 0, width: "100vw", height: `calc(100vh - 48px)` }
    : { left: w.x, top: w.y, width: w.w, height: w.h };
  const Icon = w.icon;

  return (
    <>
      {snapHint && (
        <div style={{ position: "fixed", zIndex: 9998, pointerEvents: "none", background: `${ui.accent}33`, border: `2px solid ${ui.accent}`, borderRadius: 10, transition: "all .12s ease",
          ...(snapHint === "left" ? { left: 6, top: (taskbarPos==="top"?54:6), width: "calc(50vw - 9px)", height: "calc(100vh - 60px)" }
            : snapHint === "right" ? { right: 6, top: (taskbarPos==="top"?54:6), width: "calc(50vw - 9px)", height: "calc(100vh - 60px)" }
            : { left: 6, top: (taskbarPos==="top"?54:6), width: "calc(100vw - 12px)", height: "calc(100vh - 60px)" }) }} />
      )}
      <div onMouseDown={onFocus} style={{
        position: "absolute", ...geo, zIndex: w.z, display: "flex", flexDirection: "column",
        background: ui.glassSolid, backdropFilter: "blur(30px)", borderRadius: w.maximized ? 0 : 10,
        border: `1px solid ${ui.border}`, boxShadow: "0 24px 70px rgba(0,0,0,.5)", overflow: "hidden",
        animation: "popIn .16s ease",
      }}>
        {/* Title bar */}
        <div onMouseDown={onTitleDown} onDoubleClick={onMax}
          style={{ height: 38, display: "flex", alignItems: "center", paddingLeft: 12, gap: 8, cursor: "default", flexShrink: 0 }}>
          <Icon size={15} color={ui.accent} />
          <span style={{ fontSize: 12.5, fontWeight: 500 }}>{w.title}</span>
          <div style={{ flex: 1 }} />
          <div data-nodrag style={{ display: "flex", height: "100%" }}>
            <WinBtn onClick={onMin}><Minus size={15} /></WinBtn>
            <WinBtn onClick={onMax}>{w.maximized ? <CopyIcon size={13} /> : <Square size={12} />}</WinBtn>
            <WinBtn close onClick={onClose}><X size={15} /></WinBtn>
          </div>
        </div>
        {/* Body */}
        <div style={{ flex: 1, overflow: "hidden", position: "relative", background: ui.theme === "dark" ? "rgba(20,22,28,.6)" : "rgba(255,255,255,.5)" }}>
          {children}
        </div>
        {/* resize handles */}
        {!w.maximized && ["n","s","e","w","ne","nw","se","sw"].map(d => (
          <div key={d} onMouseDown={(e) => onResizeDown(e, d)} style={resizeStyle(d)} />
        ))}
      </div>
    </>
  );
}
function WinBtn({ children, onClick, close }) {
  const [h, setH] = useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{ width: 46, height: "100%", display: "grid", placeItems: "center", cursor: "pointer",
        background: h ? (close ? "#e81123" : "rgba(128,128,128,.25)") : "transparent", color: h && close ? "#fff" : "inherit", transition: "background .12s" }}>
      {children}
    </div>
  );
}
function resizeStyle(d) {
  const s = { position: "absolute", zIndex: 5 };
  const t = 6;
  if (d === "n") return { ...s, top: 0, left: t, right: t, height: t, cursor: "ns-resize" };
  if (d === "s") return { ...s, bottom: 0, left: t, right: t, height: t, cursor: "ns-resize" };
  if (d === "e") return { ...s, right: 0, top: t, bottom: t, width: t, cursor: "ew-resize" };
  if (d === "w") return { ...s, left: 0, top: t, bottom: t, width: t, cursor: "ew-resize" };
  if (d === "ne") return { ...s, top: 0, right: 0, width: t*2, height: t*2, cursor: "nesw-resize" };
  if (d === "nw") return { ...s, top: 0, left: 0, width: t*2, height: t*2, cursor: "nwse-resize" };
  if (d === "se") return { ...s, bottom: 0, right: 0, width: t*2, height: t*2, cursor: "nwse-resize" };
  if (d === "sw") return { ...s, bottom: 0, left: 0, width: t*2, height: t*2, cursor: "nesw-resize" };
  return s;
}

/* ============================================================
   TASKBAR  (signature: centered Fluent taskbar)
   ============================================================ */
function Taskbar({ ui, clock, windows, openApp, startOpen, setStartOpen, actionOpen, setActionOpen, calOpen, setCalOpen, onTaskClick, taskbarPos }) {
  const pinned = ["explorer", "notepad", "terminal", "browser", "settings"];
  const openAppIds = [...new Set(windows.map(w => w.appId))];
  const time = clock.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const date = clock.toLocaleDateString([], { month: "numeric", day: "numeric", year: "numeric" });
  const pos = taskbarPos === "top" ? { top: 0 } : { bottom: 0 };
  return (
    <div style={{ position: "fixed", left: 0, right: 0, ...pos, height: 48, zIndex: 9000, display: "flex", alignItems: "center", justifyContent: "center",
      background: ui.glass, backdropFilter: "blur(30px) saturate(160%)", borderTop: taskbarPos === "bottom" ? `1px solid ${ui.border}` : "none", borderBottom: taskbarPos === "top" ? `1px solid ${ui.border}` : "none" }}>
      {/* centered cluster */}
      <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
        <TBButton active={startOpen} onClick={() => { setStartOpen(s => !s); setActionOpen(false); setCalOpen(false); }} ui={ui} title="Start">
          <div style={{ width: 22, height: 22, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 2 }}>
            {[0,1,2,3].map(i => <div key={i} style={{ background: ui.accent, borderRadius: 2 }} />)}
          </div>
        </TBButton>
        {[...new Set([...pinned, ...openAppIds])].map(appId => {
          const def = APP_DEFS[appId]; if (!def) return null;
          const Icon = def.iconCmp;
          const wins = windows.filter(w => w.appId === appId);
          const isOpen = wins.length > 0;
          const isActive = isOpen && !wins.every(w => w.minimized);
          return (
            <div key={appId} className="tb-item" onClick={() => { if (isOpen) onTaskClick(wins[0].id); else openApp(appId); }}
              title={def.title} style={{ width: 40, height: 40, borderRadius: 8, display: "grid", placeItems: "center", cursor: "pointer", margin: "0 1px" }}>
              <div style={{ width: 30, height: 30, borderRadius: 8, background: def.bg, display: "grid", placeItems: "center", color: "#fff", boxShadow: "0 2px 6px rgba(0,0,0,.25)" }}>
                <Icon size={17} />
              </div>
              {isOpen && <div style={{ position: "absolute", bottom: 3, left: "50%", transform: "translateX(-50%)", width: isActive ? 16 : 7, height: 3, borderRadius: 2, background: ui.accent, transition: "width .2s" }} />}
            </div>
          );
        })}
      </div>
      {/* right system tray */}
      <div style={{ position: "absolute", right: 6, display: "flex", alignItems: "center", gap: 2 }}>
        <div className="tb-item" onClick={() => { setActionOpen(a => !a); setStartOpen(false); setCalOpen(false); }} style={{ display: "flex", gap: 10, padding: "8px 12px", borderRadius: 8, cursor: "pointer", alignItems: "center" }}>
          <Wifi size={16} /><Volume2 size={16} /><BatteryFull size={16} />
        </div>
        <div className="tb-item" onClick={() => { setCalOpen(c => !c); setStartOpen(false); setActionOpen(false); }} style={{ padding: "5px 12px", borderRadius: 8, cursor: "pointer", textAlign: "right", fontSize: 12, lineHeight: 1.35 }}>
          <div>{time}</div><div>{date}</div>
        </div>
      </div>
    </div>
  );
}
function TBButton({ children, onClick, active, ui, title }) {
  return (
    <div className="tb-item" onClick={onClick} title={title} style={{ width: 40, height: 40, borderRadius: 8, display: "grid", placeItems: "center", cursor: "pointer", background: active ? ui.hover : "transparent" }}>
      {children}
    </div>
  );
}

/* ============================================================
   START MENU
   ============================================================ */
function StartMenu({ ui, openApp, sys, onClose, clock, taskbarPos }) {
  const [q, setQ] = useState("");
  const all = Object.entries(APP_DEFS).filter(([id]) => !APP_DEFS[id].hidden);
  const filtered = all.filter(([id, d]) => d.title.toLowerCase().includes(q.toLowerCase()));
  const pos = taskbarPos === "top" ? { top: 56 } : { bottom: 56 };
  return (
    <>
      <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 8999 }} />
      <div style={{ position: "fixed", left: "50%", transform: "translateX(-50%)", ...pos, width: 560, maxWidth: "94vw", zIndex: 9001,
        background: ui.glassSolid, backdropFilter: "blur(40px) saturate(160%)", border: `1px solid ${ui.border}`, borderRadius: 14, padding: 22, boxShadow: "0 24px 70px rgba(0,0,0,.5)", animation: "fadeUp .18s ease" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, background: ui.hover, borderRadius: 22, padding: "9px 16px", marginBottom: 20 }}>
          <Search size={16} color={ui.sub} />
          <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Search apps"
            style={{ flex: 1, border: "none", background: "transparent", outline: "none", color: ui.text, fontSize: 13.5 }} />
        </div>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: ui.sub, marginBottom: 12 }}>{q ? "Results" : "Pinned"}</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6,1fr)", gap: 8, marginBottom: 18 }}>
          {filtered.map(([id, d]) => {
            const Icon = d.iconCmp;
            return (
              <div key={id} className="aos-btn" onClick={() => { openApp(id); onClose(); }}
                style={{ borderRadius: 10, padding: "14px 6px", display: "flex", flexDirection: "column", alignItems: "center", gap: 8, cursor: "pointer" }}>
                <div style={{ width: 40, height: 40, borderRadius: 11, background: d.bg, display: "grid", placeItems: "center", color: "#fff" }}><Icon size={21} /></div>
                <span style={{ fontSize: 11.5, textAlign: "center", lineHeight: 1.2 }}>{d.title}</span>
              </div>
            );
          })}
        </div>
        {/* footer */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: `1px solid ${ui.border}`, paddingTop: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 32, height: 32, borderRadius: "50%", background: ui.accent, display: "grid", placeItems: "center", color: "#fff" }}><User size={17} /></div>
            <span style={{ fontSize: 13, fontWeight: 500 }}>Alex Carter</span>
          </div>
          <div style={{ display: "flex", gap: 4 }}>
            <div className="aos-btn" title="Lock" onClick={() => { onClose(); sys.lock(); }} style={{ padding: 9, borderRadius: 8, cursor: "pointer" }}><Lock size={16} /></div>
            <div className="aos-btn" title="Sign out" onClick={() => { onClose(); sys.signOut(); }} style={{ padding: 9, borderRadius: 8, cursor: "pointer" }}><Power size={16} /></div>
          </div>
        </div>
      </div>
    </>
  );
}

/* ============================================================
   ACTION CENTER + CALENDAR
   ============================================================ */
function ActionCenter({ ui, sys, notifications, clearAll, onClose, taskbarPos }) {
  const pos = taskbarPos === "top" ? { top: 56 } : { bottom: 56 };
  const tiles = [
    { label: "Wi‑Fi", icon: <Wifi size={18} />, on: true },
    { label: sys.theme === "dark" ? "Dark" : "Light", icon: sys.theme === "dark" ? <Moon size={18} /> : <Sun size={18} />, on: true, onClick: () => sys.setTheme(sys.theme === "dark" ? "light" : "dark") },
    { label: "Battery", icon: <BatteryFull size={18} />, on: true },
    { label: "Focus", icon: <Bell size={18} />, on: false },
  ];
  return (
    <>
      <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 8999 }} />
      <div style={{ position: "fixed", right: 8, ...pos, width: 360, maxWidth: "94vw", zIndex: 9001,
        background: ui.glassSolid, backdropFilter: "blur(40px)", border: `1px solid ${ui.border}`, borderRadius: 14, padding: 16, boxShadow: "0 24px 70px rgba(0,0,0,.5)", animation: "fadeUp .18s ease" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 8, marginBottom: 16 }}>
          {tiles.map((t, i) => (
            <div key={i} className="aos-btn" onClick={t.onClick} style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px", borderRadius: 10, cursor: "pointer", background: t.on ? ui.accent : ui.hover, color: t.on ? "#fff" : ui.text }}>
              {t.icon}<span style={{ fontSize: 12.5, fontWeight: 500 }}>{t.label}</span>
            </div>
          ))}
        </div>
        {/* volume + brightness */}
        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 16 }}>
          <Slider ui={ui} icon={<Volume2 size={15} />} />
          <Slider ui={ui} icon={<Sun size={15} />} />
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
          <span style={{ fontSize: 12.5, fontWeight: 600, color: ui.sub }}>Notifications</span>
          {notifications.length > 0 && <span onClick={clearAll} style={{ fontSize: 11.5, color: ui.accent, cursor: "pointer" }}>Clear all</span>}
        </div>
        <div style={{ maxHeight: 240, overflowY: "auto", display: "flex", flexDirection: "column", gap: 8 }}>
          {notifications.length === 0
            ? <div style={{ textAlign: "center", color: ui.sub, fontSize: 12.5, padding: "20px 0" }}>No new notifications</div>
            : notifications.map(n => (
              <div key={n.id} style={{ background: ui.hover, borderRadius: 10, padding: 12 }}>
                <div style={{ fontSize: 12.5, fontWeight: 600 }}>{n.title}</div>
                <div style={{ fontSize: 12, color: ui.sub, marginTop: 2 }}>{n.body}</div>
              </div>
            ))}
        </div>
      </div>
    </>
  );
}
function Slider({ ui, icon }) {
  const [v, setV] = useState(70);
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <div style={{ color: ui.sub }}>{icon}</div>
      <input type="range" min="0" max="100" value={v} onChange={e => setV(e.target.value)}
        style={{ flex: 1, accentColor: ui.accent }} />
    </div>
  );
}
function CalendarFlyout({ ui, clock, onClose, taskbarPos }) {
  const pos = taskbarPos === "top" ? { top: 56 } : { bottom: 56 };
  const now = clock;
  const year = now.getFullYear(), month = now.getMonth();
  const first = new Date(year, month, 1).getDay();
  const days = new Date(year, month + 1, 0).getDate();
  const cells = [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  return (
    <>
      <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 8999 }} />
      <div style={{ position: "fixed", right: 8, ...pos, width: 320, zIndex: 9001, background: ui.glassSolid, backdropFilter: "blur(40px)", border: `1px solid ${ui.border}`, borderRadius: 14, padding: 18, boxShadow: "0 24px 70px rgba(0,0,0,.5)", animation: "fadeUp .18s ease" }}>
        <div style={{ fontSize: 32, fontWeight: 300, marginBottom: 2 }}>{now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
        <div style={{ fontSize: 13, color: ui.sub, marginBottom: 16 }}>{now.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric", year: "numeric" })}</div>
        <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 10 }}>{now.toLocaleDateString([], { month: "long", year: "numeric" })}</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 2, fontSize: 11.5, textAlign: "center" }}>
          {["S","M","T","W","T","F","S"].map((d,i) => <div key={i} style={{ color: ui.sub, padding: 4 }}>{d}</div>)}
          {cells.map((c, i) => (
            <div key={i} style={{ padding: 6, borderRadius: "50%", aspectRatio: "1", display: "grid", placeItems: "center",
              background: c === now.getDate() ? ui.accent : "transparent", color: c === now.getDate() ? "#fff" : ui.text }}>{c || ""}</div>
          ))}
        </div>
      </div>
    </>
  );
}

/* ============================================================
   APP HOST  — routes appId → component
   ============================================================ */
function AppHost({ appId, sys, ui, win, openApp }) {
  switch (appId) {
    case "explorer": return <FileExplorer sys={sys} ui={ui} openApp={openApp} initialPath={win.props?.path} />;
    case "notepad":  return <Notepad sys={sys} ui={ui} file={win.props?.file} />;
    case "terminal": return <TerminalApp sys={sys} ui={ui} />;
    case "browser":  return <Browser ui={ui} />;
    case "settings": return <Settings sys={sys} ui={ui} />;
    case "calc":     return <CalculatorApp ui={ui} />;
    case "taskmgr":  return <TaskManager ui={ui} sys={sys} />;
    case "photos":   return <Photos ui={ui} />;
    default: return <div style={{ padding: 20 }}>Unknown app</div>;
  }
}

/* ---- File Explorer ---- */
function getNode(fs, pathArr) {
  let node = { children: fs };
  for (const p of pathArr) { if (!node.children || !node.children[p]) return null; node = node.children[p]; }
  return node;
}
function FileExplorer({ sys, ui, openApp, initialPath }) {
  const [path, setPath] = useState(initialPath || ["This PC", "Documents"]);
  const [view, setView] = useState("grid");
  const [sel, setSel] = useState(null);
  const node = getNode(sys.fs, path);
  const entries = node?.children ? Object.entries(node.children) : [];
  const quick = [["This PC"], ["This PC","Desktop"], ["This PC","Documents"], ["This PC","Pictures"], ["This PC","Downloads"]];

  const mkFolder = () => {
    const name = prompt("New folder name", "New folder"); if (!name) return;
    sys.setFs(prev => { const copy = structuredClone(prev); const n = getNode(copy, path); n.children[name] = { type: "folder", children: {} }; return copy; });
  };
  const del = () => {
    if (!sel) return;
    sys.setFs(prev => { const copy = structuredClone(prev); const n = getNode(copy, path); delete n.children[sel]; return copy; });
    setSel(null);
  };
  const open = (name, entry) => {
    if (entry.type === "folder") { setPath([...path, name]); setSel(null); }
    else if (name.endsWith(".txt")) openApp("notepad", { file: [...path, name] });
  };

  return (
    <div style={{ display: "flex", height: "100%", fontSize: 13 }}>
      {/* sidebar */}
      <div style={{ width: 180, borderRight: `1px solid ${ui.border}`, padding: 8, overflowY: "auto", flexShrink: 0 }}>
        <div style={{ fontSize: 11, color: ui.sub, padding: "6px 8px", fontWeight: 600 }}>Quick access</div>
        {quick.map(q => {
          const label = q[q.length - 1];
          const active = JSON.stringify(q) === JSON.stringify(path);
          return (
            <div key={label} className="aos-btn" onClick={() => { setPath(q); setSel(null); }}
              style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 8px", borderRadius: 6, cursor: "pointer", background: active ? ui.hover : "transparent" }}>
              {label === "This PC" ? <HardDrive size={15} color={ui.accent} /> : label === "Downloads" ? <Download size={15} color={ui.accent} /> : <Folder size={15} color={ui.accent} />}
              {label}
            </div>
          );
        })}
      </div>
      {/* main */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        {/* toolbar */}
        <div style={{ display: "flex", alignItems: "center", gap: 6, padding: 8, borderBottom: `1px solid ${ui.border}` }}>
          <button className="aos-btn" onClick={() => setPath(path.slice(0, -1).length ? path.slice(0, -1) : path)} disabled={path.length <= 1}
            style={iconBtn(ui, path.length <= 1)}><ArrowUp size={15} /></button>
          <button className="aos-btn" onClick={mkFolder} style={iconBtn(ui)}><FolderPlus size={15} /></button>
          <button className="aos-btn" onClick={del} disabled={!sel} style={iconBtn(ui, !sel)}><Trash2 size={15} /></button>
          {/* breadcrumb */}
          <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 4, background: ui.hover, borderRadius: 6, padding: "6px 10px", marginLeft: 4, overflow: "hidden" }}>
            {path.map((p, i) => (
              <React.Fragment key={i}>
                {i > 0 && <ChevronRight size={13} color={ui.sub} />}
                <span onClick={() => setPath(path.slice(0, i + 1))} style={{ cursor: "pointer", whiteSpace: "nowrap" }}>{p}</span>
              </React.Fragment>
            ))}
          </div>
          <button className="aos-btn" onClick={() => setView(view === "grid" ? "list" : "grid")} style={iconBtn(ui)}>
            {view === "grid" ? <FileText size={15} /> : <ImageIcon size={15} />}
          </button>
        </div>
        {/* files */}
        <div onMouseDown={() => setSel(null)} style={{ flex: 1, overflowY: "auto", padding: 12, display: view === "grid" ? "grid" : "block", gridTemplateColumns: "repeat(auto-fill,minmax(96px,1fr))", gap: 8, alignContent: "start" }}>
          {entries.length === 0 && <div style={{ color: ui.sub, fontSize: 12.5, gridColumn: "1/-1", padding: 20, textAlign: "center" }}>This folder is empty</div>}
          {entries.map(([name, entry]) => {
            const isFolder = entry.type === "folder";
            const active = sel === name;
            if (view === "list") return (
              <div key={name} onMouseDown={(e) => { e.stopPropagation(); setSel(name); }} onDoubleClick={() => open(name, entry)}
                style={{ display: "flex", alignItems: "center", gap: 10, padding: "7px 10px", borderRadius: 6, cursor: "pointer", background: active ? "rgba(120,160,255,.25)" : "transparent" }}>
                {isFolder ? <Folder size={17} color="#eab308" fill="#eab308" /> : <FileText size={17} color={ui.accent} />}
                <span>{name}</span>
              </div>
            );
            return (
              <div key={name} onMouseDown={(e) => { e.stopPropagation(); setSel(name); }} onDoubleClick={() => open(name, entry)}
                style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, padding: 10, borderRadius: 8, cursor: "pointer", background: active ? "rgba(120,160,255,.25)" : "transparent", border: active ? "1px solid rgba(140,170,255,.5)" : "1px solid transparent" }}>
                {isFolder ? <Folder size={40} color="#eab308" fill="#eab308" /> : <FileText size={40} color={ui.accent} />}
                <span style={{ fontSize: 12, textAlign: "center", wordBreak: "break-word", lineHeight: 1.2 }}>{name}</span>
              </div>
            );
          })}
        </div>
        <div style={{ borderTop: `1px solid ${ui.border}`, padding: "5px 12px", fontSize: 11.5, color: ui.sub }}>{entries.length} items</div>
      </div>
    </div>
  );
}
function iconBtn(ui, disabled) { return { width: 32, height: 30, borderRadius: 6, border: "none", background: "transparent", color: disabled ? ui.sub : ui.text, display: "grid", placeItems: "center", cursor: disabled ? "default" : "pointer", opacity: disabled ? .4 : 1 }; }

/* ---- Notepad ---- */
function Notepad({ sys, ui, file }) {
  const initial = file ? (getNode(sys.fs, file)?.content ?? "") : "";
  const [text, setText] = useState(initial);
  const [saved, setSaved] = useState(true);
  useEffect(() => { setText(initial); setSaved(true); }, [JSON.stringify(file)]);
  const save = () => {
    if (!file) { sys.notify("Notepad", "Open this file from File Explorer to save changes."); return; }
    sys.setFs(prev => { const copy = structuredClone(prev); const n = getNode(copy, file); if (n) n.content = text; return copy; });
    setSaved(true); sys.notify("Notepad", `Saved ${file[file.length - 1]}`);
  };
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "6px 12px", borderBottom: `1px solid ${ui.border}`, fontSize: 12.5 }}>
        <span style={{ cursor: "pointer", color: ui.accent }} onClick={save}>Save</span>
        <span style={{ color: ui.sub }}>{file ? file[file.length - 1] : "Untitled"}{saved ? "" : " •"}</span>
      </div>
      <textarea value={text} onChange={e => { setText(e.target.value); setSaved(false); }}
        spellCheck={false}
        style={{ flex: 1, resize: "none", border: "none", outline: "none", padding: 16, fontSize: 14, lineHeight: 1.6, background: "transparent", color: ui.text, fontFamily: "'Cascadia Code',Consolas,monospace" }} />
    </div>
  );
}

/* ---- Terminal ---- */
function TerminalApp({ sys, ui }) {
  const [lines, setLines] = useState([{ t: "Aurora Terminal [v1.0]  —  type 'help' for commands.", c: ui.sub }]);
  const [cwd, setCwd] = useState(["This PC", "Documents"]);
  const [input, setInput] = useState("");
  const [hist, setHist] = useState([]); const [hi, setHi] = useState(-1);
  const endRef = useRef(null);
  useEffect(() => { endRef.current?.scrollIntoView(); }, [lines]);
  const prompt = "C:\\" + cwd.join("\\") + ">";

  const run = (raw) => {
    const cmd = raw.trim(); const out = [{ t: prompt + " " + raw, c: ui.text }];
    const [c, ...args] = cmd.split(/\s+/); const arg = args.join(" ");
    const node = getNode(sys.fs, cwd);
    const push = (t, col) => out.push({ t, c: col || ui.text });
    switch (c) {
      case "": break;
      case "help": ["ls / dir   list contents","cd <dir>   change directory","pwd        print path","mkdir <n>  make folder","touch <n>  make file","cat <f>    show file","rm <n>     remove","echo <s>   print","clear      clear screen","date       current time","whoami     current user"].forEach(l => push("  " + l, ui.sub)); break;
      case "ls": case "dir":
        if (node?.children) Object.entries(node.children).forEach(([n, e]) => push((e.type === "folder" ? "<DIR>  " : "       ") + n, e.type === "folder" ? ui.accent : ui.text));
        break;
      case "pwd": push("C:\\" + cwd.join("\\")); break;
      case "cd":
        if (arg === ".." ) { if (cwd.length > 1) setCwd(cwd.slice(0, -1)); }
        else if (arg && node.children?.[arg]?.type === "folder") setCwd([...cwd, arg]);
        else if (arg) push("The system cannot find the path specified.", "#f87171");
        break;
      case "mkdir": if (arg) { sys.setFs(prev => { const cp = structuredClone(prev); getNode(cp, cwd).children[arg] = { type: "folder", children: {} }; return cp; }); } else push("usage: mkdir <name>", ui.sub); break;
      case "touch": if (arg) { sys.setFs(prev => { const cp = structuredClone(prev); getNode(cp, cwd).children[arg] = { type: "file", content: "" }; return cp; }); } else push("usage: touch <name>", ui.sub); break;
      case "cat": { const f = node.children?.[arg]; if (f?.type === "file") (f.content || "(empty)").split("\n").forEach(l => push(l)); else push("File not found.", "#f87171"); break; }
      case "rm": if (node.children?.[arg]) { sys.setFs(prev => { const cp = structuredClone(prev); delete getNode(cp, cwd).children[arg]; return cp; }); } else push("Not found.", "#f87171"); break;
      case "echo": push(arg); break;
      case "clear": setLines([]); return;
      case "date": push(new Date().toString()); break;
      case "whoami": push("aurora\\alex"); break;
      default: push(`'${c}' is not recognized as a command. Try 'help'.`, "#f87171");
    }
    setLines(p => [...p, ...out]);
  };
  const onKey = (e) => {
    if (e.key === "Enter") { run(input); if (input.trim()) { setHist(h => [...h, input]); } setHi(-1); setInput(""); }
    else if (e.key === "ArrowUp") { e.preventDefault(); if (hist.length) { const ni = hi < 0 ? hist.length - 1 : Math.max(0, hi - 1); setHi(ni); setInput(hist[ni]); } }
    else if (e.key === "ArrowDown") { e.preventDefault(); if (hi >= 0) { const ni = hi + 1; if (ni >= hist.length) { setHi(-1); setInput(""); } else { setHi(ni); setInput(hist[ni]); } } }
  };
  return (
    <div onClick={(e) => e.currentTarget.querySelector("input")?.focus()}
      style={{ height: "100%", background: "#0c0c0c", color: "#e5e5e5", fontFamily: "'Cascadia Code',Consolas,monospace", fontSize: 13, padding: 12, overflowY: "auto", lineHeight: 1.5 }}>
      {lines.map((l, i) => <div key={i} style={{ color: l.c, whiteSpace: "pre-wrap" }}>{l.t}</div>)}
      <div style={{ display: "flex" }}>
        <span style={{ color: "#e5e5e5", whiteSpace: "pre" }}>{prompt} </span>
        <input autoFocus value={input} onChange={e => setInput(e.target.value)} onKeyDown={onKey}
          style={{ flex: 1, background: "transparent", border: "none", outline: "none", color: "#e5e5e5", fontFamily: "inherit", fontSize: 13 }} />
      </div>
      <div ref={endRef} />
    </div>
  );
}

/* ---- Browser ---- */
function Browser({ ui }) {
  const home = [
    { name: "Aurora Docs", url: "aurora://docs", desc: "Get started with Aurora OS" },
    { name: "Weather", url: "aurora://weather", desc: "Local forecast" },
    { name: "News", url: "aurora://news", desc: "Top stories" },
  ];
  const [tabs, setTabs] = useState([{ id: 1, title: "New Tab", url: "" }]);
  const [active, setActive] = useState(1);
  const [addr, setAddr] = useState("");
  const tab = tabs.find(t => t.id === active);
  const go = (url) => { setTabs(ts => ts.map(t => t.id === active ? { ...t, url, title: url.replace(/^https?:\/\//, "").split("/")[0] || "New Tab" } : t)); setAddr(url); };
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      {/* tabs */}
      <div style={{ display: "flex", alignItems: "center", gap: 2, padding: "6px 8px 0", background: ui.hover }}>
        {tabs.map(t => (
          <div key={t.id} onClick={() => { setActive(t.id); setAddr(t.url); }}
            style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 12px", borderRadius: "8px 8px 0 0", fontSize: 12.5, maxWidth: 180, cursor: "pointer", background: t.id === active ? ui.glassSolid : "transparent" }}>
            <Globe size={13} /><span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.title}</span>
            {tabs.length > 1 && <X size={13} onClick={(e) => { e.stopPropagation(); setTabs(ts => ts.filter(x => x.id !== t.id)); if (active === t.id) setActive(tabs[0].id); }} />}
          </div>
        ))}
        <div className="aos-btn" onClick={() => { const id = Date.now(); setTabs(ts => [...ts, { id, title: "New Tab", url: "" }]); setActive(id); setAddr(""); }}
          style={{ padding: 6, borderRadius: 6, cursor: "pointer" }}><Plus size={15} /></div>
      </div>
      {/* address bar */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: 8, borderBottom: `1px solid ${ui.border}`, background: ui.glassSolid }}>
        <ChevronLeft size={17} color={ui.sub} /><ChevronRight size={17} color={ui.sub} /><RotateCw size={15} color={ui.sub} />
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 8, background: ui.hover, borderRadius: 18, padding: "7px 14px" }}>
          <Search size={14} color={ui.sub} />
          <input value={addr} onChange={e => setAddr(e.target.value)} onKeyDown={e => e.key === "Enter" && go(addr.includes(".") || addr.includes("://") ? addr : "https://www.google.com/search?q=" + encodeURIComponent(addr))}
            placeholder="Search or enter address" style={{ flex: 1, border: "none", background: "transparent", outline: "none", color: ui.text, fontSize: 13 }} />
        </div>
      </div>
      {/* content */}
      <div style={{ flex: 1, overflow: "auto", background: ui.theme === "dark" ? "#16181d" : "#fff" }}>
        {!tab?.url ? (
          <div style={{ padding: 40, textAlign: "center" }}>
            <div style={{ fontSize: 30, fontWeight: 300, marginBottom: 6 }}>Aurora Edge</div>
            <div style={{ color: ui.sub, fontSize: 13, marginBottom: 30 }}>Your browser, reimagined.</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(140px,1fr))", gap: 12, maxWidth: 520, margin: "0 auto" }}>
              {home.map(h => (
                <div key={h.url} className="aos-btn" onClick={() => go(h.url)} style={{ padding: 16, borderRadius: 12, cursor: "pointer", border: `1px solid ${ui.border}`, textAlign: "left" }}>
                  <Globe size={20} color={ui.accent} style={{ marginBottom: 8 }} />
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{h.name}</div>
                  <div style={{ fontSize: 11.5, color: ui.sub }}>{h.desc}</div>
                </div>
              ))}
            </div>
          </div>
        ) : tab.url.startsWith("aurora://") ? (
          <div style={{ padding: 40 }}>
            <div style={{ fontSize: 24, fontWeight: 400, marginBottom: 10 }}>{tab.url}</div>
            <p style={{ color: ui.sub, fontSize: 13.5, lineHeight: 1.7, maxWidth: 600 }}>
              This is a sandboxed demo page served by Aurora Edge. Real websites can't be embedded here
              because cross‑origin pages block framing — but everything else in the browser (tabs, history,
              the omnibox, new‑tab page) behaves like the real thing.
            </p>
          </div>
        ) : (
          <iframe title="web" src={tab.url} style={{ width: "100%", height: "100%", border: "none", background: "#fff" }}
            sandbox="allow-scripts allow-same-origin" />
        )}
      </div>
    </div>
  );
}

/* ---- Settings ---- */
function Settings({ sys, ui }) {
  const [page, setPage] = useState("personalization");
  const pages = [
    { id: "personalization", label: "Personalization", icon: <Palette size={16} /> },
    { id: "display", label: "Display", icon: <Monitor size={16} /> },
    { id: "system", label: "System", icon: <Cpu size={16} /> },
    { id: "about", label: "About", icon: <Activity size={16} /> },
  ];
  return (
    <div style={{ display: "flex", height: "100%", fontSize: 13 }}>
      <div style={{ width: 190, borderRight: `1px solid ${ui.border}`, padding: 10, flexShrink: 0 }}>
        <div style={{ fontWeight: 600, fontSize: 15, padding: "6px 8px 14px" }}>Settings</div>
        {pages.map(p => (
          <div key={p.id} className="aos-btn" onClick={() => setPage(p.id)}
            style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 10px", borderRadius: 7, cursor: "pointer", marginBottom: 2,
              background: page === p.id ? ui.hover : "transparent", borderLeft: page === p.id ? `3px solid ${ui.accent}` : "3px solid transparent" }}>
            {p.icon}{p.label}
          </div>
        ))}
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: 24 }}>
        {page === "personalization" && (
          <>
            <H>Personalization</H>
            <Label ui={ui}>Background</Label>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(120px,1fr))", gap: 10, marginBottom: 24 }}>
              {sys.wallpapers.map(w => (
                <div key={w.id} onClick={() => sys.setWallpaper(w)} style={{ cursor: "pointer" }}>
                  <div style={{ height: 70, borderRadius: 8, background: w.css, border: sys.wallpaper.id === w.id ? `2px solid ${ui.accent}` : `2px solid transparent`, boxShadow: "0 2px 8px rgba(0,0,0,.2)" }} />
                  <div style={{ fontSize: 11.5, textAlign: "center", marginTop: 4, color: ui.sub }}>{w.name}</div>
                </div>
              ))}
            </div>
            <Label ui={ui}>Accent color</Label>
            <div style={{ display: "flex", gap: 10, marginBottom: 24, flexWrap: "wrap" }}>
              {sys.accents.map(a => (
                <div key={a.id} onClick={() => sys.setAccent(a.v)} style={{ width: 34, height: 34, borderRadius: "50%", background: a.v, cursor: "pointer", border: sys.accent === a.v ? "3px solid #fff" : "3px solid transparent", boxShadow: sys.accent === a.v ? `0 0 0 2px ${a.v}` : "0 2px 6px rgba(0,0,0,.25)" }} />
              ))}
            </div>
            <Label ui={ui}>Theme</Label>
            <div style={{ display: "flex", gap: 10 }}>
              {["light", "dark"].map(t => (
                <div key={t} onClick={() => sys.setTheme(t)} className="aos-btn"
                  style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 18px", borderRadius: 8, cursor: "pointer", border: sys.theme === t ? `2px solid ${ui.accent}` : `1px solid ${ui.border}`, textTransform: "capitalize" }}>
                  {t === "dark" ? <Moon size={15} /> : <Sun size={15} />}{t}
                </div>
              ))}
            </div>
          </>
        )}
        {page === "display" && (
          <>
            <H>Display</H>
            <Label ui={ui}>Desktop icon size — {sys.iconSize}px</Label>
            <input type="range" min="56" max="104" value={sys.iconSize} onChange={e => sys.setIconSize(+e.target.value)} style={{ width: 280, accentColor: ui.accent, marginBottom: 24, display: "block" }} />
            <Label ui={ui}>Taskbar position</Label>
            <div style={{ display: "flex", gap: 10 }}>
              {["bottom", "top"].map(t => (
                <div key={t} onClick={() => sys.setTaskbarPos(t)} className="aos-btn" style={{ padding: "10px 18px", borderRadius: 8, cursor: "pointer", textTransform: "capitalize", border: sys.taskbarPos === t ? `2px solid ${ui.accent}` : `1px solid ${ui.border}` }}>{t}</div>
              ))}
            </div>
          </>
        )}
        {page === "system" && (
          <>
            <H>System</H>
            <Row ui={ui} k="Device name" v="AURORA-PC" />
            <Row ui={ui} k="Processor" v="Aurora Virtual CPU @ 3.20 GHz" />
            <Row ui={ui} k="Installed RAM" v="16.0 GB" />
            <Row ui={ui} k="System type" v="64‑bit operating system" />
            <div style={{ marginTop: 16 }}><button className="aos-btn" onClick={() => sys.openApp("taskmgr")} style={{ padding: "9px 16px", borderRadius: 8, border: `1px solid ${ui.border}`, background: "transparent", color: ui.text, cursor: "pointer" }}>Open Task Manager</button></div>
          </>
        )}
        {page === "about" && (
          <>
            <H>About Aurora OS</H>
            <p style={{ color: ui.sub, fontSize: 13.5, lineHeight: 1.7, maxWidth: 560 }}>
              Aurora OS is a desktop environment that runs entirely in your browser — windows, a file system,
              a terminal, settings, and apps, with no installation. Edition: Aurora OS Pro. Version 1.0
              (Build 2026.06). Everything you see is React.
            </p>
          </>
        )}
      </div>
    </div>
  );
}
const H = ({ children }) => <div style={{ fontSize: 22, fontWeight: 600, marginBottom: 22 }}>{children}</div>;
const Label = ({ children, ui }) => <div style={{ fontSize: 12.5, fontWeight: 600, color: ui.sub, marginBottom: 10 }}>{children}</div>;
const Row = ({ k, v, ui }) => <div style={{ display: "flex", justifyContent: "space-between", padding: "11px 0", borderBottom: `1px solid ${ui.border}`, fontSize: 13 }}><span style={{ color: ui.sub }}>{k}</span><span>{v}</span></div>;

/* ---- Calculator ---- */
function CalculatorApp({ ui }) {
  const [disp, setDisp] = useState("0");
  const [prev, setPrev] = useState(null); const [op, setOp] = useState(null); const [fresh, setFresh] = useState(false);
  const input = (d) => { if (fresh) { setDisp(d === "." ? "0." : d); setFresh(false); } else { if (d === "." && disp.includes(".")) return; setDisp(disp === "0" && d !== "." ? d : disp + d); } };
  const applyOp = (o) => { if (op && prev !== null && !fresh) equals(); setPrev(parseFloat(disp)); setOp(o); setFresh(true); };
  const equals = () => { if (op === null || prev === null) return; const a = prev, b = parseFloat(disp); let r = 0;
    if (op === "+") r = a + b; else if (op === "−") r = a - b; else if (op === "×") r = a * b; else if (op === "÷") r = b === 0 ? NaN : a / b;
    setDisp(String(+r.toFixed(10))); setPrev(null); setOp(null); setFresh(true); };
  const clear = () => { setDisp("0"); setPrev(null); setOp(null); setFresh(false); };
  const keys = [["C","±","%","÷"],["7","8","9","×"],["4","5","6","−"],["1","2","3","+"],["0",".","="]];
  const press = (k) => {
    if (k === "C") clear(); else if (k === "=") equals(); else if ("÷×−+".includes(k)) applyOp(k);
    else if (k === "±") setDisp(String(parseFloat(disp) * -1)); else if (k === "%") setDisp(String(parseFloat(disp) / 100));
    else input(k);
  };
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", padding: 12 }}>
      <div style={{ flex: "0 0 auto", textAlign: "right", padding: "20px 16px", fontSize: 40, fontWeight: 300, overflow: "hidden", minHeight: 70 }}>{disp}</div>
      <div style={{ flex: 1, display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 6 }}>
        {keys.flat().map((k, i) => {
          const isOp = "÷×−+=".includes(k); const wide = k === "0";
          return (
            <button key={i} className="aos-btn" onClick={() => press(k)}
              style={{ gridColumn: wide ? "span 2" : "span 1", border: "none", borderRadius: 10, fontSize: 18, cursor: "pointer",
                background: isOp ? ui.accent : ui.hover, color: isOp ? "#fff" : ui.text, fontWeight: 500 }}>{k}</button>
          );
        })}
      </div>
    </div>
  );
}

/* ---- Task Manager ---- */
function TaskManager({ ui, sys }) {
  const [tick, setTick] = useState(0);
  useEffect(() => { const t = setInterval(() => setTick(x => x + 1), 1500); return () => clearInterval(t); }, []);
  const procs = useMemo(() => ([
    { name: "Aurora Desktop", cpu: 2 + Math.random() * 4, mem: 180 + Math.random() * 40 },
    { name: "Aurora Edge", cpu: 4 + Math.random() * 10, mem: 320 + Math.random() * 80 },
    { name: "File Explorer", cpu: Math.random() * 2, mem: 90 + Math.random() * 20 },
    { name: "Terminal", cpu: Math.random() * 1.5, mem: 40 + Math.random() * 15 },
    { name: "System", cpu: 1 + Math.random() * 2, mem: 140 + Math.random() * 30 },
  ]), [tick]);
  const totalCpu = Math.min(99, procs.reduce((a, p) => a + p.cpu, 0)).toFixed(0);
  const totalMem = (procs.reduce((a, p) => a + p.mem, 0) / 1024 * 100).toFixed(0);
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", fontSize: 13 }}>
      <div style={{ display: "flex", gap: 12, padding: 14, borderBottom: `1px solid ${ui.border}` }}>
        <Gauge2 ui={ui} icon={<Cpu size={16} />} label="CPU" v={totalCpu} unit="%" />
        <Gauge2 ui={ui} icon={<MemoryStick size={16} />} label="Memory" v={totalMem} unit="%" />
      </div>
      <div style={{ flex: 1, overflowY: "auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 80px 90px", padding: "8px 16px", fontSize: 11.5, color: ui.sub, fontWeight: 600, borderBottom: `1px solid ${ui.border}` }}>
          <span>Name</span><span style={{ textAlign: "right" }}>CPU</span><span style={{ textAlign: "right" }}>Memory</span>
        </div>
        {procs.map((p, i) => (
          <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr 80px 90px", padding: "10px 16px", borderBottom: `1px solid ${ui.border}` }}>
            <span>{p.name}</span>
            <span style={{ textAlign: "right", color: p.cpu > 8 ? "#f59e0b" : ui.text }}>{p.cpu.toFixed(1)}%</span>
            <span style={{ textAlign: "right", color: ui.sub }}>{p.mem.toFixed(0)} MB</span>
          </div>
        ))}
      </div>
    </div>
  );
}
function Gauge2({ ui, icon, label, v, unit }) {
  return (
    <div style={{ flex: 1, background: ui.hover, borderRadius: 10, padding: 14 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, color: ui.sub, fontSize: 12, marginBottom: 8 }}>{icon}{label}</div>
      <div style={{ fontSize: 26, fontWeight: 600, color: ui.accent }}>{v}{unit}</div>
      <div style={{ height: 5, background: ui.border, borderRadius: 3, marginTop: 8, overflow: "hidden" }}>
        <div style={{ width: `${v}%`, height: "100%", background: ui.accent, transition: "width .6s" }} />
      </div>
    </div>
  );
}

/* ---- Photos (simple) ---- */
function Photos({ ui }) {
  const grad = ["linear-gradient(135deg,#667eea,#764ba2)","linear-gradient(135deg,#f093fb,#f5576c)","linear-gradient(135deg,#4facfe,#00f2fe)","linear-gradient(135deg,#43e97b,#38f9d7)","linear-gradient(135deg,#fa709a,#fee140)","linear-gradient(135deg,#30cfd0,#330867)"];
  const [sel, setSel] = useState(null);
  return (
    <div style={{ height: "100%", overflow: "auto", padding: 12 }}>
      {sel === null ? (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(120px,1fr))", gap: 8 }}>
          {grad.map((g, i) => <div key={i} onClick={() => setSel(i)} style={{ aspectRatio: "1", borderRadius: 10, background: g, cursor: "pointer" }} />)}
        </div>
      ) : (
        <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
          <div className="aos-btn" onClick={() => setSel(null)} style={{ alignSelf: "flex-start", padding: "6px 12px", borderRadius: 6, cursor: "pointer", marginBottom: 8 }}>← Back</div>
          <div style={{ flex: 1, borderRadius: 12, background: grad[sel] }} />
        </div>
      )}
    </div>
  );
}

/* ============================================================
   APP REGISTRY
   ============================================================ */
const APP_DEFS = {
  explorer: { title: "File Explorer", iconCmp: Folder,       bg: "linear-gradient(135deg,#f7c948,#f0932b)", icon: Folder,      w: 820, h: 540, single: false },
  notepad:  { title: "Notepad",       iconCmp: FileText,     bg: "linear-gradient(135deg,#60a5fa,#2563eb)", icon: FileText,    w: 640, h: 480 },
  terminal: { title: "Terminal",      iconCmp: TermIcon,     bg: "linear-gradient(135deg,#1f2937,#374151)", icon: TermIcon,    w: 720, h: 460 },
  browser:  { title: "Aurora Edge",   iconCmp: Globe,        bg: "linear-gradient(135deg,#38bdf8,#3b82f6)", icon: Globe,       w: 900, h: 600, single: true },
  settings: { title: "Settings",      iconCmp: SettingsIcon, bg: "linear-gradient(135deg,#94a3b8,#64748b)", icon: SettingsIcon,w: 760, h: 540, single: true },
  calc:     { title: "Calculator",    iconCmp: CalcIcon,     bg: "linear-gradient(135deg,#a78bfa,#7c3aed)", icon: CalcIcon,    w: 320, h: 460, single: true },
  taskmgr:  { title: "Task Manager",  iconCmp: Activity,     bg: "linear-gradient(135deg,#34d399,#059669)", icon: Activity,    w: 540, h: 480, single: true },
  photos:   { title: "Photos",        iconCmp: ImageIcon,    bg: "linear-gradient(135deg,#fb7185,#e11d48)", icon: ImageIcon,   w: 640, h: 500, single: true },
};
