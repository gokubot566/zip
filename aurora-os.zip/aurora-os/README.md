# Aurora OS — a Windows‑like desktop in the browser

A polished desktop environment built with **React 18 + Vite**: animated boot, login & lock
screens, a full window manager (drag, resize, minimize, maximize, snap, focus/z‑index,
taskbar integration), a centered Fluent‑style taskbar, an acrylic Start menu with search,
an Action Center, a calendar flyout, notifications, light/dark themes, accent colors, and
several working apps over an in‑memory virtual file system.

**Apps:** File Explorer · Notepad · Terminal · Aurora Edge (browser) · Settings ·
Calculator · Task Manager · Photos.

> State is in‑memory and resets on reload (no backend, no database).

## Run locally (dev)
```bash
npm install
npm run dev          # http://localhost:5173
```

## Build static site
```bash
npm install
npm run build        # outputs dist/
npm run preview      # serve the build at http://localhost:4173
```

## Run with Docker
```bash
docker compose up --build
# open http://localhost:8333
```
or plain Docker:
```bash
docker build -t aurora-os .
docker run -p 8333:8333 aurora-os
# open http://localhost:8333
```

## Keyboard
- **Win / Ctrl+Esc** — toggle Start menu
- **Alt+F4** — close focused window
- Drag a window to a screen edge to **snap** (left / right / maximize)

## Tech
React 18 · Vite 5 · lucide‑react · nginx (Docker). Single‑component app in
`src/AuroraOS.jsx`.
