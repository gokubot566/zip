import React from 'react';
import AppShell from './shared/AppShell.jsx';
import { Section, Tip, Warn, Alert, Def, Quiz } from './shared/kit.jsx';
import { ReportBuilder, FindingsWriter, GoodBad } from './shared/reportbuilder.jsx';
import { FileText, ListChecks, Users, Scale, Camera, GitBranch, Eye, ClipboardCheck } from 'lucide-react';

const byteSteps = [
  { module: 'WELCOME', title: 'The report is the deliverable', body: 'I\u2019m Byte. In <b>Basic Forensic Reporting</b> you\u2019ll learn to turn findings into a clear, defensible report \u2014 the thing decision-makers and courts actually read. Brilliant analysis nobody can follow is wasted. Tap <span class="hl">Next</span> or scroll.' },
  { module: 'SECTION 01', title: 'Why we report', body: 'Start with the <b>purpose</b> of forensic reporting and who reads it. A report communicates what happened, how you know, and what it means \u2014 to technical <i>and</i> non-technical audiences.' },
  { module: 'SECTION 02', title: 'The standard structure', body: 'Learn the <b>report structure</b> \u2014 executive summary, scope, methodology, evidence, analysis, findings, timeline, conclusions, recommendations, appendices. Then drag evidence into the right sections.', actionLock: 'Place the evidence into the correct report sections' },
  { module: 'SECTION 03', title: 'Write it well', body: '<b>Objectivity</b> and clear writing are everything: state facts, avoid assumptions, write for two audiences. Compare a weak finding with a strong one, then write your own.', actionLock: 'Write a strong finding that passes the check' },
  { module: 'SECTION 04', title: 'Custody & appendices', body: 'Finish the craft: <b>chain-of-custody documentation</b>, handling screenshots and evidence, and what belongs in <b>appendices</b>.' },
  { module: 'EXAM', title: 'Final exam', body: 'Last step \u2014 the <b>graded exam</b>, 70% to earn your certificate and complete the foundation track. You\u2019re nearly there.', actionLock: 'Pass the exam to complete the module' },
];
const badges = [
  { id: 'structure', label: 'Report Architect' },
  { id: 'findings', label: 'Clear Writer' },
  { id: 'exam', label: 'Certified Reporter' },
];

export default function App() {
  const sections = [
    { id: 's1', render: () => (
      <Section n={1} tag="Purpose" title="Why Forensic Reporting Matters" id="s1">
        <p>The <strong>report is the deliverable</strong>. All the acquisition discipline and analysis in the world is worthless if the findings can\u2019t be understood, trusted, and acted on. A forensic report communicates <em>what happened, how you know it, and what it means</em> \u2014 in a form that survives scrutiny.</p>
        <h3>What a good report achieves</h3>
        <ul>
          <li><strong>Communicates clearly</strong> to both technical responders and non-technical decision-makers.</li>
          <li><strong>Is defensible</strong> \u2014 every claim is backed by cited evidence and a repeatable method.</li>
          <li><strong>Supports a decision</strong> \u2014 containment, discipline, or legal action.</li>
          <li><strong>Stands alone</strong> \u2014 a reader who wasn\u2019t there can follow it end to end.</li>
        </ul>
        <Def term="Audience">Forensic reports usually serve two readers at once: executives who need the bottom line, and technical staff who need the detail. Good structure serves both without making either wade through the other\u2019s section.</Def>
        <Quiz title="Quick check · Purpose" questions={[
          { q: 'Why is the report considered the real deliverable of an investigation?', options: ['It is the longest document', 'Findings only have value if they can be understood, trusted, and acted on', 'It is required for billing', 'It replaces the evidence'], correct: 1, explain: 'Analysis that can\u2019t be communicated or defended cannot drive a decision.' },
          { q: 'A forensic report typically serves:', options: ['Only lawyers', 'Both technical and non-technical audiences', 'Only the analyst', 'Only auditors'], correct: 1, explain: 'It must speak to executives and technical staff alike.' },
        ]} />
      </Section>
    ) },

    { id: 's2', render: ({ earnBadge }) => (
      <Section n={2} tag="Structure" title="Report Structure" id="s2">
        <p>Forensic reports follow a conventional structure so any reader knows where to find what they need. Each section has one job.</p>
        <div className="cards">
          <div className="card"><div className="ic"><Eye size={18} /></div><h4>Executive summary</h4><p>The bottom line in plain language: what happened, impact, what to do. Written for leadership.</p></div>
          <div className="card"><div className="ic"><ListChecks size={18} /></div><h4>Scope</h4><p>What was \u2014 and was not \u2014 examined, and the authority for doing so.</p></div>
          <div className="card"><div className="ic"><GitBranch size={18} /></div><h4>Methodology</h4><p>Tools and steps used, so the work is repeatable and defensible.</p></div>
          <div className="card"><div className="ic"><Camera size={18} /></div><h4>Evidence collected</h4><p>Each item, its source, acquisition hash, and custody reference.</p></div>
          <div className="card"><div className="ic"><FileText size={18} /></div><h4>Analysis & findings</h4><p>What the evidence shows, each finding tied to its source.</p></div>
          <div className="card"><div className="ic"><Scale size={18} /></div><h4>Conclusions & recommendations</h4><p>What it means and what to do next \u2014 separated from raw findings.</p></div>
        </div>
        <p>A full report also includes a <strong>timeline of events</strong>, <strong>indicators of compromise</strong>, <strong>technical observations</strong>, and <strong>appendices</strong> (full logs, hash lists, custody forms).</p>
        <h3>Interactive · Build the report \u2014 drag evidence into the right section</h3>
        <ReportBuilder
          prompt="Drag each item into the report section where it belongs."
          onSolved={() => earnBadge('structure')}
          sections={[
            { id: 'exec', label: 'Executive Summary' },
            { id: 'method', label: 'Methodology' },
            { id: 'evidence', label: 'Evidence Collected' },
            { id: 'findings', label: 'Findings' },
            { id: 'appendix', label: 'Appendices' },
          ]}
          bank={[
            { id: 'b1', label: '\u201CAttacker accessed 3 hosts; no customer data confirmed exfiltrated.\u201D', section: 'exec' },
            { id: 'b2', label: 'FTK Imager 4.7; Autopsy 4.21; analysis on verified E01 image', section: 'method' },
            { id: 'b3', label: 'Disk image WKST-14.E01 \u2014 SHA-256 a91f\u2026, custody #DF-7', section: 'evidence' },
            { id: 'b4', label: 'powershell.exe -enc executed at 02:14 spawning from cmd.exe', section: 'findings' },
            { id: 'b5', label: 'Full 4,200-line authentication log export', section: 'appendix' },
            { id: 'b6', label: 'Complete SHA-256 hash list for all 6 evidence items', section: 'appendix' },
          ]}
        />
        <Quiz title="Quick check · Structure" questions={[
          { q: 'Where does the plain-language bottom line for leadership go?', options: ['Appendices', 'Executive summary', 'Methodology', 'Evidence collected'], correct: 1, explain: 'The executive summary gives non-technical readers the key outcome up front.' },
          { q: 'A full 4,000-line raw log export belongs in:', options: ['The executive summary', 'The appendices', 'The scope', 'The conclusions'], correct: 1, explain: 'Bulk raw data goes in appendices so the body stays readable.' },
        ]} />
      </Section>
    ) },

    { id: 's3', render: ({ earnBadge }) => (
      <Section n={3} tag="Craft" title="Objectivity & Writing Findings" id="s3">
        <p>How you write is as important as what you found. Findings must be <strong>objective</strong>: state what the evidence shows, cite it, and resist the urge to speculate or assume.</p>
        <h3>The rules of a good finding</h3>
        <ul>
          <li><strong>State the fact</strong>, not your feeling about it.</li>
          <li><strong>Cite the evidence</strong> \u2014 timestamp, host, log, or hash.</li>
          <li><strong>Avoid assumptions</strong> \u2014 no \u201Cprobably\u201D, \u201Cobviously\u201D, \u201CI think\u201D.</li>
          <li><strong>Separate fact from interpretation</strong> \u2014 conclusions belong in their own section.</li>
        </ul>
        <h3>Good vs weak \u2014 the same finding, two ways</h3>
        <GoodBad
          prompt="Toggle between a weak and a strong version of the same finding."
          bad={'<span class="bad">The attacker was obviously trying to steal data and probably got in through a phishing email. The admin account was definitely compromised and they were clearly after customer records.</span>'}
          good={'At <span class="hl">02:14:11 UTC</span> the <span class="hl">admin</span> account authenticated from <span class="hl">203.0.113.9</span> following 18 failed attempts (auth.log lines 412\u2013430). At 02:19:55 a 1.8&nbsp;GB outbound transfer to 185.62.44.10 was recorded (firewall log, exhibit DF-9). The volume and timing are consistent with data exfiltration; attribution of intent is outside the scope of this report.'}
        />
        <Warn><b>Notice the difference:</b> the weak version is full of <i>obviously</i>, <i>probably</i>, <i>definitely</i>, <i>clearly</i> \u2014 assumptions with no citation. The strong version states timed, sourced facts and flags interpretation as interpretation.</Warn>
        <h3>Interactive · Write your own finding</h3>
        <FindingsWriter
          prompt={'You observed: at 02:14 UTC the admin account logged in after many failed attempts from IP 203.0.113.9. Write this as one objective finding. Reference the time and the IP, and avoid speculation words.'}
          mustInclude={['02:14', '203.0.113.9']}
          avoid={['probably', 'maybe', 'i think', 'obviously', 'definitely', 'clearly']}
          sample={'At 02:14 UTC the admin account successfully authenticated from 203.0.113.9 following multiple failed attempts, consistent with a successful brute-force login.'}
          onSolved={() => earnBadge('findings')}
        />
        <Quiz title="Quick check · Craft" questions={[
          { q: 'Which phrasing belongs in an objective finding?', options: ['\u201CThe attacker was obviously after money.\u201D', '\u201Cadmin authenticated from 203.0.113.9 at 02:14 UTC after 18 failures (auth.log).\u201D', '\u201CThey probably used phishing.\u201D', '\u201CI think the server was hacked.\u201D'], correct: 1, explain: 'A finding states a timed, sourced fact \u2014 not speculation.' },
          { q: 'Where should your interpretation of <i>why</i> the attack happened go?', options: ['Mixed into the findings as fact', 'In the conclusions, clearly marked as interpretation', 'Nowhere', 'In the evidence list'], correct: 1, explain: 'Keep fact and interpretation separate; conclusions are clearly labelled as such.' },
        ]} />
      </Section>
    ) },

    { id: 's4', render: () => (
      <Section n={4} tag="Evidence" title="Custody Documentation, Screenshots & Appendices" id="s4">
        <p>The final craft of reporting is handling evidence references properly so the report is verifiable and complete.</p>
        <h3>Chain-of-custody documentation</h3>
        <p>Every evidence item referenced in the report should tie back to a custody record: its unique exhibit number, acquisition hash, who collected it, and where it\u2019s stored. This lets any reader verify the evidence is what you say it is.</p>
        <div className="codeblock"><span className="cmt"># Evidence reference as it appears in a report</span>
Exhibit:   <span className="hl">DF-7</span>
Source:    WKST-NC-14 system disk (live, write-blocked)
Image:     WKST-14.E01
SHA-256:   <span className="hl">a91f3c\u2026e4d2</span>  (verified at acquisition and analysis)
Custodian: A. Okafor \u2192 evidence locker B, 2025-05-14</div>
        <h3>Screenshots and evidence handling</h3>
        <ul>
          <li><strong>Caption every screenshot</strong> \u2014 what it shows, its source, and a figure number.</li>
          <li><strong>Never alter</strong> a screenshot to make a point; annotate with callouts instead.</li>
          <li><strong>Reference the underlying evidence</strong> a screenshot was taken from, so it can be reproduced.</li>
        </ul>
        <h3>Appendices</h3>
        <p>Appendices hold the bulk material that supports the body but would clutter it: full log exports, complete hash lists, custody forms, tool version details, and IOC tables. The body <em>summarises and cites</em>; the appendix <em>holds the full record</em>.</p>
        <Tip>A good test: a technical peer should be able to take your report plus its appendices and <b>reproduce your work</b> without asking you a single question.</Tip>
        <Quiz title="Quick check · Evidence" questions={[
          { q: 'A screenshot in a report should always be:', options: ['Edited to highlight guilt', 'Captioned with what it shows and its source, and left unaltered', 'Removed before submission', 'Taken from memory'], correct: 1, explain: 'Caption and source make it verifiable; never alter the image itself.' },
          { q: 'What primarily belongs in the appendices?', options: ['The executive summary', 'Bulk supporting material \u2014 full logs, hash lists, custody forms', 'The conclusions', 'The scope'], correct: 1, explain: 'Appendices hold the complete record that the body summarises and cites.' },
        ]} />
      </Section>
    ) },
  ];

  const examQuestions = [
    { q: 'Which statement is written objectively enough for a findings section?', options: ['\u201CThe attacker was clearly a professional.\u201D', '\u201Cpowershell.exe -enc ran at 02:14 UTC, spawned by cmd.exe (endpoint log, exhibit DF-4).\u201D', '\u201CThey probably wanted money.\u201D', '\u201CIt was obviously an inside job.\u201D'], correct: 1, explain: 'A finding states a timed, sourced fact and avoids speculation.' },
    { q: 'The plain-language outcome for company leadership belongs in the:', options: ['Appendices', 'Executive summary', 'Methodology', 'IOC table'], correct: 1, explain: 'Leadership reads the executive summary for the bottom line.' },
    { q: 'Why document tools and steps in a methodology section?', options: ['To fill space', 'So the analysis is repeatable and defensible', 'To advertise the tools', 'It is optional'], correct: 1, explain: 'Repeatability is what makes findings defensible.' },
    { q: 'A 4,000-line raw log export should be placed in the:', options: ['Executive summary', 'Appendices', 'Conclusions', 'Scope'], correct: 1, explain: 'Bulk raw data goes in appendices to keep the body readable.' },
    { q: 'Which word is a red flag in a findings statement?', options: ['Authenticated', 'Probably', 'Recorded', 'Observed'], correct: 1, explain: '\u201CProbably\u201D signals speculation \u2014 findings state what evidence shows.' },
    { q: 'An evidence item in the report should reference:', options: ['Only its filename', 'Its exhibit number, source, acquisition hash, and custodian', 'The analyst\u2019s opinion', 'Nothing'], correct: 1, explain: 'A full custody reference makes the evidence verifiable.' },
    { q: 'Where does your interpretation of attacker <i>intent</i> belong?', options: ['In the findings as fact', 'In the conclusions, marked as interpretation', 'In the evidence list', 'In the hash list'], correct: 1, explain: 'Separate fact (findings) from interpretation (conclusions).' },
    { q: 'The best test of a complete report is that a technical peer can:', options: ['Read it in one minute', 'Reproduce the work from the report and appendices alone', 'Skip the appendices', 'Guess the conclusion'], correct: 1, explain: 'Self-sufficiency and reproducibility are the marks of a strong report.' },
  ];

  const meta = {
    case: 'CASE #DFIR-103',
    eyebrow: 'Module 3 · DFIR Foundation Track',
    title: 'Basic Forensic <span class="accent">Reporting</span>',
    lede: 'Turn findings into a clear, objective, defensible report \u2014 structure it well, write findings that hold up, and document evidence properly, hands-on with Byte.',
    stats: [{ n: '4', label: 'Sections' }, { n: '2', label: 'Interactive labs' }, { n: '8Q', label: 'Final exam' }, { n: '~60m', label: 'Duration' }],
    byteName: 'Forensic Reporting',
  };

  return <AppShell meta={meta} sections={sections} byteSteps={byteSteps} badges={badges} storeKey="dfir-m3"
    exam={examQuestions} examTag="Write it up" certModule="Basic Forensic Reporting" />;
}
