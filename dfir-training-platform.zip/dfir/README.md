# Security Impossible — DFIR Foundation Track

Three standalone, interactive web-based training apps for a beginner Digital
Forensics & Incident Response course. Each module is its own Dockerised
application with a dark, forensic-lab UI, a floating mentor (**Byte**) that
walks students through the lab step by step, per-section knowledge checks, a
graded end-of-module exam, achievement badges, and a completion certificate.

| Module | Topic | Port | Signature interactives |
|--------|-------|------|------------------------|
| 1 | Digital Forensics Basics | **6261** | Evidence classification (drag-drop), chain-of-custody ordering, order-of-volatility sort, live hash-tamper demo |
| 2 | Basic Log Analysis | **6262** | Searchable/filterable log explorer (flag suspicious lines), match-events-to-attack-stages |
| 3 | Basic Forensic Reporting | **6263** | Drag-evidence report builder, findings writer (objectivity checker), good-vs-bad examples |

## Run everything (recommended)

From this directory:

```bash
docker compose up -d --build
```

Then open:

- Module 1 · Digital Forensics Basics → http://localhost:6261
- Module 2 · Basic Log Analysis → http://localhost:6262
- Module 3 · Basic Forensic Reporting → http://localhost:6263

Stop with `docker compose down`. All three containers use
`restart: unless-stopped`, so they come back automatically after a host reboot.

## Run a single module

```bash
cd m1-basics            # or m2-logs / m3-reporting
docker build -t si-dfir-basics .
docker run -d --restart unless-stopped -p 6261:80 si-dfir-basics
```

## Local development (no Docker)

```bash
cd m1-basics
npm install
npm run dev             # Vite dev server on the module's port
```

## Stack

- **React 18 + Vite** single-page app per module
- **framer-motion** + **lucide-react** for motion and icons
- Multi-stage **Docker** build: `node:20-alpine` (build) → `nginx:1.27-alpine` (serve)
- Nginx serves the static bundle with SPA fallback and a container healthcheck

## Project layout

```
dfir/
├── docker-compose.yml        # all three services, ports 6261-6263
├── m1-basics/                # Module 1 app  (port 6261)
├── m2-logs/                  # Module 2 app  (port 6262)
├── m3-reporting/             # Module 3 app  (port 6263)
│   ├── Dockerfile
│   ├── nginx.conf
│   ├── index.html
│   ├── vite.config.js
│   └── src/
│       ├── App.jsx           # module content + quizzes + exam
│       ├── main.jsx
│       └── shared/           # shared design system + components
│           ├── theme.css     # "Forensic Lab Bench" design tokens
│           ├── byte.css      # Byte mentor styles
│           ├── components.css
│           ├── Byte.jsx       # floating mentor (drag, snap, step walkthrough)
│           ├── AppShell.jsx   # topbar, progress, hero, exam, certificate
│           ├── kit.jsx        # Section, callouts, Quiz, Classify, Sortable, HashDemo, Certificate
│           ├── logx.jsx       # LogExplorer, MatchStages (Module 2)
│           └── reportbuilder.jsx  # ReportBuilder, FindingsWriter, GoodBad (Module 3)
```

> The `shared/` library is copied into each module so every app is fully
> self-contained and builds independently — no cross-module imports, no
> workspace tooling required.

## Progress & badges

Each module tracks scroll progress, awards badges as students complete the
interactive exercises, and unlocks a completion certificate once the graded
exam is passed (70%). Progress is stored per-module in the browser's
local storage.
