import React from 'react';
import AppShell from './shared/AppShell.jsx';
import { Section, Tip, Warn, Alert, Def, Quiz, Classify, Sortable, HashDemo, Certificate } from './shared/kit.jsx';
import {
  Search, Camera, HardDrive, Cpu, Network, Clock, FileSearch, Scale,
  ShieldCheck, Database, Tag, GitBranch, FlaskConical, Lock, Footprints,
} from 'lucide-react';

/* ============ Byte walkthrough steps ============ */
const byteSteps = [
  { module: 'WELCOME', title: 'Hi, I\u2019m Byte', body: 'I\u2019ll guide you through <b>Digital Forensics Basics</b>. We\u2019ll move through 8 sections \u2014 from what forensics <i>is</i> all the way to the mistakes that get evidence thrown out of court. Tap <span class="hl">Next exercise</span> at the bottom to move through them one at a time, and I\u2019ll guide you through each.' },
  { module: 'SECTION 01', title: 'What forensics really is', body: 'Start with <b>Section 01</b>. Digital forensics isn\u2019t \u201Chacking back\u201D \u2014 it\u2019s the disciplined recovery and analysis of evidence so it holds up later. Read the goals, then try the <span class="hl">evidence classification</span> drag-and-drop.', actionLock: 'Complete the evidence classification to continue' },
  { module: 'SECTION 02', title: 'Handle it right', body: '<b>Chain of custody</b> is who touched the evidence, when, and why \u2014 an unbroken log. Break the chain and the evidence may be inadmissible. Put the custody steps in order in the exercise.', actionLock: 'Order the chain-of-custody steps' },
  { module: 'SECTION 03', title: 'Grab the fragile stuff first', body: 'Evidence has an <b>order of volatility</b>. RAM and network connections vanish on shutdown; a disk survives. Sort the sources from <span class="hl">most</span> to <span class="hl">least</span> volatile.', actionLock: 'Sort the order of volatility' },
  { module: 'SECTION 04', title: 'Live vs dead', body: 'Decide whether to pull data from a <b>running</b> system (live) or a powered-off one (dead). Each has trade-offs \u2014 live captures volatile data but changes the system slightly.' },
  { module: 'SECTION 05', title: 'Prove nothing changed', body: '<b>Hashing</b> is how we prove integrity. Edit one character in the demo and watch every hash avalanche \u2014 that\u2019s how tampering is detected.', actionLock: 'Try tampering in the hash demo' },
  { module: 'SECTION 06', title: 'The investigator\u2019s map', body: 'Most investigations follow the same <b>workflow</b>: identify \u2192 preserve \u2192 collect \u2192 examine \u2192 analyse \u2192 report. Skipping a stage is where cases fall apart.' },
  { module: 'SECTION 07', title: 'Stay out of trouble', body: '<b>Legal and ethical</b> limits define what you may collect and how. Authorisation and objectivity aren\u2019t optional extras \u2014 they\u2019re the job.' },
  { module: 'EXAM', title: 'Final exam', body: 'Last step: the <b>graded exam</b>. You need 70% to earn the module certificate. You\u2019ve got this \u2014 take your time and reason from the evidence.', actionLock: 'Pass the exam to complete the module' },
];

const badges = [
  { id: 'classify', label: 'Evidence Handler' },
  { id: 'custody', label: 'Custody Keeper' },
  { id: 'volatility', label: 'Volatility Sorter' },
  { id: 'hash', label: 'Integrity Checker' },
  { id: 'exam', label: 'Certified Basics' },
];

export default function App() {
  const sections = [
    /* ---------- 01 Introduction + evidence types + classify ---------- */
    { id: 's1', render: ({ earnBadge }) => (
      <Section n={1} tag="Foundations" title="What Is Digital Forensics?" id="s1">
        <p>Digital forensics is the disciplined process of <strong>identifying, preserving, analysing, and presenting</strong> digital evidence in a way that is accurate, repeatable, and defensible. The goal is not simply to <em>find</em> something interesting \u2014 it is to find it in a way that another examiner could reproduce, and that would survive scrutiny in an incident review or a courtroom.</p>
        <h3>Goals of a forensic investigation</h3>
        <ul>
          <li><strong>Reconstruct what happened</strong> \u2014 build an accurate, evidence-backed timeline of events.</li>
          <li><strong>Preserve evidence integrity</strong> \u2014 ensure nothing is altered between collection and analysis.</li>
          <li><strong>Attribute actions</strong> \u2014 link activity to accounts, hosts, or devices where the evidence supports it.</li>
          <li><strong>Support a decision</strong> \u2014 inform containment, disciplinary action, or legal proceedings.</li>
        </ul>
        <h3>Types of digital evidence</h3>
        <div className="cards">
          <div className="card"><div className="ic"><Cpu size={18} /></div><h4>Volatile</h4><p>RAM, running processes, network connections, clipboard. Lost on power-off.</p></div>
          <div className="card"><div className="ic"><HardDrive size={18} /></div><h4>Non-volatile</h4><p>Disk files, databases, logs, deleted data in unallocated space.</p></div>
          <div className="card"><div className="ic"><Network size={18} /></div><h4>Network</h4><p>Packet captures, NetFlow, firewall and proxy records.</p></div>
          <div className="card"><div className="ic"><Tag size={18} /></div><h4>Metadata</h4><p>Timestamps, authorship, GPS, file system records \u2014 data about data.</p></div>
        </div>
        <Def term="Evidence">Any digital artefact that helps establish what happened. Its value depends entirely on how well its integrity and origin can be demonstrated.</Def>

        <h3>Interactive · Evidence classification</h3>
        <Classify
          prompt="Drag each artefact into the category that best describes it."
          items={[
            { id: 'ram', label: 'Contents of RAM' },
            { id: 'pcap', label: 'Packet capture (.pcap)' },
            { id: 'doc', label: 'Saved Word document' },
            { id: 'arp', label: 'ARP / routing table' },
            { id: 'exif', label: 'Photo EXIF timestamp' },
            { id: 'unalloc', label: 'Deleted file in unallocated space' },
          ]}
          bins={[
            { id: 'vol', label: 'Volatile', icon: <Cpu size={13} /> },
            { id: 'nonvol', label: 'Non-volatile', icon: <HardDrive size={13} /> },
            { id: 'net', label: 'Network', icon: <Network size={13} /> },
            { id: 'meta', label: 'Metadata', icon: <Tag size={13} /> },
          ]}
          answer={{ ram: 'vol', pcap: 'net', doc: 'nonvol', arp: 'vol', exif: 'meta', unalloc: 'nonvol' }}
          onSolved={() => earnBadge('classify')}
        />
        <Quiz title="Quick check · Foundations" questions={[
          { q: 'What makes a finding <i>forensically</i> sound rather than just interesting?', options: ['It was found quickly', 'It is reproducible and its integrity can be demonstrated', 'It came from an expensive tool', 'It confirms what we already suspected'], correct: 1, explain: 'Reproducibility and demonstrable integrity are what let a finding withstand scrutiny.' },
          { q: 'Which is <b>volatile</b> evidence?', options: ['A saved PDF', 'Contents of RAM', 'A disk image', 'An archived email'], correct: 1, explain: 'RAM is lost on power-off, so it is volatile and must be captured first if needed.' },
        ]} />
      </Section>
    ) },

    /* ---------- 02 Chain of custody ---------- */
    { id: 's2', render: ({ earnBadge }) => (
      <Section n={2} tag="Handling" title="Chain of Custody" id="s2">
        <p>The <strong>chain of custody</strong> is the documented, unbroken record of everyone who handled a piece of evidence \u2014 <em>who</em> had it, <em>when</em>, <em>why</em>, and <em>what they did with it</em>. It is what lets you prove the evidence presented is the same evidence that was collected, unaltered.</p>
        <Alert><b>Break the chain, lose the evidence.</b> A gap in custody \u2014 an unlabelled drive, an unlogged transfer \u2014 can render otherwise solid evidence inadmissible.</Alert>
        <h3>What every custody record captures</h3>
        <ul>
          <li><strong>Identification</strong> \u2014 a unique evidence/exhibit number and description.</li>
          <li><strong>Collection details</strong> \u2014 who collected it, when, from where.</li>
          <li><strong>Integrity</strong> \u2014 hash values recorded at acquisition.</li>
          <li><strong>Every transfer</strong> \u2014 each hand-off signed and timestamped.</li>
          <li><strong>Storage</strong> \u2014 secure, access-controlled location.</li>
        </ul>
        <h3>Interactive · Put the custody process in order</h3>
        <Sortable
          prompt="Drag these steps into the correct sequence, from first to last."
          labelTop="\u2191 First action"
          labelBottom="\u2193 Last action"
          items={[
            { id: 'transfer', label: 'Log each transfer with a signature and timestamp' },
            { id: 'identify', label: 'Identify and label the evidence with a unique number' },
            { id: 'store', label: 'Store in a secure, access-controlled location' },
            { id: 'collect', label: 'Collect and record who/when/where' },
            { id: 'hash', label: 'Hash the evidence to record its integrity' },
          ]}
          correct={['identify', 'collect', 'hash', 'transfer', 'store']}
          onSolved={() => earnBadge('custody')}
        />
        <Quiz title="Quick check · Custody" questions={[
          { q: 'Why hash evidence at the moment of collection?', options: ['To compress it', 'To create a baseline that proves it hasn\u2019t changed later', 'To encrypt it', 'To delete the original'], correct: 1, explain: 'The acquisition hash is the integrity baseline re-checked before any analysis.' },
          { q: 'A drive is moved between labs but nobody logs the transfer. What is the risk?', options: ['No risk, it\u2019s the same drive', 'The chain of custody is broken and admissibility is threatened', 'The hash changes automatically', 'It must be re-imaged'], correct: 1, explain: 'An unlogged transfer is a gap in custody \u2014 the integrity of the evidence can be challenged.' },
        ]} />
      </Section>
    ) },

    /* ---------- 03 Order of volatility ---------- */
    { id: 's3', render: ({ earnBadge }) => (
      <Section n={3} tag="Acquisition" title="Order of Volatility" id="s3">
        <p>When a system holds several kinds of evidence, you must collect the <strong>most fragile first</strong>. The <em>order of volatility</em> ranks data by how quickly it disappears. Memory and network state vanish the instant a machine is powered off; a hard disk survives for years.</p>
        <Def term="Order of volatility">The sequence in which evidence should be collected, from the most transient (CPU registers, RAM) to the most persistent (archived media), so nothing fragile is lost.</Def>
        <h3>Interactive · Sort most \u2192 least volatile</h3>
        <Sortable
          prompt="Arrange these from the MOST volatile (collect first) to the LEAST volatile."
          labelTop="\u2191 Most volatile \u2014 collect first"
          labelBottom="\u2193 Least volatile \u2014 collect last"
          items={[
            { id: 'disk', label: 'Disk / file system' },
            { id: 'reg', label: 'CPU registers & cache' },
            { id: 'ram', label: 'RAM (running processes)' },
            { id: 'net', label: 'Network connections & ARP cache' },
            { id: 'archive', label: 'Backups / archived media' },
          ]}
          correct={['reg', 'ram', 'net', 'disk', 'archive']}
          onSolved={() => earnBadge('volatility')}
        />
        <Tip>A useful mental model: <b>if pulling the plug would erase it, collect it first.</b></Tip>
        <Quiz title="Quick check · Volatility" questions={[
          { q: 'Which should be collected <b>first</b>?', options: ['Archived backup tapes', 'The hard disk', 'CPU registers and RAM', 'A printed document'], correct: 2, explain: 'Registers and RAM are the most volatile \u2014 lost instantly on power-off.' },
          { q: 'Why does the disk come <i>after</i> network state?', options: ['Disks are bigger', 'Disk data persists through a reboot, network state does not', 'Disks are encrypted', 'Network data is unimportant'], correct: 1, explain: 'Persistent data can wait; transient data cannot.' },
        ]} />
      </Section>
    ) },

    /* ---------- 04 Live vs dead + imaging ---------- */
    { id: 's4', render: () => (
      <Section n={4} tag="Acquisition" title="Live vs Dead Acquisition & Imaging" id="s4">
        <p>There are two ways to acquire evidence from a system, and the choice is a trade-off.</p>
        <div className="cards">
          <div className="card"><div className="ic"><Cpu size={18} /></div><h4>Live acquisition</h4><p>Data captured from a <b>running</b> system. Captures volatile evidence (RAM, connections) but interacting with the system changes it slightly.</p></div>
          <div className="card"><div className="ic"><HardDrive size={18} /></div><h4>Dead acquisition</h4><p>System is <b>powered off</b> and the disk imaged. Cleanest for integrity, but all volatile evidence is already gone.</p></div>
        </div>
        <h3>Forensic imaging</h3>
        <p>A <strong>forensic image</strong> is a bit-for-bit copy of storage \u2014 every sector, including deleted files and unallocated space \u2014 not just the visible files. Analysis is always performed on the <em>image</em>, never the original, and a <strong>write-blocker</strong> prevents any accidental change to the source during acquisition.</p>
        <Def term="Write-blocker">Hardware or software that allows reads from the source media but blocks all writes, guaranteeing the original is never modified during imaging.</Def>
        <Warn><b>Golden rule:</b> never analyse the original. Work from a verified image, and keep the source sealed.</Warn>
        <Quiz title="Quick check · Acquisition" questions={[
          { q: 'You need the contents of RAM. Which acquisition type is required?', options: ['Dead acquisition', 'Live acquisition', 'Either works', 'Neither'], correct: 1, explain: 'RAM only exists on a running system, so live acquisition is required.' },
          { q: 'What does a forensic image include that a normal file copy does not?', options: ['Only the visible files', 'Deleted files and unallocated space', 'Just the operating system', 'Only documents'], correct: 1, explain: 'A bit-for-bit image captures everything on the media, including deleted and slack space.' },
        ]} />
      </Section>
    ) },

    /* ---------- 05 Hashing ---------- */
    { id: 's5', render: ({ earnBadge }) => (
      <Section n={5} tag="Integrity" title="Hashing & Integrity Verification" id="s5">
        <p>A <strong>cryptographic hash</strong> is a fixed-length fingerprint of data. Change a single bit and the hash changes completely \u2014 the <em>avalanche effect</em>. By recording an image\u2019s hash at acquisition and re-computing it before analysis, you prove mathematically that nothing has changed.</p>
        <ul>
          <li><strong>MD5 / SHA-1</strong> \u2014 still widely seen for integrity checks, though deprecated for security uses.</li>
          <li><strong>SHA-256</strong> \u2014 the modern standard; collision-resistant and preferred for new work.</li>
        </ul>
        <h3>Interactive · Watch tampering break the hash</h3>
        <HashDemo onSolved={() => earnBadge('hash')} />
        <Tip>This is exactly how a verified acquisition works: the tool hashes the source and the copy and confirms they <b>match</b>. A later mismatch means the evidence changed.</Tip>
        <Quiz title="Quick check · Hashing" questions={[
          { q: 'If two files have identical SHA-256 hashes, what can you conclude?', options: ['They have the same filename', 'They are bit-for-bit identical in content', 'They were made by the same person', 'Nothing'], correct: 1, explain: 'Matching cryptographic hashes mean the content is identical.' },
          { q: 'You re-hash an image before analysis and it differs from the acquisition hash. What does that mean?', options: ['The image is fine', 'The evidence has been altered since acquisition', 'The hash algorithm is broken', 'You used the wrong filename'], correct: 1, explain: 'A changed hash means changed data \u2014 integrity is no longer assured.' },
        ]} />
      </Section>
    ) },

    /* ---------- 06 Workflow + tools + file systems + metadata + timeline ---------- */
    { id: 's6', render: () => (
      <Section n={6} tag="Method" title="The Investigation Workflow" id="s6">
        <p>Most digital investigations follow the same backbone. Skipping or reordering stages is where cases unravel.</p>
        <div className="cards">
          <div className="card"><div className="ic"><Search size={18} /></div><h4>1 · Identify</h4><p>Scope the incident and locate potential evidence sources.</p></div>
          <div className="card"><div className="ic"><ShieldCheck size={18} /></div><h4>2 · Preserve</h4><p>Protect evidence from change \u2014 isolate, write-block, hash.</p></div>
          <div className="card"><div className="ic"><Camera size={18} /></div><h4>3 · Collect</h4><p>Acquire in volatility order; image disks; log custody.</p></div>
          <div className="card"><div className="ic"><FileSearch size={18} /></div><h4>4 · Examine</h4><p>Recover and extract relevant artefacts from the image.</p></div>
          <div className="card"><div className="ic"><GitBranch size={18} /></div><h4>5 · Analyse</h4><p>Correlate artefacts into a timeline and findings.</p></div>
          <div className="card"><div className="ic"><Scale size={18} /></div><h4>6 · Report</h4><p>Document objectively for technical and non-technical readers.</p></div>
        </div>
        <h3>Supporting concepts you\u2019ll use throughout</h3>
        <Def term="File systems">How storage is organised (NTFS, ext4, APFS, FAT). They hold timestamps and records that survive deletion and drive much of the evidence you recover.</Def>
        <Def term="Metadata">Data about data \u2014 created/modified/accessed times (MAC times), authorship, GPS. Often the most decisive evidence in a timeline.</Def>
        <Def term="Timeline analysis">Ordering events from many sources (file times, logs, network) into one chronological narrative of what happened and when.</Def>
        <h3>Basic forensic tools</h3>
        <ul>
          <li><strong>FTK Imager</strong> \u2014 acquisition and verified imaging.</li>
          <li><strong>Autopsy / The Sleuth Kit</strong> \u2014 disk analysis and artefact extraction.</li>
          <li><strong>Volatility</strong> \u2014 memory (RAM) analysis.</li>
          <li><strong>Wireshark</strong> \u2014 network capture and analysis.</li>
        </ul>
        <Quiz title="Quick check · Method" questions={[
          { q: 'What comes immediately after <b>Identify</b> in the workflow?', options: ['Report', 'Preserve', 'Analyse', 'Delete'], correct: 1, explain: 'Once you know what to collect, you preserve it before anything else can change it.' },
          { q: 'Which tool is used for RAM analysis?', options: ['FTK Imager', 'Volatility', 'Wireshark', 'Autopsy'], correct: 1, explain: 'Volatility is the standard memory-forensics framework.' },
          { q: 'MAC times (modified/accessed/created) are an example of:', options: ['Network evidence', 'Metadata', 'Volatile memory', 'A hash'], correct: 1, explain: 'Timestamps are metadata \u2014 data about the file \u2014 and are central to timeline analysis.' },
        ]} />
      </Section>
    ) },

    /* ---------- 07 Legal/ethical + challenges ---------- */
    { id: 's7', render: () => (
      <Section n={7} tag="Conduct" title="Legal, Ethical & Practical Challenges" id="s7">
        <p>Technical skill is only half the job. Evidence collected without authorisation, or analysed carelessly, can be worthless \u2014 or land the investigator in trouble.</p>
        <h3>Legal and ethical foundations</h3>
        <ul>
          <li><strong>Authorisation</strong> \u2014 have explicit legal authority (warrant, policy, signed scope) before collecting anything.</li>
          <li><strong>Privacy</strong> \u2014 collect only what is in scope; respect data-protection law.</li>
          <li><strong>Objectivity</strong> \u2014 follow the evidence, including where it exonerates. You are a neutral examiner, not a prosecutor.</li>
          <li><strong>Competence</strong> \u2014 use methods you can explain and defend.</li>
        </ul>
        <h3>Common challenges</h3>
        <ul>
          <li><strong>Encryption</strong> \u2014 may block access without keys.</li>
          <li><strong>Anti-forensics</strong> \u2014 wiping, timestomping, and obfuscation.</li>
          <li><strong>Volume & cloud</strong> \u2014 huge datasets and evidence held by third parties.</li>
          <li><strong>Time pressure</strong> \u2014 the urge to skip preservation during an active incident.</li>
        </ul>
        <h3>Mistakes that get evidence thrown out</h3>
        <Alert>
          <div>
            <b>Avoid these at all costs:</b>
            <ul style={{ marginTop: 8 }}>
              <li>Analysing the original instead of a verified image.</li>
              <li>Failing to hash at acquisition (no integrity baseline).</li>
              <li>Gaps or missing signatures in the chain of custody.</li>
              <li>Powering a machine on/off without considering volatile evidence.</li>
              <li>Drawing conclusions the evidence does not support.</li>
            </ul>
          </div>
        </Alert>
        <Quiz title="Quick check · Conduct" questions={[
          { q: 'What must you have <b>before</b> collecting any evidence?', options: ['A faster computer', 'Proper authorisation', 'A signed report', 'A suspect\u2019s password'], correct: 1, explain: 'Authorisation is the legal basis for collection \u2014 without it, evidence may be inadmissible.' },
          { q: 'Being <i>objective</i> means:', options: ['Proving the suspect is guilty', 'Following the evidence wherever it leads, including exculpatory findings', 'Ignoring evidence that complicates the case', 'Working as fast as possible'], correct: 1, explain: 'A forensic examiner is neutral and reports what the evidence shows.' },
        ]} />
      </Section>
    ) },
  ];

  const examQuestions = [
    { q: 'An analyst arrives at a running, compromised workstation. In what order should evidence be collected?', options: ['Disk image first, then RAM', 'RAM and network state first, then disk', 'Only the disk \u2014 RAM is unreliable', 'Backups first'], correct: 1, explain: 'Order of volatility: capture the most transient evidence (RAM, connections) before imaging the persistent disk.' },
    { q: 'Which single practice best proves an image was not altered after acquisition?', options: ['Storing it on an SSD', 'Recording its hash at acquisition and re-verifying later', 'Renaming the file', 'Compressing it'], correct: 1, explain: 'A matching hash before and after demonstrates integrity.' },
    { q: 'A teammate suggests analysing the suspect\u2019s original drive directly to \u201Csave time\u201D. The correct response is:', options: ['Agree \u2014 it is faster', 'Refuse \u2014 always work from a verified, write-blocked image', 'Only if the drive is small', 'Only on weekends'], correct: 1, explain: 'Never analyse the original; work from a verified image to preserve the source.' },
    { q: 'Which of these is <b>metadata</b>?', options: ['The body text of an email', 'A file\u2019s created/modified timestamps', 'The contents of RAM', 'A firewall rule'], correct: 1, explain: 'Timestamps are data about the file \u2014 metadata \u2014 and are key to timelines.' },
    { q: 'An unlogged transfer of an evidence drive between two analysts primarily threatens:', options: ['The file size', 'The chain of custody and admissibility', 'The hash algorithm', 'The network'], correct: 1, explain: 'A gap in custody undermines the ability to prove the evidence is unaltered.' },
    { q: 'Why capture volatile memory at all, given it changes the system slightly?', options: ['It never changes the system', 'Because it contains evidence \u2014 running malware, keys, connections \u2014 that is lost on shutdown', 'To free up RAM', 'It is required by the file system'], correct: 1, explain: 'The evidentiary value of volatile data outweighs the minimal, documented impact of capturing it.' },
    { q: 'Which best describes proper objectivity?', options: ['Reporting only findings that support the theory', 'Reporting all findings the evidence supports, including exculpatory ones', 'Avoiding written reports', 'Letting the tool decide guilt'], correct: 1, explain: 'Objectivity means following the evidence wherever it leads.' },
    { q: 'SHA-256 is preferred over MD5 for new work because it is:', options: ['Shorter', 'More collision-resistant', 'Faster to type', 'Encrypted'], correct: 1, explain: 'SHA-256 is the modern, collision-resistant standard.' },
  ];

  const meta = {
    case: 'CASE #DFIR-101',
    eyebrow: 'Module 1 · DFIR Foundation Track',
    title: 'Digital Forensics <span class="accent">Basics</span>',
    lede: 'Learn how digital evidence is found, preserved, and proven \u2014 the core principles every investigator relies on, taught hands-on with your mentor Byte.',
    stats: [{ n: '7', label: 'Sections' }, { n: '4', label: 'Interactive labs' }, { n: '8Q', label: 'Final exam' }, { n: '~60m', label: 'Duration' }],
    byteName: 'Forensics Basics',
  };

  return (
    <AppShell meta={meta} sections={sections} byteSteps={byteSteps} badges={badges} storeKey="dfir-m1"
      exam={examQuestions} examTag="Conduct an investigation"
      certModule="Digital Forensics Basics" />
  );
}
