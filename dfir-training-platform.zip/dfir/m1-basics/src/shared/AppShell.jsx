import React, { useState, useEffect, useRef } from 'react';
import Byte from './Byte.jsx';
import { Certificate, Badges, Quiz, Section } from './kit.jsx';
import { Fingerprint } from 'lucide-react';

/* Generic module shell.
   meta, sections (render fns), byteSteps, badges, storeKey
   exam: [questions]  examTag: section tag label  certModule: string
   The last badge id is treated as the "exam/certified" badge. */
export default function AppShell({ meta, sections, byteSteps, badges, storeKey, exam, examTag, certModule }) {
  const [progress, setProgress] = useState(0);
  const [earned, setEarned] = useState({});
  const [examPassed, setExamPassed] = useState(false);
  const visitedRef = useRef(new Set());
  const sectionRefs = useRef({});
  const examBadgeId = badges[badges.length - 1]?.id;

  useEffect(() => {
    try { const r = JSON.parse(localStorage.getItem(storeKey) || '{}'); if (r.earned) setEarned(r.earned); if (r.examPassed) setExamPassed(true); } catch {}
  }, [storeKey]);
  const persist = (next, ep) => { try { localStorage.setItem(storeKey, JSON.stringify({ earned: next, examPassed: ep })); } catch {} };
  const earnBadge = (id) => setEarned(e => { const n = { ...e, [id]: true }; persist(n, examPassed); return n; });

  useEffect(() => {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(en => { if (en.isIntersecting) visitedRef.current.add(en.target.id); });
      setProgress(visitedRef.current.size / (sections.length + 1));
    }, { threshold: 0.35 });
    Object.values(sectionRefs.current).forEach(el => el && io.observe(el));
    return () => io.disconnect();
  }, [sections.length]);

  const badgeList = badges.map(b => ({ ...b, earned: !!earned[b.id] }));

  return (
    <div className="app">
      <div className="topbar">
        <div className="brand"><span className="brand-dot">SI</span><span>Security Impossible <small>· DFIR Track</small></span></div>
        <span className="topbar-spacer" />
        <span className="case-chip">{meta.case}</span>
      </div>
      <div className="gp-track"><div className="gp-fill" style={{ width: `${Math.round(progress * 100)}%` }} /></div>

      <div className="wrap">
        <header className="hero">
          <div className="hero-eyebrow"><Fingerprint size={14} /> {meta.eyebrow}</div>
          <h1 dangerouslySetInnerHTML={{ __html: meta.title }} />
          <p>{meta.lede}</p>
          <div className="hero-meta">{meta.stats.map((s, i) => <div key={i}>{s.label}<b>{s.n}</b></div>)}</div>
          <div style={{ marginTop: 24 }}><Badges list={badgeList} /></div>
        </header>

        {sections.map((s, i) => (
          <div key={s.id} ref={el => sectionRefs.current[s.id] = el}>
            {s.render({ earnBadge })}
          </div>
        ))}

        {exam && (
          <div ref={el => sectionRefs.current['exam'] = el} id="exam">
            <Section n={sections.length + 1} tag={examTag || 'Final assessment'} title="Module Exam">
              <p>This graded exam covers the whole module. You need <strong>70%</strong> to pass and unlock your completion certificate. Unlimited retries \u2014 read each scenario and reason from the evidence.</p>
              <Quiz title="Final exam" exam questions={exam} pass={0.7}
                onPass={() => { setExamPassed(true); earnBadge(examBadgeId); persist({ ...earned, [examBadgeId]: true }, true); }} />
            </Section>
            <Certificate module={certModule} done={examPassed} />
          </div>
        )}
      </div>

      <Byte labName={meta.byteName} steps={byteSteps} onStepChange={() => {}} />
    </div>
  );
}
