import React, { useState, useEffect, useRef } from 'react';
import Byte from './Byte.jsx';
import { Certificate, Badges, Quiz, Section } from './kit.jsx';
import { Fingerprint, ArrowRight, ArrowLeft, CheckCircle2, Lock, Home } from 'lucide-react';

/* Generic module shell — STEPPER edition.
   Shows one step at a time (intro -> each section -> exam -> certificate),
   with a Next / Back footer instead of a long scroll.
   meta, sections (render fns), byteSteps, badges, storeKey
   exam:[questions]  examTag  certModule
   The last badge id is the "exam/certified" badge. */
export default function AppShell({ meta, sections, byteSteps, badges, storeKey, exam, examTag, certModule }) {
  // step 0 = intro/overview; 1..N = sections; N+1 = exam; N+2 = certificate
  const N = sections.length;
  const EXAM_STEP = N + 1;
  const CERT_STEP = N + 2;
  const lastStep = exam ? CERT_STEP : N;

  const [step, setStep] = useState(0);
  const [earned, setEarned] = useState({});
  const [examPassed, setExamPassed] = useState(false);
  const [maxReached, setMaxReached] = useState(0);
  const topRef = useRef(null);
  const examBadgeId = badges[badges.length - 1]?.id;

  // restore
  useEffect(() => {
    try {
      const r = JSON.parse(localStorage.getItem(storeKey) || '{}');
      if (r.earned) setEarned(r.earned);
      if (r.examPassed) setExamPassed(true);
      if (typeof r.step === 'number') { setStep(r.step); setMaxReached(r.maxReached || r.step); }
    } catch {}
  }, [storeKey]);

  const persist = (patch) => {
    try {
      const cur = JSON.parse(localStorage.getItem(storeKey) || '{}');
      localStorage.setItem(storeKey, JSON.stringify({ ...cur, earned, examPassed, step, maxReached, ...patch }));
    } catch {}
  };
  const earnBadge = (id) => setEarned(e => { const n = { ...e, [id]: true }; try { const cur = JSON.parse(localStorage.getItem(storeKey) || '{}'); localStorage.setItem(storeKey, JSON.stringify({ ...cur, earned: n })); } catch {} return n; });

  const go = (next) => {
    const clamped = Math.max(0, Math.min(lastStep, next));
    setStep(clamped);
    setMaxReached(m => { const nm = Math.max(m, clamped); persist({ step: clamped, maxReached: nm }); return nm; });
    // scroll the step area to the top of the viewport
    requestAnimationFrame(() => { topRef.current && topRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
  };

  const badgeList = badges.map(b => ({ ...b, earned: !!earned[b.id] }));
  const progress = lastStep > 0 ? step / lastStep : 0;

  // step label for footer
  const stepLabel = () => {
    if (step === 0) return 'Overview';
    if (step >= 1 && step <= N) return `Exercise ${step} of ${N}`;
    if (step === EXAM_STEP) return 'Module exam';
    return 'Complete';
  };
  const nextLabel = () => {
    if (step === 0) return 'Start first exercise';
    if (step === N) return exam ? 'Go to module exam' : 'Finish';
    if (step === EXAM_STEP) return 'View certificate';
    return 'Next exercise';
  };

  return (
    <div className="app stepper">
      <div className="topbar">
        <div className="brand"><span className="brand-dot">SI</span><span>Security Impossible <small>· DFIR Track</small></span></div>
        <span className="topbar-spacer" />
        <span className="case-chip">{meta.case}</span>
      </div>
      <div className="gp-track"><div className="gp-fill" style={{ width: `${Math.round(progress * 100)}%` }} /></div>

      {/* step rail */}
      <div className="wrap">
        <div className="steprail" role="tablist" aria-label="Module steps">
          {Array.from({ length: lastStep + 1 }).map((_, i) => {
            const reachable = i <= maxReached;
            const isExam = i === EXAM_STEP, isCert = i === CERT_STEP;
            const label = i === 0 ? 'Intro' : isExam ? 'Exam' : isCert ? 'Done' : i;
            return (
              <button key={i} className={`steprail-dot ${i === step ? 'active' : ''} ${i < step ? 'done' : ''} ${reachable ? '' : 'locked'}`}
                onClick={() => reachable && go(i)} disabled={!reachable} title={`Step ${i}`}>
                {i < step ? <CheckCircle2 size={13} /> : !reachable ? <Lock size={11} /> : label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="wrap" ref={topRef}>
        {/* STEP 0 — overview / hero */}
        {step === 0 && (
          <header className="hero">
            <div className="hero-eyebrow"><Fingerprint size={14} /> {meta.eyebrow}</div>
            <h1 dangerouslySetInnerHTML={{ __html: meta.title }} />
            <p>{meta.lede}</p>
            <div className="hero-meta">{meta.stats.map((s, i) => <div key={i}>{s.label}<b>{s.n}</b></div>)}</div>
            <div style={{ marginTop: 24 }}><Badges list={badgeList} /></div>
            <div className="hero-howto">
              <p style={{ margin: 0 }}>Work through one exercise at a time. Finish each, then tap <b>Next exercise</b> to move on — your mentor <b>Byte</b> (bottom corner) walks you through every step.</p>
            </div>
          </header>
        )}

        {/* STEP 1..N — one section each */}
        {step >= 1 && step <= N && (
          <div className="step-pane" key={sections[step - 1].id}>
            {sections[step - 1].render({ earnBadge })}
          </div>
        )}

        {/* EXAM */}
        {exam && step === EXAM_STEP && (
          <div className="step-pane" id="exam">
            <Section n={N + 1} tag={examTag || 'Final assessment'} title="Module Exam">
              <p>This graded exam covers the whole module. You need <strong>70%</strong> to pass and unlock your completion certificate. Unlimited retries — read each scenario and reason from the evidence.</p>
              <Quiz title="Final exam" exam questions={exam} pass={0.7}
                onPass={() => { setExamPassed(true); earnBadge(examBadgeId); try { const cur = JSON.parse(localStorage.getItem(storeKey) || '{}'); localStorage.setItem(storeKey, JSON.stringify({ ...cur, examPassed: true })); } catch {} }} />
            </Section>
          </div>
        )}

        {/* CERTIFICATE */}
        {exam && step === CERT_STEP && (
          <div className="step-pane">
            <Certificate module={certModule} done={examPassed} />
            {!examPassed && <div className="callout warn" style={{ marginTop: 16 }}><Lock size={17} /><div>Pass the module exam to unlock your certificate. Use <b>Back</b> to return to the exam.</div></div>}
            <div style={{ textAlign: 'center', marginTop: 20 }}>
              <button className="btn btn-ghost" onClick={() => go(0)}><Home size={15} /> Back to overview</button>
            </div>
          </div>
        )}
      </div>

      {/* sticky step nav */}
      <div className="stepnav">
        <div className="stepnav-inner wrap">
          <button className="btn btn-ghost" disabled={step === 0} onClick={() => go(step - 1)}><ArrowLeft size={15} /> Back</button>
          <span className="stepnav-label">{stepLabel()}</span>
          {step < lastStep
            ? <button className="btn btn-primary" onClick={() => go(step + 1)}>{nextLabel()} <ArrowRight size={15} /></button>
            : <button className="btn btn-primary" onClick={() => go(0)}><Home size={15} /> Overview</button>}
        </div>
      </div>

      <Byte labName={meta.byteName} steps={byteSteps} onStepChange={() => {}} />
    </div>
  );
}
