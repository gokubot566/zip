import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Search, Flag, CheckCircle2, XCircle, RotateCcw } from 'lucide-react';

/* Log explorer — searchable/filterable log viewer where the student must
   FLAG the suspicious lines. lines:[{id,ts,sev,msg,suspicious:bool}]
   onSolved() when exactly the suspicious set is flagged. */
export function LogExplorer({ lines, onSolved, prompt }) {
  const [q, setQ] = useState('');
  const [sev, setSev] = useState('all');
  const [flagged, setFlagged] = useState({});
  const [checked, setChecked] = useState(false);
  const firedRef = useRef(false);

  const shown = useMemo(() => lines.filter(l => {
    if (sev !== 'all' && l.sev !== sev) return false;
    if (q && !(`${l.ts} ${l.sev} ${l.msg}`.toLowerCase().includes(q.toLowerCase()))) return false;
    return true;
  }), [lines, q, sev]);

  const target = lines.filter(l => l.suspicious).map(l => l.id).sort().join(',');
  const current = Object.keys(flagged).filter(k => flagged[k]).sort().join(',');
  const right = target === current;
  useEffect(() => { if (checked && right && !firedRef.current) { firedRef.current = true; onSolved && onSolved(); } }, [checked]);

  const toggle = (id) => { setFlagged(f => ({ ...f, [id]: !f[id] })); setChecked(false); };
  const flaggedCount = Object.values(flagged).filter(Boolean).length;

  return (
    <div>
      {prompt && <p>{prompt}</p>}
      <div className="logx">
        <div className="logx-bar">
          <div className="logx-search"><Search size={14} /><input value={q} placeholder="filter logs…" onChange={e => setQ(e.target.value)} /></div>
          {['all', 'crit', 'warn', 'info'].map(s => (
            <button key={s} className={`logx-filter ${sev === s ? 'active' : ''}`} onClick={() => setSev(s)}>{s.toUpperCase()}</button>
          ))}
        </div>
        <div className="logx-body">
          {shown.map(l => (
            <div key={l.id} className={`logline ${flagged[l.id] ? 'flagged' : ''}`} onClick={() => toggle(l.id)}>
              <span className="ts">{l.ts}</span>
              <span className={`sev ${l.sev}`}>{l.sev.toUpperCase()}</span>
              <span className="msg" dangerouslySetInnerHTML={{ __html: l.msg }} />
              {flagged[l.id] && <Flag size={13} style={{ color: 'var(--rose)', flexShrink: 0 }} />}
              {checked && (l.suspicious
                ? <CheckCircle2 size={13} style={{ color: 'var(--teal)', flexShrink: 0 }} />
                : (flagged[l.id] ? <XCircle size={13} style={{ color: 'var(--rose)', flexShrink: 0 }} /> : null))}
            </div>
          ))}
        </div>
        <div className="logx-foot">
          <span>{shown.length} shown · {flaggedCount} flagged</span>
          <span style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-ghost btn-sm" onClick={() => { setFlagged({}); setChecked(false); }}><RotateCcw size={12} /> Clear</button>
            <button className="btn btn-primary btn-sm" onClick={() => setChecked(true)}>Check flags</button>
          </span>
        </div>
      </div>
      {checked && (
        <div className={`fb ${right ? 'ok' : 'no'}`} style={{ marginTop: 12 }}>
          <b>{right ? 'Exactly right. ' : 'Not quite. '}</b>
          {right ? 'You flagged every suspicious line and nothing benign.' : 'Click suspicious lines to flag them. Green = a true suspicious line you missed; red = a benign line you wrongly flagged. Use the filters and search to hunt them down.'}
        </div>
      )}
    </div>
  );
}

/* Match events to attack stages (kill-chain). events:[{id,label}],
   stages:[{id,label}], answer:{eventId:stageId} */
export function MatchStages({ events, stages, answer, onSolved, prompt }) {
  const [pick, setPick] = useState({});
  const [checked, setChecked] = useState(false);
  const firedRef = useRef(false);
  const all = events.every(e => pick[e.id]);
  const right = events.every(e => pick[e.id] === answer[e.id]);
  useEffect(() => { if (checked && right && !firedRef.current) { firedRef.current = true; onSolved && onSolved(); } }, [checked]);
  return (
    <div>
      {prompt && <p>{prompt}</p>}
      <div style={{ display: 'grid', gap: 10, margin: '14px 0' }}>
        {events.map(e => (
          <div key={e.id} style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap', background: 'var(--bg)', border: '1px solid var(--line)', borderRadius: 9, padding: '11px 14px' }}>
            <span style={{ flex: 1, fontFamily: 'var(--mono)', fontSize: 13, minWidth: 200 }} dangerouslySetInnerHTML={{ __html: e.label }} />
            <select value={pick[e.id] || ''} onChange={ev => { setPick(p => ({ ...p, [e.id]: ev.target.value })); setChecked(false); }}
              style={{ background: 'var(--panel-2)', color: 'var(--ink)', border: '1px solid var(--line)', borderRadius: 7, padding: '7px 10px', fontFamily: 'var(--body)', fontSize: 13 }}>
              <option value="">— select stage —</option>
              {stages.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
            </select>
            {checked && (pick[e.id] === answer[e.id] ? <CheckCircle2 size={16} style={{ color: 'var(--teal)' }} /> : <XCircle size={16} style={{ color: 'var(--rose)' }} />)}
          </div>
        ))}
      </div>
      <button className="btn btn-primary btn-sm" disabled={!all} onClick={() => setChecked(true)}>Check matches</button>
      {checked && <div className={`fb ${right ? 'ok' : 'no'}`} style={{ marginTop: 12 }}>
        <b>{right ? 'All matched correctly. ' : 'Some are mismatched. '}</b>{right ? 'You mapped each event to the right attack stage.' : 'Reconsider the events marked in red.'}
      </div>}
    </div>
  );
}
