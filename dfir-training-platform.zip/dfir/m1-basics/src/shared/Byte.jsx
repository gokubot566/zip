import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Bot, X, Lock, ChevronRight, ChevronLeft } from 'lucide-react';

/* Byte — floating mentor. Walks the student through an ordered step array.
   steps: [{ title, body (JSX/html string), module (label), actionLock? }]
   onStepChange(index) lets the page scroll/highlight in sync. */
export default function Byte({ labName, steps, onStepChange, totalForBadge }) {
  const [open, setOpen] = useState(false);
  const [idx, setIdx] = useState(0);
  const [typing, setTyping] = useState(false);
  const [edge, setEdge] = useState('right');
  const [above, setAbove] = useState(false);
  const widgetRef = useRef(null);
  const vRatioRef = useRef(0.68);
  const sizeRef = useRef({ w: 360, h: 480 });

  // auto-open after load
  useEffect(() => { const t = setTimeout(() => setOpen(true), 800); return () => clearTimeout(t); }, []);

  // typing animation between steps
  useEffect(() => {
    setTyping(true);
    const t = setTimeout(() => setTyping(false), 480);
    onStepChange && onStepChange(idx);
    return () => clearTimeout(t);
  }, [idx]);

  const snap = useCallback((animate) => {
    const w = widgetRef.current; if (!w) return;
    const vw = window.innerWidth, vh = window.innerHeight, GAP = 14;
    const targetLeft = edge === 'left' ? GAP : vw - 64 - GAP;
    const targetTop = Math.max(8, Math.min(vRatioRef.current * vh, vh - 72));
    if (animate) { w.classList.add('byte-snapping'); w.addEventListener('transitionend', () => w.classList.remove('byte-snapping'), { once: true }); }
    w.style.left = targetLeft + 'px'; w.style.top = targetTop + 'px'; w.style.right = 'auto';
    setAbove(targetTop > vh * 0.5);
  }, [edge]);

  useEffect(() => { snap(false); }, [snap]);
  useEffect(() => {
    const onResize = () => snap(false);
    window.addEventListener('resize', onResize); return () => window.removeEventListener('resize', onResize);
  }, [snap]);

  // drag header to move whole widget
  const dragRef = useRef(null);
  const onHeaderDown = (e) => {
    const w = widgetRef.current; if (!w) return;
    const startX = e.clientX, startY = e.clientY;
    const r = w.getBoundingClientRect();
    dragRef.current = { ox: startX - r.left, oy: startY - r.top };
    const move = (ev) => {
      const nx = ev.clientX - dragRef.current.ox;
      const ny = ev.clientY - dragRef.current.oy;
      w.style.left = nx + 'px'; w.style.top = Math.max(8, ny) + 'px'; w.style.right = 'auto';
      w.classList.remove('byte-snapping');
    };
    const up = (ev) => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      const vw = window.innerWidth, vh = window.innerHeight;
      const r2 = w.getBoundingClientRect();
      const newEdge = (r2.left + 32) < vw / 2 ? 'left' : 'right';
      vRatioRef.current = Math.min(0.92, Math.max(0.05, r2.top / vh));
      setEdge(newEdge);
      setTimeout(() => snap(true), 0);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    e.preventDefault();
  };

  const step = steps[idx] || {};
  const pct = Math.round(((idx + 1) / steps.length) * 100);

  return (
    <div id="byte-widget" ref={widgetRef} className={`${edge === 'left' ? 'pos-left' : ''} ${above ? 'pos-above' : ''}`}>
      {open && (
        <div id="byte-panel" role="dialog" aria-label={`${labName} guide`}
          style={{ width: sizeRef.current.w, height: sizeRef.current.h }}>
          <div className="byte-header" onPointerDown={onHeaderDown}>
            <div className="byte-avatar"><Bot size={17} /></div>
            <span className="byte-name">Byte — {labName}</span>
            <span className="byte-dot" title="online" />
            <button className="byte-x" onClick={() => setOpen(false)} aria-label="Minimise"><X size={15} /></button>
          </div>

          <div className="byte-progress">
            <div className="byte-progress-row">
              <span>Step {idx + 1} / {steps.length}</span>
              <span className="mod">{step.module || ''}</span>
            </div>
            <div className="byte-ptrack"><div className="byte-pfill" style={{ width: pct + '%' }} /></div>
          </div>

          <div className="byte-body">
            {typing ? (
              <div className="byte-typing"><span /><span /><span /></div>
            ) : (
              <>
                {step.title && <span className="byte-step-title">{step.title}</span>}
                <div dangerouslySetInnerHTML={{ __html: step.body || '' }} />
              </>
            )}
          </div>

          {step.actionLock && !typing && (
            <div className="byte-action-lock">
              <Lock size={13} /><span>{step.actionLock}</span>
            </div>
          )}

          <div className="byte-footer">
            <button className="byte-skip" onClick={() => setOpen(false)}>Hide</button>
            <button className="btn btn-ghost btn-sm" disabled={idx === 0} onClick={() => setIdx(i => Math.max(0, i - 1))}>
              <ChevronLeft size={14} /> Back
            </button>
            <button className="btn btn-primary btn-sm" disabled={idx === steps.length - 1}
              onClick={() => setIdx(i => Math.min(steps.length - 1, i + 1))}>
              Next <ChevronRight size={14} />
            </button>
          </div>
        </div>
      )}

      <div id="byte-launcher" onClick={() => setOpen(o => !o)} role="button" aria-label="Open Byte mentor">
        {!open && <span className="byte-launcher-pulse" />}
        {open ? <X size={22} /> : <Bot size={28} />}
        {!open && <span className="byte-badge">{idx + 1}</span>}
      </div>
    </div>
  );
}
