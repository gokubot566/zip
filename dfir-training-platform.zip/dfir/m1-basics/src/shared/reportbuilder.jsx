import React, { useState, useRef, useMemo, useEffect } from 'react';
import { CheckCircle2, XCircle, RotateCcw, Download, FileText } from 'lucide-react';

/* Report builder — drag evidence/snippet cards into the correct report
   sections. bank:[{id,label,section}], sections:[{id,label}], onSolved() */
export function ReportBuilder({ bank, sections, onSolved, prompt }) {
  const [placed, setPlaced] = useState({});   // bankId -> sectionId
  const [over, setOver] = useState(null);
  const [checked, setChecked] = useState(false);
  const drag = useRef(null);
  const firedRef = useRef(false);
  const pool = bank.filter(b => placed[b.id] == null);
  const all = bank.every(b => placed[b.id] != null);
  const right = bank.every(b => placed[b.id] === b.section);
  useEffect(() => { if (checked && right && !firedRef.current) { firedRef.current = true; onSolved && onSolved(); } }, [checked]);

  return (
    <div>
      {prompt && <p>{prompt}</p>}
      <div className="dd-pool" onDragOver={e => e.preventDefault()}
        onDrop={() => { if (drag.current) { setPlaced(p => { const n = { ...p }; delete n[drag.current]; return n; }); setChecked(false); } }}>
        {pool.length === 0 ? <span style={{ color: 'var(--ink-faint)', fontSize: 13, fontFamily: 'var(--mono)' }}>All evidence placed.</span>
          : pool.map(b => <div key={b.id} className="dd-chip" draggable onDragStart={() => drag.current = b.id} onDragEnd={() => drag.current = null}>{b.label}</div>)}
      </div>
      <div className="rb-sections">
        {sections.map(s => (
          <div key={s.id} className={`rb-slot ${over === s.id ? 'over' : ''}`}
            onDragOver={e => { e.preventDefault(); setOver(s.id); }}
            onDragLeave={() => setOver(null)}
            onDrop={() => { if (drag.current) { setPlaced(p => ({ ...p, [drag.current]: s.id })); setChecked(false); } setOver(null); }}>
            <div className="slot-name"><span className="n">§</span>{s.label}</div>
            <div className="items">
              {bank.filter(b => placed[b.id] === s.id).map(b => {
                const cls = checked ? (b.section === s.id ? 'ok' : 'no') : 'neutral';
                return <div key={b.id} className={`dd-placed ${cls}`} draggable onDragStart={() => drag.current = b.id}>
                  <span>{b.label}</span>
                  {checked && (b.section === s.id ? <CheckCircle2 size={13} style={{ color: 'var(--teal)' }} /> : <XCircle size={13} style={{ color: 'var(--rose)' }} />)}
                </div>;
              })}
            </div>
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
        <button className="btn btn-primary btn-sm" disabled={!all} onClick={() => setChecked(true)}>Check report</button>
        <button className="btn btn-ghost btn-sm" onClick={() => { setPlaced({}); setChecked(false); }}><RotateCcw size={13} /> Reset</button>
      </div>
      {checked && <div className={`fb ${right ? 'ok' : 'no'}`} style={{ marginTop: 12 }}>
        <b>{right ? 'Well structured. ' : 'Some items are misplaced. '}</b>{right ? 'Every piece of evidence is in the right report section.' : 'Red items belong in a different section — drag them out and reconsider.'}
      </div>}
    </div>
  );
}

/* Findings writer — student writes a finding; we check it contains required
   elements (fact, evidence ref, no speculation words). */
export function FindingsWriter({ prompt, mustInclude = [], avoid = [], sample, onSolved }) {
  const [text, setText] = useState('');
  const [checked, setChecked] = useState(false);
  const firedRef = useRef(false);
  const lower = text.toLowerCase();
  const hasAll = mustInclude.every(m => lower.includes(m.toLowerCase()));
  const hasBad = avoid.some(a => lower.includes(a.toLowerCase()));
  const ok = hasAll && !hasBad && text.trim().length > 30;
  useEffect(() => { if (checked && ok && !firedRef.current) { firedRef.current = true; onSolved && onSolved(); } }, [checked]);
  return (
    <div>
      {prompt && <p>{prompt}</p>}
      <textarea value={text} onChange={e => { setText(e.target.value); setChecked(false); }}
        placeholder="Write your finding here…"
        style={{ width: '100%', minHeight: 90, background: '#060912', border: '1px solid var(--line)', borderRadius: 9, color: 'var(--ink)', fontFamily: 'var(--body)', fontSize: 14, padding: 12, resize: 'vertical' }} />
      <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
        <button className="btn btn-primary btn-sm" disabled={!text.trim()} onClick={() => setChecked(true)}>Check my finding</button>
      </div>
      {checked && (
        <div className={`fb ${ok ? 'ok' : 'no'}`} style={{ marginTop: 12 }}>
          {ok ? <><b>Strong finding. </b>It states a fact, references the evidence, and avoids speculation.</>
            : <><b>Needs work. </b>{!hasAll ? 'Make sure you reference the specific evidence (e.g. the timestamp, host, or hash). ' : ''}{hasBad ? 'Remove speculative words like “probably”, “maybe”, or “I think” — findings state what the evidence shows. ' : ''}{text.trim().length <= 30 ? 'Add more detail. ' : ''}</>}
          {sample && <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid var(--line-soft)' }}><b style={{ color: 'var(--teal)' }}>Model answer:</b> <span style={{ fontStyle: 'italic' }}>{sample}</span></div>}
        </div>
      )}
    </div>
  );
}

/* Good vs bad comparison toggle */
export function GoodBad({ good, bad, prompt }) {
  const [show, setShow] = useState('bad');
  return (
    <div>
      {prompt && <p>{prompt}</p>}
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <button className={`btn btn-sm ${show === 'bad' ? 'btn-primary' : 'btn-ghost'}`} onClick={() => setShow('bad')} style={show === 'bad' ? { background: 'var(--rose)', borderColor: 'var(--rose)', color: '#1a0810' } : {}}>Weak example</button>
        <button className={`btn btn-sm ${show === 'good' ? 'btn-primary' : 'btn-ghost'}`} onClick={() => setShow('good')}>Strong example</button>
      </div>
      <div className={`codeblock`} style={{ borderColor: show === 'good' ? 'var(--teal)' : 'var(--rose)' }}>
        <div dangerouslySetInnerHTML={{ __html: show === 'good' ? good : bad }} />
      </div>
    </div>
  );
}
