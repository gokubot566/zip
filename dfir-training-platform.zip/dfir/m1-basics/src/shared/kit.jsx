import React, { useState, useRef, useMemo, useEffect } from 'react';
import {
  Lightbulb, AlertTriangle, ShieldAlert, CheckCircle2, XCircle, HelpCircle,
  GripVertical, RotateCcw, Award, Hash, Search, Lock,
} from 'lucide-react';

/* ---------- Section shell ---------- */
export function Section({ n, tag, title, id, children }) {
  return (
    <section className="section" id={id}>
      <div className="sec-eyebrow">
        <span className="sec-num">{String(n).padStart(2, '0')}</span>
        <span className="sec-tag">{tag}</span>
      </div>
      <h2>{title}</h2>
      {children}
    </section>
  );
}

export const Tip   = ({ children }) => <div className="callout tip"><Lightbulb size={17} /><div>{children}</div></div>;
export const Warn  = ({ children }) => <div className="callout warn"><AlertTriangle size={17} /><div>{children}</div></div>;
export const Alert = ({ children }) => <div className="callout alert"><ShieldAlert size={17} /><div>{children}</div></div>;
export const Def   = ({ term, children }) => <div className="def"><span className="term">{term}</span>{children}</div>;

/* ---------- Quiz (per-section + exam) ----------
   questions: [{ q, options:[...], correct:index, explain }]
   pass: fraction (default 0.7). onPass(pct) fires once. */
export function Quiz({ title = 'Knowledge check', questions, pass = 0.7, onPass, exam = false }) {
  const [ans, setAns] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [attempt, setAttempt] = useState(1);
  const need = Math.ceil(questions.length * pass);
  const correct = useMemo(() => questions.filter((q, i) => ans[i] === q.correct).length, [ans, submitted, questions]);
  const passed = correct >= need;
  const all = questions.every((_, i) => ans[i] != null);
  const firedRef = useRef(false);
  useEffect(() => {
    if (submitted && passed && !firedRef.current) { firedRef.current = true; onPass && onPass(Math.round(correct / questions.length * 100)); }
  }, [submitted]);

  const pick = (qi, oi) => { if (!submitted) setAns(a => ({ ...a, [qi]: oi })); };
  return (
    <div className="quiz">
      <div className="quiz-head">
        <span className="ic">{exam ? <Award size={18} /> : <HelpCircle size={18} />}</span>
        <h4>{title}</h4>
        <span className="gate">Pass {need}/{questions.length}</span>
      </div>
      {questions.map((q, qi) => (
        <div className="q" key={qi}>
          <div className="q-prompt"><span className="q-num">{qi + 1}</span><span dangerouslySetInnerHTML={{ __html: q.q }} /></div>
          <div className="opts">
            {q.options.map((o, oi) => {
              let cls = 'opt';
              if (!submitted && ans[qi] === oi) cls += ' sel';
              if (submitted) { if (oi === q.correct) cls += ' correct'; else if (ans[qi] === oi) cls += ' wrong'; }
              return (
                <button key={oi} className={cls} disabled={submitted} onClick={() => pick(qi, oi)}>
                  <span className="mk">{submitted && oi === q.correct ? <CheckCircle2 size={13} /> : submitted && ans[qi] === oi ? <XCircle size={13} /> : String.fromCharCode(65 + oi)}</span>
                  <span dangerouslySetInnerHTML={{ __html: o }} />
                </button>
              );
            })}
          </div>
          {submitted && (
            <div className={`fb ${ans[qi] === q.correct ? 'ok' : 'no'}`}>
              <b>{ans[qi] === q.correct ? 'Correct. ' : 'Not quite. '}</b><span dangerouslySetInnerHTML={{ __html: q.explain }} />
            </div>
          )}
        </div>
      ))}
      {!submitted ? (
        <button className="btn btn-primary" style={{ marginTop: 16 }} disabled={!all} onClick={() => setSubmitted(true)}>
          {all ? 'Submit answers' : `Answer all ${questions.length}`}
        </button>
      ) : (
        <div className={`quiz-result ${passed ? 'pass' : 'fail'}`}>
          {passed ? <CheckCircle2 size={24} /> : <XCircle size={24} />}
          <div style={{ flex: 1 }}>
            <div className="score">{correct}/{questions.length} · {Math.round(correct / questions.length * 100)}%</div>
            <div style={{ fontSize: 13, color: 'var(--ink-dim)' }}>
              {passed ? (exam ? 'Exam passed — module complete.' : 'Section cleared. Keep going.') : `You need ${need} to pass. Review the feedback and retry.`}
            </div>
          </div>
          {!passed && <button className="btn btn-ghost btn-sm" onClick={() => { setAns({}); setSubmitted(false); setAttempt(a => a + 1); }}><RotateCcw size={13} /> Retry</button>}
        </div>
      )}
    </div>
  );
}

/* ---------- Drag-drop classify ----------
   items:[{id,label}], bins:[{id,label,icon?}], answer:{itemId:binId}, onSolved() */
export function Classify({ items, bins, answer, onSolved, prompt }) {
  const [placed, setPlaced] = useState({});   // itemId -> binId
  const [over, setOver] = useState(null);
  const [checked, setChecked] = useState(false);
  const drag = useRef(null);
  const pool = items.filter(i => placed[i.id] == null);
  const allPlaced = items.every(i => placed[i.id] != null);
  const allRight = items.every(i => placed[i.id] === answer[i.id]);
  const firedRef = useRef(false);
  useEffect(() => { if (checked && allRight && !firedRef.current) { firedRef.current = true; onSolved && onSolved(); } }, [checked]);

  return (
    <div>
      {prompt && <p>{prompt}</p>}
      <div className="dd-pool" onDragOver={e => e.preventDefault()}
        onDrop={() => { if (drag.current) { setPlaced(p => { const n = { ...p }; delete n[drag.current]; return n; }); setChecked(false); } }}>
        {pool.length === 0 ? <span style={{ color: 'var(--ink-faint)', fontSize: 13, fontFamily: 'var(--mono)' }}>All items sorted — check your answers.</span>
          : pool.map(i => (
            <div key={i.id} className="dd-chip" draggable
              onDragStart={() => { drag.current = i.id; }}
              onDragEnd={() => { drag.current = null; }}>{i.label}</div>
          ))}
      </div>
      <div className="dd-bins">
        {bins.map(b => (
          <div key={b.id} className={`dd-bin ${over === b.id ? 'over' : ''}`}
            onDragOver={e => { e.preventDefault(); setOver(b.id); }}
            onDragLeave={() => setOver(null)}
            onDrop={() => { if (drag.current) { setPlaced(p => ({ ...p, [drag.current]: b.id })); setChecked(false); } setOver(null); }}>
            <h5>{b.icon}{b.label}</h5>
            <div className="items">
              {items.filter(i => placed[i.id] === b.id).map(i => {
                const cls = checked ? (answer[i.id] === b.id ? 'ok' : 'no') : 'neutral';
                return (
                  <div key={i.id} className={`dd-placed ${cls}`} draggable
                    onDragStart={() => { drag.current = i.id; }}>
                    <span>{i.label}</span>
                    {checked && (answer[i.id] === b.id ? <CheckCircle2 size={13} style={{ color: 'var(--teal)' }} /> : <XCircle size={13} style={{ color: 'var(--rose)' }} />)}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
        <button className="btn btn-primary btn-sm" disabled={!allPlaced} onClick={() => setChecked(true)}>Check classification</button>
        <button className="btn btn-ghost btn-sm" onClick={() => { setPlaced({}); setChecked(false); }}><RotateCcw size={13} /> Reset</button>
      </div>
      {checked && (
        <div className={`fb ${allRight ? 'ok' : 'no'}`} style={{ marginTop: 12 }}>
          <b>{allRight ? 'All correct. ' : 'Some are misfiled. '}</b>{allRight ? 'Every item is in the right category.' : 'Red items are in the wrong bin — drag them out and try again.'}
        </div>
      )}
    </div>
  );
}

/* ---------- Sortable (order of volatility etc.) ----------
   items:[{id,label}] in scrambled order; correct:[id,...] target order */
export function Sortable({ items, correct, onSolved, prompt, labelTop, labelBottom }) {
  const [order, setOrder] = useState(items.map(i => i.id));
  const [checked, setChecked] = useState(false);
  const drag = useRef(null);
  const map = Object.fromEntries(items.map(i => [i.id, i.label]));
  const isRight = order.every((id, i) => id === correct[i]);
  const firedRef = useRef(false);
  useEffect(() => { if (checked && isRight && !firedRef.current) { firedRef.current = true; onSolved && onSolved(); } }, [checked]);

  const onDrop = (targetId) => {
    if (!drag.current || drag.current === targetId) return;
    setOrder(o => {
      const a = [...o];
      const from = a.indexOf(drag.current), to = a.indexOf(targetId);
      a.splice(from, 1); a.splice(to, 0, drag.current);
      return a;
    });
    setChecked(false);
  };
  return (
    <div>
      {prompt && <p>{prompt}</p>}
      {labelTop && <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-faint)', marginBottom: 6 }}>{labelTop}</div>}
      <div className="sortable">
        {order.map((id, i) => {
          const cls = checked ? (id === correct[i] ? 'ok' : 'no') : '';
          return (
            <div key={id} className={`sort-item ${cls}`} draggable
              onDragStart={() => { drag.current = id; }}
              onDragOver={e => e.preventDefault()}
              onDrop={() => onDrop(id)}
              onDragEnd={() => { drag.current = null; }}>
              <GripVertical size={16} className="grip" />
              <span className="rank">{i + 1}</span>
              <span className="lbl">{map[id]}</span>
              {checked && (id === correct[i] ? <CheckCircle2 size={15} style={{ color: 'var(--teal)' }} /> : <XCircle size={15} style={{ color: 'var(--rose)' }} />)}
            </div>
          );
        })}
      </div>
      {labelBottom && <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-faint)', marginTop: 6 }}>{labelBottom}</div>}
      <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
        <button className="btn btn-primary btn-sm" onClick={() => setChecked(true)}>Check order</button>
        <button className="btn btn-ghost btn-sm" onClick={() => { setOrder(items.map(i => i.id)); setChecked(false); }}><RotateCcw size={13} /> Reset</button>
      </div>
      {checked && <div className={`fb ${isRight ? 'ok' : 'no'}`} style={{ marginTop: 12 }}>
        <b>{isRight ? 'Correct order. ' : 'Not yet. '}</b>{isRight ? 'This is the right sequence.' : 'Items in red are out of position. Drag to reorder.'}
      </div>}
    </div>
  );
}

/* ---------- Hash demo (deterministic FNV-style, for teaching only) ---------- */
function fakeHash(str, len) {
  // deterministic pseudo-hash purely for demonstration of avalanche effect
  let h = 0x811c9dc5;
  const out = [];
  for (let k = 0; k < len; k++) {
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i) + k * 7; h = Math.imul(h, 0x01000193); }
    out.push(((h >>> 0) % 256).toString(16).padStart(2, '0'));
  }
  return out.join('');
}
export function HashDemo({ onSolved }) {
  const [a, setA] = useState('chain-of-custody.pdf');
  const [b, setB] = useState('chain-of-custody.pdf');
  const seen = useRef(false);
  const ha = useMemo(() => ({ md5: fakeHash(a, 16), sha1: fakeHash(a + '1', 20), sha256: fakeHash(a + '2', 32) }), [a]);
  const hb = useMemo(() => ({ md5: fakeHash(b, 16), sha1: fakeHash(b + '1', 20), sha256: fakeHash(b + '2', 32) }), [b]);
  const match = a === b;
  useEffect(() => { if (!match && !seen.current) { seen.current = true; onSolved && onSolved(); } }, [match]);
  return (
    <div className="hash-demo">
      <p style={{ marginTop: 0 }}><strong>Original evidence</strong> — the file as acquired:</p>
      <textarea value={a} onChange={e => setA(e.target.value)} />
      <div className="hash-out">
        {['md5', 'sha1', 'sha256'].map(alg => <div className="hash-row" key={alg}><span className="alg">{alg.toUpperCase()}</span><span className="val">{ha[alg]}</span></div>)}
      </div>
      <p style={{ margin: '18px 0 0' }}><strong>Working copy</strong> — edit one character to simulate tampering:</p>
      <textarea value={b} onChange={e => setB(e.target.value)} />
      <div className="hash-out">
        {['md5', 'sha1', 'sha256'].map(alg => <div className="hash-row" key={alg}><span className="alg">{alg.toUpperCase()}</span><span className="val">{hb[alg]}</span></div>)}
      </div>
      <div className={`hash-compare ${match ? 'match' : 'diff'}`}>
        {match ? <CheckCircle2 size={18} /> : <XCircle size={18} />}
        <span>{match ? 'Hashes MATCH — integrity verified, the copy is identical to the original.' : 'Hashes DIFFER — even a one-character change avalanches every hash. The evidence has been altered.'}</span>
      </div>
    </div>
  );
}

/* ---------- Badges + Certificate ---------- */
export function Badges({ list }) {
  return (
    <div className="badges">
      {list.map((b, i) => <span key={i} className={`badge ${b.earned ? 'earned' : ''}`}><Award size={13} /> {b.label}</span>)}
    </div>
  );
}
export function Certificate({ module, name = '[ Student Name ]', done }) {
  return (
    <div className="cert">
      <div className="ic"><Award size={28} /></div>
      <h3>{done ? 'Module Complete' : 'Completion Certificate'}</h3>
      <p>{done ? `Awarded to ${name} for completing` : 'Finish all sections and pass the exam to unlock'}</p>
      <p style={{ fontFamily: 'var(--display)', fontSize: 18, color: 'var(--teal)', marginTop: 4 }}>{module}</p>
      <p style={{ fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--ink-faint)', marginTop: 10 }}>Security Impossible · DFIR Foundation Track</p>
    </div>
  );
}
