import React from 'react';
import AppShell from './shared/AppShell.jsx';
import { Section, Tip, Warn, Alert, Def, Quiz } from './shared/kit.jsx';
import { LogExplorer, MatchStages } from './shared/logx.jsx';
import { ScrollText, Server, Globe, Shield, Network, KeyRound, Clock, Crosshair, Layers } from 'lucide-react';

const byteSteps = [
  { module: 'WELCOME', title: 'Logs tell the story', body: 'Welcome back \u2014 I\u2019m Byte. In <b>Basic Log Analysis</b> you\u2019ll learn to read the trail every system leaves behind. Logs are how investigators reconstruct what an attacker did, step by step. Tap <span class="hl">Next</span> or scroll on.' },
  { module: 'SECTION 01', title: 'What logs are', body: 'Start with <b>what logs are</b> and why logging matters. A log is a timestamped record of an event \u2014 a login, a request, a blocked connection. No logs, no investigation.' },
  { module: 'SECTION 02', title: 'Know your sources', body: 'Different systems write different <b>log types</b> \u2014 Windows Event Logs, Linux syslog, web, firewall, DNS, auth, VPN, cloud. Knowing where to look is half the battle.' },
  { module: 'SECTION 03', title: 'Time is everything', body: '<b>Timestamps</b> and <b>time synchronisation</b> let you line up events from different sources. If clocks drift, your timeline lies. Always normalise to UTC.' },
  { module: 'SECTION 04', title: 'Spot the bad', body: 'Now the fun part \u2014 <b>indicators of compromise</b> and suspicious patterns: failed-login bursts, privilege escalation, malware beacons, data exfiltration. Try the <span class="hl">log explorer</span> and flag the bad lines.', actionLock: 'Flag the suspicious lines in the log explorer' },
  { module: 'SECTION 05', title: 'Map the attack', body: 'Real analysis is <b>correlation</b> \u2014 connecting events into an attack story. Match each log event to its stage in the attack.', actionLock: 'Match the events to attack stages' },
  { module: 'EXAM', title: 'Final exam', body: 'Finish with the <b>graded exam</b> \u2014 70% to earn your certificate. Read each scenario like a real analyst.', actionLock: 'Pass the exam to complete the module' },
];
const badges = [
  { id: 'explorer', label: 'Log Hunter' },
  { id: 'correlate', label: 'Correlator' },
  { id: 'exam', label: 'Certified Log Analyst' },
];

export default function App() {
  const sections = [
    { id: 's1', render: () => (
      <Section n={1} tag="Foundations" title="What Are Logs & Why They Matter" id="s1">
        <p>A <strong>log</strong> is a timestamped record of an event on a system: a user logging in, a web page requested, a connection blocked, a file deleted. Individually a log line is trivial. Collected and correlated, logs are the single richest source of truth in most investigations.</p>
        <Def term="Log">A timestamped entry describing something that happened \u2014 who or what, did what, when, and often from where.</Def>
        <h3>Why logging matters</h3>
        <ul>
          <li><strong>Reconstruction</strong> \u2014 logs let you rebuild exactly what happened and in what order.</li>
          <li><strong>Detection</strong> \u2014 suspicious patterns in logs are how intrusions are spotted.</li>
          <li><strong>Attribution</strong> \u2014 source IPs, usernames, and hosts tie activity to actors.</li>
          <li><strong>Accountability</strong> \u2014 logs provide the audit trail for compliance and legal use.</li>
        </ul>
        <Alert><b>If it isn\u2019t logged, it didn\u2019t happen \u2014 for you.</b> Gaps in logging are blind spots an attacker can hide in. The first questions in any investigation are: what is logged, where, and for how long?</Alert>
        <Quiz title="Quick check · Foundations" questions={[
          { q: 'What is the minimum a useful log line should tell you?', options: ['The colour of the screen', 'What happened, when, and ideally from where/who', 'The price of the server', 'The OS licence key'], correct: 1, explain: 'Event + timestamp + source/actor is the core of any log entry.' },
          { q: 'Why are gaps in logging dangerous?', options: ['They save disk space', 'They are blind spots where activity goes unseen', 'They speed up the server', 'They improve privacy'], correct: 1, explain: 'Unlogged activity cannot be investigated \u2014 attackers exploit these blind spots.' },
        ]} />
      </Section>
    ) },

    { id: 's2', render: () => (
      <Section n={2} tag="Sources" title="Types of Logs" id="s2">
        <p>Each layer of an environment produces its own logs. A competent analyst knows which source answers which question.</p>
        <div className="cards">
          <div className="card"><div className="ic"><Server size={18} /></div><h4>Windows Event Logs</h4><p>System, Security, Application channels. Logons (4624/4625), process creation (4688), service installs.</p></div>
          <div className="card"><div className="ic"><ScrollText size={18} /></div><h4>Linux Syslog</h4><p>/var/log/auth.log, syslog, secure. SSH logins, sudo, daemon events.</p></div>
          <div className="card"><div className="ic"><Globe size={18} /></div><h4>Web server</h4><p>Apache/Nginx access & error logs. URLs, status codes, user-agents \u2014 great for web attacks.</p></div>
          <div className="card"><div className="ic"><Shield size={18} /></div><h4>Firewall</h4><p>Allowed/blocked connections, ports, source/destination IPs.</p></div>
          <div className="card"><div className="ic"><Network size={18} /></div><h4>DNS</h4><p>Domain lookups \u2014 reveals C2 domains and data exfil over DNS.</p></div>
          <div className="card"><div className="ic"><KeyRound size={18} /></div><h4>Authentication</h4><p>Logins, MFA, lockouts \u2014 the heart of access investigations.</p></div>
          <div className="card"><div className="ic"><Layers size={18} /></div><h4>Proxy / VPN</h4><p>Outbound web access and remote sessions \u2014 who connected from where.</p></div>
          <div className="card"><div className="ic"><Globe size={18} /></div><h4>Email & Cloud</h4><p>Mail flow, logins to SaaS, API calls, config changes in cloud consoles.</p></div>
        </div>
        <Tip>Match the question to the source: <b>\u201CWho logged in?\u201D</b> \u2192 auth logs. <b>\u201CWhat domain did it call?\u201D</b> \u2192 DNS. <b>\u201CWhat was downloaded?\u201D</b> \u2192 proxy/web logs.</Tip>
        <Quiz title="Quick check · Sources" questions={[
          { q: 'Which log best reveals a malware C2 <i>domain</i> being contacted?', options: ['Firewall log', 'DNS log', 'Email log', 'Application log'], correct: 1, explain: 'DNS logs record domain lookups \u2014 ideal for spotting C2 domains and DNS exfiltration.' },
          { q: 'A Windows logon failure is recorded as which event ID?', options: ['4688', '4625', '404', '200'], correct: 1, explain: '4625 = failed logon; 4624 = successful logon; 4688 = process creation.' },
        ]} />
      </Section>
    ) },

    { id: 's3', render: () => (
      <Section n={3} tag="Time" title="Timestamps & Time Synchronisation" id="s3">
        <p>A timeline is only as trustworthy as its clocks. Logs from different systems must be aligned, or events will appear in the wrong order \u2014 a fatal flaw in any investigation.</p>
        <h3>The two rules of forensic time</h3>
        <ul>
          <li><strong>Synchronise</strong> \u2014 all systems should use NTP so their clocks agree. Record any known drift.</li>
          <li><strong>Normalise to UTC</strong> \u2014 convert every timestamp to one timezone (UTC) before correlating, so 14:03 in London and 09:03 in New York line up correctly.</li>
        </ul>
        <Def term="Time skew">The difference between a system\u2019s clock and true time. Unrecorded skew silently corrupts a timeline \u2014 always note it.</Def>
        <div className="codeblock"><span className="cmt"># Same event, three sources \u2014 normalise before you correlate</span>
Web (UTC):        2025-05-14T<span className="hl">13:02:11Z</span>  GET /login
Firewall (BST):   2025-05-14 <span className="warn">14:02:10</span>     ALLOW 203.0.113.9:443
Auth (UTC):       2025-05-14T<span className="hl">13:02:13Z</span>  Failed password for admin</div>
        <Warn><b>Watch the timezone.</b> The firewall here logs in BST (UTC+1). Convert it to 13:02:10 UTC and the three events snap into a one-second window \u2014 clearly the same activity.</Warn>
        <Quiz title="Quick check · Time" questions={[
          { q: 'Why normalise all timestamps to UTC before correlating?', options: ['UTC is shorter', 'So events from different timezones line up in the correct order', 'It is required by law', 'To save storage'], correct: 1, explain: 'A single reference timezone prevents mis-ordering events across sources.' },
          { q: 'What does unrecorded clock <i>skew</i> do to a timeline?', options: ['Nothing', 'Silently puts events in the wrong order', 'Encrypts the logs', 'Improves accuracy'], correct: 1, explain: 'If a clock is off and you don\u2019t know it, your timeline is wrong.' },
        ]} />
      </Section>
    ) },

    { id: 's4', render: ({ earnBadge }) => (
      <Section n={4} tag="Detection" title="Indicators of Compromise & Suspicious Patterns" id="s4">
        <p>Analysts hunt for <strong>indicators of compromise (IOCs)</strong> and behavioural patterns that betray an attacker. The most common signals:</p>
        <ul>
          <li><strong>Failed-login bursts</strong> \u2014 many failures then a success suggests brute force / password spray.</li>
          <li><strong>Privilege escalation</strong> \u2014 a normal user suddenly gaining admin rights or adding accounts.</li>
          <li><strong>Malware indicators</strong> \u2014 odd process chains, beaconing to a fixed external IP at regular intervals.</li>
          <li><strong>Data exfiltration</strong> \u2014 large outbound transfers, especially off-hours or to unknown hosts.</li>
          <li><strong>Off-hours activity</strong> \u2014 logins or jobs at times the real user never works.</li>
        </ul>
        <h3>Interactive · Log explorer \u2014 flag the suspicious lines</h3>
        <LogExplorer
          prompt="Below is a slice of an authentication & proxy log. Use search and the severity filters, then click every line that is genuinely suspicious. Flag only the bad ones."
          onSolved={() => earnBadge('explorer')}
          lines={[
            { id: 'l1', ts: '08:01:22', sev: 'info', msg: 'Accepted password for j.lee from 10.0.4.12' },
            { id: 'l2', ts: '08:02:05', sev: 'info', msg: 'GET /dashboard 200 \u2014 user j.lee' },
            { id: 'l3', ts: '02:14:03', sev: 'warn', msg: 'Failed password for admin from 203.0.113.9 (attempt 1)', suspicious: true },
            { id: 'l4', ts: '02:14:05', sev: 'warn', msg: 'Failed password for admin from 203.0.113.9 (attempt 2)', suspicious: true },
            { id: 'l5', ts: '02:14:09', sev: 'warn', msg: 'Failed password for admin from 203.0.113.9 (attempt 17)', suspicious: true },
            { id: 'l6', ts: '02:14:11', sev: 'crit', msg: 'Accepted password for admin from 203.0.113.9 after 18 failures', suspicious: true },
            { id: 'l7', ts: '08:30:00', sev: 'info', msg: 'Scheduled backup completed successfully' },
            { id: 'l8', ts: '02:15:40', sev: 'crit', msg: 'User admin added account \u201Csvc_helper\u201D to Administrators group', suspicious: true },
            { id: 'l9', ts: '02:19:55', sev: 'crit', msg: 'Outbound 1.8GB to 185.62.44.10:443 (off-hours, unknown host)', suspicious: true },
            { id: 'l10', ts: '09:05:13', sev: 'info', msg: 'GET /api/health 200' },
            { id: 'l11', ts: '02:16:02', sev: 'warn', msg: 'DNS query for cdn-update-sync.ru (newly seen domain)', suspicious: true },
            { id: 'l12', ts: '09:06:00', sev: 'info', msg: 'Accepted password for p.adeyemi from 10.0.4.40' },
          ]}
        />
        <Quiz title="Quick check · Detection" questions={[
          { q: 'Many failed logins followed by a success from one IP indicates:', options: ['A forgotten password', 'A likely brute-force / password-spray that succeeded', 'A backup job', 'Normal behaviour'], correct: 1, explain: 'A burst of failures then a success is a classic compromised-credential pattern.' },
          { q: 'A large outbound transfer at 02:19 to an unknown host most likely indicates:', options: ['A software update', 'Possible data exfiltration', 'A DNS lookup', 'A failed login'], correct: 1, explain: 'Large off-hours transfers to unknown hosts are a primary exfiltration indicator.' },
        ]} />
      </Section>
    ) },

    { id: 's5', render: ({ earnBadge }) => (
      <Section n={5} tag="Correlation" title="Correlation: Building the Attack Story" id="s5">
        <p>Single events rarely mean much. <strong>Correlation</strong> is connecting events across sources and time into one narrative \u2014 mapping each to a stage of the attack so you can see the whole intrusion.</p>
        <Def term="Correlation">Linking related events from different logs (auth, DNS, proxy, endpoint) by time, host, user, or IP to reveal the sequence of an attack.</Def>
        <h3>Interactive · Match events to attack stages</h3>
        <MatchStages
          prompt="These events all came from the incident above. Map each to the attack stage it represents."
          events={[
            { id: 'e1', label: '18 failed logins then success for <b>admin</b> from 203.0.113.9' },
            { id: 'e2', label: 'admin adds <b>svc_helper</b> to Administrators' },
            { id: 'e3', label: 'DNS lookup of <b>cdn-update-sync.ru</b>, then repeated 443 beacons' },
            { id: 'e4', label: '1.8GB outbound to an unknown host off-hours' },
          ]}
          stages={[
            { id: 'access', label: 'Initial Access (credential brute force)' },
            { id: 'priv', label: 'Privilege Escalation / Persistence' },
            { id: 'c2', label: 'Command & Control' },
            { id: 'exfil', label: 'Exfiltration' },
          ]}
          answer={{ e1: 'access', e2: 'priv', e3: 'c2', e4: 'exfil' }}
          onSolved={() => earnBadge('correlate')}
        />
        <Tip>Read an incident as a <b>story with stages</b>: get in \u2192 dig in \u2192 phone home \u2192 take something. Mapping events to stages turns scattered logs into a clear narrative.</Tip>
        <Quiz title="Quick check · Correlation" questions={[
          { q: 'What is correlation in log analysis?', options: ['Deleting old logs', 'Linking related events across sources into one sequence', 'Encrypting logs', 'Counting log lines'], correct: 1, explain: 'Correlation connects events by time/host/user/IP into a coherent attack story.' },
          { q: 'Beaconing to a fixed external IP at regular intervals maps to which stage?', options: ['Initial Access', 'Command & Control', 'Exfiltration', 'Backup'], correct: 1, explain: 'Regular check-ins to an external host are classic C2 behaviour.' },
        ]} />
      </Section>
    ) },
  ];

  const examQuestions = [
    { q: 'You must find which external domain a suspected malware sample contacted. Which log do you check first?', options: ['Email log', 'DNS log', 'Backup log', 'Application log'], correct: 1, explain: 'DNS logs record domain lookups \u2014 the fastest way to find a C2 domain.' },
    { q: 'A firewall logs in local time (UTC+1) but your other logs are UTC. Before correlating you should:', options: ['Ignore the firewall', 'Convert all timestamps to one timezone (UTC)', 'Delete the timestamps', 'Trust the order as-is'], correct: 1, explain: 'Normalising to a single timezone keeps the timeline correct.' },
    { q: '40 failed logins for one account in two minutes, then a success, most likely indicates:', options: ['A typo', 'A successful brute-force / password spray', 'A scheduled task', 'Normal login'], correct: 1, explain: 'A failure burst ending in success is a hallmark of credential attacks.' },
    { q: 'Which event maps to the <b>Exfiltration</b> stage?', options: ['A failed login', 'A DNS lookup', 'A large off-hours outbound transfer to an unknown host', 'A successful backup'], correct: 2, explain: 'Bulk outbound data to an unknown destination is exfiltration.' },
    { q: 'A standard user account is suddenly added to the Administrators group. This is:', options: ['Routine', 'A privilege-escalation / persistence indicator', 'A DNS event', 'A time-sync issue'], correct: 1, explain: 'Unexpected privilege grants are a key escalation/persistence signal.' },
    { q: 'Windows event ID <b>4624</b> represents:', options: ['A failed logon', 'A successful logon', 'Process creation', 'A service crash'], correct: 1, explain: '4624 = successful logon; 4625 = failed logon.' },
    { q: 'Why is a single log line usually not enough to conclude an incident?', options: ['Logs are always wrong', 'Context comes from correlating multiple events across sources', 'One line is too long', 'Logs cannot be trusted'], correct: 1, explain: 'Correlation across sources provides the context a single line lacks.' },
    { q: 'The safest first questions about logging in any investigation are:', options: ['What brand is the server?', 'What is logged, where, and for how long?', 'Who owns the company?', 'What colour is the UI?'], correct: 1, explain: 'Knowing coverage, location, and retention defines what you can actually investigate.' },
  ];

  const meta = {
    case: 'CASE #DFIR-102',
    eyebrow: 'Module 2 · DFIR Foundation Track',
    title: 'Basic <span class="accent">Log Analysis</span>',
    lede: 'Learn to read the trail systems leave behind \u2014 find suspicious activity, line up timestamps, and correlate events into an attack story, hands-on with Byte.',
    stats: [{ n: '5', label: 'Sections' }, { n: '2', label: 'Interactive labs' }, { n: '8Q', label: 'Final exam' }, { n: '~60m', label: 'Duration' }],
    byteName: 'Log Analysis',
  };

  return <AppShell meta={meta} sections={sections} byteSteps={byteSteps} badges={badges} storeKey="dfir-m2"
    exam={examQuestions} examTag="Investigate the incident" certModule="Basic Log Analysis" />;
}
