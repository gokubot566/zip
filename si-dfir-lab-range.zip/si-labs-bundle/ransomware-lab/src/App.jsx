import { useState, useEffect, useRef, useCallback } from "react";
import { Icons } from "./icons.jsx";
import "@fontsource/ibm-plex-mono/400.css";
import "@fontsource/ibm-plex-mono/500.css";
import "@fontsource/ibm-plex-mono/600.css";
import "@fontsource/ibm-plex-mono/700.css";
import "@fontsource/ibm-plex-sans/400.css";
import "@fontsource/ibm-plex-sans/500.css";
import "@fontsource/ibm-plex-sans/600.css";
import "@fontsource/syne/600.css";
import "@fontsource/syne/700.css";
import "@fontsource/syne/800.css";

// Lab action bus — components emit progress events; Byte gates the Next button.
function labAction(key) {
  try { window.dispatchEvent(new CustomEvent("lab:action", { detail: { key } })); } catch (e) {}
}

/* ═══════════════════════════════════════════════════════════════════
   MERIDIAN FINANCIAL — RANSOMWARE IR LAB  v2.0
   Aesthetic: Industrial dark-ops terminal. IBM Plex Mono + Syne.
   Amber alerts, cyan data, charcoal surfaces. Real ops density.
═══════════════════════════════════════════════════════════════════ */

const CSS = `
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#080c10;
  --s1:#0d1219;
  --s2:#111820;
  --s3:#16202c;
  --s4:#1c2b38;
  --line:#1e2d3d;
  --line2:#243344;
  --cyan:#00e5ff;
  --cyan2:#00b4cc;
  --cyan-dim:rgba(0,229,255,0.08);
  --amber:#ffb830;
  --amber2:#e09800;
  --amber-dim:rgba(255,184,48,0.08);
  --red:#ff4757;
  --red2:#cc2233;
  --red-dim:rgba(255,71,87,0.08);
  --green:#00e676;
  --green-dim:rgba(0,230,118,0.08);
  --purple:#bf8aff;
  --t1:#e8f4ff;
  --t2:#8bacc8;
  --t3:#4a6a88;
  --t4:#2a4055;
  --mono:'IBM Plex Mono',monospace;
  --display:'Syne',sans-serif;
  --ui:'IBM Plex Sans',sans-serif;
  --r:6px;
}
html,body,#root{height:100%;overflow:hidden;background:var(--bg);color:var(--t1);font-family:var(--ui);font-size:13px;line-height:1.5}
::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--line2);border-radius:2px}
::-webkit-scrollbar-thumb:hover{background:var(--t4)}

/* ── Animations ── */
@keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes slideRight{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
@keyframes slideDown{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
@keyframes scanPulse{0%,100%{box-shadow:0 0 0 0 rgba(0,229,255,0.3)}50%{box-shadow:0 0 0 6px rgba(0,229,255,0)}}
@keyframes blink{0%,100%{opacity:1}49%{opacity:1}50%{opacity:0}99%{opacity:0}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes fillBar{from{width:0}to{width:var(--w,100%)}}
@keyframes glitchIn{0%{clip-path:inset(40% 0 50% 0);transform:skew(-2deg)}20%{clip-path:inset(10% 0 80% 0);transform:skew(3deg)}40%{clip-path:inset(60% 0 20% 0);transform:skew(-1deg)}60%{clip-path:inset(20% 0 60% 0);transform:skew(2deg)}80%{clip-path:inset(5% 0 90% 0);transform:skew(0)}100%{clip-path:none;transform:skew(0)}}
@keyframes typewriter{from{opacity:0;transform:translateY(2px)}to{opacity:1;transform:translateY(0)}}
@keyframes encPulse{0%,100%{background:var(--red-dim);border-color:rgba(255,71,87,0.2)}50%{background:rgba(255,71,87,0.15);border-color:rgba(255,71,87,0.4)}}
@keyframes killChainFlow{0%{stroke-dashoffset:200}100%{stroke-dashoffset:0}}

/* ── Base components ── */
button{cursor:pointer;font-family:var(--ui);border:none;outline:none}
input,textarea,select{font-family:var(--mono);background:var(--s3);border:1px solid var(--line2);border-radius:var(--r);color:var(--t1);padding:8px 12px;font-size:12px;outline:none;width:100%;transition:border-color .15s}
input:focus,textarea:focus,select:focus{border-color:var(--cyan)}
textarea{resize:vertical;line-height:1.7}
select{cursor:pointer;appearance:none}
table{border-collapse:collapse;width:100%}
th{text-align:left;font-family:var(--mono);font-size:9px;font-weight:600;letter-spacing:.1em;color:var(--t4);padding:8px 12px;border-bottom:1px solid var(--line);white-space:nowrap;text-transform:uppercase}
td{padding:9px 12px;border-bottom:1px solid var(--line);font-size:12px;vertical-align:middle}
tr:last-child td{border-bottom:none}

/* ── Btn system ── */
.btn{display:inline-flex;align-items:center;gap:6px;padding:7px 16px;border-radius:var(--r);font-size:12px;font-weight:600;font-family:var(--ui);transition:all .15s;white-space:nowrap;letter-spacing:.02em}
.btn-primary{background:var(--cyan-dim);border:1px solid rgba(0,229,255,.3);color:var(--cyan)}
.btn-primary:hover{background:rgba(0,229,255,.14);border-color:rgba(0,229,255,.5)}
.btn-danger{background:var(--red-dim);border:1px solid rgba(255,71,87,.3);color:var(--red)}
.btn-danger:hover{background:rgba(255,71,87,.14)}
.btn-amber{background:var(--amber-dim);border:1px solid rgba(255,184,48,.3);color:var(--amber)}
.btn-amber:hover{background:rgba(255,184,48,.14)}
.btn-ghost{background:transparent;border:1px solid var(--line2);color:var(--t2)}
.btn-ghost:hover{background:var(--s3);color:var(--t1)}
.btn-success{background:var(--green-dim);border:1px solid rgba(0,230,118,.3);color:var(--green)}

/* ── Tag/badge ── */
.tag{display:inline-flex;align-items:center;gap:4px;font-family:var(--mono);font-size:9px;font-weight:700;padding:2px 7px;border-radius:3px;letter-spacing:.06em;white-space:nowrap;text-transform:uppercase}
.dot{width:5px;height:5px;border-radius:50%;display:inline-block;flex-shrink:0}

/* ── Panel card ── */
.panel{background:var(--s1);border:1px solid var(--line);border-radius:var(--r)}
.panel-head{display:flex;align-items:center;gap:8px;padding:10px 16px;border-bottom:1px solid var(--line);background:var(--s2)}
.panel-body{padding:16px}

/* ── Sidebar nav ── */
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 14px;border-radius:5px;font-size:12px;cursor:pointer;transition:all .12s;color:var(--t3);border:1px solid transparent;margin-bottom:2px;font-weight:500}
.nav-item:hover{color:var(--t2);background:var(--s3)}
.nav-item.active{color:var(--cyan);background:rgba(0,229,255,.07);border-color:rgba(0,229,255,.15)}
.nav-item .nav-icon{width:16px;text-align:center;font-size:13px;flex-shrink:0}

/* ── Scrollable area ── */
.scroll{overflow-y:auto;overflow-x:hidden}

/* ── Kbd ── */
kbd{display:inline-block;font-family:var(--mono);font-size:9px;background:var(--s3);border:1px solid var(--line2);border-radius:3px;padding:1px 5px;color:var(--t2)}

/* ── Desktop ── */
.desktop-icon{display:flex;flex-direction:column;align-items:center;gap:6px;padding:10px;border-radius:8px;cursor:pointer;user-select:none;transition:background .12s;text-align:center}
.desktop-icon:hover{background:rgba(255,255,255,.06)}
.desktop-icon.active{background:rgba(0,229,255,.08)}
.icon-img{font-size:32px;line-height:1;filter:drop-shadow(0 2px 8px rgba(0,0,0,.4))}
.icon-label{font-size:10px;color:var(--t1);text-shadow:0 1px 4px rgba(0,0,0,.9);max-width:72px;line-height:1.3;font-weight:500}
.icon-malware .icon-img{filter:drop-shadow(0 0 8px rgba(255,71,87,.7))}
.icon-malware .icon-label{color:#ff8888}

/* ── Taskbar ── */
.taskbar{position:fixed;bottom:0;left:0;right:0;height:44px;background:rgba(8,12,16,.95);backdrop-filter:blur(20px);border-top:1px solid var(--line);display:flex;align-items:center;padding:0 12px;gap:4px;z-index:900}
.tb-btn{display:flex;flex-direction:column;align-items:center;gap:2px;padding:4px 10px;border-radius:5px;background:transparent;color:var(--t3);font-size:16px;min-width:48px;transition:all .12s;position:relative;border:1px solid transparent}
.tb-btn:hover{background:var(--s3);color:var(--t2)}
.tb-btn.open{background:var(--s3);color:var(--cyan);border-color:var(--line)}
.tb-btn.alert{color:var(--amber)}
.tb-btn .tb-label{font-size:8px;letter-spacing:.04em;font-family:var(--mono)}
.tb-pip{position:absolute;bottom:3px;left:50%;transform:translateX(-50%);width:16px;height:2px;border-radius:1px;background:var(--cyan)}
.tb-badge{position:absolute;top:2px;right:6px;min-width:14px;height:14px;border-radius:7px;background:var(--red);color:#fff;font-size:8px;font-weight:800;display:flex;align-items:center;justify-content:center;font-family:var(--mono);padding:0 3px;border:1.5px solid var(--bg)}

/* ── Topbar ── */
.topbar{height:48px;background:var(--s1);border-bottom:1px solid var(--line);display:flex;align-items:center;padding:0 20px;gap:12px;flex-shrink:0}

/* ── Modal overlay ── */
.modal-overlay{position:fixed;inset:0;background:rgba(8,12,16,.8);backdrop-filter:blur(6px);z-index:800;display:flex;align-items:center;justify-content:center;padding:20px;animation:fadeIn .15s ease-out}
.modal-box{background:var(--s1);border:1px solid var(--line2);border-radius:10px;width:100%;max-height:calc(100vh - 80px);overflow:hidden;display:flex;flex-direction:column;box-shadow:0 24px 80px rgba(0,0,0,.8),0 0 0 1px rgba(0,229,255,.06);animation:fadeUp .2s ease-out}
.modal-head{display:flex;align-items:center;gap:10px;padding:14px 20px;border-bottom:1px solid var(--line);flex-shrink:0;background:var(--s2)}
.modal-body{padding:20px;overflow-y:auto;flex:1}
.modal-foot{padding:14px 20px;border-top:1px solid var(--line);display:flex;gap:8px;flex-shrink:0;background:var(--s2)}

/* ── Ransom overlay ── */
.ransom-overlay{position:fixed;inset:0;z-index:9000;background:#0a0000;display:flex;align-items:center;justify-content:center}
.ransom-terminal{position:fixed;inset:0;z-index:8500;background:#050505;font-family:var(--mono);font-size:12px;padding:24px;overflow:hidden}
.term-line{animation:typewriter .1s ease-out both}

/* ── Score ── */
.score-pill{position:fixed;top:12px;right:12px;background:var(--s2);border:1px solid rgba(0,229,255,.2);border-radius:20px;padding:6px 16px;font-family:var(--mono);font-size:12px;color:var(--cyan);z-index:1000;display:flex;align-items:center;gap:8px;box-shadow:0 4px 20px rgba(0,0,0,.5)}

/* ── Kill chain ── */
.kc-node{display:flex;flex-direction:column;align-items:center;gap:6px;cursor:default}
.kc-circle{width:44px;height:44px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;border:2px solid;transition:all .3s;position:relative}
.kc-circle.active{animation:scanPulse 2s ease-in-out infinite}
.kc-label{font-size:9px;font-family:var(--mono);text-align:center;max-width:64px;line-height:1.3;text-transform:uppercase;letter-spacing:.06em}

/* ── Alert row ── */
.alert-row{padding:10px 14px;border-bottom:1px solid var(--line);cursor:pointer;transition:background .1s;border-left:2px solid transparent;animation:slideDown .2s ease-out both}
.alert-row:hover{background:var(--s3)}
.alert-row.selected{background:var(--s3);border-left-color:var(--cyan)}
.alert-row.crit{border-left-color:var(--red)}
.alert-row.high{border-left-color:var(--amber)}

/* ── Timeline ── */
.tl-item{display:flex;gap:14px;margin-bottom:12px;animation:fadeUp .2s ease-out both}
.tl-line{display:flex;flex-direction:column;align-items:center;gap:0;width:16px;flex-shrink:0}
.tl-dot{width:10px;height:10px;border-radius:50%;border:2px solid var(--bg);flex-shrink:0;margin-top:4px}
.tl-connector{flex:1;width:1px;background:var(--line);min-height:20px}
.tl-card{flex:1;background:var(--s2);border:1px solid var(--line);border-radius:var(--r);padding:10px 14px;border-left:3px solid}

/* ── IOC row ── */
.ioc-row{display:flex;align-items:center;gap:12px;padding:10px 14px;border-bottom:1px solid var(--line);transition:background .1s}
.ioc-row:hover{background:var(--s2)}
.ioc-row:last-child{border-bottom:none}

/* ── DFIR tabs ── */
.dfir-tab{padding:9px 16px;font-size:11px;font-weight:600;letter-spacing:.04em;cursor:pointer;background:transparent;border-bottom:2px solid transparent;color:var(--t3);transition:all .12s;white-space:nowrap;font-family:var(--mono)}
.dfir-tab:hover{color:var(--t2)}
.dfir-tab.active{color:var(--cyan);border-bottom-color:var(--cyan)}

/* ── Metric card ── */
.metric{background:var(--s2);border:1px solid var(--line);border-radius:var(--r);padding:14px 16px}
.metric-val{font-family:var(--display);font-size:26px;font-weight:800;line-height:1;margin-top:4px}
.metric-label{font-family:var(--mono);font-size:9px;text-transform:uppercase;letter-spacing:.1em;color:var(--t4)}

/* ── Progress bar ── */
.prog-track{height:3px;background:var(--line);border-radius:2px;overflow:hidden}
.prog-fill{height:100%;border-radius:2px;transition:width .6s ease-out}

/* ── Evidence ── */
.ev-item{display:flex;gap:14px;padding:12px 16px;border-bottom:1px solid var(--line);align-items:center}
.ev-item:last-child{border-bottom:none}
.ev-icon{width:38px;height:38px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}

/* ── VT ── */
.vt-ring{width:90px;height:90px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;flex-shrink:0;font-family:var(--mono)}

/* ── Backup ── */
.bk-row{background:var(--s2);border:1px solid var(--line);border-radius:var(--r);padding:12px 16px;margin-bottom:8px;border-left:3px solid}

/* ── CMD ── */
.cmd-win{background:#050505;border-radius:var(--r);padding:16px;font-family:var(--mono);font-size:11px;line-height:1.8;min-height:200px}
.cmd-line{animation:typewriter .12s ease-out both}

/* ── Byte ── */
.byte-widget{position:fixed;z-index:9500}
.byte-launcher{width:50px;height:50px;border-radius:50%;background:var(--s2);border:1.5px solid rgba(0,229,255,.4);display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 4px 20px rgba(0,0,0,.5),0 0 0 4px rgba(0,229,255,.05);transition:all .2s;font-size:22px;position:absolute;bottom:0;right:0}
.byte-launcher:hover{border-color:var(--cyan);box-shadow:0 4px 20px rgba(0,0,0,.5),0 0 0 6px rgba(0,229,255,.1)}
.byte-badge{position:absolute;top:-3px;right:-3px;min-width:16px;height:16px;border-radius:8px;background:var(--red);color:#fff;font-size:9px;font-weight:800;display:flex;align-items:center;justify-content:center;font-family:var(--mono);padding:0 3px;border:1.5px solid var(--bg)}
.byte-panel{position:absolute;background:var(--s1);border:1px solid rgba(0,229,255,.2);border-radius:10px;box-shadow:0 20px 60px rgba(0,0,0,.8);display:flex;flex-direction:column;overflow:hidden;animation:fadeUp .2s ease-out}
.byte-head{display:flex;align-items:center;gap:8px;padding:11px 14px;border-bottom:1px solid var(--line);background:var(--s2);cursor:grab;user-select:none;flex-shrink:0}
.byte-head:active{cursor:grabbing}
.byte-body{flex:1;overflow-y:auto;padding:14px}
.byte-body p{font-size:12px;color:var(--t2);line-height:1.8;margin-bottom:8px}
.byte-body b{color:var(--t1);font-weight:600}
.byte-action{margin:0 14px 0;padding:8px 12px;background:rgba(255,184,48,.07);border:1px solid rgba(255,184,48,.2);border-radius:6px;font-size:11px;color:var(--amber);line-height:1.4;flex-shrink:0}
.byte-foot{display:flex;align-items:center;gap:6px;padding:10px 14px;border-top:1px solid var(--line);flex-shrink:0;background:var(--s2)}
.byte-prog{height:2px;background:var(--line);border-radius:1px;overflow:hidden;margin:6px 14px 0;flex-shrink:0}
.byte-prog-fill{height:100%;background:linear-gradient(90deg,var(--cyan),var(--purple));transition:width .4s ease-out}
.byte-step-title{font-size:12px;font-weight:700;color:var(--cyan);margin-bottom:8px;font-family:var(--mono);display:flex;align-items:center;gap:7px}
.byte-num{font-size:9px;padding:1px 7px;border-radius:10px;background:rgba(0,229,255,.1);border:1px solid rgba(0,229,255,.2);color:var(--cyan);font-family:var(--mono);font-weight:800}
.byte-nav-hint{font-size:10px;color:var(--t4);font-family:var(--mono);background:rgba(0,229,255,.04);border:1px solid var(--line);border-radius:4px;padding:3px 8px;margin-bottom:8px;display:inline-block}
.byte-dot{animation:pulse 2s ease-in-out infinite}
`;

// ─── DATA ────────────────────────────────────────────────────────────────────
const RANSOM_NOTE = `!!!  YOUR FILES HAVE BEEN ENCRYPTED  !!!
Threat Actor: BLACKMATTER PRO v4.2
Victim ID:    MFS-2026-BM-7741-ALPHA
Files locked: 84,721 across 14 shares
Algorithm:    AES-256-CBC + RSA-4096

All documents, databases and backups on this
network have been encrypted and are inaccessible.

DECRYPT PORTAL: http://bm4decrypt.onion/MFS-7741
DEMAND:         2.4 BTC ($94,500 USD)
DEADLINE:       72 hours — then price doubles

Contact: bm-support@protonmail.com
DO NOT contact law enforcement.
DO NOT attempt third-party decryption tools.
`;

const CMD_LINES = [
  {t:200,  c:"cyan",   s:"C:\\Users\\sarah.chen> Invoice_Q4_2026.exe /silent"},
  {t:500,  c:"green",  s:"[*] Payload initialised — BlackMatter Pro v4.2"},
  {t:750,  c:"green",  s:"[*] Domain: MERIDIANFIN.LOCAL | User: sarah.chen"},
  {t:950,  c:"yellow", s:"[+] Enumerating network shares..."},
  {t:1100, c:"green",  s:"[+] \\\\MFS-FS01\\Finance    (WRITABLE, 2.4TB)"},
  {t:1200, c:"green",  s:"[+] \\\\MFS-FS01\\HR         (WRITABLE, 890GB)"},
  {t:1300, c:"green",  s:"[+] \\\\MFS-FS01\\Legal      (WRITABLE, 1.1TB)"},
  {t:1400, c:"green",  s:"[+] \\\\MFS-FS01\\Trading    (WRITABLE, 4.2TB)"},
  {t:1500, c:"green",  s:"[+] 14 shares identified — total 16.8TB"},
  {t:1700, c:"red",    s:"[!] Deleting VSS shadow copies..."},
  {t:1900, c:"red",    s:"[!] vssadmin delete shadows /all /quiet → 12 copies DELETED"},
  {t:2100, c:"yellow", s:"[*] Dropping persistence payload..."},
  {t:2300, c:"green",  s:"[+] C:\\ProgramData\\svchost.exe written"},
  {t:2500, c:"green",  s:"[+] Registry key: HKLM\\...\\Run\\SvcHostSvc"},
  {t:2700, c:"yellow", s:"[*] Establishing C2 beacon → 94.102.49.193:443"},
  {t:2900, c:"green",  s:"[+] Session established. ID: BM-7741"},
  {t:3100, c:"red",    s:"[!] BEGINNING ENCRYPTION CYCLE..."},
  {t:3300, c:"red",    s:"[>>] Encrypting Finance\\Q4_Reports\\earnings_2026.xlsx"},
  {t:3400, c:"red",    s:"[>>] Encrypting HR\\payroll_nov_2026.xlsx"},
  {t:3500, c:"red",    s:"[>>] Encrypting Legal\\FSCA_RegFiling_Q3.pdf"},
  {t:3600, c:"red",    s:"[>>] Encrypting 84,718 files remaining..."},
  {t:3800, c:"red",    s:"[+] Writing README_DECRYPT.txt to all shares"},
  {t:4000, c:"red",    s:"[✓] ENCRYPTION COMPLETE — 84,721 files locked"},
];

const ALERTS = [
  {id:"ALT-001",sev:"critical",time:"02:11:03",host:"WKSTN-SC-04",title:"Malicious file executed — Invoice_Q4_2026.exe",rule:"MAL-EXEC-001",detail:"EDR detected ransomware dropper execution. User: sarah.chen. Process spawned vssadmin + svchost copy.",mitre:"T1204.002"},
  {id:"ALT-002",sev:"critical",time:"02:11:06",host:"WKSTN-SC-04",title:"C2 outbound — 94.102.49.193:443 (BlackMatter)",rule:"C2-BEACON-007",detail:"Outbound HTTPS beacon to known BlackMatter C2 node. OVH Netherlands. Matches FS-ISAC TI feed.",mitre:"T1071.001"},
  {id:"ALT-003",sev:"critical",time:"02:11:09",host:"WKSTN-SC-04",title:"VSS shadow copy deletion — 12 copies destroyed",rule:"VSS-DEL-001",detail:"vssadmin.exe executed with /all /quiet flags. All 12 local snapshots deleted — local recovery blocked.",mitre:"T1490"},
  {id:"ALT-004",sev:"high",    time:"02:11:12",host:"WKSTN-SC-04",title:"Suspicious file drop — ProgramData\\svchost.exe",rule:"PERSIST-003",detail:"Malware copied to ProgramData masquerading as svchost.exe. Registry Run key added for persistence.",mitre:"T1036.005"},
  {id:"ALT-005",sev:"critical",time:"02:14:19",host:"FILESVR-01",  title:"FIM ALERT — Mass file modification: 247 files/sec",rule:"FIM-MASS-001",detail:"File Integrity Monitor: 247 file modifications per second on FILESVR-01. Extensions changing to .locked.",mitre:"T1486"},
  {id:"ALT-006",sev:"critical",time:"02:14:22",host:"FILESVR-01",  title:"Ransomware encryption in progress — .locked extension",rule:"RANSOM-001",detail:"2,847 .locked extension changes in 4 minutes across Finance and HR shares.",mitre:"T1486"},
  {id:"ALT-007",sev:"high",    time:"02:16:44",host:"FILESVR-01",  title:"Ransom note written to 14 network shares",rule:"RANSOM-002",detail:"README_DECRYPT.txt created simultaneously across all 14 SMB shares — encryption cycle complete.",mitre:"T1486"},
  {id:"ALT-008",sev:"critical",time:"02:18:41",host:"FILESVR-01",  title:"Encryption complete — 84,721 files locked in 4m 22s",rule:"RANSOM-003",detail:"FIM final count: 84,721 file modification events. All 14 shares fully encrypted. Attack duration: 7m 38s.",mitre:"T1486"},
];

const IOCS = [
  {id:"IOC-001",type:"IPv4",  value:"185.220.101.47",          conf:"High",  tlp:"AMBER",status:"blocked",   desc:"Phishing email origin — Tor exit node, OVH Romania",          mitre:"T1566.001"},
  {id:"IOC-002",type:"Domain",value:"meridian-suppliers.net",  conf:"High",  tlp:"RED",  status:"blocked",   desc:"Phishing domain — registered 2026-11-09 (4 days before attack)",mitre:"T1566.001"},
  {id:"IOC-003",type:"Hash",  value:"3a7f9c2e4b8d1f6a5e8c...", conf:"High",  tlp:"RED",  status:"active",    desc:"SHA-256: Invoice_Q4_2026.exe — BlackMatter Pro v4.2 dropper",  mitre:"T1204.002"},
  {id:"IOC-004",type:"IPv4",  value:"94.102.49.193",           conf:"High",  tlp:"RED",  status:"blocked",   desc:"C2 beacon destination — HTTPS:443, BlackMatter C2 node",      mitre:"T1071.001"},
  {id:"IOC-005",type:"Domain",value:"bm4decrypt.onion",        conf:"High",  tlp:"RED",  status:"active",    desc:"Ransom payment portal (Tor hidden service)",                  mitre:"T1219"},
  {id:"IOC-006",type:"Path",  value:"C:\\ProgramData\\svchost.exe",conf:"High",tlp:"AMBER",status:"remediated",desc:"Malware persistence — masquerading as Windows svchost",     mitre:"T1036.005"},
  {id:"IOC-007",type:"Email", value:"ap@meridian-suppliers.net",conf:"High", tlp:"AMBER",status:"active",    desc:"Phishing sender address — typosquat domain",                 mitre:"T1566"},
];

const TIMELINE = [
  {time:"02:09:44",phase:"delivery",  actor:"Threat Actor",    evt:"Phishing email delivered to sarah.chen — Invoice_Q4_2026.exe attachment from meridian-suppliers.net"},
  {time:"02:11:03",phase:"execution", actor:"sarah.chen",      evt:"Invoice_Q4_2026.exe executed on WKSTN-SC-04 — user opened attachment"},
  {time:"02:11:06",phase:"c2",        actor:"Malware",         evt:"C2 beacon established to 94.102.49.193:443 — session ID BM-7741"},
  {time:"02:11:09",phase:"impact",    actor:"Malware",         evt:"12 VSS shadow copies deleted via vssadmin — local recovery path eliminated"},
  {time:"02:11:12",phase:"persist",   actor:"Malware",         evt:"Persistence established: ProgramData\\svchost.exe + HKLM Run registry key"},
  {time:"02:14:19",phase:"impact",    actor:"Malware",         evt:"Encryption commenced — 247 file modifications/sec on FILESVR-01"},
  {time:"02:18:41",phase:"impact",    actor:"Malware",         evt:"Encryption complete — 84,721 files locked across 14 shares in 4m 22s"},
  {time:"02:19:00",phase:"detection", actor:"SIEM",            evt:"Critical alerts raised — FIM mass modification + EDR correlation"},
  {time:"02:21:44",phase:"response",  actor:"SOC Analyst",     evt:"Alert acknowledged — incident response initiated"},
];

const PHASE_CLR = {delivery:"#ff4757",execution:"#ff6b35",c2:"#bf8aff",impact:"#ff4757",persist:"#ffb830",detection:"#00e676",response:"#00e5ff"};

const MITRE_MAP = [
  {id:"T1566.001",name:"Spearphishing Attachment",phase:"Initial Access",  clr:"#ff4757",status:"confirmed",desc:"Phishing email with .exe attachment sent to sarah.chen from typosquat domain"},
  {id:"T1204.002",name:"User Execution: Malicious File",phase:"Execution", clr:"#ff6b35",status:"confirmed",desc:"sarah.chen double-clicked Invoice_Q4_2026.exe on WKSTN-SC-04 at 02:11 UTC"},
  {id:"T1547.001",name:"Registry Run Keys",          phase:"Persistence",  clr:"#ffb830",status:"confirmed",desc:"Run key written to HKLM\\...\\Run\\SvcHostSvc for reboot persistence"},
  {id:"T1036.005",name:"Masquerading: Match Legit Name",phase:"Def. Evasion",clr:"#00b4cc",status:"confirmed",desc:"Payload copied to ProgramData\\svchost.exe mimicking Windows process"},
  {id:"T1021.002",name:"SMB/Windows Admin Shares",   phase:"Lateral Mvmt", clr:"#bf8aff",status:"confirmed",desc:"sarah.chen domain credentials used to mount and encrypt 14 SMB shares"},
  {id:"T1490",    name:"Inhibit System Recovery",    phase:"Impact",       clr:"#ff4757",status:"confirmed",desc:"12 VSS shadow copies deleted via vssadmin.exe /all /quiet"},
  {id:"T1486",    name:"Data Encrypted for Impact",  phase:"Impact",       clr:"#ff4757",status:"confirmed",desc:"AES-256-CBC + RSA-4096 encryption of 84,721 files — ransom note deployed"},
  {id:"T1071.001",name:"Web Protocols C2",           phase:"C&C",         clr:"#bf8aff",status:"confirmed",desc:"HTTPS beacon to 94.102.49.193 every 300s — custom User-Agent header"},
];

const BACKUPS = [
  {share:"Finance",   size:"2.4 TB",last:"2026-11-13 23:00",rpo:"3h",  loc:"Azure Blob",  status:"good",    note:"Clean backup confirmed"},
  {share:"HR",        size:"890 GB", last:"2026-11-13 23:00",rpo:"3h",  loc:"Azure Blob",  status:"good",    note:"Clean backup confirmed"},
  {share:"Legal",     size:"1.1 TB", last:"2026-11-12 23:00",rpo:"27h", loc:"Azure Cool",  status:"warning", note:"27h old — some data loss expected"},
  {share:"Trading",   size:"4.2 TB", last:"2026-11-13 23:00",rpo:"3h",  loc:"Tape Offsite",status:"good",    note:"Restore may take 4-6h"},
  {share:"Compliance",size:"340 GB", last:"2026-11-10 23:00",rpo:"99h", loc:"Azure Cool",  status:"critical",note:"Backup failed 4 days — HIGH data loss risk"},
  {share:"Archive",   size:"8.1 TB", last:"2026-11-07 23:00",rpo:"168h",loc:"Tape Vault",  status:"critical",note:"Week-old backup — significant loss expected"},
];

const EVIDENCE = [
  {id:"EV-001",type:"Email",  icon:"✉",  clr:"#ffb830",name:"Phishing email — raw EML export",             hash:"sha256:3a7f9c2e...",size:"44 KB", added:"02:20"},
  {id:"EV-002",type:"Binary", icon:"⚙",  clr:"#ff4757",name:"Invoice_Q4_2026.exe — malware dropper",        hash:"sha256:3a7f9c2e...",size:"186 KB",added:"02:22"},
  {id:"EV-003",type:"Logs",   icon:"≡",  clr:"#00e5ff",name:"FIM event log — 84,721 encryption events",    hash:"sha256:f2d8a4c7...",size:"12.4 MB",added:"02:24"},
  {id:"EV-004",type:"Text",   icon:"📄", clr:"#ff4757",name:"README_DECRYPT.txt — ransom note (14 copies)", hash:"sha256:b9e3d1f5...",size:"2.1 KB", added:"02:25"},
  {id:"EV-005",type:"Memory", icon:"💾", clr:"#bf8aff",name:"WKSTN-SC-04 memory dump — live forensics",     hash:"sha256:c4a8e2f1...",size:"8.2 GB", added:"02:30"},
  {id:"EV-006",type:"PCAP",   icon:"📡", clr:"#00e676",name:"Network capture — C2 traffic 94.102.49.193",  hash:"sha256:7e2b9d4f...",size:"2.8 MB", added:"02:28"},
];

const PHISHING_EMAIL = {
  from:"accounts-payable@meridian-suppliers.net",
  to:"sarah.chen@meridianfinancial.com",
  subject:"URGENT: Q4 Invoice #INV-2026-4891 — Payment Overdue",
  date:"2026-11-13 09:44 UTC",
  spf:"FAIL", dkim:"FAIL", dmarc:"FAIL",
  originIp:"185.220.101.47",
  spamScore:"7.8",
  body:`Dear Sarah,

Our Q4 invoice INV-2026-4891 for $47,200 is now 14 days overdue.

This is our final notice. Failure to process payment will result in
suspension of services and legal action.

Please open the attached invoice for payment instructions.

  → Invoice_Q4_2026.exe

Best regards,
James Whitfield — Accounts Payable
Meridian Suppliers Ltd`,
  indicators:[
    {sev:"critical",text:"Domain meridian-suppliers.net registered 4 days before attack (WHOIS: 2026-11-09)"},
    {sev:"critical",text:"SPF FAIL / DKIM FAIL / DMARC FAIL — email unauthenticated, not from legitimate server"},
    {sev:"critical",text:"Reply-To: ap.recovery@gmail.com — redirects replies to attacker Gmail"},
    {sev:"high",    text:".exe attachment disguised as invoice — no legitimate supplier sends .exe files"},
    {sev:"high",    text:"Originating IP 185.220.101.47 — Tor exit node, AbuseIPDB confidence 97%"},
    {sev:"medium",  text:"Urgency + legal threat language — classic social engineering pressure tactic"},
  ],
};

const VT_DATA = {
  "Invoice_Q4_2026.exe":{detect:73,total:94,family:"BlackMatter",type:"Ransomware",tags:["ransomware","dropper","vss-killer","encrypt"]},
  "185.220.101.47":     {detect:89,total:94,family:"Tor/BulletProof",type:"Malicious IP",tags:["tor-exit","phishing","malware"]},
  "94.102.49.193":      {detect:67,total:94,family:"BlackMatter C2",type:"Malicious IP",tags:["c2","ransomware","blackmatter"]},
  "meridian-suppliers.net":{detect:45,total:94,family:"Phishing",type:"Domain",tags:["phishing","typosquat","new-domain"]},
};

const BYTE_STEPS = [
  {id:1,title:"Welcome to the IR Lab",nav:null,
   content:`<p>I'm <b>Byte</b> — your IR training guide.</p><p>You are <b>Alex Rivera, SOC Analyst II</b> at Meridian Financial Services. A ransomware attack has occurred or is about to occur.</p><p>Work through <b>5 phases</b>: Triage → Containment → Investigation → Recovery → Reporting. I'll guide each step.</p>`,action:null},
  {id:2,title:"Trigger the Incident",nav:"desktop",
   content:`<p>To experience the full simulation, <b>double-click Invoice_Q4_2026.exe</b> on the desktop (red glow icon).</p><p>This shows exactly how BlackMatter Pro v4.2 was deployed — share enumeration, VSS deletion, C2 beacon, and encryption of 84,721 files.</p>`,
   action:"Double-click Invoice_Q4_2026.exe on the desktop", gate:"exe-run"},
  {id:3,title:"Phase 1 — Open Security Alerts",nav:"alerts",
   content:`<p>After the attack triggers, open <b>Security Alerts</b> (the amber-pulsing shield icon).</p><p>You'll see <b>8 SIEM alerts</b> — EDR detections, FIM mass-modification events, and C2 beacon alerts. Click each to expand. Acknowledge the critical ones to register them.</p>`,
   action:"Open Security Alerts and acknowledge ALT-001, ALT-005, ALT-008", gate:"nav:alerts"},
  {id:4,title:"Read the Kill Chain",nav:"alerts",
   content:`<p>The correlated alert pattern tells the whole story:</p><p><b>ALT-001</b> — .exe executed → <b>ALT-002</b> — C2 beacon → <b>ALT-003</b> — VSS deleted → <b>ALT-005</b> — mass encryption → <b>ALT-008</b> — complete.</p><p>This is a <b>human-operated</b> ransomware deployment — deliberate, targeted, and fast.</p>`,action:null},
  {id:5,title:"Phase 2 — Open DFIR Platform",nav:"dfir",
   content:`<p>Open <b>CipherOps DFIR</b> from the taskbar. This is your full investigation console — case management, IOC tracking, ATT&amp;CK mapping, evidence vault.</p><p>The case <b>INC-2026-BM-001</b> is pre-loaded. Start with the <b>Overview</b> tab.</p>`,
   action:"Open CipherOps DFIR from the taskbar", gate:"nav:dfir"},
  {id:6,title:"Block IOCs",nav:"dfir",
   content:`<p>In the <b>IOCs tab</b>, block all active indicators:</p><p>• <b>IOC-003</b> — malware hash<br/>• <b>IOC-005</b> — ransom payment portal<br/>• <b>IOC-007</b> — phishing sender</p><p>Each block earns <b>+15 pts</b> and reduces re-infection risk.</p>`,
   action:"Open IOCs tab → Block all 3 active indicators", gate:"iocs-blocked"},
  {id:7,title:"Map ATT&CK Techniques",nav:"dfir",
   content:`<p>Open the <b>ATT&amp;CK tab</b>. Eight confirmed techniques are mapped across the kill chain.</p><p>Critical for your report: <b>T1490</b> (VSS deletion) means local recovery is impossible — cloud backups are the only path. <b>T1486</b> is the primary impact technique.</p>`,action:null},
  {id:8,title:"Investigate the Email",nav:"outlook",
   content:`<p>Open <b>Outlook</b> and click the phishing email from <b>meridian-suppliers.net</b>.</p><p>Six indicators are highlighted — SPF/DKIM/DMARC all FAIL, .exe attachment, Tor origin IP, and a typosquat domain registered 4 days before the attack.</p>`,
   action:"Open Outlook → click the phishing email", gate:"nav:outlook"},
  {id:9,title:"Run VirusTotal Lookups",nav:"vt",
   content:`<p>Open <b>VirusTotal</b> from the taskbar. Analyse the key IOCs:</p><p>• <b>Invoice_Q4_2026.exe</b> — 73/94 detections (BlackMatter)<br/>• <b>185.220.101.47</b> — 89/94 (Tor exit node)<br/>• <b>94.102.49.193</b> — 67/94 (C2 server)</p>`,
   action:"Open VirusTotal and analyse Invoice_Q4_2026.exe", gate:"nav:vt"},
  {id:10,title:"Check Backups",nav:"backup",
   content:`<p>Open <b>Azure Backup</b>. Finance and HR have clean 3h-old backups — restore these first.</p><p>⚠ Compliance share backup failed for 4 days — HIGH data loss risk. This is a critical finding for your regulatory report.</p>`,
   action:"Open Azure Backup → restore Finance and HR shares", gate:"backup-restored"},
  {id:11,title:"Write Analyst Notes",nav:"dfir",
   content:`<p>Return to DFIR, open the <b>Notes tab</b>. Document your findings: root cause, containment actions, evidence collected, recovery plan.</p><p>Good notes are the difference between a strong IR report and a weak one. Save for <b>+20 pts</b>.</p>`,
   action:"DFIR → Notes tab → write and save your findings", gate:"notes-saved"},
  {id:12,title:"File Executive Report",nav:"dfir",
   content:`<p>Open the <b>Report tab</b> in DFIR. Under GDPR Article 33 and FSCA regulations you have <b>72 hours</b> to notify the supervisory authority.</p><p>Complete all fields covering root cause, containment, recovery plan, and regulatory obligations. Submit for max scoring.</p>`,
   action:"DFIR → Report tab → complete and submit", gate:"report-filed"},
  {id:13,title:"Lab Complete",nav:null,
   content:`<p>You've completed the Meridian IR Lab!</p><p><b>Skills practised:</b><br/>✅ SIEM alert triage<br/>✅ Phishing email analysis<br/>✅ IOC extraction and blocking<br/>✅ ATT&amp;CK technique mapping<br/>✅ Backup RPO analysis<br/>✅ Regulatory reporting (GDPR/FSCA)</p>`,action:null},
];

// ─── UTILITIES ────────────────────────────────────────────────────────────────
function useStyles() {
  useEffect(() => {
    const id = "mir-styles";
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id;
    el.textContent = CSS;
    document.head.insertBefore(el, document.head.firstChild);
  }, []);
}

function useClock() {
  const base = useRef(new Date("2026-11-14T02:18:44Z"));
  const [s, setS] = useState(base.current.toLocaleTimeString("en-GB",{hour:"2-digit",minute:"2-digit",second:"2-digit"}));
  useEffect(() => {
    const i = setInterval(() => {
      base.current = new Date(base.current.getTime() + 1000);
      setS(base.current.toLocaleTimeString("en-GB",{hour:"2-digit",minute:"2-digit",second:"2-digit"}));
    }, 1000);
    return () => clearInterval(i);
  }, []);
  return s;
}

function sevColor(sev) {
  if (sev === "critical") return "var(--red)";
  if (sev === "high")     return "var(--amber)";
  if (sev === "medium")   return "var(--cyan)";
  return "var(--t3)";
}

function SevTag({ sev }) {
  const c = sevColor(sev);
  return <span className="tag" style={{background:`${c}15`,color:c,border:`1px solid ${c}30`}}>
    <span className="dot" style={{background:c}} />{sev}
  </span>;
}

function TlpTag({ tlp }) {
  const c = tlp==="RED"?"#ff4757":tlp==="AMBER"?"#ffb830":"#8bacc8";
  return <span className="tag" style={{background:`${c}15`,color:c,border:`1px solid ${c}30`}}>TLP:{tlp}</span>;
}

// ─── KILL CHAIN VISUALISER ────────────────────────────────────────────────────
function KillChain({ active }) {
  const nodes = [
    {icon:"📧",label:"Delivery",    clr:"#ff4757",phase:"delivery"},
    {icon:"⚙️", label:"Execution",  clr:"#ff6b35",phase:"execution"},
    {icon:"📡",label:"C2 Beacon",   clr:"#bf8aff",phase:"c2"},
    {icon:"🗑",label:"VSS Delete",  clr:"#ffb830", phase:"impact"},
    {icon:"🔗",label:"Persistence", clr:"#ffb830", phase:"persist"},
    {icon:"🔐",label:"Encrypt",     clr:"#ff4757", phase:"impact2"},
  ];
  return (
    <div style={{display:"flex",alignItems:"center",gap:0,padding:"16px 20px",overflowX:"auto"}}>
      {nodes.map((n,i) => (
        <div key={i} style={{display:"flex",alignItems:"center"}}>
          <div className="kc-node">
            <div className="kc-circle" style={{
              background:`${n.clr}12`,borderColor:`${n.clr}${active?"80":"30"}`,
              boxShadow: active ? `0 0 16px ${n.clr}30` : "none",
            }}>
              <span style={{fontSize:18}}>{n.icon}</span>
              {active && <div style={{position:"absolute",bottom:-4,left:"50%",transform:"translateX(-50%)",width:6,height:6,borderRadius:"50%",background:n.clr,animation:"scanPulse 2s ease-in-out infinite"}} />}
            </div>
            <span className="kc-label" style={{color: active ? n.clr : "var(--t4)"}}>{n.label}</span>
          </div>
          {i < nodes.length-1 && (
            <div style={{width:32,height:1,background: active ? `linear-gradient(90deg,${n.clr},${nodes[i+1].clr})` : "var(--line)",margin:"0 4px",marginBottom:20,flexShrink:0}} />
          )}
        </div>
      ))}
    </div>
  );
}

// ─── RANSOMWARE EXECUTION SEQUENCE ──────────────────────────────────────────
function RansomExec({ onDone }) {
  const [lines, setLines] = useState([]);
  const [enc, setEnc]     = useState(0);
  const [phase, setPhase] = useState("cmd"); // cmd | ransom
  const rafRef = useRef(null);
  const encRef = useRef(null);

  useEffect(() => {
    const timers = CMD_LINES.map(({t,c,s}) =>
      setTimeout(() => setLines(p => [...p,{c,s}]), t)
    );
    timers.push(setTimeout(() => setPhase("ransom"), 4200));
    timers.push(setTimeout(() => onDone(), 7500));

    // Encryption counter
    let count = 0;
    const id = setInterval(() => {
      count += Math.floor(Math.random() * 600 + 300);
      setEnc(Math.min(84721, count));
      if (count >= 84721) clearInterval(id);
    }, 120);
    encRef.current = id;

    return () => { timers.forEach(clearTimeout); clearInterval(encRef.current); };
  }, []);

  if (phase === "ransom") {
    return (
      <div className="ransom-overlay">
        <div style={{
          background:"#0d0000",border:"1px solid rgba(255,71,87,.5)",borderRadius:10,
          padding:"40px 48px",maxWidth:580,width:"100%",textAlign:"center",
          boxShadow:"0 0 80px rgba(255,71,87,.2)",animation:"fadeUp .4s ease-out",
        }}>
          <div style={{fontSize:48,marginBottom:16}}>💀</div>
          <div style={{fontFamily:"var(--display)",fontSize:22,fontWeight:800,color:"var(--red)",marginBottom:4,letterSpacing:".04em"}}>
            YOUR FILES HAVE BEEN ENCRYPTED
          </div>
          <div style={{fontFamily:"var(--mono)",fontSize:11,color:"var(--t3)",marginBottom:20}}>
            BlackMatter Pro v4.2 · MFS-2026-BM-7741-ALPHA
          </div>
          <pre style={{fontFamily:"var(--mono)",fontSize:11,color:"rgba(255,71,87,.7)",textAlign:"left",
            background:"rgba(255,71,87,.04)",border:"1px solid rgba(255,71,87,.15)",borderRadius:6,
            padding:16,lineHeight:1.9,maxHeight:200,overflow:"auto",whiteSpace:"pre-wrap"}}>
            {RANSOM_NOTE}
          </pre>
        </div>
      </div>
    );
  }

  const clrMap = {cyan:"var(--cyan)",green:"var(--green)",yellow:"var(--amber)",red:"var(--red)"};
  return (
    <div className="ransom-terminal">
      <div style={{display:"flex",gap:8,marginBottom:16,paddingBottom:8,borderBottom:"1px solid var(--line)"}}>
        {["#ff4757","#ffb830","#00e676"].map(c=><div key={c} style={{width:11,height:11,borderRadius:"50%",background:c,opacity:.7}}/>)}
        <span style={{color:"var(--t4)",fontSize:12,marginLeft:4}}>Windows PowerShell</span>
        {enc > 0 && <span style={{marginLeft:"auto",color:"var(--red)",fontFamily:"var(--mono)",fontSize:11}}>
          ⚠ ENCRYPTING — {enc.toLocaleString()} / 84,721
        </span>}
      </div>
      <div style={{flex:1}}>
        {lines.map((l,i) => (
          <div key={i} className="cmd-line" style={{color:clrMap[l.c]||"#888",marginBottom:2,animationDelay:`${i*0.02}s`}}>{l.s}</div>
        ))}
        {enc > 1000 && (
          <div style={{marginTop:12}}>
            <div style={{color:"var(--red)",marginBottom:6,fontSize:11}}>ENCRYPTION PROGRESS: {Math.round(enc/84721*100)}%</div>
            <div className="prog-track" style={{width:"50%",height:5}}>
              <div className="prog-fill" style={{width:`${enc/84721*100}%`,background:"linear-gradient(90deg,var(--red),var(--amber))"}}/>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── SECURITY ALERTS ─────────────────────────────────────────────────────────
function AlertsPanel({ active, onClose }) {
  const [sel, setSel]  = useState(null);
  const [ack, setAck]  = useState(new Set());
  const visible = active ? ALERTS : [];

  if (!active) return null;
  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal-box" style={{maxWidth:900}}>
        <div className="modal-head">
          <span style={{fontSize:16}}>🛡</span>
          <span style={{fontFamily:"var(--display)",fontSize:14,fontWeight:700,flex:1}}>Security Alerts — Azure Sentinel</span>
          <span className="tag" style={{background:"rgba(255,71,87,.1)",color:"var(--red)",border:"1px solid rgba(255,71,87,.2)"}}>
            <span className="dot byte-dot" style={{background:"var(--red)"}} />{visible.filter(a=>!ack.has(a.id)).length} OPEN
          </span>
          <button className="btn btn-ghost" style={{marginLeft:12,padding:"4px 10px"}} onClick={onClose}>✕</button>
        </div>
        <div style={{display:"flex",height:460,overflow:"hidden"}}>
          {/* List */}
          <div style={{width:420,borderRight:"1px solid var(--line)",overflowY:"auto",flexShrink:0}}>
            {visible.map((a,i) => (
              <div key={a.id} className={`alert-row ${a.sev} ${sel?.id===a.id?"selected":""}`}
                style={{animationDelay:`${i*.06}s`}}
                onClick={() => setSel(a)}>
                <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:4}}>
                  <SevTag sev={a.sev} />
                  <span style={{fontFamily:"var(--mono)",fontSize:10,color:"var(--t4)"}}>{a.time} UTC</span>
                  {ack.has(a.id) && <span style={{marginLeft:"auto",fontSize:9,color:"var(--green)",fontFamily:"var(--mono)"}}>ACK</span>}
                </div>
                <div style={{fontSize:12,color:ack.has(a.id)?"var(--t3)":"var(--t1)",lineHeight:1.4}}>{a.title}</div>
                <div style={{fontSize:10,color:"var(--t4)",marginTop:3,fontFamily:"var(--mono)"}}>{a.host}</div>
              </div>
            ))}
          </div>
          {/* Detail */}
          <div style={{flex:1,padding:20,overflowY:"auto"}}>
            {sel ? <>
              <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:14,alignItems:"center"}}>
                <SevTag sev={sel.sev} />
                <span className="tag" style={{background:"var(--cyan-dim)",color:"var(--cyan)",border:"1px solid rgba(0,229,255,.2)"}}>{sel.mitre}</span>
              </div>
              <div style={{fontFamily:"var(--display)",fontSize:14,fontWeight:700,color:"var(--t1)",marginBottom:10,lineHeight:1.4}}>{sel.title}</div>
              <p style={{fontSize:12,color:"var(--t2)",lineHeight:1.75,marginBottom:16}}>{sel.detail}</p>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:16}}>
                {[["Alert ID",sel.id],["Host",sel.host],["Rule",sel.rule],["Time",sel.time+" UTC"]].map(([k,v])=>(
                  <div key={k} style={{background:"var(--s3)",borderRadius:6,padding:"10px 12px",border:"1px solid var(--line)"}}>
                    <div style={{fontSize:9,color:"var(--t4)",fontFamily:"var(--mono)",textTransform:"uppercase",letterSpacing:".08em",marginBottom:3}}>{k}</div>
                    <div style={{fontSize:12,color:"var(--t1)",fontFamily:"var(--mono)"}}>{v}</div>
                  </div>
                ))}
              </div>
              {!ack.has(sel.id) && (
                <button className="btn btn-primary" onClick={()=>setAck(p=>new Set([...p,sel.id]))}>
                  ✓ Acknowledge Alert
                </button>
              )}
            </> : (
              <div style={{height:"100%",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:8,color:"var(--t4)"}}>
                <span style={{fontSize:32}}>🔔</span>
                <span style={{fontSize:12}}>Select an alert</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── OUTLOOK ─────────────────────────────────────────────────────────────────
function OutlookPanel({ onClose, addScore }) {
  const [sel, setSel]    = useState(null);
  const [added, setAdded] = useState(false);

  const emails = [
    {id:1,from:"IT Security",   subject:"[CRITICAL] Ransomware on FILESVR-01 — immediate action",time:"02:20",sev:"critical",unread:true},
    {id:2,from:"meridian-suppliers.net",subject:"URGENT: Q4 Invoice #INV-2026-4891 — Payment Overdue",time:"Yesterday 09:44",sev:"phishing",unread:false},
    {id:3,from:"SIEM Auto-Alert",subject:"EDR: Invoice_Q4_2026.exe executed — WKSTN-SC-04",time:"02:11",sev:"high",unread:true},
    {id:4,from:"Compliance Team",subject:"GDPR breach notification — 72h deadline active",time:"02:25",sev:"high",unread:true},
  ];

  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal-box" style={{maxWidth:900}}>
        <div className="modal-head">
          <span style={{fontSize:16}}>📧</span>
          <span style={{fontFamily:"var(--display)",fontSize:14,fontWeight:700,flex:1}}>Outlook — sarah.chen@meridianfinancial.com</span>
          <button className="btn btn-ghost" style={{padding:"4px 10px"}} onClick={onClose}>✕</button>
        </div>
        <div style={{display:"flex",height:460,overflow:"hidden"}}>
          {/* Email list */}
          <div style={{width:320,borderRight:"1px solid var(--line)",overflowY:"auto",flexShrink:0}}>
            {emails.map(e => {
              const c = e.sev==="critical"?"var(--red)":e.sev==="phishing"?"var(--red)":e.sev==="high"?"var(--amber)":"var(--line)";
              return (
                <div key={e.id} onClick={()=>setSel(e)} style={{padding:"11px 14px",borderBottom:"1px solid var(--line)",cursor:"pointer",borderLeft:`2px solid ${sel?.id===e.id?c:"transparent"}`,background:sel?.id===e.id?"var(--s2)":"transparent"}}
                  onMouseEnter={ev=>{if(sel?.id!==e.id)ev.currentTarget.style.background="var(--s3)"}}
                  onMouseLeave={ev=>{if(sel?.id!==e.id)ev.currentTarget.style.background="transparent"}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                    <span style={{fontSize:12,fontWeight:e.unread?600:400,color:"var(--t1)",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:200}}>{e.from}</span>
                    <span style={{fontSize:10,color:"var(--t4)",flexShrink:0}}>{e.time}</span>
                  </div>
                  <div style={{fontSize:11,color:"var(--t2)",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{e.subject}</div>
                </div>
              );
            })}
          </div>
          {/* Email body */}
          <div style={{flex:1,padding:20,overflowY:"auto"}}>
            {sel?.id === 2 ? <>
              <div style={{background:"rgba(255,71,87,.07)",border:"1px solid rgba(255,71,87,.25)",borderRadius:7,padding:"10px 14px",marginBottom:14}}>
                <div style={{fontSize:12,fontWeight:600,color:"var(--red)",marginBottom:3}}>⚠ PHISHING EMAIL — DO NOT OPEN ATTACHMENT</div>
                <div style={{fontSize:11,color:"var(--t2)"}}>Automated analysis: malicious .exe attachment, unauthenticated sender, Tor origin IP</div>
              </div>
              <div style={{marginBottom:12,borderBottom:"1px solid var(--line)",paddingBottom:12}}>
                {[["From",PHISHING_EMAIL.from],["To",PHISHING_EMAIL.to],["Subject",PHISHING_EMAIL.subject],["Date",PHISHING_EMAIL.date]].map(([k,v])=>(
                  <div key={k} style={{display:"flex",gap:10,padding:"3px 0",fontSize:12}}>
                    <span style={{color:"var(--t4)",minWidth:60}}>{k}:</span>
                    <span style={{fontFamily:"var(--mono)",color:"var(--t1)"}}>{v}</span>
                  </div>
                ))}
                <div style={{display:"flex",gap:8,marginTop:8,flexWrap:"wrap"}}>
                  {["SPF","DKIM","DMARC"].map(k=>(
                    <span key={k} className="tag" style={{background:"rgba(255,71,87,.1)",color:"var(--red)",border:"1px solid rgba(255,71,87,.25)"}}>{k}: FAIL</span>
                  ))}
                  <span className="tag" style={{background:"rgba(255,71,87,.1)",color:"var(--red)",border:"1px solid rgba(255,71,87,.25)"}}>Origin: {PHISHING_EMAIL.originIp}</span>
                  <span className="tag" style={{background:"rgba(255,71,87,.1)",color:"var(--red)",border:"1px solid rgba(255,71,87,.25)"}}>Spam: {PHISHING_EMAIL.spamScore}</span>
                </div>
              </div>
              <pre style={{fontSize:12,color:"var(--t2)",lineHeight:1.8,whiteSpace:"pre-wrap",fontFamily:"var(--ui)",marginBottom:14,background:"var(--s2)",padding:14,borderRadius:6,border:"1px solid var(--line)"}}>{PHISHING_EMAIL.body}</pre>
              <div style={{marginBottom:14}}>
                <div style={{fontSize:11,fontWeight:600,color:"var(--t3)",marginBottom:8,fontFamily:"var(--mono)",textTransform:"uppercase",letterSpacing:".08em"}}>Phishing Indicators</div>
                {PHISHING_EMAIL.indicators.map((ind,i)=>(
                  <div key={i} style={{display:"flex",gap:8,padding:"6px 0",borderBottom:"1px solid var(--line)",alignItems:"flex-start"}}>
                    <SevTag sev={ind.sev} />
                    <span style={{fontSize:11,color:"var(--t2)",lineHeight:1.5}}>{ind.text}</span>
                  </div>
                ))}
              </div>
              <button className="btn btn-primary" onClick={()=>{setAdded(true);addScore(15);}}>
                {added ? "✓ Added to DFIR Case" : "Add to DFIR Case (+15 pts)"}
              </button>
            </> : sel ? (
              <div>
                <div style={{fontFamily:"var(--display)",fontSize:15,fontWeight:700,color:"var(--t1)",marginBottom:12}}>{sel.subject}</div>
                <p style={{fontSize:12,color:"var(--t2)",lineHeight:1.75}}>
                  {sel.id===1 ? "CRITICAL SECURITY INCIDENT: Ransomware (BlackMatter Pro v4.2) confirmed on FILESVR-01. 84,721 files encrypted. Immediate containment required. Open DFIR platform and begin IR procedures." :
                   sel.id===3 ? "EDR Alert: Invoice_Q4_2026.exe executed by sarah.chen on WKSTN-SC-04 at 02:11:03 UTC. Process spawned vssadmin.exe and created persistence. Quarantine recommended immediately." :
                   "GDPR Article 33 requires notification to the supervisory authority (ICO) within 72 hours of becoming aware of a personal data breach. The breach occurred at 02:11 UTC — deadline is 02:11 UTC on 17 November 2026. File executive report immediately."}
                </p>
              </div>
            ) : (
              <div style={{height:"100%",display:"flex",alignItems:"center",justifyContent:"center",color:"var(--t4)"}}>Select an email</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── VIRUSTOTAL ───────────────────────────────────────────────────────────────
function VTPanel({ onClose, addScore }) {
  const [q, setQ]         = useState("");
  const [res, setRes]     = useState(null);
  const [loading, setLd]  = useState(false);
  const [scored, setScrd] = useState(false);

  function analyse() {
    if (!q.trim()) return;
    setLd(true); setRes(null);
    setTimeout(() => {
      const key = Object.keys(VT_DATA).find(k => q.toLowerCase().includes(k.toLowerCase()));
      setRes(key ? {...VT_DATA[key],query:key} : {detect:0,total:94,family:"Unknown",type:"Not found",tags:[],query:q});
      setLd(false);
      if (!scored) { addScore(20); setScrd(true); }
    }, 1600);
  }

  const detColor = res ? (res.detect>50?"var(--red)":res.detect>10?"var(--amber)":"var(--green)") : "var(--t3)";

  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal-box" style={{maxWidth:720}}>
        <div className="modal-head">
          <span style={{fontSize:16}}>🦠</span>
          <span style={{fontFamily:"var(--display)",fontSize:14,fontWeight:700,flex:1}}>VirusTotal — Threat Intelligence</span>
          <button className="btn btn-ghost" style={{padding:"4px 10px"}} onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <div style={{display:"flex",gap:8,marginBottom:14}}>
            <input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&analyse()} placeholder="File hash, IP address, domain, or URL..." />
            <button className="btn btn-primary" style={{flexShrink:0}} onClick={analyse}>Analyse</button>
          </div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:18}}>
            {Object.keys(VT_DATA).map(k => (
              <button key={k} onClick={()=>setQ(k)} style={{padding:"4px 10px",background:"var(--s3)",border:"1px solid var(--line2)",borderRadius:4,color:"var(--t2)",cursor:"pointer",fontSize:11,fontFamily:"var(--mono)"}}>
                {k.length > 24 ? k.slice(0,24)+"…" : k}
              </button>
            ))}
          </div>
          {loading && (
            <div style={{textAlign:"center",padding:40,color:"var(--t4)"}}>
              <div style={{width:28,height:28,border:"2px solid var(--cyan)",borderTopColor:"transparent",borderRadius:"50%",animation:"spin .8s linear infinite",margin:"0 auto 12px"}} />
              <div style={{fontSize:12,fontFamily:"var(--mono)"}}>Querying 94 security vendors...</div>
            </div>
          )}
          {res && !loading && (
            <div style={{animation:"fadeUp .2s ease-out"}}>
              <div style={{display:"flex",gap:20,alignItems:"flex-start",marginBottom:20}}>
                <div className="vt-ring" style={{background:`${detColor}12`,border:`2px solid ${detColor}40`}}>
                  <div style={{fontSize:28,fontWeight:800,color:detColor,lineHeight:1,fontFamily:"var(--display)"}}>{res.detect}</div>
                  <div style={{fontSize:10,color:"var(--t4)"}}>/ {res.total}</div>
                </div>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"var(--display)",fontSize:16,fontWeight:700,color:"var(--t1)",marginBottom:4}}>{res.family}</div>
                  <div style={{fontSize:12,color:"var(--t2)",marginBottom:10}}>{res.type}</div>
                  <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                    {res.tags?.map(t=>(
                      <span key={t} className="tag" style={{background:"rgba(255,71,87,.08)",color:"#ff8888",border:"1px solid rgba(255,71,87,.2)"}}>{t}</span>
                    ))}
                  </div>
                </div>
              </div>
              {res.detect > 0 && (
                <div style={{background:"var(--red-dim)",border:"1px solid rgba(255,71,87,.2)",borderRadius:7,padding:"12px 16px"}}>
                  <div style={{fontSize:12,fontWeight:600,color:"var(--red)",marginBottom:4}}>⚠ MALICIOUS — {res.detect}/{res.total} vendors</div>
                  <div style={{fontSize:11,color:"var(--t2)",lineHeight:1.7}}>Confirmed as part of the BlackMatter Pro v4.2 ransomware campaign. Recommend blocking all associated IOCs and sharing with FS-ISAC under TLP:AMBER.</div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── BACKUP MANAGER ───────────────────────────────────────────────────────────
function BackupPanel({ onClose, addScore }) {
  const [restored,  setRestored]  = useState(new Set());
  const [restoring, setRestoring] = useState(null);
  const [prog, setProg]           = useState({});

  function restore(i) {
    if (restored.has(i) || restoring !== null) return;
    setRestoring(i);
    let p = 0;
    const iv = setInterval(() => {
      p += Math.random() * 8 + 3;
      setProg(prev => ({...prev,[i]:Math.min(100,p)}));
      if (p >= 100) {
        clearInterval(iv);
        setRestoring(null);
        setRestored(prev => { const n=new Set([...prev,i]); if(n.size>=2) labAction("backup-restored"); return n; });
        addScore(BACKUPS[i].status==="good" ? 25 : 10);
      }
    }, 200);
  }

  const stClr = {good:"var(--green)",warning:"var(--amber)",critical:"var(--red)"};
  const ready = BACKUPS.filter((_,i)=>restored.has(i)).length;

  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal-box" style={{maxWidth:820}}>
        <div className="modal-head">
          <span style={{fontSize:16}}>💾</span>
          <span style={{fontFamily:"var(--display)",fontSize:14,fontWeight:700,flex:1}}>Azure Backup — Recovery Console</span>
          <button className="btn btn-ghost" style={{padding:"4px 10px"}} onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginBottom:20}}>
            <div className="metric"><div className="metric-label">Recovery Readiness</div><div className="metric-val" style={{color:ready>3?"var(--green)":"var(--amber)"}}>{Math.round(ready/6*100)}%</div></div>
            <div className="metric"><div className="metric-label">Clean Backups</div><div className="metric-val" style={{color:"var(--green)"}}>{BACKUPS.filter(b=>b.status==="good").length}/6</div></div>
            <div className="metric"><div className="metric-label">Shares Restored</div><div className="metric-val" style={{color:"var(--cyan)"}}>{ready}/6</div></div>
          </div>
          {BACKUPS.map((b,i) => (
            <div key={i} className="bk-row" style={{borderLeftColor:stClr[b.status]}}>
              <div style={{display:"flex",alignItems:"center",gap:12,flexWrap:"wrap"}}>
                <div style={{flex:1,minWidth:200}}>
                  <div style={{fontSize:13,fontWeight:600,color:"var(--t1)",marginBottom:2,fontFamily:"var(--mono)"}}>{b.share}</div>
                  <div style={{fontSize:10,color:"var(--t4)"}}>
                    {b.size} · RPO: <span style={{color:stClr[b.status]}}>{b.rpo}</span> · {b.loc} · {b.last}
                  </div>
                </div>
                <SevTag sev={b.status==="good"?"low":b.status} />
                {restored.has(i)
                  ? <span style={{fontSize:12,color:"var(--green)",fontWeight:600,fontFamily:"var(--mono)"}}>✓ Restored</span>
                  : restoring===i
                  ? <div style={{textAlign:"right",minWidth:140}}>
                      <div style={{fontSize:10,color:"var(--cyan)",marginBottom:4,fontFamily:"var(--mono)"}}>{Math.round(prog[i]||0)}%</div>
                      <div className="prog-track" style={{width:140}}>
                        <div className="prog-fill" style={{width:`${prog[i]||0}%`,background:"var(--cyan)"}}/>
                      </div>
                    </div>
                  : <button className={`btn ${b.status==="good"?"btn-success":"btn-ghost"}`} style={{fontSize:11,padding:"5px 14px"}} onClick={()=>restore(i)} disabled={restoring!==null}>
                      {b.status==="critical" ? "⚠ Attempt Restore" : "Restore (+25)"}
                    </button>
                }
              </div>
              {b.status !== "good" && (
                <div style={{marginTop:8,fontSize:11,color:stClr[b.status]}}>⚠ {b.note}</div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── DFIR PLATFORM ────────────────────────────────────────────────────────────
function DFIRPlatform({ onClose, score, addScore }) {
  const [tab,    setTab]    = useState("overview");
  const [notes,  setNotes]  = useState("");
  const [noteSaved, setNoteSaved] = useState(false);
  const [iocSt,  setIocSt]  = useState({});
  const [report, setReport] = useState({root:"",contain:"",recover:"",regulatory:""});
  const [submitted, setSubmitted] = useState(false);
  const [repScored, setRepScored] = useState(false);

  const TABS = ["overview","timeline","iocs","logs","mitre","evidence","notes","report"];
  const TAB_LABELS = {overview:"Overview",timeline:"Timeline",iocs:"IOCs",logs:"Log Corr.",mitre:"ATT&CK",evidence:"Evidence",notes:"Notes",report:"Exec Report"};

  function blockIOC(id) { setIocSt(p=>{const n={...p,[id]:"blocked"}; const blocked=Object.values(n).filter(v=>v==="blocked").length; if(blocked>=3) labAction("iocs-blocked"); return n;}); addScore(15); }
  function saveNote() { if (notes.length > 30 && !noteSaved) { setNoteSaved(true); addScore(20); labAction("notes-saved"); } }
  function submitReport() {
    const filled = Object.values(report).filter(v=>v.trim().length>20).length;
    if (filled < 2) return;
    setSubmitted(true);
    if (!repScored) { addScore(filled*15); setRepScored(true); }
    labAction("report-filed");
  }

  return (
    <div style={{position:"fixed",inset:0,background:"var(--bg)",zIndex:700,display:"flex",flexDirection:"column",animation:"fadeIn .15s ease-out"}}>
      {/* Top bar */}
      <div className="topbar">
        <div style={{display:"flex",alignItems:"center",gap:10,marginRight:20}}>
          <div style={{width:28,height:28,borderRadius:6,background:"var(--cyan-dim)",border:"1px solid rgba(0,229,255,.25)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14}}>⚔</div>
          <div>
            <div style={{fontFamily:"var(--display)",fontSize:12,fontWeight:700,color:"var(--t1)"}}>CipherOps DFIR</div>
            <div style={{fontSize:9,fontFamily:"var(--mono)",color:"var(--t4)",letterSpacing:".08em"}}>Meridian IR · v2.0</div>
          </div>
        </div>
        <span style={{fontFamily:"var(--mono)",fontSize:10,background:"rgba(255,71,87,.1)",color:"var(--red)",border:"1px solid rgba(255,71,87,.25)",padding:"3px 12px",borderRadius:20}}>INC-2026-BM-001</span>
        <span style={{fontFamily:"var(--mono)",fontSize:10,color:"var(--t4)",marginLeft:8}}>BlackMatter Pro v4.2 · P1 Critical</span>
        <div style={{marginLeft:"auto",display:"flex",gap:8,alignItems:"center"}}>
          <span style={{fontFamily:"var(--mono)",fontSize:12,color:"var(--cyan)",fontWeight:700}}>{score} pts</span>
          <button className="btn btn-ghost" style={{padding:"5px 12px",fontSize:11}} onClick={onClose}>← Back to Desktop</button>
        </div>
      </div>
      {/* Tab bar */}
      <div style={{display:"flex",borderBottom:"1px solid var(--line)",background:"var(--s1)",overflowX:"auto",flexShrink:0,padding:"0 20px"}}>
        {TABS.map(t=>(
          <button key={t} className={`dfir-tab ${tab===t?"active":""}`} onClick={()=>setTab(t)}>
            {TAB_LABELS[t]}
          </button>
        ))}
      </div>
      {/* Content */}
      <div style={{flex:1,overflowY:"auto",padding:24,background:"var(--bg)"}}>

        {/* ── OVERVIEW ── */}
        {tab==="overview" && (
          <div style={{animation:"fadeUp .2s ease-out",maxWidth:1100}}>
            <div style={{fontFamily:"var(--display)",fontSize:20,fontWeight:800,color:"var(--t1)",marginBottom:4}}>Case Overview</div>
            <p style={{color:"var(--t3)",fontSize:12,fontFamily:"var(--mono)",marginBottom:20}}>INC-2026-BM-001 · BlackMatter Pro v4.2 · Meridian Financial Services · 14 Nov 2026</p>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))",gap:10,marginBottom:24}}>
              {[["Files Encrypted","84,721","var(--red)"],["Shares Locked","14/14","var(--red)"],["Ransom Demand","$94,500","var(--amber)"],["Attack Duration","7m 38s","var(--amber)"],["VSS Deleted","12","var(--red)"],["Backup RPO","73% ok","var(--green)"]].map(([l,v,c])=>(
                <div key={l} className="metric"><div className="metric-label">{l}</div><div className="metric-val" style={{color:c}}>{v}</div></div>
              ))}
            </div>
            <div className="panel" style={{marginBottom:16}}>
              <div className="panel-head">
                <span style={{fontSize:12,fontWeight:600,color:"var(--t2)"}}>Kill Chain</span>
              </div>
              <KillChain active={true} />
            </div>
            <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:16}}>
              <div className="panel">
                <div className="panel-head"><span style={{fontSize:12,fontWeight:600,color:"var(--t2)"}}>Incident Summary</span></div>
                <div className="panel-body">
                  <p style={{fontSize:13,color:"var(--t2)",lineHeight:1.85}}>At <b style={{color:"var(--amber)"}}>02:11:03 UTC on 14 November 2026</b>, user <b style={{color:"var(--t1)"}}>sarah.chen</b> executed phishing attachment <b style={{color:"var(--red)"}}>Invoice_Q4_2026.exe</b> on WKSTN-SC-04. BlackMatter Pro v4.2 deleted 12 VSS shadow copies, established a C2 channel to <b style={{color:"var(--red)"}}>94.102.49.193</b>, and encrypted <b style={{color:"var(--red)"}}>84,721 files across 14 SMB shares</b> in under 5 minutes. Ransom: <b style={{color:"var(--red)"}}>2.4 BTC ($94,500)</b>.</p>
                </div>
              </div>
              <div className="panel">
                <div className="panel-head"><span style={{fontSize:12,fontWeight:600,color:"var(--t2)"}}>Action Tracker</span></div>
                <div style={{padding:"8px 14px"}}>
                  {[{done:true,a:"Alert acknowledged",t:"02:19"},{done:true,a:"C2 IP blocked",t:"02:22"},{done:true,a:"WKSTN-SC-04 isolated",t:"02:23"},{done:true,a:"Malware quarantined",t:"02:21"},{done:false,a:"Backup restore",t:"—"},{done:false,a:"Password reset",t:"—"},{done:false,a:"Regulatory notification",t:"—"}].map((item,i)=>(
                    <div key={i} style={{display:"flex",gap:9,padding:"7px 0",borderBottom:"1px solid var(--line)",alignItems:"center"}}>
                      <span style={{color:item.done?"var(--green)":"var(--amber)",fontSize:13}}>{item.done?"✓":"○"}</span>
                      <span style={{fontSize:11,color:item.done?"var(--t3)":"var(--t1)",flex:1}}>{item.a}</span>
                      <span style={{fontSize:10,color:"var(--t4)",fontFamily:"var(--mono)"}}>{item.t}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── TIMELINE ── */}
        {tab==="timeline" && (
          <div style={{animation:"fadeUp .2s ease-out",maxWidth:800}}>
            <div style={{fontFamily:"var(--display)",fontSize:20,fontWeight:800,color:"var(--t1)",marginBottom:4}}>Incident Timeline</div>
            <p style={{color:"var(--t3)",fontSize:12,fontFamily:"var(--mono)",marginBottom:20}}>{TIMELINE.length} events · Chronological kill-chain</p>
            <div style={{position:"relative",paddingLeft:8}}>
              <div style={{position:"absolute",left:19,top:0,bottom:0,width:1,background:"var(--line)"}} />
              {TIMELINE.map((ev,i)=>(
                <div key={i} className="tl-item" style={{animationDelay:`${i*.05}s`}}>
                  <div className="tl-line">
                    <div className="tl-dot" style={{background:PHASE_CLR[ev.phase]||"var(--t4)"}} />
                    {i < TIMELINE.length-1 && <div className="tl-connector" />}
                  </div>
                  <div className="tl-card" style={{borderLeftColor:PHASE_CLR[ev.phase]||"var(--t4)"}}>
                    <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:5,flexWrap:"wrap"}}>
                      <span style={{fontFamily:"var(--mono)",fontSize:10,color:"var(--t4)"}}>{ev.time} UTC</span>
                      <span className="tag" style={{background:`${PHASE_CLR[ev.phase]||"#888"}18`,color:PHASE_CLR[ev.phase]||"#888",border:"none",fontSize:8}}>{ev.phase}</span>
                      <span style={{fontSize:10,color:"var(--t4)",fontStyle:"italic"}}>{ev.actor}</span>
                    </div>
                    <div style={{fontSize:12,color:"var(--t1)",lineHeight:1.5}}>{ev.evt}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── IOCs ── */}
        {tab==="iocs" && (
          <div style={{animation:"fadeUp .2s ease-out",maxWidth:1000}}>
            <div style={{fontFamily:"var(--display)",fontSize:20,fontWeight:800,color:"var(--t1)",marginBottom:4}}>Indicators of Compromise</div>
            <p style={{color:"var(--t3)",fontSize:12,fontFamily:"var(--mono)",marginBottom:20}}>{IOCS.length} IOCs · {IOCS.filter(i=>(iocSt[i.id]||i.status)==="blocked").length} blocked · Block active IOCs to earn +15 pts each</p>
            <div className="panel">
              {IOCS.map((ioc,i)=>{
                const st = iocSt[ioc.id]||ioc.status;
                const tlpC = ioc.tlp==="RED"?"#ff4757":ioc.tlp==="AMBER"?"#ffb830":"#8bacc8";
                return (
                  <div key={ioc.id} className="ioc-row" style={{animationDelay:`${i*.04}s`}}>
                    <div style={{minWidth:80,fontFamily:"var(--mono)",fontSize:10,color:"var(--cyan)"}}>{ioc.id}</div>
                    <span className="tag" style={{background:"var(--cyan-dim)",color:"var(--cyan)",border:"1px solid rgba(0,229,255,.2)",flexShrink:0}}>{ioc.type}</span>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontFamily:"var(--mono)",fontSize:11,color:"var(--t1)",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",marginBottom:2}}>{ioc.value}</div>
                      <div style={{fontSize:11,color:"var(--t3)"}}>{ioc.desc}</div>
                    </div>
                    <TlpTag tlp={ioc.tlp} />
                    <span className="tag" style={{background:st==="blocked"?"rgba(0,230,118,.1)":st==="active"?"rgba(255,71,87,.1)":"rgba(255,255,255,.05)",color:st==="blocked"?"var(--green)":st==="active"?"var(--red)":"var(--t3)",border:"none",flexShrink:0}}>{st}</span>
                    <div style={{flexShrink:0,minWidth:100}}>
                      {st==="active"
                        ? <button className="btn btn-danger" style={{fontSize:10,padding:"4px 12px"}} onClick={()=>blockIOC(ioc.id)}>Block (+15)</button>
                        : st==="blocked" ? <span style={{fontSize:11,color:"var(--green)",fontFamily:"var(--mono)"}}>✓ Blocked</span>
                        : <span style={{fontSize:11,color:"var(--t4)"}}>Remediated</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── LOG CORRELATION ── */}
        {tab==="logs" && (
          <div style={{animation:"fadeUp .2s ease-out",maxWidth:1100}}>
            <div style={{fontFamily:"var(--display)",fontSize:20,fontWeight:800,color:"var(--t1)",marginBottom:4}}>Log Correlation</div>
            <p style={{color:"var(--t3)",fontSize:12,fontFamily:"var(--mono)",marginBottom:20}}>Correlated EDR, FIM, and authentication events</p>
            <div className="panel" style={{marginBottom:16}}>
              <div className="panel-head"><span style={{fontSize:12,fontWeight:600,color:"var(--t2)"}}>Authentication &amp; EDR Events</span></div>
              <div style={{overflowX:"auto"}}>
                <table>
                  <thead><tr>{["Time","User","Host","Event","Source IP","Result","Risk"].map(h=><th key={h}>{h}</th>)}</tr></thead>
                  <tbody>
                    {[
                      {t:"02:11:03",u:"sarah.chen",h:"WKSTN-SC-04",e:"Invoice_Q4_2026.exe executed",ip:"10.2.1.44",r:"ALLOWED",risk:"critical"},
                      {t:"02:11:06",u:"SYSTEM",h:"WKSTN-SC-04",e:"C2 beacon — 94.102.49.193:443",ip:"94.102.49.193",r:"ALLOWED",risk:"critical"},
                      {t:"02:11:09",u:"SYSTEM",h:"WKSTN-SC-04",e:"vssadmin delete shadows /all",ip:"10.2.1.44",r:"SUCCESS",risk:"critical"},
                      {t:"02:11:12",u:"SYSTEM",h:"WKSTN-SC-04",e:"svchost.exe drop + registry key",ip:"10.2.1.44",r:"SUCCESS",risk:"high"},
                      {t:"02:14:19",u:"sarah.chen",h:"FILESVR-01",e:"SMB mass write 247 files/sec",ip:"10.2.1.44",r:"IN PROG",risk:"critical"},
                      {t:"02:18:41",u:"sarah.chen",h:"FILESVR-01",e:"Encryption complete 84,721 files",ip:"10.2.1.44",r:"DONE",risk:"critical"},
                    ].map((row,i)=>{
                      const riskC = row.risk==="critical"?"var(--red)":row.risk==="high"?"var(--amber)":"var(--t3)";
                      return <tr key={i} style={{background:row.risk==="critical"?"rgba(255,71,87,.03)":"transparent"}}>
                        <td style={{fontFamily:"var(--mono)",color:"var(--t4)"}}>{row.t}</td>
                        <td style={{fontFamily:"var(--mono)",color:"var(--t1)"}}>{row.u}</td>
                        <td style={{color:"var(--t2)"}}>{row.h}</td>
                        <td style={{color:row.risk==="critical"?"#ff8888":"var(--t1)"}}>{row.e}</td>
                        <td style={{fontFamily:"var(--mono)",color:row.ip.startsWith("94")?"var(--red)":"var(--t2)"}}>{row.ip}</td>
                        <td><span className="tag" style={{background:`${riskC}15`,color:riskC,border:"none",fontSize:9}}>{row.r}</span></td>
                        <td><SevTag sev={row.risk} /></td>
                      </tr>;
                    })}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="panel">
              <div className="panel-head"><span style={{fontSize:12,fontWeight:600,color:"var(--t2)"}}>FIM — File Integrity Events (sample)</span></div>
              <div style={{background:"#050810",padding:16,fontFamily:"var(--mono)",fontSize:11,lineHeight:1.8,maxHeight:180,overflowY:"auto"}}>
                {[
                  {c:"#ff6666",s:'{"time":"02:14:22","host":"FILESVR-01","event":"FILE_MODIFIED","path":"\\\\Finance\\Q4_Reports\\earnings_2026.xlsx","new_ext":".locked","pid":4821}'},
                  {c:"#ff6666",s:'{"time":"02:14:23","host":"FILESVR-01","event":"FILE_MODIFIED","path":"\\\\Finance\\Clients\\HSBC_contract.docx","new_ext":".locked","pid":4821}'},
                  {c:"#ffcc44",s:'{"time":"02:14:24","host":"FILESVR-01","event":"FILE_CREATED","path":"\\\\Finance\\README_DECRYPT.txt","pid":4821}'},
                  {c:"#ff6666",s:'{"time":"02:14:25","host":"FILESVR-01","event":"FILE_MODIFIED","path":"\\\\HR\\payroll_nov_2026.xlsx","new_ext":".locked","pid":4821}'},
                  {c:"#666",   s:'... [84,717 additional events truncated] ...'},
                  {c:"#88ff88",s:'{"time":"02:18:41","host":"FILESVR-01","event":"PROCESS_TERM","note":"Encryption cycle complete — 84,721 files"}'},
                ].map((l,i)=><div key={i} style={{color:l.c}}>{l.s}</div>)}
              </div>
            </div>
          </div>
        )}

        {/* ── MITRE ── */}
        {tab==="mitre" && (
          <div style={{animation:"fadeUp .2s ease-out",maxWidth:900}}>
            <div style={{fontFamily:"var(--display)",fontSize:20,fontWeight:800,color:"var(--t1)",marginBottom:4}}>MITRE ATT&amp;CK Mapping</div>
            <p style={{color:"var(--t3)",fontSize:12,fontFamily:"var(--mono)",marginBottom:16}}>{MITRE_MAP.length} techniques confirmed — BlackMatter Pro v4.2 campaign</p>
            <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:20}}>
              {["Initial Access","Execution","Persistence","Defense Evasion","Lateral Mvmt","Impact","C&C"].map(t=>{
                const a = MITRE_MAP.some(m=>m.phase===t);
                return <span key={t} style={{fontSize:10,padding:"3px 12px",borderRadius:20,background:a?"rgba(255,71,87,.1)":"var(--s2)",border:`1px solid ${a?"rgba(255,71,87,.3)":"var(--line)"}`,color:a?"var(--red)":"var(--t4)"}}>{t}</span>;
              })}
            </div>
            {MITRE_MAP.map((t,i)=>(
              <div key={t.id} style={{background:"var(--s2)",border:"1px solid var(--line)",borderLeft:`3px solid ${t.clr}`,borderRadius:"0 6px 6px 0",padding:"12px 16px",marginBottom:8,animation:`fadeUp .2s ${i*.04}s both`}}>
                <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:6,flexWrap:"wrap"}}>
                  <span style={{fontFamily:"var(--mono)",fontSize:11,fontWeight:700,color:t.clr,background:`${t.clr}12`,padding:"2px 8px",borderRadius:4}}>{t.id}</span>
                  <span style={{fontSize:13,fontWeight:600,color:"var(--t1)"}}>{t.name}</span>
                  <span style={{marginLeft:"auto",fontSize:9,padding:"2px 8px",borderRadius:10,background:"rgba(255,71,87,.1)",color:"var(--red)",fontFamily:"var(--mono)",textTransform:"uppercase"}}>{t.status}</span>
                </div>
                <div style={{fontSize:12,color:"var(--t2)",lineHeight:1.6}}>{t.desc}</div>
              </div>
            ))}
          </div>
        )}

        {/* ── EVIDENCE ── */}
        {tab==="evidence" && (
          <div style={{animation:"fadeUp .2s ease-out",maxWidth:900}}>
            <div style={{fontFamily:"var(--display)",fontSize:20,fontWeight:800,color:"var(--t1)",marginBottom:4}}>Evidence Vault</div>
            <p style={{color:"var(--t3)",fontSize:12,fontFamily:"var(--mono)",marginBottom:20}}>Chain of custody maintained — all items SHA-256 verified at collection</p>
            <div className="panel">
              {EVIDENCE.map((ev,i)=>(
                <div key={ev.id} className="ev-item" style={{animationDelay:`${i*.05}s`}}>
                  <div className="ev-icon" style={{background:`${ev.clr}12`,border:`1px solid ${ev.clr}25`}}><span>{ev.icon}</span></div>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:12,fontWeight:600,color:"var(--t1)",marginBottom:3}}>{ev.name}</div>
                    <div style={{fontSize:10,color:"var(--t4)",fontFamily:"var(--mono)"}}>{ev.hash} · {ev.size} · Added {ev.added} UTC</div>
                  </div>
                  <span className="tag" style={{background:`${ev.clr}12`,color:ev.clr,border:`1px solid ${ev.clr}25`,flexShrink:0}}>{ev.type}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── NOTES ── */}
        {tab==="notes" && (
          <div style={{animation:"fadeUp .2s ease-out",maxWidth:800}}>
            <div style={{fontFamily:"var(--display)",fontSize:20,fontWeight:800,color:"var(--t1)",marginBottom:4}}>Analyst Notes</div>
            <p style={{color:"var(--t3)",fontSize:12,fontFamily:"var(--mono)",marginBottom:20}}>Document investigation findings, containment actions, and recommendations</p>
            <textarea value={notes} onChange={e=>setNotes(e.target.value)} rows={14}
              placeholder={`## Investigation Notes — INC-2026-BM-001\n## Analyst: Alex Rivera | Date: 2026-11-14\n\n### Initial Triage\n- Acknowledged CRITICAL FIM alert on FILESVR-01\n- Identified README_DECRYPT.txt across all 14 shares\n- Confirmed BlackMatter Pro v4.2 via EDR signature\n\n### Email Analysis\n- Invoice_Q4_2026.exe executed by sarah.chen at 02:11:03\n- SPF/DKIM/DMARC all FAIL — sender unauthenticated\n- Origin IP 185.220.101.47 confirmed Tor exit node\n\n### Containment Actions\n- [x] WKSTN-SC-04 isolated from domain\n- [x] C2 IP 94.102.49.193 blocked at perimeter\n- [x] IOCs shared to FS-ISAC TLP:AMBER\n\n### Recovery Priority\n1. Finance share — 3h RPO, clean backup, restore first\n2. HR share — 3h RPO, clean backup\n3. Legal — 27h RPO, some data loss expected\n...\n`}
              style={{marginBottom:12}}
            />
            <div style={{display:"flex",gap:10,alignItems:"center"}}>
              <button className={`btn ${noteSaved?"btn-success":"btn-primary"}`} onClick={saveNote}>
                {noteSaved ? "✓ Saved (+20 pts)" : "Save Notes (+20 pts)"}
              </button>
              <span style={{fontSize:11,color:"var(--t4)",fontFamily:"var(--mono)"}}>{notes.length} chars</span>
            </div>
          </div>
        )}

        {/* ── EXEC REPORT ── */}
        {tab==="report" && (
          <div style={{animation:"fadeUp .2s ease-out",maxWidth:900}}>
            <div style={{fontFamily:"var(--display)",fontSize:20,fontWeight:800,color:"var(--t1)",marginBottom:4}}>Executive Incident Report</div>
            {submitted ? (
              <div style={{background:"rgba(0,230,118,.06)",border:"1px solid rgba(0,230,118,.2)",borderRadius:10,padding:32,textAlign:"center",marginTop:20}}>
                <div style={{fontSize:40,marginBottom:12}}>✅</div>
                <div style={{fontFamily:"var(--display)",fontSize:18,fontWeight:700,color:"var(--green)",marginBottom:8}}>Report Submitted</div>
                <div style={{fontSize:13,color:"var(--t2)",lineHeight:1.7}}>Delivered to CISO, CEO and General Counsel.<br/>ICO (UK) and FSCA (SA) regulatory notifications initiated.</div>
              </div>
            ) : (
              <>
                <div style={{background:"var(--amber-dim)",border:"1px solid rgba(255,184,48,.2)",borderRadius:7,padding:"10px 16px",marginBottom:20,fontSize:12,color:"var(--amber)"}}>
                  ⏱ <b>72-Hour Deadline Active</b> — Incident at 02:11 UTC. Notify ICO and FSCA by 02:11 UTC, 17 November 2026.
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
                  {[
                    {k:"root",label:"Root Cause Analysis",ph:"How the attack began — phishing email, user execution, authentication gaps..."},
                    {k:"contain",label:"Containment Actions Taken",ph:"Isolation, firewall blocks, IOC blocking, credential resets..."},
                    {k:"recover",label:"Recovery Plan & Timeline",ph:"Backup restore priority, estimated RTO, data loss assessment..."},
                    {k:"regulatory",label:"Regulatory Obligations",ph:"GDPR Article 33, FSCA requirements, data subjects affected, notification timeline..."},
                  ].map(f=>(
                    <div key={f.k}>
                      <label style={{display:"block",fontSize:11,color:"var(--t2)",fontWeight:600,marginBottom:6}}>{f.label}</label>
                      <textarea value={report[f.k]} onChange={e=>setReport(p=>({...p,[f.k]:e.target.value}))} rows={5} placeholder={f.ph} />
                    </div>
                  ))}
                </div>
                <div style={{display:"flex",gap:10,marginTop:16,alignItems:"center"}}>
                  <button className="btn btn-primary" onClick={submitReport}>
                    Submit Report (+{Object.values(report).filter(v=>v.trim().length>20).length*15} pts)
                  </button>
                  <span style={{fontSize:11,color:"var(--t4)",fontFamily:"var(--mono)"}}>{Object.values(report).filter(v=>v.trim().length>20).length}/4 fields</span>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── TERMINAL ─────────────────────────────────────────────────────────────────
function TerminalPanel({ onClose, addScore }) {
  const [lines, setLines]   = useState(["Microsoft Windows [Version 11.0.26100.2894]","","C:\\Users\\SOCAnalyst>"]);
  const [input, setInput]   = useState("");
  const [scored, setScored] = useState(new Set());
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({behavior:"smooth"}); }, [lines]);

  function exec(cmd) {
    const c = cmd.trim().toLowerCase();
    const push = (...ls) => setLines(p=>[...p,`C:\\Users\\SOCAnalyst> ${cmd}`,...ls,"","C:\\Users\\SOCAnalyst>"]);
    if (!c) { setLines(p=>[...p,"C:\\Users\\SOCAnalyst>"]); setInput(""); return; }

    if (c.includes("netsh") && c.includes("block")) {
      push("[+] Firewall rule added: BLOCK outbound to 94.102.49.193","Rule applied to all profiles.");
      if (!scored.has("fw")) { addScore(20); setScored(p=>new Set([...p,"fw"])); }
    } else if (c.includes("isolate") || (c.includes("netsh") && c.includes("wkstn"))) {
      push("[+] WKSTN-SC-04 isolated from domain network","Network adapter disabled. Host unreachable from LAN.");
      if (!scored.has("iso")) { addScore(25); setScored(p=>new Set([...p,"iso"])); }
    } else if (c.includes("reg delete")) {
      push("[+] Registry key deleted: HKLM\\...\\Run\\SvcHostSvc","Persistence removed.");
      if (!scored.has("reg")) { addScore(15); setScored(p=>new Set([...p,"reg"])); }
    } else if (c.includes("taskkill")) {
      push("[+] Process svchost.exe (PID 4821) terminated.");
    } else if (c==="help") {
      push("Available commands:","  netsh advfirewall firewall add rule name=BLOCK_C2 dir=out action=block remoteip=94.102.49.193","  isolate WKSTN-SC-04","  reg delete HKLM\\...\\Run\\SvcHostSvc","  taskkill /f /pid 4821","  ipconfig | whoami | hostname");
    } else if (c==="whoami") { push("MERIDIANFIN\\SOCAnalyst");
    } else if (c==="hostname") { push("SOC-WS-01");
    } else if (c==="ipconfig") { push("  IPv4: 10.4.1.50  Subnet: 255.255.255.0  GW: 10.4.1.1");
    } else { push(`'${cmd}' is not recognized. Type 'help' for available commands.`); }
    setInput("");
  }

  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal-box" style={{maxWidth:760}}>
        <div className="modal-head" style={{background:"#050810"}}>
          <div style={{display:"flex",gap:6}}>
            {["#ff4757","#ffb830","#00e676"].map(c=><div key={c} style={{width:11,height:11,borderRadius:"50%",background:c,opacity:.8}}/>)}
          </div>
          <span style={{flex:1,textAlign:"center",fontSize:12,color:"var(--t4)",fontFamily:"var(--mono)"}}>Windows PowerShell — SOC Analyst</span>
          <button className="btn btn-ghost" style={{padding:"4px 10px",background:"transparent",border:"none",color:"var(--t4)"}} onClick={onClose}>✕</button>
        </div>
        <div style={{background:"#050810",padding:16,height:380,display:"flex",flexDirection:"column"}}>
          <div style={{flex:1,overflowY:"auto",fontFamily:"var(--mono)",fontSize:12,color:"#c0c0c0",lineHeight:1.7}}>
            {lines.map((l,i)=><div key={i}>{l}</div>)}
            <div ref={endRef} />
          </div>
          <div style={{display:"flex",gap:8,alignItems:"center",borderTop:"1px solid var(--line)",paddingTop:8,marginTop:4}}>
            <span style={{color:"#00e676",fontFamily:"var(--mono)",fontSize:12,flexShrink:0}}>PS C:\{">"}</span>
            <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&exec(input)}
              style={{background:"transparent",border:"none",flex:1,color:"#c0c0c0",fontFamily:"var(--mono)",fontSize:12,padding:0,outline:"none"}}
              autoFocus placeholder="Type 'help' for available commands..." />
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── BYTE ASSISTANT ───────────────────────────────────────────────────────────
function ByteAssistant({ activeApp, onOpen }) {
  const [open,    setOpen]    = useState(false);
  const [stepIdx, setStepIdx] = useState(0);
  const [typing,  setTyping]  = useState(false);
  const [html,    setHtml]    = useState("");
  const [edge,    setEdge]    = useState("right");
  const [vRatio,  setVRatio]  = useState(0.72);
  const [panelW,  setPanelW]  = useState(380);
  const [panelH,  setPanelH]  = useState(440);
  const [skipped, setSkipped] = useState(false);
  const [doneActions, setDoneActions] = useState(() => new Set());

  useEffect(() => {
    function onAct(e){ const k=e?.detail?.key; if(!k) return; setDoneActions(prev=>{ if(prev.has(k)) return prev; const n=new Set(prev); n.add(k); return n; }); }
    window.addEventListener("lab:action", onAct);
    return () => window.removeEventListener("lab:action", onAct);
  }, []);

  const wRef    = useRef(null);
  const bodyRef = useRef(null);
  const dragging   = useRef(false);
  const dragOff    = useRef({x:0,y:0});
  const resizing   = useRef(null);
  const resStart   = useRef({});
  const typTimer   = useRef(null);

  const step  = BYTE_STEPS[stepIdx];
  const total = BYTE_STEPS.length;
  const prog  = (stepIdx+1)/total*100;

  useEffect(() => { const t=setTimeout(()=>setOpen(true),1400); return()=>clearTimeout(t); },[]);
  useEffect(() => { if(open) snap(true); },[open]);
  useEffect(() => {
    if(!open) return;
    setTyping(true); setHtml("");
    clearTimeout(typTimer.current);
    typTimer.current = setTimeout(()=>{
      setTyping(false); setHtml(step.content);
      if(bodyRef.current) bodyRef.current.scrollTop=0;
    },500);
    // Broadcast the current step's target app so the desktop/taskbar can highlight it
    try { window.dispatchEvent(new CustomEvent("lab:highlight", { detail: { nav: (step.nav && step.nav!=="desktop") ? step.nav : null } })); } catch(e){}
    return()=>clearTimeout(typTimer.current);
  },[stepIdx,open]);

  function snap(animate,forceEdge) {
    const w=wRef.current; if(!w) return;
    const e=forceEdge||edge; if(forceEdge) setEdge(forceEdge);
    const vw=window.innerWidth,vh=window.innerHeight;
    const tl=e==="left"?12:vw-50-12;
    const tt=Math.max(8,Math.min(vRatio*vh,vh-50-8));
    w.style.transition=animate?"left .28s ease,top .28s ease":"none";
    w.style.left=tl+"px"; w.style.top=tt+"px";
    w.style.right="auto"; w.style.bottom="auto";
    setTimeout(()=>{if(w)w.style.transition="none";},300);
  }

  useEffect(()=>{const fn=()=>{snap(false);const maxW=Math.max(280,window.innerWidth-48);const maxH=Math.max(220,window.innerHeight-120);setPanelW(w=>Math.min(w,maxW));setPanelH(h=>Math.min(h,maxH));};window.addEventListener("resize",fn);return()=>window.removeEventListener("resize",fn);});

  useEffect(()=>{
    const mm=e=>{
      if(!dragging.current||!wRef.current) return;
      wRef.current.style.transition="none";
      wRef.current.style.left=(e.clientX-dragOff.current.x)+"px";
      wRef.current.style.top=(e.clientY-dragOff.current.y)+"px";
      setVRatio((e.clientY-dragOff.current.y)/window.innerHeight);
    };
    const mu=e=>{
      if(!dragging.current) return; dragging.current=false; document.body.style.cursor="";
      const w=wRef.current; if(!w) return;
      const r=w.getBoundingClientRect();
      const ne=r.left+25<window.innerWidth/2?"left":"right";
      setVRatio(r.top/window.innerHeight); setEdge(ne); snap(true,ne);
    };
    window.addEventListener("mousemove",mm); window.addEventListener("mouseup",mu);
    return()=>{window.removeEventListener("mousemove",mm);window.removeEventListener("mouseup",mu);};
  });

  useEffect(()=>{
    const mm=e=>{
      if(!resizing.current) return;
      const {sw,sh,sx,sy,type}=resStart.current;
      const dx=e.clientX-sx,dy=e.clientY-sy;
      if(type==="side"){setPanelW(edge==="right"?Math.max(280,Math.min(window.innerWidth-48,sw-dx)):Math.max(280,Math.min(window.innerWidth-48,sw+dx)));}
      else{setPanelW(edge==="right"?Math.max(280,Math.min(window.innerWidth-48,sw-dx)):Math.max(280,Math.min(window.innerWidth-48,sw+dx)));setPanelH(Math.max(220,Math.min(window.innerHeight-48,sh+dy)));}
    };
    const mu=()=>{resizing.current=null;document.body.style.cursor="";};
    window.addEventListener("mousemove",mm); window.addEventListener("mouseup",mu);
    return()=>{window.removeEventListener("mousemove",mm);window.removeEventListener("mouseup",mu);};
  });

  function startDrag(e){if(e.target.closest(".byte-close-x")||e.target.closest(".brs")||e.target.closest(".brc"))return;e.preventDefault();const r=wRef.current.getBoundingClientRect();dragOff.current={x:e.clientX-r.left,y:e.clientY-r.top};dragging.current=true;document.body.style.cursor="grabbing";}
  function startResize(e,type){e.stopPropagation();e.preventDefault();resizing.current=type;resStart.current={sw:panelW,sh:panelH,sx:e.clientX,sy:e.clientY,type};document.body.style.cursor=type==="side"?"ew-resize":"nwse-resize";}

  function goNext(){
    if(nextLocked) return;
    if(stepIdx<total-1){
      const next=BYTE_STEPS[stepIdx+1];
      if(next.nav&&next.nav!=="desktop"&&next.nav!==activeApp) onOpen(next.nav);
      setStepIdx(stepIdx+1);
    }
  }
  function goPrev(){if(stepIdx>0){const p=BYTE_STEPS[stepIdx-1];if(p.nav&&p.nav!=="desktop"&&p.nav!==activeApp)onOpen(p.nav);setStepIdx(stepIdx-1);}}

  if(skipped) return null;
  const panelLeft=edge==="left";
  const isLast=stepIdx===total-1;

  // Strict gating: nav:<app> gates require activeApp match; other keys require the emitted event.
  const gates = step.gate ? (Array.isArray(step.gate)?step.gate:[step.gate]) : [];
  const gatesSatisfied = gates.every(g => g.startsWith("nav:") ? activeApp===g.slice(4) : doneActions.has(g));
  const actionComplete = step.action ? gatesSatisfied : true;
  const nextLocked = !!step.action && !actionComplete && !isLast;

  return (
    <div className="byte-widget" ref={wRef} style={{position:"fixed",width:50,height:50,zIndex:9500}}>
      {open && (
        <div className="byte-panel" style={{width:panelW,height:panelH,bottom:50,[panelLeft?"left":"right"]:0}}>
          {/* Resize handles */}
          <div className="brs" style={{position:"absolute",top:"50%",transform:"translateY(-50%)",width:5,height:40,borderRadius:3,background:"rgba(0,229,255,.15)",cursor:"ew-resize",[panelLeft?"right":"left"]:-7}} onMouseDown={e=>startResize(e,"side")} />
          <div className="brc" style={{position:"absolute",width:12,height:12,borderRadius:3,background:"rgba(0,229,255,.12)",cursor:"nwse-resize",bottom:-6,[panelLeft?"right":"left"]:-6}} onMouseDown={e=>startResize(e,"corner")} />
          {/* Header */}
          <div className="byte-head" onMouseDown={startDrag}>
            <span style={{display:"inline-flex",color:"var(--cyan)"}}><Icons.Bot size={17}/></span>
            <span style={{flex:1,fontFamily:"var(--mono)",fontSize:11,fontWeight:700,color:"var(--t1)"}}>Byte — Meridian IR</span>
            <span className="byte-dot" style={{width:7,height:7,borderRadius:"50%",background:"var(--green)",flexShrink:0,display:"inline-block"}} />
            <button className="byte-close-x" onClick={()=>setOpen(false)} style={{background:"transparent",border:"none",color:"var(--t4)",fontSize:15,cursor:"pointer",padding:"0 2px",marginLeft:4,display:"inline-flex"}}><Icons.Minus size={14}/></button>
          </div>
          {/* Progress */}
          <div style={{padding:"7px 14px 5px",borderBottom:"1px solid var(--line)",flexShrink:0}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:4,fontSize:10,color:"var(--t4)",fontFamily:"var(--mono)"}}>
              <span>Step {stepIdx+1} / {total}</span>
              <span style={{background:"var(--cyan-dim)",color:"var(--cyan)",border:"1px solid rgba(0,229,255,.2)",padding:"0 7px",borderRadius:10,fontSize:9}}>{step.nav?.toUpperCase()||"LAB"}</span>
            </div>
            <div className="byte-prog"><div className="byte-prog-fill" style={{width:prog+"%"}} /></div>
          </div>
          {/* Body */}
          <div className="byte-body" ref={bodyRef} style={{flex:1,overflowY:"auto",padding:14}}>
            {step.nav&&step.nav!=="desktop"&&step.nav!==activeApp&&(
              <div className="byte-nav-hint">→ Navigate to: <b style={{color:"var(--cyan)"}}>{step.nav}</b></div>
            )}
            {isLast&&<div style={{display:"inline-flex",alignItems:"center",gap:6,background:"rgba(0,230,118,.08)",border:"1px solid rgba(0,230,118,.2)",borderRadius:20,padding:"3px 12px",marginBottom:10,fontSize:10,fontWeight:700,color:"var(--green)",fontFamily:"var(--mono)"}}>✓ LAB COMPLETE</div>}
            <div className="byte-step-title">
              <span className="byte-num">{String(stepIdx+1).padStart(2,"0")}</span>
              {step.title}
            </div>
            {typing
              ? <div style={{display:"flex",gap:4,padding:"4px 0"}}>{[0,1,2].map(i=><div key={i} style={{width:6,height:6,borderRadius:"50%",background:"rgba(0,229,255,.4)",animation:`pulse 1.2s ${i*.2}s ease-in-out infinite`}}/>)}</div>
              : <div dangerouslySetInnerHTML={{__html:html}} />
            }
          </div>
          {step.action&&!typing&&(
            <div className="byte-action" style={{margin:"0 14px 10px",display:"flex",alignItems:"center",gap:7,color:actionComplete?"var(--green)":"var(--amber)",border:`1px solid ${actionComplete?"rgba(0,230,118,.3)":"rgba(255,184,48,.3)"}`,background:actionComplete?"rgba(0,230,118,.07)":"rgba(255,184,48,.06)",borderRadius:7,padding:"8px 11px",fontSize:11}}>
              {actionComplete?<Icons.Check size={13} color="var(--green)"/>:<Icons.Lock size={13} color="var(--amber)"/>}
              <span>{actionComplete?"Action complete — you may continue":step.action}</span>
            </div>
          )}
          {/* Footer */}
          <div className="byte-foot" style={{display:"flex",alignItems:"center",gap:6,padding:"9px 14px",borderTop:"1px solid var(--line)",flexShrink:0}}>
            <button onClick={()=>setSkipped(true)} style={{background:"transparent",border:"none",color:"var(--t4)",fontSize:10,cursor:"pointer"}}>Skip</button>
            <div style={{flex:1}} />
            <button className="btn btn-ghost" style={{padding:"5px 12px",fontSize:11}} onClick={goPrev} disabled={stepIdx===0}>← Back</button>
            <button className={`btn ${isLast?"btn-success":"btn-primary"}`} style={{padding:"5px 14px",fontSize:11,opacity:nextLocked?0.4:1,cursor:nextLocked?"default":"pointer"}} onClick={isLast?()=>setSkipped(true):goNext} disabled={nextLocked} title={nextLocked?"Complete the action to continue":""}>
              {isLast?"Finish ✓":(nextLocked?"Locked":"Next →")}
            </button>
          </div>
        </div>
      )}
      {/* Launcher */}
      <div className="byte-launcher" onClick={()=>setOpen(v=>!v)}>
        {open?<span style={{display:"inline-flex",color:"var(--cyan)"}}><Icons.X size={18}/></span>:<span style={{display:"inline-flex",color:"var(--cyan)"}}><Icons.Bot size={22}/></span>}
        {!open&&<span className="byte-badge">{stepIdx+1}</span>}
      </div>
    </div>
  );
}

// ─── DESKTOP ICONS ────────────────────────────────────────────────────────────
function Desktop({ onOpen, infected }) {
  const icons = [
    {id:"dfir",    icon:"⚔",  label:"CipherOps DFIR", cls:""},
    {id:"alerts",  icon:"🛡",  label:"Security Alerts",cls:"",blink:infected},
    {id:"outlook", icon:"📧",  label:"Outlook",        cls:""},
    {id:"backup",  icon:"💾",  label:"Azure Backup",   cls:""},
    {id:"terminal",icon:"⬛",  label:"Terminal",       cls:""},
    {id:"vt",      icon:"🦠",  label:"VirusTotal",     cls:""},
  ];
  return (
    <div style={{position:"absolute",top:20,left:20,display:"flex",flexDirection:"column",gap:4}}>
      {icons.map(ic=>(
        <div key={ic.id} className={`desktop-icon ${ic.cls}`} onDoubleClick={()=>onOpen(ic.id)}
          style={{position:"relative"}}>
          <div className="icon-img" style={{filter:ic.blink?`drop-shadow(0 0 8px rgba(255,184,48,.9)) drop-shadow(0 0 16px rgba(255,184,48,.4))`:"",animation:ic.blink?"pulse 1.5s infinite":""}}>{ic.icon}</div>
          <div className="icon-label">{ic.label}</div>
          {ic.blink&&<div style={{position:"absolute",top:6,right:4,width:8,height:8,borderRadius:"50%",background:"var(--amber)",animation:"pulse 1s infinite"}}/>}
        </div>
      ))}
      {/* Malware .exe */}
      <div className="desktop-icon icon-malware" onDoubleClick={()=>onOpen("exe")} title="WARNING: Malicious file">
        <div className="icon-img">⚙️</div>
        <div className="icon-label" style={{color:"#ff8888"}}>Invoice_Q4_2026.exe</div>
      </div>
    </div>
  );
}

// ─── LIVE ALERT FEED (bottom-right toasts) ───────────────────────────────────
function AlertFeed({ infected }) {
  const [toasts, setToasts] = useState([]);
  const idx = useRef(0);

  useEffect(() => {
    if (!infected) return;
    const iv = setInterval(() => {
      if (idx.current < ALERTS.length) {
        const a = ALERTS[idx.current];
        const id = Date.now();
        setToasts(p => [{ ...a, id }, ...p.slice(0, 4)]);
        idx.current++;
      }
    }, 2500);
    return () => clearInterval(iv);
  }, [infected]);

  return (
    <div style={{position:"fixed",right:14,bottom:52,width:340,zIndex:800,pointerEvents:"none",display:"flex",flexDirection:"column",gap:6}}>
      {toasts.map((t,i) => (
        <div key={t.id} style={{background:"var(--s1)",border:`1px solid ${t.sev==="critical"?"rgba(255,71,87,.35)":"rgba(255,184,48,.3)"}`,borderRadius:7,padding:"9px 12px",animation:"slideRight .3s ease-out",opacity:1-i*.15,boxShadow:"0 4px 20px rgba(0,0,0,.5)"}}>
          <div style={{display:"flex",gap:7,alignItems:"center",marginBottom:4}}>
            <SevTag sev={t.sev} />
            <span style={{fontFamily:"var(--mono)",fontSize:9,color:"var(--t4)"}}>{t.time} UTC</span>
          </div>
          <div style={{fontSize:11,color:"var(--t1)",lineHeight:1.35}}>{t.title}</div>
        </div>
      ))}
    </div>
  );
}

// ─── SCORE PANEL ─────────────────────────────────────────────────────────────
function ScorePanel({ score }) {
  const milestones = [{p:50,l:"Alert Triage"},{p:100,l:"Containment"},{p:200,l:"Investigation"},{p:300,l:"Recovery"},{p:500,l:"Report Filed"}];
  const next = milestones.find(m=>m.p>score);
  return (
    <div className="score-pill">
      <span style={{fontSize:9,color:"var(--t4)",fontFamily:"var(--mono)"}}>SCORE</span>
      <span style={{fontWeight:700}}>{score}</span>
      {next&&<span style={{fontSize:10,color:"var(--t4)"}}>→ {next.l}</span>}
    </div>
  );
}

// ─── WELCOME MODAL ────────────────────────────────────────────────────────────
function WelcomeModal({ onStart }) {
  return (
    <div className="modal-overlay">
      <div className="modal-box" style={{maxWidth:560,animation:"fadeUp .3s ease-out"}}>
        <div style={{padding:"32px 36px"}}>
          <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
            <div style={{width:48,height:48,borderRadius:10,background:"var(--cyan-dim)",border:"1px solid rgba(0,229,255,.3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24}}>🏦</div>
            <div>
              <div style={{fontFamily:"var(--display)",fontSize:22,fontWeight:800,color:"var(--t1)",letterSpacing:".02em"}}>Meridian Financial</div>
              <div style={{fontSize:12,color:"var(--t3)",fontFamily:"var(--mono)",marginTop:2}}>Ransomware Incident Response Lab · v2.0</div>
            </div>
          </div>
          <div style={{background:"var(--s2)",borderRadius:8,padding:"14px 16px",marginBottom:20,border:"1px solid var(--line)"}}>
            <div style={{fontSize:12,color:"var(--t2)",lineHeight:1.85}}>
              You are <b style={{color:"var(--t1)"}}>Alex Rivera, SOC Analyst II</b>. The time is <b style={{color:"var(--cyan)"}}>02:18 UTC, 14 November 2026</b>. A critical security alert is about to arrive.<br/><br/>
              <b style={{color:"var(--amber)"}}>Objective:</b> Investigate, contain, and respond to a BlackMatter Pro v4.2 ransomware attack targeting <b style={{color:"var(--t1)"}}>FILESVR-01</b>. You will move through the five IR phases — <b style={{color:"var(--t1)"}}>Triage → Containment → Investigation → Recovery → Reporting</b> — completing the six tasks below to maximise your score.
            </div>
          </div>
          <div style={{fontSize:11,color:"var(--t3)",fontFamily:"var(--mono)",letterSpacing:".06em",marginBottom:8}}>YOUR WORKFLOW — 6 TASKS</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:24}}>
            {["1. Triage alerts in Security Alerts","2. Open DFIR platform for investigation","3. Block IOCs and contain the attack","4. Analyse IOCs in VirusTotal","5. Restore backups in Azure Backup","6. File the Executive Report"].map((s,i)=>(
              <div key={i} style={{display:"flex",gap:7,alignItems:"flex-start",fontSize:11,color:"var(--t2)"}}>
                <span style={{color:"var(--cyan)",flexShrink:0,fontFamily:"var(--mono)"}}>›</span>{s}
              </div>
            ))}
          </div>
          <div style={{display:"flex",gap:10,alignItems:"center"}}>
            <button className="btn btn-primary" style={{flex:1,justifyContent:"center",padding:"10px 20px",fontSize:13}} onClick={onStart}>
              Start Lab — Begin Monitoring
            </button>
            <div style={{fontSize:11,color:"var(--t4)",fontFamily:"var(--mono)"}}>Byte guide will appear →</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── TASKBAR ─────────────────────────────────────────────────────────────────
function Taskbar({ open, onOpen, time, infected, score }) {
  const [hl, setHl] = useState(null);
  useEffect(() => {
    function onHl(e){ setHl(e?.detail?.nav || null); }
    window.addEventListener("lab:highlight", onHl);
    return () => window.removeEventListener("lab:highlight", onHl);
  }, []);
  const apps = [
    {id:"dfir",    icon:"⚔",  label:"DFIR"},
    {id:"alerts",  icon:"🛡",  label:"Alerts",  alert:infected},
    {id:"outlook", icon:"📧",  label:"Outlook"},
    {id:"backup",  icon:"💾",  label:"Backup"},
    {id:"terminal",icon:"⬛",  label:"CMD"},
    {id:"vt",      icon:"🦠",  label:"VT"},
  ];
  return (
    <div className="taskbar">
      {/* Logo */}
      <div style={{display:"flex",alignItems:"center",gap:8,marginRight:8,paddingRight:12,borderRight:"1px solid var(--line)"}}>
        <div style={{width:24,height:24,borderRadius:5,background:"var(--cyan-dim)",border:"1px solid rgba(0,229,255,.25)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12}}>⚔</div>
        <span style={{fontFamily:"var(--display)",fontSize:11,fontWeight:700,color:"var(--t1)"}}>MIR</span>
      </div>
      {apps.map(a=>{
        const highlight = hl===a.id && open!==a.id;
        return (
        <button key={a.id} className={`tb-btn ${open===a.id?"open":""} ${a.alert?"alert":""}`} onClick={()=>onOpen(a.id)}
          style={highlight?{boxShadow:"0 0 0 2px rgba(0,229,255,.55), 0 0 14px rgba(0,229,255,.4)",borderRadius:8,animation:"pulse 1.4s infinite"}:undefined}
          title={highlight?"Byte: open this next":undefined}>
          <span style={{fontSize:16}}>{a.icon}</span>
          <span className="tb-label">{a.label}</span>
          {open===a.id&&<div className="tb-pip"/>}
          {highlight&&<div style={{position:"absolute",top:2,right:4,width:7,height:7,borderRadius:"50%",background:"var(--cyan)",animation:"pulse 1s infinite"}}/>}
          {a.alert&&<div className="tb-badge">!</div>}
        </button>
      );})}
      <div style={{flex:1}}/>
      {/* Phase indicator */}
      <div style={{fontFamily:"var(--mono)",fontSize:10,padding:"3px 14px",borderRadius:20,background:infected?"rgba(255,71,87,.1)":"rgba(255,255,255,.04)",border:`1px solid ${infected?"rgba(255,71,87,.3)":"var(--line)"}`,color:infected?"var(--red)":"var(--t4)",animation:infected?"pulse 2s infinite":"none"}}>
        {infected?"● INCIDENT ACTIVE":"MONITORING"}
      </div>
      <div style={{fontFamily:"var(--mono)",fontSize:12,color:"var(--t2)",marginLeft:12,minWidth:70,textAlign:"right"}}>{time}</div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  useStyles();
  const clock    = useClock();
  const [started,  setStarted]  = useState(false);
  const [infected, setInfected] = useState(false);
  const [showExec, setShowExec] = useState(false);
  const [openApp,  setOpenApp]  = useState(null);
  const [score,    setScore]    = useState(0);

  const addScore = useCallback(pts => setScore(p => p + pts), []);

  function handleOpen(id) {
    if (id === "exe") { setShowExec(true); return; }
    setOpenApp(id);
    if (id === "alerts" && infected) addScore(25);
  }

  function handleExeDone() {
    setShowExec(false);
    setInfected(true);
    labAction("exe-run");
    setTimeout(() => setOpenApp("alerts"), 600);
  }

  // Wallpaper
  const wallBg = infected
    ? "radial-gradient(ellipse at 20% 80%,rgba(255,71,87,.06) 0%,transparent 60%),radial-gradient(ellipse at 80% 20%,rgba(255,71,87,.04) 0%,transparent 50%),linear-gradient(135deg,#080c10 0%,#0a0d12 100%)"
    : "radial-gradient(ellipse at 30% 40%,rgba(0,229,255,.04) 0%,transparent 60%),radial-gradient(ellipse at 70% 70%,rgba(191,138,255,.03) 0%,transparent 50%),linear-gradient(135deg,#080c10 0%,#0a0e14 100%)";

  return (
    <div style={{height:"100dvh",background:wallBg,position:"relative",overflow:"hidden",transition:"background 2s"}}>
      {/* Grid lines */}
      <div style={{position:"absolute",inset:0,backgroundImage:"linear-gradient(rgba(255,255,255,.012) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.012) 1px,transparent 1px)",backgroundSize:"60px 60px",pointerEvents:"none",opacity:infected?.5:1}} />

      {/* Welcome */}
      {!started && <WelcomeModal onStart={()=>setStarted(true)} />}

      {/* Score */}
      {started && <ScorePanel score={score} />}

      {/* Desktop */}
      {started && <Desktop onOpen={handleOpen} infected={infected} />}

      {/* Infection clock text */}
      {infected && (
        <div style={{position:"fixed",top:58,left:"50%",transform:"translateX(-50%)",background:"rgba(255,71,87,.08)",border:"1px solid rgba(255,71,87,.3)",borderRadius:20,padding:"5px 20px",fontFamily:"var(--mono)",fontSize:11,color:"var(--red)",zIndex:500,animation:"slideDown .3s ease-out"}}>
          🚨 RANSOMWARE ACTIVE — Open Security Alerts → DFIR → Contain
        </div>
      )}

      {/* Ransomware execution */}
      {showExec && <RansomExec onDone={handleExeDone} />}

      {/* App modals */}
      {openApp==="dfir"    && <DFIRPlatform   onClose={()=>setOpenApp(null)} score={score} addScore={addScore} />}
      {openApp==="alerts"  && <AlertsPanel    active={infected} onClose={()=>setOpenApp(null)} />}
      {openApp==="outlook" && <OutlookPanel   onClose={()=>setOpenApp(null)} addScore={addScore} />}
      {openApp==="backup"  && <BackupPanel    onClose={()=>setOpenApp(null)} addScore={addScore} />}
      {openApp==="vt"      && <VTPanel        onClose={()=>setOpenApp(null)} addScore={addScore} />}
      {openApp==="terminal"&& <TerminalPanel  onClose={()=>setOpenApp(null)} addScore={addScore} />}

      {/* Alert toasts */}
      {started && <AlertFeed infected={infected} />}

      {/* Taskbar */}
      {started && <Taskbar open={openApp} onOpen={handleOpen} time={clock} infected={infected} score={score} />}

      {/* Byte */}
      {started && <ByteAssistant activeApp={openApp} onOpen={handleOpen} />}
    </div>
  );
}
