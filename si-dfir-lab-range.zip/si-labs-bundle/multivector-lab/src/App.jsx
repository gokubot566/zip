import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { LabProvider } from './context/LabContext';
import NavSidebar from './components/NavSidebar';
import AIAssistant from './components/AIAssistant';
import Dashboard from './pages/Dashboard';
import EvidenceRepository from './pages/EvidenceRepository';
import AttackTimeline from './pages/AttackTimeline';
import IOCManagement from './pages/IOCManagement';
import ContainmentConsole from './pages/ContainmentConsole';
import {
  ImpactAssessment,
  ExecutiveBriefing,
  RegulatoryNotification,
  FinalReport,
  Scoring,
} from './pages/AllPages';

export default function App() {
  return (
    <LabProvider>
      <BrowserRouter>
        <div style={{ display: 'flex', minHeight: '100vh', background: '#060a14' }}>
          <NavSidebar />
          <main style={{ flex: 1, overflowY: 'auto', maxHeight: '100vh' }}>
            <Routes>
              <Route path="/"            element={<Dashboard />} />
              <Route path="/evidence"    element={<EvidenceRepository />} />
              <Route path="/timeline"    element={<AttackTimeline />} />
              <Route path="/ioc"         element={<IOCManagement />} />
              <Route path="/containment" element={<ContainmentConsole />} />
              <Route path="/impact"      element={<ImpactAssessment />} />
              <Route path="/executive"   element={<ExecutiveBriefing />} />
              <Route path="/regulatory"  element={<RegulatoryNotification />} />
              <Route path="/report"      element={<FinalReport />} />
              <Route path="/scoring"     element={<Scoring />} />
            </Routes>
          </main>
          <AIAssistant />
        </div>
      </BrowserRouter>
    </LabProvider>
  );
}
