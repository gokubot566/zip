import React, { useState } from 'react';
import { useLab } from '../context/LabContext';

const phaseColor = {
  'Initial Access':'#ef4444','Execution':'#f97316','Persistence':'#f59e0b',
  'Command & Control':'#8b5cf6','Credential Access':'#ec4899','Lateral Movement':'#3b82f6',
  'Collection':'#06b6d4','Exfiltration':'#10b981','Impact':'#dc2626',
};

export default function AttackTimeline() {
  const { state, dispatch } = useLab();
  const [editId, setEditId] = useState(null);
  const [noteText, setNoteText] = useState('');

  const completed = state.attackChain.filter(s=>s.completed).length;

  function toggle(id) { dispatch({ type:'TOGGLE_CHAIN_STEP', id }); }
  function saveNote(id) {
    dispatch({ type:'UPDATE_CHAIN_NOTES', id, notes: noteText });
    setEditId(null);
  }
  function startEdit(step) {
    setEditId(step.id);
    setNoteText(step.notes || '');
  }

  return (
    <div style={{ padding:'28px 32px', maxWidth:1000, margin:'0 auto' }}>
      <div style={{ marginBottom:24 }}>
        <h1 style={{ fontFamily:'monospace', fontWeight:800, fontSize:20, color:'#f8fafc', marginBottom:4 }}>⏱️ Attack Timeline Builder</h1>
        <p style={{ fontSize:13, color:'#475569', marginBottom:12 }}>
          Check each step as you confirm it from the evidence. Add analyst notes. Target: reconstruct the complete 14-step attack chain.
        </p>
        <div style={{ display:'flex', gap:12, alignItems:'center' }}>
          <div style={{ padding:'6px 14px', background:'rgba(109,40,217,0.12)', border:'1px solid #6d28d9', borderRadius:6, fontFamily:'monospace', fontSize:13, color:'#a78bfa' }}>
            {completed}/{state.attackChain.length} steps confirmed
          </div>
          <div style={{ height:6, flex:1, maxWidth:300, background:'#1e293b', borderRadius:3, overflow:'hidden' }}>
            <div style={{ width:`${Math.round((completed/state.attackChain.length)*100)}%`, height:'100%', background:'linear-gradient(90deg,#6d28d9,#4f46e5)', transition:'width 0.4s' }}/>
          </div>
        </div>
      </div>

      {/* MITRE phases legend */}
      <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginBottom:20 }}>
        {Object.entries(phaseColor).map(([phase,color]) => (
          <span key={phase} style={{ padding:'3px 10px', borderRadius:4, background:color+'22', border:`1px solid ${color}44`, color, fontSize:11, fontFamily:'monospace' }}>{phase}</span>
        ))}
      </div>

      {/* Timeline */}
      <div style={{ display:'flex', flexDirection:'column', gap:0 }}>
        {state.attackChain.map((step, i) => (
          <div key={step.id} style={{ display:'flex', gap:0 }}>
            {/* Connector */}
            <div style={{ display:'flex', flexDirection:'column', alignItems:'center', width:40, flexShrink:0 }}>
              <div
                onClick={() => toggle(step.id)}
                style={{
                  width:28, height:28, borderRadius:'50%', cursor:'pointer',
                  background: step.completed ? phaseColor[step.phase]||'#6d28d9' : '#1e293b',
                  border: `2px solid ${step.completed ? phaseColor[step.phase]||'#6d28d9' : '#334155'}`,
                  display:'flex', alignItems:'center', justifyContent:'center',
                  fontSize:13, color:'#fff', fontWeight:700, flexShrink:0,
                  transition:'all 0.2s', zIndex:1,
                }}
                title={step.completed ? 'Click to unconfirm' : 'Click to confirm'}
              >{step.completed ? '✓' : String(i+1).padStart(2,'0')}</div>
              {i < state.attackChain.length-1 && (
                <div style={{ width:2, flex:1, minHeight:16, background: step.completed?'#334155':'#1e293b' }}/>
              )}
            </div>

            {/* Card */}
            <div style={{
              flex:1, marginLeft:12, marginBottom:8,
              background:'#0f172a', border:`1px solid ${step.completed?phaseColor[step.phase]+'44':'#1e293b'}`,
              borderRadius:8, padding:'12px 16px', transition:'all 0.2s',
            }}>
              <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:6, flexWrap:'wrap' }}>
                <span style={{ fontFamily:'monospace', fontSize:12, color:'#6d28d9', fontWeight:700 }}>{step.time}</span>
                <span style={{ padding:'2px 8px', borderRadius:3, background:phaseColor[step.phase]+'22', color:phaseColor[step.phase], fontSize:10, fontFamily:'monospace', fontWeight:700 }}>{step.phase}</span>
                <span style={{ fontFamily:'monospace', fontSize:11, color:'#334155' }}>{step.host}</span>
                {step.user && <span style={{ fontFamily:'monospace', fontSize:11, color:'#475569' }}>👤 {step.user}</span>}
              </div>
              <div style={{ fontFamily:'monospace', fontWeight:600, fontSize:13, color: step.completed?'#e2e8f0':'#94a3b8', marginBottom:6 }}>{step.event}</div>
              <div style={{ display:'flex', gap:10, fontSize:11, color:'#334155', fontFamily:'monospace', marginBottom: step.notes||editId===step.id ? 8 : 0, flexWrap:'wrap' }}>
                {step.ioc && <span>IOC: <span style={{color:'#f59e0b'}}>{step.ioc}</span></span>}
                <span>Evidence: <span style={{color:'#3b82f6'}}>{step.evidence}</span></span>
              </div>

              {editId === step.id ? (
                <div style={{ marginTop:8 }}>
                  <textarea value={noteText} onChange={e=>setNoteText(e.target.value)} rows={3}
                    placeholder="Analyst notes — what did you find in the evidence to confirm this step?"
                    style={{ width:'100%', background:'#1e293b', border:'1px solid #4f46e5', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:12, padding:'8px 10px', resize:'vertical', outline:'none', boxSizing:'border-box' }}
                  />
                  <div style={{ display:'flex', gap:8, marginTop:6 }}>
                    <button onClick={() => saveNote(step.id)} style={{ padding:'5px 14px', borderRadius:5, background:'#6d28d9', border:'none', color:'#fff', fontFamily:'monospace', fontSize:12, cursor:'pointer' }}>Save</button>
                    <button onClick={() => setEditId(null)} style={{ padding:'5px 14px', borderRadius:5, background:'transparent', border:'1px solid #334155', color:'#64748b', fontFamily:'monospace', fontSize:12, cursor:'pointer' }}>Cancel</button>
                  </div>
                </div>
              ) : (
                <div style={{ display:'flex', gap:8, marginTop:4 }}>
                  {step.notes && <div style={{ flex:1, padding:'6px 10px', background:'#1e293b', borderRadius:5, fontSize:12, color:'#94a3b8', fontFamily:'monospace' }}>{step.notes}</div>}
                  <button onClick={() => startEdit(step)} style={{ padding:'4px 10px', borderRadius:5, background:'transparent', border:'1px solid #334155', color:'#475569', fontFamily:'monospace', fontSize:11, cursor:'pointer' }}>
                    {step.notes ? '✏️ Edit' : '+ Note'}
                  </button>
                  <button onClick={() => toggle(step.id)} style={{
                    padding:'4px 12px', borderRadius:5, border:'none', cursor:'pointer', fontFamily:'monospace', fontSize:11,
                    background: step.completed ? 'rgba(220,38,38,0.15)' : 'rgba(109,40,217,0.15)',
                    color: step.completed ? '#ef4444' : '#a78bfa',
                  }}>{step.completed ? '✗ Unconfirm' : '✓ Confirm'}</button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
