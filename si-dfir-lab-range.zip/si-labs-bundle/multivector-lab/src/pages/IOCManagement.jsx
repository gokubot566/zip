import React, { useState } from 'react';
import { useLab } from '../context/LabContext';

const typeColor = { IP:'#ef4444', DOMAIN:'#f59e0b', HASH:'#8b5cf6', FILE:'#3b82f6', USER:'#22c55e', URL:'#06b6d4' };
const confColor = { HIGH:'#22c55e', MEDIUM:'#f59e0b', LOW:'#64748b' };

const BLANK = { type:'IP', value:'', confidence:'HIGH', tags:'', source:'', notes:'' };

export default function IOCManagement() {
  const { state, dispatch } = useLab();
  const [form, setForm] = useState(BLANK);
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState('ALL');

  function addIOC() {
    if (!form.value.trim()) return;
    dispatch({ type:'ADD_IOC', ioc:{ ...form, tags: form.tags.split(',').map(t=>t.trim()).filter(Boolean), added: new Date().toISOString() } });
    setForm(BLANK); setShowForm(false);
  }

  const types = ['ALL','IP','DOMAIN','HASH','FILE','USER'];
  const filtered = filter === 'ALL' ? state.iocs : state.iocs.filter(i => i.type === filter);

  return (
    <div style={{ padding:'28px 32px', maxWidth:1100, margin:'0 auto' }}>
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:20 }}>
        <div>
          <h1 style={{ fontFamily:'monospace', fontWeight:800, fontSize:20, color:'#f8fafc', marginBottom:4 }}>🎯 IOC Management</h1>
          <p style={{ fontSize:13, color:'#475569' }}>Track and document all Indicators of Compromise. {state.iocs.length} IOCs identified.</p>
        </div>
        <button onClick={() => setShowForm(s=>!s)} style={{
          padding:'9px 18px', borderRadius:7, background:'#6d28d9', border:'none',
          color:'#fff', fontFamily:'monospace', fontSize:13, fontWeight:700, cursor:'pointer',
        }}>+ Add IOC</button>
      </div>

      {/* Add form */}
      {showForm && (
        <div style={{ background:'#0f172a', border:'1px solid #6d28d9', borderRadius:10, padding:'20px 22px', marginBottom:20 }}>
          <h3 style={{ fontFamily:'monospace', fontSize:14, color:'#a78bfa', marginBottom:14 }}>Add New IOC</h3>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 2fr 1fr', gap:12, marginBottom:12 }}>
            <div>
              <label style={{ fontSize:11, fontFamily:'monospace', color:'#475569', display:'block', marginBottom:5 }}>TYPE</label>
              <select value={form.type} onChange={e=>setForm(f=>({...f,type:e.target.value}))} style={{ width:'100%', padding:'8px 10px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13 }}>
                {['IP','DOMAIN','HASH','FILE','USER','URL'].map(t=><option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize:11, fontFamily:'monospace', color:'#475569', display:'block', marginBottom:5 }}>VALUE</label>
              <input value={form.value} onChange={e=>setForm(f=>({...f,value:e.target.value}))} placeholder="e.g. 185.220.101.93" style={{ width:'100%', padding:'8px 10px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13, boxSizing:'border-box', outline:'none' }}/>
            </div>
            <div>
              <label style={{ fontSize:11, fontFamily:'monospace', color:'#475569', display:'block', marginBottom:5 }}>CONFIDENCE</label>
              <select value={form.confidence} onChange={e=>setForm(f=>({...f,confidence:e.target.value}))} style={{ width:'100%', padding:'8px 10px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13 }}>
                {['HIGH','MEDIUM','LOW'].map(c=><option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:12 }}>
            <div>
              <label style={{ fontSize:11, fontFamily:'monospace', color:'#475569', display:'block', marginBottom:5 }}>TAGS (comma-separated)</label>
              <input value={form.tags} onChange={e=>setForm(f=>({...f,tags:e.target.value}))} placeholder="e.g. C2, Ransomware" style={{ width:'100%', padding:'8px 10px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13, boxSizing:'border-box', outline:'none' }}/>
            </div>
            <div>
              <label style={{ fontSize:11, fontFamily:'monospace', color:'#475569', display:'block', marginBottom:5 }}>SOURCE</label>
              <input value={form.source} onChange={e=>setForm(f=>({...f,source:e.target.value}))} placeholder="e.g. EDR / Email Gateway" style={{ width:'100%', padding:'8px 10px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13, boxSizing:'border-box', outline:'none' }}/>
            </div>
          </div>
          <div style={{ marginBottom:14 }}>
            <label style={{ fontSize:11, fontFamily:'monospace', color:'#475569', display:'block', marginBottom:5 }}>ANALYST NOTES</label>
            <textarea value={form.notes} onChange={e=>setForm(f=>({...f,notes:e.target.value}))} rows={2} placeholder="Describe the IOC and how it was identified..." style={{ width:'100%', padding:'8px 10px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13, resize:'vertical', outline:'none', boxSizing:'border-box' }}/>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <button onClick={addIOC} style={{ padding:'8px 20px', borderRadius:7, background:'#6d28d9', border:'none', color:'#fff', fontFamily:'monospace', fontSize:13, fontWeight:700, cursor:'pointer' }}>Add IOC</button>
            <button onClick={() => setShowForm(false)} style={{ padding:'8px 16px', borderRadius:7, background:'transparent', border:'1px solid #334155', color:'#64748b', fontFamily:'monospace', fontSize:13, cursor:'pointer' }}>Cancel</button>
          </div>
        </div>
      )}

      {/* Filter */}
      <div style={{ display:'flex', gap:6, marginBottom:14 }}>
        {types.map(t => (
          <button key={t} onClick={() => setFilter(t)} style={{
            padding:'4px 12px', borderRadius:20, fontSize:11, fontFamily:'monospace', cursor:'pointer',
            border:`1px solid ${filter===t ? '#6d28d9':'#1e293b'}`,
            background: filter===t?'#6d28d9':'transparent',
            color: filter===t?'#fff':'#64748b',
          }}>{t}</button>
        ))}
      </div>

      {/* IOC table */}
      <div style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, overflow:'hidden' }}>
        <div style={{ display:'grid', gridTemplateColumns:'80px 100px 2fr 90px 1fr 1fr 60px', gap:0, padding:'10px 16px', background:'#0a0e1a', borderBottom:'1px solid #1e293b' }}>
          {['ID','TYPE','VALUE','CONFIDENCE','TAGS','NOTES',''].map((h,i) => (
            <div key={i} style={{ fontSize:10, fontFamily:'monospace', color:'#334155', letterSpacing:'0.06em' }}>{h}</div>
          ))}
        </div>
        {filtered.map(ioc => (
          <div key={ioc.id} style={{ display:'grid', gridTemplateColumns:'80px 100px 2fr 90px 1fr 1fr 60px', gap:0, padding:'12px 16px', borderBottom:'1px solid #0f172a', alignItems:'start' }}>
            <div style={{ fontFamily:'monospace', fontSize:11, color:'#334155' }}>{ioc.id}</div>
            <div>
              <span style={{ padding:'2px 8px', borderRadius:3, background:(typeColor[ioc.type]||'#475569')+'22', color:typeColor[ioc.type]||'#475569', fontSize:10, fontFamily:'monospace', fontWeight:700 }}>{ioc.type}</span>
            </div>
            <div style={{ fontFamily:'monospace', fontSize:12, color:'#e2e8f0', wordBreak:'break-all', paddingRight:8 }}>{ioc.value}</div>
            <div>
              <span style={{ fontSize:11, fontFamily:'monospace', fontWeight:700, color:confColor[ioc.confidence]||'#64748b' }}>● {ioc.confidence}</span>
            </div>
            <div style={{ display:'flex', flexWrap:'wrap', gap:4 }}>
              {(Array.isArray(ioc.tags)?ioc.tags:[]).map(tag => (
                <span key={tag} style={{ padding:'1px 6px', borderRadius:3, background:'#1e293b', color:'#94a3b8', fontSize:10, fontFamily:'monospace' }}>{tag}</span>
              ))}
            </div>
            <div style={{ fontSize:11, color:'#64748b', lineHeight:1.5 }}>{ioc.notes}</div>
            <div>
              <button onClick={() => dispatch({type:'REMOVE_IOC',id:ioc.id})} style={{ padding:'3px 8px', borderRadius:4, background:'rgba(220,38,38,0.12)', border:'1px solid rgba(220,38,38,0.2)', color:'#ef4444', fontSize:10, cursor:'pointer', fontFamily:'monospace' }}>✕</button>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div style={{ padding:'30px', textAlign:'center', color:'#334155', fontFamily:'monospace', fontSize:13 }}>No IOCs in this category</div>
        )}
      </div>
    </div>
  );
}
