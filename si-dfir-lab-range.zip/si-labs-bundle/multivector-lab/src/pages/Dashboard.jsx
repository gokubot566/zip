import React from 'react';
import { Link } from 'react-router-dom';
import { useLab } from '../context/LabContext';
import { SCENARIO, SCORING_RUBRIC } from '../data/evidence';

const sev = { CRITICAL:'#dc2626', HIGH:'#f59e0b', MEDIUM:'#3b82f6', LOW:'#22c55e' };

function MetricCard({ label, value, sub, color }) {
  return (
    <div style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, padding:'18px 20px' }}>
      <div style={{ fontSize:11, fontFamily:'monospace', color:'#475569', marginBottom:6, letterSpacing:'0.06em' }}>{label}</div>
      <div style={{ fontSize:28, fontWeight:800, fontFamily:'monospace', color: color||'#f8fafc' }}>{value}</div>
      {sub && <div style={{ fontSize:12, color:'#475569', marginTop:3 }}>{sub}</div>}
    </div>
  );
}

function ScoreBar({ label, score, max }) {
  const pct = Math.round((score/max)*100);
  return (
    <div style={{ marginBottom:12 }}>
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
        <span style={{ fontSize:12, fontFamily:'monospace', color:'#94a3b8' }}>{label}</span>
        <span style={{ fontSize:12, fontFamily:'monospace', color:'#6d28d9', fontWeight:700 }}>{score}/{max}</span>
      </div>
      <div style={{ height:6, background:'#1e293b', borderRadius:3, overflow:'hidden' }}>
        <div style={{ width:`${pct}%`, height:'100%', background:'linear-gradient(90deg,#6d28d9,#4f46e5)', borderRadius:3, transition:'width 0.5s' }}/>
      </div>
    </div>
  );
}

const QUICK_LINKS = [
  { path:'/evidence', icon:'🗂️', label:'Review Evidence', desc:'6 evidence files' },
  { path:'/timeline', icon:'⏱️', label:'Build Timeline', desc:'14 attack steps' },
  { path:'/ioc', icon:'🎯', label:'Manage IOCs', desc:'7 known indicators' },
  { path:'/containment', icon:'🛡️', label:'Containment', desc:'Document actions' },
  { path:'/impact', icon:'⚖️', label:'Impact Assessment', desc:'PII & regulatory' },
  { path:'/report', icon:'📄', label:'Final Report', desc:'Generate output' },
];

export default function Dashboard() {
  const { state } = useLab();
  const chainPct = Math.round((state.attackChain.filter(s=>s.completed).length / state.attackChain.length)*100);
  const iocCount = state.iocs.length;
  const containCount = state.containmentActions.length;

  return (
    <div style={{ padding:'28px 32px', maxWidth:1100, margin:'0 auto' }}>
      {/* Header */}
      <div style={{ marginBottom:28 }}>
        <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:8 }}>
          <span style={{ background:sev.CRITICAL, color:'#fff', padding:'3px 10px', borderRadius:4, fontSize:11, fontFamily:'monospace', fontWeight:700 }}>⚠ CRITICAL</span>
          <span style={{ background:'#dc2626', color:'#fff', padding:'3px 10px', borderRadius:4, fontSize:11, fontFamily:'monospace', fontWeight:700 }}>ACTIVE INCIDENT</span>
          <span style={{ background:'#1e293b', color:'#94a3b8', padding:'3px 10px', borderRadius:4, fontSize:11, fontFamily:'monospace' }}>CASE: INC-2024-1114-001</span>
        </div>
        <h1 style={{ fontFamily:'monospace', fontWeight:800, fontSize:24, color:'#f8fafc', margin:0 }}>{SCENARIO.title}</h1>
        <p style={{ color:'#475569', fontSize:13, marginTop:6 }}>
          {SCENARIO.org} · {SCENARIO.date} · DFIR Investigation Platform
        </p>
      </div>

      {/* Metric cards */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14, marginBottom:24 }}>
        <MetricCard label="INCIDENT STATUS" value="ACTIVE" color="#dc2626"/>
        <MetricCard label="HOSTS AFFECTED" value="5+" sub="3 servers · 2+ workstations" color="#f59e0b"/>
        <MetricCard label="DATA EXFILTRATED" value="2.3 GB" sub="~47,000 customer records" color="#ef4444"/>
        <MetricCard label="INVESTIGATION SCORE" value={state.score.total} sub="out of 100 points" color={state.score.total>=80?'#22c55e':state.score.total>=60?'#f59e0b':'#ef4444'}/>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:20, marginBottom:24 }}>
        {/* Scenario */}
        <div style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, padding:'20px 22px' }}>
          <h2 style={{ fontFamily:'monospace', fontWeight:700, fontSize:15, color:'#a78bfa', marginBottom:14 }}>📋 Incident Overview</h2>
          <div style={{ fontSize:13, color:'#94a3b8', lineHeight:1.8, fontFamily:'monospace' }}>
            <div>Organisation: <span style={{color:'#e2e8f0'}}>NovaCorp Financial Services Pty Ltd</span></div>
            <div>Incident Date: <span style={{color:'#e2e8f0'}}>2024-11-14</span></div>
            <div>Attack Type: <span style={{color:'#ef4444'}}>Phishing → Ransomware + Data Exfiltration</span></div>
            <div>Initial Vector: <span style={{color:'#e2e8f0'}}>Macro-enabled Excel attachment</span></div>
            <div>Exfil Target: <span style={{color:'#e2e8f0'}}>Finance share + Customer DB</span></div>
            <div>Ransom Demand: <span style={{color:'#fbbf24'}}>45 BTC (~AUD 4.2M)</span></div>
          </div>
          <div style={{ marginTop:14, padding:'10px 12px', background:'rgba(220,38,38,0.08)', border:'1px solid rgba(220,38,38,0.2)', borderRadius:7, fontSize:12, color:'#fca5a5', fontFamily:'monospace' }}>
            ⚠ ACTIVE THREAT: Ransomware deployed across 5+ systems. Possible additional compromised hosts not yet identified by overnight analyst.
          </div>
        </div>

        {/* Scoring */}
        <div style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, padding:'20px 22px' }}>
          <h2 style={{ fontFamily:'monospace', fontWeight:700, fontSize:15, color:'#a78bfa', marginBottom:14 }}>🏆 Scoring Progress</h2>
          {Object.entries(SCORING_RUBRIC).map(([key,val]) => (
            <ScoreBar key={key} label={val.label} score={state.score[key]||0} max={val.max}/>
          ))}
          <div style={{ marginTop:12, padding:'8px 12px', background:'#1e293b', borderRadius:6, display:'flex', justifyContent:'space-between' }}>
            <span style={{ fontFamily:'monospace', fontSize:13, color:'#94a3b8' }}>TOTAL</span>
            <span style={{ fontFamily:'monospace', fontSize:16, fontWeight:800, color: state.score.total>=80?'#22c55e':state.score.total>=60?'#f59e0b':'#ef4444' }}>{state.score.total}/100</span>
          </div>
        </div>
      </div>

      {/* Progress */}
      <div style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, padding:'20px 22px', marginBottom:24 }}>
        <h2 style={{ fontFamily:'monospace', fontWeight:700, fontSize:15, color:'#a78bfa', marginBottom:14 }}>📊 Investigation Progress</h2>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:14 }}>
          {[
            { label:'Attack Chain Steps', value:`${state.attackChain.filter(s=>s.completed).length}/${state.attackChain.length}`, pct:chainPct },
            { label:'IOCs Identified', value:`${iocCount} indicators`, pct:Math.min(Math.round((iocCount/7)*100),100) },
            { label:'Containment Actions', value:`${containCount} actions`, pct:Math.min(Math.round((containCount/5)*100),100) },
          ].map(item => (
            <div key={item.label} style={{ padding:'14px 16px', background:'#1e293b', borderRadius:8 }}>
              <div style={{ fontSize:11, fontFamily:'monospace', color:'#475569', marginBottom:6 }}>{item.label}</div>
              <div style={{ fontSize:18, fontWeight:700, fontFamily:'monospace', color:'#e2e8f0', marginBottom:6 }}>{item.value}</div>
              <div style={{ height:4, background:'#0f172a', borderRadius:2, overflow:'hidden' }}>
                <div style={{ width:`${item.pct}%`, height:'100%', background:'#6d28d9', borderRadius:2, transition:'width 0.5s' }}/>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick links */}
      <div style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, padding:'20px 22px' }}>
        <h2 style={{ fontFamily:'monospace', fontWeight:700, fontSize:15, color:'#a78bfa', marginBottom:14 }}>🚀 Investigation Modules</h2>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10 }}>
          {QUICK_LINKS.map(l => (
            <Link key={l.path} to={l.path} style={{ textDecoration:'none' }}>
              <div style={{
                padding:'14px 16px', background:'#1e293b', borderRadius:8,
                border:'1px solid transparent', transition:'all 0.15s', cursor:'pointer',
              }}
                onMouseEnter={e => { e.currentTarget.style.borderColor='#6d28d9'; e.currentTarget.style.background='rgba(109,40,217,0.1)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor='transparent'; e.currentTarget.style.background='#1e293b'; }}
              >
                <div style={{ fontSize:20, marginBottom:6 }}>{l.icon}</div>
                <div style={{ fontFamily:'monospace', fontWeight:700, fontSize:13, color:'#e2e8f0', marginBottom:2 }}>{l.label}</div>
                <div style={{ fontSize:11, color:'#475569' }}>{l.desc}</div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
