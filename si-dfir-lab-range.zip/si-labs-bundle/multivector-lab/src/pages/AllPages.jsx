import React, { useState } from 'react';
import { useLab } from '../context/LabContext';

// ── Impact Assessment ─────────────────────────────────────────────────────────
export function ImpactAssessment() {
  const { state, dispatch } = useLab();
  const ia = state.impactAssessment;
  function update(data) { dispatch({ type:'UPDATE_IMPACT', data }); }

  const REGULATORY = [
    { key:'NDB', label:'Privacy Act 1988 — Notifiable Data Breach', desc:'OAIC notification required. 47,000 customer records with TFN, DOB, account details exfiltrated.' },
    { key:'APRA', label:'APRA CPS 234 — Material Incident Notification', desc:'APRA notification within 72 hours. NovaCorp is an APRA-regulated entity.' },
    { key:'ASD', label:'ASD ReportCyber — Ransomware Report', desc:'Voluntary but strongly recommended. Report via reportcyber.gov.au.' },
  ];

  return (
    <div style={{ padding:'28px 32px', maxWidth:900, margin:'0 auto' }}>
      <h1 style={{ fontFamily:'monospace', fontWeight:800, fontSize:20, color:'#f8fafc', marginBottom:4 }}>⚖️ Impact Assessment</h1>
      <p style={{ fontSize:13, color:'#475569', marginBottom:24 }}>Assess the business and regulatory impact of this incident. Required for the executive brief and regulatory notifications.</p>

      <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
        {/* PII */}
        <div style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, padding:'20px 22px' }}>
          <h3 style={{ fontFamily:'monospace', fontSize:14, color:'#a78bfa', marginBottom:14 }}>Personal Information at Risk</h3>
          <label style={{ display:'flex', alignItems:'center', gap:10, marginBottom:12, cursor:'pointer' }}>
            <input type="checkbox" checked={ia.piiIdentified} onChange={e=>update({piiIdentified:e.target.checked})} style={{ width:16, height:16, accentColor:'#6d28d9' }}/>
            <span style={{ fontFamily:'monospace', fontSize:13, color:'#e2e8f0' }}>I have confirmed that exfiltrated data includes personal information under the Privacy Act 1988</span>
          </label>
          {ia.piiIdentified && (
            <div style={{ padding:'12px 14px', background:'rgba(220,38,38,0.06)', border:'1px solid rgba(220,38,38,0.2)', borderRadius:7, marginBottom:12 }}>
              <div style={{ fontFamily:'monospace', fontSize:12, color:'#fca5a5', lineHeight:1.9 }}>
                <div>✓ CustomerList_2024.xlsx — Full name, DOB, TFN, address, account balance [TIER 4]</div>
                <div>✓ Staff_Payroll_Nov2024.xlsx — Employee TFN, salary, banking details [TIER 4]</div>
                <div>✓ SRV-DB01 export.csv — ~47,000 customer records (name, DOB, TFN, BSB, account) [TIER 4]</div>
              </div>
            </div>
          )}
          <div style={{ marginBottom:8 }}>
            <label style={{ fontSize:11, fontFamily:'monospace', color:'#475569', display:'block', marginBottom:5 }}>ESTIMATED RECORDS AFFECTED</label>
            <input value={ia.recordCount} onChange={e=>update({recordCount:e.target.value})} placeholder="e.g. ~47,000 customer records + 200 staff records" style={{ width:'100%', padding:'8px 10px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13, boxSizing:'border-box', outline:'none' }}/>
          </div>
        </div>

        {/* Regulatory */}
        <div style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, padding:'20px 22px' }}>
          <h3 style={{ fontFamily:'monospace', fontSize:14, color:'#a78bfa', marginBottom:14 }}>Regulatory Obligations</h3>
          {REGULATORY.map(r => {
            const checked = ia.regulatoryObligation?.includes(r.key);
            return (
              <label key={r.key} style={{ display:'flex', alignItems:'flex-start', gap:10, marginBottom:12, cursor:'pointer' }}>
                <input type="checkbox" checked={!!checked} onChange={e=>{
                  const cur=(ia.regulatoryObligation||'').split(',').filter(Boolean);
                  const next=e.target.checked ? [...cur,r.key] : cur.filter(k=>k!==r.key);
                  update({regulatoryObligation:next.join(',')});
                }} style={{ width:16, height:16, accentColor:'#6d28d9', marginTop:2 }}/>
                <div>
                  <div style={{ fontFamily:'monospace', fontSize:13, color:'#e2e8f0', fontWeight:700 }}>{r.label}</div>
                  <div style={{ fontSize:12, color:'#64748b', marginTop:2 }}>{r.desc}</div>
                </div>
              </label>
            );
          })}
        </div>

        {/* Business Impact */}
        <div style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, padding:'20px 22px' }}>
          <h3 style={{ fontFamily:'monospace', fontSize:14, color:'#a78bfa', marginBottom:12 }}>Business Impact Assessment</h3>
          <textarea value={ia.businessImpact} onChange={e=>update({businessImpact:e.target.value})} rows={5}
            placeholder="Describe the business impact:&#10;- Systems affected and operational impact&#10;- Estimated downtime&#10;- Financial exposure (ransom demand, recovery costs, regulatory fines)&#10;- Reputational risk&#10;- Customer notification requirements"
            style={{ width:'100%', padding:'10px 12px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13, resize:'vertical', outline:'none', boxSizing:'border-box' }}/>
        </div>

        {/* Notes */}
        <div style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, padding:'20px 22px' }}>
          <h3 style={{ fontFamily:'monospace', fontSize:14, color:'#a78bfa', marginBottom:12 }}>Additional Notes</h3>
          <textarea value={ia.notes} onChange={e=>update({notes:e.target.value})} rows={3}
            placeholder="Any additional impact observations..."
            style={{ width:'100%', padding:'10px 12px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13, resize:'vertical', outline:'none', boxSizing:'border-box' }}/>
        </div>
      </div>
    </div>
  );
}

// ── Executive Briefing ────────────────────────────────────────────────────────
export function ExecutiveBriefing() {
  const { state, dispatch } = useLab();

  const TEMPLATE = `EXECUTIVE INCIDENT BRIEFING — INC-2024-1114-001
Classification: HIGHLY CONFIDENTIAL — ATTORNEY-CLIENT PRIVILEGED
Date: 2024-11-14 | Organisation: NovaCorp Financial Services Pty Ltd

1. INCIDENT SUMMARY
[Describe what happened in 2-3 plain-language sentences suitable for board-level readers]

2. CONFIRMED ATTACK TIMELINE
01:22 — [Complete the timeline from your investigation]
...

3. SYSTEMS AFFECTED
[List all confirmed compromised hosts]

4. DATA COMPROMISED
[Describe what data was exfiltrated, estimated volume and sensitivity]

5. CURRENT STATUS & CONTAINMENT
[What has been done, what is still in progress]

6. REGULATORY OBLIGATIONS
[Summarise NDB, APRA CPS 234, and ASD reporting requirements]

7. RECOMMENDED IMMEDIATE ACTIONS
[Prioritised list for leadership]

8. RECOVERY ESTIMATE
[Estimated timeline to restore operations]

Prepared by: [Analyst name]
Date/Time: ${new Date().toLocaleString('en-AU')}`;

  return (
    <div style={{ padding:'28px 32px', maxWidth:900, margin:'0 auto' }}>
      <h1 style={{ fontFamily:'monospace', fontWeight:800, fontSize:20, color:'#f8fafc', marginBottom:4 }}>📝 Executive Briefing</h1>
      <p style={{ fontSize:13, color:'#475569', marginBottom:16 }}>
        Prepare an executive-level briefing suitable for board, legal counsel, and law enforcement. Use plain language. Avoid excessive technical jargon.
      </p>
      <div style={{ display:'flex', gap:8, marginBottom:16 }}>
        <button onClick={() => dispatch({type:'SET_EXECUTIVE_BRIEF', text: TEMPLATE})} style={{ padding:'8px 16px', borderRadius:7, background:'transparent', border:'1px solid #6d28d9', color:'#a78bfa', fontFamily:'monospace', fontSize:12, cursor:'pointer' }}>📋 Load Template</button>
        <span style={{ fontSize:12, color:'#334155', fontFamily:'monospace', alignSelf:'center' }}>{state.executiveBrief.length} characters · {Math.ceil(state.executiveBrief.length/1500)} page(s) approx</span>
      </div>
      <textarea
        value={state.executiveBrief}
        onChange={e => dispatch({type:'SET_EXECUTIVE_BRIEF', text: e.target.value})}
        rows={30}
        placeholder="Write your executive briefing here, or load the template above to get started..."
        style={{ width:'100%', padding:'16px 18px', background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, color:'#e2e8f0', fontFamily:'monospace', fontSize:13, resize:'vertical', outline:'none', boxSizing:'border-box', lineHeight:1.8 }}
      />
      {state.executiveBrief.length > 0 && (
        <div style={{ marginTop:12, padding:'10px 14px', background:'rgba(34,197,94,0.06)', border:'1px solid rgba(34,197,94,0.2)', borderRadius:7, fontSize:12, fontFamily:'monospace', color:'#86efac' }}>
          ✓ Briefing saved automatically. Word count: ~{Math.round(state.executiveBrief.split(' ').length)} words.
        </div>
      )}
    </div>
  );
}

// ── Regulatory Notification ───────────────────────────────────────────────────
export function RegulatoryNotification() {
  const { state, dispatch } = useLab();

  const REGS = [
    {
      id:'OAIC', title:'Office of the Australian Information Commissioner (OAIC)', urgency:'REQUIRED',
      deadline:'Assess within 30 days; notify ASAP once eligible breach confirmed',
      trigger:'Unauthorised access to personal information likely to cause serious harm',
      grounds:'47,000 customer records (TFN, DOB, account details) exfiltrated. Serious harm test met.',
      url:'https://www.oaic.gov.au/privacy/notifiable-data-breaches',
      color:'#dc2626',
    },
    {
      id:'APRA', title:'Australian Prudential Regulation Authority (APRA) — CPS 234', urgency:'REQUIRED',
      deadline:'Within 72 hours of becoming aware of a material incident',
      trigger:'Material information security incident at an APRA-regulated entity',
      grounds:'NovaCorp is APRA-regulated. Ransomware + data exfil constitutes material incident.',
      url:'https://www.apra.gov.au',
      color:'#f59e0b',
    },
    {
      id:'ASD', title:'Australian Signals Directorate — ReportCyber', urgency:'RECOMMENDED',
      deadline:'As soon as practicable',
      trigger:'Ransomware or cybercrime affecting Australian organisations',
      grounds:'Ransomware incident with data exfiltration. ASD engagement provides threat intelligence support.',
      url:'https://www.reportcyber.gov.au',
      color:'#3b82f6',
    },
    {
      id:'AFP', title:'Australian Federal Police — Cyber Crime', urgency:'CONSIDER',
      deadline:'No specific deadline',
      trigger:'Criminal activity — ransom demand received',
      grounds:'45 BTC ransom demand. Extortion is a criminal offence. AFP may assist with threat actor identification.',
      url:'https://www.afp.gov.au',
      color:'#8b5cf6',
    },
  ];

  return (
    <div style={{ padding:'28px 32px', maxWidth:900, margin:'0 auto' }}>
      <h1 style={{ fontFamily:'monospace', fontWeight:800, fontSize:20, color:'#f8fafc', marginBottom:4 }}>📋 Regulatory Notification Assessment</h1>
      <p style={{ fontSize:13, color:'#475569', marginBottom:24 }}>
        Assess each regulatory body's notification requirements. Document your determination and rationale.
      </p>
      <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
        {REGS.map(r => (
          <div key={r.id} style={{ background:'#0f172a', border:`1px solid ${r.color}33`, borderRadius:10, overflow:'hidden' }}>
            <div style={{ padding:'14px 20px', background:`${r.color}11`, borderBottom:`1px solid ${r.color}33`, display:'flex', alignItems:'center', gap:12 }}>
              <span style={{ padding:'3px 10px', borderRadius:4, background:r.color, color:'#fff', fontSize:10, fontFamily:'monospace', fontWeight:700 }}>{r.urgency}</span>
              <span style={{ fontFamily:'monospace', fontWeight:700, fontSize:14, color:'#f8fafc' }}>{r.title}</span>
            </div>
            <div style={{ padding:'16px 20px' }}>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:12 }}>
                <div style={{ fontSize:12, fontFamily:'monospace', color:'#64748b', lineHeight:1.7 }}>
                  <span style={{ color:'#475569' }}>Deadline: </span><span style={{ color:'#e2e8f0' }}>{r.deadline}</span><br/>
                  <span style={{ color:'#475569' }}>Trigger: </span><span style={{ color:'#94a3b8' }}>{r.trigger}</span>
                </div>
                <div style={{ fontSize:12, color:'#94a3b8', lineHeight:1.7 }}>
                  <div style={{ color:'#22c55e', fontWeight:700, marginBottom:4, fontFamily:'monospace' }}>APPLICABLE — GROUNDS:</div>
                  {r.grounds}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ marginTop:20 }}>
        <div style={{ fontFamily:'monospace', fontSize:13, color:'#a78bfa', marginBottom:8 }}>NOTIFICATION DETERMINATION NOTES</div>
        <textarea value={state.regulatoryNotes} onChange={e=>dispatch({type:'SET_REGULATORY_NOTES',text:e.target.value})} rows={6}
          placeholder="Document your regulatory notification determination, timelines, and who is responsible for each notification..."
          style={{ width:'100%', padding:'12px 14px', background:'#0f172a', border:'1px solid #1e293b', borderRadius:8, color:'#e2e8f0', fontFamily:'monospace', fontSize:13, resize:'vertical', outline:'none', boxSizing:'border-box' }}/>
      </div>
    </div>
  );
}

// ── Final Report ──────────────────────────────────────────────────────────────
export function FinalReport() {
  const { state, dispatch } = useLab();
  const completed = state.attackChain.filter(s=>s.completed);

  function generateReport() {
    const report = `DIGITAL FORENSICS & INCIDENT RESPONSE — FINAL REPORT
Case ID: INC-2024-1114-001
Organisation: NovaCorp Financial Services Pty Ltd
Classification: HIGHLY CONFIDENTIAL — ATTORNEY-CLIENT PRIVILEGED
Report Date: ${new Date().toLocaleDateString('en-AU',{day:'numeric',month:'long',year:'numeric'})}
Analyst: ${state.analyst||'Lab Learner'}
Score Achieved: ${state.score.total}/100

═══════════════════════════════════════════════════════════
1. EXECUTIVE SUMMARY
═══════════════════════════════════════════════════════════

${state.executiveBrief || '[Complete the Executive Briefing module first]'}

═══════════════════════════════════════════════════════════
2. ATTACK CHAIN RECONSTRUCTION (${completed.length}/${state.attackChain.length} steps confirmed)
═══════════════════════════════════════════════════════════

${completed.map(s=>`[${s.time}] ${s.phase.toUpperCase()} — ${s.event}
  Host: ${s.host} | User: ${s.user}
  Evidence: ${s.evidence}${s.notes ? '\n  Notes: '+s.notes : ''}`).join('\n\n')}

═══════════════════════════════════════════════════════════
3. INDICATORS OF COMPROMISE (${state.iocs.length} identified)
═══════════════════════════════════════════════════════════

${state.iocs.map(i=>`${i.id} | ${i.type} | ${i.value}
  Confidence: ${i.confidence} | Tags: ${Array.isArray(i.tags)?i.tags.join(', '):i.tags}
  Notes: ${i.notes}`).join('\n\n')}

═══════════════════════════════════════════════════════════
4. MISSED HOSTS IDENTIFIED
═══════════════════════════════════════════════════════════

${state.missedHostsIdentified.length ? state.missedHostsIdentified.join(', ') : 'None identified yet'}

═══════════════════════════════════════════════════════════
5. CONTAINMENT ACTIONS (${state.containmentActions.length} recorded)
═══════════════════════════════════════════════════════════

${state.containmentActions.map((a,i)=>`${String(i+1).padStart(2,'0')}. [${a.type}] ${a.action}
   Host: ${a.host}
   Rationale: ${a.rationale}`).join('\n\n')}

═══════════════════════════════════════════════════════════
6. IMPACT & REGULATORY ASSESSMENT
═══════════════════════════════════════════════════════════

PII Identified: ${state.impactAssessment.piiIdentified ? 'YES — 47,000+ records' : 'Not confirmed'}
Records Affected: ${state.impactAssessment.recordCount || 'Not quantified'}
Regulatory Obligations: ${state.impactAssessment.regulatoryObligation || 'Not assessed'}
Business Impact: ${state.impactAssessment.businessImpact || 'Not assessed'}

Regulatory Notes:
${state.regulatoryNotes || 'Not completed'}

═══════════════════════════════════════════════════════════
7. SCORING SUMMARY
═══════════════════════════════════════════════════════════

Attack Chain Reconstruction: ${state.score.attackChain}/30
IOC Identification:          ${state.score.iocId}/20
Missed Host Identification:  ${state.score.missedHosts}/15
Containment Actions:         ${state.score.containment}/15
Impact Assessment:           ${state.score.impact}/10
Executive Communication:     ${state.score.executive}/10
─────────────────────────────
TOTAL SCORE:                 ${state.score.total}/100

Grade: ${state.score.total>=85?'DISTINCTION':state.score.total>=70?'CREDIT':state.score.total>=50?'PASS':'REFER'}

═══════════════════════════════════════════════════════════
END OF REPORT — Security Impossible Pty Ltd
═══════════════════════════════════════════════════════════`;
    dispatch({ type:'SET_FINAL_REPORT', text: report });
  }

  return (
    <div style={{ padding:'28px 32px', maxWidth:1000, margin:'0 auto' }}>
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:20 }}>
        <div>
          <h1 style={{ fontFamily:'monospace', fontWeight:800, fontSize:20, color:'#f8fafc', marginBottom:4 }}>📄 Final Incident Report</h1>
          <p style={{ fontSize:13, color:'#475569' }}>Generate a complete DFIR report for executives, legal counsel, and law enforcement.</p>
        </div>
        <button onClick={generateReport} style={{ padding:'10px 22px', borderRadius:7, background:'#6d28d9', border:'none', color:'#fff', fontFamily:'monospace', fontSize:13, fontWeight:700, cursor:'pointer' }}>⚡ Generate Report</button>
      </div>
      {state.finalReport ? (
        <div style={{ background:'#0a0e1a', border:'1px solid #1e293b', borderRadius:10, padding:'24px', overflowY:'auto', maxHeight:'70vh' }}>
          <pre style={{ fontFamily:'monospace', fontSize:12, color:'#94a3b8', lineHeight:1.8, whiteSpace:'pre-wrap', margin:0 }}>{state.finalReport}</pre>
        </div>
      ) : (
        <div style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, padding:'60px', textAlign:'center', color:'#334155' }}>
          <div style={{ fontSize:48, marginBottom:12 }}>📄</div>
          <div style={{ fontFamily:'monospace', fontSize:14 }}>Complete the investigation modules, then click Generate Report</div>
          <div style={{ fontSize:12, marginTop:8 }}>Current score: {state.score.total}/100</div>
        </div>
      )}
    </div>
  );
}

// ── Scoring ───────────────────────────────────────────────────────────────────
export function Scoring() {
  const { state } = useLab();
  const RUBRIC = [
    { key:'attackChain', label:'Attack Chain Reconstruction', max:30, hint:'Confirm each of the 14 attack steps in the Timeline module' },
    { key:'iocId', label:'IOC Identification', max:20, hint:'Identify all 7 IOCs across IP, domain, hash, file, and user categories' },
    { key:'missedHosts', label:'Missed Host Identification', max:15, hint:'Find WKSTN-112 (s.nguyen) and document WKSTN-089 full scope' },
    { key:'containment', label:'Containment Actions', max:15, hint:'Document at least 5 containment actions with rationale' },
    { key:'impact', label:'Impact & Regulatory Assessment', max:10, hint:'Confirm PII and identify applicable regulatory obligations' },
    { key:'executive', label:'Executive Communication', max:10, hint:'Write a 200+ character executive brief in plain language' },
  ];
  const grade = state.score.total>=85?'DISTINCTION':state.score.total>=70?'CREDIT':state.score.total>=50?'PASS':'REFER';
  const gradeColor = { DISTINCTION:'#22c55e', CREDIT:'#3b82f6', PASS:'#f59e0b', REFER:'#ef4444' }[grade];

  return (
    <div style={{ padding:'28px 32px', maxWidth:800, margin:'0 auto' }}>
      <h1 style={{ fontFamily:'monospace', fontWeight:800, fontSize:20, color:'#f8fafc', marginBottom:4 }}>🏆 Assessment Scoring</h1>
      <p style={{ fontSize:13, color:'#475569', marginBottom:24 }}>Real-time scoring across all assessment criteria.</p>

      <div style={{ textAlign:'center', padding:'30px', background:'#0f172a', border:`1px solid ${gradeColor}44`, borderRadius:12, marginBottom:24 }}>
        <div style={{ fontSize:60, fontWeight:900, fontFamily:'monospace', color:gradeColor }}>{state.score.total}</div>
        <div style={{ fontSize:16, color:'#94a3b8', marginTop:4, fontFamily:'monospace' }}>out of 100 points</div>
        <div style={{ marginTop:12, display:'inline-block', padding:'6px 24px', borderRadius:6, background:gradeColor+'22', border:`1px solid ${gradeColor}`, color:gradeColor, fontFamily:'monospace', fontWeight:700, fontSize:16 }}>{grade}</div>
      </div>

      <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
        {RUBRIC.map(r => {
          const score = state.score[r.key]||0;
          const pct = Math.round((score/r.max)*100);
          return (
            <div key={r.key} style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, padding:'16px 20px' }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
                <div>
                  <div style={{ fontFamily:'monospace', fontWeight:700, fontSize:13, color:'#e2e8f0' }}>{r.label}</div>
                  <div style={{ fontSize:11, color:'#475569', marginTop:2 }}>💡 {r.hint}</div>
                </div>
                <div style={{ fontFamily:'monospace', fontSize:18, fontWeight:800, color: pct===100?'#22c55e':pct>50?'#f59e0b':'#ef4444' }}>
                  {score}/{r.max}
                </div>
              </div>
              <div style={{ height:8, background:'#1e293b', borderRadius:4, overflow:'hidden' }}>
                <div style={{ width:`${pct}%`, height:'100%', background: pct===100?'#22c55e':pct>50?'#f59e0b':'#6d28d9', borderRadius:4, transition:'width 0.5s' }}/>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
