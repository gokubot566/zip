import React, { useState } from 'react';
import { useLab } from '../context/LabContext';
import { EVIDENCE_FILES } from '../data/evidence';

const catColor = { Email:'#3b82f6', EDR:'#ef4444', Network:'#f59e0b', FIM:'#8b5cf6', Notes:'#22c55e', Reference:'#64748b' };

export default function EvidenceRepository() {
  const { state, dispatch } = useLab();
  const [selected, setSelected] = useState(null);
  const [filter, setFilter] = useState('ALL');

  function view(ev) {
    setSelected(ev);
    dispatch({ type:'MARK_EVIDENCE_VIEWED', id: ev.id });
  }

  const cats = ['ALL', ...new Set(EVIDENCE_FILES.map(e => e.category))];
  const filtered = filter === 'ALL' ? EVIDENCE_FILES : EVIDENCE_FILES.filter(e => e.category === filter);

  return (
    <div style={{ padding:'28px 32px', maxWidth:1200, margin:'0 auto', display:'flex', gap:20, height:'calc(100vh - 56px)' }}>
      {/* File list */}
      <div style={{ width:320, flexShrink:0, display:'flex', flexDirection:'column', gap:10 }}>
        <div>
          <h1 style={{ fontFamily:'monospace', fontWeight:800, fontSize:18, color:'#f8fafc', marginBottom:4 }}>🗂️ Evidence Repository</h1>
          <p style={{ fontSize:12, color:'#475569', marginBottom:12 }}>Click a file to view. All evidence is admissible.</p>
          <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:12 }}>
            {cats.map(c => (
              <button key={c} onClick={() => setFilter(c)} style={{
                padding:'3px 10px', borderRadius:20, fontSize:11, fontFamily:'monospace', cursor:'pointer',
                border:`1px solid ${filter===c?'#6d28d9':'#1e293b'}`,
                background: filter===c?'#6d28d9':'transparent',
                color: filter===c?'#fff':'#64748b',
              }}>{c}</button>
            ))}
          </div>
        </div>
        <div style={{ flex:1, overflowY:'auto', display:'flex', flexDirection:'column', gap:8 }}>
          {filtered.map(ev => {
            const viewed = state.evidenceViewed.includes(ev.id);
            const isActive = selected?.id === ev.id;
            return (
              <button key={ev.id} onClick={() => view(ev)} style={{
                textAlign:'left', padding:'12px 14px', borderRadius:8, cursor:'pointer',
                background: isActive?'rgba(109,40,217,0.12)':'#0f172a',
                border:`1px solid ${isActive?'#6d28d9':'#1e293b'}`,
                transition:'all 0.12s',
              }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
                  <span style={{ background:catColor[ev.category]||'#475569', color:'#fff', padding:'1px 7px', borderRadius:3, fontSize:10, fontFamily:'monospace', fontWeight:700 }}>{ev.category}</span>
                  <span style={{ fontFamily:'monospace', fontSize:10, color:'#334155' }}>{ev.id}</span>
                  {viewed && <span style={{ marginLeft:'auto', color:'#22c55e', fontSize:10 }}>✓ viewed</span>}
                </div>
                <div style={{ fontFamily:'monospace', fontSize:12, color:'#e2e8f0', fontWeight:600, marginBottom:2 }}>{ev.name}</div>
                <div style={{ fontSize:11, color:'#475569' }}>{ev.size} · {new Date(ev.timestamp).toLocaleTimeString('en-AU',{hour:'2-digit',minute:'2-digit'})}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Viewer */}
      <div style={{ flex:1, background:'#0a0e1a', border:'1px solid #1e293b', borderRadius:10, overflow:'hidden', display:'flex', flexDirection:'column' }}>
        {selected ? (
          <>
            {/* File header */}
            <div style={{ padding:'14px 20px', background:'#0f172a', borderBottom:'1px solid #1e293b', display:'flex', alignItems:'flex-start', gap:12 }}>
              <div style={{ flex:1 }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
                  <span style={{ background:catColor[selected.category]||'#475569', color:'#fff', padding:'2px 8px', borderRadius:3, fontSize:10, fontFamily:'monospace', fontWeight:700 }}>{selected.category}</span>
                  <span style={{ fontFamily:'monospace', fontSize:11, color:'#6d28d9' }}>{selected.id}</span>
                </div>
                <div style={{ fontFamily:'monospace', fontWeight:700, fontSize:15, color:'#f8fafc' }}>{selected.name}</div>
                <div style={{ fontSize:12, color:'#475569', marginTop:2 }}>{selected.description}</div>
              </div>
              <div style={{ fontSize:11, fontFamily:'monospace', color:'#334155', textAlign:'right', lineHeight:1.9 }}>
                <div>Size: {selected.size}</div>
                <div>TS: {selected.timestamp}</div>
                <div style={{ wordBreak:'break-all', maxWidth:260 }}>SHA256: {selected.hash.substring(0,40)}...</div>
              </div>
            </div>
            {/* Content */}
            <div style={{ flex:1, overflowY:'auto', padding:'16px 20px' }}>
              <pre style={{
                fontFamily:'monospace', fontSize:12, color:'#94a3b8',
                lineHeight:1.7, whiteSpace:'pre-wrap', wordBreak:'break-word', margin:0,
              }}>{selected.content}</pre>
            </div>
          </>
        ) : (
          <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:12, color:'#334155' }}>
            <div style={{ fontSize:48 }}>🗂️</div>
            <div style={{ fontFamily:'monospace', fontSize:14 }}>Select an evidence file to view</div>
            <div style={{ fontSize:12 }}>{state.evidenceViewed.length}/{EVIDENCE_FILES.length} files reviewed</div>
          </div>
        )}
      </div>
    </div>
  );
}
