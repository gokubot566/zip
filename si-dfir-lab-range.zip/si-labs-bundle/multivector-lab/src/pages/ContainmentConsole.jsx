import React, { useState } from 'react';
import { useLab } from '../context/LabContext';

const TEMPLATES = [
  { action:'Network isolation — WKSTN-047', type:'Network', host:'WKSTN-047', rationale:'Primary infection point. Macro execution and C2 beacon confirmed.' },
  { action:'Network isolation — SRV-FILE01', type:'Network', host:'SRV-FILE01', rationale:'Lateral movement target. Bulk file copy and exfiltration origin.' },
  { action:'Network isolation — SRV-DC01', type:'Network', host:'SRV-DC01', rationale:'Domain controller compromised. Scheduled task created by attacker.' },
  { action:'Network isolation — SRV-DB01', type:'Network', host:'SRV-DB01', rationale:'Database server compromised. Customer records exported.' },
  { action:'Network isolation — WKSTN-089', type:'Network', host:'WKSTN-089', rationale:'Secondary phishing victim (m.okafor). Macro execution confirmed.' },
  { action:'Network isolation — WKSTN-112', type:'Network', host:'WKSTN-112', rationale:'MISSED HOST (s.nguyen). C2 beacon confirmed. Not isolated by overnight analyst.' },
  { action:'Disable svc_backup account', type:'Account', host:'SRV-DC01', rationale:'Service account used for lateral movement across FILE01, DC01, DB01.' },
  { action:'Reset Domain Administrator password', type:'Account', host:'SRV-DC01', rationale:'Credentials harvested from WKSTN-047 LSASS dump. All privileged accounts at risk.' },
  { action:'Reset j.thompson password', type:'Account', host:'WKSTN-047', rationale:'Primary victim account. Credentials exposed via LSASS dump.' },
  { action:'Block 185.220.101.93 at perimeter firewall', type:'Firewall', host:'Perimeter', rationale:'Primary C2 and exfiltration IP. TOR exit node.' },
  { action:'Remove SvcHelper32 service from all hosts', type:'Remediation', host:'ALL', rationale:'Reverse shell RAT persisting as Windows service across 5 hosts.' },
  { action:'Remove SvcUpdate scheduled task from SRV-DC01', type:'Remediation', host:'SRV-DC01', rationale:'Persistence mechanism created by attacker on domain controller.' },
  { action:'Preserve forensic images before remediation', type:'Forensic', host:'ALL', rationale:'Legal and regulatory obligation. Required for potential law enforcement referral.' },
  { action:'Notify legal counsel — attorney-client privilege', type:'Legal', host:'N/A', rationale:'Establishes attorney-client privilege over IR communications. Standard practice.' },
  { action:'Notify OAIC — Notifiable Data Breach', type:'Regulatory', host:'N/A', rationale:'47,000 customer records with TFN, DOB, account details exfiltrated. NDB scheme triggered.' },
];

const typeColor = {
  Network:'#3b82f6', Account:'#f59e0b', Firewall:'#ef4444',
  Remediation:'#8b5cf6', Forensic:'#06b6d4', Legal:'#ec4899', Regulatory:'#22c55e',
};

const BLANK = { action:'', type:'Network', host:'', rationale:'' };

export default function ContainmentConsole() {
  const { state, dispatch } = useLab();
  const [form, setForm] = useState(BLANK);
  const [showForm, setShowForm] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);

  function addAction(data) {
    dispatch({ type:'ADD_CONTAINMENT', action: data || form });
    setForm(BLANK); setShowForm(false);
  }

  function addMissedHost(host) {
    dispatch({ type:'ADD_MISSED_HOST', host });
  }

  return (
    <div style={{ padding:'28px 32px', maxWidth:1000, margin:'0 auto' }}>
      <div style={{ marginBottom:20 }}>
        <h1 style={{ fontFamily:'monospace', fontWeight:800, fontSize:20, color:'#f8fafc', marginBottom:4 }}>🛡️ Containment Console</h1>
        <p style={{ fontSize:13, color:'#475569', marginBottom:12 }}>
          Document all containment and remediation actions. Justify each action with evidence. Identify hosts missed by the overnight analyst.
        </p>
        <div style={{ display:'flex', gap:8 }}>
          <button onClick={() => setShowForm(s=>!s)} style={{ padding:'8px 16px', borderRadius:7, background:'#6d28d9', border:'none', color:'#fff', fontFamily:'monospace', fontSize:12, cursor:'pointer', fontWeight:700 }}>+ Custom Action</button>
          <button onClick={() => setShowTemplates(s=>!s)} style={{ padding:'8px 16px', borderRadius:7, background:'transparent', border:'1px solid #6d28d9', color:'#a78bfa', fontFamily:'monospace', fontSize:12, cursor:'pointer' }}>📋 Action Templates</button>
        </div>
      </div>

      {/* Missed hosts */}
      <div style={{ background:'rgba(220,38,38,0.06)', border:'1px solid rgba(220,38,38,0.2)', borderRadius:10, padding:'16px 20px', marginBottom:20 }}>
        <div style={{ fontFamily:'monospace', fontWeight:700, fontSize:13, color:'#fca5a5', marginBottom:8 }}>🔍 Missed Host Identification</div>
        <p style={{ fontSize:12, color:'#64748b', marginBottom:12, fontFamily:'monospace' }}>
          The overnight analyst did not identify all compromised hosts. Review evidence carefully. Score: {state.missedHostsIdentified.length}/2 missed hosts found.
        </p>
        <div style={{ display:'flex', gap:10 }}>
          {['WKSTN-112 (s.nguyen)', 'WKSTN-089 (m.okafor full scope)'].map((h, i) => {
            const host = i === 0 ? 'WKSTN-112' : 'WKSTN-089';
            const found = state.missedHostsIdentified.includes(host);
            return (
              <button key={host} onClick={() => !found && addMissedHost(host)} style={{
                padding:'8px 16px', borderRadius:7, cursor: found?'default':'pointer',
                background: found?'rgba(34,197,94,0.12)':'rgba(220,38,38,0.1)',
                border:`1px solid ${found?'#22c55e':'rgba(220,38,38,0.3)'}`,
                color: found?'#22c55e':'#fca5a5', fontFamily:'monospace', fontSize:12, fontWeight:700,
              }}>
                {found ? '✓ ' : '? '}{h}
              </button>
            );
          })}
        </div>
      </div>

      {/* Templates */}
      {showTemplates && (
        <div style={{ background:'#0f172a', border:'1px solid #334155', borderRadius:10, padding:'16px 18px', marginBottom:20 }}>
          <div style={{ fontFamily:'monospace', fontWeight:700, fontSize:13, color:'#a78bfa', marginBottom:12 }}>Containment Action Templates</div>
          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            {TEMPLATES.map((t, i) => {
              const already = state.containmentActions.some(a => a.action === t.action);
              return (
                <div key={i} style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 12px', background:'#1e293b', borderRadius:7 }}>
                  <span style={{ padding:'2px 8px', borderRadius:3, background:(typeColor[t.type]||'#475569')+'22', color:typeColor[t.type]||'#475569', fontSize:10, fontFamily:'monospace', fontWeight:700, flexShrink:0 }}>{t.type}</span>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:'monospace', fontSize:12, color:'#e2e8f0', marginBottom:2 }}>{t.action}</div>
                    <div style={{ fontSize:11, color:'#475569' }}>{t.rationale}</div>
                  </div>
                  <button onClick={() => !already && addAction(t)} disabled={already} style={{
                    padding:'5px 14px', borderRadius:5, fontFamily:'monospace', fontSize:11, cursor: already?'default':'pointer',
                    background: already?'rgba(34,197,94,0.1)':'#6d28d9', border:'none',
                    color: already?'#22c55e':'#fff', flexShrink:0, fontWeight:700,
                  }}>{already ? '✓ Added' : '+ Add'}</button>
                </div>
              );
            })}
          </div>
          <button onClick={() => setShowTemplates(false)} style={{ marginTop:10, padding:'6px 14px', borderRadius:6, background:'transparent', border:'1px solid #334155', color:'#64748b', fontFamily:'monospace', fontSize:12, cursor:'pointer' }}>Close</button>
        </div>
      )}

      {/* Custom form */}
      {showForm && (
        <div style={{ background:'#0f172a', border:'1px solid #6d28d9', borderRadius:10, padding:'18px 20px', marginBottom:20 }}>
          <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr 1fr', gap:12, marginBottom:12 }}>
            <div><label style={{ fontSize:11, fontFamily:'monospace', color:'#475569', display:'block', marginBottom:5 }}>ACTION</label>
              <input value={form.action} onChange={e=>setForm(f=>({...f,action:e.target.value}))} placeholder="Describe the containment action" style={{ width:'100%', padding:'8px 10px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13, boxSizing:'border-box', outline:'none' }}/>
            </div>
            <div><label style={{ fontSize:11, fontFamily:'monospace', color:'#475569', display:'block', marginBottom:5 }}>TYPE</label>
              <select value={form.type} onChange={e=>setForm(f=>({...f,type:e.target.value}))} style={{ width:'100%', padding:'8px 10px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13 }}>
                {Object.keys(typeColor).map(t=><option key={t}>{t}</option>)}
              </select>
            </div>
            <div><label style={{ fontSize:11, fontFamily:'monospace', color:'#475569', display:'block', marginBottom:5 }}>HOST/SYSTEM</label>
              <input value={form.host} onChange={e=>setForm(f=>({...f,host:e.target.value}))} placeholder="e.g. WKSTN-047" style={{ width:'100%', padding:'8px 10px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13, boxSizing:'border-box', outline:'none' }}/>
            </div>
          </div>
          <div style={{ marginBottom:12 }}>
            <label style={{ fontSize:11, fontFamily:'monospace', color:'#475569', display:'block', marginBottom:5 }}>RATIONALE</label>
            <textarea value={form.rationale} onChange={e=>setForm(f=>({...f,rationale:e.target.value}))} rows={2} placeholder="Justify the action with evidence reference..." style={{ width:'100%', padding:'8px 10px', background:'#1e293b', border:'1px solid #334155', borderRadius:6, color:'#e2e8f0', fontFamily:'monospace', fontSize:13, resize:'vertical', outline:'none', boxSizing:'border-box' }}/>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <button onClick={() => addAction()} style={{ padding:'8px 20px', borderRadius:7, background:'#6d28d9', border:'none', color:'#fff', fontFamily:'monospace', fontSize:13, fontWeight:700, cursor:'pointer' }}>Add Action</button>
            <button onClick={() => setShowForm(false)} style={{ padding:'8px 16px', borderRadius:7, background:'transparent', border:'1px solid #334155', color:'#64748b', fontFamily:'monospace', fontSize:13, cursor:'pointer' }}>Cancel</button>
          </div>
        </div>
      )}

      {/* Actions log */}
      <div style={{ background:'#0f172a', border:'1px solid #1e293b', borderRadius:10, overflow:'hidden' }}>
        <div style={{ padding:'12px 18px', background:'#0a0e1a', borderBottom:'1px solid #1e293b', fontFamily:'monospace', fontSize:12, color:'#475569' }}>
          CONTAINMENT ACTION LOG — {state.containmentActions.length} actions recorded
        </div>
        {state.containmentActions.length === 0 ? (
          <div style={{ padding:'40px', textAlign:'center', color:'#334155', fontFamily:'monospace', fontSize:13 }}>
            No actions logged yet. Add actions above or use templates.
          </div>
        ) : (
          state.containmentActions.map((a, i) => (
            <div key={a.id} style={{ padding:'12px 18px', borderBottom:'1px solid #0f172a', display:'flex', gap:12, alignItems:'flex-start' }}>
              <div style={{ fontFamily:'monospace', fontSize:11, color:'#334155', flexShrink:0, width:24 }}>{String(i+1).padStart(2,'0')}</div>
              <span style={{ padding:'2px 8px', borderRadius:3, background:(typeColor[a.type]||'#475569')+'22', color:typeColor[a.type]||'#475569', fontSize:10, fontFamily:'monospace', fontWeight:700, flexShrink:0 }}>{a.type}</span>
              <div style={{ flex:1 }}>
                <div style={{ fontFamily:'monospace', fontSize:12, color:'#e2e8f0', marginBottom:2 }}>{a.action}</div>
                <div style={{ fontSize:11, color:'#64748b' }}>{a.rationale}</div>
                <div style={{ fontSize:10, color:'#334155', fontFamily:'monospace', marginTop:3 }}>Host: {a.host} · {new Date(a.ts).toLocaleTimeString()}</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
