import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { ATTACK_CHAIN, INITIAL_IOCS, SCORING_RUBRIC } from '../data/evidence';

const LabContext = createContext();

const initialState = {
  caseStatus: 'ACTIVE',
  attackChain: ATTACK_CHAIN.map(e => ({ ...e, completed: false, notes: '' })),
  iocs: INITIAL_IOCS,
  containmentActions: [],
  impactAssessment: { piiIdentified: false, recordCount: '', regulatoryObligation: '', businessImpact: '', notes: '' },
  executiveBrief: '',
  regulatoryNotes: '',
  finalReport: '',
  missedHostsIdentified: [],
  score: { attackChain: 0, iocId: 0, missedHosts: 0, containment: 0, impact: 0, executive: 0, total: 0 },
  timeline: [],
  evidenceViewed: [],
  aiHistory: [],
  startTime: new Date().toISOString(),
};

function reducer(state, action) {
  switch (action.type) {
    case 'TOGGLE_CHAIN_STEP':
      return { ...state, attackChain: state.attackChain.map(s => s.id === action.id ? { ...s, completed: !s.completed } : s) };
    case 'UPDATE_CHAIN_NOTES':
      return { ...state, attackChain: state.attackChain.map(s => s.id === action.id ? { ...s, notes: action.notes } : s) };
    case 'ADD_IOC':
      return { ...state, iocs: [...state.iocs, { ...action.ioc, id: `IOC-${String(state.iocs.length + 1).padStart(3,'0')}` }] };
    case 'REMOVE_IOC':
      return { ...state, iocs: state.iocs.filter(i => i.id !== action.id) };
    case 'ADD_CONTAINMENT':
      return { ...state, containmentActions: [...state.containmentActions, { ...action.action, id: Date.now(), ts: new Date().toISOString() }] };
    case 'UPDATE_IMPACT':
      return { ...state, impactAssessment: { ...state.impactAssessment, ...action.data } };
    case 'SET_EXECUTIVE_BRIEF':
      return { ...state, executiveBrief: action.text };
    case 'SET_REGULATORY_NOTES':
      return { ...state, regulatoryNotes: action.text };
    case 'SET_FINAL_REPORT':
      return { ...state, finalReport: action.text };
    case 'ADD_MISSED_HOST':
      return { ...state, missedHostsIdentified: state.missedHostsIdentified.includes(action.host) ? state.missedHostsIdentified : [...state.missedHostsIdentified, action.host] };
    case 'MARK_EVIDENCE_VIEWED':
      return { ...state, evidenceViewed: state.evidenceViewed.includes(action.id) ? state.evidenceViewed : [...state.evidenceViewed, action.id] };
    case 'ADD_AI_MESSAGE':
      return { ...state, aiHistory: [...state.aiHistory, action.message] };
    case 'CALCULATE_SCORE': {
      const attackChainScore = Math.round((state.attackChain.filter(s => s.completed).length / state.attackChain.length) * SCORING_RUBRIC.attackChain.max);
      const iocScore = Math.min(state.iocs.length >= 7 ? SCORING_RUBRIC.iocId.max : Math.round((state.iocs.length / 7) * SCORING_RUBRIC.iocId.max), SCORING_RUBRIC.iocId.max);
      const missedScore = Math.round((state.missedHostsIdentified.length / 2) * SCORING_RUBRIC.missedHosts.max);
      const containScore = Math.min(Math.round((state.containmentActions.length / 5) * SCORING_RUBRIC.containment.max), SCORING_RUBRIC.containment.max);
      const impactScore = state.impactAssessment.piiIdentified && state.impactAssessment.regulatoryObligation ? SCORING_RUBRIC.impact.max : Math.round(SCORING_RUBRIC.impact.max / 2);
      const execScore = state.executiveBrief.length > 200 ? SCORING_RUBRIC.executive.max : Math.round(SCORING_RUBRIC.executive.max / 2);
      const total = attackChainScore + iocScore + missedScore + containScore + impactScore + execScore;
      return { ...state, score: { attackChain: attackChainScore, iocId: iocScore, missedHosts: missedScore, containment: containScore, impact: impactScore, executive: execScore, total } };
    }
    default: return state;
  }
}

export function LabProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  useEffect(() => { dispatch({ type: 'CALCULATE_SCORE' }); }, [
    state.attackChain, state.iocs, state.missedHostsIdentified,
    state.containmentActions, state.impactAssessment, state.executiveBrief
  ]);
  return <LabContext.Provider value={{ state, dispatch }}>{children}</LabContext.Provider>;
}

export const useLab = () => useContext(LabContext);
