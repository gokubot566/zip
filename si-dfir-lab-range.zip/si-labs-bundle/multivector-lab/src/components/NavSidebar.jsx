import React from 'react';
import { NavLink } from 'react-router-dom';
import { useLab } from '../context/LabContext';

const NAV = [
  { path: '/',           icon: '📊', label: 'Dashboard' },
  { path: '/evidence',   icon: '🗂️', label: 'Evidence Repository' },
  { path: '/timeline',   icon: '⏱️', label: 'Attack Timeline' },
  { path: '/ioc',        icon: '🎯', label: 'IOC Management' },
  { path: '/containment',icon: '🛡️', label: 'Containment Console' },
  { path: '/impact',     icon: '⚖️', label: 'Impact Assessment' },
  { path: '/executive',  icon: '📝', label: 'Executive Briefing' },
  { path: '/regulatory', icon: '📋', label: 'Regulatory Notification' },
  { path: '/report',     icon: '📄', label: 'Final Report' },
  { path: '/scoring',    icon: '🏆', label: 'Scoring' },
];

export default function NavSidebar() {
  const { state } = useLab();
  const pct = Math.round((state.score.total / 100) * 100);

  return (
    <aside style={{
      width: 240, flexShrink: 0,
      background: '#0a0e1a',
      borderRight: '1px solid #1e293b',
      display: 'flex', flexDirection: 'column',
      height: '100vh', position: 'sticky', top: 0,
      overflowY: 'auto',
    }}>
      {/* Logo */}
      <div style={{ padding: '20px 18px 14px', borderBottom: '1px solid #1e293b' }}>
        <div style={{
          fontFamily: 'monospace', fontWeight: 800, fontSize: 13,
          color: '#f8fafc', letterSpacing: '0.05em', lineHeight: 1.3,
        }}>
          <span style={{ color: '#6d28d9' }}>SI</span> DFIR PLATFORM
        </div>
        <div style={{ fontSize: 10, color: '#475569', fontFamily: 'monospace', marginTop: 3 }}>
          INC-2024-1114-001
        </div>
        <div style={{
          marginTop: 8, padding: '4px 8px', borderRadius: 4,
          background: '#dc2626', color: '#fff',
          fontSize: 10, fontFamily: 'monospace', fontWeight: 700,
          display: 'inline-block',
        }}>⚠ CRITICAL — ACTIVE</div>
      </div>

      {/* Score */}
      <div style={{ padding: '12px 18px', borderBottom: '1px solid #1e293b' }}>
        <div style={{ fontSize: 10, color: '#475569', fontFamily: 'monospace', marginBottom: 5 }}>INVESTIGATION SCORE</div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 5 }}>
          <span style={{ fontSize: 26, fontWeight: 800, fontFamily: 'monospace', color: state.score.total >= 80 ? '#22c55e' : state.score.total >= 60 ? '#f59e0b' : '#ef4444' }}>
            {state.score.total}
          </span>
          <span style={{ color: '#475569', fontSize: 12 }}>/100</span>
        </div>
        <div style={{ height: 4, background: '#1e293b', borderRadius: 2, overflow: 'hidden', marginTop: 4 }}>
          <div style={{ width: `${state.score.total}%`, height: '100%', background: 'linear-gradient(90deg,#6d28d9,#4f46e5)', borderRadius: 2, transition: 'width 0.5s' }}/>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '8px 0' }}>
        {NAV.map(item => (
          <NavLink key={item.path} to={item.path} end={item.path === '/'} style={({ isActive }) => ({
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '10px 18px', textDecoration: 'none',
            background: isActive ? 'rgba(109,40,217,0.15)' : 'transparent',
            borderLeft: isActive ? '2px solid #6d28d9' : '2px solid transparent',
            color: isActive ? '#a78bfa' : '#64748b',
            fontSize: 13, fontFamily: 'monospace',
            transition: 'all 0.12s',
          })}
            onMouseEnter={e => { if (!e.currentTarget.style.borderLeftColor.includes('6d28d9')) { e.currentTarget.style.color = '#94a3b8'; e.currentTarget.style.background = 'rgba(255,255,255,0.03)'; } }}
            onMouseLeave={e => { if (!e.currentTarget.style.borderLeftColor.includes('6d28d9')) { e.currentTarget.style.color = '#64748b'; e.currentTarget.style.background = 'transparent'; } }}
          >
            <span style={{ fontSize: 15 }}>{item.icon}</span>
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      {/* Case info */}
      <div style={{ padding: '12px 18px', borderTop: '1px solid #1e293b', fontSize: 10, color: '#334155', fontFamily: 'monospace', lineHeight: 1.8 }}>
        <div>NovaCorp Financial</div>
        <div>2024-11-14 | DFIR-IRIS</div>
        <div style={{ color: '#6d28d9', marginTop: 4 }}>securityimpossible.com</div>
      </div>
    </aside>
  );
}
