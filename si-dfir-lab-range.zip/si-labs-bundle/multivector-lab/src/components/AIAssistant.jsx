import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLab } from '../context/LabContext';

// ── Guided walkthrough: ordered steps that navigate the student through the lab ──
const GUIDE_STEPS = [
  { path: '/',           title: 'Step 1 — Read the Incident Brief',
    body: 'Welcome. You are the lead DFIR analyst for NovaCorp Financial. Overnight, a multi-vector attack hit the network: phishing → macro execution → credential theft → lateral movement → data exfiltration → ransomware.\n\nStart on the Dashboard. Read the incident summary and note the systems flagged. Your job across the next steps: reconstruct the attack, capture IOCs, contain the threat, assess impact, and brief leadership.' },
  { path: '/evidence',   title: 'Step 2 — Review the Evidence Repository',
    body: 'Open the Evidence Repository. Six evidence sources are available: email gateway logs, EDR process logs, FIM logs, network flow logs, authentication logs, and the ransom note.\n\nKey task: identify the 5 recipients of the phishing email and which had the attachment DELIVERED vs BLOCKED. Watch for the host the overnight analyst missed — WKSTN-112 (s.nguyen).' },
  { path: '/timeline',   title: 'Step 3 — Reconstruct the Attack Timeline',
    body: 'Open the Attack Timeline. Trace the process parent-child chain from the EDR logs:\n\nOUTLOOK → EXCEL → cmd → PowerShell (-Enc) → download cradle → svc32.exe → service install → C2 beacon → LSASS dump → lateral movement → DB export → 2.3GB exfil → ransomware.\n\nAdd each event in chronological order. Switch to "Ask" for tiered hints if you get stuck.' },
  { path: '/ioc',        title: 'Step 4 — Capture the 7 IOCs',
    body: 'Open IOC Management. Record 7 indicators:\n\n• 185.220.101.93 (C2 / exfil, TOR exit)\n• 185.220.101.47 (phishing origin)\n• doc-secure-portal.net (phishing domain)\n• Hash of the RAT dropper (svc32.exe)\n• Hash of the CRYPT0 ransomware\n• Invoice_INV8841.xlsm (the lure)\n• svc_backup (compromised account)' },
  { path: '/containment',title: 'Step 5 — Contain the Threat',
    body: 'Open the Containment Console. Containment must cover EVERY compromised system:\n\n1. Network-isolate all 6 affected hosts (WKSTN-047, SRV-FILE01, DC01, DB01, WKSTN-089, and WKSTN-112 — don\'t miss it).\n2. Disable the svc_backup account.\n3. Reset Domain Admin + harvested user passwords.\n4. Remove the SvcHelper32 service and SvcUpdate scheduled task.\n5. Block the C2 IPs at the perimeter.' },
  { path: '/impact',     title: 'Step 6 — Assess the Impact',
    body: 'Open Impact Assessment. Quantify what was lost:\n\n• ~2.3 GB exfiltrated from SRV-FILE01 and SRV-DB01 via SFTP to the C2.\n• ~47,000 customer records (TFN, DOB, account numbers).\n• 5 systems encrypted by CRYPT0 ransomware (double-extortion).\n\nDetermine whether this is a notifiable breach (it is).' },
  { path: '/executive',  title: 'Step 7 — Write the Executive Briefing',
    body: 'Open Executive Briefing. Write a 1-page brief in plain language: what happened, when, what was compromised, current containment status, regulatory obligations, and recommended next steps. Avoid jargon — your audience is legal and the board.' },
  { path: '/regulatory', title: 'Step 8 — Handle Regulatory Notification',
    body: 'Open Regulatory Notification. NovaCorp is APRA-regulated and holds personal information, so:\n\n• OAIC Notifiable Data Breach (NDB) notification IS required.\n• APRA CPS 234 notification within 72 hours.\n• ASD ReportCyber is recommended.\n\nThe ransom demand does NOT remove the notification obligation.' },
  { path: '/report',     title: 'Step 9 — Compile the Final Report',
    body: 'Open Final Report. Bring everything together: timeline, IOCs, containment actions, impact assessment, and regulatory steps. This is the formal record of the incident.' },
  { path: '/scoring',    title: 'Step 10 — Review Your Score',
    body: 'Open the Scoring page to see how completely you handled the incident. Anything you missed is listed so you can go back and finish it. Well done — you have worked a full multi-vector incident end to end.' },
];

const HINT_LIBRARY = {
  general: [
    { level: 1, text: "Start with the email gateway logs — identify who received the phishing email and which recipients had the attachment delivered vs blocked." },
    { level: 2, text: "Cross-reference the email recipients against the EDR logs. Look for EXCEL.EXE spawning cmd.exe — that's your macro execution indicator." },
    { level: 3, text: "INSTRUCTOR: 5 recipients received the phishing email. j.thompson (WKSTN-047), a.chen, m.okafor (WKSTN-089), and s.nguyen (WKSTN-112) had it DELIVERED. r.patel had it BLOCKED. The overnight analyst missed WKSTN-112 (s.nguyen) entirely." },
  ],
  timeline: [
    { level: 1, text: "Build your timeline chronologically. Start with the first event (email delivery) and trace each process parent-child relationship through the EDR logs." },
    { level: 2, text: "PowerShell with -Enc flag indicates Base64-encoded commands — a common obfuscation technique. The encoded string decodes to a reverse shell setup. Follow the process tree: OUTLOOK → EXCEL → cmd → PowerShell → download cradle → reverse shell." },
    { level: 3, text: "INSTRUCTOR: Full chain: 01:22 phishing → 01:47 Excel opens → 01:48 macro spawns cmd → 02:03 PowerShell download cradle → 02:18 certutil downloads svc32.exe → 02:19 service installed → 02:22 C2 beacon → 03:45 LSASS dump → 04:12 lateral to FILE01 → 04:14 lateral to DC01 → 04:15 DB export → 05:42 exfil 2.3GB → 06:45 ransomware." },
  ],
  ioc: [
    { level: 1, text: "IOCs span multiple categories: IP addresses (C2 and phishing origin), domain names, file hashes, filenames, and compromised user accounts. Check all evidence sources." },
    { level: 2, text: "The hash da39a3ee5e6b4b0d3255bfef95601890afd80709 appears on multiple hosts in FIM and EDR logs — this is the reverse shell dropper (svc32.exe / SvcHelper32.exe). 185.220.101.93 is a known TOR exit node used for both C2 beaconing (port 4444) and exfiltration (port 22/SFTP)." },
    { level: 3, text: "INSTRUCTOR: 7 IOCs required: IOC-001 (185.220.101.93 - C2/exfil), IOC-002 (185.220.101.47 - phishing origin), IOC-003 (doc-secure-portal.net - phishing domain), IOC-004 (hash - RAT dropper), IOC-005 (hash - CRYPT0 ransomware), IOC-006 (Invoice_INV8841.xlsm - lure), IOC-007 (svc_backup - compromised account)." },
  ],
  containment: [
    { level: 1, text: "Containment must address all confirmed and suspected compromised systems. Think about network isolation, account disabling, password resets, and persistence mechanism removal." },
    { level: 2, text: "Critical containment actions: (1) Network isolate all 5 confirmed hosts, (2) Disable svc_backup account immediately, (3) Reset all Administrator and harvested credentials, (4) Remove scheduled tasks on DC01, (5) Block C2 IPs at perimeter firewall. Don't forget WKSTN-112!" },
    { level: 3, text: "INSTRUCTOR: Complete containment list: isolate WKSTN-047, SRV-FILE01, SRV-DC01, SRV-DB01, WKSTN-089, WKSTN-112; disable svc_backup; reset Domain Admin, j.thompson, m.okafor, s.nguyen passwords; remove SvcHelper32 service and SvcUpdate scheduled task; block 185.220.101.93 and 185.220.101.47 at perimeter." },
  ],
  privacy: [
    { level: 1, text: "Check the data classification guide. The exfiltrated data from SRV-FILE01 Finance share and SRV-DB01 contains personal information — review whether this triggers the Notifiable Data Breaches scheme." },
    { level: 2, text: "The NDB scheme (Privacy Act 1988, Part IIIC) applies when: (1) unauthorised access/disclosure of personal information occurs AND (2) it's likely to result in serious harm. The exfiltrated data includes ~47,000 customer TFNs, account numbers, and DOBs. This almost certainly meets both tests." },
    { level: 3, text: "INSTRUCTOR: NDB notification IS required. Grounds: unauthorised access (confirmed), personal information (47,000 records including TFN, DOB, account details — all 'sensitive' under APPs), serious harm (financial identity theft, fraud). Also: APRA CPS 234 notification within 72 hours (NovaCorp is APRA-regulated). ASD ReportCyber voluntary but recommended. Ransom demand does NOT change notification obligation." },
  ],
  exfil: [
    { level: 1, text: "Look at the network flow logs — specifically outbound traffic to external IPs. Calculate the total bytes transferred and identify the protocol used." },
    { level: 2, text: "The flow logs show 2,459,648,000 bytes (approximately 2.3 GB) transferred from SRV-FILE01 (10.0.2.10) to 185.220.101.93 via SFTP (port 22) at 05:42:17. The FIM logs show data.7z was created at 05:31 and the Finance share was bulk-copied at 05:30." },
    { level: 3, text: "INSTRUCTOR: Exfil path: robocopy Finance share → C:\\Windows\\Temp\\staging → 7z with password encryption → curl SFTP upload to C2. Duration: 724 seconds (~12 min). Data included CustomerList_2024.xlsx, Staff_Payroll_Nov2024.xlsx, and SRV-DB01 SQL export (export.csv with 47,000 customer records)." },
  ],
  executive: [
    { level: 1, text: "Executive briefings must answer: What happened? When? What was compromised? What are we doing about it? What is the business/regulatory impact? Use plain language — avoid excessive technical jargon." },
    { level: 2, text: "Structure: (1) Incident summary (2-3 sentences), (2) Timeline of key events, (3) Systems affected and data compromised, (4) Current containment status, (5) Regulatory obligations, (6) Recommended next steps, (7) Estimated recovery timeline. Keep it to 1 page. Anticipate questions from legal and the board." },
    { level: 3, text: "INSTRUCTOR: Key exec communication points: ransomware + data theft (double extortion model), 47,000 customer records exfiltrated (TFN/DOB/account details), 5 systems encrypted, mandatory OAIC and APRA notification obligations, ASD engagement recommended, legal privilege over IR communications, 45 BTC ransom demand (do NOT pay without legal advice and law enforcement consultation)." },
  ],
};

const QUICK_QUESTIONS = [
  { label: "Timeline help", key: "timeline" },
  { label: "IOC guidance", key: "ioc" },
  { label: "Containment steps", key: "containment" },
  { label: "Privacy & NDB", key: "privacy" },
  { label: "Exfiltration analysis", key: "exfil" },
  { label: "Executive brief tips", key: "executive" },
];

export default function AIAssistant() {
  const { state, dispatch } = useLab();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState('guide'); // 'guide' | 'ask'
  const [guideIdx, setGuideIdx] = useState(0);
  const [input, setInput] = useState('');
  const [hintLevels, setHintLevels] = useState({});
  const [activeCategory, setActiveCategory] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (open && mode === 'ask') messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [state.aiHistory, open, mode]);

  const guideStep = GUIDE_STEPS[guideIdx];
  function goToStep(idx) {
    const clamped = Math.max(0, Math.min(GUIDE_STEPS.length - 1, idx));
    setGuideIdx(clamped);
    navigate(GUIDE_STEPS[clamped].path);
  }

  function sendMessage(text, category) {
    const msg = { role: 'user', text, ts: new Date().toISOString() };
    dispatch({ type: 'ADD_AI_MESSAGE', message: msg });

    const cat = category || detectCategory(text);
    setActiveCategory(cat);
    const currentLevel = hintLevels[cat] || 1;
    const hints = HINT_LIBRARY[cat] || HINT_LIBRARY.general;
    const hint = hints.find(h => h.level === currentLevel) || hints[0];

    setTimeout(() => {
      dispatch({
        type: 'ADD_AI_MESSAGE',
        message: {
          role: 'assistant',
          text: hint.text,
          category: cat,
          level: currentLevel,
          ts: new Date().toISOString(),
        },
      });
    }, 600);
  }

  function escalateHint() {
    if (!activeCategory) return;
    const max = HINT_LIBRARY[activeCategory]?.length || 1;
    const current = hintLevels[activeCategory] || 1;
    if (current < max) {
      setHintLevels(prev => ({ ...prev, [activeCategory]: current + 1 }));
      const hints = HINT_LIBRARY[activeCategory];
      const nextHint = hints.find(h => h.level === current + 1);
      dispatch({ type: 'ADD_AI_MESSAGE', message: { role: 'user', text: `[Hint escalated to Level ${current + 1}]`, ts: new Date().toISOString() } });
      setTimeout(() => {
        dispatch({ type: 'ADD_AI_MESSAGE', message: { role: 'assistant', text: nextHint.text, category: activeCategory, level: current + 1, ts: new Date().toISOString() } });
      }, 400);
    }
  }

  function detectCategory(text) {
    const t = text.toLowerCase();
    if (t.includes('timeline') || t.includes('chain') || t.includes('sequence')) return 'timeline';
    if (t.includes('ioc') || t.includes('indicator') || t.includes('hash') || t.includes('ip')) return 'ioc';
    if (t.includes('contain') || t.includes('isolat') || t.includes('block')) return 'containment';
    if (t.includes('privacy') || t.includes('oaic') || t.includes('ndb') || t.includes('notif') || t.includes('regul')) return 'privacy';
    if (t.includes('exfil') || t.includes('data') || t.includes('transfer') || t.includes('gb')) return 'exfil';
    if (t.includes('exec') || t.includes('brief') || t.includes('report') || t.includes('board')) return 'executive';
    return 'general';
  }

  function handleSend() {
    if (!input.trim()) return;
    sendMessage(input);
    setInput('');
  }

  const badgeColor = level => level === 3 ? '#dc2626' : level === 2 ? '#f59e0b' : '#6d28d9';
  const badgeLabel = level => level === 3 ? 'INSTRUCTOR' : level === 2 ? 'HINT L2' : 'HINT L1';

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          position: 'fixed', bottom: 28, right: 28, zIndex: 1000,
          width: 64, height: 64, borderRadius: '50%',
          background: 'linear-gradient(135deg,#6d28d9,#4f46e5)',
          border: 'none', cursor: 'pointer',
          boxShadow: '0 4px 20px rgba(109,40,217,0.45)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 26, color: '#fff',
          transition: 'transform 0.2s',
        }}
        onMouseEnter={e => e.currentTarget.style.transform='scale(1.08)'}
        onMouseLeave={e => e.currentTarget.style.transform='scale(1)'}
        title="AI DFIR Assistant"
      >
        <span style={{ fontFamily:'monospace', fontWeight:800, fontSize:20 }}>B</span>
      </button>

      {/* Panel */}
      {open && (
        <div style={{
          position: 'fixed', bottom: 104, right: 28, zIndex: 1000,
          width: 420, height: 560, display: 'flex', flexDirection: 'column',
          background: '#0f172a', borderRadius: 16,
          border: '1px solid #1e293b',
          boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
          overflow: 'hidden',
        }}>
          {/* Header */}
          <div style={{
            padding: '14px 18px', background: 'linear-gradient(135deg,#6d28d9,#4f46e5)',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <div>
              <div style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 14, color: '#fff' }}>BYTE — DFIR Assistant</div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)' }}>Lab 10 · Multi-Vector Attack</div>
            </div>
            <button onClick={() => setOpen(false)} style={{ background: 'transparent', border: 'none', color: '#fff', fontSize: 18, cursor: 'pointer' }}>✕</button>
          </div>

          {/* Mode tabs */}
          <div style={{ display: 'flex', background: '#1e293b', borderBottom: '1px solid #334155' }}>
            {[['guide','Guided Steps'],['ask','Ask Byte']].map(([m,label]) => (
              <button key={m} onClick={() => setMode(m)} style={{
                flex: 1, padding: '10px', border: 'none', cursor: 'pointer',
                background: mode === m ? '#0f172a' : 'transparent',
                color: mode === m ? '#a78bfa' : '#64748b',
                fontFamily: 'monospace', fontSize: 12, fontWeight: 700,
                borderBottom: mode === m ? '2px solid #6d28d9' : '2px solid transparent',
              }}>{label}</button>
            ))}
          </div>

          {mode === 'guide' ? (
            <>
              {/* Progress */}
              <div style={{ padding: '10px 16px 6px', background: '#0f172a' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, fontFamily: 'monospace', color: '#64748b', marginBottom: 6 }}>
                  <span>Step {guideIdx + 1} of {GUIDE_STEPS.length}</span>
                  <span style={{ color: '#a78bfa' }}>{Math.round(((guideIdx + 1) / GUIDE_STEPS.length) * 100)}%</span>
                </div>
                <div style={{ height: 4, background: '#1e293b', borderRadius: 2, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${((guideIdx + 1) / GUIDE_STEPS.length) * 100}%`, background: 'linear-gradient(90deg,#6d28d9,#4f46e5)', transition: 'width .3s' }} />
                </div>
              </div>

              {/* Step content */}
              <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px' }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: '#f8fafc', marginBottom: 10, fontFamily: 'monospace' }}>{guideStep.title}</div>
                {guideStep.body.split('\n\n').map((para, i) => (
                  <p key={i} style={{ fontSize: 13, color: '#cbd5e1', lineHeight: 1.65, marginBottom: 10, whiteSpace: 'pre-wrap' }}>{para}</p>
                ))}
                <button onClick={() => navigate(guideStep.path)} style={{
                  marginTop: 4, padding: '8px 14px', borderRadius: 8, cursor: 'pointer',
                  background: 'rgba(109,40,217,0.15)', border: '1px solid #6d28d9', color: '#a78bfa',
                  fontSize: 12, fontFamily: 'monospace', fontWeight: 600,
                }}>↳ Open this page</button>
              </div>

              {/* Guide nav */}
              <div style={{ padding: '10px 14px', background: '#0f172a', borderTop: '1px solid #1e293b', display: 'flex', gap: 8, alignItems: 'center' }}>
                <button onClick={() => goToStep(guideIdx - 1)} disabled={guideIdx === 0} style={{
                  padding: '8px 14px', borderRadius: 8, cursor: guideIdx === 0 ? 'default' : 'pointer',
                  background: 'transparent', border: '1px solid #334155', color: '#94a3b8',
                  fontSize: 12, fontFamily: 'monospace', opacity: guideIdx === 0 ? 0.4 : 1,
                }}>← Back</button>
                <div style={{ flex: 1 }} />
                <button onClick={() => goToStep(guideIdx + 1)} disabled={guideIdx === GUIDE_STEPS.length - 1} style={{
                  padding: '8px 16px', borderRadius: 8, cursor: guideIdx === GUIDE_STEPS.length - 1 ? 'default' : 'pointer',
                  background: '#4f46e5', border: 'none', color: '#fff',
                  fontSize: 12, fontFamily: 'monospace', fontWeight: 600, opacity: guideIdx === GUIDE_STEPS.length - 1 ? 0.4 : 1,
                }}>Next Step →</button>
              </div>
            </>
          ) : (
          <>
          {/* Quick questions */}
          <div style={{ padding: '10px 12px', background: '#1e293b', borderBottom: '1px solid #334155', display: 'flex', flexWrap: 'wrap', gap: 5 }}>
            {QUICK_QUESTIONS.map(q => (
              <button key={q.key} onClick={() => sendMessage(q.label, q.key)} style={{
                padding: '4px 10px', borderRadius: 20, border: '1px solid #4f46e5',
                background: 'transparent', color: '#a78bfa', fontSize: 11, cursor: 'pointer',
                fontFamily: 'monospace', transition: 'all 0.15s',
              }}
                onMouseEnter={e => { e.currentTarget.style.background = '#4f46e5'; e.currentTarget.style.color = '#fff'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#a78bfa'; }}
              >{q.label}</button>
            ))}
          </div>

          {/* Messages */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 10 }}>
            {state.aiHistory.length === 0 && (
              <div style={{ textAlign: 'center', color: '#475569', fontSize: 13, marginTop: 40 }}>
                Ask me about the investigation, or click a quick question above. For a full walkthrough, use the <b style={{color:'#a78bfa'}}>Guided Steps</b> tab.
              </div>
            )}
            {state.aiHistory.map((msg, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
                <div style={{
                  maxWidth: '85%', padding: '10px 13px', borderRadius: 10,
                  background: msg.role === 'user' ? '#4f46e5' : '#1e293b',
                  border: msg.role === 'assistant' ? '1px solid #334155' : 'none',
                  fontSize: 13, color: '#e2e8f0', lineHeight: 1.6,
                }}>
                  {msg.role === 'assistant' && msg.level && (
                    <div style={{ marginBottom: 6 }}>
                      <span style={{
                        fontSize: 10, fontWeight: 700, fontFamily: 'monospace',
                        background: badgeColor(msg.level), color: '#fff',
                        padding: '2px 7px', borderRadius: 4,
                      }}>{badgeLabel(msg.level)}</span>
                    </div>
                  )}
                  {msg.text}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef}/>
          </div>

          {/* Escalate hint */}
          {activeCategory && (hintLevels[activeCategory] || 1) < 3 && (
            <div style={{ padding: '6px 14px', background: '#1e293b', borderTop: '1px solid #334155' }}>
              <button onClick={escalateHint} style={{
                width: '100%', padding: '7px', borderRadius: 7,
                background: 'transparent', border: '1px solid #f59e0b',
                color: '#fbbf24', fontSize: 12, cursor: 'pointer', fontFamily: 'monospace',
              }}>
                Need more detail? Get next hint level
              </button>
            </div>
          )}

          {/* Input */}
          <div style={{ padding: '10px 12px', background: '#0f172a', borderTop: '1px solid #1e293b', display: 'flex', gap: 8 }}>
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSend()}
              placeholder="Ask about the investigation..."
              style={{
                flex: 1, padding: '9px 12px', borderRadius: 8,
                background: '#1e293b', border: '1px solid #334155',
                color: '#e2e8f0', fontSize: 13, fontFamily: 'monospace', outline: 'none',
              }}
            />
            <button onClick={handleSend} style={{
              padding: '9px 16px', borderRadius: 8,
              background: '#4f46e5', border: 'none', color: '#fff',
              fontSize: 13, cursor: 'pointer', fontWeight: 600,
            }}>→</button>
          </div>
          </>
          )}
        </div>
      )}
    </>
  );
}
