import { useState, useEffect, useRef } from "react";

// ─── BYTE DFIR LAB — 13 guided steps ─────────────────────────────────────────
const BYTE_STEPS = [
  {
    id: 1, title: "Welcome to Lab 10", nav: null,
    content: `<p>I'm <b>Byte</b> — your DFIR training guide for Lab 10. 👋</p>
<p>You are <b>Jordan Hayes, SOC Analyst II</b>. An EDR alert has fired on workstation <b>ubuntu-ws-047</b> belonging to finance analyst James Hartley. Malware is actively communicating with a C2 server right now.</p>
<p>Your rule: <b>collect evidence before you touch anything.</b> Work through 4 phases: Alert Triage → Volatile Evidence → Malware Artefacts → Containment.</p>`,
    action: null,
  },
  {
    id: 2, title: "Phase 1 — Read the SIEM Alerts", nav: "alerts",
    content: `<p>Open <b>Security Alerts</b>. Six alerts document what EDR detected on ubuntu-ws-047.</p>
<p>Focus on <b>ALT-001</b> and <b>ALT-002</b> — these confirm active C2 communication on ports 4444 (reverse shell) and 443 (data exfiltration) right now.</p>
<p><b>Do not contain yet.</b> The machine is still running. Every process, connection, and session is live evidence you'll destroy the moment you isolate it.</p>`,
    action: "Expand each alert — read the detail and MITRE ATT&CK technique",
  },
  {
    id: 3, title: "Acknowledge the Critical Alerts", nav: "alerts",
    content: `<p>Click <b>Acknowledge</b> on the three most critical alerts: ALT-001, ALT-002, and ALT-003. Each earns +25 XP and marks them as reviewed in your incident record.</p>
<p>Acknowledging an alert in a SIEM means you've taken responsibility for investigating it. Unacknowledged alerts in a live incident are a chain-of-custody problem — they suggest the SOC didn't see the threat in time.</p>`,
    action: "Click Acknowledge on ALT-001, ALT-002, ALT-003 (+25 XP each)",
  },
  {
    id: 4, title: "The Order of Volatility", nav: "terminal",
    content: `<p>Open the <b>Terminal</b>. Before running any command, understand the evidence order rule:</p>
<p><b>RFC 3227</b> says collect from most ephemeral to most persistent:<br/>
1. Running processes (lost when killed)<br/>
2. Network connections (change constantly)<br/>
3. Login sessions (may disconnect)<br/>
4. ARP cache (refreshes frequently)<br/>
5. Routing table<br/>
6. File system / disk (most persistent)</p>
<p>Always collect volatile data first. Disk evidence waits. Evidence that's gone is gone forever.</p>`,
    action: null,
  },
  {
    id: 5, title: "Record System Time First", nav: "terminal",
    content: `<p><b>RFC 3227 Rule 1:</b> always capture the system clock before anything else. This anchors every subsequent evidence item to a verified point on the timeline.</p>
<p>Type <code>date</code> then immediately <code>save evidence-01-timestamp.txt</code>.</p>
<p>The <code>save</code> command auto-generates a SHA-256 hash and logs the entry to your Evidence Log (+50 XP per unique save).</p>`,
    action: "Run: date → save evidence-01-timestamp.txt",
  },
  {
    id: 6, title: "Capture Running Processes", nav: "terminal",
    content: `<p>Run <code>ps aux</code>. Look for anything suspicious — especially processes running from <b>/tmp</b> or hidden directories. World-writable directories are never valid homes for system daemons.</p>
<p>Suspicious lines highlight red automatically. Save immediately after: <code>save evidence-02-processes.txt</code></p>
<p>Key tells: executable in /tmp, name mimicking a real daemon (syslogd, cron), elevated CPU from an unknown process.</p>`,
    action: "Run: ps aux → save evidence-02-processes.txt",
  },
  {
    id: 7, title: "Capture Network Connections", nav: "terminal",
    content: `<p>Run <code>ss -tulpn</code> then <code>lsof -i</code>. You're hunting ESTABLISHED connections to external IPs owned by non-browser processes.</p>
<p>Note the <b>Send-Q column</b> in ss output — bytes queued for transmission prove active exfiltration is in progress, not just a stale connection.</p>
<p>Save: <code>save evidence-03-network.txt</code> and <code>save evidence-04-lsof.txt</code></p>`,
    action: "Run: ss -tulpn → save evidence-03-network.txt",
  },
  {
    id: 8, title: "Capture User Sessions", nav: "terminal",
    content: `<p>Run <code>who</code> then <code>w</code>. Look for tmux or screen sessions — attackers use these to maintain persistent shells that survive SSH disconnection.</p>
<p>The <code>w</code> command shows system load average. Elevated load on a finance workstation at 02:00 UTC is a strong anomaly indicator.</p>
<p>Save: <code>save evidence-05-sessions.txt</code></p>`,
    action: "Run: who → w → save evidence-05-sessions.txt",
  },
  {
    id: 9, title: "Capture Layer 2 & Routing", nav: "terminal",
    content: `<p>Run <code>arp -a</code> — this shows hosts contacted at Layer 2 recently. Extra entries beyond your default gateway and subnet suggest lateral movement reconnaissance.</p>
<p>Then <code>ip route</code> to verify no attacker-injected static routes exist. Sophisticated malware sometimes poisons routing to intercept traffic.</p>
<p>Save: <code>save evidence-06-layer2.txt</code></p>`,
    action: "Run: arp -a → ip route → save evidence-06-layer2.txt",
  },
  {
    id: 10, title: "Investigate Malware Artefacts", nav: "terminal",
    content: `<p>Now collect non-volatile evidence. Run <code>ls -la /tmp/.cache</code> to examine the malware directory. Note the timestamp — it should match the SIEM alert time exactly.</p>
<p>Then document persistence: <code>crontab -l</code> for the user-level mechanism, then <code>cat /etc/cron.hourly/sys-update</code> for the system-level one.</p>
<p>Two persistence mechanisms mean killing the process alone won't stop it — it will restart within 5 minutes.</p>`,
    action: "Run: ls -la /tmp/.cache → crontab -l → cat /etc/cron.hourly/sys-update",
  },
  {
    id: 11, title: "Hash the Malware Binary", nav: "terminal",
    content: `<p>Run <code>sha256sum /tmp/.cache/syslogd-helper</code>. This SHA-256 hash is your <b>primary IOC</b> — it uniquely identifies this exact binary.</p>
<p>Submit this hash to VirusTotal or your threat intel platform to identify the malware family, associated campaigns, and other victims.</p>
<p>If the binary is deleted or the host is reimaged, this hash is the only remaining proof of what the malware was. Save it: <code>save evidence-09-malware-hash.txt</code></p>`,
    action: "Run: sha256sum /tmp/.cache/syslogd-helper → save evidence-09-malware-hash.txt",
  },
  {
    id: 12, title: "Review Your Evidence Chain", nav: "evidence",
    content: `<p>Open the <b>Evidence Log</b>. Every saved file appears here with its timestamp, command, filename, and SHA-256 hash marked <b style="color:var(--green)">✓ HASH OK</b>.</p>
<p>Verify the chain before containment: every item must have a hash, every item must be in the correct chronological order, and timestamps must match the date output from Step 5.</p>
<p>A chain of custody with a gap can be challenged in legal proceedings. Don't proceed until you're satisfied.</p>`,
    action: "Open Evidence Log — verify every item has SHA-256 HASH OK",
  },
  {
    id: 13, title: "Phase 4 — Contain the Host", nav: "terminal",
    content: `<p>Return to the <b>Terminal</b> and type <code>contain</code>. The platform checks that all required evidence items are collected before allowing isolation.</p>
<p>If evidence is missing, the command will list what's still needed. Collect it first — containment without evidence is a critical IR failure.</p>
<p>Once complete: the C2 connections are severed, PIDs 1887 and 1889 are killed, and the crontab persistence entry is removed. Host isolated. Incident contained. +200 XP.</p>`,
    action: "Run: contain (requires all evidence collected)",
  },
];

const NAV_MAP = {
  alerts: "ALERTS", terminal: "TERMINAL", processes: "PROCESSES",
  network: "NETWORK", evidence: "EVIDENCE",
};

export default function ByteAssistant({ activePage, onNavigate }) {
  const [open,    setOpen]    = useState(false);
  const [stepIdx, setStepIdx] = useState(0);
  const [typing,  setTyping]  = useState(false);
  const [html,    setHtml]    = useState("");
  const [skipped, setSkipped] = useState(false);
  const [edge,    setEdge]    = useState("right");
  const [vRatio,  setVRatio]  = useState(0.76);
  const [panelW,  setPanelW]  = useState(400);
  const [panelH,  setPanelH]  = useState(480);

  const wRef     = useRef(null);
  const bodyRef  = useRef(null);
  const dragging = useRef(false);
  const dragOff  = useRef({ x: 0, y: 0 });
  const resizing = useRef(null);
  const resStart = useRef({});
  const typTimer = useRef(null);

  const step  = BYTE_STEPS[stepIdx];
  const total = BYTE_STEPS.length;
  const prog  = ((stepIdx + 1) / total) * 100;
  const isLast = stepIdx === total - 1;
  const panelLeft = edge === "left";
  const moduleLabel = step.nav ? NAV_MAP[step.nav] || "LAB" : "LAB";

  // Auto-open after 1.2s
  useEffect(() => {
    const t = setTimeout(() => setOpen(true), 1200);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => { if (open) snap(true); }, [open]);

  // Typing animation
  useEffect(() => {
    if (!open) return;
    setTyping(true); setHtml("");
    clearTimeout(typTimer.current);
    typTimer.current = setTimeout(() => {
      setTyping(false);
      setHtml(step.content);
      if (bodyRef.current) bodyRef.current.scrollTop = 0;
    }, 480);
    return () => clearTimeout(typTimer.current);
  }, [stepIdx, open]);

  // ── Snap to edge ──────────────────────────────────────────────────────────
  function snap(animate, forceEdge) {
    const w = wRef.current; if (!w) return;
    const e = forceEdge || edge;
    if (forceEdge) setEdge(forceEdge);
    const vw = window.innerWidth, vh = window.innerHeight;
    const LAUNCHER = 52, GAP = 12;
    const tl = e === "left" ? GAP : vw - LAUNCHER - GAP;
    const tt = Math.max(8, Math.min(vRatio * vh, vh - LAUNCHER - 8));
    w.style.transition = animate ? "left .28s ease, top .28s ease" : "none";
    w.style.left = tl + "px";
    w.style.top  = tt + "px";
    w.style.right = "auto";
    w.style.bottom = "auto";
    setTimeout(() => { if (w) w.style.transition = "none"; }, 320);
  }

  // Resize handler
  useEffect(() => {
    const fn = () => { snap(false); const maxW=Math.max(280,window.innerWidth-48); const maxH=Math.max(220,window.innerHeight-120); setPanelW(w=>Math.min(w,maxW)); setPanelH(h=>Math.min(h,maxH)); };
    window.addEventListener("resize", fn);
    return () => window.removeEventListener("resize", fn);
  });

  // Drag
  useEffect(() => {
    const mm = e => {
      if (!dragging.current || !wRef.current) return;
      wRef.current.style.transition = "none";
      wRef.current.style.left = (e.clientX - dragOff.current.x) + "px";
      wRef.current.style.top  = (e.clientY - dragOff.current.y) + "px";
      setVRatio((e.clientY - dragOff.current.y) / window.innerHeight);
    };
    const mu = () => {
      if (!dragging.current) return;
      dragging.current = false;
      document.body.style.cursor = "";
      const w = wRef.current; if (!w) return;
      const r = w.getBoundingClientRect();
      const ne = r.left + 26 < window.innerWidth / 2 ? "left" : "right";
      setVRatio(r.top / window.innerHeight);
      setEdge(ne);
      snap(true, ne);
    };
    window.addEventListener("mousemove", mm);
    window.addEventListener("mouseup", mu);
    return () => { window.removeEventListener("mousemove", mm); window.removeEventListener("mouseup", mu); };
  });

  // Resize
  useEffect(() => {
    const mm = e => {
      if (!resizing.current) return;
      const { sw, sh, sx, sy, type } = resStart.current;
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (type === "side" || type === "corner") {
        setPanelW(edge === "right"
          ? Math.max(280, Math.min(window.innerWidth - 48, sw - dx))
          : Math.max(280, Math.min(window.innerWidth - 48, sw + dx)));
      }
      if (type === "corner") {
        setPanelH(Math.max(220, Math.min(window.innerHeight - 48, sh + dy)));
      }
    };
    const mu = () => { resizing.current = null; document.body.style.cursor = ""; };
    window.addEventListener("mousemove", mm);
    window.addEventListener("mouseup", mu);
    return () => { window.removeEventListener("mousemove", mm); window.removeEventListener("mouseup", mu); };
  });

  function startDrag(e) {
    if (e.target.closest(".byte-close-dfir") || e.target.closest(".brs-dfir") || e.target.closest(".brc-dfir")) return;
    e.preventDefault();
    const r = wRef.current.getBoundingClientRect();
    dragOff.current = { x: e.clientX - r.left, y: e.clientY - r.top };
    dragging.current = true;
    document.body.style.cursor = "grabbing";
  }

  function startResize(e, type) {
    e.stopPropagation(); e.preventDefault();
    resizing.current = type;
    resStart.current = { sw: panelW, sh: panelH, sx: e.clientX, sy: e.clientY, type };
    document.body.style.cursor = type === "side" ? "ew-resize" : "nwse-resize";
  }

  function goNext() {
    if (stepIdx >= total - 1) return;
    const next = BYTE_STEPS[stepIdx + 1];
    if (next.nav && next.nav !== activePage) onNavigate(next.nav);
    setStepIdx(i => i + 1);
  }

  function goPrev() {
    if (stepIdx <= 0) return;
    const prev = BYTE_STEPS[stepIdx - 1];
    if (prev.nav && prev.nav !== activePage) onNavigate(prev.nav);
    setStepIdx(i => i - 1);
  }

  if (skipped) return null;

  const CSS = `
    /* ── Byte DFIR ── */
    .byte-panel-dfir {
      position: absolute;
      background: var(--surface);
      border: 1px solid rgba(56,139,253,.25);
      border-radius: 10px;
      box-shadow: 0 24px 64px rgba(0,0,0,.85), 0 0 0 1px rgba(56,139,253,.08);
      display: flex; flex-direction: column; overflow: hidden;
      animation: byteSlideIn .22s cubic-bezier(.16,1,.3,1);
    }
    @keyframes byteSlideIn {
      from { opacity: 0; transform: translateY(8px) scale(.97); }
      to   { opacity: 1; transform: translateY(0)  scale(1); }
    }
    .byte-head-dfir {
      display: flex; align-items: center; gap: 8px;
      padding: 10px 14px;
      border-bottom: 1px solid var(--border);
      background: var(--surface2);
      cursor: grab; user-select: none; flex-shrink: 0;
    }
    .byte-head-dfir:active { cursor: grabbing; }
    .byte-avatar-dfir {
      width: 24px; height: 24px; border-radius: 6px;
      background: rgba(56,139,253,.15);
      border: 1px solid rgba(56,139,253,.3);
      display: flex; align-items: center; justify-content: center;
      font-size: 13px; flex-shrink: 0;
    }
    .byte-body-dfir {
      flex: 1; overflow-y: auto; padding: 13px 14px;
      font-size: 12px; color: var(--t2); line-height: 1.8;
    }
    .byte-body-dfir p { margin-bottom: 8px; }
    .byte-body-dfir b { color: var(--t1); font-weight: 600; }
    .byte-body-dfir code {
      font-family: var(--mono); font-size: 10.5px;
      background: var(--surface3); padding: 1px 5px;
      border-radius: 3px; color: var(--cyan);
    }
    .byte-action-dfir {
      margin: 0 12px 10px;
      padding: 8px 11px;
      background: rgba(210,153,34,.07);
      border: 1px solid rgba(210,153,34,.22);
      border-radius: 6px; font-size: 11px;
      color: var(--orange); line-height: 1.5; flex-shrink: 0;
    }
    .byte-foot-dfir {
      display: flex; align-items: center; gap: 6px;
      padding: 9px 12px;
      border-top: 1px solid var(--border);
      background: var(--surface2); flex-shrink: 0;
    }
    .byte-foot-dfir.foot-left { flex-direction: row-reverse; }
    .byte-prog-dfir {
      height: 2px; background: var(--border); border-radius: 1px;
      overflow: hidden; margin: 0 14px 0; flex-shrink: 0;
    }
    .byte-step-title-dfir {
      font-size: 12px; font-weight: 700; color: var(--blue);
      margin-bottom: 8px; font-family: var(--mono);
      display: flex; align-items: center; gap: 7px;
    }
    .byte-num-dfir {
      font-size: 9px; padding: 1px 7px; border-radius: 10px;
      background: rgba(56,139,253,.1); border: 1px solid rgba(56,139,253,.2);
      color: var(--blue); font-family: var(--mono); font-weight: 800;
    }
    .byte-nav-hint-dfir {
      font-size: 10px; color: var(--blue); font-family: var(--mono);
      background: var(--blue-dim); border: 1px solid rgba(56,139,253,.15);
      border-radius: 4px; padding: 3px 8px;
      margin-bottom: 8px; display: inline-block;
    }
    .byte-launcher-dfir {
      width: 52px; height: 52px; border-radius: 50%;
      background: var(--surface2);
      border: 1.5px solid rgba(56,139,253,.45);
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      box-shadow: 0 4px 20px rgba(0,0,0,.55), 0 0 0 4px rgba(56,139,253,.06);
      transition: all .2s; position: absolute; bottom: 0; right: 0;
    }
    .byte-launcher-dfir:hover {
      border-color: var(--blue);
      box-shadow: 0 4px 24px rgba(0,0,0,.6), 0 0 0 7px rgba(56,139,253,.12);
    }
    .byte-badge-dfir {
      position: absolute; top: -3px; right: -3px;
      min-width: 17px; height: 17px; border-radius: 9px;
      background: var(--red); color: #fff;
      font-size: 9px; font-weight: 800;
      display: flex; align-items: center; justify-content: center;
      font-family: var(--mono); padding: 0 3px;
      border: 1.5px solid var(--bg);
    }
    .byte-online-dfir {
      width: 7px; height: 7px; border-radius: 50%;
      background: var(--green); flex-shrink: 0;
      animation: pulse 2s ease-in-out infinite;
    }
    .byte-typing-dfir {
      display: flex; gap: 4px; padding: 4px 0;
    }
    .byte-typing-dfir span {
      width: 6px; height: 6px; border-radius: 50%;
      background: rgba(56,139,253,.4);
    }
    .byte-typing-dfir span:nth-child(1) { animation: pulse 1.2s 0s   ease-in-out infinite; }
    .byte-typing-dfir span:nth-child(2) { animation: pulse 1.2s .2s  ease-in-out infinite; }
    .byte-typing-dfir span:nth-child(3) { animation: pulse 1.2s .4s  ease-in-out infinite; }
  `;

  return (
    <>
      <style>{CSS}</style>
      {/* Fixed-position anchor: 52×52 launcher */}
      <div ref={wRef} style={{ position: "fixed", width: 52, height: 52, zIndex: 9500 }}>

        {/* Pop-out panel */}
        {open && (
          <div
            className="byte-panel-dfir"
            style={{
              width: panelW,
              height: panelH,
              bottom: 52,
              [panelLeft ? "left" : "right"]: 0,
            }}
          >
            {/* ── Resize: side handle ── */}
            <div
              className="brs-dfir"
              style={{
                position: "absolute",
                top: "50%", transform: "translateY(-50%)",
                width: 5, height: 44, borderRadius: 3,
                background: "rgba(56,139,253,.18)",
                cursor: "ew-resize",
                [panelLeft ? "right" : "left"]: -7,
              }}
              onMouseDown={e => startResize(e, "side")}
            />
            {/* ── Resize: corner handle ── */}
            <div
              className="brc-dfir"
              style={{
                position: "absolute",
                width: 13, height: 13, borderRadius: 3,
                background: "rgba(56,139,253,.14)",
                cursor: "nwse-resize",
                bottom: -6,
                [panelLeft ? "right" : "left"]: -6,
              }}
              onMouseDown={e => startResize(e, "corner")}
            />

            {/* ── Header ── */}
            <div className="byte-head-dfir" onMouseDown={startDrag}>
              <div className="byte-avatar-dfir">🤖</div>
              <span style={{
                flex: 1, fontFamily: "var(--mono)", fontSize: 11,
                fontWeight: 700, color: "var(--t1)",
              }}>
                Byte — DFIR Lab
              </span>
              <span className="byte-online-dfir" />
              <button
                className="byte-close-dfir"
                onClick={() => setOpen(false)}
                style={{
                  background: "transparent", border: "none",
                  color: "var(--t3)", fontSize: 16, cursor: "pointer",
                  padding: "0 2px", marginLeft: 4, lineHeight: 1,
                }}
              >–</button>
            </div>

            {/* ── Progress ── */}
            <div style={{
              padding: "7px 14px 5px",
              borderBottom: "1px solid var(--border)",
              flexShrink: 0,
            }}>
              <div style={{
                display: "flex", justifyContent: "space-between",
                marginBottom: 4, fontSize: 10, color: "var(--t3)",
                fontFamily: "var(--mono)",
              }}>
                <span>Step {stepIdx + 1} / {total}</span>
                <span style={{
                  background: "var(--blue-dim)", color: "var(--blue)",
                  border: "1px solid rgba(56,139,253,.2)",
                  padding: "0 7px", borderRadius: 10, fontSize: 9,
                }}>{moduleLabel}</span>
              </div>
              <div className="byte-prog-dfir">
                <div style={{
                  height: "100%", width: prog + "%",
                  background: "linear-gradient(90deg,var(--blue),var(--green))",
                  transition: "width .4s ease-out",
                }} />
              </div>
            </div>

            {/* ── Body ── */}
            <div className="byte-body-dfir" ref={bodyRef}>
              {step.nav && step.nav !== activePage && (
                <div className="byte-nav-hint-dfir">
                  → Navigate to: <b style={{ color: "var(--blue)" }}>{step.nav.toUpperCase()}</b>
                </div>
              )}
              {isLast && (
                <div style={{
                  display: "inline-flex", alignItems: "center", gap: 6,
                  background: "rgba(63,185,80,.08)", border: "1px solid rgba(63,185,80,.22)",
                  borderRadius: 20, padding: "3px 12px", marginBottom: 10,
                  fontSize: 10, fontWeight: 700, color: "var(--green)",
                  fontFamily: "var(--mono)",
                }}>✓ LAB COMPLETE</div>
              )}
              <div className="byte-step-title-dfir">
                <span className="byte-num-dfir">{String(stepIdx + 1).padStart(2, "0")}</span>
                {step.title}
              </div>
              {typing ? (
                <div className="byte-typing-dfir">
                  <span /><span /><span />
                </div>
              ) : (
                <div dangerouslySetInnerHTML={{ __html: html }} />
              )}
            </div>

            {/* ── Action banner ── */}
            {step.action && !typing && (
              <div className="byte-action-dfir">
                ⚡ {step.action}
              </div>
            )}

            {/* ── Footer ── */}
            <div className={`byte-foot-dfir${panelLeft ? " foot-left" : ""}`}>
              <button
                onClick={() => setSkipped(true)}
                style={{
                  background: "transparent", border: "none",
                  color: "var(--t3)", fontSize: 10,
                  cursor: "pointer", padding: "2px 4px",
                }}
              >Skip tutorial</button>
              <div style={{ flex: 1 }} />
              <button
                className="btn btn-ghost"
                style={{ padding: "5px 11px", fontSize: 11 }}
                onClick={goPrev}
                disabled={stepIdx === 0}
              >← Back</button>
              <button
                className={`btn ${isLast ? "btn-green" : "btn-primary"}`}
                style={{ padding: "5px 14px", fontSize: 11 }}
                onClick={isLast ? () => setSkipped(true) : goNext}
              >{isLast ? "Finish ✓" : "Next →"}</button>
            </div>
          </div>
        )}

        {/* ── Launcher circle ── */}
        <div
          className="byte-launcher-dfir"
          onClick={() => setOpen(v => !v)}
        >
          {open
            ? <span style={{ fontSize: 20, color: "var(--blue)", fontWeight: 300, lineHeight: 1 }}>×</span>
            : <span style={{ fontSize: 22 }}>🤖</span>
          }
          {!open && <span className="byte-badge-dfir">{stepIdx + 1}</span>}
        </div>
      </div>
    </>
  );
}
