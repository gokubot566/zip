import { useState, useEffect } from "react";
import { INCIDENT, TIMELINE_EVENTS } from "../data/incident.js";
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip, BarChart, Bar, Cell } from "recharts";

function AnimatedNumber({ target, duration = 1200, prefix = "", suffix = "", decimals = 0 }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let start = 0, startTime = null;
    function step(ts) {
      if (!startTime) startTime = ts;
      const progress = Math.min((ts - startTime) / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      setVal(+(start + (target - start) * ease).toFixed(decimals));
      if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }, [target]);
  return <span>{prefix}{typeof val === "number" ? val.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals }) : val}{suffix}</span>;
}

const PHASE_DATA = [
  { phase: "Initial", events: 1, t: "09:44" },
  { phase: "Exec", events: 4, t: "02:11" },
  { phase: "Lateral", events: 2, t: "02:13" },
  { phase: "Impact", events: 2, t: "02:14" },
  { phase: "Detect", events: 2, t: "02:19" },
  { phase: "Contain", events: 3, t: "02:44" },
  { phase: "Recovery", events: 5, t: "06:00" },
  { phase: "Closure", events: 1, t: "20:32" },
];

const TIMELINE_SPREAD = [
  { time: "02:09", files: 0, severity: 0 },
  { time: "02:11", files: 0, severity: 90 },
  { time: "02:13", files: 0, severity: 95 },
  { time: "02:14", files: 20000, severity: 100 },
  { time: "02:15", files: 50000, severity: 100 },
  { time: "02:18", files: 84721, severity: 100 },
  { time: "02:19", files: 84721, severity: 80 },
  { time: "02:44", files: 84721, severity: 50 },
  { time: "06:00", files: 84721, severity: 30 },
  { time: "20:32", files: 0, severity: 0 },
];

const FAILURES = TIMELINE_EVENTS.filter(e => e.flags.includes("RESPONSE_FAILURE"));

const KPI_CARDS = [
  { label: "Affected Systems",    value: INCIDENT.affectedSystems, suffix: "", color: "var(--red)",    icon: "🖥",  sub: "23 endpoints / servers", def: "Total hosts (workstations and servers) impacted by the incident." },
  { label: "Files Encrypted",     value: INCIDENT.encryptedFiles,  suffix: "", color: "var(--amber)",  icon: "🔐",  sub: "Across 14 SMB shares", def: "Number of files encrypted by the ransomware across all network shares." },
  { label: "Business Downtime",   value: INCIDENT.downtimeHours,   suffix: "h", color: "var(--amber)", icon: "⏱",  sub: "18.4 hours total", decimals: 1, def: "Total time business operations were disrupted by the incident." },
  { label: "Financial Impact",    value: 2340, prefix: "$", suffix: "K",  color: "var(--red)",    icon: "💰",  sub: "Estimated total cost", def: "Estimated total cost: downtime, recovery, data loss, and regulatory exposure." },
  { label: "MTTD",  full: "Mean Time to Detect",  value: INCIDENT.mttd, suffix: "m",   color: "var(--green)",  icon: "🔍",  sub: "Detection speed", decimals: 1, def: "Mean Time to Detect — how long from the attacker's first action until the security team detected the incident. Lower is better." },
  { label: "MTTC",  full: "Mean Time to Contain", value: INCIDENT.mttc, suffix: "m",   color: "var(--amber)",  icon: "🛡",  sub: "Containment lag", decimals: 1, def: "Mean Time to Contain — how long from detection until the threat was isolated/contained. Here, encryption finished before containment arrived." },
  { label: "MTTR",  full: "Mean Time to Recover", value: INCIDENT.mttr, suffix: "m",   color: "var(--red)",    icon: "🔧",  sub: "Full recovery time", decimals: 0, def: "Mean Time to Recover — total time from detection until systems were fully restored to normal operation." },
  { label: "Response Failures",   value: FAILURES.length,           suffix: "",  color: "var(--red)",    icon: "⚠",  sub: "Critical process gaps", def: "Number of deliberate process gaps (RESPONSE FAILURE events) flagged in the timeline for analysis." },
];

export default function Overview({ addXP }) {
  const [hovered, setHovered] = useState(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => { const t = setTimeout(() => setVisible(true), 100); return () => clearTimeout(t); }, []);
  useEffect(() => { if (visible) addXP && addXP(10, "Viewed overview"); }, [visible]);

  return (
    <div style={{ padding: "20px 24px", maxWidth: 1200, margin: "0 auto" }}>
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:6 }}>
          <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--t4)", letterSpacing:".12em", textTransform:"uppercase" }}>Post-Incident Review Dashboard</span>
          <div style={{ flex:1, height:1, background:"var(--line)" }} />
          <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--t3)" }}>INC-2026-0447 · CLOSED</span>
        </div>
        <h1 style={{ fontSize:22, fontWeight:800, color:"var(--t1)", letterSpacing:".01em", lineHeight:1.2 }}>
          BlackMatter Ransomware — Meridian Financial
        </h1>
        <p style={{ fontSize:12, color:"var(--t3)", marginTop:4 }}>
          2026-11-14 · Duration: 18h 23m · Family: BlackMatter Pro v4.2 · Analyst: Alex Rivera
        </p>
      </div>

      {/* Live ticker */}
      <div style={{ background:"var(--s2)", border:"1px solid var(--line)", borderRadius:6, padding:"6px 14px", marginBottom:16, overflow:"hidden" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <span style={{ fontSize:9, fontWeight:700, color:"var(--red)", fontFamily:"var(--mono)", letterSpacing:".1em", flexShrink:0 }}>● LIVE</span>
          <div className="ticker-wrap">
            <div className="ticker-inner">
              {[...TIMELINE_EVENTS, ...TIMELINE_EVENTS].map((e, i) => (
                <span key={i} style={{ fontSize:10, color:"var(--t3)", fontFamily:"var(--mono)", marginRight:60, whiteSpace:"nowrap" }}>
                  ›› {e.time.split("T")[1]?.slice(0,5)} · {e.phase.toUpperCase()} · {e.title}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* KPI Grid */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:10, marginBottom:16 }}>
        {KPI_CARDS.map((card, i) => (
          <div key={card.label} className="card" style={{
            padding:"14px 16px",
            borderLeft:`2px solid ${card.color}`,
            animation:`fadeIn .3s ${i*.06}s both`,
            cursor:"help",
            position:"relative",
            transition:"transform .15s, box-shadow .15s, border-color .15s",
          }}
          onMouseEnter={e => { setHovered(card.label); e.currentTarget.style.transform="translateY(-3px)"; e.currentTarget.style.boxShadow=`0 8px 28px rgba(0,0,0,.5)`; e.currentTarget.style.borderLeftColor=card.color; }}
          onMouseLeave={e => { setHovered(null); e.currentTarget.style.transform="translateY(0)"; e.currentTarget.style.boxShadow="none"; }}
          >
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
              <span style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", letterSpacing:".08em" }}>{card.label}</span>
              <span style={{ fontSize:18 }}>{card.icon}</span>
            </div>
            <div style={{ fontSize:26, fontWeight:800, color:card.color, fontFamily:"var(--mono)", lineHeight:1 }}>
              {visible ? <AnimatedNumber target={card.value} prefix={card.prefix||""} suffix={card.suffix||""} decimals={card.decimals||0} /> : "—"}
            </div>
            <div style={{ fontSize:10, color:"var(--t3)", marginTop:4 }}>{card.full || card.sub}</div>
            {hovered === card.label && card.def && (
              <div style={{
                position:"absolute", top:"calc(100% + 8px)", left:0, right:0, zIndex:50,
                background:"#0e1620", border:`1px solid ${card.color}`, borderRadius:8,
                padding:"10px 12px", boxShadow:"0 8px 28px rgba(0,0,0,.6)",
                fontSize:11, color:"var(--t2)", lineHeight:1.6,
                animation:"fadeIn .12s both",
              }}>
                <div style={{ fontSize:10, fontWeight:700, color:card.color, marginBottom:4, fontFamily:"var(--mono)" }}>{card.full || card.label}</div>
                {card.def}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:16 }}>
        {/* Attack progression */}
        <div className="card">
          <div className="card-head">
            <span style={{ fontSize:11, fontWeight:600, color:"var(--t2)" }}>Attack Progression — Files Encrypted</span>
          </div>
          <div style={{ padding:"12px 8px 8px" }}>
            <ResponsiveContainer width="100%" height={160}>
              <AreaChart data={TIMELINE_SPREAD}>
                <defs>
                  <linearGradient id="fileGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ff3d57" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#ff3d57" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" tick={{ fontSize:9, fill:"#4a6a88", fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize:9, fill:"#4a6a88", fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} tickFormatter={v => v > 0 ? `${(v/1000).toFixed(0)}K` : "0"} />
                <Tooltip contentStyle={{ background:"#0e1620", border:"1px solid #1a2535", borderRadius:6, fontSize:10, fontFamily:"JetBrains Mono" }} />
                <Area type="monotone" dataKey="files" stroke="#ff3d57" fill="url(#fileGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Phase distribution */}
        <div className="card">
          <div className="card-head">
            <span style={{ fontSize:11, fontWeight:600, color:"var(--t2)" }}>Events by Attack Phase</span>
          </div>
          <div style={{ padding:"12px 8px 8px" }}>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={PHASE_DATA} barSize={18}>
                <XAxis dataKey="phase" tick={{ fontSize:9, fill:"#4a6a88", fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize:9, fill:"#4a6a88", fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background:"#0e1620", border:"1px solid #1a2535", borderRadius:6, fontSize:10, fontFamily:"JetBrains Mono" }} />
                <Bar dataKey="events" radius={[3,3,0,0]}>
                  {PHASE_DATA.map((e, i) => (
                    <Cell key={i} fill={["#ff3d57","#ff3d57","#ff3d57","#ff3d57","#00e676","#ffb830","#60a5fa","#00e5ff"][i] || "#4a6a88"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Response failures callout */}
      <div className="card" style={{ marginBottom:16, borderColor:"rgba(255,61,87,.3)" }}>
        <div className="card-head" style={{ background:"rgba(255,61,87,.08)" }}>
          <span style={{ fontSize:11, fontWeight:700, color:"var(--red)" }}>⚠ Critical Response Failures Identified ({FAILURES.length})</span>
          <span style={{ marginLeft:"auto", fontSize:10, color:"var(--t3)" }}>These represent deliberate process gaps for analysis</span>
        </div>
        <div style={{ padding:14, display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:10 }}>
          {FAILURES.map((f, i) => (
            <div key={f.id} style={{
              background:"rgba(255,61,87,.06)", border:"1px solid rgba(255,61,87,.2)",
              borderRadius:7, padding:"10px 12px",
              animation:`fadeIn .3s ${i*.08}s both`,
            }}>
              <div style={{ display:"flex", gap:6, alignItems:"center", marginBottom:5 }}>
                <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--red)", background:"rgba(255,61,87,.15)", padding:"1px 7px", borderRadius:3, fontWeight:700, textTransform:"uppercase" }}>FAILURE</span>
                <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--t4)" }}>{f.time.split("T")[1]?.slice(0,5)} UTC</span>
              </div>
              <div style={{ fontSize:12, fontWeight:600, color:"var(--t1)", marginBottom:3 }}>{f.title}</div>
              <div style={{ fontSize:10, color:"var(--t3)", lineHeight:1.5 }}>{f.notes?.slice(0,100)}...</div>
            </div>
          ))}
        </div>
      </div>

      {/* Executive summary */}
      <div className="card">
        <div className="card-head">
          <span style={{ fontSize:11, fontWeight:600, color:"var(--t2)" }}>Executive Summary</span>
          <div style={{ marginLeft:"auto", display:"flex", gap:6 }}>
            <span style={{ fontSize:9, padding:"2px 8px", borderRadius:10, background:"var(--red-dim)", color:"var(--red)", fontFamily:"var(--mono)", border:"1px solid rgba(255,61,87,.3)" }}>SEVERITY: P1 CRITICAL</span>
            <span style={{ fontSize:9, padding:"2px 8px", borderRadius:10, background:"var(--green-dim)", color:"var(--green)", fontFamily:"var(--mono)", border:"1px solid rgba(0,230,118,.3)" }}>STATUS: CLOSED</span>
          </div>
        </div>
        <div style={{ padding:16 }}>
          <p style={{ fontSize:13, color:"var(--t2)", lineHeight:1.85, marginBottom:12 }}>
            On <strong style={{ color:"var(--amber)" }}>14 November 2026 at 02:11 UTC</strong>, user <strong style={{ color:"var(--t1)" }}>sarah.chen</strong> executed a phishing attachment (<code style={{ fontFamily:"var(--mono)", fontSize:11, background:"var(--s3)", padding:"1px 5px", borderRadius:3 }}>Invoice_Q4_2026.exe</code>) on workstation WKSTN-SC-04. The payload — identified as <strong style={{ color:"var(--red)" }}>BlackMatter Pro v4.2</strong> — escalated privileges via CVE-2021-34527, laterally moved to FILESVR-01 using an over-privileged service account, and encrypted <strong style={{ color:"var(--red)" }}>84,721 files across 14 SMB shares</strong> in under 5 minutes.
          </p>
          <p style={{ fontSize:13, color:"var(--t2)", lineHeight:1.85, marginBottom:12 }}>
            The SOC detected the attack via FIM alerts within <strong style={{ color:"var(--green)" }}>9.3 minutes</strong> — however, network containment was delayed <strong style={{ color:"var(--red)" }}>25 minutes</strong> by approval chain governance gaps, executive notification occurred <strong style={{ color:"var(--red)" }}>56 minutes</strong> late, the primary forensic workstation was <strong style={{ color:"var(--red)" }}>reimaged before evidence preservation</strong>, and a <strong style={{ color:"var(--red)" }}>4-day silent backup failure</strong> for the Compliance share resulted in permanent data loss.
          </p>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:10, marginTop:16 }}>
            {[
              { label:"Total Recovery Time", value:"18h 23m", color:"var(--red)" },
              { label:"Estimated Financial Impact", value:"$2.34M", color:"var(--amber)" },
              { label:"Data Loss", value:"Compliance share (4d)", color:"var(--red)" },
              { label:"Response Maturity Score", value:"6.2 / 10", color:"var(--amber)" },
              { label:"Process Failures Identified", value:"6 critical", color:"var(--red)" },
              { label:"Recommendations Generated", value:"6 actions", color:"var(--cyan)" },
            ].map(s => (
              <div key={s.label} style={{ background:"var(--s3)", borderRadius:6, padding:"10px 12px", border:"1px solid var(--line)" }}>
                <div style={{ fontSize:9, color:"var(--t4)", fontFamily:"var(--mono)", textTransform:"uppercase", letterSpacing:".08em", marginBottom:4 }}>{s.label}</div>
                <div style={{ fontSize:15, fontWeight:700, color:s.color, fontFamily:"var(--mono)" }}>{s.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
