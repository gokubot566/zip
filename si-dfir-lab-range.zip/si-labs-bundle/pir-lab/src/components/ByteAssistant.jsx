import { useState, useEffect, useRef, useCallback } from "react";

// ─── BYTE PIR LAB — 13 guided steps ─────────────────────────────────────────
const BYTE_STEPS = [
  {
    id: 1, title: "Welcome to Lab 9", nav: null,
    content: `<p>I'm <b>Byte</b> — your IR training guide for Lab 9. 👋</p>
<p>You are <b>Alex Rivera, IR Analyst II</b>. A ransomware attack against Meridian Financial Services has already been investigated. Your job now is the <b>Post-Incident Review</b> — understanding what happened, what failed, and how to prevent recurrence.</p>
<p>Work through <b>8 modules</b>: Overview → Timeline → Metrics → Evidence → Gap Analysis → Recommendations → Final Report → Assessment. I'll guide every step.</p>`,
    action: null,
  },
  {
    id: 2, title: "Read the Overview Dashboard", nav: "overview",
    content: `<p>The <b>Overview</b> dashboard shows all top-level incident data for INC-2026-0447.</p>
<p>Study the <b>8 KPI cards</b>: encrypted files, downtime hours, financial impact, and the three IR metrics (MTTD, MTTC, MTTR).</p>
<p>Note the <b>8 response failures</b> highlighted in red — these are the deliberate process gaps you'll analyse in depth throughout the lab.</p>`,
    action: "Hover over each KPI card and review the Response Failures panel",
  },
  {
    id: 3, title: "Explore the Incident Timeline", nav: "timeline",
    content: `<p>Open the <b>Incident Timeline</b>. 19 events reconstruct the full kill chain from phishing delivery to incident closure.</p>
<p>Events flagged <b style="color:#ff3d57">⚠ RESPONSE FAILURE</b> are the 8 critical process gaps. Expand each one — they contain the analyst notes you'll need for gap analysis.</p>
<p>Use the <b>Failures Only</b> filter to focus on the 8 critical gaps quickly.</p>`,
    action: "Click 'Failures Only' filter — expand all 8 RESPONSE FAILURE events",
  },
  {
    id: 4, title: "Identify the 8 Response Failures", nav: "timeline",
    content: `<p>The 8 response failures you must understand for this lab are:</p>
<p><b>T02</b> — 8-min escalation gap at shift handover<br/>
<b>T04</b> — VSS deletion not alerted in real-time<br/>
<b>T06</b> — CVE-2021-34527 unpatched 47 days<br/>
<b>T11</b> — Malware sample NOT preserved (reimaged first)<br/>
<b>T12</b> — 25-minute containment delay (approval chain)<br/>
<b>T13</b> — Management notification 56 minutes late<br/>
<b>T14</b> — Recovery began before full eradication confirmed<br/>
<b>T18</b> — Compliance share: 4-day silent backup failure</p>
<p>These will form the backbone of your Gap Analysis and Recommendations.</p>`,
    action: null,
  },
  {
    id: 5, title: "Calculate IR Metrics", nav: "metrics",
    content: `<p>Open <b>Metrics Center</b>. Four IR metrics need to be calculated from the incident timestamps.</p>
<p>For each metric, you are given <b>T0</b> and <b>T1</b> timestamps. Calculate the difference in minutes (or hours) and enter your answer.</p>
<p><b>Key insight:</b> MTTD was excellent (9.3m) but MTTC was 25 minutes — meaning the encryption completed before containment arrived. This is the central lesson of this incident.</p>`,
    action: "Calculate all 4 metrics — use the Hint button if you get stuck",
  },
  {
    id: 6, title: "Review Forensic Evidence", nav: "evidence",
    content: `<p>Open the <b>Evidence Vault</b>. 8 forensic artifacts are collected from the incident.</p>
<p>Pay special attention to <b>EV-006</b> — the Forensics Gap Report. This documents the permanent loss of the original malware sample and memory artifacts because WKSTN-SC-04 was reimaged before the DFIR team could acquire evidence.</p>
<p>Click each artifact to read the full file contents.</p>`,
    action: "Open EV-006 (Forensics Gap) and EV-007 (Ransom Note) — read both carefully",
  },
  {
    id: 7, title: "Complete Gap Analysis", nav: "gaps",
    content: `<p>Open <b>Gap Analysis</b>. You'll classify 11 actions from the incident into <b>Worked Well</b> or <b>Needs Improvement</b>.</p>
<p>5 things genuinely worked well (FIM detection speed, threat intel match, Finance/HR backup recovery, Incident Commander response, password reset scope).</p>
<p>6 things need improvement — these are the response failures you identified in the timeline.</p>`,
    action: "Classify all 11 items — then click Submit Gap Analysis",
  },
  {
    id: 8, title: "Build Recommendations", nav: "recommendations",
    content: `<p>Open the <b>Recommendations Engine</b>. 6 pre-loaded recommendations address each process failure.</p>
<p>Review the CRITICAL-priority recommendations first — especially <b>R1</b> (DFIR evidence gate) and <b>R2</b> (backup monitoring). These address the two most damaging failures.</p>
<p>You can also <b>add your own recommendation</b> using the + button — this earns +75 XP.</p>`,
    action: "Read all 6 recommendations — add at least one of your own (+75 XP)",
  },
  {
    id: 9, title: "Generate the PIR Report", nav: "report",
    content: `<p>Open <b>Final Report</b>. This is the Post-Incident Review document you'd submit to leadership.</p>
<p>The report contains: Executive Summary, Metrics Table, Operational Strengths (5 items), Process Failures (6 items), Recommendations, and a <b>Response Maturity Score of 6.2/10</b>.</p>
<p>Click <b>Generate Report</b> to finalise it and earn +150 XP. The print button then allows PDF export.</p>`,
    action: "Click 'Generate & Finalise Report' (+150 XP)",
  },
  {
    id: 10, title: "Take the Assessment — Q1 & Q2", nav: "assessment",
    content: `<p>Open <b>Assessment Hub</b>. 5 questions test your understanding of the PIR.</p>
<p><b>Q1</b> tests your understanding of why reimaging WKSTN-SC-04 was a critical failure.</p>
<p><b>Q2</b> tests your knowledge of acceptable MTTC for active ransomware — the answer is under 15 minutes, based on how fast BlackMatter encrypted 84,721 files.</p>`,
    action: "Answer Q1 and Q2 — 10 pts each",
  },
  {
    id: 11, title: "Assessment — Q3 & Q4", nav: "assessment",
    content: `<p><b>Q3</b> asks about the security principle violated by the over-privileged <code>svc_backup</code> service account — the answer is Principle of Least Privilege.</p>
<p><b>Q4</b> asks about the type of security control failure represented by the silent 4-day backup monitoring gap — this is a <b>detective control failure</b>.</p>`,
    action: "Answer Q3 and Q4 — 10 pts each",
  },
  {
    id: 12, title: "Assessment — Q5 (Written Response)", nav: "assessment",
    content: `<p><b>Q5</b> is the written response — the most important question in the lab.</p>
<p>You must write a 3-4 sentence executive summary explaining this incident to the CISO <b>without blaming individuals</b>. Focus on process failures, quantify the business impact, and state the single most important recommendation.</p>
<p>Use <b>blameless language</b>: "a process gap allowed..." rather than "sarah.chen caused..."</p>`,
    action: "Write your Q5 executive summary — at least 30 characters to submit",
  },
  {
    id: 13, title: "Lab Complete! 🎉", nav: null,
    content: `<p>You've completed Lab 9: Post-Incident Review &amp; Lessons Learned!</p>
<p><b>Skills practised:</b><br/>
✅ IR timeline reconstruction<br/>
✅ MTTD / MTTC / MTTR calculation<br/>
✅ Forensic evidence gap analysis<br/>
✅ Gap classification (worked/needs improvement)<br/>
✅ Recommendations engine<br/>
✅ Blameless PIR writing<br/>
✅ Executive communication</p>
<p>Review your XP total and achievements in the top navigation bar.</p>`,
    action: null,
  },
];

const NAV_MAP = {
  overview: "OVERVIEW", timeline: "TIMELINE", metrics: "METRICS",
  evidence: "EVIDENCE", gaps: "GAPS", recommendations: "RECS",
  report: "REPORT", assessment: "ASSESSMENT",
};

export default function ByteAssistant({ activePage, onNavigate }) {
  const [open,      setOpen]    = useState(false);
  const [stepIdx,   setStepIdx] = useState(0);
  const [typing,    setTyping]  = useState(false);
  const [html,      setHtml]    = useState("");
  const [skipped,   setSkipped] = useState(false);
  const [edge,      setEdge]    = useState("right");
  const [vRatio,    setVRatio]  = useState(0.72);
  const [panelW,    setPanelW]  = useState(380);
  const [panelH,    setPanelH]  = useState(460);

  const wRef      = useRef(null);
  const bodyRef   = useRef(null);
  const dragging  = useRef(false);
  const dragOff   = useRef({ x: 0, y: 0 });
  const resizing  = useRef(null);
  const resStart  = useRef({});
  const typTimer  = useRef(null);

  const step  = BYTE_STEPS[stepIdx];
  const total = BYTE_STEPS.length;
  const prog  = ((stepIdx + 1) / total) * 100;

  // Auto-open after 1.5s
  useEffect(() => {
    const t = setTimeout(() => setOpen(true), 1500);
    return () => clearTimeout(t);
  }, []);

  // Snap on open
  useEffect(() => { if (open) snap(true); }, [open]);

  // Typing animation on step change
  useEffect(() => {
    if (!open) return;
    setTyping(true); setHtml("");
    clearTimeout(typTimer.current);
    typTimer.current = setTimeout(() => {
      setTyping(false);
      setHtml(step.content);
      if (bodyRef.current) bodyRef.current.scrollTop = 0;
    }, 500);
    return () => clearTimeout(typTimer.current);
  }, [stepIdx, open]);

  // ── Snap to edge ──────────────────────────────────────────────────────────
  function snap(animate, forceEdge) {
    const w = wRef.current; if (!w) return;
    const e = forceEdge || edge;
    if (forceEdge) setEdge(forceEdge);
    const vw = window.innerWidth, vh = window.innerHeight;
    const tl = e === "left" ? 12 : vw - 50 - 12;
    const tt = Math.max(8, Math.min(vRatio * vh, vh - 50 - 8));
    w.style.transition = animate ? "left .28s ease, top .28s ease" : "none";
    w.style.left = tl + "px";
    w.style.top  = tt + "px";
    setTimeout(() => { if (w) w.style.transition = "none"; }, 300);
  }

  useEffect(() => {
    const fn = () => snap(false);
    window.addEventListener("resize", fn);
    return () => window.removeEventListener("resize", fn);
  });

  // ── Drag ──────────────────────────────────────────────────────────────────
  useEffect(() => {
    const mm = e => {
      if (!dragging.current || !wRef.current) return;
      wRef.current.style.transition = "none";
      wRef.current.style.left = (e.clientX - dragOff.current.x) + "px";
      wRef.current.style.top  = (e.clientY - dragOff.current.y) + "px";
      setVRatio((e.clientY - dragOff.current.y) / window.innerHeight);
    };
    const mu = e => {
      if (!dragging.current) return;
      dragging.current = false;
      document.body.style.cursor = "";
      const w = wRef.current; if (!w) return;
      const r = w.getBoundingClientRect();
      const ne = r.left + 25 < window.innerWidth / 2 ? "left" : "right";
      setVRatio(r.top / window.innerHeight);
      setEdge(ne);
      snap(true, ne);
    };
    window.addEventListener("mousemove", mm);
    window.addEventListener("mouseup", mu);
    return () => { window.removeEventListener("mousemove", mm); window.removeEventListener("mouseup", mu); };
  });

  // ── Resize ────────────────────────────────────────────────────────────────
  useEffect(() => {
    const mm = e => {
      if (!resizing.current) return;
      const { sw, sh, sx, sy, type } = resStart.current;
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (type === "side") {
        setPanelW(edge === "right" ? Math.max(280, Math.min(window.innerWidth - 48, sw - dx)) : Math.max(280, Math.min(window.innerWidth - 48, sw + dx)));
      } else {
        setPanelW(edge === "right" ? Math.max(280, Math.min(window.innerWidth - 48, sw - dx)) : Math.max(280, Math.min(window.innerWidth - 48, sw + dx)));
        setPanelH(Math.max(220, Math.min(window.innerHeight - 48, sh + dy)));
      }
    };
    const mu = () => { resizing.current = null; document.body.style.cursor = ""; };
    window.addEventListener("mousemove", mm);
    window.addEventListener("mouseup", mu);
    return () => { window.removeEventListener("mousemove", mm); window.removeEventListener("mouseup", mu); };
  });

  function startDrag(e) {
    if (e.target.closest(".byte-close-x") || e.target.closest(".brs") || e.target.closest(".brc")) return;
    e.preventDefault();
    const r = wRef.current.getBoundingClientRect();
    dragOff.current = { x: e.clientX - r.left, y: e.clientY - r.top };
    dragging.current = true;
    document.body.style.cursor = "grabbing";
  }

  function startResize(e, type) {
    e.stopPropagation(); e.preventDefault();
    resizing.current = type;
    resStart.current = { sw: panelW, sh: panelH, sx: e.clientX, sy: e.clientY, type };
    document.body.style.cursor = type === "side" ? "ew-resize" : "nwse-resize";
  }

  function goNext() {
    if (stepIdx < total - 1) {
      const next = BYTE_STEPS[stepIdx + 1];
      if (next.nav && next.nav !== activePage) onNavigate(next.nav);
      setStepIdx(stepIdx + 1);
    }
  }

  function goPrev() {
    if (stepIdx > 0) {
      const prev = BYTE_STEPS[stepIdx - 1];
      if (prev.nav && prev.nav !== activePage) onNavigate(prev.nav);
      setStepIdx(stepIdx - 1);
    }
  }

  if (skipped) return null;

  const panelLeft = edge === "left";
  const isLast    = stepIdx === total - 1;
  const moduleLabel = step.nav ? NAV_MAP[step.nav] || "LAB" : "LAB";

  const CSS = `
    .byte-panel-pir{position:absolute;background:var(--s1);border:1px solid rgba(0,229,255,.2);border-radius:10px;
      box-shadow:0 20px 60px rgba(0,0,0,.8);display:flex;flex-direction:column;overflow:hidden;
      animation:fadeIn .2s ease-out}
    .byte-head-pir{display:flex;align-items:center;gap:8px;padding:11px 14px;
      border-bottom:1px solid var(--line);background:var(--s2);cursor:grab;user-select:none;flex-shrink:0}
    .byte-head-pir:active{cursor:grabbing}
    .byte-body-pir{flex:1;overflow-y:auto;padding:14px;font-size:12px;color:var(--t2);line-height:1.8}
    .byte-body-pir p{margin-bottom:8px}
    .byte-body-pir b{color:var(--t1);font-weight:600}
    .byte-body-pir code{font-family:var(--mono);font-size:10px;background:var(--s3);
      padding:1px 5px;border-radius:3px;color:var(--cyan)}
    .byte-action-pir{margin:0 14px 10px;padding:8px 12px;background:rgba(255,184,48,.07);
      border:1px solid rgba(255,184,48,.2);border-radius:6px;font-size:11px;
      color:var(--amber);line-height:1.4;flex-shrink:0}
    .byte-foot-pir{display:flex;align-items:center;gap:6px;padding:10px 14px;
      border-top:1px solid var(--line);flex-shrink:0;background:var(--s2)}
    .byte-prog-pir{height:2px;background:var(--line);border-radius:1px;overflow:hidden;
      margin:0 14px 0;flex-shrink:0}
    .byte-step-title{font-size:12px;font-weight:700;color:var(--cyan);margin-bottom:8px;
      font-family:var(--mono);display:flex;align-items:center;gap:7px}
    .byte-num{font-size:9px;padding:1px 7px;border-radius:10px;background:rgba(0,229,255,.1);
      border:1px solid rgba(0,229,255,.2);color:var(--cyan);font-family:var(--mono);font-weight:800}
    .byte-nav-hint{font-size:10px;color:var(--t4);font-family:var(--mono);background:rgba(0,229,255,.04);
      border:1px solid var(--line);border-radius:4px;padding:3px 8px;margin-bottom:8px;display:inline-block}
    .byte-launcher-pir{width:50px;height:50px;border-radius:50%;background:var(--s2);
      border:1.5px solid rgba(0,229,255,.4);display:flex;align-items:center;justify-content:center;
      cursor:pointer;box-shadow:0 4px 20px rgba(0,0,0,.5),0 0 0 4px rgba(0,229,255,.05);
      transition:all .2s;font-size:22px;position:absolute;bottom:0;right:0}
    .byte-launcher-pir:hover{border-color:var(--cyan);box-shadow:0 4px 20px rgba(0,0,0,.5),0 0 0 6px rgba(0,229,255,.1)}
    .byte-badge-pir{position:absolute;top:-3px;right:-3px;min-width:16px;height:16px;
      border-radius:8px;background:var(--red);color:#fff;font-size:9px;font-weight:800;
      display:flex;align-items:center;justify-content:center;font-family:var(--mono);
      padding:0 3px;border:1.5px solid var(--bg)}
  `;

  return (
    <>
      <style>{CSS}</style>
      <div ref={wRef} style={{ position: "fixed", width: 50, height: 50, zIndex: 9500 }}>
        {/* Panel */}
        {open && (
          <div className="byte-panel-pir" style={{
            width: panelW, height: panelH,
            bottom: 50,
            [panelLeft ? "left" : "right"]: 0,
          }}>
            {/* Resize handles */}
            <div className="brs" style={{
              position: "absolute", top: "50%", transform: "translateY(-50%)",
              width: 5, height: 40, borderRadius: 3,
              background: "rgba(0,229,255,.15)", cursor: "ew-resize",
              [panelLeft ? "right" : "left"]: -7,
            }} onMouseDown={e => startResize(e, "side")} />
            <div className="brc" style={{
              position: "absolute", width: 12, height: 12, borderRadius: 3,
              background: "rgba(0,229,255,.12)", cursor: "nwse-resize",
              bottom: -6, [panelLeft ? "right" : "left"]: -6,
            }} onMouseDown={e => startResize(e, "corner")} />

            {/* Header */}
            <div className="byte-head-pir" onMouseDown={startDrag}>
              <span style={{ fontSize: 16 }}>🤖</span>
              <span style={{ flex: 1, fontFamily: "var(--mono)", fontSize: 11, fontWeight: 700, color: "var(--t1)" }}>
                Byte — PIR Lab
              </span>
              <span style={{
                width: 7, height: 7, borderRadius: "50%", background: "var(--green)",
                flexShrink: 0, animation: "pulse 2s ease-in-out infinite",
              }} />
              <button className="byte-close-x" onClick={() => setOpen(false)} style={{
                background: "transparent", border: "none", color: "var(--t4)",
                fontSize: 15, cursor: "pointer", padding: "0 2px", marginLeft: 4,
              }}>–</button>
            </div>

            {/* Step + module info */}
            <div style={{ padding: "7px 14px 5px", borderBottom: "1px solid var(--line)", flexShrink: 0 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, fontSize: 10, color: "var(--t4)", fontFamily: "var(--mono)" }}>
                <span>Step {stepIdx + 1} / {total}</span>
                <span style={{
                  background: "var(--cyan-dim)", color: "var(--cyan)",
                  border: "1px solid rgba(0,229,255,.2)", padding: "0 7px",
                  borderRadius: 10, fontSize: 9,
                }}>{moduleLabel}</span>
              </div>
              <div className="byte-prog-pir">
                <div style={{ height: "100%", width: prog + "%", background: "linear-gradient(90deg,var(--cyan),var(--purple))", transition: "width .4s ease-out" }} />
              </div>
            </div>

            {/* Body */}
            <div className="byte-body-pir" ref={bodyRef} style={{ flex: 1, overflowY: "auto", padding: 14 }}>
              {step.nav && step.nav !== activePage && (
                <div className="byte-nav-hint">
                  → Navigate to: <b style={{ color: "var(--cyan)" }}>{step.nav.toUpperCase()}</b>
                </div>
              )}
              {isLast && (
                <div style={{
                  display: "inline-flex", alignItems: "center", gap: 6,
                  background: "rgba(0,230,118,.08)", border: "1px solid rgba(0,230,118,.2)",
                  borderRadius: 20, padding: "3px 12px", marginBottom: 10,
                  fontSize: 10, fontWeight: 700, color: "var(--green)", fontFamily: "var(--mono)",
                }}>✓ LAB COMPLETE</div>
              )}
              <div className="byte-step-title">
                <span className="byte-num">{String(stepIdx + 1).padStart(2, "0")}</span>
                {step.title}
              </div>
              {typing ? (
                <div style={{ display: "flex", gap: 4, padding: "4px 0" }}>
                  {[0, 1, 2].map(i => (
                    <div key={i} style={{
                      width: 6, height: 6, borderRadius: "50%",
                      background: "rgba(0,229,255,.4)",
                      animation: `pulse 1.2s ${i * 0.2}s ease-in-out infinite`,
                    }} />
                  ))}
                </div>
              ) : (
                <div dangerouslySetInnerHTML={{ __html: html }} />
              )}
            </div>

            {/* Action banner */}
            {step.action && !typing && (
              <div className="byte-action-pir">
                ⚡ {step.action}
              </div>
            )}

            {/* Footer */}
            <div className="byte-foot-pir">
              <button onClick={() => setSkipped(true)} style={{
                background: "transparent", border: "none", color: "var(--t4)",
                fontSize: 10, cursor: "pointer",
              }}>Skip</button>
              <div style={{ flex: 1 }} />
              <button className="btn btn-ghost" style={{ padding: "5px 12px", fontSize: 11 }} onClick={goPrev} disabled={stepIdx === 0}>
                ← Back
              </button>
              <button
                className={`btn ${isLast ? "btn-green" : "btn-cyan"}`}
                style={{ padding: "5px 14px", fontSize: 11 }}
                onClick={isLast ? () => setSkipped(true) : goNext}
              >
                {isLast ? "Finish ✓" : "Next →"}
              </button>
            </div>
          </div>
        )}

        {/* Launcher bubble */}
        <div className="byte-launcher-pir" onClick={() => setOpen(v => !v)}>
          {open
            ? <span style={{ fontSize: 18, color: "var(--cyan)" }}>×</span>
            : <span style={{ fontSize: 20 }}>🤖</span>
          }
          {!open && <span className="byte-badge-pir">{stepIdx + 1}</span>}
        </div>
      </div>
    </>
  );
}
