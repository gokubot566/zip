// ═══════════════════════════════════════════════════════════════════════════
// VANTARA SOC PLATFORM v3.1 — Enterprise Security Operations Center
// ═══════════════════════════════════════════════════════════════════════════
import { useState, useMemo, useEffect, useRef } from "react";
import { Icons } from "./icons.jsx";

// ═══════════════════════════════════════════════════════════════════════════
// LAB ACTION BUS — components emit progress events; Byte gates the Next button.
// ═══════════════════════════════════════════════════════════════════════════
function labAction(key) {
  try { window.dispatchEvent(new CustomEvent("lab:action", { detail: { key } })); } catch (e) {}
}

// ─── CSS ─────────────────────────────────────────────────────────────────────
const CSS = `
*{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#060E1A;--surface:#0B1525;--card:#0F1E30;--card-hi:#152540;
  --border:#1C3050;--border-hi:#284870;
  --accent:#38BDF8;--accent-dim:#0E4A6A;
  --amber:#F59E0B;--amber-dim:#7C3E00;
  --red:#F87171;--red-dim:#7F1D1D;--red-bg:#1A0808;
  --green:#34D399;--green-dim:#064E3B;
  --purple:#A78BFA;--purple-dim:#3B1F6E;
  --text1:#EAF1F8;--text2:#8BACC8;--text3:#4A6A88;
  --ui:'Inter',system-ui,sans-serif;--mono:'JetBrains Mono','Courier New',monospace;
  --r4:4px;--r6:6px;--r8:8px;--r12:12px;
}
html,body,#root{height:100%;overflow:hidden}
body{background:var(--bg);color:var(--text1);font-family:var(--ui);font-size:13px;line-height:1.5}
::-webkit-scrollbar{width:5px;height:5px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--border-hi);border-radius:3px}
::-webkit-scrollbar-thumb:hover{background:#3A6080}
input,textarea,select{font-family:var(--mono);background:var(--card);border:1px solid var(--border);border-radius:var(--r6);color:var(--text1);padding:7px 10px;font-size:12px;outline:none;width:100%;transition:border-color 0.15s}
input:focus,textarea:focus,select:focus{border-color:var(--accent)}
select{cursor:pointer}
textarea{resize:vertical;line-height:1.6}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
@keyframes fadein{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}
.risk-fill{height:100%;border-radius:2px;width:var(--risk-w,0%);background:var(--risk-c,#4ADE80);transition:width 0.8s ease-out}
.ticker-anim{display:inline-flex;gap:0;animation:ticker 32s linear infinite;-webkit-animation:ticker 32s linear infinite;will-change:transform;transform:translate3d(0,0,0);-webkit-transform:translate3d(0,0,0);backface-visibility:hidden;-webkit-backface-visibility:hidden}
.ticker-anim:hover{animation-play-state:paused;-webkit-animation-play-state:paused}
@keyframes ticker{0%{transform:translate3d(0,0,0)}100%{transform:translate3d(-50%,0,0)}}@-webkit-keyframes ticker{0%{-webkit-transform:translate3d(0,0,0)}100%{-webkit-transform:translate3d(-50%,0,0)}}
.pulse{animation:pulse 2s ease-in-out infinite}
.fadein{animation:fadein 0.2s ease-out}


table{border-collapse:collapse;width:100%}
th{text-align:left;font-family:var(--mono);font-size:10px;font-weight:600;letter-spacing:0.08em;color:var(--text3);padding:8px 12px;border-bottom:1px solid var(--border);white-space:nowrap}
td{padding:9px 12px;border-bottom:1px solid var(--border);vertical-align:middle;font-size:12px}
tr:last-child td{border-bottom:none}
tr.hoverable:hover td{background:var(--card-hi);cursor:pointer}
.tag{display:inline-flex;align-items:center;font-family:var(--mono);font-size:10px;font-weight:600;padding:2px 8px;border-radius:var(--r4);letter-spacing:0.04em;white-space:nowrap}
`;

// ─── DATA ────────────────────────────────────────────────────────────────────
const ORG = { name:"Vantara Solutions", domain:"vantara.io", mx:"mx1.vantara.io" };
const ME = { name:"John Mercer", email:"john.mercer@vantara.io", initials:"JM", role:"SOC Analyst II", tier:"L2" };

const PHISH_URL  = "https://docusign-esign-verify.account-secure.net/d/?id=NDA3MjExOTU=&ref=john.mercer%40vantara.io";
const PHISH_IP   = "185.220.101.52";
const PHISH_FROM = "docusign-notify@esign-secure.net";
const PHISH_DOM  = "esign-secure.net";
const HARVEST    = "account-secure.net";

const USERS = {
  "john.mercer@vantara.io":     {name:"John Mercer",   dept:"Strategy & Ops",   risk:42},
  "claire.ashworth@vantara.io": {name:"Claire Ashworth",dept:"Consulting",       risk:18},
  "priya.kapoor@vantara.io":    {name:"Priya Kapoor",  dept:"Engineering",      risk:29},
  "r.foster@vantara.io":        {name:"Rachel Foster", dept:"Human Resources",  risk:11},
  "m.nguyen@vantara.io":        {name:"Michael Nguyen",dept:"Finance",          risk:22},
};

const EMAILS = [
  { id:"em001",folder:"inbox",read:true,starred:true,
    from:{name:"Claire Ashworth",email:"claire.ashworth@vantara.io",av:"CA"},
    to:[ME.email],cc:["r.foster@vantara.io"],
    subject:"Q3 Meridian Delivery Review — Exec Pack for Friday",
    preview:"Exec pack updated with Q3 utilisation data. Section 3 needs a narrative frame before leadership review.",
    body:`John,

Exec pack is updated with the Meridian Q3 utilisation data. Before Friday's 09:00 call, please review Section 3 — the numbers need contextualising before we present to the board.

Tom Reeves (Meridian) has requested a pre-read by Thursday EOB. Can you sign off on the exec summary draft I've attached?

Also cc'ing Rachel as she's now covering the billing dispute thread.

Claire
────────────────────────────────────
Claire Ashworth  |  Principal Consultant
Vantara Solutions  ·  +44 7711 203 481`,
    date:"2025-05-16T08:42:00",cat:"internal",
    attachments:[{name:"Meridian_Q3_Review_v5.pptx",size:"3.4 MB",type:"pptx"}],
    headers:{SPF:"PASS",DKIM:"PASS",DMARC:"PASS","X-Spam-Score":"0.1","X-Originating-IP":"10.0.1.14","Reply-To":"claire.ashworth@vantara.io"},
    rep:{score:98,verdict:"Safe",cat:"trusted-internal"},links:[]},

  { id:"em002",folder:"inbox",read:false,starred:false,isPhishing:true,
    from:{name:"DocuSign",email:PHISH_FROM,av:"DS"},
    to:[ME.email],cc:[],
    subject:"ACTION REQUIRED: Contract amendment pending your signature — expires 16 May 23:59",
    preview:"Vantara Solutions Legal has sent a document for your immediate signature. Failure to sign may affect your employment status.",
    body:`DocuSign Notification Service
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  You have an important document awaiting signature

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Dear john.mercer@vantara.io,

Vantara Solutions (Legal & Compliance Dept.) has sent you a document for electronic signature:

  Document:    "Employment Contract Amendment — Compensation Review 2025"
  Sender:      legal@vantara.io
  Document ID: DS-9182736-VNT
  Expires:     16 May 2025 · 23:59 UTC

YOUR SIGNATURE IS REQUIRED WITHIN 24 HOURS.
Failure to sign may result in automatic contract expiry and a review of your employment status.

  ▶  REVIEW AND SIGN DOCUMENT
     ${PHISH_URL}

If you received this in error, contact legal@vantara.io immediately.

DocuSign, Inc.  ·  221 Main Street Suite 1000  ·  San Francisco CA 94105
© 2025 DocuSign Inc. All rights reserved.`,
    date:"2025-05-15T03:18:00",cat:"external",
    attachments:[],
    phishIndicators:[
      {sev:"critical",label:"Sender domain impersonation",mitre:"T1566.001",detail:`From: ${PHISH_FROM} — 'esign-secure.net' is not a DocuSign domain. Legitimate DocuSign notifications originate exclusively from @docusign.com or @docusign.net. The domain esign-secure.net was registered 17 days before this message (WHOIS: 2025-04-28, NameSilo, privacy-protected).`},
      {sev:"high",label:"Reply-To mismatch",mitre:"T1598",detail:"Reply-To resolves to support@esign-helpdesk.org — a separate domain designed to intercept replies and prevent victims from contacting the real DocuSign."},
      {sev:"critical",label:"SPF authentication failure",mitre:"T1566.001",detail:`SPF: FAIL. ${PHISH_IP} is not listed in permitted senders for ${PHISH_DOM}. The SPF record for this domain is absent/incomplete.`},
      {sev:"critical",label:"DKIM signature absent",mitre:"T1566.001",detail:"No DKIM signature is present. All genuine DocuSign emails carry a verifiable DKIM signature from docusign.com. The absence of any DKIM record is a strong forgery indicator."},
      {sev:"high",label:"DMARC policy failure",mitre:"T1566.001",detail:"DMARC: FAIL. Neither SPF nor DKIM alignment passes against the From domain. Legitimate enterprise senders consistently pass DMARC."},
      {sev:"critical",label:"Credential-harvesting URL",mitre:"T1598.003",detail:`The 'REVIEW AND SIGN' link resolves to ${PHISH_URL} — the actual registered domain is account-secure.net, not docusign.com. The subdomain structure mimics a legitimate DocuSign path. VirusTotal: 17/92 vendors.`},
      {sev:"high",label:"Coercive social engineering language",mitre:"T1566",detail:"'Failure to sign may result in automatic contract expiry and a review of your employment status' — employment-threat language is a hallmark of spear-phishing targeting corporate employees."},
      {sev:"high",label:"Tor exit-node sender IP",mitre:"T1090.003",detail:`${PHISH_IP} is listed in the Tor exit-node consensus (dan.me.uk/torlist). AbuseIPDB confidence: 98%. OVH SAS Romania bulletproof hosting. No legitimate DocuSign infrastructure uses Tor.`},
      {sev:"medium",label:"Off-hours delivery",mitre:"T1566",detail:"Delivered at 03:18 UTC — outside business hours across all Vantara operating timezones. Automated phishing campaigns target low-vigilance windows."},
    ],
    headers:{SPF:"FAIL",DKIM:"FAIL",DMARC:"FAIL","X-Spam-Score":"8.4","X-Originating-IP":PHISH_IP,"X-Mailer":"Bulk Mailer v3.1","X-Campaign-ID":"phish-docusign-ent-052025-b","Return-Path":`<bounce@${PHISH_DOM}>`,"Reply-To":"support@esign-helpdesk.org","Received":`from smtp-out.mailbulk-eu47.net (${PHISH_IP}) by ${ORG.mx} with ESMTP id ph9sm8273641; Thu, 15 May 2025 03:18:44 +0000`,"DKIM-Signature":"(none — no valid signature present)","Message-ID":"<phish-DS-9182736-20250515@esign-secure.net>"},
    rep:{score:3,verdict:"MALICIOUS",cat:"phishing-kit"},
    links:[{url:PHISH_URL,label:"REVIEW AND SIGN DOCUMENT",safe:false,vt:"17/92",cat:"Credential Harvesting"}]},

  { id:"em003",folder:"inbox",read:true,starred:false,
    from:{name:"IT Service Desk",email:"servicedesk@vantara.io",av:"IT"},
    to:[ME.email],cc:[],
    subject:"Scheduled maintenance window — Saturday 25 May 01:00–05:00 UTC",
    preview:"Planned maintenance this Saturday. VPN, Intranet, SharePoint, and CI/CD unavailable. No action required.",
    body:`Hello John,

Scheduled maintenance on Saturday 25 May between 01:00 and 05:00 UTC.

Services temporarily unavailable:
  • VPN Gateway (vpn.vantara.io)
  • Intranet Portal (intranet.vantara.io)
  • SharePoint Online (SSO-federated)
  • CI/CD pipeline runners (GitLab)

Please save open work and close active VPN sessions before 00:45 UTC. No action required otherwise. For issues after 05:30 UTC, log a ticket at servicedesk.vantara.io or call ext. 1000.

IT Service Desk`,
    date:"2025-05-15T11:30:00",cat:"it-notice",attachments:[],
    headers:{SPF:"PASS",DKIM:"PASS",DMARC:"PASS","X-Spam-Score":"0.0","X-Originating-IP":"10.0.0.4","Reply-To":"servicedesk@vantara.io"},
    rep:{score:99,verdict:"Safe",cat:"trusted-internal"},links:[]},

  { id:"em004",folder:"inbox",read:true,starred:false,
    from:{name:"GitHub",email:"noreply@github.com",av:"GH"},
    to:[ME.email],cc:[],
    subject:"[vantara-solutions/client-portal] PR #341: Implement RBAC middleware layer",
    preview:"Priya Kapoor opened PR #341 — 8 files changed, +412 −38. Your review requested.",
    body:`Priya Kapoor opened a pull request in vantara-solutions/client-portal

PR #341: Implement RBAC middleware layer
8 files changed   +412 −38

Adds role-based access control to the client portal API. Permissions evaluated per-route against a centralised policy engine. Unit test coverage: 94%.

Reviewers: @john-mercer  @devops-team

View PR → github.com/vantara-solutions/client-portal/pull/341`,
    date:"2025-05-14T14:22:00",cat:"dev",attachments:[],
    headers:{SPF:"PASS",DKIM:"PASS",DMARC:"PASS","X-Spam-Score":"0.1","X-Originating-IP":"192.30.252.201","Reply-To":"noreply@github.com"},
    rep:{score:97,verdict:"Safe",cat:"trusted-external"},links:[]},

  { id:"em005",folder:"inbox",read:false,starred:false,
    from:{name:"Marcus Webb",email:"m.webb@hartwell-partners.com",av:"MW"},
    to:[ME.email],cc:[],
    subject:"Vantara / Hartwell — Due Diligence Pack request ahead of Tuesday board",
    preview:"John, following our call — please send the standard DD pack by Friday COB. Board meeting is Tuesday 20th.",
    body:`John,

Following our conversation last week — could you send the due diligence pack for the Hartwell engagement?

Our legal team needs certificates of insurance and the last two years of audited accounts before they can sign off on the MSA. Ideally by Friday COB — the board meeting is Tuesday 20th.

Marcus
────────────────────────────────────
Marcus Webb  |  Director of Procurement
Hartwell Partners LLP  ·  +44 20 7946 0312`,
    date:"2025-05-14T09:05:00",cat:"client",attachments:[],
    headers:{SPF:"PASS",DKIM:"PASS",DMARC:"PASS","X-Spam-Score":"0.3","X-Originating-IP":"82.163.44.17","Reply-To":"m.webb@hartwell-partners.com"},
    rep:{score:84,verdict:"Safe",cat:"known-external"},links:[]},

  { id:"em006",folder:"inbox",read:true,starred:false,
    from:{name:"LinkedIn",email:"messages-noreply@linkedin.com",av:"LI"},
    to:[ME.email],cc:[],
    subject:"Farrukh Tashkentov accepted your connection request",
    preview:"Farrukh Tashkentov (Head of Digital Transformation, Meridian Group) is now connected with you.",
    body:`Hi John,

Farrukh Tashkentov accepted your connection request.

Farrukh Tashkentov — Head of Digital Transformation, Meridian Group

View profile → linkedin.com/in/farrukh-tashkentov

LinkedIn Corporation  ·  Sunnyvale CA 94085`,
    date:"2025-05-13T16:45:00",cat:"social",attachments:[],
    headers:{SPF:"PASS",DKIM:"PASS",DMARC:"PASS","X-Spam-Score":"0.2","X-Originating-IP":"108.174.10.32","Reply-To":"messages-noreply@linkedin.com"},
    rep:{score:95,verdict:"Safe",cat:"trusted-external"},links:[]},

  { id:"em007",folder:"sent",read:true,starred:false,
    from:{name:ME.name,email:ME.email,av:"JM"},
    to:["claire.ashworth@vantara.io"],cc:["m.nguyen@vantara.io"],
    subject:"RE: Q3 Meridian Delivery Review — Exec Pack for Friday",
    preview:"Claire, exec summary attached and good to go. Softened section 3 language. Pre-read sent to Tom.",
    body:`Claire,

Exec summary attached and cleared. Softened the utilisation language in section 3 slightly. Pre-read now sent to Tom with a note that final slides follow Thursday morning.

John`,
    date:"2025-05-16T09:55:00",cat:"internal",
    attachments:[{name:"Meridian_Q3_ExecSummary_FINAL.pdf",size:"1.1 MB",type:"pdf"}],
    headers:{SPF:"PASS",DKIM:"PASS",DMARC:"PASS","X-Spam-Score":"0.0","X-Originating-IP":"10.0.1.22","Reply-To":ME.email},
    rep:{score:99,verdict:"Safe",cat:"trusted-internal"},links:[]},

  { id:"em008",folder:"drafts",read:true,starred:false,
    from:{name:ME.name,email:ME.email,av:"JM"},
    to:["m.webb@hartwell-partners.com"],cc:[],
    subject:"RE: Vantara / Hartwell — Due Diligence Pack",
    preview:"[DRAFT] Marcus, please find attached the requested due diligence materials.",
    body:`Marcus,

Please find attached the due diligence pack — certificates of insurance and FY2023/FY2024 audited accounts.

Let me know if anything else is needed ahead of Tuesday.

[DRAFT — not sent]`,
    date:"2025-05-15T17:30:00",cat:"client",
    attachments:[{name:"Vantara_DD_Pack_2025.zip",size:"8.7 MB",type:"zip"}],
    headers:{},rep:{score:99,verdict:"Safe",cat:"trusted-internal"},links:[]},

  { id:"em009",folder:"archive",read:true,starred:false,
    from:{name:"Rachel Foster",email:"r.foster@vantara.io",av:"RF"},
    to:[ME.email],cc:[],
    subject:"New starter onboarding — sign-off required before system provisioning",
    preview:"Docs for Kieran Walsh, Amara Osei, and Nikhil Rao are in SharePoint. Need your sign-off.",
    body:`John,

Onboarding docs for the three new joiners are ready for your sign-off: Kieran Walsh, Amara Osei, Nikhil Rao.

Files in SharePoint under HR > Onboarding > May 2025. HR can't provision system access until approved.

Rachel`,
    date:"2025-05-09T10:15:00",cat:"internal",attachments:[],
    headers:{SPF:"PASS",DKIM:"PASS",DMARC:"PASS","X-Spam-Score":"0.0","X-Originating-IP":"10.0.1.8","Reply-To":"r.foster@vantara.io"},
    rep:{score:99,verdict:"Safe",cat:"trusted-internal"},links:[]},

  { id:"em010",folder:"spam",read:false,starred:false,
    from:{name:"Prize Notification Centre",email:"winner@prize-global-notify.xyz",av:"PN"},
    to:[ME.email],cc:[],
    subject:"🎉 Congratulations — You have been selected as our £50,000 weekly winner",
    preview:"Your email address has been randomly selected. Claim your prize within 72 hours.",
    body:`CONGRATULATIONS!

john.mercer@vantara.io has been selected as our £50,000 weekly prize recipient.

Claim: http://claim-prize-winners.info/claim?ref=VNT-7391823

Expires in 72 hours.`,
    date:"2025-05-13T07:02:00",cat:"spam",attachments:[],
    headers:{SPF:"FAIL",DKIM:"FAIL",DMARC:"FAIL","X-Spam-Score":"9.6","X-Originating-IP":"91.194.60.11","Reply-To":"claim@prize-global-notify.xyz"},
    rep:{score:2,verdict:"Spam",cat:"bulk-spam"},links:[]},
];


// ─── SECOND PHISHING EMAIL CONSTANTS ─────────────────────────────────────────
const PHISH2_URL  = "https://microsoftonline-secure-verify.ms-account-alerts.net/signin/?token=aHR0cHM6Ly92YW50YXJhLmlv";
const PHISH2_IP   = "91.108.56.212";
const PHISH2_FROM = "security-alert@ms-account-alerts.net";
const PHISH2_DOM  = "ms-account-alerts.net";

const EMAILS_EXTRA = [
  { id:"em011",folder:"inbox",read:false,starred:false,isPhishing:true,hasNoCase:true,
    from:{name:"Microsoft Account Team",email:PHISH2_FROM,av:"MS"},
    to:[ME.email],cc:[],
    subject:"⚠ Your Microsoft 365 account has been flagged — immediate verification required",
    preview:"Unusual sign-in activity detected from an unrecognised device. Verify your identity immediately to avoid account suspension.",
    body:`Microsoft Account Security Alert
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  We detected unusual sign-in activity on your account

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Dear john.mercer@vantara.io,

We have detected a sign-in attempt to your Microsoft 365 account from an unrecognised device and location:

  Country:    Nigeria (Lagos)
  Device:     Windows 11 PC — Unknown
  IP Address: 102.89.45.178
  Time:       17 May 2025 · 22:41 UTC

If this was you, no action is required. If this was NOT you, your account may be compromised.

VERIFY YOUR IDENTITY IMMEDIATELY to secure your account and prevent unauthorised access:

  ▶  SECURE MY ACCOUNT NOW
     ${PHISH2_URL}

You have 12 HOURS to verify before your account is automatically suspended.

Microsoft Account Team
Microsoft Corporation  ·  One Microsoft Way  ·  Redmond, WA 98052
© 2025 Microsoft Corporation. All rights reserved.`,
    date:"2025-05-17T22:55:00",cat:"external",
    attachments:[],
    phishIndicators:[
      {sev:"critical",label:"Sender domain impersonation",mitre:"T1566.001",detail:"From: security-alert@ms-account-alerts.net — this is NOT a Microsoft domain. All genuine Microsoft security alerts originate from @microsoft.com, @account.microsoft.com, or @accountprotection.microsoft.com. The domain ms-account-alerts.net was registered 9 days before this message."},
      {sev:"critical",label:"SPF authentication failure",mitre:"T1566.001",detail:"SPF: FAIL. Originating server 91.108.56.212 is not listed in permitted senders for ms-account-alerts.net. Legitimate Microsoft emails pass SPF from microsoft.com infrastructure."},
      {sev:"critical",label:"DKIM signature absent",mitre:"T1566.001",detail:"No DKIM signature present. All genuine Microsoft account security emails carry a valid DKIM signature from microsoft.com."},
      {sev:"high",label:"DMARC policy failure",mitre:"T1566.001",detail:"DMARC: FAIL. Neither SPF nor DKIM alignment passes against the From domain. Legitimate Microsoft emails consistently pass DMARC with p=reject enforcement."},
      {sev:"critical",label:"Credential-harvesting URL",mitre:"T1598.003",detail:"The 'SECURE MY ACCOUNT' link resolves to microsoftonline-secure-verify.ms-account-alerts.net — the registered domain is ms-account-alerts.net, not microsoft.com. The subdomain uses 'microsoftonline' to appear legitimate at a glance. VirusTotal: 8/92 detections."},
      {sev:"high",label:"Urgency and account-suspension threat",mitre:"T1566",detail:"'You have 12 HOURS to verify before your account is automatically suspended' — classic urgency tactic to suppress rational deliberation and force immediate action."},
      {sev:"medium",label:"Suspicious sender IP geolocation",mitre:"T1090",detail:"Originating IP 91.108.56.212 geolocates to Frankfurt, DE — Telegram-associated ASN infrastructure frequently used for bulk phishing relay campaigns."},
      {sev:"medium",label:"Mismatched sign-in alert geography",mitre:"T1566",detail:"The alleged sign-in is from Lagos, Nigeria, but the sending server is in Frankfurt, Germany — inconsistent with how Microsoft's genuine alert system works, where alerts originate from Microsoft's own infrastructure."},
    ],
    headers:{SPF:"FAIL",DKIM:"FAIL",DMARC:"FAIL","X-Spam-Score":"7.2","X-Originating-IP":PHISH2_IP,"X-Mailer":"PHPMailer 6.5.0","Return-Path":`<bounce@${PHISH2_DOM}>`,"Reply-To":`noreply@${PHISH2_DOM}`,"Received":`from relay4.bulkmailer-eu.net (${PHISH2_IP}) by ${ORG.mx} with ESMTP id ms7sm4810293; Sat, 17 May 2025 22:55:11 +0000`,"DKIM-Signature":"(none — absent)","Message-ID":"<ms-sec-alert-7483920@ms-account-alerts.net>"},
    rep:{score:5,verdict:"MALICIOUS",cat:"phishing-kit"},
    links:[{url:PHISH2_URL,label:"SECURE MY ACCOUNT NOW",safe:false,vt:"8/92",cat:"Credential Harvesting / Microsoft 365 Lure"}]},
];

// Merge all emails
const ALL_EMAILS = [...EMAILS, ...EMAILS_EXTRA];

const ALERTS = [
  {id:"ALT-5521",sev:"critical",status:"open",title:"Phishing email — SPF/DKIM/DMARC triple-fail delivered to inbox",rule:"PHISH-044",user:"john.mercer@vantara.io",src:PHISH_IP,time:"2025-05-15T03:18:44",tactic:"Initial Access",tech:"T1566.001",case:"INC-2025-0312",
    desc:"Mail gateway accepted message from Tor exit-node IP with triple auth failure. Spam score 8.4 — below quarantine threshold 9.0. Correlation: sender IP matches FS-ISAC feed entry (2025-05-13)."},
  {id:"ALT-5522",sev:"high",status:"open",title:"DNS query to newly-registered uncategorised domain",rule:"DNS-HUNT-017",user:"john.mercer@vantara.io",src:"10.0.1.22",time:"2025-05-15T07:44:12",tactic:"Reconnaissance",tech:"T1590",case:"INC-2025-0312",
    desc:`Proxy log: VANT-JM-001 queried ${HARVEST} (domain age: 17 days, uncategorised). No HTTP follow-through — possible email hover/prefetch. Block applied on subdomain query.`},
  {id:"ALT-5523",sev:"high",status:"investigating",title:"User-submitted phish report — DocuSign lure, second recipient",rule:"USR-RPT-001",user:"priya.kapoor@vantara.io",src:"10.0.2.41",time:"2025-05-15T09:12:00",tactic:"Initial Access",tech:"T1566.001",case:"INC-2025-0312",
    desc:"priya.kapoor@vantara.io submitted PhishAlert report on DocuSign-themed email. Sender domain: esign-secure.net — matches ALT-5521. Campaign confirmed multi-target."},
  {id:"ALT-5524",sev:"medium",status:"open",title:"Azure AD — Sign-in from new external IP geolocation",rule:"AAD-GEO-003",user:"john.mercer@vantara.io",src:"82.163.44.99",time:"2025-05-15T08:30:00",tactic:"Defense Evasion",tech:"T1078",case:null,
    desc:"Azure AD login from 82.163.44.99 (London, GB, BT Consumer). Last auth from 10.0.1.22 (internal). New external IP — likely WFH. No MFA anomalies. Correlate with INC-2025-0312."},
  {id:"ALT-5525",sev:"critical",status:"open",title:"MFA fatigue attack — 3 consecutive push denials from Tor IP",rule:"MFA-FATIGUE-002",user:"john.mercer@vantara.io",src:PHISH_IP,time:"2025-05-15T10:45:00",tactic:"Credential Access",tech:"T1110.004",case:"INC-2025-0312",
    desc:`3 Microsoft Authenticator pushes to john.mercer from ${PHISH_IP} within 4 minutes. All denied. Possible credential capture — attacker attempting MFA bypass.`},
  {id:"ALT-5526",sev:"low",status:"resolved",title:"Bulk spam — prize notification, auto-quarantined",rule:"SPAM-001",user:"john.mercer@vantara.io",src:"91.194.60.11",time:"2025-05-13T07:02:19",tactic:"",tech:"",case:null,
    desc:"Bulk spam auto-quarantined at gateway. Spam score 9.6. No user interaction. Resolved."},
  {id:"ALT-5527",sev:"low",status:"resolved",title:"Single failed password attempt — likely typo",rule:"AUTH-FAIL-001",user:"m.nguyen@vantara.io",src:"10.0.3.15",time:"2025-05-15T09:00:00",tactic:"",tech:"",case:null,
    desc:"Single failed password, internal network. No follow-up attempts. Resolved."},
  {id:"ALT-5528",sev:"medium",status:"open",title:"Endpoint — PowerShell encoded command (likely FP)",rule:"EP-PS-007",user:"priya.kapoor@vantara.io",src:"10.0.2.41",time:"2025-05-15T11:22:00",tactic:"Execution",tech:"T1059.001",case:null,
    desc:"powershell.exe -EncodedCommand on VANT-PK-001. Parent: code.exe (VS Code). Decoded to benign npm install. Likely false positive — pending review."},
  {id:"ALT-5529",sev:"critical",status:"open",title:"Threat intel feed — sender IP matches FS-ISAC PHANTOM-07 campaign",rule:"TI-MATCH-009",user:"GATEWAY",src:PHISH_IP,time:"2025-05-15T03:19:01",tactic:"Initial Access",tech:"T1566.001",case:"INC-2025-0312",
    desc:`${PHISH_IP} matched FS-ISAC feed (submitted 2025-05-13 by Barclays). Campaign: 'DocuSign-themed enterprise credential harvest, UK financial sector'. TLP:AMBER.`},
];

const CASE = {
  id:"INC-2025-0312",title:"Spear-Phishing Campaign — DocuSign Impersonation (TA-PHANTOM-07)",
  status:"In Progress",sev:"High",priority:"P1",sla:"2025-05-16T07:45:00",
  assignee:"John Mercer",created:"2025-05-15T07:45:00",updated:"2025-05-16T10:22:00",
  reporter:"SIEM Auto-Triage (ALT-5521 + ALT-5529)",
  affectedUsers:["john.mercer@vantara.io","priya.kapoor@vantara.io"],
  affectedAssets:["mx1.vantara.io","VANT-JM-001","VANT-PK-001"],
  tags:["phishing","credential-harvesting","docusign-spoof","mfa-fatigue","tor-infrastructure","ta-phantom-07"],
  mitre:["T1566.001","T1598.003","T1090.003","T1110.004","T1078","T1027"],
  summary:`At 03:18 UTC on 15 May 2025, a targeted spear-phishing email impersonating DocuSign was delivered to john.mercer@vantara.io through the Vantara mail gateway. The message passed below the quarantine threshold (spam score 8.4 vs threshold 9.0) despite triple authentication failure (SPF/DKIM/DMARC). The sending IP (${PHISH_IP}) is attributed to a Tor exit-node operated by OVH SAS Romania and was independently flagged in an FS-ISAC threat-intel feed submitted by Barclays Bank on 2025-05-13.\n\nA second recipient (priya.kapoor@vantara.io) submitted a phishing report at 09:12 UTC confirming the campaign targeted at least two employees. DNS proxy logs indicate john.mercer's workstation issued a query to the phishing harvest domain (${HARVEST}) at 07:44 UTC — the query was blocked and no HTTP connection was established.\n\nAt 10:45–10:48 UTC, three consecutive MFA push notifications were sent to john.mercer from the attacker IP, suggesting credentials may have been captured. All pushes were denied. Azure AD sign-in logs show no successful attacker authentication. Current assessment: no confirmed credential compromise. IOCs contained.`,
};

const TIMELINE_EVENTS = [
  {time:"2025-05-15T03:18:44",phase:"delivery",actor:"Threat Actor (185.220.101.52)",evt:"Phishing email injected via Tor exit-node. SPF FAIL · DKIM FAIL · DMARC FAIL. Spam score 8.4 — below 9.0 quarantine threshold. Message passed to inbox.",sev:"critical",mitre:"T1566.001"},
  {time:"2025-05-15T03:18:45",phase:"detection",actor:"mx1.vantara.io",evt:"Mail gateway logged auth failures. Event forwarded to SIEM. Message not quarantined due to threshold gap.",sev:"high",mitre:""},
  {time:"2025-05-15T03:19:01",phase:"detection",actor:"Vantara-Sentinel SIEM",evt:"Correlation rule PHISH-044 fired. TI match ALT-5529 fired on FS-ISAC feed. Case INC-2025-0312 auto-created.",sev:"high",mitre:""},
  {time:"2025-05-15T07:44:12",phase:"victim-activity",actor:"john.mercer@vantara.io (VANT-JM-001)",evt:`Workstation queried ${HARVEST}. Proxy blocked subdomain follow-up. No HTTP connection — indicates user hovered over phishing link in email client.`,sev:"high",mitre:"T1598"},
  {time:"2025-05-15T07:45:00",phase:"triage",actor:"SOC Tier-1 Auto-Triage",evt:"Alert triaged. Severity escalated to HIGH-P1. Assigned to John Mercer (L2). SLA: 24h.",sev:"medium",mitre:""},
  {time:"2025-05-15T08:00:00",phase:"investigation",actor:"John Mercer (Analyst)",evt:"Investigation initiated. Email headers extracted. SPF/DKIM/DMARC failures confirmed. X-Campaign-ID header noted.",sev:"low",mitre:""},
  {time:"2025-05-15T08:05:00",phase:"investigation",actor:"John Mercer (Analyst)",evt:"IOCs extracted. Phishing URL submitted to VirusTotal: 17/92 detections. Sender domain and harvest domain submitted.",sev:"low",mitre:""},
  {time:"2025-05-15T08:22:00",phase:"investigation",actor:"John Mercer (Analyst)",evt:`WHOIS: esign-secure.net and account-secure.net both registered 2025-04-28 via NameSilo (privacy-protected) — 17 days before attack. Coordinated infrastructure provisioning.`,sev:"medium",mitre:""},
  {time:"2025-05-15T08:45:00",phase:"containment",actor:"John Mercer (Analyst)",evt:`IOCs added to perimeter firewall block-list and email gateway deny-list. DNS sinkhole activated for ${HARVEST} on internal resolvers.`,sev:"medium",mitre:""},
  {time:"2025-05-15T09:00:00",phase:"remediation",actor:"John Mercer (Analyst)",evt:"Victim notification sent to john.mercer@vantara.io. No confirmed URL click in proxy logs.",sev:"low",mitre:""},
  {time:"2025-05-15T09:12:00",phase:"discovery",actor:"priya.kapoor@vantara.io",evt:"Second victim submitted phishing report. Same sender domain. Campaign confirmed multi-target. Quarantine action executed.",sev:"high",mitre:"T1566.001"},
  {time:"2025-05-15T10:45:00",phase:"escalation",actor:`Threat Actor (${PHISH_IP})`,evt:"MFA fatigue attack: 3 consecutive Authenticator push requests over 3 minutes. ALL DENIED by user. ALT-5525 raised.",sev:"critical",mitre:"T1110.004"},
  {time:"2025-05-15T10:55:00",phase:"containment",actor:"John Mercer (Analyst)",evt:"Azure AD CA policy updated: block auth from Tor range 185.220.101.0/24. Password reset initiated as precaution.",sev:"medium",mitre:""},
  {time:"2025-05-16T10:22:00",phase:"reporting",actor:"John Mercer (Analyst)",evt:"IOCs shared with FS-ISAC under TLP:AMBER. 7-day Azure AD log review pending. Status: In Progress.",sev:"low",mitre:""},
];

const IOCS_INIT = [
  {id:"IOC-001",type:"IPv4",value:PHISH_IP,conf:"High",tlp:"AMBER",status:"active",source:"Mail Header",tags:["tor-exit","bulletproof"],added:"2025-05-15T07:50:00",ctx:"Sending IP. OVH SAS Romania. Tor exit node. AbuseIPDB: 98%."},
  {id:"IOC-002",type:"Domain",value:PHISH_DOM,conf:"High",tlp:"AMBER",status:"active",source:"Mail Header",tags:["sender-spoof"],added:"2025-05-15T07:51:00",ctx:"Sender domain. Registered 2025-04-28. NameSilo privacy. 17 days old."},
  {id:"IOC-003",type:"Domain",value:HARVEST,conf:"High",tlp:"RED",status:"contained",source:"URL Extraction",tags:["credential-harvest"],added:"2025-05-15T07:52:00",ctx:"Harvest domain. DNS sinkholed at 10:22 UTC."},
  {id:"IOC-004",type:"URL",value:PHISH_URL,conf:"High",tlp:"RED",status:"contained",source:"Email Body",tags:["phishing-kit"],added:"2025-05-15T07:53:00",ctx:"Active phishing URL. VT: 17/92. Blocked at perimeter."},
  {id:"IOC-005",type:"Email",value:PHISH_FROM,conf:"High",tlp:"AMBER",status:"active",source:"Mail Header",tags:["sender-spoof"],added:"2025-05-15T07:54:00",ctx:"Attacker sender. Impersonates DocuSign."},
  {id:"IOC-006",type:"Email",value:"support@esign-helpdesk.org",conf:"Medium",tlp:"AMBER",status:"active",source:"Reply-To Header",tags:["reply-harvest"],added:"2025-05-15T08:05:00",ctx:"Reply-To exfiltration address. Victim replies route to attacker."},
  {id:"IOC-007",type:"Domain",value:"esign-helpdesk.org",conf:"Medium",tlp:"AMBER",status:"active",source:"Reply-To Header",tags:["phishing-infra"],added:"2025-05-15T08:06:00",ctx:"Reply-To domain. Same registrar/date as esign-secure.net."},
  {id:"IOC-008",type:"String",value:"phish-docusign-ent-052025-b",conf:"High",tlp:"AMBER",status:"active",source:"X-Campaign-ID Header",tags:["campaign-id"],added:"2025-05-15T08:15:00",ctx:"Campaign ID. Matches Barclays FS-ISAC report pattern."},
  {id:"IOC-009",type:"ASN",value:"AS3214 (OVH SAS Romania)",conf:"Medium",tlp:"WHITE",status:"active",source:"IP WHOIS",tags:["infrastructure"],added:"2025-05-15T08:20:00",ctx:"ASN hosting Tor exit and attacker infra."},
  {id:"IOC-010",type:"Hash-MD5",value:"d41d8cd98f00b204e9800998ecf8427e",conf:"Low",tlp:"WHITE",status:"inactive",source:"MIME Analysis",tags:[],added:"2025-05-15T08:22:00",ctx:"Message body hash. No attachments in phishing email."},
];

const NOTES_INIT = [
  {id:"N001",author:"John Mercer",role:"L2",time:"2025-05-15T08:10:00",content:`VirusTotal results for ${PHISH_IP}: 14/94 vendors flagged malicious. AbuseIPDB confidence 98%. Confirmed Tor exit node (dan.me.uk/torlist). IP in active use since July 2023. Passive DNS links to smtp-relay-47.net and bounce-mailer-eu.net.`,tags:["osint","ip-analysis"]},
  {id:"N002",author:"John Mercer",role:"L2",time:"2025-05-15T08:30:00",content:`Domain registration: ${PHISH_DOM} and ${HARVEST} both registered 2025-04-28 via NameSilo (privacy-protected). Also esign-helpdesk.org — same date, same registrar. All three almost certainly provisioned in a single operation 17 days before the attack.`,tags:["whois","domain-analysis"]},
  {id:"N003",author:"Sarah Okafor",role:"SOC Lead",time:"2025-05-15T09:45:00",content:"Peer review complete. Solid analysis. Additional note: X-Campaign-ID header 'phish-docusign-ent-052025-b' — the 'ent-052025' string suggests this is campaign 'b' of a series. Check FS-ISAC for 'phish-docusign-ent-052025-a'. Barclays submission (13 May) likely campaign 'a'.",tags:["peer-review","campaign-analysis"]},
  {id:"N004",author:"John Mercer",role:"L2",time:"2025-05-15T10:05:00",content:"FS-ISAC search: Barclays submission 2025-05-13 references 'docusign-ent-052025-a' against UK financial sector. Same IP subnet (185.220.101.0/24). Vantara is campaign target 'b'. Escalated to FS-ISAC for full deconfliction.",tags:["threat-intel","campaign-correlation"]},
  {id:"N005",author:"John Mercer",role:"L2",time:"2025-05-16T10:22:00",content:`Azure AD logs reviewed for 48h window. No successful auth from ${PHISH_IP} or Romanian IP range. All MFA pushes denied. Provisional: no credential compromise. Password reset issued as precaution. 7-day extended review pending.`,tags:["azure-ad","credential-check"]},
];

const EVIDENCE = [
  {id:"EV001",name:"Phishing email — raw EML export",type:"email",hash:"sha256:3f7a9c2e1b4d8f0e6c5a3b2d9e7f1a4c6b8e2f0d",size:"14.2 KB",added:"2025-05-15T08:00:00",chain:"John Mercer → Case"},
  {id:"EV002",name:"Email header analysis report",type:"report",hash:"sha256:7b2e4f1d9c8a5e3b0f7d2c9a6e4b1f8d3c9e5a1b",size:"88 KB",added:"2025-05-15T08:18:00",chain:"John Mercer → Case"},
  {id:"EV003",name:"VirusTotal report — phishing URL",type:"report",hash:"sha256:9d4c7f2a1e8b5c3a6f0d2e9c7b4a1f3e2d8c6b4a",size:"34 KB",added:"2025-05-15T08:08:00",chain:"John Mercer → Case"},
  {id:"EV004",name:"WHOIS records — esign-secure.net, account-secure.net, esign-helpdesk.org",type:"osint",hash:"sha256:2c8e5b3a9f1d7c4e0b6a3f9d2e7c5b1a4f8e3d2c",size:"7.1 KB",added:"2025-05-15T08:26:00",chain:"John Mercer → Case"},
  {id:"EV005",name:"Proxy log extract — VANT-JM-001 (15 May 00:00–24:00)",type:"logs",hash:"sha256:5a1f8e3c7b9d4a2e6f0c8b5a3d1e9f7c2b4d6e8a",size:"2.3 MB",added:"2025-05-15T09:07:00",chain:"SIEM Export → John Mercer → Case"},
  {id:"EV006",name:"Azure AD sign-in logs (48h window)",type:"logs",hash:"sha256:8f2c6a4e1b9d7f3c5a0e2b8f6c4a1e9d3b7f5c2a",size:"1.9 MB",added:"2025-05-16T10:17:00",chain:"Azure AD Export → John Mercer → Case"},
  {id:"EV007",name:"MFA push notification logs (ALT-5525)",type:"logs",hash:"sha256:4d9b3e7f2c1a6e8d5b0f4c2a9d7e3b1f6c8a5d2e",size:"4.2 KB",added:"2025-05-15T11:05:00",chain:"Azure AD Export → John Mercer → Case"},
  {id:"EV008",name:"FS-ISAC TI report — PHANTOM-07 / docusign-ent-052025",type:"threat-intel",hash:"sha256:1e6f9c4b8a3d7e2f5c0b4a9d2e7c5b3f8e1d4c7a",size:"156 KB",added:"2025-05-16T09:30:00",chain:"FS-ISAC Share → John Mercer → Case"},
];

const AUTH_LOGS = [
  {time:"2025-05-15T03:18:44",user:"john.mercer@vantara.io",action:"Email Received",src:PHISH_IP,loc:"Bucharest, RO",device:"—",result:"DELIVERED",risk:"critical",note:"Inbound from Tor exit node. SPF/DKIM/DMARC FAIL"},
  {time:"2025-05-15T07:44:12",user:"john.mercer@vantara.io",action:"DNS Query",src:"10.0.1.22",loc:"Vantara HQ",device:"VANT-JM-001",result:"QUERY LOGGED",risk:"medium",note:`Workstation queried ${HARVEST}. No HTTP connection.`},
  {time:"2025-05-15T08:30:01",user:"john.mercer@vantara.io",action:"Azure AD Sign-in",src:"82.163.44.99",loc:"London, GB",device:"VANT-JM-001",result:"SUCCESS + MFA",risk:"low",note:"New external IP. MFA satisfied. Possible WFH."},
  {time:"2025-05-15T10:45:02",user:"john.mercer@vantara.io",action:"MFA Push",src:PHISH_IP,loc:"Bucharest, RO",device:"Unknown",result:"DENIED",risk:"critical",note:"Push denied. Attempt 1/3."},
  {time:"2025-05-15T10:46:44",user:"john.mercer@vantara.io",action:"MFA Push",src:PHISH_IP,loc:"Bucharest, RO",device:"Unknown",result:"DENIED",risk:"critical",note:"Push denied. Attempt 2/3."},
  {time:"2025-05-15T10:48:11",user:"john.mercer@vantara.io",action:"MFA Push",src:PHISH_IP,loc:"Bucharest, RO",device:"Unknown",result:"DENIED",risk:"critical",note:"Push denied. Attempt 3/3. ALT-5525 raised."},
  {time:"2025-05-15T09:12:00",user:"priya.kapoor@vantara.io",action:"Phish Report",src:"10.0.2.41",loc:"Vantara HQ",device:"VANT-PK-001",result:"SUBMITTED",risk:"medium",note:"User submitted DocuSign email to PhishAlert."},
];

const PROXY_LOGS = [
  {time:"2025-05-15T07:44:12",user:"john.mercer",host:"VANT-JM-001",action:"DNS_QUERY",url:HARVEST,cat:"Uncategorised",blocked:false,risk:"high",note:"Domain age 17 days. No prior history. No HTTP follow-through."},
  {time:"2025-05-15T07:44:13",user:"john.mercer",host:"VANT-JM-001",action:"DNS_QUERY",url:`docusign-esign-verify.${HARVEST}`,cat:"Uncategorised",blocked:true,risk:"critical",note:"Subdomain query. Blocked by proxy (newly-registered domain policy)."},
  {time:"2025-05-15T09:15:40",user:"john.mercer",host:"VANT-JM-001",action:"GET",url:"https://www.virustotal.com/gui/url/search",cat:"Security Tools",blocked:false,risk:"none",note:"Analyst enrichment — VirusTotal URL search."},
  {time:"2025-05-15T10:20:00",user:"priya.kapoor",host:"VANT-PK-001",action:"DNS_QUERY",url:HARVEST,cat:"Uncategorised",blocked:true,risk:"high",note:"Second user querying phishing domain. Tenant-wide block applied."},
  {time:"2025-05-14T14:30:00",user:"john.mercer",host:"VANT-JM-001",action:"GET",url:"https://github.com/vantara-solutions/client-portal/pull/341",cat:"Software Development",blocked:false,risk:"none",note:"Normal developer activity."},
];

const MITRE_TTPS = [
  {id:"T1566.001",name:"Spear-Phishing Link",tactic:"Initial Access",status:"confirmed",color:"#F87171",desc:"Targeted phishing email containing malicious DocuSign credential-harvest link. Personalised with recipient email in URL parameter.",evidence:["em002 — phishing email with harvest URL","ALT-5521 — SIEM detection","ALT-5529 — TI feed match"]},
  {id:"T1598.003",name:"Phishing for Information: Link",tactic:"Reconnaissance",status:"confirmed",color:"#F87171",desc:"Malicious URL designed to harvest Microsoft 365 credentials via fake DocuSign portal.",evidence:["IOC-004 — phishing URL","PROXY-002 — DNS blocked","VT: 17/92"]},
  {id:"T1090.003",name:"Proxy: Multi-hop Proxy",tactic:"Command & Control",status:"confirmed",color:"#FB923C",desc:"Attacker used Tor exit-node infrastructure to anonymise campaign origin and prevent IP attribution.",evidence:["IOC-001 — Tor exit node","ALT-5521 — sender IP","AbuseIPDB 98%"]},
  {id:"T1110.004",name:"Credential Stuffing / MFA Fatigue",tactic:"Credential Access",status:"confirmed",color:"#F87171",desc:"Following phishing delivery, attacker initiated MFA fatigue attack with 3 push notifications in 3 minutes. Suggests credentials were obtained from prior compromise.",evidence:["ALT-5525 — 3× MFA denial","AUTH-LOG 10:45–10:48"]},
  {id:"T1078",name:"Valid Accounts",tactic:"Defense Evasion",status:"suspected",color:"#FBBF24",desc:"MFA fatigue attempt implies attacker possessed valid username/password. If approved, adversary would have authenticated with legitimate credentials.",evidence:["ALT-5525","ALT-5524 — Azure AD anomaly"]},
  {id:"T1027",name:"Obfuscated Files or Information",tactic:"Defense Evasion",status:"confirmed",color:"#FB923C",desc:"URL parameter id=NDA3MjExOTU= is Base64-encoded victim tracking ID, obfuscating victim enumeration in the phishing kit backend.",evidence:["em002 — URL analysis","Base64 decode: 407211950"]},
];

const THREAT_ACTOR = {
  id:"TA-PHANTOM-07",name:"PHANTOM-07",aka:["Phantom Lure","DocuPhish-EU"],
  motivation:"Financial — Credential harvesting for Business Email Compromise",
  origin:"Eastern Europe (assessed)",confidence:"Medium",
  firstSeen:"2024-11-12",lastSeen:"2025-05-15",
  sectors:["Financial Services","Professional Services","Legal","Consulting"],
  ttps:["T1566.001","T1598.003","T1090.003","T1110.004","T1078.004"],
  infra:[PHISH_DOM,HARVEST,"esign-helpdesk.org","docu-sign-notify.net (2025-01)","ds-contract-verify.com (2024-11)"],
  desc:"PHANTOM-07 is an assessed financially-motivated threat group conducting targeted spear-phishing campaigns against professional-services organisations in Western Europe. The group consistently impersonates trusted SaaS platforms (DocuSign, Adobe Sign, Microsoft 365) with purpose-registered spoofing domains provisioned 2–3 weeks before use. MFA fatigue follow-up attacks suggest a credential re-use pipeline. No confirmed ransomware or data-exfiltration stage observed — likely BEC-focused.",
  campaigns:[
    {date:"2025-05-13",target:"Barclays Bank PLC",vector:"DocuSign spoof",result:"Blocked"},
    {date:"2025-03-01",target:"Clifford Chance LLP",vector:"Adobe Sign spoof",result:"1 credential captured"},
    {date:"2024-11-12",target:"PwC UK",vector:"DocuSign spoof",result:"Blocked"},
  ],
};

const ENRICH = {
  [PHISH_IP]:{type:"ip",vt:"14/94",vtLabel:"Malicious",abuse:98,asn:"AS3214 OVH SAS",country:"Romania",city:"Bucharest",isTor:true,registrar:null,registered:null,registrant:null,categories:["Phishing","C2","Spam"],passivedns:[PHISH_DOM,"bounce-mailer-eu.net","smtp-relay-47.net"],summary:"Tor exit node with persistent malicious history. Associated with 3+ phishing campaigns. OVH Romania bulletproof hosting."},
  [PHISH_DOM]:{type:"domain",vt:"17/94",vtLabel:"Malicious",abuse:null,asn:null,country:"Romania",city:null,isTor:false,registrar:"NameSilo LLC",registered:"2025-04-28",registrant:"REDACTED (privacy)",categories:["Phishing","New Domain"],passivedns:[],summary:"Purpose-registered phishing domain. 17 days old at attack. Same registrar/date as harvest domain."},
  [HARVEST]:{type:"domain",vt:"17/92",vtLabel:"Malicious",abuse:null,asn:null,country:"Romania",city:null,isTor:false,registrar:"NameSilo LLC",registered:"2025-04-28",registrant:"REDACTED (privacy)",categories:["Phishing","Credential Harvesting"],passivedns:[`docusign-esign-verify.${HARVEST}`],summary:"Credential harvest domain. Full DocuSign phishing kit. DNS sinkholed by Vantara at 10:22 UTC 2025-05-15."},
};

// ─── UTILS ────────────────────────────────────────────────────────────────────
function useWidth() {
  const [w, setW] = useState(() => typeof window !== "undefined" ? window.innerWidth : 1280);
  useEffect(() => {
    const fn = () => setW(window.innerWidth);
    window.addEventListener("resize", fn);
    return () => window.removeEventListener("resize", fn);
  }, []);
  return w;
}
function useClock() {
  const [t, setT] = useState(() => new Date().toLocaleTimeString("en-GB", {hour:"2-digit",minute:"2-digit",second:"2-digit"}));
  useEffect(() => {
    const i = setInterval(() => setT(new Date().toLocaleTimeString("en-GB", {hour:"2-digit",minute:"2-digit",second:"2-digit"})), 1000);
    return () => clearInterval(i);
  }, []);
  return t;
}
// NOW is always the real current time — no hardcoded date
function fmtAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const d = Math.floor(diff/86400000), h = Math.floor(diff/3600000), m = Math.floor(diff/60000);
  if (d > 6) return new Date(iso).toLocaleDateString("en-GB",{day:"numeric",month:"short"});
  if (d >= 1) return `${d}d ago`; if (h >= 1) return `${h}h ago`; return `${m}m ago`;
}
function fmtFull(iso) { return new Date(iso).toLocaleString("en-GB",{weekday:"short",day:"numeric",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}); }
function fmtTs(iso) { return new Date(iso).toLocaleString("en-GB",{day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}); }
function fmtShort(iso) { return new Date(iso).toLocaleString("en-GB",{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"}); }
function inits(n) { return n.split(" ").map(x=>x[0]).join("").slice(0,2).toUpperCase(); }

// ─── DESIGN TOKENS ────────────────────────────────────────────────────────────
const SEV_T = {
  critical:{ bg:"#1C0808", border:"#7F1D1D", text:"#FCA5A5", dot:"#F87171", label:"CRITICAL" },
  high:    { bg:"#1C1008", border:"#7C2D12", text:"#FED7AA", dot:"#FB923C", label:"HIGH" },
  medium:  { bg:"#1C1A08", border:"#713F12", text:"#FEF08A", dot:"#FACC15", label:"MEDIUM" },
  low:     { bg:"#081C10", border:"#14532D", text:"#86EFAC", dot:"#4ADE80", label:"LOW" },
  info:    { bg:"#08101C", border:"#1E3A5F", text:"#93C5FD", dot:"#60A5FA", label:"INFO" },
  none:    { bg:"var(--card)", border:"var(--border)", text:"var(--text3)", dot:"var(--text3)", label:"NONE" },
};
const PHASE_C = { delivery:"#F87171",detection:"#FB923C","victim-activity":"#FACC15",triage:"#A78BFA",investigation:"#38BDF8",containment:"#FACC15",remediation:"#4ADE80",escalation:"#F87171",discovery:"#FB923C",reporting:"#94A3B8" };
const TLP_T = { RED:{bg:"#1C0808",text:"#FCA5A5"}, AMBER:{bg:"#1C1008",text:"#FED7AA"}, GREEN:{bg:"#081C10",text:"#86EFAC"}, WHITE:{bg:"var(--card)",text:"var(--text2)"} };

// ─── PRIMITIVES ───────────────────────────────────────────────────────────────
function SevBadge({ level, sm }) {
  const s = SEV_T[(level||"").toLowerCase()] || SEV_T.info;
  const p = sm ? "1px 7px" : "2px 9px";
  const fs = sm ? 9 : 10;
  return <span className="tag" style={{ background:s.bg, color:s.text, border:`1px solid ${s.border}`, padding:p, fontSize:fs, gap:5 }}>
    <span style={{ width:5, height:5, borderRadius:"50%", background:s.dot, display:"inline-block", flexShrink:0 }} />
    {s.label}
  </span>;
}

function StatusBadge({ status }) {
  const C = { open:SEV_T.high, investigating:SEV_T.medium, resolved:SEV_T.low };
  const s = C[status] || SEV_T.info;
  return <span className="tag" style={{ background:s.bg, color:s.text, border:`1px solid ${s.border}`, padding:"1px 7px", fontSize:9 }}>{status.toUpperCase()}</span>;
}

function TlpBadge({ tlp }) {
  const t = TLP_T[tlp] || TLP_T.WHITE;
  return <span className="tag" style={{ background:t.bg, color:t.text, border:"1px solid "+t.text+"40", padding:"1px 7px", fontSize:9 }}>TLP:{tlp}</span>;
}

function Avatar({ name, size=32, accent=false }) {
  return <div style={{ width:size, height:size, borderRadius:"50%", background: accent ? "rgba(56,189,248,0.15)" : "var(--card-hi)", border:"1px solid "+(accent?"rgba(56,189,248,0.4)":"var(--border-hi)"), display:"flex", alignItems:"center", justifyContent:"center", fontSize:Math.round(size*0.33), fontWeight:700, color: accent?"var(--accent)":"var(--text2)", fontFamily:"var(--mono)", flexShrink:0, letterSpacing:"0.05em" }}>
    {inits(name)}
  </div>;
}

function Chip({ children, color }) {
  return <span className="tag" style={{ background:color+"18", color, border:"1px solid "+color+"40", padding:"1px 8px", fontSize:9 }}>{children}</span>;
}

function PulseIcon({ color="#4ADE80" }) {
  return <span className="pulse" style={{ display:"inline-block", width:7, height:7, borderRadius:"50%", background:color, flexShrink:0 }} />;
}

function SectionHead({ children, sub }) {
  return <div style={{ marginBottom:14 }}>
    <h3 style={{ fontSize:11, fontWeight:600, color:"var(--text2)", letterSpacing:"0.08em", fontFamily:"var(--mono)", textTransform:"uppercase" }}>{children}</h3>
    {sub && <p style={{ fontSize:11, color:"var(--text3)", marginTop:3 }}>{sub}</p>}
  </div>;
}

function Card({ children, style:s, danger, accent }) {
  const border = danger ? "var(--red-dim)" : accent ? "rgba(56,189,248,0.3)" : "var(--border)";
  return <div style={{ background:"var(--card)", border:`1px solid ${border}`, borderRadius:8, overflow:"hidden", ...s }}>{children}</div>;
}

function CardHead({ icon, title, right, danger }) {
  return <div style={{ display:"flex", alignItems:"center", gap:8, padding:"10px 16px", borderBottom:"1px solid var(--border)", background:"var(--card-hi)" }}>
    {icon && <i className={`ti ${icon}`} style={{ fontSize:13, color: danger ? "var(--red)" : "var(--accent)", flexShrink:0 }} aria-hidden="true" />}
    <span style={{ fontSize:10, fontWeight:700, letterSpacing:"0.1em", fontFamily:"var(--mono)", color:"var(--text2)", flex:1, textTransform:"uppercase" }}>{title}</span>
    {right && <span style={{ fontSize:10, color:"var(--text3)" }}>{right}</span>}
  </div>;
}

function BtnPrimary({ children, onClick, icon, sm, danger, amber }) {
  const bg = danger ? "rgba(248,113,113,0.12)" : amber ? "rgba(245,158,11,0.12)" : "rgba(56,189,248,0.12)";
  const border = danger ? "#7F1D1D" : amber ? "#78350F" : "rgba(56,189,248,0.35)";
  const color = danger ? "var(--red)" : amber ? "var(--amber)" : "var(--accent)";
  const [hov, setHov] = useState(false);
  return <button onClick={onClick} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
    style={{ display:"inline-flex", alignItems:"center", gap:5, padding: sm?"5px 12px":"7px 16px", borderRadius:6, border:`1px solid ${border}`, background: hov ? bg+"cc" : bg, color, fontSize: sm?10:11, fontWeight:600, cursor:"pointer", fontFamily:"var(--ui)", transition:"background 0.15s", whiteSpace:"nowrap" }}>
    {icon && <i className={`ti ${icon}`} style={{ fontSize: sm?12:13 }} aria-hidden="true" />}
    {children}
  </button>;
}

function BtnGhost({ children, onClick, icon, sm }) {
  const [hov, setHov] = useState(false);
  return <button onClick={onClick} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
    style={{ display:"inline-flex", alignItems:"center", gap:5, padding: sm?"5px 10px":"7px 14px", borderRadius:6, border:"1px solid var(--border)", background: hov ? "var(--card-hi)" : "transparent", color:"var(--text2)", fontSize: sm?10:11, fontWeight:500, cursor:"pointer", fontFamily:"var(--ui)", transition:"background 0.15s", whiteSpace:"nowrap" }}>
    {icon && <i className={`ti ${icon}`} style={{ fontSize: sm?12:13 }} aria-hidden="true" />}
    {children}
  </button>;
}

function MetricCard({ label, value, icon, color, sub }) {
  return <div style={{ background:"var(--card)", border:"1px solid var(--border)", borderRadius:8, padding:"14px 16px" }}>
    <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8 }}>
      <div style={{ width:28, height:28, borderRadius:6, background:color+"18", border:"1px solid "+color+"30", display:"flex", alignItems:"center", justifyContent:"center" }}>
        <i className={`ti ${icon}`} style={{ color, fontSize:14 }} aria-hidden="true" />
      </div>
      <span style={{ fontSize:10, fontWeight:600, color:"var(--text3)", letterSpacing:"0.08em", fontFamily:"var(--mono)", textTransform:"uppercase" }}>{label}</span>
    </div>
    <div style={{ fontSize:26, fontWeight:700, color, fontFamily:"var(--mono)", lineHeight:1, marginBottom:sub?4:0 }}>{value}</div>
    {sub && <div style={{ fontSize:10, color:"var(--text3)", marginTop:4 }}>{sub}</div>}
  </div>;
}

// RiskBar — pure inline styles, animated via useEffect + requestAnimationFrame
// Zero CSS class dependency. Works regardless of CSP or build cache.
function RiskBar({ risk, color }) {
  const fillRef = useRef(null);
  useEffect(() => {
    const el = fillRef.current;
    if (!el) return;
    // Set the color immediately (safe — not a keyframe, just a property)
    el.style.background = color;
    // Animate width from 0 → target using rAF
    const target = risk;
    let current = 0;
    const step = target / 30; // reach target in ~30 frames (~500ms at 60fps)
    let raf;
    function animate() {
      current = Math.min(current + step, target);
      el.style.width = current + "%";
      if (current < target) raf = requestAnimationFrame(animate);
    }
    // Small delay so element is in DOM and has layout
    const t = setTimeout(() => { raf = requestAnimationFrame(animate); }, 80);
    return () => { clearTimeout(t); cancelAnimationFrame(raf); };
  }, [risk, color]);
  return (
    <div style={{ height:3, background:"var(--border)", borderRadius:2, overflow:"hidden" }}>
      <div ref={fillRef} style={{ height:"100%", width:"0%", borderRadius:2 }} />
    </div>
  );
}

function KvRow({ k, v, mono, hi, copy }) {
  const [cp, setCp] = useState(false);
  return <div style={{ display:"flex", gap:8, padding:"6px 0", borderBottom:"1px solid var(--border)", alignItems:"flex-start" }}>
    <span style={{ fontSize:10, color:"var(--text3)", fontFamily:"var(--mono)", fontWeight:600, letterSpacing:"0.04em", minWidth:130, flexShrink:0, paddingTop:1, textTransform:"uppercase" }}>{k}</span>
    <span style={{ fontSize:11.5, color: hi ? "var(--amber)" : "var(--text1)", fontFamily: mono ? "var(--mono)" : "var(--ui)", flex:1, wordBreak:"break-all", lineHeight:1.5 }}>{v}</span>
    {copy && <i className="ti ti-copy" onClick={()=>{navigator.clipboard?.writeText(v);setCp(true);setTimeout(()=>setCp(false),1500);}} style={{ fontSize:11, color:cp?"var(--green)":"var(--text3)", cursor:"pointer", flexShrink:0, marginTop:1 }} aria-hidden="true" />}
  </div>;
}

// ─── VANTARA LOGO ─────────────────────────────────────────────────────────────
function VantaraLogo({ compact = false, size = "nav" }) {
  // size: "nav" (header), "sidebar" (mail sidebar)
  const isSidebar = size === "sidebar";
  return (
    <div style={{ display:"flex", alignItems:"center", gap: isSidebar?10:8, userSelect:"none" }}>
      {/* Shield + V mark SVG */}
      <svg width={isSidebar?32:26} height={isSidebar?32:26} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Vantara SOC logo" role="img">
        <defs>
          <linearGradient id="shieldGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.9"/>
            <stop offset="100%" stopColor="#0EA5E9" stopOpacity="0.7"/>
          </linearGradient>
          <linearGradient id="glowGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.3"/>
            <stop offset="100%" stopColor="#38BDF8" stopOpacity="0"/>
          </linearGradient>
        </defs>
        {/* Outer shield */}
        <path d="M16 2L4 7V15.5C4 21.85 9.33 27.74 16 30C22.67 27.74 28 21.85 28 15.5V7L16 2Z"
          fill="url(#shieldGrad)" fillOpacity="0.12" stroke="url(#shieldGrad)" strokeWidth="1.2" strokeLinejoin="round"/>
        {/* Inner glow layer */}
        <path d="M16 4.5L6 9V15.5C6 20.7 10.5 25.6 16 27.7C21.5 25.6 26 20.7 26 15.5V9L16 4.5Z"
          fill="url(#glowGrad)"/>
        {/* V letterform */}
        <path d="M10.5 11.5L14.8 20.5H17.2L21.5 11.5H19L16 17.8L13 11.5H10.5Z"
          fill="#38BDF8" fillOpacity="0.95"/>
        {/* Top shine dot */}
        <circle cx="22" cy="9" r="2" fill="#38BDF8" fillOpacity="0.6"/>
      </svg>

      {/* Wordmark — hidden on compact mobile */}
      {!compact && (
        <div style={{ lineHeight:1 }}>
          <div style={{ display:"flex", alignItems:"baseline", gap: isSidebar?4:3 }}>
            <span style={{
              fontSize: isSidebar?14:12,
              fontWeight:800,
              color:"var(--text1)",
              letterSpacing: isSidebar?"-0.01em":"0.01em",
              fontFamily:"var(--ui)"
            }}>Vantara</span>
            <span style={{
              fontSize: isSidebar?9:8,
              fontWeight:700,
              color:"var(--accent)",
              letterSpacing:"0.12em",
              fontFamily:"var(--mono)",
              opacity:0.9,
              paddingBottom:1
            }}>SOC</span>
          </div>
          {isSidebar && (
            <div style={{ fontSize:8, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.1em", marginTop:2 }}>
              SECURITY OPERATIONS
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── TICKER BANNER ───────────────────────────────────────────────────────────
// Pure JS animation — translates a div using requestAnimationFrame.
// No CSS keyframes, no className, no style injection. Works in any environment.
function TickerBanner({ feed }) {
  const trackRef = useRef(null);
  const posRef   = useRef(0);
  const rafRef   = useRef(null);
  const pausedRef = useRef(false);
  const widthRef  = useRef(0);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    const el = trackRef.current;
    if (!el) return;

    // Measure half-width (content is doubled, so we scroll exactly one copy)
    function getHalfWidth() {
      return el.scrollWidth / 2;
    }

    // Speed: pixels per frame at 60fps ≈ 32s per full scroll
    const PX_PER_FRAME = 0.9;

    function tick() {
      if (!pausedRef.current && !expanded) {
        const half = getHalfWidth() || 1;
        posRef.current += PX_PER_FRAME;
        if (posRef.current >= half) posRef.current = 0;
        el.style.transform = "translateX(-" + posRef.current + "px)";
      }
      rafRef.current = requestAnimationFrame(tick);
    }

    rafRef.current = requestAnimationFrame(tick);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [expanded]);

  const items = [...feed, ...feed];

  return (
    <div style={{ background:"var(--card)", border:"1px solid var(--border)", borderRadius:7, overflow:"hidden" }}>
      <div style={{ padding:"6px 14px", display:"flex", alignItems:"center", gap:12 }}>
        <div style={{ display:"flex", alignItems:"center", gap:6, flexShrink:0 }}>
          <PulseIcon color="var(--red)" />
          <span style={{ fontSize:9, fontWeight:700, color:"var(--red)", fontFamily:"var(--mono)", letterSpacing:"0.1em" }}>LIVE</span>
        </div>
        <div
          style={{ flex:1, overflow:"hidden", position:"relative" }}
          onMouseEnter={() => { pausedRef.current = true; labAction("ticker-paused"); }}
          onMouseLeave={() => { pausedRef.current = false; }}
        >
          <div
            ref={trackRef}
            style={{ display:"inline-flex", gap:0, willChange:"transform", whiteSpace:"nowrap" }}
          >
            {items.map((f, i) => (
              <span key={i} style={{ fontSize:10, color:"var(--text3)", fontFamily:"var(--mono)", marginRight:64, whiteSpace:"nowrap", flexShrink:0 }}>
                {"››"} {f}
              </span>
            ))}
          </div>
        </div>
        <button
          onClick={() => { setExpanded(v => !v); labAction("ticker-paused"); }}
          style={{ flexShrink:0, display:"inline-flex", alignItems:"center", gap:5, background:expanded?"rgba(56,189,248,0.15)":"transparent", border:"1px solid var(--border-hi)", borderRadius:5, padding:"4px 9px", color:"var(--accent)", fontSize:10, fontFamily:"var(--mono)", cursor:"pointer", fontWeight:600 }}
          title="View all events in a readable list"
        >
          {expanded ? <Icons.X size={12}/> : <Icons.Activity size={12}/>}
          {expanded ? "Close" : "View all"}
        </button>
      </div>
      {expanded && (
        <div style={{ borderTop:"1px solid var(--border)", maxHeight:220, overflowY:"auto", padding:"8px 14px", display:"flex", flexDirection:"column", gap:4 }}>
          <div style={{ fontSize:9, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.08em", marginBottom:4 }}>FULL EVENT FEED — {feed.length} EVENTS (paused for reading)</div>
          {feed.map((f, i) => (
            <div key={i} style={{ display:"flex", gap:8, alignItems:"flex-start", fontSize:11, color:"var(--text2)", fontFamily:"var(--mono)", padding:"4px 0", borderBottom:"1px solid rgba(28,48,80,0.4)" }}>
              <span style={{ color:"var(--accent)", flexShrink:0 }}>{String(i+1).padStart(2,"0")}</span>
              <span style={{ lineHeight:1.5 }}>{f}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── SOC DASHBOARD ────────────────────────────────────────────────────────────
function SOCDashboard({ onNav }) {
  const w = useWidth();
  const isNarrow = w < 900;
  const [selAlert, setSelAlert] = useState(null);

  const feed = [
    "ALT-5529 · TI match: 185.220.101.52 → FS-ISAC PHANTOM-07",
    "ALT-5522 · DNS query to account-secure.net blocked · VANT-JM-001",
    "ALT-5525 · MFA fatigue: 3 push denials · john.mercer@vantara.io",
    "ALT-5523 · User phish report submitted · priya.kapoor@vantara.io",
    "ALT-5521 · Phishing delivered · SPF/DKIM/DMARC FAIL · Inbox",
    "ALT-5524 · Azure AD geo-anomaly · London IP · MFA satisfied",
  ];

  return (
    <div style={{ height:"100%", overflowY:"auto", padding: isNarrow?"12px":"16px 20px", display:"flex", flexDirection:"column", gap:14 }}>

      {/* Live ticker — JS rAF animation, zero CSS dependency */}
      <TickerBanner feed={feed} />

      {/* KPI row */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(130px,1fr))", gap:10 }}>
        <MetricCard label="Open Alerts" value={ALERTS.filter(a=>a.status!=="resolved").length} icon="ti-alert-triangle" color="var(--amber)" sub="2 critical" />
        <MetricCard label="Critical" value={ALERTS.filter(a=>a.sev==="critical").length} icon="ti-flame" color="var(--red)" sub="Immediate action" />
        <MetricCard label="Active Cases" value={1} icon="ti-folder-open" color="var(--accent)" sub="INC-2025-0312" />
        <MetricCard label="MTTD" value="4h 26m" icon="ti-clock" color="var(--text2)" sub="Last 24 hours" />
        <MetricCard label="MTTR" value="18h 12m" icon="ti-clock-check" color="var(--text2)" sub="Last 7 days" />
        <MetricCard label="False Positive" value="22%" icon="ti-percentage" color="var(--green)" sub="This month" />
      </div>

      {/* Main grid */}
      <div style={{ display:"grid", gridTemplateColumns: isNarrow?"1fr":"1fr 300px", gap:14, minHeight:0 }}>

        {/* Alert queue */}
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          <Card>
            <CardHead icon="ti-bell-ringing" title="Alert Queue" right={`${ALERTS.length} total`} />
            <div style={{ overflowX:"auto" }}>
              <table>
                <thead>
                  <tr>
                    <th>Alert ID</th><th>Severity</th><th>Title</th><th>User</th><th>Source IP</th><th>Time</th><th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {ALERTS.map(a => (
                    <tr key={a.id} className="hoverable" onClick={() => { setSelAlert(p => p?.id===a.id ? null : a); labAction("alert:"+a.id); }}>
                      <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--accent)" }}>{a.id}</span></td>
                      <td><SevBadge level={a.sev} sm /></td>
                      <td style={{ maxWidth:220 }}><div style={{ overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", fontSize:12 }}>{a.title}</div></td>
                      <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text2)" }}>{a.user?.split("@")[0]||a.user}</span></td>
                      <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color: a.src===PHISH_IP?"var(--red)":"var(--text2)" }}>{a.src}</span></td>
                      <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text3)" }}>{fmtShort(a.time)}</span></td>
                      <td><StatusBadge status={a.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          {selAlert && (
            <Card style={{ animation:"fadein 0.2s ease-out" }}>
              <CardHead icon="ti-info-circle" title={`Alert Detail — ${selAlert.id}`} />
              <div style={{ padding:"14px 16px" }}>
                <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:12 }}>
                  <SevBadge level={selAlert.sev} />
                  <StatusBadge status={selAlert.status} />
                  {selAlert.tech && <Chip color="var(--purple)">{selAlert.tech}</Chip>}
                  {selAlert.tactic && <Chip color="var(--text2)">{selAlert.tactic}</Chip>}
                </div>
                <p style={{ fontSize:13, fontWeight:600, color:"var(--text1)", marginBottom:8, lineHeight:1.4 }}>{selAlert.title}</p>
                <p style={{ fontSize:12, color:"var(--text2)", lineHeight:1.7, marginBottom:14 }}>{selAlert.desc}</p>
                <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                  {selAlert.case && <BtnPrimary onClick={()=>onNav("investigation")} icon="ti-folder-open" sm>Open {selAlert.case}</BtnPrimary>}
                  <BtnGhost onClick={()=>onNav("mailbox")} icon="ti-mail" sm>View Email</BtnGhost>
                  <BtnPrimary onClick={()=>{}} icon="ti-lock" sm danger>Quarantine</BtnPrimary>
                </div>
              </div>
            </Card>
          )}
        </div>

        {/* Right panels */}
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          <Card>
            <CardHead icon="ti-mail-shield" title="Email Security Monitor" />
            <div style={{ padding:"12px 16px" }}>
              {[
                {l:"Processed (24h)",v:"1,847",c:"var(--text1)"},
                {l:"Auth failures",v:"12",c:"var(--amber)"},
                {l:"Quarantined",v:"8",c:"var(--amber)"},
                {l:"Phish below threshold",v:"1",c:"var(--red)"},
                {l:"User-reported phish",v:"2",c:"var(--accent)"},
                {l:"Blocked outbound",v:"0",c:"var(--green)"},
              ].map(r => (
                <div key={r.l} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"6px 0", borderBottom:"1px solid var(--border)" }}>
                  <span style={{ fontSize:11, color:"var(--text2)" }}>{r.l}</span>
                  <span style={{ fontSize:14, fontWeight:700, color:r.c, fontFamily:"var(--mono)" }}>{r.v}</span>
                </div>
              ))}
              <div style={{ marginTop:10 }}>
                <BtnGhost onClick={()=>onNav("mailbox")} icon="ti-mail" sm>Open Mailbox</BtnGhost>
              </div>
            </div>
          </Card>

          <Card>
            <CardHead icon="ti-user-shield" title="User Risk Scores" />
            <div style={{ padding:"10px 16px" }}>
              {Object.entries(USERS).map(([email,u]) => {
                const rc = u.risk>70?"var(--red)":u.risk>40?"var(--amber)":"var(--green)";
                return (
                  <div key={email} style={{ padding:"5px 0", borderBottom:"1px solid var(--border)" }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                      <span style={{ fontSize:11, color:"var(--text2)", fontWeight:500 }}>{u.name}</span>
                      <span style={{ fontSize:11, fontWeight:700, color:rc, fontFamily:"var(--mono)" }}>{u.risk}</span>
                    </div>
                    <RiskBar risk={u.risk} color={rc} />
                  </div>
                );
              })}
            </div>
          </Card>

          <Card>
            <CardHead icon="ti-crosshair" title="Active TTPs" />
            <div style={{ padding:"8px 16px" }}>
              {MITRE_TTPS.slice(0,4).map(t => (
                <div key={t.id} onClick={()=>onNav("investigation")} style={{ display:"flex", gap:8, alignItems:"center", padding:"6px 0", borderBottom:"1px solid var(--border)", cursor:"pointer" }}>
                  <span style={{ fontFamily:"var(--mono)", fontSize:9, color:t.color, background:t.color+"18", border:"1px solid "+t.color+"40", padding:"1px 6px", borderRadius:3, flexShrink:0 }}>{t.id}</span>
                  <span style={{ fontSize:11, color:"var(--text2)", flex:1, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{t.name}</span>
                  <span style={{ fontSize:9, fontWeight:700, color:t.status==="confirmed"?"var(--red)":"var(--amber)", fontFamily:"var(--mono)", flexShrink:0 }}>{t.status}</span>
                </div>
              ))}
              <div style={{ marginTop:10 }}>
                <BtnGhost onClick={()=>onNav("investigation")} icon="ti-crosshair" sm>ATT&CK Matrix</BtnGhost>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ─── MAILBOX ──────────────────────────────────────────────────────────────────
function Mailbox({ onNav, cases, setCases, setOpenCaseId }) {
  const w = useWidth();
  const isMobile = w < 600;
  const isTablet = w >= 600 && w < 960;
  const isDesktop = w >= 960;

  const [folder, setFolder] = useState("inbox");
  const [selId, setSelId] = useState(null);
  const [viewMode, setViewMode] = useState("body");
  const [search, setSearch] = useState("");
  const [showNav, setShowNav] = useState(false);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [ctxMenu, setCtxMenu] = useState(null);
  const [enrichTarget, setEnrichTarget] = useState(null);
  const [catFilter, setCatFilter] = useState("all");
  const bodyScrollRef = useRef(null);

  // Create Case modal state
  const [showCreateCase, setShowCreateCase] = useState(false);
  const [createCaseEmail, setCreateCaseEmail] = useState(null);
  const [caseForm, setCaseForm] = useState({ title:"", sev:"High", priority:"P1", assignee:"John Mercer", tags:"", description:"" });
  const [caseCreatedFor, setCaseCreatedFor] = useState(null); // emailId just cased
  const [caseSuccessMsg, setCaseSuccessMsg] = useState(null);

  function openCreateCase(emailId) {
    const em = ALL_EMAILS.find(e => e.id === emailId);
    if (!em) return;
    setCaseForm({
      title: `Phishing Email — ${em.from.name} impersonation`,
      sev: "High",
      priority: "P1",
      assignee: "John Mercer",
      tags: "phishing,credential-harvesting," + (em.from.email.split("@")[1]||"unknown"),
      description: `Suspicious email received from ${em.from.email} on ${fmtFull(em.date)}. Subject: "${em.subject}". Auth failures: SPF=${em.headers?.SPF||"?"} DKIM=${em.headers?.DKIM||"?"} DMARC=${em.headers?.DMARC||"?"}. Requires investigation.`,
    });
    setCreateCaseEmail(emailId);
    setShowCreateCase(true);
  }

  function submitCreateCase() {
    if (!caseForm.title.trim() || !createCaseEmail) return;
    const newId = "INC-2025-" + String(cases.length + 313).padStart(4,"0");
    const newCase = {
      id: newId,
      emailId: createCaseEmail,
      title: caseForm.title,
      status: "Open",
      sev: caseForm.sev,
      priority: caseForm.priority,
      assignee: caseForm.assignee,
      created: new Date().toISOString(),
      updated: new Date().toISOString(),
      reporter: "John Mercer (Manual)",
      affectedUsers: [ME.email],
      tags: caseForm.tags.split(",").map(t=>t.trim()).filter(Boolean),
      description: caseForm.description,
      isPreExisting: false,
    };
    setCases(prev => [...prev, newCase]);
    setOpenCaseId(newId);
    setCaseCreatedFor(createCaseEmail);
    setShowCreateCase(false);
    setCaseSuccessMsg({ id: newId, fn: () => { onNav("investigation"); setCaseSuccessMsg(null); } });
    setTimeout(() => setCaseSuccessMsg(null), 6000);
    labAction("createcase");
  }

  // Quarantine state
  const [quarantined, setQuarantined] = useState(new Set());
  const [showQuarantineModal, setShowQuarantineModal] = useState(false);
  const [quarantineTarget, setQuarantineTarget] = useState(null); // email id to quarantine
  const [quarantineReason, setQuarantineReason] = useState("phishing");
  const [quarantineNote, setQuarantineNote] = useState("");
  const [quarantineSuccess, setQuarantineSuccess] = useState(null); // email id just quarantined (shows toast)

  function openQuarantineModal(id) {
    setQuarantineTarget(id);
    setQuarantineReason("phishing");
    setQuarantineNote("");
    setShowQuarantineModal(true);
    setCtxMenu(null);
  }

  function confirmQuarantine() {
    if (!quarantineTarget) return;
    setQuarantined(prev => new Set([...prev, quarantineTarget]));
    setShowQuarantineModal(false);
    setQuarantineSuccess(quarantineTarget);
    if (selId === quarantineTarget) setSelId(null);
    setTimeout(() => setQuarantineSuccess(null), 4000);
    labAction("quarantine:"+quarantineTarget);
  }

  const FOLDERS = {
    inbox:      {icon:"ti-inbox",      label:"Inbox",      count:ALL_EMAILS.filter(e=>e.folder==="inbox"&&!e.read&&!quarantined.has(e.id)).length},
    sent:       {icon:"ti-send",       label:"Sent",       count:0},
    drafts:     {icon:"ti-pencil",     label:"Drafts",     count:ALL_EMAILS.filter(e=>e.folder==="drafts").length},
    quarantine: {icon:"ti-shield-x",   label:"Quarantine", count:quarantined.size, danger:true},
    spam:       {icon:"ti-ban",        label:"Spam",       count:ALL_EMAILS.filter(e=>e.folder==="spam"&&!e.read).length},
    archive:    {icon:"ti-archive",    label:"Archive",    count:0},
  };
  const CATS = ["all","internal","client","external","dev","social","it-notice","spam"];

  const emailList = useMemo(() => {
    if (folder === "quarantine") {
      const qEmails = ALL_EMAILS.filter(e => quarantined.has(e.id));
      if (!search.trim()) return qEmails;
      const q = search.toLowerCase();
      return qEmails.filter(e => e.subject.toLowerCase().includes(q) || e.from.name.toLowerCase().includes(q));
    }
    return ALL_EMAILS.filter(e => {
      if (e.folder !== folder) return false;
      if (quarantined.has(e.id)) return false;
      if (catFilter !== "all" && e.cat !== catFilter) return false;
      if (!search.trim()) return true;
      const q = search.toLowerCase();
      return e.subject.toLowerCase().includes(q) || e.from.name.toLowerCase().includes(q) || e.preview.toLowerCase().includes(q);
    });
  }, [folder, catFilter, search, quarantined]);

  const email = useMemo(() => selId ? ALL_EMAILS.find(e=>e.id===selId) : null, [selId]);

  // Reset scroll when email changes
  useEffect(() => { if (bodyScrollRef.current) bodyScrollRef.current.scrollTop = 0; }, [selId, viewMode]);
  useEffect(() => { setShowAnalysis(false); }, [selId]);

  function openEmail(id) { setSelId(id); setViewMode("body"); setCtxMenu(null); labAction("email:"+id); }
  function changeFolder(f) { setFolder(f); setSelId(null); setShowNav(false); setCatFilter("all"); setSearch(""); }
  function handleCtx(ev, id) { ev.preventDefault(); setCtxMenu({ x:Math.min(ev.clientX,w-200), y:Math.min(ev.clientY,window.innerHeight-220), id }); }

  const repColor = (rep) => rep?.score>80 ? "var(--green)" : rep?.score>50 ? "var(--amber)" : "var(--red)";

  const Sidebar = (
    <div style={{ display:"flex", flexDirection:"column", height:"100%", background:"var(--surface)", borderRight:"1px solid var(--border)" }}>
      <div style={{ padding:"14px 14px 12px", borderBottom:"1px solid var(--border)" }}>
        <VantaraLogo size="sidebar" />
      </div>

      <div style={{ padding:"10px 12px 6px" }}>
        <button style={{ width:"100%", background:"rgba(56,189,248,0.1)", border:"1px solid rgba(56,189,248,0.3)", color:"var(--accent)", borderRadius:7, padding:"9px", fontSize:12, fontWeight:600, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:6 }}>
          <i className="ti ti-pencil-plus" style={{ fontSize:13 }} aria-hidden="true" /> Compose
        </button>
      </div>

      <nav style={{ flex:1, padding:"6px 10px", overflowY:"auto" }}>
        {Object.entries(FOLDERS).map(([key,f]) => {
          const isAct = folder===key;
          const ac = f.danger ? "var(--amber)" : "var(--accent)";
          const abg = f.danger ? "rgba(245,158,11,0.08)" : "rgba(56,189,248,0.08)";
          const bbg = key==="spam" ? "var(--red-dim)" : f.danger ? "rgba(245,158,11,0.2)" : "rgba(56,189,248,0.15)";
          const bc = key==="spam" ? "var(--red)" : f.danger ? "var(--amber)" : "var(--accent)";
          return (
            <button key={key} onClick={() => changeFolder(key)}
              style={{ display:"flex", alignItems:"center", gap:9, width:"100%", padding:"8px 10px", borderRadius:6, border:"none", background: isAct?abg:"transparent", color: isAct?ac:f.danger?"var(--amber)":"var(--text2)", cursor:"pointer", textAlign:"left", fontSize:12, fontWeight: isAct?600:400, borderLeft: isAct?`2px solid ${ac}`:"2px solid transparent", marginBottom:1 }}>
              <i className={`ti ${f.icon}`} style={{ fontSize:15 }} aria-hidden="true" />
              <span style={{ flex:1 }}>{f.label}</span>
              {f.count > 0 && <span style={{ fontSize:9, fontWeight:700, padding:"1px 7px", borderRadius:10, background:bbg, color:bc }}>{f.count}</span>}
            </button>
          );
        })}
      </nav>

      <div style={{ padding:"10px 12px", borderTop:"1px solid var(--border)" }}>
        <button onClick={() => onNav("soc")} style={{ width:"100%", background:"rgba(245,158,11,0.08)", border:"1px solid rgba(245,158,11,0.3)", color:"var(--amber)", borderRadius:6, padding:"8px", fontSize:10, fontWeight:700, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:6, fontFamily:"var(--mono)", letterSpacing:"0.06em" }}>
          <i className="ti ti-shield-bolt" style={{ fontSize:12 }} aria-hidden="true" /> SOC PLATFORM
        </button>
      </div>

      <div style={{ padding:"12px 14px 16px", borderTop:"1px solid var(--border)" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <Avatar name={ME.name} size={34} accent />
          <div style={{ minWidth:0 }}>
            <div style={{ fontSize:12, fontWeight:600, color:"var(--text1)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{ME.name}</div>
            <div style={{ fontSize:10, color:"var(--text3)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", fontFamily:"var(--mono)" }}>{ME.email}</div>
          </div>
        </div>
      </div>
    </div>
  );

  const EmailList = (
    <div style={{ display:"flex", flexDirection:"column", height:"100%", background:"var(--surface)" }}>
      <div style={{ padding:"10px 12px", borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        {!isDesktop && (
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8 }}>
            <button onClick={()=>setShowNav(v=>!v)} style={{ background:"transparent", border:"none", color:"var(--text3)", cursor:"pointer", fontSize:18, padding:2 }}><i className="ti ti-menu-2" aria-hidden="true" /></button>
            <span style={{ fontWeight:700, fontSize:14, color:"var(--text1)", flex:1 }}>{FOLDERS[folder]?.label}</span>
            <span style={{ fontSize:10, color:"var(--text3)", fontFamily:"var(--mono)" }}>{emailList.length}</span>
          </div>
        )}
        {isDesktop && <div style={{ display:"flex", alignItems:"center", marginBottom:8 }}>
          <span style={{ fontWeight:700, fontSize:14, color:"var(--text1)", flex:1 }}>{FOLDERS[folder]?.label}</span>
          <span style={{ fontSize:10, color:"var(--text3)", fontFamily:"var(--mono)" }}>{emailList.length}</span>
        </div>}
        <div style={{ position:"relative", marginBottom:8 }}>
          <i className="ti ti-search" style={{ position:"absolute", left:9, top:"50%", transform:"translateY(-50%)", fontSize:12, color:"var(--text3)", pointerEvents:"none" }} aria-hidden="true" />
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search…" style={{ paddingLeft:30 }} />
        </div>
        <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
          {CATS.map(c => (
            <button key={c} onClick={()=>setCatFilter(c)} style={{ fontSize:9, padding:"2px 8px", borderRadius:10, border:`1px solid ${catFilter===c?"var(--accent)":"var(--border)"}`, background: catFilter===c?"rgba(56,189,248,0.1)":"transparent", color: catFilter===c?"var(--accent)":"var(--text3)", cursor:"pointer", fontFamily:"var(--mono)" }}>
              {c}
            </button>
          ))}
        </div>
      </div>

      <div style={{ overflowY:"auto", flex:1 }}>
        {emailList.length === 0 && (
          <div style={{ padding:28, textAlign:"center", color:"var(--text3)", fontSize:12, display:"flex", flexDirection:"column", alignItems:"center", gap:8 }}>
            {folder === "quarantine"
              ? <><i className="ti ti-shield-check" style={{ fontSize:32, color:"var(--green)", marginBottom:4 }} aria-hidden="true" /><span style={{ fontSize:13, color:"var(--text2)", fontWeight:500 }}>Quarantine is empty</span><span style={{ fontSize:11 }}>No isolated messages</span></>
              : <><i className="ti ti-inbox" style={{ fontSize:28, marginBottom:4 }} aria-hidden="true" /><span>No messages found</span></>
            }
          </div>
        )}
        {emailList.map(e => (
          <div key={e.id} onClick={()=>openEmail(e.id)} onContextMenu={ev=>handleCtx(ev,e.id)}
            style={{ padding:"11px 14px", cursor:"pointer", borderBottom:"1px solid var(--border)", background: selId===e.id?"rgba(56,189,248,0.06)": e.isPhishing?"rgba(248,113,113,0.04)":"transparent", borderLeft: selId===e.id?"2px solid var(--accent)": e.isPhishing?"2px solid var(--red)":"2px solid transparent" }}
            onMouseEnter={ev=>{ if(selId!==e.id) ev.currentTarget.style.background="var(--card)"; }}
            onMouseLeave={ev=>{ ev.currentTarget.style.background=selId===e.id?"rgba(56,189,248,0.06)":e.isPhishing?"rgba(248,113,113,0.04)":"transparent"; }}>
            <div style={{ display:"flex", alignItems:"center", gap:7, marginBottom:3 }}>
              {!e.read && <span style={{ width:6, height:6, borderRadius:"50%", background:"var(--accent)", flexShrink:0 }} />}
              <span style={{ fontWeight:e.read?400:600, fontSize:12.5, color:"var(--text1)", flex:1, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                {e.from.name}
              </span>
              <span style={{ fontSize:10, color:"var(--text3)", fontFamily:"var(--mono)", flexShrink:0 }}>{fmtAgo(e.date)}</span>
            </div>
            <div style={{ fontSize:12, fontWeight:e.read?400:500, color:"var(--text2)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", marginBottom:3 }}>{e.subject}</div>
            <div style={{ fontSize:11, color:"var(--text3)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{e.preview}</div>
            <div style={{ display:"flex", gap:5, marginTop:5, flexWrap:"wrap", alignItems:"center" }}>
              <span style={{ fontFamily:"var(--mono)", fontSize:9, color:"var(--text3)", background:"var(--card-hi)", border:"1px solid var(--border)", padding:"1px 6px", borderRadius:3 }}>{e.cat}</span>
              {e.attachments?.length>0 && <i className="ti ti-paperclip" style={{ fontSize:10, color:"var(--text3)" }} aria-hidden="true" />}
              {e.rep && <span style={{ fontFamily:"var(--mono)", fontSize:9, color:repColor(e.rep), fontWeight:600 }}>REP:{e.rep.score}</span>}
              {quarantined.has(e.id) && <span style={{ fontFamily:"var(--mono)", fontSize:9, color:"var(--amber)", background:"rgba(245,158,11,0.12)", border:"1px solid rgba(245,158,11,0.3)", padding:"1px 6px", borderRadius:3, fontWeight:700 }}>QUARANTINED</span>}
              {e.isPhishing && (() => {
                const ec = cases.find(c => c.emailId === e.id);
                return ec
                  ? <span style={{ fontFamily:"var(--mono)", fontSize:9, color:"var(--green)", background:"rgba(52,211,153,0.08)", border:"1px solid rgba(52,211,153,0.3)", padding:"1px 6px", borderRadius:3, fontWeight:700 }}>{ec.id}</span>
                  : <span style={{ fontFamily:"var(--mono)", fontSize:9, color:"var(--amber)", background:"rgba(245,158,11,0.08)", border:"1px solid rgba(245,158,11,0.25)", padding:"1px 6px", borderRadius:3, fontWeight:600 }}>NO CASE</span>;
              })()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const EmailView = (
    <div style={{ display:"flex", flexDirection:"column", height:"100%", background:"var(--bg)" }}>
      {!email ? (
        <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:12, color:"var(--text3)" }}>
          <i className="ti ti-mail-opened" style={{ fontSize:48 }} aria-hidden="true" />
          <p style={{ fontSize:13 }}>Select a message to read</p>
          <p style={{ fontSize:10, fontFamily:"var(--mono)" }}>Right-click for quick actions</p>
        </div>
      ) : (
        <>
          {/* Threat banner */}
          {email.isPhishing && (() => {
            const emailCase = cases.find(c => c.emailId === email.id);
            return (
              <div style={{ background:"var(--red-bg)", borderBottom:"1px solid var(--red-dim)", padding:"9px 16px", display:"flex", alignItems:"center", gap:10, flexShrink:0, flexWrap:"wrap" }}>
                <PulseIcon color="var(--red)" />
                <span style={{ fontSize:11, fontWeight:600, color:"var(--red)", flex:1, minWidth:160 }}>THREAT DETECTED — Phishing indicators found. Do not click any links.</span>
                <div style={{ display:"flex", gap:6, flexShrink:0, flexWrap:"wrap", alignItems:"center" }}>
                  {emailCase ? (
                    <button onClick={()=>{ setOpenCaseId(emailCase.id); onNav("investigation"); }}
                      style={{ display:"inline-flex", alignItems:"center", gap:5, padding:"4px 11px", borderRadius:5, border:"1px solid rgba(74,222,128,0.4)", background:"rgba(52,211,153,0.1)", color:"var(--green)", fontSize:10, fontWeight:700, cursor:"pointer", fontFamily:"var(--mono)", whiteSpace:"nowrap" }}>
                      <i className="ti ti-folder-check" style={{ fontSize:12 }} aria-hidden="true" />
                      {emailCase.id}
                    </button>
                  ) : (
                    <BtnPrimary onClick={()=>openCreateCase(email.id)} icon="ti-folder-plus" sm amber>
                      Create Case
                    </BtnPrimary>
                  )}
                  <BtnPrimary onClick={()=>openQuarantineModal(email.id)} icon="ti-shield-x" sm danger>
                    {quarantined.has(email.id) ? "Quarantined" : "Quarantine"}
                  </BtnPrimary>
                  <BtnPrimary onClick={()=>onNav("investigation")} icon="ti-shield-search" sm danger>Investigate</BtnPrimary>
                </div>
              </div>
            );
          })()}

          {/* Quarantine status banner */}
          {quarantined.has(email.id) && (
            <div style={{ background:"rgba(245,158,11,0.07)", borderBottom:"1px solid rgba(245,158,11,0.25)", padding:"7px 16px", display:"flex", alignItems:"center", gap:10, flexShrink:0 }}>
              <i className="ti ti-shield-check" style={{ color:"var(--amber)", fontSize:14, flexShrink:0 }} aria-hidden="true" />
              <span style={{ fontSize:11, fontWeight:600, color:"var(--amber)", flex:1 }}>
                This message has been quarantined — isolated from inbox and logged as a security event
              </span>
              <button onClick={()=>setFolder("quarantine")} style={{ background:"transparent", border:"1px solid rgba(245,158,11,0.4)", color:"var(--amber)", borderRadius:5, padding:"3px 10px", fontSize:10, fontWeight:600, cursor:"pointer", fontFamily:"var(--mono)", whiteSpace:"nowrap" }}>
                View in Quarantine
              </button>
            </div>
          )}

          {/* Toolbar */}
          <div style={{ padding:"8px 16px", borderBottom:"1px solid var(--border)", display:"flex", alignItems:"center", gap:8, flexShrink:0, background:"var(--card)", flexWrap:"wrap" }}>
            <BtnGhost onClick={()=>setSelId(null)} icon="ti-arrow-left" sm>Back</BtnGhost>
            <div style={{ flex:1 }} />
            {["body","headers","links"].map(v => (
              <button key={v} onClick={()=>setViewMode(v)} style={{ padding:"5px 12px", borderRadius:5, border:`1px solid ${viewMode===v?"var(--accent)":"var(--border)"}`, background: viewMode===v?"rgba(56,189,248,0.1)":"transparent", color: viewMode===v?"var(--accent)":"var(--text3)", fontSize:10, fontWeight:600, cursor:"pointer", fontFamily:"var(--mono)", letterSpacing:"0.05em" }}>
                {v.toUpperCase()}
              </button>
            ))}
            <BtnPrimary
              onClick={() => openQuarantineModal(email.id)}
              icon="ti-shield-x" sm danger
              style={{ opacity: quarantined.has(email.id) ? 0.5 : 1 }}
            >
              {quarantined.has(email.id) ? "Quarantined" : "Quarantine"}
            </BtnPrimary>
            {email.isPhishing && <BtnPrimary onClick={()=>onNav("investigation")} icon="ti-folder-open" sm amber>SOC Case</BtnPrimary>}
          </div>

          {/* Scrollable body */}
          <div ref={bodyScrollRef} style={{ flex:1, overflowY:"auto", padding: isMobile?"14px 12px":"20px 28px" }}>

            {viewMode === "body" && (
              <>
                <h1 style={{ fontSize: isMobile?15:20, fontWeight:700, color:"var(--text1)", margin:"0 0 18px", lineHeight:1.3, wordBreak:"break-word" }}>{email.subject}</h1>

                {/* Sender card */}
                <div style={{ background:"var(--card)", border:`1px solid ${email.isPhishing?"var(--red-dim)":"var(--border)"}`, borderRadius:8, padding:"14px 16px", marginBottom:12 }}>
                  <div style={{ display:"flex", gap:12, alignItems:"flex-start" }}>
                    <Avatar name={email.from.name} size={38} />
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ display:"flex", flexWrap:"wrap", gap:8, alignItems:"center", marginBottom:6 }}>
                        <span style={{ fontSize:14, fontWeight:600, color:"var(--text1)" }}>{email.from.name}</span>
                        <span style={{ fontFamily:"var(--mono)", fontSize:9, color:"var(--text3)", background:"var(--card-hi)", border:"1px solid var(--border)", padding:"1px 7px", borderRadius:3 }}>{email.cat}</span>
                        {email.rep && <span style={{ fontFamily:"var(--mono)", fontSize:9, fontWeight:700, color:repColor(email.rep), background:repColor(email.rep)+"18", border:"1px solid "+repColor(email.rep)+"40", padding:"1px 7px", borderRadius:3 }}>REP {email.rep.score}/100</span>}
                        {email.isPhishing && <SevBadge level="critical" sm />}
                      </div>
                      <div style={{ fontSize:11.5, color:"var(--text3)", lineHeight:1.7 }}>
                        <div><b style={{ color:"var(--text3)", fontWeight:500 }}>From: </b><span style={{ fontFamily:"var(--mono)", color: email.isPhishing?"var(--red)":"var(--text2)" }}>{email.from.email}</span></div>
                        <div><b style={{ color:"var(--text3)", fontWeight:500 }}>To: </b><span style={{ fontFamily:"var(--mono)", color:"var(--text2)" }}>{email.to?.join(", ")}</span></div>
                        {email.cc?.length > 0 && <div><b style={{ color:"var(--text3)", fontWeight:500 }}>CC: </b><span style={{ fontFamily:"var(--mono)", color:"var(--text2)" }}>{email.cc.join(", ")}</span></div>}
                        {email.headers?.["Reply-To"] && email.headers["Reply-To"] !== email.from.email && (
                          <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap" }}>
                            <span><b style={{ color:"var(--text3)", fontWeight:500 }}>Reply-To: </b><span style={{ fontFamily:"var(--mono)", color:"var(--amber)" }}>{email.headers["Reply-To"]}</span></span>
                            <Chip color="var(--amber)">⚠ DIFFERS FROM SENDER</Chip>
                          </div>
                        )}
                        <div style={{ marginTop:4, color:"var(--text3)" }}>{fmtFull(email.date)}</div>
                      </div>
                    </div>
                  </div>

                  {/* Auth pills */}
                  {email.headers?.SPF && (
                    <div style={{ marginTop:12, padding:"8px 10px", background:"var(--card-hi)", borderRadius:6, border:"1px solid var(--border)", display:"flex", gap:8, flexWrap:"wrap", alignItems:"center" }}>
                      <span style={{ fontSize:9, fontWeight:700, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.08em" }}>AUTH:</span>
                      {["SPF","DKIM","DMARC"].map(k => {
                        const v = email.headers[k];
                        return v && <span key={k} className="tag" style={{ background:v==="PASS"?"var(--green-dim)":"var(--red-dim)", color:v==="PASS"?"var(--green)":"var(--red)", border:"none", padding:"2px 9px", fontSize:9 }}>{k}: {v}</span>;
                      })}
                      {email.headers["X-Spam-Score"] && (
                        <span style={{ marginLeft:"auto", fontSize:11, fontWeight:700, fontFamily:"var(--mono)", color: parseFloat(email.headers["X-Spam-Score"])>5?"var(--red)":"var(--green)" }}>
                          Spam: {email.headers["X-Spam-Score"]}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Attachments */}
                {email.attachments?.length > 0 && (
                  <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:12 }}>
                    {email.attachments.map(a => (
                      <div key={a.name} style={{ display:"flex", alignItems:"center", gap:8, background:"var(--card)", border:"1px solid var(--border)", borderRadius:7, padding:"8px 12px" }}>
                        <i className="ti ti-paperclip" style={{ fontSize:14, color:"var(--accent)" }} aria-hidden="true" />
                        <div>
                          <div style={{ fontSize:12, fontWeight:500, color:"var(--text1)" }}>{a.name}</div>
                          <div style={{ fontSize:10, color:"var(--text3)", fontFamily:"var(--mono)" }}>{a.size}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Body text */}
                <div style={{ fontSize:13.5, lineHeight:1.85, color:"var(--text2)", whiteSpace:"pre-wrap", wordBreak:"break-word", background:"var(--card)", border:"1px solid var(--border)", borderRadius:8, padding:"18px 20px" }}>
                  {email.isPhishing
                    ? email.body.split(PHISH_URL).map((part,i,arr) =>
                        i < arr.length-1 ? (
                          <span key={i}>{part}
                            <span onClick={()=>setEnrichTarget(HARVEST)} style={{ fontFamily:"var(--mono)", fontSize:11, color:"var(--red)", textDecoration:"underline", background:"rgba(248,113,113,0.1)", padding:"1px 4px", borderRadius:3, cursor:"pointer", wordBreak:"break-all" }} title="Click to analyse">{PHISH_URL}</span>
                            <span style={{ fontFamily:"var(--mono)", fontSize:9, background:"var(--red-bg)", color:"var(--red)", border:"1px solid var(--red-dim)", padding:"1px 6px", borderRadius:3, marginLeft:5, fontWeight:700 }}>MALICIOUS LINK</span>
                          </span>
                        ) : <span key={i}>{part}</span>)
                    : email.body}
                </div>

                {/* Link preview */}
                {email.links?.length > 0 && (
                  <div style={{ marginTop:12 }}>
                    <Card>
                      <CardHead icon="ti-link" title="Embedded Links" />
                      {email.links.map((lk,i) => (
                        <div key={i} style={{ padding:"10px 16px", borderBottom: i<email.links.length-1?"1px solid var(--border)":"none" }}>
                          <div style={{ display:"flex", gap:8, alignItems:"center", flexWrap:"wrap", marginBottom:5 }}>
                            <span className="tag" style={{ background:lk.safe?"var(--green-dim)":"var(--red-dim)", color:lk.safe?"var(--green)":"var(--red)", border:"none", padding:"2px 8px", fontSize:9 }}>{lk.safe?"SAFE":"MALICIOUS"}</span>
                            {lk.vt && <span className="tag" style={{ background:"var(--red-bg)", color:"var(--red)", border:"1px solid var(--red-dim)", padding:"2px 8px", fontSize:9 }}>VT: {lk.vt}</span>}
                            <span style={{ fontSize:10, color:"var(--text3)" }}>{lk.cat}</span>
                          </div>
                          <div style={{ fontFamily:"var(--mono)", fontSize:11, color:lk.safe?"var(--text2)":"var(--red)", wordBreak:"break-all", marginBottom:6 }}>{lk.url}</div>
                          <div style={{ fontSize:11, color:"var(--text3)", marginBottom:6 }}>Anchor: "{lk.label}"</div>
                          {!lk.safe && <BtnPrimary onClick={()=>setEnrichTarget(HARVEST)} icon="ti-virus" sm danger>Domain Intel</BtnPrimary>}
                        </div>
                      ))}
                    </Card>
                  </div>
                )}

                {/* Phishing indicators */}
                {email.isPhishing && (
                  <div style={{ marginTop:16 }}>
                    <button onClick={()=>setShowAnalysis(v=>!v)} style={{ width:"100%", background:"var(--red-bg)", border:"1px solid var(--red-dim)", borderRadius:7, padding:"10px 16px", display:"flex", alignItems:"center", gap:9, cursor:"pointer", color:"var(--red)", fontSize:12, fontWeight:600 }}>
                      <i className="ti ti-shield-exclamation" style={{ fontSize:15 }} aria-hidden="true" />
                      Threat Indicator Analysis — {email.phishIndicators.length} indicators
                      <i className={`ti ${showAnalysis?"ti-chevron-up":"ti-chevron-down"}`} style={{ marginLeft:"auto", fontSize:12 }} aria-hidden="true" />
                    </button>
                    {showAnalysis && (
                      <div style={{ border:"1px solid var(--red-dim)", borderTop:"none", borderRadius:"0 0 7px 7px", overflow:"hidden" }}>
                        {email.phishIndicators.map((ind,i) => {
                          const SC={critical:"var(--red)",high:"var(--amber)",medium:"var(--amber)"};
                          const c=SC[ind.sev]||"var(--amber)";
                          return (
                            <div key={i} style={{ padding:"12px 16px", borderBottom: i<email.phishIndicators.length-1?"1px solid rgba(127,29,29,0.4)":"none", background:"rgba(26,8,8,0.6)" }}>
                              <div style={{ display:"flex", flexWrap:"wrap", gap:8, alignItems:"center", marginBottom:5 }}>
                                <span style={{ width:7, height:7, borderRadius:"50%", background:c, flexShrink:0 }} />
                                <span style={{ fontSize:12, fontWeight:600, color:c }}>{ind.label}</span>
                                <span className="tag" style={{ background:c+"18", color:c, border:"1px solid "+c+"40", padding:"1px 6px", fontSize:8, textTransform:"uppercase" }}>{ind.sev}</span>
                                {ind.mitre && <Chip color="var(--purple)">{ind.mitre}</Chip>}
                              </div>
                              <div style={{ fontSize:12, color:"rgba(252,165,165,0.7)", lineHeight:1.7, paddingLeft:15 }}>{ind.detail}</div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}

            {viewMode === "headers" && (
              <div style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:8, padding:"16px 20px", fontFamily:"var(--mono)", fontSize:11.5, lineHeight:2 }}>
                <div style={{ color:"var(--accent)", fontWeight:700, marginBottom:14, fontSize:11, letterSpacing:"0.08em" }}>━━ RAW EMAIL HEADERS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</div>
                {Object.entries(email.headers || {}).map(([k,v]) => {
                  const bad = ["SPF","DKIM","DMARC"].includes(k) && v==="FAIL";
                  const warn = k==="Reply-To" && v!==email.from.email;
                  const spam = k==="X-Spam-Score" && parseFloat(v)>5;
                  const cid = k==="X-Campaign-ID";
                  const kc = bad||spam ? "var(--red)" : warn||cid ? "var(--amber)" : "var(--accent)";
                  const vc = bad||spam ? "var(--red)" : warn||cid ? "var(--amber)" : "var(--text2)";
                  return (
                    <div key={k} style={{ marginBottom:2, wordBreak:"break-all" }}>
                      <span style={{ color:kc, fontWeight:500 }}>{k}: </span>
                      <span style={{ color:vc }}>{v}</span>
                      {(bad||warn||spam||cid) && <span style={{ marginLeft:10, fontSize:9, fontWeight:700, padding:"1px 6px", borderRadius:3, background: bad||spam?"var(--red-dim)":"rgba(245,158,11,0.2)", color: bad||spam?"var(--red)":"var(--amber)" }}>{bad?"⚠ AUTH FAIL":spam?"⚠ HIGH SPAM":cid?"⚠ CAMPAIGN ID":"⚠ MISMATCH"}</span>}
                    </div>
                  );
                })}
                <div style={{ marginTop:18, paddingTop:16, borderTop:"1px solid var(--border)" }}>
                  <div style={{ color:"var(--accent)", fontWeight:700, marginBottom:10, fontSize:11, letterSpacing:"0.08em" }}>━━ MESSAGE BODY ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</div>
                  <pre style={{ color:"var(--text3)", whiteSpace:"pre-wrap", wordBreak:"break-word", lineHeight:1.7, fontSize:11 }}>{email.body}</pre>
                </div>
              </div>
            )}

            {viewMode === "links" && (
              <Card>
                <CardHead icon="ti-link" title="Link Analysis" />
                {!email.links?.length
                  ? <div style={{ padding:20, color:"var(--text3)", fontSize:12 }}>No hyperlinks found.</div>
                  : email.links.map((lk,i) => (
                    <div key={i} style={{ padding:"14px 16px", borderBottom:"1px solid var(--border)" }}>
                      <div style={{ display:"flex", gap:8, flexWrap:"wrap", alignItems:"center", marginBottom:8 }}>
                        <span className="tag" style={{ background:lk.safe?"var(--green-dim)":"var(--red-dim)", color:lk.safe?"var(--green)":"var(--red)", border:"none", fontSize:9 }}>{lk.safe?"SAFE":"MALICIOUS"}</span>
                        {lk.vt && <span className="tag" style={{ background:"var(--red-bg)", color:"var(--red)", border:"1px solid var(--red-dim)", fontSize:9 }}>VT: {lk.vt}</span>}
                      </div>
                      <div style={{ fontFamily:"var(--mono)", fontSize:11, color:"var(--red)", wordBreak:"break-all", marginBottom:6 }}>{lk.url}</div>
                      <div style={{ fontSize:11, color:"var(--text3)", marginBottom:10 }}>Anchor: "{lk.label}" · Category: {lk.cat}</div>
                      {!lk.safe && <BtnPrimary onClick={()=>setEnrichTarget(HARVEST)} icon="ti-virus" sm danger>Domain Intelligence</BtnPrimary>}
                    </div>
                  ))
                }
              </Card>
            )}
          </div>
        </>
      )}
    </div>
  );

  return (
    <div style={{ display:"flex", height:"100%", position:"relative", overflow:"hidden" }}>
      {/* Context menu */}
      {ctxMenu && (
        <>
          <div onClick={()=>setCtxMenu(null)} style={{ position:"fixed", inset:0, zIndex:500 }} />
          <div style={{ position:"fixed", left:ctxMenu.x, top:ctxMenu.y, zIndex:600, background:"var(--card)", border:"1px solid var(--border-hi)", borderRadius:8, padding:"4px 0", minWidth:190, boxShadow:"0 12px 40px rgba(0,0,0,0.6)" }}>
            {[{icon:"ti-mail-opened",label:"Mark as read"},{icon:"ti-flag",label:"Flag"},{icon:"ti-shield-x",label:"Quarantine",c:"var(--amber)",fn:()=>{openQuarantineModal(ctxMenu.id);}},{icon:"ti-arrow-up-circle",label:"Escalate to SOC",c:"var(--amber)",fn:()=>{setCtxMenu(null);onNav("investigation");}},{icon:"ti-user-cancel",label:"Block sender",c:"var(--red)"},{icon:"ti-trash",label:"Delete",c:"var(--red)"}]
              .map(item => (
                <button key={item.label} onClick={item.fn||(() => setCtxMenu(null))} style={{ width:"100%", display:"flex", alignItems:"center", gap:9, padding:"8px 14px", background:"transparent", border:"none", color:item.c||"var(--text2)", cursor:"pointer", fontSize:12, textAlign:"left" }}
                  onMouseEnter={e=>e.currentTarget.style.background="var(--card-hi)"}
                  onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                  <i className={`ti ${item.icon}`} style={{ fontSize:14 }} aria-hidden="true" />
                  {item.label}
                </button>
              ))}
          </div>
        </>
      )}

      {/* Create Case success toast */}
      {caseSuccessMsg && (
        <div style={{ position:"fixed", bottom:24, left:"50%", transform:"translateX(-50%)", zIndex:700, background:"rgba(6,14,26,0.97)", border:"1px solid rgba(56,189,248,0.4)", borderRadius:10, padding:"14px 20px", display:"flex", alignItems:"center", gap:14, boxShadow:"0 8px 36px rgba(0,0,0,0.7)", minWidth:340, animation:"fadein 0.25s ease-out" }}>
          <div style={{ width:34, height:34, borderRadius:"50%", background:"rgba(56,189,248,0.12)", border:"1px solid rgba(56,189,248,0.35)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
            <i className="ti ti-folder-check" style={{ color:"var(--accent)", fontSize:17 }} aria-hidden="true" />
          </div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:13, fontWeight:700, color:"var(--text1)" }}>Case {caseSuccessMsg.id} created</div>
            <div style={{ fontSize:11, color:"var(--text3)", fontFamily:"var(--mono)", marginTop:2 }}>Ready for investigation in the DFIR platform</div>
          </div>
          <button onClick={caseSuccessMsg.fn} style={{ background:"rgba(56,189,248,0.1)", border:"1px solid rgba(56,189,248,0.35)", borderRadius:6, color:"var(--accent)", cursor:"pointer", fontSize:11, fontWeight:700, padding:"5px 12px", whiteSpace:"nowrap" }}>Open →</button>
          <button onClick={()=>setCaseSuccessMsg(null)} style={{ background:"transparent", border:"none", color:"var(--text3)", cursor:"pointer", fontSize:16, marginLeft:2 }}>✕</button>
        </div>
      )}

      {/* Create Case modal */}
      {showCreateCase && createCaseEmail && (() => {
        const em = ALL_EMAILS.find(e => e.id === createCaseEmail);
        return (
          <div style={{ position:"absolute", inset:0, zIndex:510, background:"rgba(6,14,26,0.9)", display:"flex", alignItems:"center", justifyContent:"center", padding:16 }}>
            <div style={{ background:"var(--card)", border:"1px solid rgba(56,189,248,0.3)", borderRadius:12, width:Math.min(580,w-24), maxHeight:"90vh", overflow:"auto", boxShadow:"0 24px 64px rgba(0,0,0,0.75)", animation:"fadein 0.2s ease-out" }}>
              {/* Header */}
              <div style={{ background:"rgba(56,189,248,0.06)", borderBottom:"1px solid var(--border)", padding:"16px 22px", display:"flex", alignItems:"center", gap:13 }}>
                <div style={{ width:38, height:38, borderRadius:8, background:"rgba(56,189,248,0.12)", border:"1px solid rgba(56,189,248,0.3)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                  <i className="ti ti-folder-plus" style={{ color:"var(--accent)", fontSize:18 }} aria-hidden="true" />
                </div>
                <div>
                  <div style={{ fontSize:15, fontWeight:700, color:"var(--text1)" }}>Create Investigation Case</div>
                  <div style={{ fontSize:10, color:"var(--text3)", fontFamily:"var(--mono)", marginTop:2 }}>Register a new DFIR case from this phishing email</div>
                </div>
                <button onClick={()=>setShowCreateCase(false)} style={{ marginLeft:"auto", background:"transparent", border:"none", color:"var(--text3)", cursor:"pointer", fontSize:18, lineHeight:1 }}>✕</button>
              </div>

              <div style={{ padding:"18px 22px" }}>
                {/* Source email summary */}
                <div style={{ background:"rgba(248,113,113,0.06)", border:"1px solid rgba(248,113,113,0.25)", borderRadius:7, padding:"10px 14px", marginBottom:18 }}>
                  <div style={{ fontSize:10, fontWeight:700, color:"var(--red)", fontFamily:"var(--mono)", letterSpacing:"0.06em", marginBottom:6 }}>SOURCE EMAIL</div>
                  <div style={{ fontSize:12, fontWeight:600, color:"var(--text1)", marginBottom:3 }}>{em?.subject}</div>
                  <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
                    <span style={{ fontFamily:"var(--mono)", fontSize:11, color:"var(--red)" }}>{em?.from.email}</span>
                    <span style={{ fontSize:10, color:"var(--text3)" }}>·</span>
                    <span style={{ fontSize:11, color:"var(--text3)" }}>{fmtFull(em?.date)}</span>
                    {em?.headers?.SPF && (
                      <div style={{ display:"flex", gap:5 }}>
                        {["SPF","DKIM","DMARC"].map(k => em?.headers?.[k] && (
                          <span key={k} style={{ fontFamily:"var(--mono)", fontSize:9, fontWeight:700, padding:"1px 6px", borderRadius:3, background: em.headers[k]==="PASS"?"rgba(52,211,153,0.15)":"rgba(248,113,113,0.15)", color: em.headers[k]==="PASS"?"var(--green)":"var(--red)" }}>{k}:{em.headers[k]}</span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Form */}
                <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
                  <div>
                    <label style={{ display:"block", fontSize:10, fontWeight:600, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:6 }}>Case Title *</label>
                    <input value={caseForm.title} onChange={e=>setCaseForm(p=>({...p,title:e.target.value}))} placeholder="e.g. Phishing — Microsoft 365 Impersonation" />
                  </div>

                  <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12 }}>
                    <div>
                      <label style={{ display:"block", fontSize:10, fontWeight:600, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:6 }}>Severity</label>
                      <select value={caseForm.sev} onChange={e=>setCaseForm(p=>({...p,sev:e.target.value}))}>
                        {["Critical","High","Medium","Low"].map(s=><option key={s}>{s}</option>)}
                      </select>
                    </div>
                    <div>
                      <label style={{ display:"block", fontSize:10, fontWeight:600, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:6 }}>Priority</label>
                      <select value={caseForm.priority} onChange={e=>setCaseForm(p=>({...p,priority:e.target.value}))}>
                        {["P1","P2","P3","P4"].map(p=><option key={p}>{p}</option>)}
                      </select>
                    </div>
                    <div>
                      <label style={{ display:"block", fontSize:10, fontWeight:600, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:6 }}>Assignee</label>
                      <select value={caseForm.assignee} onChange={e=>setCaseForm(p=>({...p,assignee:e.target.value}))}>
                        {["John Mercer","Sarah Okafor","Priya Kapoor","SOC Tier-1"].map(a=><option key={a}>{a}</option>)}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label style={{ display:"block", fontSize:10, fontWeight:600, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:6 }}>Tags (comma-separated)</label>
                    <input value={caseForm.tags} onChange={e=>setCaseForm(p=>({...p,tags:e.target.value}))} placeholder="phishing, credential-harvesting, microsoft-spoof" />
                  </div>

                  <div>
                    <label style={{ display:"block", fontSize:10, fontWeight:600, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:6 }}>Initial Case Description</label>
                    <textarea value={caseForm.description} onChange={e=>setCaseForm(p=>({...p,description:e.target.value}))} rows={4} placeholder="Describe the initial findings and what triggered this case…" />
                  </div>

                  {/* What gets auto-populated */}
                  <div style={{ background:"rgba(56,189,248,0.04)", border:"1px solid rgba(56,189,248,0.2)", borderRadius:7, padding:"10px 14px" }}>
                    <div style={{ fontSize:10, fontWeight:600, color:"var(--accent)", fontFamily:"var(--mono)", letterSpacing:"0.06em", marginBottom:8 }}>AUTO-POPULATED ON CREATION</div>
                    {[
                      "Email headers and auth failures extracted as evidence",
                      "Sender IP and domain registered as IOCs",
                      "Phishing indicators logged to case timeline",
                      "Alert linked to case in SIEM",
                      "Initial timeline event created",
                    ].map((a,i) => (
                      <div key={i} style={{ display:"flex", alignItems:"center", gap:8, padding:"2px 0" }}>
                        <i className="ti ti-circle-check" style={{ color:"var(--accent)", fontSize:11, flexShrink:0 }} aria-hidden="true" />
                        <span style={{ fontSize:11, color:"var(--text2)" }}>{a}</span>
                      </div>
                    ))}
                  </div>

                  <div style={{ display:"flex", gap:10, justifyContent:"flex-end", paddingTop:4 }}>
                    <BtnGhost onClick={()=>setShowCreateCase(false)}>Cancel</BtnGhost>
                    <BtnPrimary onClick={submitCreateCase} icon="ti-folder-plus" disabled={!caseForm.title.trim()}>
                      Create Case &amp; Open Investigation
                    </BtnPrimary>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Quarantine success toast */}
      {quarantineSuccess && (
        <div style={{ position:"fixed", bottom:24, left:"50%", transform:"translateX(-50%)", zIndex:700, background:"rgba(6,14,26,0.97)", border:"1px solid rgba(245,158,11,0.5)", borderRadius:10, padding:"12px 20px", display:"flex", alignItems:"center", gap:12, boxShadow:"0 8px 32px rgba(0,0,0,0.7)", minWidth:320, animation:"fadein 0.25s ease-out" }}>
          <div style={{ width:32, height:32, borderRadius:"50%", background:"rgba(52,211,153,0.15)", border:"1px solid rgba(52,211,153,0.4)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
            <i className="ti ti-shield-check" style={{ color:"var(--green)", fontSize:16 }} aria-hidden="true" />
          </div>
          <div>
            <div style={{ fontSize:13, fontWeight:600, color:"var(--text1)" }}>Email quarantined successfully</div>
            <div style={{ fontSize:11, color:"var(--text3)", fontFamily:"var(--mono)", marginTop:2 }}>Moved to Quarantine folder · IOCs logged</div>
          </div>
          <button onClick={()=>setQuarantineSuccess(null)} style={{ marginLeft:"auto", background:"transparent", border:"none", color:"var(--text3)", cursor:"pointer", fontSize:16, lineHeight:1 }}>✕</button>
        </div>
      )}

      {/* Quarantine confirmation modal */}
      {showQuarantineModal && quarantineTarget && (() => {
        const targetEmail = ALL_EMAILS.find(e => e.id === quarantineTarget);
        return (
          <div style={{ position:"absolute", inset:0, zIndex:500, background:"rgba(6,14,26,0.88)", display:"flex", alignItems:"center", justifyContent:"center", padding:20 }}>
            <div style={{ background:"var(--card)", border:"1px solid rgba(245,158,11,0.4)", borderRadius:12, width:Math.min(500,w-32), overflow:"hidden", boxShadow:"0 20px 60px rgba(0,0,0,0.7)", animation:"fadein 0.2s ease-out" }}>
              {/* Header */}
              <div style={{ background:"rgba(245,158,11,0.08)", borderBottom:"1px solid rgba(245,158,11,0.25)", padding:"14px 20px", display:"flex", alignItems:"center", gap:12 }}>
                <div style={{ width:36, height:36, borderRadius:8, background:"rgba(245,158,11,0.15)", border:"1px solid rgba(245,158,11,0.35)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                  <i className="ti ti-shield-x" style={{ color:"var(--amber)", fontSize:18 }} aria-hidden="true" />
                </div>
                <div>
                  <div style={{ fontSize:14, fontWeight:700, color:"var(--text1)" }}>Quarantine Email</div>
                  <div style={{ fontSize:10, color:"var(--text3)", fontFamily:"var(--mono)", marginTop:2 }}>This action will isolate the message and log it as a security event</div>
                </div>
              </div>

              <div style={{ padding:"18px 20px" }}>
                {/* Target email info */}
                <div style={{ background:"var(--card-hi)", border:"1px solid var(--border)", borderRadius:7, padding:"10px 14px", marginBottom:16 }}>
                  <div style={{ fontSize:11, color:"var(--text3)", marginBottom:4 }}>Target message</div>
                  <div style={{ fontSize:12, fontWeight:600, color:"var(--text1)", marginBottom:3 }}>{targetEmail?.subject}</div>
                  <div style={{ fontFamily:"var(--mono)", fontSize:11, color: targetEmail?.isPhishing ? "var(--red)" : "var(--text2)" }}>{targetEmail?.from.email}</div>
                </div>

                {/* Reason */}
                <div style={{ marginBottom:14 }}>
                  <label style={{ display:"block", fontSize:10, fontWeight:600, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:6 }}>Quarantine Reason</label>
                  <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                    {[
                      {val:"phishing", label:"Phishing / Social Engineering", icon:"ti-fish-hook"},
                      {val:"malware", label:"Malware / Malicious Attachment", icon:"ti-virus"},
                      {val:"spam", label:"Spam / Unsolicited", icon:"ti-ban"},
                      {val:"suspicious", label:"Suspicious / Under Investigation", icon:"ti-eye"},
                    ].map(r => (
                      <button key={r.val} onClick={()=>setQuarantineReason(r.val)}
                        style={{ display:"flex", alignItems:"center", gap:6, padding:"6px 12px", borderRadius:6, border:`1px solid ${quarantineReason===r.val?"rgba(245,158,11,0.6)":"var(--border)"}`, background: quarantineReason===r.val?"rgba(245,158,11,0.1)":"transparent", color: quarantineReason===r.val?"var(--amber)":"var(--text2)", fontSize:11, cursor:"pointer", fontWeight: quarantineReason===r.val?600:400, transition:"all 0.1s" }}>
                        <i className={`ti ${r.icon}`} style={{ fontSize:12 }} aria-hidden="true" />
                        {r.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Analyst note */}
                <div style={{ marginBottom:18 }}>
                  <label style={{ display:"block", fontSize:10, fontWeight:600, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:6 }}>Analyst Note (optional)</label>
                  <textarea value={quarantineNote} onChange={e=>setQuarantineNote(e.target.value)}
                    placeholder="e.g. Phishing email impersonating DocuSign — confirmed SPF/DKIM/DMARC failures. Campaign ID: phish-docusign-ent-052025-b. IOCs logged in INC-2025-0312."
                    rows={3} style={{ fontSize:11 }} />
                </div>

                {/* Actions this quarantine will perform */}
                <div style={{ background:"rgba(52,211,153,0.05)", border:"1px solid rgba(52,211,153,0.2)", borderRadius:7, padding:"10px 14px", marginBottom:18 }}>
                  <div style={{ fontSize:10, fontWeight:600, color:"var(--green)", fontFamily:"var(--mono)", letterSpacing:"0.06em", marginBottom:8 }}>ACTIONS THAT WILL BE TAKEN</div>
                  {[
                    "Message moved to Quarantine folder",
                    "Sender added to temporary block-list",
                    "Security event logged in audit trail",
                    "Case INC-2025-0312 updated with quarantine action",
                    "User notification sent (no further interaction required)",
                  ].map((a,i) => (
                    <div key={i} style={{ display:"flex", alignItems:"center", gap:8, padding:"3px 0" }}>
                      <i className="ti ti-circle-check" style={{ color:"var(--green)", fontSize:12, flexShrink:0 }} aria-hidden="true" />
                      <span style={{ fontSize:11, color:"var(--text2)" }}>{a}</span>
                    </div>
                  ))}
                </div>

                {/* Buttons */}
                <div style={{ display:"flex", gap:10, justifyContent:"flex-end" }}>
                  <BtnGhost onClick={()=>setShowQuarantineModal(false)}>Cancel</BtnGhost>
                  <BtnPrimary onClick={confirmQuarantine} icon="ti-shield-x" danger>Confirm Quarantine</BtnPrimary>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Domain enrichment modal */}
      {enrichTarget && ENRICH[enrichTarget] && (
        <div style={{ position:"absolute", inset:0, zIndex:400, background:"rgba(6,14,26,0.85)", display:"flex", alignItems:"center", justifyContent:"center", padding:16 }}>
          <Card style={{ width:Math.min(540,w-32), maxHeight:"80vh", overflow:"auto" }} accent>
            <CardHead icon="ti-virus" title={`Domain Intelligence — ${enrichTarget}`} />
            <div style={{ padding:"16px 18px" }}>
              {(() => { const e=ENRICH[enrichTarget];
                return (
                  <>
                    <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:14 }}>
                      <Chip color="var(--red)">VT: {e.vt} — {e.vtLabel}</Chip>
                      {e.isTor && <Chip color="var(--red)">TOR EXIT NODE</Chip>}
                      {e.abuse && <Chip color="var(--amber)">AbuseIPDB: {e.abuse}%</Chip>}
                    </div>
                    <p style={{ fontSize:12.5, color:"var(--text2)", lineHeight:1.7, marginBottom:14, background:"var(--card-hi)", padding:"10px 12px", borderRadius:6, border:"1px solid var(--border)" }}>{e.summary}</p>
                    {[["Registrar",e.registrar],["Registered",e.registered],["Registrant",e.registrant],["ASN",e.asn],["Country / City",`${e.country||"—"} / ${e.city||"—"}`],["Categories",e.categories?.join(", ")],["Passive DNS",e.passivedns?.join(", ")]].filter(([,v])=>v).map(([k,v]) => <KvRow key={k} k={k} v={v} mono />)}
                    <div style={{ display:"flex", gap:8, marginTop:14 }}>
                      <BtnPrimary onClick={()=>{setEnrichTarget(null);onNav("investigation");}} icon="ti-folder-open" sm amber>Open Case IOCs</BtnPrimary>
                      <BtnGhost onClick={()=>setEnrichTarget(null)} sm>Close</BtnGhost>
                    </div>
                  </>
                );
              })()}
            </div>
          </Card>
        </div>
      )}

      {/* Mobile nav */}
      {!isDesktop && showNav && (
        <div style={{ position:"absolute", inset:0, zIndex:300, display:"flex" }}>
          <div style={{ width:220, height:"100%" }}>{Sidebar}</div>
          <div style={{ flex:1, background:"rgba(0,0,0,0.7)" }} onClick={()=>setShowNav(false)} />
        </div>
      )}

      {isDesktop && <div style={{ width:196, flexShrink:0 }}>{Sidebar}</div>}

      <div style={{ flex:1, display:"flex", overflow:"hidden", minWidth:0 }}>
        {(!isMobile || !selId) && (
          <div style={{ width: isDesktop?272:isTablet?240:"100%", flexShrink:0, borderRight:(isDesktop||isTablet)?"1px solid var(--border)":"none", overflow:"hidden", display:"flex", flexDirection:"column" }}>
            {EmailList}
          </div>
        )}
        {(isDesktop || isTablet || (isMobile && selId)) && (
          <div style={{ flex:1, overflow:"hidden", display:"flex", flexDirection:"column", minWidth:0 }}>
            {EmailView}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── INVESTIGATION ────────────────────────────────────────────────────────────
function Investigation({ onNav, cases, setCases, openCaseId, setOpenCaseId }) {
  const w = useWidth();
  const isMobile = w < 640;
  const [tab, setTab] = useState("overview");
  const [iocs, setIocs] = useState(IOCS_INIT);
  const [notes, setNotes] = useState(NOTES_INIT);

  // Resolve active case — fall back to pre-existing if nothing else selected
  const preExistingCase = cases.find(c => c.isPreExisting) || cases[0];
  const ACTIVE_CASE_META = cases.find(c => c.id === openCaseId) || preExistingCase;
  // For pre-existing case, use full CASE constant data; for new cases, build from meta
  const isPreExisting = ACTIVE_CASE_META?.isPreExisting;
  const CASE = isPreExisting ? {
    id: ACTIVE_CASE_META.id,
    title: ACTIVE_CASE_META.title,
    status: ACTIVE_CASE_META.status,
    sev: ACTIVE_CASE_META.sev,
    priority: ACTIVE_CASE_META.priority,
    sla: "2025-05-16T07:45:00",
    assignee: ACTIVE_CASE_META.assignee,
    created: ACTIVE_CASE_META.created,
    updated: ACTIVE_CASE_META.updated,
    reporter: ACTIVE_CASE_META.reporter,
    affectedUsers: ACTIVE_CASE_META.affectedUsers,
    affectedAssets: ["mx1.vantara.io","VANT-JM-001","VANT-PK-001"],
    tags: ACTIVE_CASE_META.tags,
    mitre: ["T1566.001","T1598.003","T1090.003","T1110.004","T1078","T1027"],
    summary: `At 03:18 UTC on 15 May 2025, a targeted spear-phishing email impersonating DocuSign was delivered to john.mercer@vantara.io through the Vantara mail gateway. The message passed below the quarantine threshold (spam score 8.4 vs threshold 9.0) despite triple authentication failure (SPF/DKIM/DMARC). The sending IP (${PHISH_IP}) is attributed to a Tor exit-node operated by OVH SAS Romania and was independently flagged in an FS-ISAC threat-intel feed.

A second recipient (priya.kapoor@vantara.io) submitted a phishing report at 09:12 UTC confirming the campaign targeted at least two employees. DNS proxy logs indicate john.mercer's workstation issued a query to the phishing harvest domain (${HARVEST}) at 07:44 UTC — blocked by proxy, no HTTP connection established.

At 10:45–10:48 UTC, three MFA push notifications were sent to john.mercer from the attacker IP. All denied. Azure AD logs: no credential compromise confirmed. IOCs contained.`,
    actions: [
      {d:"2025-05-15T08:45:00",a:"IOCs added to perimeter block-list",who:"John Mercer",done:true},
      {d:"2025-05-15T09:00:00",a:"Victim notification sent (john.mercer & priya.kapoor)",who:"John Mercer",done:true},
      {d:"2025-05-15T10:55:00",a:"Azure AD CA policy updated — Tor range blocked",who:"John Mercer",done:true},
      {d:"2025-05-15T10:58:00",a:"Password reset initiated for john.mercer",who:"System",done:true},
      {d:"2025-05-16T10:22:00",a:"IOCs shared to FS-ISAC (TLP:AMBER)",who:"John Mercer",done:true},
      {d:"2025-05-17T09:00:00",a:"7-day Azure AD extended log review",who:"John Mercer",done:false},
      {d:"2025-05-18T17:00:00",a:"SLA deadline — closure report",who:"System",done:false},
    ],
  } : {
    id: ACTIVE_CASE_META?.id || "N/A",
    title: ACTIVE_CASE_META?.title || "Untitled Case",
    status: ACTIVE_CASE_META?.status || "Open",
    sev: ACTIVE_CASE_META?.sev || "High",
    priority: ACTIVE_CASE_META?.priority || "P1",
    sla: new Date(Date.now() + 86400000).toISOString(),
    assignee: ACTIVE_CASE_META?.assignee || ME.name,
    created: ACTIVE_CASE_META?.created || new Date().toISOString(),
    updated: ACTIVE_CASE_META?.updated || new Date().toISOString(),
    reporter: ACTIVE_CASE_META?.reporter || ME.name,
    affectedUsers: ACTIVE_CASE_META?.affectedUsers || [ME.email],
    affectedAssets: ["mx1.vantara.io"],
    tags: ACTIVE_CASE_META?.tags || ["phishing"],
    mitre: ["T1566.001","T1598.003"],
    summary: ACTIVE_CASE_META?.description || "Investigation in progress.",
    actions: [
      {d: ACTIVE_CASE_META?.created || new Date().toISOString(), a:"Case opened from mailbox escalation", who: ACTIVE_CASE_META?.assignee || ME.name, done:true},
      {d: ACTIVE_CASE_META?.created || new Date().toISOString(), a:"Sender IP 91.108.56.212 added to IOC list", who: ME.name, done:false},
      {d: ACTIVE_CASE_META?.created || new Date().toISOString(), a:"Domain ms-account-alerts.net flagged for block", who: ME.name, done:false},
      {d: ACTIVE_CASE_META?.created || new Date().toISOString(), a:"Notify affected user — verify no credential entry", who: ME.name, done:false},
      {d: ACTIVE_CASE_META?.created || new Date().toISOString(), a:"Confirm geo-mismatch (Frankfurt sender vs Lagos sign-in)", who: ME.name, done:false},
    ],
  };
  const [noteText, setNoteText] = useState("");
  const [showAddIOC, setShowAddIOC] = useState(false);
  const [newIOC, setNewIOC] = useState({type:"Domain",value:"",conf:"High",tlp:"AMBER",tags:""});
  const [enrichTarget, setEnrichTarget] = useState(null);
  const [showSide, setShowSide] = useState(!isMobile);
  const tabScrollRef = useRef(null);

  const TABS = [
    {id:"overview",  label:"Overview",  icon:"ti-layout-dashboard"},
    {id:"timeline",  label:"Timeline",  icon:"ti-timeline"},
    {id:"iocs",      label:"IOCs",      icon:"ti-virus"},
    {id:"logs",      label:"Log Corr.", icon:"ti-database"},
    {id:"mitre",     label:"ATT&CK",    icon:"ti-crosshair"},
    {id:"evidence",  label:"Evidence",  icon:"ti-file-certificate"},
    {id:"notes",     label:"Notes",     icon:"ti-notes"},
    {id:"actor",     label:"Actor",     icon:"ti-user-question"},
  ];

  useEffect(() => { if (tabScrollRef.current) tabScrollRef.current.scrollTop = 0; }, [tab]);

  function addNote() {
    if (!noteText.trim()) return;
    setNotes(p => [{id:`N${Date.now()}`,author:ME.name,role:ME.tier,time:new Date().toISOString(),content:noteText.trim(),tags:["analyst-note"]},...p]);
    setNoteText("");
  }
  function addIOC() {
    if (!newIOC.value.trim()) return;
    setIocs(p => [{id:`IOC-${String(Date.now()).slice(-3)}`,type:newIOC.type,value:newIOC.value,conf:newIOC.conf,tlp:newIOC.tlp,status:"active",source:"Manual",tags:newIOC.tags.split(",").map(t=>t.trim()).filter(Boolean),added:new Date().toISOString(),ctx:"Manually added by analyst"},...p]);
    setNewIOC({type:"Domain",value:"",conf:"High",tlp:"AMBER",tags:""});
    setShowAddIOC(false);
  }

  const SidePanel = (
    <div style={{ width:isMobile?"100%":240, background:"var(--surface)", borderRight:"1px solid var(--border)", display:"flex", flexDirection:"column", flexShrink:0, overflow:"hidden" }}>
      <div style={{ padding:"14px 14px 12px", borderBottom:"1px solid var(--border)" }}>
        <VantaraLogo size="sidebar" />
        <div style={{ marginTop:8, fontFamily:"var(--mono)", fontSize:9, color:"var(--text3)", letterSpacing:"0.08em" }}>CipherOps DFIR · v3.0</div>
      </div>

      <div style={{ padding:"10px 12px", borderBottom:"1px solid var(--border)" }}>
        <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:8 }}>
          <span style={{ fontSize:9, fontWeight:700, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.1em", textTransform:"uppercase", flex:1 }}>Cases ({cases.length})</span>
          {cases.length > 1 && <span style={{ fontSize:9, color:"var(--accent)", fontFamily:"var(--mono)" }}>click to switch</span>}
        </div>
        {cases.map(c => (
          <div key={c.id} onClick={()=>{ setOpenCaseId(c.id); setTab("overview"); }}
            style={{ background: c.id===CASE.id ? "var(--card-hi)" : "var(--card)", border: c.id===CASE.id ? "1px solid rgba(56,189,248,0.35)" : "1px solid var(--border)", borderLeft: c.id===CASE.id ? "3px solid var(--accent)" : "3px solid transparent", borderRadius:6, padding:"9px 11px", marginBottom:6, cursor:"pointer", transition:"all 0.15s" }}>
            <div style={{ display:"flex", gap:5, alignItems:"center", marginBottom:3 }}>
              <span style={{ fontFamily:"var(--mono)", fontSize:9, color: c.id===CASE.id ? "var(--accent)" : "var(--text3)" }}>{c.id}</span>
              {c.isPreExisting && <span style={{ fontFamily:"var(--mono)", fontSize:8, color:"var(--green)", background:"rgba(52,211,153,0.1)", border:"1px solid rgba(52,211,153,0.25)", padding:"0 5px", borderRadius:3 }}>REGISTERED</span>}
              {!c.isPreExisting && <span style={{ fontFamily:"var(--mono)", fontSize:8, color:"var(--amber)", background:"rgba(245,158,11,0.1)", border:"1px solid rgba(245,158,11,0.25)", padding:"0 5px", borderRadius:3 }}>NEW</span>}
            </div>
            <div style={{ fontSize:11, fontWeight:600, color:"var(--text1)", lineHeight:1.35, marginBottom:5 }}>{c.title}</div>
            <div style={{ display:"flex", gap:5, flexWrap:"wrap" }}>
              <SevBadge level={c.sev} sm />
              <span className="tag" style={{ background:"rgba(245,158,11,0.08)", color:"var(--amber)", border:"1px solid rgba(245,158,11,0.25)", fontSize:8 }}>{c.status}</span>
            </div>
          </div>
        ))}
      </div>

      <div style={{ padding:"8px 12px", borderBottom:"1px solid var(--border)" }}>
        <div style={{ fontSize:9, fontWeight:700, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.1em", marginBottom:6, textTransform:"uppercase" }}>Linked Alerts</div>
        {ALERTS.filter(a=>a.case).map(a => (
          <div key={a.id} style={{ padding:"6px 8px", background:"var(--card)", border:"1px solid var(--border)", borderRadius:5, marginBottom:5 }}>
            <div style={{ display:"flex", gap:6, alignItems:"center", marginBottom:3 }}>
              <PulseIcon color={SEV_T[a.sev]?.dot||"var(--amber)"} />
              <span style={{ fontFamily:"var(--mono)", fontSize:9, color:"var(--accent)" }}>{a.id}</span>
              <SevBadge level={a.sev} sm />
            </div>
            <div style={{ fontSize:10, color:"var(--text2)", lineHeight:1.35 }}>{a.title}</div>
          </div>
        ))}
      </div>

      <div style={{ flex:1 }} />
      <div style={{ padding:"10px 12px", display:"flex", flexDirection:"column", gap:6 }}>
        <BtnGhost onClick={()=>onNav("mailbox")} icon="ti-mail" sm>Open Mailbox</BtnGhost>
        <BtnGhost onClick={()=>onNav("soc")} icon="ti-layout-dashboard" sm>SOC Dashboard</BtnGhost>
      </div>

      <div style={{ padding:"12px 14px 16px", borderTop:"1px solid var(--border)" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <Avatar name={ME.name} size={32} accent />
          <div>
            <div style={{ fontSize:12, fontWeight:600, color:"var(--text1)" }}>{ME.name}</div>
            <div style={{ fontSize:9, color:"var(--text3)", fontFamily:"var(--mono)" }}>SOC Analyst {ME.tier}</div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ display:"flex", height:"100%", overflow:"hidden", position:"relative" }}>
      {isMobile && showSide && (
        <div style={{ position:"absolute", inset:0, zIndex:200, display:"flex" }}>
          <div style={{ width:260, height:"100%" }}>{SidePanel}</div>
          <div style={{ flex:1, background:"rgba(0,0,0,0.7)" }} onClick={()=>setShowSide(false)} />
        </div>
      )}
      {!isMobile && SidePanel}

      <div style={{ flex:1, display:"flex", flexDirection:"column", minWidth:0, overflow:"hidden" }}>
        {/* Case header */}
        <div style={{ background:"var(--card)", borderBottom:"1px solid var(--border)", padding:"12px 18px", flexShrink:0 }}>
          {isMobile && <button onClick={()=>setShowSide(v=>!v)} style={{ background:"transparent", border:"none", color:"var(--text3)", cursor:"pointer", fontSize:18, marginBottom:8 }}><i className="ti ti-menu-2" aria-hidden="true" /></button>}
          <div style={{ display:"flex", flexWrap:"wrap", gap:8, alignItems:"center", marginBottom:6 }}>
            <span style={{ fontFamily:"var(--mono)", fontSize:10, background:"var(--card-hi)", color:"var(--text3)", padding:"2px 9px", borderRadius:4, border:"1px solid var(--border)" }}>{CASE.id}</span>
            <SevBadge level={CASE.sev} />
            <Chip color="var(--amber)">{CASE.priority}</Chip>
            <Chip color="var(--amber)">{CASE.status}</Chip>
            <span style={{ marginLeft:"auto", fontSize:10, color:"var(--red)", fontFamily:"var(--mono)" }}><i className="ti ti-alarm" style={{ marginRight:4 }} aria-hidden="true" />SLA: {fmtShort(CASE.sla)}</span>
          </div>
          <h2 style={{ fontSize: isMobile?13:16, fontWeight:700, color:"var(--text1)", lineHeight:1.3, wordBreak:"break-word", margin:"0 0 6px" }}>{CASE.title}</h2>
          <div style={{ fontSize:11, color:"var(--text3)", fontFamily:"var(--mono)", display:"flex", gap:14, flexWrap:"wrap" }}>
            <span><i className="ti ti-user" style={{ marginRight:4 }} aria-hidden="true" />{CASE.assignee}</span>
            <span><i className="ti ti-clock" style={{ marginRight:4 }} aria-hidden="true" />{fmtTs(CASE.updated)}</span>
          </div>
        </div>

        {/* Tab bar */}
        <div style={{ background:"var(--surface)", borderBottom:"1px solid var(--border)", padding:"0 18px", display:"flex", gap:0, overflowX:"auto", flexShrink:0 }}>
          {TABS.map(t => (
            <button key={t.id} onClick={()=>setTab(t.id)}
              style={{ display:"flex", alignItems:"center", gap:5, padding:"9px 14px", background:"transparent", border:"none", fontSize:11, fontWeight:500, cursor:"pointer", color: tab===t.id?"var(--accent)":"var(--text3)", borderBottom: tab===t.id?"2px solid var(--accent)":"2px solid transparent", whiteSpace:"nowrap", transition:"color 0.15s" }}>
              <i className={`ti ${t.icon}`} style={{ fontSize:12 }} aria-hidden="true" />
              {t.label}
            </button>
          ))}
        </div>

        {/* Tab content — scroll container */}
        <div ref={tabScrollRef} style={{ flex:1, overflowY:"auto", padding: isMobile?"12px 10px":"18px 22px", background:"var(--bg)" }}>

          {tab==="overview" && (
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>

              {/* New case notice */}
              {!isPreExisting && (
                <div style={{ background:"rgba(56,189,248,0.06)", border:"1px solid rgba(56,189,248,0.3)", borderRadius:8, padding:"14px 18px" }}>
                  <div style={{ display:"flex", gap:10, alignItems:"flex-start" }}>
                    <div style={{ width:36, height:36, borderRadius:7, background:"rgba(56,189,248,0.1)", border:"1px solid rgba(56,189,248,0.3)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                      <i className="ti ti-folder-plus" style={{ color:"var(--accent)", fontSize:17 }} aria-hidden="true" />
                    </div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:13, fontWeight:700, color:"var(--text1)", marginBottom:4 }}>Case {CASE.id} — Newly Created</div>
                      <p style={{ fontSize:12, color:"var(--text2)", lineHeight:1.7, marginBottom:10 }}>
                        This case was just opened from a phishing email in your mailbox. The investigation platform has auto-populated initial evidence from the email headers and auth failures. Begin your analysis using the Timeline, IOCs, and Log Correlation tabs.
                      </p>
                      <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                        <BtnPrimary onClick={()=>setTab("timeline")} icon="ti-timeline" sm>View Timeline</BtnPrimary>
                        <BtnPrimary onClick={()=>setTab("iocs")} icon="ti-virus" sm>Add IOCs</BtnPrimary>
                        <BtnGhost onClick={()=>onNav("mailbox")} icon="ti-mail" sm>Return to Mailbox</BtnGhost>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(120px,1fr))", gap:10 }}>
                <MetricCard label="IOCs" value={iocs.length} icon="ti-virus" color="var(--red)" />
                <MetricCard label="Evidence" value={EVIDENCE.length} icon="ti-file-certificate" color="var(--accent)" />
                <MetricCard label="Timeline" value={TIMELINE_EVENTS.length} icon="ti-timeline" color="var(--purple)" />
                <MetricCard label="Notes" value={notes.length} icon="ti-notes" color="var(--green)" />
                <MetricCard label="Users" value={CASE.affectedUsers.length} icon="ti-users" color="var(--amber)" />
                <MetricCard label="TTPs" value={isPreExisting ? CASE.mitre.length : MITRE_TTPS.filter(t=>CASE.mitre.includes(t.id)).length} icon="ti-crosshair" color="var(--red)" />
              </div>

              <div style={{ display:"grid", gridTemplateColumns: isMobile?"1fr":"2fr 1fr", gap:14 }}>
                <Card>
                  <CardHead icon="ti-report" title="Case Summary" />
                  <div style={{ padding:"14px 16px" }}>
                    {CASE.summary.split("\n\n").map((p,i) => <p key={i} style={{ fontSize:12.5, color:"var(--text2)", lineHeight:1.75, marginBottom: i<CASE.summary.split("\n\n").length-1?12:0 }}>{p}</p>)}
                  </div>
                </Card>
                <Card>
                  <CardHead icon="ti-list-check" title="Action Tracker" right={CASE.id} />
                  <div style={{ padding:"8px 14px" }}>
                    {(CASE.actions || []).map((item,i) => (
                      <div key={i} style={{ display:"flex", gap:9, padding:"7px 0", borderBottom:"1px solid var(--border)", alignItems:"flex-start" }}>
                        <i className={`ti ${item.done?"ti-circle-check":"ti-circle-dashed"}`} style={{ fontSize:14, color:item.done?"var(--green)":"var(--amber)", flexShrink:0, marginTop:1 }} aria-hidden="true" />
                        <div style={{ flex:1 }}>
                          <div style={{ fontSize:11, color:item.done?"var(--text3)":"var(--text2)" }}>{item.a}</div>
                          <div style={{ fontSize:9, color:"var(--text3)", fontFamily:"var(--mono)" }}>{item.who} · {fmtShort(item.d)}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>

              <div style={{ display:"grid", gridTemplateColumns: isMobile?"1fr":"1fr 1fr", gap:12 }}>
                <Card>
                  <CardHead icon="ti-user-exclamation" title="Affected Users" />
                  <div style={{ padding:"8px 14px" }}>
                    {CASE.affectedUsers.map(u => {
                      const usr=USERS[u];
                      const rc=(usr?.risk||0)>40?"var(--red)":"var(--amber)";
                      return (
                        <div key={u} style={{ display:"flex", gap:10, padding:"8px 0", borderBottom:"1px solid var(--border)", alignItems:"center" }}>
                          <Avatar name={usr?.name||u} size={32} />
                          <div style={{ flex:1 }}>
                            <div style={{ fontSize:12, fontWeight:600, color:"var(--text1)" }}>{usr?.name||u}</div>
                            <div style={{ fontSize:10, color:"var(--text3)", fontFamily:"var(--mono)" }}>{u}</div>
                          </div>
                          <span style={{ fontSize:10, fontFamily:"var(--mono)", color:rc, fontWeight:700 }}>Risk: {usr?.risk||"?"}</span>
                        </div>
                      );
                    })}
                  </div>
                </Card>
                <Card>
                  <CardHead icon="ti-crosshair" title="Confirmed TTPs" />
                  <div style={{ padding:"8px 14px" }}>
                    {MITRE_TTPS.slice(0,4).map(t => (
                      <div key={t.id} onClick={()=>setTab("mitre")} style={{ display:"flex", gap:8, padding:"7px 0", borderBottom:"1px solid var(--border)", alignItems:"center", cursor:"pointer" }}>
                        <span style={{ fontFamily:"var(--mono)", fontSize:9, color:t.color, background:t.color+"18", border:"1px solid "+t.color+"40", padding:"1px 7px", borderRadius:3, flexShrink:0 }}>{t.id}</span>
                        <span style={{ fontSize:11, color:"var(--text2)", flex:1, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{t.name}</span>
                        <span style={{ fontSize:9, fontWeight:700, color:t.status==="confirmed"?"var(--red)":"var(--amber)", fontFamily:"var(--mono)", flexShrink:0 }}>{t.status}</span>
                      </div>
                    ))}
                    <button onClick={()=>setTab("mitre")} style={{ marginTop:8, fontSize:11, color:"var(--accent)", background:"transparent", border:"none", cursor:"pointer" }}>View full ATT&CK mapping →</button>
                  </div>
                </Card>
              </div>

              <Card>
                <CardHead icon="ti-tag" title="Case Tags" />
                <div style={{ padding:"12px 16px", display:"flex", gap:6, flexWrap:"wrap" }}>
                  {CASE.tags.map(t => <span key={t} style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text2)", background:"var(--card-hi)", border:"1px solid var(--border)", padding:"3px 10px", borderRadius:5 }}>{t}</span>)}
                </div>
              </Card>
            </div>
          )}

          {tab==="timeline" && (
            <div>
              <p style={{ fontSize:11, color:"var(--text3)", fontFamily:"var(--mono)", marginBottom:16 }}>{TIMELINE_EVENTS.length} events · Chronological</p>
              <div style={{ position:"relative", paddingLeft:4 }}>
                <div style={{ position:"absolute", left:22, top:0, bottom:0, width:1, background:"var(--border)" }} />
                {TIMELINE_EVENTS.map((evt,i) => {
                  const pc = PHASE_C[evt.phase]||"#94A3B8";
                  return (
                    <div key={i} style={{ display:"flex", gap:14, marginBottom:14 }}>
                      <div style={{ width:46, display:"flex", justifyContent:"center", alignItems:"flex-start", paddingTop:4, flexShrink:0 }}>
                        <div style={{ width:10, height:10, borderRadius:"50%", background:pc, border:"2px solid var(--bg)", zIndex:1 }} />
                      </div>
                      <div style={{ flex:1, background:"var(--card)", border:"1px solid var(--border)", borderLeft:`3px solid ${pc}`, borderRadius:"0 7px 7px 0", padding:"10px 14px", minWidth:0 }}>
                        <div style={{ display:"flex", flexWrap:"wrap", gap:8, alignItems:"center", marginBottom:6 }}>
                          <span style={{ fontSize:10, fontFamily:"var(--mono)", color:"var(--text3)" }}>{fmtTs(evt.time)}</span>
                          <span className="tag" style={{ background:pc+"18", color:pc, border:"1px solid "+pc+"40", fontSize:8, textTransform:"uppercase" }}>{evt.phase}</span>
                          {evt.mitre && <Chip color="var(--purple)">{evt.mitre}</Chip>}
                          {evt.sev==="critical" && <Chip color="var(--red)">CRITICAL</Chip>}
                        </div>
                        <p style={{ fontSize:12, color:"var(--text2)", lineHeight:1.65, marginBottom:5 }}>{evt.evt}</p>
                        <p style={{ fontSize:10, color:"var(--text3)", fontFamily:"var(--mono)" }}>
                          <i className="ti ti-user" style={{ marginRight:4, fontSize:10 }} aria-hidden="true" />{evt.actor}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {tab==="iocs" && (
            <div>
              {!isPreExisting && (
                <div style={{ background:"rgba(245,158,11,0.05)", border:"1px solid rgba(245,158,11,0.25)", borderRadius:7, padding:"10px 14px", marginBottom:14 }}>
                  <div style={{ fontSize:10, fontWeight:600, color:"var(--amber)", fontFamily:"var(--mono)", letterSpacing:"0.06em", marginBottom:5 }}>AUTO-EXTRACTED FROM EMAIL</div>
                  <p style={{ fontSize:11, color:"var(--text2)", lineHeight:1.6 }}>The sender IP, domain, and phishing URL have been auto-added as IOCs from the source email headers. Review and add additional indicators as your investigation progresses.</p>
                </div>
              )}
              <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:14, flexWrap:"wrap" }}>
                <p style={{ fontSize:11, color:"var(--text3)", fontFamily:"var(--mono)", flex:1 }}>{iocs.length} indicators · {iocs.filter(i=>i.status==="active").length} active</p>
                <BtnPrimary onClick={()=>setShowAddIOC(v=>!v)} icon="ti-plus" sm>Add IOC</BtnPrimary>
              </div>

              {showAddIOC && (
                <Card style={{ marginBottom:14 }}>
                  <CardHead icon="ti-virus" title="New Indicator of Compromise" />
                  <div style={{ padding:"14px 16px" }}>
                    <div style={{ display:"grid", gridTemplateColumns: isMobile?"1fr":"repeat(3,1fr)", gap:10, marginBottom:10 }}>
                      <div><label style={{ display:"block", fontSize:9, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.06em", marginBottom:4, textTransform:"uppercase" }}>Type</label>
                        <select value={newIOC.type} onChange={e=>setNewIOC(p=>({...p,type:e.target.value}))}>
                          {["Domain","URL","IPv4","Email","Hash-MD5","Hash-SHA256","ASN","String"].map(t=><option key={t}>{t}</option>)}
                        </select></div>
                      <div><label style={{ display:"block", fontSize:9, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.06em", marginBottom:4, textTransform:"uppercase" }}>Confidence</label>
                        <select value={newIOC.conf} onChange={e=>setNewIOC(p=>({...p,conf:e.target.value}))}>
                          {["High","Medium","Low"].map(c=><option key={c}>{c}</option>)}
                        </select></div>
                      <div><label style={{ display:"block", fontSize:9, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.06em", marginBottom:4, textTransform:"uppercase" }}>TLP</label>
                        <select value={newIOC.tlp} onChange={e=>setNewIOC(p=>({...p,tlp:e.target.value}))}>
                          {["RED","AMBER","GREEN","WHITE"].map(t=><option key={t}>{t}</option>)}
                        </select></div>
                    </div>
                    <div style={{ marginBottom:10 }}>
                      <label style={{ display:"block", fontSize:9, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.06em", marginBottom:4, textTransform:"uppercase" }}>Value</label>
                      <input value={newIOC.value} onChange={e=>setNewIOC(p=>({...p,value:e.target.value}))} placeholder="e.g. malicious-domain.net" />
                    </div>
                    <div style={{ marginBottom:12 }}>
                      <label style={{ display:"block", fontSize:9, color:"var(--text3)", fontFamily:"var(--mono)", letterSpacing:"0.06em", marginBottom:4, textTransform:"uppercase" }}>Tags (comma-separated)</label>
                      <input value={newIOC.tags} onChange={e=>setNewIOC(p=>({...p,tags:e.target.value}))} placeholder="phishing, c2, malware" />
                    </div>
                    <div style={{ display:"flex", gap:8 }}>
                      <BtnPrimary onClick={addIOC} icon="ti-plus" sm>Add IOC</BtnPrimary>
                      <BtnGhost onClick={()=>setShowAddIOC(false)} sm>Cancel</BtnGhost>
                    </div>
                  </div>
                </Card>
              )}

              <Card>
                <div style={{ overflowX:"auto" }}>
                  <table>
                    <thead><tr><th>ID</th><th>Type</th><th>Value</th><th>Conf</th><th>TLP</th><th>Status</th><th>Added</th><th></th></tr></thead>
                    <tbody>
                      {iocs.map(ioc => {
                        const cc = ioc.conf==="High"?"var(--red)":ioc.conf==="Medium"?"var(--amber)":"var(--text3)";
                        const hasE = !!ENRICH[ioc.value];
                        return (
                          <tr key={ioc.id} className="hoverable">
                            <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--accent)" }}>{ioc.id}</span></td>
                            <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text3)" }}>{ioc.type}</span></td>
                            <td style={{ maxWidth:220 }}>
                              <div style={{ fontFamily:"var(--mono)", fontSize:11, color:"var(--text1)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }} title={ioc.value}>{ioc.value}</div>
                              <div style={{ fontSize:10, color:"var(--text3)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{ioc.ctx}</div>
                            </td>
                            <td><span style={{ fontFamily:"var(--mono)", fontSize:10, fontWeight:700, color:cc }}>{ioc.conf}</span></td>
                            <td><TlpBadge tlp={ioc.tlp} /></td>
                            <td><span style={{ fontFamily:"var(--mono)", fontSize:9, fontWeight:700, color:ioc.status==="contained"?"var(--green)":"var(--amber)" }}>{ioc.status}</span></td>
                            <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text3)" }}>{fmtShort(ioc.added)}</span></td>
                            <td>{hasE && <BtnGhost onClick={()=>setEnrichTarget(ioc.value)} icon="ti-search" sm>Enrich</BtnGhost>}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </Card>

              {enrichTarget && ENRICH[enrichTarget] && (() => {
                const e=ENRICH[enrichTarget];
                return (
                  <Card style={{ marginTop:14 }}>
                    <CardHead icon="ti-shield-search" title={`Enrichment — ${enrichTarget}`} right={<button onClick={()=>setEnrichTarget(null)} style={{ background:"transparent", border:"none", color:"var(--text3)", cursor:"pointer", fontSize:14 }}>✕</button>} />
                    <div style={{ padding:"14px 16px" }}>
                      <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:12 }}>
                        <Chip color="var(--red)">VT: {e.vt} — {e.vtLabel}</Chip>
                        {e.isTor && <Chip color="var(--red)">TOR EXIT NODE</Chip>}
                        {e.abuse && <Chip color="var(--amber)">AbuseIPDB: {e.abuse}%</Chip>}
                      </div>
                      <p style={{ fontSize:12.5, color:"var(--text2)", lineHeight:1.7, marginBottom:12, background:"var(--card-hi)", padding:"10px 12px", borderRadius:6, border:"1px solid var(--border)" }}>{e.summary}</p>
                      {[["Registrar",e.registrar],["Registered",e.registered],["Registrant",e.registrant],["ASN",e.asn],["Country / City",`${e.country||"—"} / ${e.city||"—"}`],["Categories",e.categories?.join(", ")],["Passive DNS",e.passivedns?.join(", ")]].filter(([,v])=>v).map(([k,v]) => <KvRow key={k} k={k} v={v} mono copy />)}
                    </div>
                  </Card>
                );
              })()}
            </div>
          )}

          {tab==="logs" && (
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              <Card>
                <CardHead icon="ti-lock-password" title="Authentication Logs — Correlated Events" />
                <div style={{ overflowX:"auto" }}>
                  <table>
                    <thead><tr><th>Timestamp</th><th>User</th><th>Action</th><th>Source IP</th><th>Geo</th><th>Device</th><th>Result</th><th>Risk</th></tr></thead>
                    <tbody>
                      {AUTH_LOGS.map((log,i) => {
                        const suspicious = log.src===PHISH_IP||log.risk==="critical";
                        return (
                          <tr key={i} style={{ background: suspicious?"rgba(248,113,113,0.04)":"transparent" }}>
                            <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text3)" }}>{fmtShort(log.time)}</span></td>
                            <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text2)" }}>{log.user}</span></td>
                            <td style={{ fontSize:11 }}>{log.action}</td>
                            <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:log.src===PHISH_IP?"var(--red)":"var(--text2)", fontWeight:log.src===PHISH_IP?700:400 }}>{log.src}</span></td>
                            <td><span style={{ fontSize:11, color:"var(--text3)" }}>{log.loc}</span></td>
                            <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text3)" }}>{log.device}</span></td>
                            <td><span style={{ fontFamily:"var(--mono)", fontSize:10, fontWeight:700, color: log.result.includes("SUCCESS")?"var(--green)":log.result==="DENIED"?"var(--amber)":log.result.includes("FAIL")?"var(--red)":"var(--text2)" }}>{log.result}</span></td>
                            <td><SevBadge level={log.risk==="none"?"info":log.risk} sm /></td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </Card>
              <Card>
                <CardHead icon="ti-network" title="Proxy / DNS Logs — Correlated Events" />
                <div style={{ overflowX:"auto" }}>
                  <table>
                    <thead><tr><th>Timestamp</th><th>User</th><th>Host</th><th>Action</th><th>URL / Domain</th><th>Category</th><th>Blocked</th><th>Risk</th></tr></thead>
                    <tbody>
                      {PROXY_LOGS.map((log,i) => (
                        <tr key={i} style={{ background: log.risk==="critical"?"rgba(248,113,113,0.04)":log.risk==="high"?"rgba(245,158,11,0.03)":"transparent" }}>
                          <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text3)" }}>{fmtShort(log.time)}</span></td>
                          <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text2)" }}>{log.user}</span></td>
                          <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text3)" }}>{log.host}</span></td>
                          <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color: log.action.includes("DNS")?"var(--purple)":"var(--accent)" }}>{log.action}</span></td>
                          <td style={{ maxWidth:200 }}><div style={{ fontFamily:"var(--mono)", fontSize:10, color: (log.url.includes(HARVEST)||log.url.includes(PHISH_DOM))?"var(--red)":"var(--text2)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }} title={log.url}>{log.url}</div></td>
                          <td><span style={{ fontSize:11, color:"var(--text3)" }}>{log.cat}</span></td>
                          <td>{log.blocked && <span className="tag" style={{ background:"var(--red-dim)", color:"var(--red)", border:"none", fontSize:9 }}>BLOCKED</span>}</td>
                          <td><SevBadge level={log.risk==="none"?"info":log.risk} sm /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            </div>
          )}

          {tab==="mitre" && (
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              <Card>
                <CardHead icon="ti-layout-grid" title="ATT&CK Tactic Coverage" />
                <div style={{ padding:"12px 16px", display:"flex", gap:6, flexWrap:"wrap" }}>
                  {["Initial Access","Execution","Persistence","Privilege Escalation","Defense Evasion","Credential Access","Discovery","Lateral Movement","Collection","Command & Control","Exfiltration","Impact"].map(tac => {
                    const active = MITRE_TTPS.some(t=>t.tactic===tac);
                    return <span key={tac} className="tag" style={{ background: active?"rgba(248,113,113,0.12)":"var(--card-hi)", color: active?"var(--red)":"var(--text3)", border:`1px solid ${active?"var(--red-dim)":"var(--border)"}`, padding:"3px 10px", fontSize:10 }}>{tac}</span>;
                  })}
                </div>
              </Card>
              {MITRE_TTPS.map(t => (
                <div key={t.id} style={{ background:"var(--card)", border:"1px solid var(--border)", borderLeft:`3px solid ${t.color}`, borderRadius:"0 8px 8px 0", padding:"14px 18px" }}>
                  <div style={{ display:"flex", flexWrap:"wrap", gap:8, alignItems:"center", marginBottom:8 }}>
                    <span style={{ fontFamily:"var(--mono)", fontSize:10, fontWeight:700, color:t.color, background:t.color+"18", border:"1px solid "+t.color+"40", padding:"2px 9px", borderRadius:4 }}>{t.id}</span>
                    <span style={{ fontSize:13, fontWeight:600, color:"var(--text1)" }}>{t.name}</span>
                    <span style={{ fontSize:11, color:"var(--text3)" }}>{t.tactic}</span>
                    <span style={{ marginLeft:"auto", fontSize:9, fontWeight:700, fontFamily:"var(--mono)", color:t.status==="confirmed"?"var(--red)":"var(--amber)", background:t.status==="confirmed"?"var(--red-dim)":"rgba(245,158,11,0.15)", padding:"2px 8px", borderRadius:3 }}>{t.status.toUpperCase()}</span>
                  </div>
                  <p style={{ fontSize:12.5, color:"var(--text2)", lineHeight:1.7, marginBottom:10 }}>{t.desc}</p>
                  <div style={{ display:"flex", flexWrap:"wrap", gap:5 }}>
                    {t.evidence.map((ev,i) => <span key={i} style={{ fontFamily:"var(--mono)", fontSize:9, color:"var(--text3)", background:"var(--card-hi)", border:"1px solid var(--border)", padding:"2px 8px", borderRadius:3 }}>{ev}</span>)}
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab==="evidence" && (
            <div>
              <p style={{ fontSize:11, color:"var(--text3)", fontFamily:"var(--mono)", marginBottom:14 }}>{EVIDENCE.length} items — chain of custody maintained</p>
              {EVIDENCE.map(ev => {
                const tc = {email:"var(--amber)",report:"var(--accent)",osint:"var(--purple)",logs:"var(--green)","threat-intel":"var(--red)"}[ev.type]||"var(--text2)";
                const ti = {email:"ti-mail",report:"ti-file-analytics",osint:"ti-world-search",logs:"ti-database","threat-intel":"ti-shield-search"}[ev.type]||"ti-file";
                return (
                  <div key={ev.id} style={{ background:"var(--card)", border:"1px solid var(--border)", borderRadius:7, padding:"13px 16px", marginBottom:8, display:"flex", gap:13, alignItems:"flex-start" }}>
                    <div style={{ width:36, height:36, borderRadius:7, background:tc+"18", border:"1px solid "+tc+"30", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                      <i className={`ti ${ti}`} style={{ color:tc, fontSize:18 }} aria-hidden="true" />
                    </div>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ fontSize:13, fontWeight:600, color:"var(--text1)", marginBottom:4 }}>{ev.name}</div>
                      <div style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text3)", wordBreak:"break-all", marginBottom:5 }}>{ev.hash}</div>
                      <div style={{ display:"flex", gap:14, flexWrap:"wrap", fontSize:11, color:"var(--text3)" }}>
                        <span>Size: {ev.size}</span>
                        <span>Added: {fmtTs(ev.added)}</span>
                        <span>Chain: {ev.chain}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {tab==="notes" && (
            <div>
              <Card style={{ marginBottom:16 }}>
                <CardHead icon="ti-notes" title="Add Investigation Note" />
                <div style={{ padding:"14px 16px" }}>
                  <textarea value={noteText} onChange={e=>setNoteText(e.target.value)} placeholder="Document your analysis, findings, or investigation steps…" rows={4} style={{ marginBottom:10 }} />
                  <BtnPrimary onClick={addNote} icon="ti-plus" sm>Submit Note</BtnPrimary>
                </div>
              </Card>
              {notes.map(n => (
                <div key={n.id} style={{ background:"var(--card)", border:"1px solid var(--border)", borderRadius:7, padding:"14px 16px", marginBottom:10 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:10, flexWrap:"wrap" }}>
                    <Avatar name={n.author} size={32} />
                    <div>
                      <div style={{ fontSize:12, fontWeight:600, color:"var(--text1)" }}>{n.author}</div>
                      <div style={{ fontSize:10, color:"var(--text3)", fontFamily:"var(--mono)" }}>{n.role} · {fmtTs(n.time)}</div>
                    </div>
                  </div>
                  <div style={{ fontSize:13, color:"var(--text2)", lineHeight:1.8, borderLeft:"2px solid rgba(56,189,248,0.35)", paddingLeft:14 }}>{n.content}</div>
                  <div style={{ display:"flex", gap:5, flexWrap:"wrap", marginTop:8 }}>
                    {n.tags?.map(t => <span key={t} style={{ fontFamily:"var(--mono)", fontSize:9, color:"var(--text3)", background:"var(--card-hi)", border:"1px solid var(--border)", padding:"1px 7px", borderRadius:3 }}>{t}</span>)}
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab==="actor" && (
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              <div style={{ background:"var(--card)", border:"1px solid rgba(248,113,113,0.3)", borderRadius:8, padding:"16px 18px" }}>
                <div style={{ display:"flex", gap:13, alignItems:"flex-start", flexWrap:"wrap", marginBottom:14 }}>
                  <div style={{ width:46, height:46, borderRadius:8, background:"rgba(248,113,113,0.1)", border:"1px solid rgba(248,113,113,0.3)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                    <i className="ti ti-user-question" style={{ color:"var(--red)", fontSize:22 }} aria-hidden="true" />
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ display:"flex", flexWrap:"wrap", gap:8, alignItems:"center", marginBottom:5 }}>
                      <span style={{ fontSize:15, fontWeight:700, color:"var(--text1)", fontFamily:"var(--mono)" }}>{THREAT_ACTOR.name}</span>
                      <Chip color="var(--red)">ACTIVE THREAT ACTOR</Chip>
                      <Chip color="var(--amber)">Confidence: {THREAT_ACTOR.confidence}</Chip>
                    </div>
                    <div style={{ fontSize:11, color:"var(--text3)", fontFamily:"var(--mono)" }}>AKA: {THREAT_ACTOR.aka.join(" · ")}</div>
                  </div>
                </div>
                <p style={{ fontSize:13, color:"var(--text2)", lineHeight:1.8, marginBottom:14 }}>{THREAT_ACTOR.desc}</p>
                <div style={{ display:"grid", gridTemplateColumns: isMobile?"1fr":"1fr 1fr", gap:2 }}>
                  {[["Motivation",THREAT_ACTOR.motivation],["Origin",THREAT_ACTOR.origin],["First Seen",THREAT_ACTOR.firstSeen],["Last Observed",THREAT_ACTOR.lastSeen],["Target Sectors",THREAT_ACTOR.sectors.join(", ")],["MITRE TTPs",THREAT_ACTOR.ttps.join(", ")]].map(([k,v]) => <KvRow key={k} k={k} v={v} />)}
                </div>
              </div>

              <Card>
                <CardHead icon="ti-server" title="Known Infrastructure" />
                <div style={{ padding:"10px 16px" }}>
                  {THREAT_ACTOR.infra.map((d,i) => (
                    <div key={i} style={{ display:"flex", gap:10, alignItems:"center", padding:"6px 0", borderBottom:"1px solid var(--border)" }}>
                      <i className="ti ti-world" style={{ color:"var(--red)", fontSize:13, flexShrink:0 }} aria-hidden="true" />
                      <span style={{ fontFamily:"var(--mono)", fontSize:11, color:"var(--text2)", flex:1 }}>{d}</span>
                      {ENRICH[d] && <BtnGhost onClick={()=>setEnrichTarget(d)} icon="ti-search" sm>Intel</BtnGhost>}
                    </div>
                  ))}
                </div>
              </Card>

              <Card>
                <CardHead icon="ti-timeline" title="Attributed Campaigns" />
                <div style={{ overflowX:"auto" }}>
                  <table>
                    <thead><tr><th>Date</th><th>Target</th><th>Vector</th><th>Result</th></tr></thead>
                    <tbody>
                      {THREAT_ACTOR.campaigns.map((c,i) => (
                        <tr key={i}>
                          <td><span style={{ fontFamily:"var(--mono)", fontSize:10, color:"var(--text3)" }}>{c.date}</span></td>
                          <td style={{ fontSize:12 }}>{c.target}</td>
                          <td style={{ fontSize:11, color:"var(--text2)" }}>{c.vector}</td>
                          <td><span style={{ fontSize:11, fontWeight:600, color:c.result==="Blocked"?"var(--green)":"var(--amber)" }}>{c.result}</span></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── THREAT INTEL ─────────────────────────────────────────────────────────────
function ThreatIntel({ onNav }) {
  const w = useWidth();
  const [target, setTarget] = useState(PHISH_IP);
  const e = ENRICH[target];

  return (
    <div style={{ height:"100%", overflowY:"auto", padding: w<640?"12px":"16px 22px", display:"flex", flexDirection:"column", gap:14 }}>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))", gap:10 }}>
        {Object.keys(ENRICH).map(key => {
          const en=ENRICH[key];
          return (
            <div key={key} onClick={()=>setTarget(key)} style={{ background: target===key?"rgba(56,189,248,0.06)":"var(--card)", border:`1px solid ${target===key?"rgba(56,189,248,0.4)":"var(--border)"}`, borderRadius:8, padding:"13px 15px", cursor:"pointer", transition:"border-color 0.15s" }}>
              <div style={{ fontSize:9, color:"var(--text3)", fontFamily:"var(--mono)", marginBottom:5, textTransform:"uppercase" }}>{en.type}</div>
              <div style={{ fontFamily:"var(--mono)", fontSize:12, color:"var(--red)", fontWeight:600, wordBreak:"break-all", marginBottom:8 }}>{key}</div>
              <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                <Chip color="var(--red)">VT: {en.vt}</Chip>
                {en.isTor && <Chip color="var(--red)">TOR</Chip>}
              </div>
            </div>
          );
        })}
      </div>

      {e && (
        <div style={{ display:"grid", gridTemplateColumns: w<900?"1fr":"1fr 1fr", gap:14 }}>
          <Card>
            <CardHead icon="ti-shield-search" title={`Intelligence Report — ${target}`} />
            <div style={{ padding:"14px 18px" }}>
              <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:14 }}>
                <Chip color="var(--red)">VT: {e.vt} — {e.vtLabel}</Chip>
                {e.isTor && <Chip color="var(--red)">TOR EXIT NODE</Chip>}
                {e.abuse && <Chip color="var(--amber)">AbuseIPDB: {e.abuse}%</Chip>}
              </div>
              <p style={{ fontSize:13, color:"var(--text2)", lineHeight:1.75, marginBottom:14, background:"var(--card-hi)", padding:"12px 14px", borderRadius:6, border:"1px solid var(--border)" }}>{e.summary}</p>
              {[["Type",e.type],["Registrar",e.registrar],["Registered",e.registered],["Registrant",e.registrant],["ASN",e.asn],["Country / City",`${e.country||"—"} / ${e.city||"—"}`],["Categories",e.categories?.join(", ")],["Passive DNS",e.passivedns?.join(", ")]].filter(([,v])=>v).map(([k,v]) => <KvRow key={k} k={k} v={v} mono copy />)}
            </div>
          </Card>

          <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
            <Card>
              <CardHead icon="ti-virus" title="Related IOCs" />
              <div style={{ padding:"10px 14px" }}>
                {IOCS_INIT.filter(i => i.value===target || i.ctx?.toLowerCase().includes(target.split(".")[0]) || i.tags?.some(t=>["tor-exit","bulletproof","phishing-infra","sender-spoof"].includes(t))).slice(0,6).map(ioc => (
                  <div key={ioc.id} style={{ padding:"6px 0", borderBottom:"1px solid var(--border)" }}>
                    <div style={{ display:"flex", gap:6, alignItems:"center", marginBottom:3 }}>
                      <span style={{ fontFamily:"var(--mono)", fontSize:9, color:"var(--accent)" }}>{ioc.id}</span>
                      <TlpBadge tlp={ioc.tlp} />
                    </div>
                    <div style={{ fontFamily:"var(--mono)", fontSize:11, color:"var(--text2)", wordBreak:"break-all" }}>{ioc.value}</div>
                    <div style={{ fontSize:10, color:"var(--text3)" }}>{ioc.type} · {ioc.source}</div>
                  </div>
                ))}
              </div>
            </Card>

            <Card>
              <CardHead icon="ti-user-question" title="Threat Actor Attribution" />
              <div style={{ padding:"14px 16px" }}>
                <div style={{ display:"flex", gap:10, alignItems:"center", marginBottom:10 }}>
                  <div style={{ width:38, height:38, borderRadius:7, background:"rgba(248,113,113,0.1)", border:"1px solid rgba(248,113,113,0.3)", display:"flex", alignItems:"center", justifyContent:"center" }}>
                    <i className="ti ti-user-question" style={{ color:"var(--red)", fontSize:18 }} aria-hidden="true" />
                  </div>
                  <div>
                    <div style={{ fontSize:13, fontWeight:700, color:"var(--text1)", fontFamily:"var(--mono)" }}>{THREAT_ACTOR.name}</div>
                    <div style={{ fontSize:10, color:"var(--text3)" }}>{THREAT_ACTOR.motivation}</div>
                  </div>
                </div>
                <p style={{ fontSize:12, color:"var(--text2)", lineHeight:1.7, marginBottom:12 }}>
                  {target} is attributed to PHANTOM-07 infrastructure with High confidence. Belongs to {e.asn||"same ASN"} — consistent with 3 prior campaign observations.
                </p>
                <BtnPrimary onClick={()=>onNav("investigation")} icon="ti-folder-open" sm amber>View Case ATT&CK</BtnPrimary>
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════
// BYTE ASSISTANT — Circle launcher + pop-out guided tutorial panel
// ═══════════════════════════════════════════════════════════════════════════

const BYTE_STEPS = [

  // ════════════════════════════════════════════════════
  // PHASE 1 — INITIAL TRIAGE ON THE SOC DASHBOARD
  // ════════════════════════════════════════════════════

  {
    id:1, page:"soc", title:"Welcome — Vantara SOC Lab",
    content:`Welcome. I'm **Byte**, your guided training assistant for this lab.\n\nYou are **John Mercer, SOC Analyst II** at Vantara Solutions. A spear-phishing campaign is underway. Two malicious emails are in your inbox — but the platform won't tell you which ones. You must identify them through evidence.\n\nThis walkthrough follows the official scenario document through **5 phases**:\n\n• **Phase 1** — SOC Dashboard triage\n• **Phase 2** — Mailbox investigation\n• **Phase 3** — CipherOps DFIR investigation\n• **Phase 4** — Threat intelligence enrichment\n• **Phase 5** — Containment and remediation\n\nWe are currently on the **SOC Dashboard** — your first operational view. Let's begin.`,
    action:null, nav:"soc",
  },

  {
    id:2, page:"soc", title:"1.1 — Read the Live Alert Feed",
    content:`At the very top of the dashboard is the **scrolling ticker** — your real-time SIEM event feed.\n\n**Hover over it to pause** and read each event carefully. Look for:\n\n• An IP address associated with the **Tor network** (185.220.101.52)\n• **DNS queries** to uncategorised, newly-registered domains\n• **MFA push denials** on a user account\n• A **user-submitted phishing report**\n\n🔑 **Key Question:** Which user appears most frequently across these alerts? What does their activity pattern suggest about who is being targeted?`,
    action:"Hover over the ticker to pause and read all events", gate:"ticker-paused", nav:"soc",
  },

  {
    id:3, page:"soc", title:"1.2 — Alert Queue: ALT-5521 & ALT-5529",
    content:`Scroll to the **Alert Queue** table. Click each open alert row to expand its detail panel.\n\n**Start with these two:**\n\n📌 **ALT-5521** — "Phishing email — SPF/DKIM/DMARC triple-fail"\n→ Note the Tor IP (185.220.101.52), the triple auth failure, and the linked case **INC-2025-0312**\n\n📌 **ALT-5529** — "Threat intel feed match — sender IP"\n→ The sender IP matches the **FS-ISAC PHANTOM-07** campaign feed (TLP:AMBER). This confirms the email is part of a known threat-actor campaign.\n\nThe "Open INC-2025-0312" button in the detail panel links directly to the investigation case.`,
    action:"Click ALT-5521 and ALT-5529 to expand their detail panels", gate:["alert:ALT-5521","alert:ALT-5529"], nav:"soc",
  },

  {
    id:4, page:"soc", title:"1.2 — Alert Queue: ALT-5522, ALT-5525 & ALT-5523",
    content:`Continue through the remaining three open alerts:\n\n📌 **ALT-5522** — "DNS query to newly-registered domain"\n→ John Mercer's workstation queried **account-secure.net** — the credential harvest domain. The proxy blocked the subdomain follow-through. No HTTP connection was made.\n\n📌 **ALT-5525** — "MFA fatigue — 3 consecutive push denials"\n→ Three Microsoft Authenticator pushes from **185.220.101.52** within 4 minutes — all denied. This suggests the attacker may already hold valid credentials from an earlier compromise.\n\n📌 **ALT-5523** — "User phish report — priya.kapoor"\n→ A second employee submitted a phishing report for the same sender domain — confirming this is a **multi-target campaign**, not a single inbox hit.`,
    action:"Click ALT-5522, ALT-5525, and ALT-5523 to expand each", gate:["alert:ALT-5522","alert:ALT-5525","alert:ALT-5523"], nav:"soc",
  },

  {
    id:5, page:"soc", title:"1.3 — User Risk Scores & Email Security Monitor",
    content:`Two panels sit on the **right side** of the dashboard. Review them one at a time.\n\n**1. User Risk Scores**\n• Find the user with the **highest risk score**.\n• **John Mercer = 42** (elevated). This is high because he is the primary target of the campaign you are investigating.\n\n**2. Email Security Monitor**\n• Look at the counter labelled **"Phish below threshold: 1"**.\n• This means one phishing email scored **below** the level that would have auto-quarantined it — so it landed in the inbox.\n\nWhy this matters:\n• The DocuSign phishing email scored **8.4** on the spam filter.\n• The quarantine threshold is **9.0**.\n• 8.4 is below 9.0, so the email was **delivered, not quarantined**.\n\n📝 **Remember this for Phase 5.** Lowering the threshold to 7.0, or enforcing strict DMARC regardless of spam score, would have blocked this email at the gateway. You will recommend exactly this later.`,
    action:null, nav:"soc",
  },

  // ════════════════════════════════════════════════════
  // PHASE 2 — MAILBOX INVESTIGATION
  // ════════════════════════════════════════════════════

  {
    id:6, page:"mailbox", title:"Phase 2 — Navigate to Mailbox",
    content:`Navigate to the **Mailbox** tab now.\n\nThe inbox contains a mix of legitimate business emails and two phishing messages. **The platform does not label which emails are malicious** — you must determine this through evidence.\n\nBefore opening any message, scan the list panel for these indicators:\n\n• **Unread dot** (blue) — left of sender name\n• **REP score** — sender reputation out of 100. Low = suspicious\n• **Category tag** — "external" emails from unknown senders warrant scrutiny\n• **Case badge** — 🟢 green ID = registered incident; 🟡 amber NO CASE = unescalated\n• **Arrival time** — emails arriving in the early hours (e.g. 03:18 UTC) are suspicious`,
    action:"Navigate to the Mailbox tab", nav:"mailbox",
  },

  {
    id:7, page:"mailbox", title:"2.2 — Open the DocuSign Email (em002)",
    content:`In your inbox, find and click the email titled:\n**"ACTION REQUIRED: Contract amendment pending your signature — expires 16 May 23:59"**\n\nSender: DocuSign · Arrived: 03:18 UTC (early hours — suspicious)\n\nBefore you open it, note its list indicators:\n• **Unread** — blue dot present\n• **REP: 3** — extremely low sender reputation\n• **No case badge** shown in list? Actually look again — it shows a **🟢 INC-2025-0312** badge\n• Category: **external**\n\nOnce you open it, a **red threat banner** will appear at the top.`,
    action:"Click the DocuSign email (em002) to open it", gate:"email:em002", nav:"mailbox",
  },

  {
    id:8, page:"mailbox", title:"2.3 — Read the Threat Banner",
    content:`A **red threat banner** appears at the top of the email viewer. Read it carefully:\n\n• A **pulsing red THREAT DETECTED** indicator — phishing flags confirmed\n• A **green INC-2025-0312 badge** — this email already has a registered investigation case (auto-created by the SIEM)\n• **Quarantine** button — to isolate the message\n• **Investigate** button — to open the DFIR case\n\nThe authentication pills show: **SPF: FAIL · DKIM: FAIL · DMARC: FAIL** — a triple authentication failure is a definitive phishing indicator.\n\n💡 Click the green **INC-2025-0312** badge to preview the investigation case. Then return to the mailbox to continue the email inspection.`,
    action:"Click the INC-2025-0312 badge, then return to Mailbox", nav:"mailbox",
  },

  {
    id:9, page:"mailbox", title:"2.4 — Inspect the Sender Card",
    content:`Below the subject line, the **sender card** shows the key metadata.\n\nVerify each field:\n\n• **From:** docusign-notify@**esign-secure.net** — NOT a docusign.com address. The domain esign-secure.net was registered only 17 days before this email.\n• **REP: 3/100** — the lowest possible reputation tier. Confirmed malicious.\n• **Reply-To:** support@esign-helpdesk.org — differs from the sender address (amber warning displayed). Victim replies go to the attacker, not DocuSign.\n• **SPF: FAIL · DKIM: FAIL · DMARC: FAIL** — all three cryptographic authentication mechanisms failed.\n• **Spam Score: 8.4** — just 0.6 points below the 9.0 quarantine threshold.\n\n🔑 **Key Question:** Why would an attacker set a different Reply-To address?`,
    action:null, nav:"mailbox",
  },

  {
    id:10, page:"mailbox", title:"2.5 — View Raw Email Headers",
    content:`Click the **HEADERS** button in the toolbar (equivalent to "View Source" in a real mail client).\n\nLocate these fields — they appear **highlighted in red or amber**:\n\n• **X-Originating-IP: 185.220.101.52** — the Tor exit-node that relayed this message\n• **X-Mailer: Bulk Mailer v3.1** — NOT used by legitimate DocuSign infrastructure\n• **X-Campaign-ID: phish-docusign-ent-052025-b** — the attacker's own tracking ID, left in the header. The '-b' suffix means this is the **second campaign run** — another organisation was targeted first.\n• **DKIM-Signature: (none)** — no cryptographic signing present\n\n🔑 **Key Question:** The campaign ID ends with '-b'. What does this tell you about whether Vantara was the first organisation targeted?`,
    action:"Click HEADERS in the toolbar and locate the X-Campaign-ID field", nav:"mailbox",
  },

  {
    id:11, page:"mailbox", title:"2.6 — Analyse Embedded Links",
    content:`Click the **LINKS** button in the toolbar to view the full malicious URL:\n\n\`https://docusign-esign-verify.account-secure.net/d/?id=NDA3MjExOTU=&ref=john.mercer@vantara.io\`\n\nObserve:\n• The actual registered domain is **account-secure.net** — not docusign.com\n• The subdomain **docusign-esign-verify.** is crafted to appear legitimate at a glance\n• The **?id=NDA3MjExOTU=** parameter decodes from Base64 to **407211950** — a victim tracking ID\n• **&ref=** contains John Mercer's own email — this is a **personalised, targeted lure**\n\nClick **Domain Intel** to open the enrichment modal for account-secure.net and view VirusTotal scores, WHOIS data, and passive DNS records.`,
    action:"Click LINKS in toolbar, then click 'Domain Intel'", nav:"mailbox",
  },

  {
    id:12, page:"mailbox", title:"2.7 — Threat Indicator Analysis",
    content:`Scroll down in the email body and click the **Threat Indicator Analysis** toggle.\n\nNine indicators are listed — read each one and note:\n\n• **Severity level** — Critical / High / Medium\n• **Associated MITRE ATT&CK technique** (shown as a purple chip)\n\nKey indicators to focus on:\n🔴 **Sender domain impersonation** (Critical) — T1566.001\n🔴 **SPF/DKIM/DMARC triple-fail** (Critical) — T1566.001\n🔴 **Credential-harvesting URL** (Critical) — T1598.003\n🟠 **Tor exit-node sender IP** (High) — T1090.003\n🟠 **Coercive language — employment threat** (High) — T1566\n\nNine indicators across a single email is a strong, evidence-based phishing confirmation.`,
    action:"Open the Threat Indicator Analysis section and read all 9 indicators", nav:"mailbox",
  },

  {
    id:13, page:"mailbox", title:"2.8 — Quarantine the DocuSign Email",
    content:`Now quarantine em002.\n\nClick the **Quarantine** button in the threat banner or toolbar.\n\nIn the confirmation modal:\n1. Select **Phishing / Social Engineering** as the quarantine reason\n2. In the **Analyst Note** field, write a brief justification — for example:\n   *"SPF/DKIM/DMARC all FAIL. Sender IP 185.220.101.52 is a Tor exit node (AbuseIPDB: 98%). X-Campaign-ID confirms coordinated campaign. Quarantined pending full investigation under INC-2025-0312."*\n3. Click **Confirm Quarantine**\n\n✅ The email moves to the **Quarantine folder**. A green success toast confirms the action was logged. The row now shows an amber **QUARANTINED** badge.`,
    action:"Quarantine em002 — select reason, add analyst note, confirm", gate:"quarantine:em002", nav:"mailbox",
  },

  {
    id:14, page:"mailbox", title:"2.9 — Investigate the Microsoft 365 Email (em011)",
    content:`Return to the inbox and open the email from **"Microsoft Account Team"**:\n\n**Subject:** "⚠ Your Microsoft 365 account has been flagged — immediate verification required"\n\nThis email shows an amber **NO CASE** badge — it has not been escalated yet. Apply the same inspection steps you used for em002:\n\n• Check the sender domain: **ms-account-alerts.net** — registered only **9 days** before arrival\n• Note the spam score: **7.2** — again below the quarantine threshold\n• Sending IP **91.108.56.212** geolocates to **Frankfurt, Germany** — but the alleged suspicious sign-in is from **Lagos, Nigeria**. This is geographically inconsistent.\n• Urgency language: *"You have 12 HOURS to verify before your account is automatically suspended"*\n\n🔑 **Key Question:** How do the two phishing emails differ in infrastructure? Do they share characteristics suggesting the same threat actor?`,
    action:"Open the Microsoft 365 phishing email (em011) and inspect it", gate:"email:em011", nav:"mailbox",
  },

  {
    id:15, page:"mailbox", title:"2.10 — Create a New Investigation Case (em011)",
    content:`Click the amber **Create Case** button in the threat banner.\n\nIn the **Create Investigation Case** modal:\n\n1. **Review the auto-populated title** — edit to something specific, e.g. *"Microsoft 365 Credential Harvest — ms-account-alerts.net Impersonation"*\n2. Set **Severity: High** and **Priority: P1**\n3. Leave **Assignee: John Mercer**\n4. Add **tags:** phishing, microsoft-spoof, ms-account-alerts\n5. Review the auto-populated description and add your own observations from the header inspection\n6. Click **"Create Case & Open Investigation"**\n\n✅ Case **INC-2025-0313** is created. The Investigation platform opens. The email list now shows a green case ID badge next to em011.`,
    action:"Complete the Create Case form and click 'Create Case & Open Investigation'", gate:"createcase", nav:"mailbox",
  },

  // ════════════════════════════════════════════════════
  // PHASE 3 — DFIR INVESTIGATION (CipherOps)
  // ════════════════════════════════════════════════════

  {
    id:16, page:"investigation", title:"Phase 3 — CipherOps DFIR Platform",
    content:`You are now in **CipherOps DFIR** — the investigation platform.\n\nThe left sidebar shows your **case registry**. You should see:\n• 🟢 **INC-2025-0312** — REGISTERED (auto-triaged by SIEM)\n• 🟡 **INC-2025-0313** — NEW (the case you just created)\n\nClick each case card to switch investigation context. **Start with INC-2025-0312** — the DocuSign campaign.\n\nThe **8 investigation tabs** across the top give you the complete DFIR workflow:\nOverview · Timeline · IOCs · Log Correlation · ATT&CK · Evidence · Notes · Actor`,
    action:"Select INC-2025-0312 in the sidebar and open the Overview tab", nav:"investigation",
  },

  {
    id:17, page:"investigation", title:"3.1 — Case Overview (INC-2025-0312)",
    content:`In the **Overview tab** for INC-2025-0312, review:\n\n📊 **Metric cards** — count of IOCs, evidence items, timeline events, notes, affected users, and confirmed TTPs\n\n📄 **Case Summary** — read the full narrative from email delivery through MFA fatigue attack. Note the sequence: delivery at 03:18 → DNS probe at 07:44 → MFA fatigue at 10:45.\n\n✅ **Action Tracker** — most containment steps are marked complete. Two items are still **pending** — the 7-day Azure AD log review, and the SLA closure report. You'll address these in Phase 5.\n\n👥 **Affected Users** — both john.mercer and priya.kapoor are listed. Check their risk scores.\n\nClick **"View full ATT&CK mapping"** in the Confirmed TTPs panel to navigate to the ATT&CK tab.`,
    action:"Read the Case Summary and check the Action Tracker", nav:"investigation",
  },

  {
    id:18, page:"investigation", title:"3.2 — Build the Investigation Timeline",
    content:`Click the **Timeline tab**. Sixteen events are displayed chronologically.\n\nIdentify these **critical moments** in the kill-chain:\n\n⏱ **03:18 UTC** — Phishing email delivered via Tor exit-node; auth failures logged by gateway\n⏱ **07:44 UTC** — Analyst workstation DNS-queries the harvest domain (blocked before HTTP)\n⏱ **07:45 UTC** — Case INC-2025-0312 auto-created by SIEM triage\n⏱ **09:12 UTC** — priya.kapoor submits phishing report — campaign confirmed multi-target\n⏱ **10:45 UTC** — MFA fatigue: 3 Authenticator pushes from Tor IP, all denied\n⏱ **10:55 UTC** — Azure AD Conditional Access updated: Tor range blocked\n\n🔑 **Note the phases** — each event has a phase badge (delivery, detection, victim-activity, triage, containment). This is the structure of your incident narrative.`,
    action:"Open the Timeline tab and locate the 6 key events above", nav:"investigation",
  },

  {
    id:19, page:"investigation", title:"3.3 — IOC Analysis & Enrichment",
    content:`Click the **IOCs tab**. Ten indicators are pre-loaded for INC-2025-0312.\n\nFor each IOC, review:\n• **Type** (IPv4, Domain, URL, Email, String, ASN)\n• **Confidence** (High / Medium / Low)\n• **TLP** (RED / AMBER / GREEN / WHITE)\n• **Status** (active / contained)\n\n🔬 **For IOCs with an Enrich button**, click to view threat intelligence:\n→ **185.220.101.52** — VirusTotal, AbuseIPDB, Tor confirmation\n→ **esign-secure.net** — WHOIS date, registrar, passive DNS\n→ **account-secure.net** — harvest domain, sinkhole status\n\n📝 **Now switch to INC-2025-0313** in the sidebar. Use **Add IOC** to manually add:\n1. Sender IP: **91.108.56.212** (Type: IPv4, Confidence: High, TLP: AMBER)\n2. Phishing domain: **ms-account-alerts.net** (Type: Domain, TLP: AMBER)`,
    action:"Enrich 3 IOCs in INC-2025-0312, then add 2 IOCs to INC-2025-0313", nav:"investigation",
  },

  {
    id:20, page:"investigation", title:"3.4 — Log Correlation",
    content:`Click the **Log Correlation tab** (switch back to INC-2025-0312).\n\nReview both log tables:\n\n**Authentication Logs:**\n• Three **MFA Push DENIED** rows in rapid succession from 185.220.101.52 — highlighted red\n• The Azure AD sign-in from **82.163.44.99 (London)** — this is a DIFFERENT IP from the attacker. Likely the analyst working remotely. MFA was satisfied — this is legitimate.\n\n**Proxy / DNS Logs:**\n• DNS query to **account-secure.net** from john.mercer at 07:44 — QUERY LOGGED (no HTTP)\n• Same domain queried by priya.kapoor — BLOCKED\n\n🔑 **Key Question:** The DNS query happened at 07:44 — before the investigation began. What caused it? *(Hint: email clients generate DNS lookups when hovering over links to render previews — the user didn't need to click.)*`,
    action:"Open the Log Correlation tab and identify the 3 MFA denial rows", nav:"investigation",
  },

  {
    id:21, page:"investigation", title:"3.5 — MITRE ATT&CK Mapping",
    content:`Click the **ATT&CK tab**.\n\nAt the top, the **tactic coverage matrix** shows which MITRE tactics are active — highlighted in red.\n\nFor each of the **six technique cards**, review:\n• Technique ID and name\n• Confirmation status: 🔴 **Confirmed** or 🟡 **Suspected**\n• Evidence references below the description\n\n**Pay attention to the distinction between:**\n• **T1566.001** (Spear-Phishing Link) — *Initial Access* — the delivery mechanism\n• **T1598.003** (Phishing for Information) — *Reconnaissance* — the goal of harvesting credentials\n\nBoth apply to the same email, but they represent **different attacker objectives**: gaining a foothold AND stealing information.\n\nNote **T1110.004** (MFA Fatigue) as a **separate follow-up technique** — the attacker pivoted from phishing to active credential abuse.`,
    action:"Open the ATT&CK tab and read all 6 technique cards", nav:"investigation",
  },

  {
    id:22, page:"investigation", title:"3.6 — Evidence Review",
    content:`Click the **Evidence tab**. Eight items are logged for INC-2025-0312:\n\n🗂 For each evidence item, note:\n• **Type** — email, report, OSINT, logs, threat-intel\n• **SHA-256 hash** — the chain-of-custody fingerprint. This value confirms the evidence has not been altered since collection — critical for legal defensibility.\n• **Custody trail** — who collected it and when\n\nEvidence includes the raw EML export, header analysis report, VirusTotal report for the phishing URL, WHOIS records for all three malicious domains, proxy log extract, Azure AD sign-in logs, MFA push logs, and the FS-ISAC threat intelligence report.\n\nThe evidence chain ensures that if this incident requires legal action or regulatory reporting, every artefact has a verified, auditable origin.`,
    action:"Open the Evidence tab and note the hash format for each item", nav:"investigation",
  },

  {
    id:23, page:"investigation", title:"3.7 — Write Analyst Notes",
    content:`Click the **Notes tab**. Five existing notes provide campaign context. Read them all — they include OSINT findings, peer review from the SOC Lead, FS-ISAC correlation, and Azure AD findings.\n\n📝 **Now add at least two notes of your own:**\n\n**Note 1 — X-Campaign-ID analysis:**\n*"The X-Campaign-ID header value 'phish-docusign-ent-052025-b' indicates this is the second campaign run (-b suffix). Barclays Bank reported campaign -a to FS-ISAC on 2025-05-13 against the UK financial sector. Vantara is campaign target b — attribution to PHANTOM-07 confirmed with High confidence."*\n\n**Note 2 — DNS proxy log finding:**\n*"The DNS query to account-secure.net at 07:44 UTC preceded the formal investigation. The proxy blocked the subdomain follow-through. No HTTP connection was established — the query was likely triggered by the email client's link-hover preview rendering, not a deliberate click. No credential submission confirmed."*`,
    action:"Add 2 analyst notes to the Notes tab", nav:"investigation",
  },

  {
    id:24, page:"investigation", title:"3.8 — Threat Actor Profile (PHANTOM-07)",
    content:`Click the **Actor tab**. Review the full **PHANTOM-07** threat actor profile:\n\n🎯 **Motivation:** Financial — Business Email Compromise and credential harvesting\n🌍 **Origin:** Eastern Europe (assessed, medium confidence)\n🏗 **Infrastructure pattern:** Purpose-registered domains 9–17 days before use via NameSilo (privacy-protected). Cloudflare CDN to hide hosting IP.\n\n**Three attributed campaigns:**\n• 2025-05-13 — Barclays Bank PLC — DocuSign spoof — Blocked\n• 2025-03-01 — Clifford Chance LLP — Adobe Sign spoof — 1 credential captured\n• 2024-11-12 — PwC UK — DocuSign spoof — Blocked\n\nIn the **Known Infrastructure** panel, click **Intel** next to esign-secure.net or account-secure.net to view the enrichment report inline.\n\nNext — navigate to **Threat Intel** for deep-dive IOC enrichment →`,
    action:null, nav:"investigation",
  },

  // ════════════════════════════════════════════════════
  // PHASE 4 — THREAT INTELLIGENCE ENRICHMENT
  // ════════════════════════════════════════════════════

  {
    id:25, page:"threatintel", title:"Phase 4 — Threat Intelligence Module",
    content:`Navigate to the **Threat Intel** tab.\n\nThree intelligence cards are displayed — one per primary malicious indicator:\n• The **sending IP** (185.220.101.52)\n• The **sender domain** (esign-secure.net)\n• The **harvest domain** (account-secure.net)\n\nClick each card to load its full intelligence report on the right. Let's work through all three.`,
    action:"Navigate to the Threat Intel tab", nav:"threatintel",
  },

  {
    id:26, page:"threatintel", title:"4.1 — IP Intelligence: 185.220.101.52",
    content:`Click the **185.220.101.52** card.\n\nKey intelligence findings:\n\n• **VirusTotal: 14/94** — 14 vendors flagged this IP as malicious\n• **AbuseIPDB: 98%** confidence — extremely high abuse history\n• **ASN: AS3214 OVH SAS** — cloud provider known to host bulletproof services\n• **Confirmed Tor exit node** — used to anonymise the campaign sender\n• **Passive DNS:** also resolves to smtp-relay-47.net and bounce-mailer-eu.net — related phishing relay infrastructure\n\n🔎 This IP is the smoking gun connecting the email delivery to a known threat actor. The FS-ISAC submission from Barclays (2025-05-13) used this exact IP — two days before the Vantara attack.`,
    action:"Click the 185.220.101.52 card and review all intelligence fields", nav:"threatintel",
  },

  {
    id:27, page:"threatintel", title:"4.2 — Domain Intelligence",
    content:`Now click **esign-secure.net**, then **account-secure.net**.\n\nBoth domains share identical registration characteristics:\n\n• **Registered: 2025-04-28** via NameSilo — the same date for both domains\n• **Registrant:** REDACTED (privacy-protected)\n• **Age at attack:** 17 days — classic short-lived phishing infrastructure\n• **Categories:** Phishing / Credential Harvesting\n\n🔑 **Why does same-day registration matter?** Registering both the spoofing domain AND the harvest domain on the same day strongly implies they were provisioned in a single coordinated operation — confirming a single threat actor controlled the entire campaign infrastructure from day one.\n\nThe harvest domain (account-secure.net) has been **DNS sinkholed** by Vantara — noted in its enrichment record.`,
    action:"Click esign-secure.net then account-secure.net and compare registration dates", nav:"threatintel",
  },

  {
    id:28, page:"threatintel", title:"4.3 — Threat Actor Attribution",
    content:`In the **Threat Actor Attribution** card (right panel), confirm the attribution:\n\n• Both the IP and both domains are attributed to **PHANTOM-07** with **High confidence**\n• Attribution rationale: same ASN (OVH SAS Romania), same NameSilo registration pattern, consistent SaaS-impersonation campaign style, and match to the FS-ISAC Barclays submission\n\n📋 **Campaign chain confirmed:**\n→ PHANTOM-07 registered infrastructure on 2025-04-28\n→ Campaign 'a' hit Barclays (2025-05-13) — reported to FS-ISAC\n→ Campaign 'b' hit Vantara (2025-05-15) — this investigation\n→ MFA fatigue follow-up indicates credentials may have been captured (all pushes denied — no compromise confirmed)\n\nPhase 4 complete. Return to Investigation for the final phase →`,
    action:null, nav:"threatintel",
  },

  // ════════════════════════════════════════════════════
  // PHASE 5 — CONTAINMENT AND REMEDIATION
  // ════════════════════════════════════════════════════

  {
    id:29, page:"investigation", title:"Phase 5 — Containment & Remediation",
    content:`Return to the **Investigation tab** and select **INC-2025-0312**. Open the **Overview tab**.\n\nThe **Action Tracker** shows all completed containment steps:\n\n✅ IOCs added to perimeter firewall block-list\n✅ Email gateway deny-list updated with sender domains\n✅ DNS sinkhole activated for account-secure.net\n✅ Victim notifications sent (john.mercer & priya.kapoor)\n✅ Azure AD CA policy updated — Tor IP range blocked\n✅ Password reset initiated for john.mercer\n✅ IOCs shared to FS-ISAC under TLP:AMBER\n\nTwo items remain **pending** — you need to document recommendations for both.`,
    action:"Navigate to Investigation → INC-2025-0312 → Overview → Action Tracker", nav:"investigation",
  },

  {
    id:30, page:"investigation", title:"5.1 — Document Pending Actions",
    content:`The two **pending items** in the Action Tracker require your documented recommendations:\n\n**⏳ 7-day Azure AD extended log review:**\nConfirm no successful authentication occurred from the attacker IP range (185.220.101.0/24) across the **full 7-day log retention window** — not just the 48h window already reviewed. This rules out any credential use before the MFA fatigue event was detected.\n\n**⏳ SLA closure report:**\nDraft an executive summary covering:\n• What happened (delivery, probe, MFA fatigue)\n• What was confirmed (no credential compromise, no lateral movement)\n• What containment actions were taken and when\n• Recommended control improvements\n\n💡 Add your recommendations as **analyst notes** in the Notes tab — these become part of the formal case record.`,
    action:"Add a note documenting your recommendation for the 7-day log review", nav:"investigation",
  },

  {
    id:31, page:"investigation", title:"5.1 — Remediation Recommendation",
    content:`**Final remediation note** — this is your most important policy recommendation from this lab.\n\nThe DocuSign phishing email scored **8.4** on the spam filter. The quarantine threshold is **9.0**. The difference: **0.6 points** allowed a confirmed phishing email into the inbox.\n\n📝 **Add this recommendation as an analyst note:**\n\n*"Gateway policy gap identified: phishing email scored 8.4, threshold 9.0. Recommend one of: (a) reduce quarantine threshold for external senders from 9.0 to 7.0, or (b) enable strict DMARC enforcement regardless of spam score — any DMARC FAIL from an external sender triggers quarantine without relying on the spam score. Either change would have blocked both phishing emails at the gateway before inbox delivery."*\n\nThis note should go into the case record as a policy recommendation for the security team.`,
    action:"Add the gateway policy recommendation as an analyst note", nav:"investigation",
  },

  // ════════════════════════════════════════════════════
  // CONCLUSION
  // ════════════════════════════════════════════════════

  {
    id:32, page:"investigation", title:"Knowledge Check — Test Your Understanding",
    content:`Before you finish, confirm what you learned. Answer the questions below. You can review any tab if you need to check an answer.`,
    action:null, nav:"investigation",
    quiz: [
      {
        q: "The DocuSign phishing email scored 8.4 on the spam filter but still reached the inbox. Why?",
        options: [
          "The spam filter was disabled",
          "8.4 was below the 9.0 quarantine threshold, so it was delivered",
          "DMARC passed, so it was trusted",
          "The user manually moved it out of quarantine",
        ],
        answer: 1,
        explain: "The quarantine threshold was 9.0. A score of 8.4 fell below it, so the email was delivered rather than quarantined — the core policy gap of this incident.",
      },
      {
        q: "What does an SPF / DKIM / DMARC triple-FAIL indicate?",
        options: [
          "A temporary mail server outage",
          "The recipient's mailbox is full",
          "The sender could not be authenticated — a strong phishing/spoofing indicator",
          "The email was encrypted end-to-end",
        ],
        answer: 2,
        explain: "All three email-authentication mechanisms failed, meaning the sender's identity could not be verified — a definitive sign of spoofing/phishing.",
      },
      {
        q: "The sending IP 185.220.101.52 was identified as which type of infrastructure?",
        options: [
          "A Microsoft 365 relay",
          "A Tor exit node",
          "The victim's own workstation",
          "A Vantara internal mail server",
        ],
        answer: 1,
        explain: "185.220.101.52 is a Tor exit node (AbuseIPDB 98%), used by the attacker to anonymise the campaign origin.",
      },
      {
        q: "The X-Campaign-ID header ended in '-b'. What did this tell you?",
        options: [
          "It was the backup copy of the email",
          "Vantara was the second organisation targeted by this campaign",
          "The email was sent in the evening",
          "It was a legitimate DocuSign batch ID",
        ],
        answer: 1,
        explain: "The '-b' suffix indicated a second campaign run. Campaign '-a' hit Barclays two days earlier (reported to FS-ISAC), confirming a coordinated multi-org campaign by PHANTOM-07.",
      },
      {
        q: "MFA push notifications were sent to John Mercer and all were DENIED. What attack technique is this?",
        options: [
          "Password spraying",
          "SQL injection",
          "MFA fatigue (push bombing)",
          "DNS tunnelling",
        ],
        answer: 2,
        explain: "Repeated MFA push requests aiming for the user to accidentally approve one is an MFA fatigue attack (MITRE T1110.004). All pushes were denied — no compromise confirmed.",
      },
    ],
  },

  {
    id:33, page:"investigation", title:"Lab Complete",
    content:`You have completed the **Vantara SOC Phishing Investigation and Incident Response** lab.\n\n**Skills exercised in this scenario:**\n\n✅ Recognising phishing indicators across multiple data sources\n✅ Analysing SPF, DKIM, and DMARC authentication failures\n✅ Correlating email events with proxy logs, auth logs, and SIEM alerts\n✅ Creating and managing DFIR investigation cases\n✅ Extracting and enriching IOCs with threat intelligence\n✅ Mapping attacker behaviour to MITRE ATT&CK techniques\n✅ Executing multi-layer containment actions\n✅ Sharing structured threat intelligence under TLP classifications\n\n**Want to go further?**\n• Decode the Base64 URL parameters to understand victim tracking\n• Cross-reference X-Campaign-ID values against FS-ISAC to map the full campaign sequence\n• Draft a formal Incident Report covering scope, root cause, timeline, and control improvements\n• Research PHANTOM-07 on MITRE ATT&CK Groups, AlienVault OTX, or Recorded Future`,
    action:null, nav:"investigation",
  },
];

// ─── BYTE ASSISTANT COMPONENT ──────────────────────────────────────────────────
function ByteAssistant({ activeNav, onNav }) {
  const [open, setOpen]         = useState(false);
  const [stepIdx, setStepIdx]   = useState(0);
  const [typing, setTyping]     = useState(false);
  const [rendered, setRendered] = useState("");
  const [skipped, setSkipped]   = useState(false);
  const [doneActions, setDoneActions] = useState(() => new Set());
  const [quizAnswers, setQuizAnswers] = useState({}); // { "stepIdx-qIdx": optionIdx }

  // ── Listen for lab action events from UI components ──
  useEffect(() => {
    function onAct(e) {
      const k = e?.detail?.key;
      if (!k) return;
      setDoneActions(prev => {
        if (prev.has(k)) return prev;
        const next = new Set(prev);
        next.add(k);
        return next;
      });
    }
    window.addEventListener("lab:action", onAct);
    return () => window.removeEventListener("lab:action", onAct);
  }, []);

  // Position state
  const [edge, setEdge]         = useState("right");   // "left" | "right"
  const [vRatio, setVRatio]     = useState(0.72);      // 0–1 vertical
  const [panelW, setPanelW]     = useState(520);
  const [panelH, setPanelH]     = useState(520);

  // Drag state (widget drag)
  const dragging   = useRef(false);
  const dragOff    = useRef({ x:0, y:0 });
  // Resize state
  const resizing   = useRef(null); // null | "side" | "corner"
  const resizeStart= useRef({});

  const widgetRef  = useRef(null);
  const panelRef   = useRef(null);
  const bodyRef    = useRef(null);
  const typingTimer= useRef(null);

  const step = BYTE_STEPS[stepIdx];
  const totalSteps = BYTE_STEPS.length;

  // ── Auto-open after 900ms ──
  useEffect(() => {
    const t = setTimeout(() => setOpen(true), 900);
    return () => clearTimeout(t);
  }, []);

  // ── Snap to edge after open ──
  useEffect(() => {
    if (open) snapToEdge(true);
  }, [open]);

  // ── Typing animation when step changes ──
  useEffect(() => {
    if (!open) return;
    setTyping(true);
    setRendered("");
    if (typingTimer.current) clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => {
      setTyping(false);
      setRendered(step.content);
      // Scroll body to top
      if (bodyRef.current) bodyRef.current.scrollTop = 0;
    }, 600);
    return () => clearTimeout(typingTimer.current);
  }, [stepIdx, open]);

  // ── Snap helper ──
  function snapToEdge(animate, forceEdge) {
    const w = widgetRef.current;
    if (!w) return;
    const curEdge = forceEdge || edge;
    if (forceEdge) setEdge(forceEdge);
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const GAP = 12;
    const targetLeft = curEdge === "left" ? GAP : vw - 64 - GAP;
    const targetTop  = Math.max(8, Math.min(vRatio * vh, vh - 64 - 8));
    w.style.transition = animate ? "left 0.28s ease, top 0.28s ease" : "none";
    w.style.left   = targetLeft + "px";
    w.style.top    = targetTop  + "px";
    w.style.right  = "auto";
    w.style.bottom = "auto";
    setTimeout(() => { if (w) w.style.transition = "none"; }, 300);
  }

  // ── Window resize: re-snap widget AND clamp panel to viewport ──
  useEffect(() => {
    function onResize() {
      snapToEdge(false);
      const maxW = Math.max(280, window.innerWidth - 48);
      const maxH = Math.max(220, window.innerHeight - 120);
      setPanelW(w => Math.min(w, maxW));
      setPanelH(h => Math.min(h, maxH));
    }
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  });

  // ── Widget drag ──
  useEffect(() => {
    function onMouseMove(e) {
      if (!dragging.current || !widgetRef.current) return;
      const newLeft = e.clientX - dragOff.current.x;
      const newTop  = e.clientY - dragOff.current.y;
      widgetRef.current.style.transition = "none";
      widgetRef.current.style.left = newLeft + "px";
      widgetRef.current.style.top  = newTop  + "px";
      // Track vertical ratio continuously
      setVRatio(newTop / window.innerHeight);
    }
    function onMouseUp(e) {
      if (!dragging.current) return;
      dragging.current = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
      // Snap to nearest edge
      const w = widgetRef.current;
      if (!w) return;
      const rect = w.getBoundingClientRect();
      const midX = rect.left + 32;
      const newEdge = midX < window.innerWidth / 2 ? "left" : "right";
      const newRatio = rect.top / window.innerHeight;
      setVRatio(newRatio);
      setEdge(newEdge);
      snapToEdge(true, newEdge);
    }
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup",   onMouseUp);
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup",   onMouseUp);
    };
  });

  // ── Panel resize ──
  useEffect(() => {
    function onMouseMove(e) {
      if (!resizing.current) return;
      const { startW, startH, startX, startY, type } = resizeStart.current;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const MIN_W = 280, MIN_H = 220;
      const MAX_W = vw - 48, MAX_H = vh - 48;
      if (type === "side") {
        // Horizontal resize — direction depends on edge
        const newW = edge === "right"
          ? Math.max(MIN_W, Math.min(MAX_W, startW - dx))
          : Math.max(MIN_W, Math.min(MAX_W, startW + dx));
        setPanelW(newW);
      } else {
        // Corner resize — both axes
        const newW = edge === "right"
          ? Math.max(MIN_W, Math.min(MAX_W, startW - dx))
          : Math.max(MIN_W, Math.min(MAX_W, startW + dx));
        const newH = Math.max(MIN_H, Math.min(MAX_H, startH + dy));
        setPanelW(newW);
        setPanelH(newH);
      }
    }
    function onMouseUp() {
      if (resizing.current) resizing.current = null;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    }
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup",   onMouseUp);
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup",   onMouseUp);
    };
  });

  function startDrag(e) {
    if (e.target.closest(".byte-ctrl-btn") || e.target.closest(".byte-resize-side") || e.target.closest(".byte-resize-corner")) return;
    e.preventDefault();
    const rect = widgetRef.current.getBoundingClientRect();
    dragOff.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    dragging.current = true;
    document.body.style.cursor = "grabbing";
    document.body.style.userSelect = "none";
  }

  function startResize(e, type) {
    e.stopPropagation();
    e.preventDefault();
    resizing.current = type;
    resizeStart.current = { startW: panelW, startH: panelH, startX: e.clientX, startY: e.clientY, type };
    document.body.style.cursor = type === "side" ? "ew-resize" : "nwse-resize";
    document.body.style.userSelect = "none";
  }

  function goNext() {
    if (nextLocked) return;
    if (stepIdx < totalSteps - 1) {
      const next = BYTE_STEPS[stepIdx + 1];
      if (next.nav && next.nav !== activeNav) onNav(next.nav);
      setStepIdx(stepIdx + 1);
    }
  }

  function goPrev() {
    if (stepIdx > 0) {
      const prev = BYTE_STEPS[stepIdx - 1];
      if (prev.nav && prev.nav !== activeNav) onNav(prev.nav);
      setStepIdx(stepIdx - 1);
    }
  }

  function skipTutorial() {
    setSkipped(true);
    setOpen(false);
  }

  // ── Quadrant class for panel positioning ──
  const panelLeft = edge === "left";

  // ── Parse markdown-lite for bold (**text**) and newlines ──
  // Render inline markdown (**bold**, `code`) and strip stray markers
  function renderInline(str, keyBase) {
    if (str == null) return null;
    // Normalise inline status emoji to plain text markers (callouts handle leading emoji)
    str = str
      .replace(/🟢\s*/g, "")
      .replace(/🟡\s*/g, "")
      .replace(/🔴\s*/g, "")
      .replace(/→\s*/g, "→ ");
    // Split on **bold** and `code`
    const parts = str.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
    return parts.map((p, i) => {
      if (p.startsWith("**") && p.endsWith("**")) {
        return <strong key={`${keyBase}-b${i}`} style={{ color:"#E8F4FF", fontWeight:700 }}>{p.slice(2,-2)}</strong>;
      }
      if (p.startsWith("`") && p.endsWith("`") && p.length > 1) {
        return <code key={`${keyBase}-c${i}`} style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:12, background:"rgba(56,189,248,0.12)", color:"#7DD3FC", padding:"1px 5px", borderRadius:4 }}>{p.slice(1,-1)}</code>;
      }
      return <span key={`${keyBase}-t${i}`}>{p}</span>;
    });
  }

  // Map an emoji prefix to a callout style + lucide icon
  function calloutMeta(line) {
    const map = {
      "🔑": { color:"#FBBF24", bg:"rgba(251,191,36,0.10)", border:"rgba(251,191,36,0.35)", Icon:Icons.Key },
      "📌": { color:"#60A5FA", bg:"rgba(96,165,250,0.10)", border:"rgba(96,165,250,0.30)", Icon:Icons.Pin },
      "💡": { color:"#34D399", bg:"rgba(52,211,153,0.10)", border:"rgba(52,211,153,0.30)", Icon:Icons.Bulb },
      "📝": { color:"#A78BFA", bg:"rgba(167,139,250,0.10)", border:"rgba(167,139,250,0.30)", Icon:Icons.Note },
      "🎯": { color:"#F87171", bg:"rgba(248,113,113,0.10)", border:"rgba(248,113,113,0.30)", Icon:Icons.Target },
      "⚠️": { color:"#FB923C", bg:"rgba(251,146,60,0.10)", border:"rgba(251,146,60,0.30)", Icon:Icons.Warn },
      "✅": { color:"#34D399", bg:"rgba(52,211,153,0.10)", border:"rgba(52,211,153,0.30)", Icon:Icons.Check },
      "🚨": { color:"#F87171", bg:"rgba(248,113,113,0.10)", border:"rgba(248,113,113,0.30)", Icon:Icons.Alert },
      "🔍": { color:"#60A5FA", bg:"rgba(96,165,250,0.10)", border:"rgba(96,165,250,0.30)", Icon:Icons.Search },
      "📊": { color:"#60A5FA", bg:"rgba(96,165,250,0.10)", border:"rgba(96,165,250,0.30)", Icon:Icons.Chart },
      "📋": { color:"#A78BFA", bg:"rgba(167,139,250,0.10)", border:"rgba(167,139,250,0.30)", Icon:Icons.Clipboard },
    };
    for (const k of Object.keys(map)) {
      if (line.startsWith(k)) return { ...map[k], rest: line.slice(k.length).trim() };
    }
    return null;
  }

  // Full block parser: paragraphs, bullets, callouts, arrows
  function parseContent(text) {
    if (!text) return [];
    // Normalise: split into logical lines
    const lines = text.replace(/\r/g, "").split("\n");
    const blocks = [];
    let buffer = [];
    const flushPara = () => {
      if (buffer.length) {
        const joined = buffer.join(" ").trim();
        if (joined) blocks.push({ type:"p", text:joined });
        buffer = [];
      }
    };
    for (let raw of lines) {
      const line = raw.trim();
      if (line === "") { flushPara(); continue; }
      const callout = calloutMeta(line);
      if (callout) { flushPara(); blocks.push({ type:"callout", ...callout }); continue; }
      if (/^[•\-\*]\s+/.test(line)) { flushPara(); blocks.push({ type:"bullet", text: line.replace(/^[•\-\*]\s+/, "") }); continue; }
      if (/^→\s*/.test(line) || /^->\s*/.test(line)) { flushPara(); blocks.push({ type:"arrow", text: line.replace(/^(→|->)\s*/, "") }); continue; }
      buffer.push(line);
    }
    flushPara();

    return blocks.map((b, bi) => {
      if (b.type === "callout") {
        const Icon = b.Icon;
        return (
          <div key={bi} style={{ display:"flex", gap:8, alignItems:"flex-start", background:b.bg, border:`1px solid ${b.border}`, borderRadius:8, padding:"8px 10px", margin:"0 0 10px 0" }}>
            <span style={{ flexShrink:0, marginTop:1, color:b.color }}><Icon size={15}/></span>
            <span style={{ lineHeight:1.6, color:"#D4E6F7", fontSize:12.5 }}>{renderInline(b.rest, `co${bi}`)}</span>
          </div>
        );
      }
      if (b.type === "bullet") {
        return (
          <div key={bi} style={{ display:"flex", gap:8, alignItems:"flex-start", margin:"0 0 7px 0" }}>
            <span style={{ flexShrink:0, marginTop:7, width:5, height:5, borderRadius:"50%", background:"#38BDF8" }} />
            <span style={{ lineHeight:1.6, color:"#C8DCF0", fontSize:12.5 }}>{renderInline(b.text, `bu${bi}`)}</span>
          </div>
        );
      }
      if (b.type === "arrow") {
        return (
          <div key={bi} style={{ display:"flex", gap:7, alignItems:"flex-start", margin:"-2px 0 8px 13px" }}>
            <span style={{ flexShrink:0, marginTop:1, color:"#5A7A98" }}><Icons.CornerArrow size={13}/></span>
            <span style={{ lineHeight:1.55, color:"#A8C0D8", fontSize:12 }}>{renderInline(b.text, `ar${bi}`)}</span>
          </div>
        );
      }
      return (
        <p key={bi} style={{ margin:"0 0 10px 0", lineHeight:1.7, color:"#C8DCF0", fontSize:13 }}>
          {renderInline(b.text, `p${bi}`)}
        </p>
      );
    });
  }

  const progress = ((stepIdx + 1) / totalSteps) * 100;
  const isLastStep = stepIdx === totalSteps - 1;
  const isFirstStep = stepIdx === 0;
  const hasAction = !!step.action;

  // ── Strict action gating ──
  // Each action step unlocks Next only when its action is detected:
  //  • step.gate  → wait for that specific emitted event key
  //  • otherwise  → require the student to be on the step's target page
  const gates = step.gate ? (Array.isArray(step.gate) ? step.gate : [step.gate]) : [];
  const navSatisfied = step.nav ? activeNav === step.nav : true;
  const gatesSatisfied = gates.every(k => doneActions.has(k));
  // Quiz steps: all questions must be answered correctly to unlock
  const quizAllCorrect = step.quiz
    ? step.quiz.every((q, qi) => quizAnswers[`${stepIdx}-${qi}`] === q.answer)
    : true;
  const actionComplete = (hasAction ? (navSatisfied && gatesSatisfied) : true) && quizAllCorrect;
  const nextLocked = (hasAction || step.quiz) ? (!actionComplete && !isLastStep) : false;

  if (skipped) return null;

  return (
    <>
      {/* ── Injected styles ── */}
      <style>{`
        #byte-widget {
          position: fixed;
          width: 64px;
          height: 64px;
          z-index: 9999;
          left: auto;
          top: auto;
        }
        #byte-launcher {
          position: absolute;
          bottom: 0; right: 0;
          width: 54px; height: 54px;
          border-radius: 50%;
          background: linear-gradient(135deg, #0B1A2C 0%, #0E2A44 100%);
          border: 1.5px solid rgba(56,189,248,0.5);
          box-shadow: 0 0 0 3px rgba(56,189,248,0.08), 0 4px 20px rgba(0,0,0,0.5);
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
          transition: box-shadow 0.2s, border-color 0.2s, transform 0.15s;
          user-select: none;
        }
        #byte-launcher:hover {
          box-shadow: 0 0 0 5px rgba(56,189,248,0.15), 0 6px 28px rgba(0,0,0,0.6);
          border-color: rgba(56,189,248,0.8);
          transform: scale(1.05);
        }
        .byte-launcher-icon-close { display: none; }
        #byte-widget.panel-open .byte-launcher-icon-bot   { display: none; }
        #byte-widget.panel-open .byte-launcher-icon-close { display: flex; }
        .byte-step-badge {
          position: absolute;
          top: -2px; right: -2px;
          min-width: 16px; height: 16px;
          border-radius: 8px;
          background: #F87171;
          color: #0B0F1A;
          font-size: 9px; font-weight: 800;
          display: flex; align-items: center; justify-content: center;
          font-family: 'JetBrains Mono', monospace;
          padding: 0 3px;
          border: 1.5px solid #0B1A2C;
        }
        #byte-assistant {
          position: absolute;
          bottom: 64px;
          border-radius: 12px;
          background: linear-gradient(160deg, #0A1828 0%, #0C1E35 100%);
          border: 1px solid rgba(56,189,248,0.25);
          box-shadow: 0 20px 60px rgba(0,0,0,0.75), 0 0 0 1px rgba(56,189,248,0.06);
          display: flex; flex-direction: column;
          overflow: visible;
          transform-origin: bottom right;
          animation: byte-pop-in 0.22s cubic-bezier(0.34,1.56,0.64,1) both;
        }
        #byte-assistant.pos-align-left {
          left: 0; right: auto;
          transform-origin: bottom left;
          animation: byte-pop-in-left 0.22s cubic-bezier(0.34,1.56,0.64,1) both;
        }
        #byte-assistant.pos-align-right {
          right: 0; left: auto;
        }
        @keyframes byte-pop-in {
          from { opacity:0; transform: scale(0.85) translateY(12px); }
          to   { opacity:1; transform: scale(1) translateY(0); }
        }
        @keyframes byte-pop-in-left {
          from { opacity:0; transform: scale(0.85) translateY(12px); }
          to   { opacity:1; transform: scale(1) translateY(0); }
        }
        #byte-header {
          display: flex; align-items: center; gap:9px;
          padding: 11px 14px 10px;
          border-bottom: 1px solid rgba(56,189,248,0.12);
          cursor: grab;
          flex-shrink: 0;
          background: rgba(56,189,248,0.04);
          border-radius: 12px 12px 0 0;
          user-select: none;
        }
        #byte-header:active { cursor: grabbing; }
        .byte-avatar {
          width: 28px; height: 28px;
          border-radius: 8px;
          background: rgba(56,189,248,0.1);
          border: 1px solid rgba(56,189,248,0.3);
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0;
        }
        .byte-name {
          flex: 1;
          font-size: 11.5px; font-weight: 700;
          color: #EAF1F8;
          font-family: 'Inter', sans-serif;
          letter-spacing: 0.01em;
        }
        .byte-online-dot {
          width: 7px; height: 7px; border-radius: 50%;
          background: #34D399;
          box-shadow: 0 0 6px rgba(52,211,153,0.6);
          animation: pulse 2.5s ease-in-out infinite;
        }
        .byte-ctrl-btn {
          width: 22px; height: 22px;
          border-radius: 5px;
          border: 1px solid rgba(56,189,248,0.15);
          background: transparent;
          color: #4A6A88;
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
          transition: background 0.15s, color 0.15s;
          flex-shrink: 0;
        }
        .byte-ctrl-btn:hover { background: rgba(248,113,113,0.15); color: #F87171; border-color: rgba(248,113,113,0.3); }
        #byte-progress-wrap {
          padding: 10px 14px 8px;
          border-bottom: 1px solid rgba(56,189,248,0.08);
          flex-shrink: 0;
        }
        .byte-progress-label {
          display: flex; align-items: center; justify-content: space-between;
          margin-bottom: 6px;
        }
        #byte-step-num { font-size: 10px; color: #4A6A88; font-family: 'JetBrains Mono', monospace; }
        #byte-step-badge {
          font-size: 9px; font-weight: 800;
          background: rgba(56,189,248,0.12); color: #38BDF8;
          border: 1px solid rgba(56,189,248,0.25);
          padding: 1px 7px; border-radius: 10px;
          font-family: 'JetBrains Mono', monospace;
        }
        .byte-progress-track {
          height: 3px; border-radius: 2px;
          background: rgba(56,189,248,0.1);
          overflow: hidden;
        }
        .byte-progress-fill {
          height: 100%; border-radius: 2px;
          background: linear-gradient(90deg, #38BDF8, #7C3AED);
          transition: width 0.4s cubic-bezier(0.4,0,0.2,1);
        }
        #byte-body {
          flex: 1;
          overflow-y: auto;
          padding: 14px 16px 10px;
          scroll-behavior: smooth;
        }
        #byte-body::-webkit-scrollbar { width: 4px; }
        #byte-body::-webkit-scrollbar-track { background: transparent; }
        #byte-body::-webkit-scrollbar-thumb { background: rgba(56,189,248,0.2); border-radius: 2px; }
        .byte-step-title {
          font-size: 13px; font-weight: 700; color: #38BDF8;
          font-family: 'Inter', sans-serif;
          margin-bottom: 10px;
          display: flex; align-items: center; gap: 6px;
        }
        .byte-step-num-pill {
          font-size: 9px; font-weight: 800;
          background: rgba(56,189,248,0.12); color: #38BDF8;
          border: 1px solid rgba(56,189,248,0.25);
          padding: 1px 7px; border-radius: 10px;
          font-family: 'JetBrains Mono', monospace;
        }
        .byte-typing {
          display: flex; gap: 4px; align-items: center; padding: 8px 0;
        }
        .byte-typing span {
          width: 7px; height: 7px; border-radius: 50%;
          background: rgba(56,189,248,0.4);
          animation: byte-dot 1.2s ease-in-out infinite;
        }
        .byte-typing span:nth-child(2) { animation-delay: 0.2s; }
        .byte-typing span:nth-child(3) { animation-delay: 0.4s; }
        @keyframes byte-dot {
          0%, 80%, 100% { transform: scale(0.6); opacity: 0.35; }
          40%            { transform: scale(1);   opacity: 1; }
        }
        #byte-action-lock {
          display: flex; align-items: center; gap: 8px;
          margin: 0 12px 0;
          padding: 8px 12px;
          background: rgba(245,158,11,0.07);
          border: 1px solid rgba(245,158,11,0.25);
          border-radius: 7px;
          color: #F59E0B;
          font-size: 11px; font-weight: 500;
          flex-shrink: 0;
          font-family: 'Inter', sans-serif;
        }
        #byte-action-lock.byte-action-done {
          background: rgba(52,211,153,0.08);
          border-color: rgba(52,211,153,0.3);
          color: #34D399;
        }
        #byte-footer {
          display: flex; align-items: center; gap: 6px;
          padding: 10px 14px 12px;
          border-top: 1px solid rgba(56,189,248,0.08);
          flex-shrink: 0;
        }
        #byte-assistant.pos-align-left #byte-footer { flex-direction: row-reverse; }
        .byte-btn {
          display: inline-flex; align-items: center; justify-content: center;
          gap: 4px;
          border-radius: 6px;
          font-size: 11px; font-weight: 600;
          cursor: pointer;
          font-family: 'Inter', sans-serif;
          transition: all 0.15s;
          white-space: nowrap;
          padding: 6px 12px;
          border: 1px solid;
        }
        .byte-btn:disabled { opacity: 0.35; cursor: default; }
        .byte-btn-primary {
          background: rgba(56,189,248,0.12);
          border-color: rgba(56,189,248,0.35);
          color: #38BDF8;
        }
        .byte-btn-primary:not(:disabled):hover {
          background: rgba(56,189,248,0.2);
          border-color: rgba(56,189,248,0.6);
        }
        .byte-btn-ghost {
          background: transparent;
          border-color: rgba(56,189,248,0.1);
          color: #4A6A88;
        }
        .byte-btn-ghost:not(:disabled):hover {
          background: rgba(56,189,248,0.06);
          color: #8BACC8;
          border-color: rgba(56,189,248,0.2);
        }
        .byte-btn-skip {
          background: transparent;
          border-color: transparent;
          color: #4A6A88;
          font-size: 10px;
          padding: 4px 8px;
        }
        .byte-btn-skip:hover { color: #F87171; }
        .byte-spacer { flex: 1; }
        .byte-nav-hint {
          display: inline-flex; align-items: center; gap: 5px;
          font-size: 10px; color: #4A6A88;
          background: rgba(56,189,248,0.05);
          border: 1px solid rgba(56,189,248,0.1);
          border-radius: 4px; padding: 3px 8px;
          margin-bottom: 10px;
          font-family: 'JetBrains Mono', monospace;
        }
        .byte-resize-side {
          position: absolute; top: 50%; transform: translateY(-50%);
          width: 6px; height: 48px; border-radius: 3px;
          background: rgba(56,189,248,0.18);
          cursor: ew-resize;
          transition: background 0.15s;
        }
        .byte-resize-side:hover { background: rgba(56,189,248,0.45); }
        .byte-resize-corner {
          position: absolute;
          width: 14px; height: 14px; border-radius: 2px;
          background: rgba(56,189,248,0.15);
          cursor: nwse-resize;
          transition: background 0.15s;
        }
        .byte-resize-corner:hover { background: rgba(56,189,248,0.4); }
        #byte-assistant.pos-align-right .byte-resize-side  { left: -8px; }
        #byte-assistant.pos-align-left  .byte-resize-side  { right: -8px; cursor: ew-resize; }
        #byte-assistant.pos-align-right .byte-resize-corner { left: -8px; bottom: -8px; cursor: sw-resize; }
        #byte-assistant.pos-align-left  .byte-resize-corner { right: -8px; bottom: -8px; cursor: se-resize; }
        .byte-complete-badge {
          display: inline-flex; align-items: center; gap: 6px;
          background: rgba(52,211,153,0.1);
          border: 1px solid rgba(52,211,153,0.3);
          border-radius: 20px; padding: 5px 14px;
          color: #34D399; font-size: 11px; font-weight: 700;
          margin-bottom: 12px;
          font-family: 'JetBrains Mono', monospace;
        }
      `}</style>

      {/* ── Widget anchor ── */}
      <div
        id="byte-widget"
        ref={widgetRef}
        className={open ? "panel-open" : ""}
        style={{ position:"fixed", width:64, height:64, zIndex:9999 }}
      >
        {/* Pop-out panel */}
        {open && (
          <div
            id="byte-assistant"
            ref={panelRef}
            className={panelLeft ? "pos-align-left" : "pos-align-right"}
            style={{ width:panelW, height:panelH, bottom:64 }}
          >
            {/* Resize handles */}
            <div
              className="byte-resize-side"
              onMouseDown={e => startResize(e, "side")}
            />
            <div
              className="byte-resize-corner"
              onMouseDown={e => startResize(e, "corner")}
            />

            {/* Header */}
            <div id="byte-header" onMouseDown={startDrag}>
              <div className="byte-avatar">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#38BDF8" strokeWidth="1.8" strokeLinecap="round">
                  <rect x="3" y="11" width="18" height="11" rx="2"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                  <circle cx="12" cy="16.5" r="1.2" fill="#38BDF8" stroke="none"/>
                </svg>
              </div>
              <span className="byte-name">Byte — Vantara SOC Lab</span>
              <span className="byte-online-dot" />
              <div className="byte-controls">
                <button className="byte-ctrl-btn" onClick={() => setOpen(false)} title="Minimise">
                  <svg width="11" height="11" viewBox="0 0 11 11" fill="none">
                    <path d="M1 5.5h9" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  </svg>
                </button>
              </div>
            </div>

            {/* Progress */}
            <div id="byte-progress-wrap">
              <div className="byte-progress-label">
                <span id="byte-step-num">Step {stepIdx + 1} / {totalSteps}</span>
                <span id="byte-step-badge">{step.page.toUpperCase()}</span>
              </div>
              <div className="byte-progress-track">
                <div className="byte-progress-fill" style={{ width: progress + "%" }} />
              </div>
            </div>

            {/* Body */}
            <div id="byte-body" ref={bodyRef}>
              {step.nav && step.nav !== activeNav && (
                <div className="byte-nav-hint">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 18l6-6-6-6"/></svg>
                  Navigate to: <strong style={{ color:"#38BDF8" }}>{step.nav === "soc" ? "SOC Dashboard" : step.nav === "mailbox" ? "Mailbox" : step.nav === "investigation" ? "Investigation" : "Threat Intel"}</strong>
                </div>
              )}

              {isLastStep && (
                <div className="byte-complete-badge">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M20 6L9 17l-5-5"/></svg>
                  LAB COMPLETE
                </div>
              )}

              <div className="byte-step-title">
                <span className="byte-step-num-pill">{String(stepIdx + 1).padStart(2,"0")}</span>
                {step.title}
              </div>

              {typing ? (
                <div className="byte-typing"><span/><span/><span/></div>
              ) : (
                <div className="byte-content">{parseContent(rendered)}</div>
              )}

              {!typing && step.quiz && (
                <div style={{ marginTop:6, display:"flex", flexDirection:"column", gap:12 }}>
                  {step.quiz.map((q, qi) => {
                    const key = `${stepIdx}-${qi}`;
                    const chosen = quizAnswers[key];
                    const answered = chosen !== undefined;
                    const correct = answered && chosen === q.answer;
                    return (
                      <div key={qi} style={{ background:"rgba(56,189,248,0.04)", border:"1px solid rgba(56,189,248,0.15)", borderRadius:8, padding:"10px 12px" }}>
                        <div style={{ display:"flex", gap:7, alignItems:"flex-start", marginBottom:8 }}>
                          <span style={{ color:"#38BDF8", flexShrink:0, marginTop:1 }}><Icons.Question size={14}/></span>
                          <span style={{ fontSize:12.5, fontWeight:600, color:"#E8F4FF", lineHeight:1.5 }}>{q.q}</span>
                        </div>
                        <div style={{ display:"flex", flexDirection:"column", gap:5 }}>
                          {q.options.map((opt, oi) => {
                            const isChosen = chosen === oi;
                            const showCorrect = answered && oi === q.answer;
                            const showWrong = answered && isChosen && oi !== q.answer;
                            return (
                              <button
                                key={oi}
                                onClick={() => setQuizAnswers(prev => ({ ...prev, [key]: oi }))}
                                style={{
                                  textAlign:"left", display:"flex", gap:8, alignItems:"center",
                                  padding:"7px 10px", borderRadius:6, cursor:"pointer",
                                  fontSize:12, lineHeight:1.4,
                                  fontFamily:"'Inter',sans-serif",
                                  background: showCorrect ? "rgba(52,211,153,0.12)" : showWrong ? "rgba(248,113,113,0.12)" : "rgba(255,255,255,0.02)",
                                  border: `1px solid ${showCorrect ? "rgba(52,211,153,0.4)" : showWrong ? "rgba(248,113,113,0.4)" : "rgba(56,189,248,0.15)"}`,
                                  color: showCorrect ? "#34D399" : showWrong ? "#F87171" : "#C8DCF0",
                                }}
                              >
                                <span style={{ flexShrink:0, width:16 }}>
                                  {showCorrect ? <Icons.Check size={14} color="#34D399"/> : showWrong ? <Icons.X size={13} color="#F87171"/> : <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:11, color:"#5A7A98" }}>{String.fromCharCode(65+oi)}</span>}
                                </span>
                                {opt}
                              </button>
                            );
                          })}
                        </div>
                        {answered && (
                          <div style={{ marginTop:8, fontSize:11.5, lineHeight:1.55, color: correct ? "#9DE8C8" : "#F0B8B8", background: correct ? "rgba(52,211,153,0.08)" : "rgba(248,113,113,0.08)", borderRadius:6, padding:"7px 9px" }}>
                            {correct ? "Correct. " : "Not quite. "}{q.explain}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Action / quiz lock */}
            {(hasAction || step.quiz) && (
              <div id="byte-action-lock" className={actionComplete ? "byte-action-done" : ""}>
                {actionComplete ? (
                  <Icons.Check size={13} color="#34D399" />
                ) : (
                  <Icons.Lock size={13} color="#F59E0B" />
                )}
                <span>{actionComplete
                  ? (step.quiz ? "All answers correct — you may continue" : "Action complete — you may continue")
                  : (step.quiz ? "Answer all questions correctly to continue" : step.action)}</span>
              </div>
            )}

            {/* Footer */}
            <div id="byte-footer">
              <button className="byte-btn byte-btn-skip" onClick={skipTutorial}>Skip</button>
              <span className="byte-spacer" />
              <button
                className="byte-btn byte-btn-ghost"
                onClick={goPrev}
                disabled={isFirstStep}
              >← Back</button>
              <button
                className="byte-btn byte-btn-primary"
                onClick={isLastStep ? () => { setOpen(false); setSkipped(true); } : goNext}
                disabled={nextLocked}
                title={nextLocked ? "Complete the highlighted action to continue" : ""}
              >
                {isLastStep ? "Finish" : (nextLocked ? "Locked" : "Next →")}
              </button>
            </div>
          </div>
        )}

        {/* Launcher circle */}
        <div id="byte-launcher" onClick={() => setOpen(v => !v)}>
          <span className="byte-launcher-icon-bot">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#38BDF8" strokeWidth="1.7" strokeLinecap="round">
              <rect x="3" y="11" width="18" height="11" rx="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
              <circle cx="12" cy="16.5" r="1.3" fill="#38BDF8" stroke="none"/>
            </svg>
          </span>
          <span className="byte-launcher-icon-close">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38BDF8" strokeWidth="2.2" strokeLinecap="round">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </span>
          {!open && (
            <span className="byte-step-badge">{stepIdx + 1}</span>
          )}
        </div>
      </div>
    </>
  );
}

// ─── ROOT ─────────────────────────────────────────────────────────────────────
export default function App() {
  const w = useWidth();
  const clock = useClock();
  const isMobile = w < 640;
  const [active, setActive] = useState("soc");

  // Global case registry — INC-2025-0312 is pre-registered for em002
  const [cases, setCases] = useState([
    {
      id:"INC-2025-0312",
      emailId:"em002",
      title:"Spear-Phishing Campaign — DocuSign Impersonation (TA-PHANTOM-07)",
      status:"In Progress",sev:"High",priority:"P1",
      assignee:"John Mercer",created:"2025-05-15T07:45:00",updated:"2025-05-16T10:22:00",
      reporter:"SIEM Auto-Triage (ALT-5521 + ALT-5529)",
      affectedUsers:["john.mercer@vantara.io","priya.kapoor@vantara.io"],
      tags:["phishing","credential-harvesting","docusign-spoof","mfa-fatigue","ta-phantom-07"],
      description:"Targeted spear-phishing email impersonating DocuSign delivered via Tor exit-node. Triple auth failure (SPF/DKIM/DMARC). MFA fatigue attack observed. Campaign attributed to TA-PHANTOM-07.",
      isPreExisting:true,
    }
  ]);
  const [openCaseId, setOpenCaseId] = useState("INC-2025-0312");

  const NAV = [
    {id:"soc",          label:"SOC Dashboard", icon:"ti-layout-dashboard", badge:ALERTS.filter(a=>a.status!=="resolved").length, bColor:"var(--red)"},
    {id:"mailbox",      label:"Mailbox",        icon:"ti-mail",             badge:ALL_EMAILS.filter(e=>e.folder==="inbox"&&!e.read).length, bColor:"var(--accent)"},
    {id:"investigation",label:"Investigation",  icon:"ti-shield-search",    badge:null},
    {id:"threatintel",  label:"Threat Intel",   icon:"ti-virus",            badge:null},
  ];

  const PAGES = {
    soc:          <SOCDashboard onNav={setActive} cases={cases} />,
    mailbox:      <Mailbox onNav={setActive} cases={cases} setCases={setCases} setOpenCaseId={setOpenCaseId} />,
    investigation:<Investigation onNav={setActive} cases={cases} setCases={setCases} openCaseId={openCaseId} setOpenCaseId={setOpenCaseId} />,
    threatintel:  <ThreatIntel onNav={setActive} />,
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", height:"100dvh", background:"var(--bg)", overflow:"hidden" }}>
      {/* Global styles — rendered synchronously in JSX, never deferred */}
      <style dangerouslySetInnerHTML={{ __html: CSS }} />
      {/* Top nav */}
      <header style={{ background:"var(--surface)", borderBottom:"1px solid var(--border)", height:48, display:"flex", alignItems:"center", padding:"0 14px", gap:8, flexShrink:0 }}>
        {/* Logo */}
        <div style={{ display:"flex", alignItems:"center", gap:0, marginRight:8, flexShrink:0 }}>
          <VantaraLogo compact={isMobile} />
        </div>

        {/* Nav */}
        <nav style={{ display:"flex", gap:2, flex:1, alignItems:"center" }}>
          {NAV.map(n => (
            <button key={n.id} onClick={()=>setActive(n.id)}
              style={{ display:"inline-flex", alignItems:"center", gap:5, padding: isMobile?"6px 10px":"6px 14px", borderRadius:6, border:"none", background: active===n.id?"rgba(56,189,248,0.1)":"transparent", color: active===n.id?"var(--accent)":"var(--text2)", cursor:"pointer", fontSize:12, fontWeight: active===n.id?600:400, position:"relative", borderBottom: active===n.id?"2px solid var(--accent)":"2px solid transparent", transition:"all 0.15s" }}>
              <i className={`ti ${n.icon}`} style={{ fontSize:14 }} aria-hidden="true" />
              {!isMobile && n.label}
              {n.badge > 0 && <span style={{ position:"absolute", top:2, right:2, minWidth:15, height:15, borderRadius:8, background:n.bColor, display:"flex", alignItems:"center", justifyContent:"center", fontSize:8, fontWeight:700, color:"var(--bg)", fontFamily:"var(--mono)", padding:"0 3px" }}>{n.badge}</span>}
            </button>
          ))}
        </nav>

        {/* Status */}
        <div style={{ display:"flex", alignItems:"center", gap:10, flexShrink:0 }}>
          {!isMobile && <>
            <div style={{ display:"flex", alignItems:"center", gap:5, background:"rgba(74,222,128,0.08)", border:"1px solid rgba(74,222,128,0.2)", borderRadius:5, padding:"3px 9px" }}>
              <PulseIcon />
              <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--green)", letterSpacing:"0.08em", fontWeight:600 }}>SIEM LIVE</span>
            </div>
            <span style={{ fontSize:9, fontFamily:"var(--mono)", color:"var(--amber)", background:"rgba(245,158,11,0.08)", border:"1px solid rgba(245,158,11,0.2)", padding:"3px 9px", borderRadius:5 }}>{openCaseId || "INC-2025-0312"} ({cases.length})</span>
          </>}
          <span style={{ fontSize:11, fontFamily:"var(--mono)", color:"var(--text3)", minWidth:64, textAlign:"right" }}>{clock}</span>
          <Avatar name={ME.name} size={28} accent />
        </div>
      </header>

      {/* Active page */}
      <main style={{ flex:1, overflow:"hidden", minHeight:0, display:"flex", flexDirection:"column" }}>
        {PAGES[active]}
      </main>

      {/* Byte Assistant */}
      <ByteAssistant activeNav={active} onNav={setActive} />
    </div>
  );
}
