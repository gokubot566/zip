# File System Analysis — UI/UX aligned to the ICTSAS305 lab

This is the File System Analysis & Metadata Extraction scenario, unchanged in
substance, but its guided experience and overall look now match the
ICTSAS305 "Provide ICT Advice to Clients" lab.

## What changed

### The guide ("Byte assistance") is now the shared cast-led guide
The old floating Byte robot has been replaced by the same guide system the
ICTSAS305 lab uses, built entirely from the OS's own design tokens so it looks
native to the desktop:

- A pre-login **Intro** (welcome → meet the team → the case brief), fronted by
  the cast.
- A draggable, collapsible **guide panel** whose header shows the teammate
  running the current stage, a progress bar, and a Progress tracker checklist.
- Each stage is briefed **in character** (Elena, Marcus, Priya, David, Hannah),
  teaches tappable **jargon chips** (with a glossary modal), links straight to
  the right app, and hosts the **Record-Your-Findings** questions.
- On completion the guide opens a **Lab Complete** screen with a team sign-off.

The seven investigation stages (locate → collect → inspect → hash → threat
intel → static analysis → verdict) and the investigation apps (Files, Terminal,
OmniGuard, Threat Lookup, PE Inspector) are the same scenario as before.

### Overall look matches
`theme.css` now maps the investigation apps' palette onto the OS design tokens,
so the apps inherit the OS theme/accent (and light/dark) like the ICTSAS305
apps — no teal side-theme.

## The three fixes

1. **"our" removed.** Priya now introduces herself as "malware analyst" (not
   "our malware analyst") in `content.js`.
2. **Verdict is now fill-in, not tick-to-confirm.** Stage 7 asks the student to
   *type* the verdict and the IOCs (C2 domain, SHA-256). Each answer is checked
   on submit; the lab finishes only when they match, and a gentle **hint**
   appears on a wrong answer (never the answer). This uses the same QuizInput
   component as the reference lab. See `quizzes.js` (`q_verdict`, `q_ioc_c2`,
   `q_ioc_hash`) and `stages.js` (the `verdict` stage).
3. **Single "Restart lab".** The duplicate restart is gone; there is now exactly
   one Restart control, on the Lab Complete screen.

## Run
- Dev: `npm install && npm run dev` → http://localhost:8346
- Container: `docker compose up -d --build`
- Tests: `npm test` (engine + server-render of every app)
