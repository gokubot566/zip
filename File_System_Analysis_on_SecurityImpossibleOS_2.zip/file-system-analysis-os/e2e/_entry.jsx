// Bundled and run by run-e2e.mjs inside a jsdom environment. Mounts the real
// <App/> and drives the entire lab end-to-end via real DOM events:
// boot → intro → login → 7 investigation stages (operating the real apps) →
// verdict fill-ins (with an intentional wrong answer → hint) → completion.
import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import { OSProvider } from '../src/core/OSContext.jsx';
import App from '../src/App.jsx';
import { SUSPECT } from '../src/labs/file-system-analysis/scenario.js';

const SHA = SUSPECT.hashes.sha256;
const log = [];
const say = (m) => { log.push(m); console.log('  ' + m); };
let stepN = 0;
const step = (m) => say(`[${String(++stepN).padStart(2, '0')}] ${m}`);
function assert(cond, m) { if (!cond) throw new Error('ASSERT FAILED: ' + m); say('   ✓ ' + m); }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function tick(fn) { await act(async () => { if (fn) fn(); await sleep(0); }); await sleep(0); }
async function waitFor(pred, label, timeout = 12000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) { if (pred()) return true; await tick(); await sleep(30); }
  throw new Error(`TIMEOUT waiting for: ${label}`);
}

const $ = (sel) => document.querySelector(sel);
const $all = (sel) => Array.from(document.querySelectorAll(sel));
const qlast = (sel) => { const a = $all(sel); return a[a.length - 1] || null; };
const byText = (sel, text) => $all(sel).filter((e) => (e.textContent || '').toLowerCase().includes(text.toLowerCase()));
const lastByText = (sel, text) => { const a = byText(sel, text); return a[a.length - 1] || null; };

function click(el) {
  if (!el) throw new Error('click: element not found');
  el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true }));
}
function setValue(el, value) {
  const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
  el.dispatchEvent(new window.Event('input', { bubbles: true }));
}
function pressEnter(el) {
  el.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
}
const guideText = () => ($('[data-e2e="guide-panel"]')?.textContent || '');
const curStage = () => $('[data-e2e="guide-stage-title"]')?.getAttribute('data-stage') || null;
const okOf = (id) => $(`[data-e2e="quiz-${id}"]`)?.getAttribute('data-ok');
const txtOf = (id) => $(`[data-e2e="quiz-${id}"]`)?.textContent || '';

async function run() {
  const container = document.getElementById('root');
  await act(async () => { createRoot(container).render(React.createElement(OSProvider, null, React.createElement(App))); });
  await tick();

  // ---- BOOT ----
  step('Wait for boot → intro');
  await waitFor(() => $('[data-e2e="intro-next"]') || $('[data-e2e="intro-finish"]'), 'intro to appear');
  assert(!!$('[data-e2e="intro-next"]'), 'Intro sequence rendered');

  // Issue 1: Priya must NOT say "our malware analyst" anywhere.
  step('Check cast wording (issue 1)');
  await tick(() => click($('[data-e2e="intro-next"]')));        // welcome → cast (meet the team)
  await waitFor(() => /meet the team/i.test(document.body.textContent), 'cast page');
  const bodyText = document.body.textContent.toLowerCase();
  assert(!bodyText.includes('our malware analyst'), 'No "our malware analyst" text');
  assert(/priya/i.test(document.body.textContent) && /malware analyst/i.test(document.body.textContent), 'Priya introduced as malware analyst');

  // ---- INTRO → LOGIN ----
  step('Finish intro');
  await tick(() => click($('[data-e2e="intro-next"]')));        // cast → brief
  await waitFor(() => $('[data-e2e="intro-finish"]'), 'brief page');
  await tick(() => click($('[data-e2e="intro-finish"]')));      // introDone
  step('Sign in (blank password accepted)');
  await waitFor(() => $('form'), 'login form');
  await tick(() => { const f = $('form'); f.dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true })); });
  await waitFor(() => $('[data-e2e="guide-panel"]'), 'guide panel after login');
  assert(curStage() === 'locate', 'Guide starts at Stage 1 (locate)');

  // ---- STAGE 1: LOCATE ----
  step('Stage 1 — Locate (Files → C:\\Windows\\Temp)');
  await tick(() => click($('[data-e2e="guide-open-app"]')));    // open Files
  await waitFor(() => lastByText('.files-q', 'Windows Temp'), 'Files app open');
  await tick(() => click(lastByText('.files-q', 'Windows Temp')));  // navigate to Temp → foundFile
  await waitFor(() => $('[data-e2e="quiz-input-q_locate_path"]'), 'locate quiz unlocked (foundFile)');
  await tick(() => setValue($('[data-e2e="quiz-input-q_locate_path"]'), 'C:\\Windows\\Temp'));
  await tick(() => click($('[data-e2e="quiz-submit-q_locate_path"]')));
  await waitFor(() => curStage() === 'restore', 'advance to Stage 2');
  assert(curStage() === 'restore', 'Stage 1 complete → restore');

  // ---- STAGE 2: RESTORE ----
  step('Stage 2 — Collect (OmniGuard restore + ack)');
  await tick(() => click($('[data-e2e="guide-open-app"]')));    // open OmniGuard
  await waitFor(() => $('.sec-item') || lastByText('.sec-nav', 'Protection history'), 'OmniGuard open');
  if (!$('.sec-item') && !$('.sec-restore')) await tick(() => click(lastByText('.sec-nav', 'Protection history')));
  await waitFor(() => qlast('.sec-item'), 'quarantine entry');
  await tick(() => click(qlast('.sec-item')));                  // expand the quarantined item
  await waitFor(() => $('.sec-restore'), 'restore button');
  await tick(() => click(qlast('.sec-restore')));               // restored
  await waitFor(() => $('[data-e2e="guide-ack"]'), 'ack toggle');
  await tick(() => click($('[data-e2e="guide-ack"]')));         // restoreAck
  await waitFor(() => curStage() === 'inspect', 'advance to Stage 3');
  assert(curStage() === 'inspect', 'Stage 2 complete → inspect');

  // ---- STAGE 3: INSPECT (reuse the open Files window) ----
  step('Stage 3 — Inspect properties (Files → details)');
  await tick(() => click(lastByText('.files-q', 'Windows Temp')));  // ensure at Temp
  await waitFor(() => qlast('.file.suspect'), 'suspect file visible');
  await tick(() => click(qlast('.file.suspect')));              // select suspect
  await waitFor(() => lastByText('.foot-btn', 'Details'), 'Details button');
  await tick(() => click(lastByText('.foot-btn', 'Details')));  // openProps → inspected
  await waitFor(() => curStage() === 'hash', 'advance to Stage 4');
  assert(curStage() === 'hash', 'Stage 3 complete → hash');

  // ---- STAGE 4: HASH ----
  step('Stage 4 — Compute hash (Terminal)');
  await tick(() => click($('[data-e2e="guide-open-app"]')));    // open Terminal
  await waitFor(() => qlast('.term-input'), 'Terminal open');
  await tick(() => setValue(qlast('.term-input'), 'certutil -hashfile crack.exe SHA256'));
  await tick(() => pressEnter(qlast('.term-input')));           // hashed
  await waitFor(() => $('[data-e2e="quiz-input-q_sha256"]'), 'hash quiz unlocked');
  await tick(() => setValue($('[data-e2e="quiz-input-q_sha256"]'), SHA));
  await tick(() => click($('[data-e2e="quiz-submit-q_sha256"]')));
  await waitFor(() => curStage() === 'intel', 'advance to Stage 5');
  assert(curStage() === 'intel', 'Stage 4 complete → intel');

  // ---- STAGE 5: INTEL ----
  step('Stage 5 — Threat-intel lookup');
  await tick(() => click($('[data-e2e="guide-open-app"]')));    // open Threat Lookup
  await waitFor(() => qlast('.intel-input input'), 'Threat Lookup open');
  await tick(() => setValue(qlast('.intel-input input'), SHA));
  await tick(() => click(qlast('.intel-go')));                  // intelDone
  await waitFor(() => $('[data-e2e="quiz-input-q_family"]'), 'family quiz unlocked');
  await tick(() => setValue($('[data-e2e="quiz-input-q_family"]'), 'AsyncRAT'));
  await tick(() => click($('[data-e2e="quiz-submit-q_family"]')));
  await waitFor(() => curStage() === 'static', 'advance to Stage 6');
  assert(curStage() === 'static', 'Stage 5 complete → static');

  // ---- STAGE 6: STATIC ----
  step('Stage 6 — Static analysis (PE Inspector → Imports)');
  await tick(() => click($('[data-e2e="guide-open-app"]')));    // open PE Inspector
  await waitFor(() => lastByText('.pe-tabs button', 'Imports'), 'PE Inspector open');
  await tick(() => click(lastByText('.pe-tabs button', 'Imports')));  // staticDone
  await waitFor(() => $('[data-e2e="quiz-input-q_capability"]'), 'capability quiz unlocked');
  await tick(() => setValue($('[data-e2e="quiz-input-q_capability"]'),
    'It hooks the keyboard to log keystrokes, injects into other processes to hide, resists termination, and calls out to a C2 server.'));
  await tick(() => click($('[data-e2e="quiz-submit-q_capability"]')));
  await waitFor(() => curStage() === 'verdict', 'advance to Stage 7');
  assert(curStage() === 'verdict', 'Stage 6 complete → verdict');

  // ---- STAGE 7: VERDICT (issue 2 — fill-in with hint on mismatch) ----
  step('Stage 7 — Verdict: wrong answer must show a hint');
  await waitFor(() => $('[data-e2e="quiz-opt-q_verdict-benign"]'), 'verdict options shown');
  await tick(() => click($('[data-e2e="quiz-opt-q_verdict-benign"]')));   // WRONG
  await tick();
  assert(okOf('q_verdict') === '0', 'Wrong verdict rejected');
  assert(/look again|weigh the evidence|points one way/i.test(txtOf('q_verdict')), 'Hint shown for wrong verdict');
  step('Stage 7 — Correct verdict + IOC fill-ins');
  await tick(() => click($('[data-e2e="quiz-opt-q_verdict-malicious"]')));  // CORRECT
  await waitFor(() => okOf('q_verdict') === '1', 'verdict accepted');

  // C2 IOC — wrong then right
  await tick(() => setValue($('[data-e2e="quiz-input-q_ioc_c2"]'), 'totally-wrong.example'));
  await tick(() => click($('[data-e2e="quiz-submit-q_ioc_c2"]')));
  assert(okOf('q_ioc_c2') === '0', 'Wrong C2 rejected');
  assert(/duckdns|defanged|sentinel/i.test(txtOf('q_ioc_c2')), 'Hint shown for wrong C2');
  await tick(() => setValue($('[data-e2e="quiz-input-q_ioc_c2"]'), 'sentinel-c2-node[.]duckdns[.]org'));
  await tick(() => click($('[data-e2e="quiz-submit-q_ioc_c2"]')));
  await waitFor(() => okOf('q_ioc_c2') === '1' || curStage() !== 'verdict', 'C2 accepted (defanged)');

  // Hash IOC — right
  await tick(() => setValue($('[data-e2e="quiz-input-q_ioc_hash"]'), SHA));
  await tick(() => click($('[data-e2e="quiz-submit-q_ioc_hash"]')));
  await waitFor(() => okOf('q_ioc_hash') === '1' || /threat confirmed/i.test(document.body.textContent), 'Hash IOC accepted');

  // ---- COMPLETION ----
  step('Completion screen + single restart (issue 3)');
  await waitFor(() => byText('h1', 'threat confirmed').length > 0 || /threat confirmed/i.test(document.body.textContent), 'completion screen');
  const restartButtons = $all('button').filter((b) => /restart lab/i.test(b.textContent || ''));
  assert(restartButtons.length === 1, `Exactly ONE "Restart lab" control (found ${restartButtons.length})`);
  assert(!document.body.textContent.toLowerCase().includes('our malware analyst'), 'Still no "our malware analyst" anywhere');
  assert(/sha-?256|9f2c4a7b/i.test(document.body.textContent), 'Completion shows the recorded SHA-256 IOC');

  say('\nALL E2E STEPS PASSED ✅');
  return true;
}

globalThis.__E2E = run().then(
  () => ({ ok: true, log }),
  (e) => { console.error('\n✘ ' + e.message); return { ok: false, error: e.message, log }; },
);
