// End-to-end test runner for the File System Analysis lab.
// No external browser is required: it mounts the real React <App/> in jsdom and
// drives the whole flow through real DOM events. Bundles src with esbuild first
// (so JSX/asset/CSS imports resolve exactly like the Vite build).
//
// Usage: node e2e/run-e2e.mjs
import { JSDOM } from 'jsdom';
import { build } from 'esbuild';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const DIR = path.dirname(fileURLToPath(import.meta.url));

// --- jsdom environment (set globals BEFORE the bundle imports react-dom) ---
const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', {
  url: 'http://localhost:8346/',
  pretendToBeVisual: true,
});
const { window } = dom;
globalThis.window = window;
globalThis.document = window.document;
Object.defineProperty(globalThis, 'navigator', { value: window.navigator, configurable: true });
for (const k of ['HTMLElement', 'HTMLInputElement', 'HTMLTextAreaElement', 'SVGElement', 'Element', 'Node',
  'Event', 'MouseEvent', 'KeyboardEvent', 'CustomEvent', 'getComputedStyle', 'DOMParser', 'MutationObserver']) {
  if (window[k] && !globalThis[k]) globalThis[k] = window[k];
}
globalThis.requestAnimationFrame = (cb) => setTimeout(() => cb(Date.now()), 0);
globalThis.cancelAnimationFrame = (id) => clearTimeout(id);
window.requestAnimationFrame = globalThis.requestAnimationFrame;
window.cancelAnimationFrame = globalThis.cancelAnimationFrame;
window.scrollTo = () => {};
if (!window.Element.prototype.scrollIntoView) window.Element.prototype.scrollIntoView = () => {};
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

// --- bundle the entry ---
const outfile = path.join(DIR, '.e2e-bundle.mjs');
await build({
  entryPoints: [path.join(DIR, '_entry.jsx')],
  bundle: true, format: 'esm', platform: 'browser', jsx: 'automatic',
  outfile, logLevel: 'error', sourcemap: false,
  loader: { '.png': 'dataurl', '.jpg': 'dataurl', '.svg': 'text', '.css': 'empty' },
  define: { 'process.env.NODE_ENV': '"development"' },
  banner: { js: "import { createRequire as __cr } from 'module'; const require = __cr(import.meta.url);" },
});

console.log('\n=== END-TO-END WALKTHROUGH (jsdom, real <App/>) ===\n');
await import(pathToFileURL(outfile).href);
const result = await globalThis.__E2E;

// cleanup
import('node:fs').then((fs) => { try { fs.unlinkSync(outfile); } catch {} });

if (!result.ok) { console.error('\nRESULT: FAIL —', result.error); process.exit(1); }
console.log('\nRESULT: PASS — ' + result.log.filter((l) => l.startsWith('[')).length + ' steps, all assertions green.');
process.exit(0);
