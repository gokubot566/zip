import React, { useState } from 'react';
import { Trophy, Copy, Check, RefreshCw, ShieldCheck } from 'lucide-react';
import { useOS } from '../../../core/OSContext.jsx';
import { Speech } from '../guide/Cast.jsx';
import { SUMMARY, SUSPECT } from '../scenario.js';

// Shown when all seven stages are complete. Reviews the recorded verdict + IOCs,
// lets the student copy their findings for submission, gives a team sign-off,
// and offers a SINGLE "Restart lab" control (issue 3: no duplicate restart).
export default function Completion() {
  const { state, resetSession } = useOS();
  const [copied, setCopied] = useState(false);
  const answers = state.labState.answers ?? {};

  const verdict = answers.q_verdict?.value === 'malicious'
    ? 'Malicious — a keylogging Remote Access Trojan (RAT)'
    : (answers.q_verdict?.value ?? '—');
  const c2 = answers.q_ioc_c2?.value || 'sentinel-c2-node[.]duckdns[.]org';
  const hash = answers.q_ioc_hash?.value || SUSPECT.hashes.sha256;

  const report =
    `FILE SYSTEM ANALYSIS — TRIAGE FINDINGS\n` +
    `======================================\n` +
    `Sample:      crack.exe\n` +
    `Location:    C:\\Windows\\Temp\\crack.exe\n` +
    `Verdict:     ${verdict}\n` +
    `Family:      ${SUSPECT.intel?.family ?? 'AsyncRAT (Remote Access Trojan)'}\n\n` +
    `Indicators of Compromise (IOCs)\n` +
    `- SHA-256:   ${hash}\n` +
    `- C2 domain: ${c2}\n` +
    `- Behaviour: keyboard hooks, process injection, anti-termination, phones home\n`;

  const copy = async () => {
    try {
      if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(report);
      else {
        const ta = document.createElement('textarea');
        ta.value = report; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
      }
      setCopied(true); setTimeout(() => setCopied(false), 1800);
    } catch { /* ignore */ }
  };

  return (
    <div className="scrolly" style={{ height: '100%', padding: 22, color: 'var(--text-primary)' }}>
      <div style={{ textAlign: 'center', marginBottom: 18 }}>
        <Trophy size={44} color="var(--accent)" />
        <h1 style={{ fontSize: 22, margin: '10px 0 4px' }}>{SUMMARY.passTitle}</h1>
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6, maxWidth: 620, margin: '0 auto' }}>{SUMMARY.passBody}</p>
      </div>

      {/* recorded findings */}
      <div style={{ border: '1px solid var(--border-strong)', borderRadius: 'var(--radius-md)', overflow: 'hidden', marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--surface-1)', padding: '10px 14px', borderBottom: '1px solid var(--border)', fontWeight: 700, fontSize: 13 }}>
          <ShieldCheck size={16} color="var(--success)" /> Your recorded findings
        </div>
        <div style={{ padding: 14, fontSize: 12.5, lineHeight: 1.7 }}>
          <Row k="Verdict" v={verdict} />
          <Row k="SHA-256" v={hash} mono />
          <Row k="C2 domain" v={c2} mono />
          <Row k="Family" v={SUSPECT.intel?.family ?? 'AsyncRAT (Remote Access Trojan)'} />
          <Row k="Behaviour" v="Keyboard hooks, process injection, anti-termination, phones home" />
        </div>
      </div>

      <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
        <button className="os-btn primary" onClick={copy}>
          {copied ? <><Check size={15} /> Copied</> : <><Copy size={15} /> Copy findings for submission</>}
        </button>
        <button className="os-btn" onClick={resetSession} title="Restart the whole lab from the beginning">
          <RefreshCw size={15} /> Restart lab
        </button>
      </div>

      {/* team sign-off */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, maxWidth: 620 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-tertiary)', letterSpacing: 0.5 }}>FROM THE TEAM</div>
        <Speech id="elena" size={36}>Clear verdict, clean evidence, and IOCs the whole team can act on. That’s exactly how a triage should close. Nice work.</Speech>
        <Speech id="priya" size={36}>You read the file from its own code and didn’t run it once — textbook static analysis.</Speech>
        <Speech id="david" size={36}>And you reused threat intel before going deep. Fast, defensible, and repeatable.</Speech>
      </div>
    </div>
  );
}

function Row({ k, v, mono }) {
  return (
    <div style={{ display: 'flex', gap: 10 }}>
      <span style={{ minWidth: 110, color: 'var(--text-tertiary)' }}>{k}:</span>
      <span className={mono ? 'mono selectable' : 'selectable'} style={{ color: 'var(--text-primary)', wordBreak: 'break-all' }}>{v}</span>
    </div>
  );
}
