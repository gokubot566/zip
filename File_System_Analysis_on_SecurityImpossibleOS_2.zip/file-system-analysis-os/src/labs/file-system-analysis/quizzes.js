// ===========================================================================
// "Record Your Findings" quizzes + forgiving validators for the File System
// Analysis lab. Validators are case-insensitive, trim whitespace, accept
// reasonable variants, and return a gentle hint on a wrong answer — never the
// answer. Pure JS so the Node tests can import and check them.
//
// The verdict stage (issue 2) uses these fill-in questions instead of a
// tick-to-confirm: the student types the IOCs and only finishes when they
// match; repeated misses reveal a hint.
// ===========================================================================

import { SUSPECT } from './scenario.js';

const norm = (s) => String(s ?? '').trim().toLowerCase();
const squash = (s) => norm(s).replace(/[\s]+/g, ' ');
// strip defang wrappers so "sentinel-c2-node[.]duckdns[.]org" == "sentinel-c2-node.duckdns.org"
const defang = (s) => norm(s).replace(/\[\.\]/g, '.').replace(/\(dot\)/g, '.').replace(/\s+/g, '');

export const QUIZZES = {
  // Stage 1 — where was it found.
  q_locate_path: {
    id: 'q_locate_path', stageId: 'locate', type: 'text',
    prompt: 'In which folder did you find the suspicious executable?',
    placeholder: 'e.g. C:\\Path\\To\\Folder',
    validate: (v) => {
      const s = defang(v);
      return (s.includes('windows\\temp') || s.includes('windows/temp') || s.endsWith('\\temp') || s.includes(':\\windows\\temp'))
        ? { ok: true }
        : { ok: false, hint: 'It sat in the system temporary folder. Look at the path in the Files app — it ends in \\Windows\\Temp.' };
    },
  },

  // Stage 4 — the SHA-256 fingerprint (typed back from the Terminal output).
  q_sha256: {
    id: 'q_sha256', stageId: 'hash', type: 'text',
    prompt: 'Paste the SHA-256 fingerprint you computed for crack.exe.',
    placeholder: 'the 64-character hex string',
    validate: (v) => {
      const s = norm(v).replace(/\s+/g, '');
      if (s === SUSPECT.hashes.sha256.toLowerCase()) return { ok: true };
      // accept a clear partial (first 12 hex chars) so a copy-paste slip still passes
      if (s.length >= 12 && SUSPECT.hashes.sha256.toLowerCase().startsWith(s)) return { ok: true };
      return { ok: false, hint: 'Run "certutil -hashfile crack.exe SHA256" in the Terminal and copy the whole hex string it prints (use the Copy button).' };
    },
  },

  // Stage 5 — the malware family from threat intel.
  q_family: {
    id: 'q_family', stageId: 'intel', type: 'text',
    prompt: 'What malware family does threat intelligence attribute crack.exe to?',
    placeholder: 'e.g. FamilyName',
    validate: (v) => (norm(v).replace(/\s+/g, '').includes('asyncrat')
      ? { ok: true }
      : { ok: false, hint: 'Read the vendor labels in Threat Lookup — the family name ends in "RAT" and starts with "Async".' }),
  },

  // Stage 6 — reflection on capability (open answer).
  q_capability: {
    id: 'q_capability', stageId: 'static', type: 'longtext',
    prompt: 'In your own words: from its imports, what is crack.exe built to do?',
    placeholder: 'e.g. It hooks the keyboard to log keystrokes, injects into other processes to hide, resists being killed, and calls out to a server…',
    validate: (v) => (norm(v).length >= 30
      ? { ok: true }
      : { ok: false, hint: 'Mention a couple of the flagged imports you saw — keyboard hooks (keylogging), process injection (hiding), and the network call (phoning home).' }),
  },

  // Stage 7 — VERDICT (choice) + IOC fill-ins (issue 2).
  q_verdict: {
    id: 'q_verdict', stageId: 'verdict', type: 'choice',
    prompt: 'Based on everything you found, what is crack.exe?',
    options: [
      { id: 'benign', text: 'Harmless / false alarm' },
      { id: 'suspicious', text: 'Suspicious, needs more data' },
      { id: 'malicious', text: 'Malicious — a keylogging RAT' },
    ],
    validate: (v) => (v === 'malicious'
      ? { ok: true }
      : { ok: false, hint: 'Weigh the evidence: temp-folder drop, 58/70 engines flagging it, keylogging + injection imports, and a call to a C2 server. It all points one way.' }),
  },
  q_ioc_c2: {
    id: 'q_ioc_c2', stageId: 'verdict', type: 'text',
    prompt: 'IOC 1 — enter the command-and-control (C2) domain the file contacts.',
    placeholder: 'e.g. bad-domain[.]example[.]org',
    validate: (v) => (defang(v).includes('sentinel-c2-node.duckdns.org')
      ? { ok: true }
      : { ok: false, hint: 'Check the strings/network indicator in the PE Inspector or Threat Lookup. It’s a DuckDNS domain beginning "sentinel-c2-node". Defanged form is fine.' }),
  },
  q_ioc_hash: {
    id: 'q_ioc_hash', stageId: 'verdict', type: 'text',
    prompt: 'IOC 2 — enter the file’s SHA-256 fingerprint.',
    placeholder: 'the 64-character hex string',
    validate: (v) => {
      const s = norm(v).replace(/\s+/g, '');
      if (s === SUSPECT.hashes.sha256.toLowerCase()) return { ok: true };
      if (s.length >= 12 && SUSPECT.hashes.sha256.toLowerCase().startsWith(s)) return { ok: true };
      return { ok: false, hint: 'This is the same fingerprint you computed in the Terminal (Stage 4). Paste the full SHA-256 hex string.' };
    },
  },
};

export function quizPassed(state, quizId) {
  return !!state?.labState?.answers?.[quizId]?.ok;
}
