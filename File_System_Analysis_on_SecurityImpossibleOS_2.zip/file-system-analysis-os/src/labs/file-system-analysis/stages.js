// ===========================================================================
// The linear stage model for the File System Analysis lab — Stages 1–7.
//
// Each stage carries its guide-overlay content (a `speaker` cast id + an
// in-character `intro`, instructions, "why this matters", jargon it teaches,
// an app to open, gating, and Record-Your-Findings questions) and a
// done(state) predicate derived only from the lab's own state:
//   - investigation flags the apps set in state.labState.fsa.* (via the bridge)
//   - quiz answers in state.labState.answers.* (via quizPassed)
// Valid speaker ids (shared cast): elena, marcus, priya, david, auditor.
// ===========================================================================

import { quizPassed } from './quizzes.js';

const fsa = (s, key) => s?.labState?.fsa?.[key];

export const STAGES = [
  {
    id: 'locate', part: 'A', step: 'Stage 1', title: 'Locate the file',
    speaker: 'elena', app: 'files', teaches: ['metadata'],
    intro: 'Every investigation starts by finding the artefact the attacker left behind. Malware loves temporary folders — writable, noisy, easy to overlook. Open the Files app and look through the common hiding spots. One executable does not belong.',
    instructions: [
      'Open the Files app from the dock.',
      'Browse to C:\\Windows\\Temp.',
      'Spot crack.exe among the files.',
      'Record the folder you found it in.',
    ],
    why: 'A random .exe in a temp folder, with no installed app to explain it, is a classic red flag on its own.',
    requires: (s) => !!fsa(s, 'foundFile'),
    requiresLabel: 'Browse to C:\\Windows\\Temp in the Files app to unlock this question.',
    quizIds: ['q_locate_path'],
    done: (s) => !!fsa(s, 'foundFile') && quizPassed(s, 'q_locate_path'),
  },
  {
    id: 'restore', part: 'A', step: 'Stage 2', title: 'Collect the file',
    speaker: 'auditor', app: 'security', teaches: ['quarantine'],
    intro: 'Your security tool already quarantined the file — good instinct, but you can’t examine a file you can’t reach. Open OmniGuard, find the quarantined item and restore it for analysis so you can work on it safely.',
    instructions: [
      'Open OmniGuard from the dock.',
      'Open Protection history.',
      'Select the crack.exe entry and choose Restore.',
    ],
    why: 'Only ever restore malware inside an isolated analysis machine — never on a live corporate PC. Here the workstation is safely simulated.',
    ackId: 'restoreAck',
    ackLabel: 'I understand this is only safe because the workstation is isolated/simulated.',
    done: (s) => !!fsa(s, 'restored') && !!s?.labState?.restoreAck,
  },
  {
    id: 'inspect', part: 'A', step: 'Stage 3', title: 'Inspect properties',
    speaker: 'auditor', app: 'files', teaches: ['metadata'],
    intro: 'Cheap, fast checks first — the file’s own details often reveal a lot before you reach for heavier tools. Right-click crack.exe and choose Open details. Note the size, the timestamps, and whether any legitimate software explains it.',
    instructions: [
      'In the Files app, right-click crack.exe → Open details.',
      'Read the size and the created/modified timestamps.',
      'Check whether it has a known publisher.',
    ],
    why: 'Small size + temp location + identical create/modify times + no vendor is the pattern of a freshly-dropped loader.',
    requires: (s) => !!fsa(s, 'inspected'),
    requiresLabel: 'Open crack.exe’s details in the Files app to continue.',
    done: (s) => !!fsa(s, 'inspected'),
  },
  {
    id: 'hash', part: 'A', step: 'Stage 4', title: 'Compute the hash',
    speaker: 'priya', app: 'terminal', teaches: ['hash', 'sha-256'],
    intro: 'A hash turns the whole file into one short string — change a single byte and it changes completely, so it uniquely identifies this exact file. Open the Terminal and run the hash command on crack.exe.',
    instructions: [
      'Open the Terminal from the dock.',
      'Run: certutil -hashfile crack.exe SHA256',
      'Copy the resulting hash, then record it below.',
    ],
    why: 'The fingerprint lets you look the file up in threat databases without sharing the file itself.',
    requires: (s) => !!fsa(s, 'hashed'),
    requiresLabel: 'Compute the SHA-256 hash in the Terminal to unlock this question.',
    quizIds: ['q_sha256'],
    done: (s) => !!fsa(s, 'hashed') && quizPassed(s, 'q_sha256'),
  },
  {
    id: 'intel', part: 'A', step: 'Stage 5', title: 'Threat-intel lookup',
    speaker: 'david', app: 'intel', teaches: ['ioc', 'detection ratio', 'threat intelligence'],
    intro: 'Reuse the world’s knowledge before doing your own deep analysis. Open Threat Lookup and search the hash — it checks dozens of antivirus engines and community reports without running the file. Read the detection ratio, the vendor labels and the reputation.',
    instructions: [
      'Open Threat Lookup from the dock.',
      'Paste the SHA-256 hash and search.',
      'Read the detection ratio and vendor labels, then record the family.',
    ],
    why: 'If lots of engines already know it as bad, you have strong evidence fast — and the labels tell you the type and family.',
    requires: (s) => !!fsa(s, 'intelDone'),
    requiresLabel: 'Search the hash in Threat Lookup to unlock this question.',
    quizIds: ['q_family'],
    done: (s) => !!fsa(s, 'intelDone') && quizPassed(s, 'q_family'),
  },
  {
    id: 'static', part: 'A', step: 'Stage 6', title: 'Static analysis',
    speaker: 'priya', app: 'pe', teaches: ['static analysis', 'pe', 'import', 'process injection'],
    intro: 'Threat intel says others think it’s bad — now confirm it yourself from the file’s own code, safely. Open the PE Inspector and review the header, the imports (the Windows functions it calls) and the strings. Flag the imports linked to spying and persistence.',
    instructions: [
      'Open PE Inspector from the dock and load crack.exe.',
      'Review the Imports tab and note the flagged (red) APIs.',
      'Record what the file is built to do.',
    ],
    why: 'Static analysis means examining a file without running it, so it can’t hurt you — and 25+ flagged imports is itself a red flag.',
    requires: (s) => !!fsa(s, 'staticDone'),
    requiresLabel: 'Review the imports in PE Inspector to unlock this question.',
    quizIds: ['q_capability'],
    done: (s) => !!fsa(s, 'staticDone') && quizPassed(s, 'q_capability'),
  },
  {
    id: 'verdict', part: 'A', step: 'Stage 7', title: 'Reach a verdict',
    speaker: 'elena', teaches: ['ioc', 'c2', 'rat', 'keylogger'],
    intro: 'Pull it together. Based on the location, the metadata, the threat-intel hits and the imports — is crack.exe malware? Record your verdict, then type the key Indicators of Compromise another analyst could hunt for. I’ll only sign off once they match.',
    instructions: [
      'Choose your verdict below.',
      'Type each Indicator of Compromise (IOC) into the boxes.',
      'Submit each answer — hints appear if something doesn’t match.',
    ],
    why: 'Every triage ends in a clear, defensible decision. IOCs let the whole team detect this threat elsewhere in the network.',
    quizIds: ['q_verdict', 'q_ioc_c2', 'q_ioc_hash'],
    done: (s) => quizPassed(s, 'q_verdict') && quizPassed(s, 'q_ioc_c2') && quizPassed(s, 'q_ioc_hash'),
  },
];

export function stageById(id) { return STAGES.find((s) => s.id === id) ?? null; }
export function stageDone(state, id) { const st = stageById(id); return st ? !!st.done(state) : false; }
export function currentStageId(state) {
  const first = STAGES.find((s) => !s.done(state));
  return (first ?? STAGES[STAGES.length - 1]).id;
}
export function progress(state) {
  const done = STAGES.filter((s) => s.done(state)).length;
  return { done, total: STAGES.length };
}
export function allComplete(state) { return STAGES.every((s) => s.done(state)); }
