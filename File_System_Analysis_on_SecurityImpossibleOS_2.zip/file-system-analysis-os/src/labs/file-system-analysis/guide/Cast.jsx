import React from 'react';
import { CHARACTERS } from '../content.js';

// The shared Security Impossible cast — licensed flat-illustration portraits.
// id → portrait mapping matches the course convention: character-1 Priya,
// character-2 David, character-3 Hannah (id "auditor"), character-4 Marcus,
// character-5 Elena. Imported so Vite fingerprints + bundles them.
import priyaPhoto from '../assets/cast/character-1.png';
import davidPhoto from '../assets/cast/character-2.png';
import auditorPhoto from '../assets/cast/character-3.png';
import marcusPhoto from '../assets/cast/character-4.png';
import elenaPhoto from '../assets/cast/character-5.png';

export const CAST_PHOTOS = {
  elena: elenaPhoto,
  marcus: marcusPhoto,
  priya: priyaPhoto,
  david: davidPhoto,
  auditor: auditorPhoto,
};

// A circular portrait ringed in the character's brand colour. Glows when speaking.
export function CastPhoto({ id, size = 40, speaking = false }) {
  const c = CHARACTERS[id];
  if (!c) return null;
  return (
    <span
      title={`${c.name} — ${c.role}`}
      style={{
        width: size, height: size, flexShrink: 0, display: 'inline-block',
        borderRadius: '50%', overflow: 'hidden', lineHeight: 0,
        background: 'var(--surface-1)',
        boxShadow: speaking ? `0 0 0 2px ${c.color}, 0 0 12px ${c.color}66` : `0 0 0 2px ${c.color}`,
        transition: 'box-shadow .25s',
      }}
    >
      <img src={CAST_PHOTOS[id]} alt={c.name} draggable="false"
        style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', userSelect: 'none' }} />
    </span>
  );
}

// A cast member speaking: portrait beside a named, attributed line.
export function Speech({ id, size = 36, children }) {
  const c = CHARACTERS[id];
  if (!c) return null;
  return (
    <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
      <CastPhoto id={id} size={size} speaking />
      <div style={{ minWidth: 0, flex: 1 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-primary)' }}>
          {c.name} <span style={{ color: 'var(--text-tertiary)', fontWeight: 500 }}>· {c.role}</span>
        </div>
        <div style={{ fontSize: 12.5, color: 'var(--text-secondary)', lineHeight: 1.55, marginTop: 2 }}>{children}</div>
      </div>
    </div>
  );
}
