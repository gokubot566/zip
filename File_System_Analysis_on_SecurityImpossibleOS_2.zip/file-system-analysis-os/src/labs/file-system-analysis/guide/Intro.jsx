import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, ArrowLeft, ShieldCheck, Users, FileSearch, LogIn } from 'lucide-react';
import { useOS } from '../../../core/OSContext.jsx';
import { CastPhoto, Speech } from './Cast.jsx';
import { LAB_TITLE, LAB_SUBTITLE, LAB_DURATION, CAST, CHARACTERS, BRIEF, HOST } from '../content.js';

// Pre-login guided intro: welcome → meet the team → the case brief. Fronted by
// Elena (IR Lead). On finish it sets labState.introDone and reveals the real
// sign-in screen. Mirrors the ICTSAS305 intro structure and styling.
const PAGES = ['welcome', 'cast', 'brief'];

export default function Intro() {
  const { mergeLabState } = useOS();
  const [page, setPage] = useState(0);
  const key = PAGES[page];
  const speaker = CHARACTERS.elena;

  const finish = () => mergeLabState({ introDone: true });
  const next = () => (page < PAGES.length - 1 ? setPage(page + 1) : finish());

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 90000, background: 'rgba(4,8,16,0.72)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <motion.div
        initial={{ opacity: 0, y: 16, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        style={{ width: 'min(720px, 96vw)', maxHeight: '90vh', background: 'var(--surface-2)', border: '1px solid var(--border-strong)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '16px 20px', borderBottom: '1px solid var(--border)', background: 'var(--surface-1)' }}>
          <CastPhoto id="elena" size={40} speaking />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 15, fontWeight: 700 }}>{speaker.name} <span style={{ fontWeight: 500, fontSize: 12, color: 'var(--text-tertiary)' }}>· {speaker.role}</span></div>
            <div style={{ fontSize: 11.5, color: 'var(--text-tertiary)' }}>{LAB_TITLE}</div>
          </div>
          <div style={{ display: 'flex', gap: 5 }}>
            {PAGES.map((p, i) => (
              <div key={p} style={{ width: i === page ? 20 : 7, height: 7, borderRadius: 999, background: i === page ? 'var(--accent)' : 'var(--border-strong)', transition: 'width .2s' }} />
            ))}
          </div>
        </div>

        <div className="scrolly" style={{ flex: 1, minHeight: 0, padding: 22 }}>
          <AnimatePresence mode="wait">
            <motion.div key={key} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} transition={{ duration: 0.18 }}>
              {key === 'welcome' && <Welcome />}
              {key === 'cast' && <Cast />}
              {key === 'brief' && <BriefPage />}
            </motion.div>
          </AnimatePresence>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 18px', borderTop: '1px solid var(--border)', background: 'var(--surface-1)' }}>
          <button className="os-btn ghost" onClick={() => setPage(Math.max(0, page - 1))} disabled={page === 0}>
            <ArrowLeft size={15} /> Back
          </button>
          {key === 'brief' ? (
            <button className="os-btn primary" data-e2e="intro-finish" onClick={finish}><LogIn size={15} /> Go to the sign-in screen</button>
          ) : (
            <button className="os-btn primary" data-e2e="intro-next" onClick={next}>Next <ArrowRight size={15} /></button>
          )}
        </div>
      </motion.div>
    </div>
  );
}

function Welcome() {
  return (
    <div>
      <h1 style={{ fontSize: 22, margin: '0 0 4px' }}>{LAB_SUBTITLE}</h1>
      <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
        Hi, I’m <strong>Elena Vasquez</strong> — I lead incident response here. You’re the analyst on this
        case. Together we’ll work a suspicious file end to end: find it, collect it safely, and prove
        whether it’s malware.
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, margin: '14px 0' }}>
        <InfoCard icon={<ShieldCheck size={17} color="var(--success)" />} title="Everything is safe">
          The whole environment is <strong>simulated</strong>. You’ll handle a suspicious-looking file,
          but nothing here is real malware and nothing can run.
        </InfoCard>
        <InfoCard icon={<Users size={17} color="var(--accent)" />} title={`This is ${HOST}`}>
          The lab simulates an isolated analysis workstation. You’ll use the <strong>Files</strong> app,
          <strong> Terminal</strong>, <strong>OmniGuard</strong>, <strong>Threat Lookup</strong> and the
          <strong> PE Inspector</strong>.
        </InfoCard>
      </div>
      <p style={{ fontSize: 12.5, color: 'var(--text-tertiary)' }}>⏱ {LAB_DURATION}</p>
      <div style={{ marginTop: 10, padding: 12, border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', background: 'var(--surface-1)' }}>
        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 6 }}>A habit that helps</div>
        <div style={{ fontSize: 12.5, color: 'var(--text-secondary)', lineHeight: 1.55 }}>
          Whenever a stage teaches a technical word — <span className="chip" style={{ fontSize: 11 }}>hash</span>{' '}
          <span className="chip" style={{ fontSize: 11 }}>IOC</span>{' '}
          <span className="chip" style={{ fontSize: 11 }}>quarantine</span> — tap it in the guide to see a
          plain-English meaning. The guide floats on top of the desktop; drag it anywhere by its header.
        </div>
      </div>
    </div>
  );
}

function Cast() {
  return (
    <div>
      <h2 style={{ fontSize: 18, margin: '0 0 4px' }}>Meet the team</h2>
      <p style={{ fontSize: 12.5, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
        You’re the analyst on the keyboard — but you’re not alone. Each teammate steps in to guide the
        stage that’s their specialty.
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}>
        {CAST.map((c) => <PersonRow key={c.id} p={c} />)}
      </div>
    </div>
  );
}

function PersonRow({ p }) {
  const c = CHARACTERS[p.id];
  return (
    <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', padding: 12, background: 'var(--surface-1)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)' }}>
      <CastPhoto id={p.id} size={44} />
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 700 }}>{c.name} <span style={{ fontWeight: 500, color: 'var(--text-tertiary)', fontSize: 11.5 }}>· {c.role}</span></div>
        <div style={{ fontSize: 12.5, color: 'var(--text-secondary)', lineHeight: 1.5, marginTop: 2 }}>{p.blurb}</div>
      </div>
    </div>
  );
}

function BriefPage() {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <FileSearch size={18} color="var(--accent)" />
        <h2 style={{ fontSize: 18, margin: 0 }}>The case</h2>
      </div>
      <Speech id="elena" size={34}>
        Here’s what we know. Read it, then sign in — I’ll walk you through the first stage the moment
        you’re on the machine.
      </Speech>

      <div style={{ border: '1px solid var(--border-strong)', borderRadius: 'var(--radius-md)', overflow: 'hidden', margin: '10px 0' }}>
        <div style={{ background: 'var(--accent)', color: 'var(--accent-contrast)', padding: '8px 14px', fontWeight: 700, fontSize: 13 }}>
          {BRIEF.ref} · {HOST}
        </div>
        <div style={{ padding: 14, fontSize: 12.5, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
          <div style={{ fontWeight: 700, color: 'var(--text-primary)' }}>Summary</div>
          <div>{BRIEF.summary}</div>
          <div style={{ marginTop: 10, fontWeight: 700, color: 'var(--text-primary)' }}>Detail</div>
          <div className="selectable">{BRIEF.detail}</div>
          <div style={{ marginTop: 10, fontWeight: 700, color: 'var(--text-primary)' }}>Your objectives</div>
          <ul style={{ margin: '4px 0' }}>{BRIEF.what.map((x) => <li key={x}>{x}</li>)}</ul>
        </div>
      </div>
    </div>
  );
}

function InfoCard({ icon, title, children }) {
  return (
    <div style={{ padding: 12, border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', background: 'var(--surface-1)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontWeight: 700, fontSize: 12.5, marginBottom: 5 }}>{icon}{title}</div>
      <div style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{children}</div>
    </div>
  );
}
