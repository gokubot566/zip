import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronDown, ChevronUp, X, ExternalLink, BookOpen, ListChecks, CheckCircle2, Circle,
  PartyPopper, GripVertical,
} from 'lucide-react';
import { useOS } from '../../../core/OSContext.jsx';
import { CastPhoto, Speech } from './Cast.jsx';
import Intro from './Intro.jsx';
import QuizInput from './QuizInput.jsx';
import { STAGES, currentStageId, stageById, stageDone, progress, allComplete } from '../stages.js';
import { GLOSSARY, CHARACTERS, BRIEF } from '../content.js';

const APP_LABELS = {
  files: 'Files', terminal: 'Terminal', security: 'OmniGuard',
  intel: 'Threat Lookup', pe: 'PE Inspector', completion: 'Lab Complete',
};

// The lab's guided-tour host. Mounts once above the whole shell. Shows the
// intro before login, a sign-in hint on the login screen, then a draggable
// team panel where the cast walk the student through every stage in character,
// teach jargon, and host the Record-Your-Findings questions.
export default function Guide() {
  const { state } = useOS();
  const { session } = state;
  if (!session.booted) return null;
  if (!state.labState.introDone) return <Intro />;
  if (!session.loggedIn) return <LoginHint />;
  return <GuidePanel />;
}

function LoginHint() {
  return (
    <div style={{ position: 'fixed', left: 24, bottom: 24, zIndex: 50000, maxWidth: 340, padding: '12px 14px', background: 'var(--surface-2)', border: '1px solid var(--border-strong)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-md)' }}>
      <Speech id="elena" size={34}>
        Sign in as <strong>analyst</strong> to step onto {`WORKSTATION-07`}. No password is needed —
        just press <span className="mono" style={{ color: 'var(--text-primary)' }}>Enter</span>.
      </Speech>
    </div>
  );
}

function GuidePanel() {
  const os = useOS();
  const { state, mergeLabState, openApp } = os;
  const collapsed = !!state.labState.guideCollapsed;
  const savedPos = state.labState.guidePos ?? null;
  const [pos, setPos] = useState(savedPos);
  const [showJargon, setShowJargon] = useState(null);
  const [showProgress, setShowProgress] = useState(false);
  const drag = useRef(null);

  const done = allComplete(state);
  const curId = currentStageId(state);
  const stage = stageById(curId);
  const p = progress(state);
  const speakerId = done ? 'elena' : (stage?.speaker ?? 'elena');
  const speaker = CHARACTERS[speakerId];

  useEffect(() => {
    if (done && !state.labState.completionShown) {
      mergeLabState({ completionShown: true });
      openApp('completion');
    }
  }, [done]); // eslint-disable-line

  const beginDrag = (e) => {
    const startX = e.clientX, startY = e.clientY;
    const base = pos ?? { x: window.innerWidth - 380, y: 80 };
    drag.current = { startX, startY, baseX: base.x, baseY: base.y };
    const onMove = (ev) => {
      const nx = Math.max(6, Math.min(window.innerWidth - 60, drag.current.baseX + (ev.clientX - startX)));
      const ny = Math.max(6, Math.min(window.innerHeight - 60, drag.current.baseY + (ev.clientY - startY)));
      setPos({ x: nx, y: ny });
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      setPos((cur) => { if (cur) mergeLabState({ guidePos: cur }); return cur; });
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const posStyle = pos ? { left: pos.x, top: pos.y } : { right: 24, top: 80 };

  if (collapsed) {
    return (
      <button
        onClick={() => mergeLabState({ guideCollapsed: false })}
        title={`Open your lab guide — ${speaker.name} is talking you through this step`}
        style={{ position: 'fixed', zIndex: 50000, ...posStyle, width: 56, height: 56, borderRadius: '50%', background: 'var(--surface-2)', border: 'none', boxShadow: 'var(--shadow-md)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0 }}
      >
        <CastPhoto id={speakerId} size={48} speaking />
        {!done && <span style={{ position: 'absolute', top: -3, right: -3, width: 14, height: 14, borderRadius: 999, background: 'var(--accent)', color: 'var(--accent-contrast)', fontSize: 9, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{p.total - p.done}</span>}
      </button>
    );
  }

  return (
    <motion.div
      data-e2e="guide-panel"
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      style={{ position: 'fixed', zIndex: 50000, ...posStyle, width: 356, maxHeight: 'min(76vh, 680px)', background: 'var(--surface-2)', border: '1px solid var(--border-strong)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}
    >
      <div
        onPointerDown={beginDrag}
        style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderBottom: '1px solid var(--border)', background: 'var(--surface-1)', cursor: 'grab', touchAction: 'none' }}
      >
        <CastPhoto id={speakerId} size={34} speaking />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{speaker.name}</div>
          <div style={{ fontSize: 10.5, color: 'var(--text-tertiary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{speaker.role} · {p.done}/{p.total} stages complete</div>
        </div>
        <GripVertical size={16} color="var(--text-tertiary)" />
        <button className="os-btn ghost" style={{ padding: 5 }} title="Minimise" onClick={() => mergeLabState({ guideCollapsed: true })}>
          <ChevronDown size={16} />
        </button>
      </div>

      <div style={{ height: 4, background: 'var(--surface-solid)' }}>
        <div style={{ width: `${(p.done / p.total) * 100}%`, height: '100%', background: 'var(--accent)', transition: 'width .3s' }} />
      </div>

      <div className="scrolly" style={{ flex: 1, minHeight: 0, padding: 14 }}>
        {done ? (
          <CompletePanel onOpen={() => openApp('completion')} />
        ) : (
          <StagePanel stage={stage} state={state} setShowJargon={setShowJargon} onOpenApp={(id) => openApp(id)} />
        )}
      </div>

      <div style={{ borderTop: '1px solid var(--border)', background: 'var(--surface-1)' }}>
        <button className="list-row" style={{ width: '100%', border: 'none', borderRadius: 0, justifyContent: 'space-between', fontSize: 12 }} onClick={() => setShowProgress((v) => !v)}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 7 }}><ListChecks size={15} /> Progress tracker</span>
          {showProgress ? <ChevronDown size={15} /> : <ChevronUp size={15} />}
        </button>
        <AnimatePresence>
          {showProgress && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} style={{ overflow: 'hidden' }}>
              <div className="scrolly" style={{ maxHeight: 220, padding: '4px 12px 10px' }}>
                {STAGES.map((s) => {
                  const d = stageDone(state, s.id);
                  const cur = s.id === curId && !done;
                  return (
                    <div key={s.id} style={{ display: 'flex', gap: 8, alignItems: 'center', padding: '3px 0' }}>
                      {d ? <CheckCircle2 size={14} color="var(--success)" /> : <Circle size={14} color={cur ? 'var(--accent)' : 'var(--text-tertiary)'} />}
                      <span style={{ fontSize: 11.5, color: d ? 'var(--text-primary)' : cur ? 'var(--accent)' : 'var(--text-secondary)', fontWeight: cur ? 700 : 400 }}>
                        {s.step}: {s.title}
                      </span>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {showJargon && <JargonModal termKey={showJargon} onClose={() => setShowJargon(null)} />}
    </motion.div>
  );
}

function StagePanel({ stage, state, setShowJargon, onOpenApp }) {
  if (!stage) return null;
  const requiresMet = !stage.requires || stage.requires(state);
  const isDone = stageDone(state, stage.id);
  const appLabel = stage.app ? APP_LABELS[stage.app] : null;
  const ackChecked = stage.ackId ? !!state.labState[stage.ackId] : false;
  const speaker = CHARACTERS[stage.speaker] ?? CHARACTERS.elena;

  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--accent)', letterSpacing: 0.4 }}>{stage.step.toUpperCase()}</div>
      <h3 data-e2e="guide-stage-title" data-stage={stage.id} style={{ fontSize: 15, margin: '2px 0 10px' }}>{stage.title}</h3>

      <div style={{ padding: '10px 12px', background: 'var(--surface-1)', border: '1px solid var(--border)', borderLeft: `3px solid ${speaker.color}`, borderRadius: 'var(--radius-sm)' }}>
        <Speech id={stage.speaker ?? 'elena'} size={32}>{stage.intro}</Speech>
      </div>

      {stage.teaches?.length > 0 && (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', margin: '8px 0' }}>
          {stage.teaches.map((t) => (
            <button key={t} className="chip" style={{ fontSize: 11, cursor: 'pointer', borderColor: 'var(--accent)' }} onClick={() => setShowJargon(t)}>
              <BookOpen size={12} /> {t}
            </button>
          ))}
        </div>
      )}

      {stage.id === 'locate' && (
        <div style={{ fontSize: 12, color: 'var(--text-secondary)', background: 'var(--surface-1)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: 10, margin: '6px 0' }}>
          <strong>{BRIEF.ref}</strong> — {BRIEF.summary}
        </div>
      )}

      <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)', margin: '10px 0 4px' }}>What to do</div>
      <ol style={{ margin: 0, paddingLeft: 18, fontSize: 12.5, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
        {stage.instructions.map((s, i) => <li key={i} style={{ marginBottom: 3 }}>{s}</li>)}
      </ol>

      {appLabel && (
        <button className="os-btn" data-e2e="guide-open-app" style={{ marginTop: 10, fontSize: 12 }} onClick={() => onOpenApp(stage.app)}>
          <ExternalLink size={14} /> Open {appLabel}
        </button>
      )}

      {stage.why && (
        <details style={{ marginTop: 10, fontSize: 12.5, color: 'var(--text-secondary)' }}>
          <summary style={{ cursor: 'pointer', fontWeight: 600, color: 'var(--text-primary)' }}>Why this matters</summary>
          <p style={{ lineHeight: 1.55, marginTop: 4 }}>{stage.why}</p>
        </details>
      )}

      {stage.quizIds && !requiresMet && (
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', marginTop: 12, padding: '10px 12px', background: 'var(--warning-bg)', border: '1px solid var(--warning)', borderRadius: 'var(--radius-sm)' }}>
          <BookOpen size={15} color="var(--warning)" style={{ flexShrink: 0, marginTop: 1 }} />
          <div style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{stage.requiresLabel}</div>
        </div>
      )}

      {stage.quizIds && requiresMet && stage.quizIds.map((qid) => <QuizInput key={qid} quizId={qid} />)}

      {stage.ackId && <AckToggle stage={stage} checked={ackChecked} met={!stage.requires || requiresMet} />}

      {isDone && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 14, padding: '10px 12px', background: 'var(--success-bg)', border: '1px solid var(--success)', borderRadius: 'var(--radius-sm)' }}>
          <CheckCircle2 size={16} color="var(--success)" />
          <span style={{ fontSize: 12.5, color: 'var(--text-primary)' }}>Stage complete — the next teammate will pick you up from here.</span>
        </div>
      )}
    </div>
  );
}

function AckToggle({ stage, checked }) {
  const { mergeLabState } = useOS();
  return (
    <button
      className="list-row"
      data-e2e="guide-ack"
      style={{ width: '100%', border: `1px solid ${checked ? 'var(--success)' : 'var(--border-strong)'}`, marginTop: 12, background: checked ? 'var(--success-bg)' : 'transparent' }}
      onClick={() => mergeLabState({ [stage.ackId]: !checked })}
    >
      {checked ? <CheckCircle2 size={16} color="var(--success)" /> : <Circle size={16} color="var(--text-tertiary)" />}
      <span style={{ fontSize: 12.5, textAlign: 'left', color: 'var(--text-secondary)' }}>{stage.ackLabel}</span>
    </button>
  );
}

function CompletePanel({ onOpen }) {
  return (
    <div style={{ textAlign: 'center', padding: '10px 4px' }}>
      <PartyPopper size={40} color="var(--accent)" style={{ margin: '0 auto' }} />
      <h3 style={{ fontSize: 16, margin: '10px 0 6px' }}>All stages complete!</h3>
      <p style={{ fontSize: 12.5, color: 'var(--text-secondary)', lineHeight: 1.55 }}>
        You located the file, collected it safely, fingerprinted it, confirmed it against threat intel,
        proved its intent, and recorded your verdict and IOCs. Open the completion screen to review your
        findings and hear from the team.
      </p>
      <button className="os-btn primary" data-e2e="guide-open-completion" style={{ marginTop: 10 }} onClick={onOpen}>Open completion screen</button>
    </div>
  );
}

function JargonModal({ termKey, onClose }) {
  const def = GLOSSARY[termKey] ?? '';
  const title = termKey.replace(/\b\w/g, (c) => c.toUpperCase());
  return (
    <div onMouseDown={onClose} style={{ position: 'fixed', inset: 0, zIndex: 60000, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div onMouseDown={(e) => e.stopPropagation()} style={{ width: 'min(420px, 92vw)', background: 'var(--surface-2)', border: '1px solid var(--border-strong)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)', overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 16px', borderBottom: '1px solid var(--border)', background: 'var(--surface-1)' }}>
          <BookOpen size={18} color="var(--accent)" />
          <div style={{ flex: 1, fontSize: 14, fontWeight: 700 }}>{title}</div>
          <button className="os-btn ghost" style={{ padding: 5 }} onClick={onClose}><X size={16} /></button>
        </div>
        <div style={{ padding: 16, fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{def}</div>
      </div>
    </div>
  );
}
