import React, { useState } from 'react';
import { CheckCircle2, HelpCircle, Lightbulb } from 'lucide-react';
import { useOS } from '../../../core/OSContext.jsx';
import { QUIZZES } from '../quizzes.js';

// A single "Record Your Findings" question. Reads/writes labState.answers, with
// forgiving validation from quizzes.js. Wrong answers reveal a gentle hint —
// never the answer. Reused by the intro sequence and the guide overlay.
export default function QuizInput({ quizId }) {
  const { state, mergeLabState } = useOS();
  const quiz = QUIZZES[quizId];
  const saved = state.labState.answers?.[quizId] ?? null;
  const [value, setValue] = useState(saved?.value ?? '');
  const [feedback, setFeedback] = useState(saved?.ok ? { ok: true } : null);

  if (!quiz) return null;

  const save = (val, res) => {
    const answers = { ...(state.labState.answers ?? {}), [quizId]: { value: val, ok: res.ok } };
    mergeLabState({ answers });
    setFeedback(res);
  };

  const submit = (val = value) => {
    const res = quiz.validate(val);
    save(typeof val === 'string' ? val.trim() : val, res);
  };

  const ok = feedback?.ok;

  return (
    <div data-e2e={`quiz-${quizId}`} data-ok={ok ? '1' : '0'} style={{ marginTop: 12, padding: 12, background: 'var(--surface-2)', border: `1px solid ${ok ? 'var(--success)' : 'var(--border)'}`, borderRadius: 'var(--radius-md)' }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', marginBottom: 8 }}>
        <HelpCircle size={16} color="var(--accent)" style={{ flexShrink: 0, marginTop: 1 }} />
        <div style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text-primary)' }}>{quiz.prompt}</div>
      </div>

      {quiz.type === 'choice' ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {quiz.options.map((o) => {
            const selected = value === o.id;
            return (
              <button
                key={o.id}
                data-e2e={`quiz-opt-${quizId}-${o.id}`}
                onClick={() => { setValue(o.id); submit(o.id); }}
                className={`list-row ${selected ? 'selected' : ''}`}
                style={{ width: '100%', border: '1px solid var(--border)', textAlign: 'left', alignItems: 'flex-start' }}
              >
                <span style={{ fontWeight: 700, color: 'var(--accent)' }}>{o.id.toUpperCase()}</span>
                <span style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>{o.text}</span>
              </button>
            );
          })}
        </div>
      ) : quiz.type === 'longtext' ? (
        <textarea
          className="os-textarea selectable"
          data-e2e={`quiz-input-${quizId}`}
          style={{ minHeight: 84, fontSize: 12.5 }}
          placeholder={quiz.placeholder}
          value={value}
          onChange={(e) => { setValue(e.target.value); if (feedback) setFeedback(null); }}
        />
      ) : (
        <input
          className="os-input selectable"
          data-e2e={`quiz-input-${quizId}`}
          style={{ fontSize: 12.5 }}
          placeholder={quiz.placeholder}
          value={value}
          onChange={(e) => { setValue(e.target.value); if (feedback) setFeedback(null); }}
          onKeyDown={(e) => { if (e.key === 'Enter') submit(); }}
        />
      )}

      {quiz.type !== 'choice' && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8 }}>
          <button className="os-btn primary" data-e2e={`quiz-submit-${quizId}`} style={{ fontSize: 12 }} onClick={() => submit()}>
            {quiz.type === 'longtext' ? 'Save answer' : 'Check answer'}
          </button>
          {ok && <span style={{ fontSize: 12, color: 'var(--success)', display: 'flex', alignItems: 'center', gap: 5 }}><CheckCircle2 size={15} /> {quiz.type === 'longtext' ? 'Saved' : 'Correct'}</span>}
        </div>
      )}

      {ok && quiz.type === 'choice' && (
        <div style={{ fontSize: 12, color: 'var(--success)', display: 'flex', alignItems: 'center', gap: 5, marginTop: 8 }}><CheckCircle2 size={15} /> Correct</div>
      )}

      {feedback && !ok && feedback.hint && (
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', marginTop: 8, padding: '8px 10px', background: 'var(--warning-bg)', border: '1px solid var(--warning)', borderRadius: 'var(--radius-sm)' }}>
          <Lightbulb size={15} color="var(--warning)" style={{ flexShrink: 0, marginTop: 1 }} />
          <div style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{feedback.hint}</div>
        </div>
      )}
    </div>
  );
}
