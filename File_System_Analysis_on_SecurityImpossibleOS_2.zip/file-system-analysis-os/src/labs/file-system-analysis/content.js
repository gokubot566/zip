// ===========================================================================
// Content for the File System Analysis lab's guided experience.
// Mirrors the ICTSAS305 lab's content model (cast + glossary + brief) so the
// guide overlay renders with the same look and structure.
// ===========================================================================

export const LAB_TITLE = 'File System Analysis & Metadata Extraction';
export const LAB_SUBTITLE = 'Locate, collect and triage a suspicious file — decide if it is malware.';
export const LAB_DURATION = 'This lab is designed to be completed in about 45–60 minutes.';
export const HOST = 'WORKSTATION-07';

// The shared Security Impossible cast — roles re-tagged for this DFIR scenario.
// (id, name, colour and portrait stay constant course-wide; only role changes.)
export const CHARACTERS = {
  elena:   { name: 'Elena Vasquez', role: 'Incident Response Lead',      color: '#6366f1' },
  marcus:  { name: 'Marcus Chen',   role: 'SOC Manager',                 color: '#3b82f6' },
  priya:   { name: 'Priya Patel',   role: 'Malware Analyst',             color: '#10b981' },
  david:   { name: 'David Okafor',  role: 'Threat Intelligence Analyst', color: '#f59e0b' },
  auditor: { name: 'Hannah Wong',   role: 'Digital Forensics Examiner',  color: '#06b6d4' },
};

// Short self-introductions for the intro "meet the team" page.
// (Issue 1 fix: Priya says "malware analyst", not "our malware analyst".)
export const CAST = [
  { id: 'elena',   blurb: 'I run the case and I’ll sign off on your final verdict.' },
  { id: 'marcus',  blurb: 'SOC Manager. My analysts raised the alert that started all this.' },
  { id: 'priya',   blurb: 'Malware analyst — hashing and static analysis are my world. I’ll help you read the file.' },
  { id: 'david',   blurb: 'Threat Intelligence. I’ll help you check the file’s reputation against what the world already knows.' },
  { id: 'auditor', blurb: 'Digital Forensics. I care about collecting evidence cleanly so it holds up.' },
];

// The case brief the student reads before starting (shown in the intro and
// recapped in Stage 1 of the guide).
export const BRIEF = {
  ref: 'CASE SI-2025-0473',
  summary: 'The SOC flagged unusual activity on WORKSTATION-07. Something suspicious was written into a system temp folder.',
  detail:
    'Automated monitoring on ' + HOST + ' raised an alert: an unexpected executable appeared in ' +
    'C:\\Windows\\Temp shortly after the user opened an email attachment. The endpoint tool quarantined ' +
    'the file. Your job is to locate it, collect it safely, examine it, fingerprint it, check threat ' +
    'intelligence, prove its intent, and record a clear verdict with Indicators of Compromise (IOCs).',
  what: [
    'Find the suspicious file on disk.',
    'Collect it safely from quarantine (in this isolated analysis machine only).',
    'Examine its metadata, fingerprint it, and check threat intel.',
    'Prove intent from its own code, then record a verdict and IOCs.',
  ],
};

// Plain-English jargon. Keyed by the lowercase term used in stage.teaches.
// Rendered by the guide's jargon modal and glossary chips.
export const GLOSSARY = {
  'hash': 'A short string that uniquely identifies a file — its fingerprint. Change a single byte and it changes completely.',
  'sha-256': 'A specific, very strong type of file hash (fingerprint).',
  'ioc': 'Indicator of Compromise — a tell-tale sign of an attack (a bad file, domain, hash or behaviour) that others can hunt for.',
  'pe': 'Portable Executable — the standard format of Windows .exe and .dll programs.',
  'rat': 'Remote Access Trojan — malware that lets an attacker control your machine from afar.',
  'trojan': 'Malware pretending to be something harmless so you run it.',
  'keylogger': 'Malware that records everything you type, including passwords.',
  'static analysis': 'Examining a file without executing it, so it cannot do any harm.',
  'import': 'A built-in Windows function a program calls to do its work (e.g. read the keyboard).',
  'quarantine': 'When security software isolates a file so it cannot run.',
  'c2': 'Command-and-Control — the server malware phones home to for orders.',
  'metadata': 'Information describing a file: its size, dates, owner and type.',
  'detection ratio': 'How many antivirus engines flagged the file, out of the total that scanned it.',
  'dropper': 'A small program whose job is to install other malware.',
  'process injection': 'Running malicious code inside another, trusted program to hide.',
  'threat intelligence': 'Shared knowledge about known-bad files, domains and techniques, so you can reuse what others have already found.',
};
