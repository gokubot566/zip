import React from 'react';
import { useFsaLab } from './bridge.jsx';
import { FilesApp, TerminalApp, SecurityApp, IntelApp, PEApp } from './apps.jsx';

/* =============================================================================
   App wrappers
   Each Security Impossible OS window hosts one ported lab app. The wrapper pulls
   the shared investigation state from the bridge and passes the exact props the
   original component expects. Everything is rendered inside `.fsa-scope` so the
   lab's palette applies only within the lab surface.
   ============================================================================= */

function Surface({ children }) {
  return <div className="fsa-scope fsa-app-scope">{children}</div>;
}

function withLab(Comp) {
  return function Wrapped() {
    const { lab, patchLab, openApp, allDone } = useFsaLab();
    return (
      <Surface>
        <Comp lab={lab} patchLab={patchLab} openApp={openApp} allDone={allDone} />
      </Surface>
    );
  };
}

export const FilesAppW = withLab(FilesApp);
export const TerminalAppW = withLab(TerminalApp);
export const SecurityAppW = withLab(SecurityApp);
export const IntelAppW = withLab(IntelApp);
export const PEAppW = withLab(PEApp);
