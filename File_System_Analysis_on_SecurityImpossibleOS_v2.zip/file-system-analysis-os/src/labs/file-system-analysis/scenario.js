/* =============================================================================
   Security Impossible OS — File System Analysis & Metadata Extraction
   All lab content lives here: the virtual file system, the suspicious file's
   forensic profile, the investigation task gates, Byte's guided script, and the
   plain-English glossary. UI components read from these exports.
   ============================================================================= */

export const LAB_META = {
  os: 'Security Impossible OS',
  version: '3.1',
  title: 'File System Analysis & Metadata Extraction',
  subtitle: 'Locate, collect and triage a suspicious file — decide if it is malware.',
  host: 'WORKSTATION-07',
  analyst: 'you',
  duration: '45–60 min',
  unit: 'Malware Triage & Incident Response — foundations',
};

/* ---- The mentor cast (shared roster; roles re-tagged for a DFIR scenario) ---
   Keep id, name, color and portrait constant course-wide — only role changes. */
export const CHARACTERS = {
  elena:   { name: 'Elena Vasquez', role: 'Incident Response Lead',      color: '#6366f1' },
  marcus:  { name: 'Marcus Chen',   role: 'SOC Manager',                 color: '#3b82f6' },
  priya:   { name: 'Priya Patel',   role: 'Malware Analyst',             color: '#10b981' },
  david:   { name: 'David Okafor',  role: 'Threat Intelligence Analyst', color: '#f59e0b' },
  auditor: { name: 'Hannah Wong',   role: 'Digital Forensics Examiner',  color: '#06b6d4' },
};

/* =============================================================================
   THE SUSPICIOUS FILE — single source of truth for its forensic properties.
   Values mirror a real .NET keylogger/RAT dropper triage (see lab brief).
   ============================================================================= */
export const SUSPECT = {
  name: 'crack.exe',
  path: '/tmp/crack.exe',
  displayPath: 'C:\\Windows\\Temp\\crack.exe  (mounted at /tmp on this workstation)',
  sizeBytes: 177152,          // ~173 KB
  sizeHuman: '173 KB',
  created: '2025-11-18 02:47:11',
  modified: '2025-11-18 02:47:11',
  accessed: '2025-11-18 02:49:03',
  owner: 'SYSTEM',
  quarantined: true,          // Defender grabbed it; student must "restore" to analyse
  hashes: {
    md5:    'e3b0c44298fc1c149afbf4c8996fb924',
    sha1:   'da39a3ee5e6b4b0d3255bfef95601890afd80709',
    sha256: '9f2c4a7b1e8d0f63a5c9b2e4d7f10a3c6b8e5d2f4a9c1b7e0d3f6a2c5b8e1d4f7',
  },
  // simulated threat-intel result (as if pasted into a hash lookup service)
  intel: {
    detectionEngines: 70,
    detectionHits: 58,
    firstSeen: '2025-09-02',
    lastSeen: '2025-11-19',
    reputation: -37,           // community score
    labels: ['Trojan', 'Keylogger', 'RAT', 'MSIL/Agent', 'AsyncRAT'],
    family: 'AsyncRAT (Remote Access Trojan family)',
  },
  // simulated PE static-analysis (PeStudio-style)
  pe: {
    fileType: 'Win32 EXE (PE32)',
    subsystem: 'GUI (windowed)',
    dotnet: true,
    packed: true,
    bits: 32,
    sections: ['.text', '.rsrc', '.reloc', '.data'],
    dosHeaderBytes: 128,
    stringsCount: 2605,
    importsFlagged: 27,
    // the specific imports the lab calls out, with plain-language red flags
    suspiciousImports: [
      { api: 'SetWindowsHookEx',       flag: 'Installs a global hook — the classic keylogging technique.' },
      { api: 'GetKeyboardState',       flag: 'Reads the whole keyboard at once — captures what you type.' },
      { api: 'GetAsyncKeyState',       flag: 'Polls individual keys — another way to log keystrokes.' },
      { api: 'GetForegroundWindow',    flag: 'Sees which window you are in — steals context around keystrokes.' },
      { api: 'CreateRemoteThread',     flag: 'Runs code inside another program — process injection.' },
      { api: 'SetThreadExecutionState',flag: 'Stops the machine sleeping — keeps the spy running.' },
      { api: 'RtlSetProcessIsCritical',flag: 'Marks itself un-killable — resists being shut down.' },
      { api: 'InternetOpenUrlA',       flag: 'Opens a network connection — phones home to a server.' },
    ],
    // benign-looking imports to contrast (teaches "not every import is bad")
    normalImports: ['CreateWindowExW', 'GetMessageW', 'LoadIconW', 'RegisterClassExW'],
  },
  // network indicators observed in the sandbox report
  network: [
    { ioc: 'ip-api.com', note: 'Looks up the victim’s public location.' },
    { ioc: 'sentinel-c2-node[.]duckdns[.]org', note: 'Command-and-control (attacker) server.' },
    { ioc: '45.132.—.— : 6606', note: 'AsyncRAT default control port.' },
  ],
};

/* Files scattered in the VFS so the student has to actually *look* for the one
   bad file among normal-looking system/user files. Only /tmp/crack.exe is the
   target. `susp:true` marks the answer. */
export const FILE_SYSTEM = {
  '/': ['tmp', 'home', 'etc', 'var', 'opt'],
  '/home': ['analyst'],
  '/home/analyst': ['Documents', 'Downloads', 'Pictures', 'notes.txt', 'report-draft.md'],
  '/home/analyst/Documents': ['onboarding.pdf', 'passwords-REMINDER.txt', 'quarterly.xlsx'],
  '/home/analyst/Downloads': ['setup-legit-app.msi', 'invoice_47812.pdf', 'holiday-photos.zip'],
  '/home/analyst/Pictures': ['team.png', 'diagram.png'],
  '/etc': ['hosts', 'services', 'crontab'],
  '/var': ['log', 'tmp', 'cache'],
  '/var/log': ['system.log', 'auth.log', 'defender.log'],
  '/var/tmp': ['update-cache.tmp'],
  '/opt': ['tools'],
  '/opt/tools': ['README.md'],
  // the smoking gun
  '/tmp': ['crack.exe', 'sess_a91.tmp', 'chrome_installer.log', '.X0-lock'],
};

/* Descriptions shown in file "Properties" for the non-target files, so nothing
   looks obviously placeholder. Keyed by full path. Optional. */
export const FILE_INFO = {
  '/tmp/crack.exe': { kind: 'Application (PE executable)', note: 'Unknown publisher. Placed in a temp folder. No matching installed software.' },
  '/tmp/sess_a91.tmp': { kind: 'Temp data', note: 'Browser session scratch file. Normal.' },
  '/tmp/chrome_installer.log': { kind: 'Log file', note: 'Left by a browser update. Normal.' },
  '/tmp/.X0-lock': { kind: 'Lock file', note: 'Display-server lock. Normal on a desktop.' },
  '/home/analyst/Documents/passwords-REMINDER.txt': { kind: 'Text', note: 'Bad practice, but not malware. Flag to the user separately.' },
  '/home/analyst/Downloads/setup-legit-app.msi': { kind: 'Installer', note: 'Signed installer for a known app. Benign.' },
  '/var/log/defender.log': { kind: 'Log file', note: 'Security software log — may mention the quarantine event.' },
};

/* =============================================================================
   INVESTIGATION TASKS — the gated flow Byte walks the student through.
   Each task has an id, the app it happens in, a completion signal, and the
   step-by-step commands (each with plain "what it does" + "why it matters").
   `check` is how App.jsx knows the task is satisfied.
   ============================================================================= */
export const TASKS = [
  {
    id: 'locate', n: 1, area: 'Locate the file', app: 'files', speaker: 'elena',
    threat: 'Unknown suspicious file',
    stage: 'Stage 1 of 7 · Find the threat. Every investigation starts by finding the artefact — the actual file or trace the attacker left behind.',
    tool: { name: 'Files', what: 'A file browser (like Windows Explorer). It lets you walk the folder tree and look at what is on disk.' },
    brief: "Malware loves <b>temporary folders</b> — they’re writable, noisy, and easy to overlook. Open the <b>Files</b> app and look through the common hiding spots. One executable does not belong.",
    goal: "Open the Files app and find the suspicious executable in /tmp.",
    successNote: "Found it — crack.exe sitting in /tmp. An .exe in a temp folder with no matching software is a classic red flag.",
    check: { type: 'foundFile', path: '/tmp/crack.exe' },
    steps: [
      { cmd: 'Open the Files app from the dock',
        what: 'Launches the file browser so you can walk the folder tree.',
        why: 'You investigate on-disk first — see what’s actually there before touching anything.' },
      { cmd: 'Browse to /tmp',
        what: 'Opens the system temporary directory.',
        why: 'Temp folders are writable by everything, so they’re a favourite drop spot for malware.' },
      { cmd: 'Spot crack.exe among the files',
        what: 'Identifies the one program file that has no business being there.',
        why: 'A random .exe in temp, with no installed app to explain it, is suspicious on its own.' },
    ],
  },
  {
    id: 'restore', n: 2, area: 'Collect the file', app: 'security', speaker: 'auditor',
    threat: 'Sample locked in quarantine',
    stage: 'Stage 2 of 7 · Collect the evidence. Before you can analyse anything, you need clean, controlled access to the sample — without letting it run loose.',
    tool: { name: 'OmniGuard', what: 'The workstation’s anti-virus / endpoint protection tool. It blocks threats and stores caught files in quarantine (a locked, safe holding area).' },
    brief: "Your security tool already <b>quarantined</b> the file — good instinct, but you can’t examine a file you can’t reach. Open <b>OmniGuard</b>, find the quarantined item and <b>restore it for analysis</b> so you can work on it safely.",
    goal: "Restore the quarantined crack.exe from OmniGuard so it can be analysed.",
    successNote: "Restored to /tmp. In a real lab this only happens inside an isolated analysis machine — never on a live corporate PC.",
    check: { type: 'restored' },
    steps: [
      { cmd: 'Open OmniGuard',
        what: 'Opens the built-in protection app.',
        why: 'The sample was auto-quarantined; this is where you release it for controlled analysis.' },
      { cmd: 'Open Protection history',
        what: 'Lists everything the tool has blocked or quarantined.',
        why: 'The quarantine event tells you when it was caught and what it was called.' },
      { cmd: 'Select the crack.exe entry → Restore',
        what: 'Returns the file to /tmp so tools can read it.',
        why: 'Only do this in a sandbox. Restoring malware on a real machine is dangerous.' },
    ],
  },
  {
    id: 'inspect', n: 3, area: 'Inspect properties', app: 'files', speaker: 'auditor',
    threat: 'Undocumented metadata',
    stage: 'Stage 3 of 7 · Examine the basics. Cheap, fast checks first — the file’s own details often reveal a lot before you reach for heavier tools.',
    tool: { name: 'File details', what: 'The file’s metadata (data about the file): its size, when it was created and changed, who owns it, and whether it is signed by a known publisher.' },
    brief: "Before any deep tooling, read the basics. <b>Right-click crack.exe</b> and choose <b>Open details</b> to see its file information. Note the <b>size</b>, the <b>timestamps</b>, and whether any legitimate software explains it. Small size + temp location + no known vendor is a pattern.",
    goal: "Right-click crack.exe and open its details to review the file information.",
    successNote: "173 KB, created and modified at the same second, owned by SYSTEM, no publisher. Small single-purpose binaries like this are typical droppers/loaders.",
    check: { type: 'inspected' },
    steps: [
      { cmd: 'Right-click crack.exe → Open details',
        what: 'Opens the file-details panel (its size, dates, owner and type).',
        why: 'Metadata is “data about the file” — size, dates and owner give early clues.' },
      { cmd: 'Read the size and timestamps',
        what: 'Records how big it is and when it appeared.',
        why: '173 KB is tiny for a real app; identical create/modify times suggest it was just dropped.' },
      { cmd: 'Check for a known publisher',
        what: 'Looks for a signature or vendor name.',
        why: 'No publisher + unexplained presence = you can’t trust it.' },
    ],
  },
  {
    id: 'hash', n: 4, area: 'Compute the hash', app: 'terminal', speaker: 'priya',
    threat: 'File not yet fingerprinted',
    stage: 'Stage 4 of 7 · Fingerprint it. A hash gives the file a unique ID you can share and search — the key that unlocks threat intelligence.',
    tool: { name: 'Terminal', what: 'A text command line. You type commands and it prints results. Here you use it to run the hashing tool on the file.' },
    brief: "A <b>hash</b> <i>(fingerprint)</i> turns the whole file into one short string. Change a single byte and the string changes completely — so it uniquely identifies this exact file. Open the <b>Terminal</b> and run the hash command on crack.exe.",
    goal: "Use the terminal to compute the SHA-256 hash of /tmp/crack.exe.",
    successNote: "You now have the file’s fingerprint. Next we ask the world if anyone has seen it before.",
    check: { type: 'command', match: 'sha256:/tmp/crack.exe' },
    steps: [
      { cmd: 'sha256sum /tmp/crack.exe',
        what: 'Calculates the SHA-256 fingerprint of the file.',
        why: 'The fingerprint lets you look the file up in threat databases without sharing the file itself.' },
      { cmd: 'Copy the resulting hash',
        what: 'Grabs the long hex string it prints.',
        why: 'You’ll paste this into the threat-intel lookup in the next step.' },
    ],
  },
  {
    id: 'intel', n: 5, area: 'Threat-intel lookup', app: 'intel', speaker: 'david',
    threat: 'Unknown reputation',
    stage: 'Stage 5 of 7 · Check what’s known. Reuse the world’s knowledge before doing your own deep analysis — if it’s already known-bad, that’s fast, strong evidence.',
    tool: { name: 'Threat Lookup', what: 'A threat-intelligence search. You paste a file’s fingerprint and it reports how many antivirus engines call it malicious, what they name it, and its community reputation.' },
    brief: "Open <b>Threat Lookup</b> and search the hash. This checks it against dozens of antivirus engines and community reports — no need to run the file. Read the <b>detection ratio</b>, the <b>vendor labels</b> and the <b>reputation</b>.",
    goal: "Look up the SHA-256 hash in Threat Lookup and review the verdict.",
    successNote: "58 of 70 engines flag it, labelled Trojan / Keylogger / RAT, community reputation deeply negative. That’s a strong malicious signal.",
    check: { type: 'intelLookup' },
    steps: [
      { cmd: 'Paste the hash into Threat Lookup → Search',
        what: 'Queries many security vendors at once for that fingerprint.',
        why: 'If lots of engines already know it as bad, you have your answer fast.' },
      { cmd: 'Read the detection ratio',
        what: 'Shows how many engines flagged it (e.g. 58 / 70).',
        why: 'A high ratio strongly indicates malware.' },
      { cmd: 'Read the vendor labels',
        what: 'Shows what each vendor calls it (Trojan, Keylogger, RAT…).',
        why: 'Agreement on Trojan/RAT tells you the type and family of threat.' },
    ],
  },
  {
    id: 'static', n: 6, area: 'Static analysis', app: 'pe', speaker: 'priya',
    threat: 'Behaviour unknown',
    stage: 'Stage 6 of 7 · Prove intent. Threat intel says others think it’s bad — now confirm it yourself from the file’s own code, safely.',
    tool: { name: 'PE Inspector', what: 'A static-analysis tool for Windows programs. It opens the file’s structure without running it, and lists the functions (imports) and text (strings) inside — revealing what the program is built to do.' },
    brief: "Now look <i>inside</i> the file <b>without running it</b> — that’s <b>static analysis</b>. Open the <b>PE Inspector</b> and review the header, the <b>imports</b> <i>(the Windows functions it calls)</i>, and the strings. Flag the imports linked to spying and persistence.",
    goal: "Open PE Inspector on crack.exe and review its imports and structure.",
    successNote: "27 flagged imports — keyboard hooks, process injection, anti-kill, and a network call. The code is built to spy and hide.",
    check: { type: 'staticAnalysis' },
    steps: [
      { cmd: 'Load crack.exe in PE Inspector',
        what: 'Parses the file’s internal structure safely, without executing it.',
        why: 'Static analysis = examining a file without running it, so it can’t hurt you.' },
      { cmd: 'Review the Imports tab',
        what: 'Lists the Windows functions the program uses.',
        why: 'Functions like keyboard hooks and remote-thread creation reveal intent.' },
      { cmd: 'Note the flagged (red) APIs',
        what: 'Highlights imports commonly abused by malware.',
        why: '25+ flagged imports is itself a red flag the tool calls out automatically.' },
    ],
  },
  {
    id: 'verdict', n: 7, area: 'Reach a verdict', app: 'report', speaker: 'elena',
    threat: 'Case unresolved',
    stage: 'Stage 7 of 7 · Decide and report. Turn your evidence into a clear verdict and a list of IOCs the whole team can act on.',
    tool: { name: 'Triage Report', what: 'Your findings write-up. It gathers the evidence, records your verdict, and lists the Indicators of Compromise (IOCs) so others can detect this threat elsewhere.' },
    brief: "Pull it together. Based on the location, the metadata, the threat-intel hits and the imports, decide: <b>is crack.exe malware?</b> Then list the <b>Indicators of Compromise</b> <i>(IOCs — the tell-tale signs)</i> another analyst could hunt for.",
    goal: "Submit your verdict and confirm the key Indicators of Compromise.",
    successNote: "Case closed: crack.exe is a keylogging Remote Access Trojan. You collected it safely, fingerprinted it, confirmed it against threat intel, and proved malicious intent from its own code.",
    check: { type: 'verdict' },
    steps: [
      { cmd: 'Choose the verdict: Malicious',
        what: 'Records your professional conclusion.',
        why: 'Every triage ends in a clear, defensible decision.' },
      { cmd: 'Confirm the IOCs',
        what: 'Lists the fingerprint, the C2 domain, the file path and the behaviours.',
        why: 'IOCs let the whole team detect this threat elsewhere in the network.' },
    ],
  },
];
export const TASK_ORDER = TASKS.map((t) => t.id);

/* =============================================================================
   BYTE — the floating guide. Page 1 = Byte (robot) intro; page 2 = the team.
   ============================================================================= */
export const BYTE_INTRO = {
  // Page 1 — Byte speaks (robot avatar for every line).
  byteLines: [
    "Hi, I’m Byte — your guide inside Security Impossible OS. 👋 I float on top of the desktop and I’ll walk you through every step, so you’re never stuck.",
    "Here’s the case: the SOC flagged odd activity on this workstation. Something suspicious was dropped into a <b>temp folder</b>. Your job is to find it, collect it safely, and prove whether it’s malware.",
    "📖 One habit that helps: whenever you see a technical word like <b>hash</b> or <b>IOC</b>, I put a one-word meaning right next to it, and every task lists the exact commands with a plain explanation. Tap the <b>ⓘ</b> on any command to see what it does.",
    "Ready to meet the team?",
  ],
  // Page 2 — the human cast introduce themselves.
  team: [
    { s: 'elena',   t: "I’m Elena, Incident Response Lead. I run the case and I’ll sign off on your final verdict." },
    { s: 'marcus',  t: "Marcus, SOC Manager. My analysts raised the alert that started all this." },
    { s: 'priya',   t: "I’m Priya, our Malware Analyst — hashing and static analysis are my world. I’ll help you read the file." },
    { s: 'david',   t: "David, Threat Intelligence. I’ll help you check the file’s reputation against what the world already knows." },
    { s: 'auditor', t: "And I’m Hannah, Digital Forensics. I care about collecting evidence cleanly so it holds up." },
  ],
};

/* =============================================================================
   GLOSSARY — one-word / plain meanings for jargon. Rendered as a reference and
   used for inline chips. Keep meanings genuinely short.
   ============================================================================= */
export const GLOSSARY = [
  { term: 'Hash', one: 'Fingerprint', long: 'A short string that uniquely identifies a file. Change one byte and it changes completely.' },
  { term: 'SHA-256', one: 'Fingerprint', long: 'A specific, very strong type of file hash (fingerprint).' },
  { term: 'IOC', one: 'Clue', long: 'Indicator of Compromise — a tell-tale sign of an attack (a bad file, domain, or behaviour) others can hunt for.' },
  { term: 'PE', one: 'Windows-program', long: 'Portable Executable — the standard format of Windows .exe and .dll programs.' },
  { term: 'RAT', one: 'Remote-spy', long: 'Remote Access Trojan — malware that lets an attacker control your machine from afar.' },
  { term: 'Trojan', one: 'Disguised-malware', long: 'Malware pretending to be something harmless so you run it.' },
  { term: 'Keylogger', one: 'Keystroke-spy', long: 'Malware that records everything you type, including passwords.' },
  { term: 'Static analysis', one: 'Look-don’t-run', long: 'Examining a file without executing it, so it can’t do any harm.' },
  { term: 'Import', one: 'Function-used', long: 'A built-in Windows function a program calls to do its work (e.g. read the keyboard).' },
  { term: 'Quarantine', one: 'Locked-away', long: 'When security software isolates a file so it can’t run.' },
  { term: 'C2', one: 'Attacker-server', long: 'Command-and-Control — the server malware phones home to for orders.' },
  { term: 'Metadata', one: 'Data-about-data', long: 'Information describing a file: its size, dates, owner and type.' },
  { term: 'Detection ratio', one: 'Flags-count', long: 'How many antivirus engines flagged the file, out of the total that scanned it.' },
  { term: 'Dropper', one: 'Malware-installer', long: 'A small program whose job is to install other malware.' },
  { term: 'Process injection', one: 'Code-smuggling', long: 'Running malicious code inside another, trusted program to hide.' },
];

/* =============================================================================
   PROCESS + TOOLBOX — plain-English overview of the whole lab, shown in the
   desktop Help panel so users understand what they're doing and why.
   ============================================================================= */
export const LAB_ABOUT =
  "You are a security analyst. The SOC (Security Operations Centre — the team that watches for attacks) flagged odd activity on this workstation. Something suspicious was dropped into a temporary folder. Your job is malware triage: find the file, collect it safely, and gather enough evidence to decide whether it is harmful — then record what you found so the rest of the team can act.";

export const PROCESS = [
  { n: 1, title: 'Find the threat', tool: 'Files', text: 'Locate the suspicious file. Malware often hides in temp folders because anything can write there.' },
  { n: 2, title: 'Collect it safely', tool: 'OmniGuard', text: 'Release the file from quarantine so you can analyse it — something only ever done inside an isolated machine.' },
  { n: 3, title: 'Examine the basics', tool: 'File details', text: 'Read its size, dates and publisher. Cheap checks often reveal a lot before heavier tools.' },
  { n: 4, title: 'Fingerprint it', tool: 'Terminal', text: 'Compute a hash — a short unique ID for the exact file — so you can look it up without sharing the file.' },
  { n: 5, title: 'Check what’s known', tool: 'Threat Lookup', text: 'Search the fingerprint against many antivirus engines and reports. Known-bad is fast, strong evidence.' },
  { n: 6, title: 'Prove intent', tool: 'PE Inspector', text: 'Read the file’s own code without running it. The functions it uses reveal what it was built to do.' },
  { n: 7, title: 'Decide & report', tool: 'Triage Report', text: 'Turn the evidence into a clear verdict and a list of IOCs the whole team can hunt for.' },
];

export const TOOLBOX = [
  { name: 'Files', what: 'A file browser (like Windows Explorer) for walking the folder tree and inspecting what is on disk.' },
  { name: 'OmniGuard', what: 'The anti-virus / endpoint protection tool. It blocks threats and holds caught files in quarantine (a safe, locked area).' },
  { name: 'Terminal', what: 'A text command line. You type commands and read the output — here, to compute the file’s hash (fingerprint).' },
  { name: 'Threat Lookup', what: 'A threat-intelligence search. Paste a fingerprint to see how many vendors call it malicious, what they name it, and its reputation.' },
  { name: 'PE Inspector', what: 'A static-analysis tool: it opens a Windows program’s structure without running it and lists its functions and strings.' },
  { name: 'Triage Report', what: 'Where you record your verdict and the Indicators of Compromise (IOCs) — the tell-tale signs others can search for.' },
];

/* =============================================================================
   COMPLETION — shown when all 7 tasks are cleared.
   ============================================================================= */
export const LEARNING_OUTCOMES = [
  'Identify common locations where malware hides, such as temp directories.',
  'Collect a suspicious file safely without contaminating evidence.',
  'Read file metadata and recognise suspicious patterns.',
  'Compute a file hash (fingerprint) from the command line.',
  'Use threat intelligence to check a file’s reputation by its hash.',
  'Perform static analysis to read a program’s intent from its imports.',
  'Reach a defensible verdict and record Indicators of Compromise (IOCs).',
];

export const SUMMARY = {
  passTitle: 'Case closed — threat confirmed',
  passBody:
    "You located a suspicious executable in a temp folder, released it into a safe analysis environment, fingerprinted it, confirmed its bad reputation against threat intelligence, and proved malicious intent from its own code — keyboard hooks, process injection, anti-kill and a call home to a command-and-control server. crack.exe is a keylogging Remote Access Trojan. That’s a complete malware-triage workflow, start to finish.",
  outcomesTitle: 'What you practised',
  verdict: {
    correct: 'malicious',
    prompt: 'Based on everything you found, what is crack.exe?',
    options: [
      { value: 'benign',    label: 'Harmless / false alarm' },
      { value: 'suspicious',label: 'Suspicious, needs more data' },
      { value: 'malicious', label: 'Malicious — a keylogging RAT' },
    ],
    wrongNote: 'Look again at the threat-intel hits and the imports — the evidence points one way.',
  },
  iocs: [
    { k: 'File', v: 'crack.exe in a temp folder (C:\\Windows\\Temp)' },
    { k: 'Fingerprint (SHA-256)', v: '9f2c…d4f7' },
    { k: 'C2 domain', v: 'sentinel-c2-node[.]duckdns[.]org' },
    { k: 'Behaviour', v: 'Keyboard hooks, process injection, anti-termination, phones home' },
    { k: 'Family', v: 'AsyncRAT (Remote Access Trojan)' },
  ],
};

export const DISCLAIMER =
  'Training simulation. Security Impossible OS, WORKSTATION-07, “crack.exe”, all users, files, hashes, domains and detections shown are fictional and run entirely offline inside your browser — no real files are read and no real systems are touched. The hash and IOCs are invented for training. Built for foundational malware-triage and incident-response practice.';
