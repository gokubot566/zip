// Headless E2E runner: mounts the real <App/> in jsdom and drives the two
// reviewer changes. Bundles test/e2e-entry.jsx with esbuild so JSX/CSS/asset
// imports resolve like the Vite build. Usage: node test/e2e-dom.mjs
import { JSDOM } from 'jsdom';
import { build } from 'esbuild';
import { pathToFileURL, fileURLToPath } from 'node:url';
import path from 'node:path';
import fs from 'node:fs';

const DIR = path.dirname(fileURLToPath(import.meta.url));

const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', {
  url: 'http://localhost:3000/', pretendToBeVisual: true,
});
const { window } = dom;
globalThis.window = window;
globalThis.document = window.document;
Object.defineProperty(globalThis, 'navigator', { value: window.navigator, configurable: true });
for (const k of ['HTMLElement', 'HTMLInputElement', 'HTMLTextAreaElement', 'SVGElement', 'Element', 'Node',
  'Event', 'MouseEvent', 'KeyboardEvent', 'CustomEvent', 'getComputedStyle', 'DOMParser', 'MutationObserver']) {
  if (window[k] && !globalThis[k]) globalThis[k] = window[k];
}
globalThis.requestAnimationFrame = (cb) => setTimeout(() => cb(Date.now()), 0);
globalThis.cancelAnimationFrame = (id) => clearTimeout(id);
window.requestAnimationFrame = globalThis.requestAnimationFrame;
window.cancelAnimationFrame = globalThis.cancelAnimationFrame;
window.matchMedia = window.matchMedia || (() => ({
  matches: false,
  media: '', onchange: null,
  addEventListener() {}, removeEventListener() {},
  addListener() {}, removeListener() {},  // legacy API framer-motion still calls
  dispatchEvent() { return false; },
}));
globalThis.matchMedia = window.matchMedia;
window.confirm = () => true;
window.scrollTo = () => {};
if (!window.Element.prototype.scrollIntoView) window.Element.prototype.scrollIntoView = () => {};
class RO { observe() {} unobserve() {} disconnect() {} }
globalThis.ResizeObserver = window.ResizeObserver = RO;
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

const outfile = path.join(DIR, '.e2e-bundle.mjs');
await build({
  entryPoints: [path.join(DIR, 'e2e-entry.jsx')],
  bundle: true, format: 'esm', platform: 'browser', jsx: 'automatic',
  outfile, logLevel: 'error',
  loader: { '.png': 'dataurl', '.jpg': 'dataurl', '.jpeg': 'dataurl', '.gif': 'dataurl', '.webp': 'dataurl', '.svg': 'text', '.css': 'empty' },
  define: { 'process.env.NODE_ENV': '"development"' },
  banner: { js: "import { createRequire as __cr } from 'module'; const require = __cr(import.meta.url);" },
});

console.log('\n=== FSA LAB — END-TO-END (jsdom, real <App/>) ===\n');
await import(pathToFileURL(outfile).href);
const result = await globalThis.__E2E;
try { fs.unlinkSync(outfile); } catch {}

if (!result.ok) { console.error('\nRESULT: FAIL —', result.error); process.exit(1); }
console.log('\nRESULT: PASS — ' + result.log.filter((l) => l.startsWith('  [')).length + ' steps, all assertions green.');
process.exit(0);
