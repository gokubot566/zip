/* End-to-end checks for the two reviewer changes, run against the REAL <App/>
   mounted in jsdom (no browser needed):
     • Byte intro copy — the "just like a real machine" bubble is gone and the
       "drag me anywhere / grab my header" clause is gone; the intro still hands
       off to the team.
     • TermChip overlap fix — the glossary chip renders under the collision-free
       .tchip class family (not .term, which the Terminal app also defines and
       which made the inline chip a full-height column that overlapped text).
   Bundled by run-e2e.mjs with esbuild, executed under jsdom.                    */
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import { OSProvider } from '../src/core/OSContext.jsx';
import App from '../src/App.jsx';

const log = [];
const say = (m) => { log.push(m); console.log(m); };
let step = 0;
const stepHead = (m) => say(`  [${String(++step).padStart(2, '0')}] ${m}`);
function assert(cond, m) { if (!cond) throw new Error('ASSERT FAILED: ' + m); say('     \u2713 ' + m); }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function tick(fn) { await act(async () => { if (fn) fn(); await sleep(0); }); await sleep(0); }
async function waitFor(pred, label, timeout = 8000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) { if (pred()) return true; await act(async () => { await sleep(20); }); }
  throw new Error('waitFor timed out: ' + label);
}

const $ = (sel) => document.querySelector(sel);
const $all = (sel) => Array.from(document.querySelectorAll(sel));
const byText = (sel, re) => $all(sel).filter((el) => re.test(el.textContent || ''));
function click(el) { if (!el) throw new Error('click: missing element'); el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true })); }
function setInputValue(el, v) {
  const set = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  set.call(el, v); el.dispatchEvent(new window.Event('input', { bubbles: true }));
}

// Strings that MUST be gone after the edits.
const REMOVED_MACHINE = 'just like a real machine';
const REMOVED_DRAG_1 = 'drag me anywhere';
const REMOVED_DRAG_2 = 'grab my header';

async function run() {
  const container = document.getElementById('root');
  await act(async () => { createRoot(container).render(React.createElement(OSProvider, null, React.createElement(App))); });
  await tick();

  // ---- BOOT ----
  stepHead('Boot the OS');
  await waitFor(() => $('input[type="password"]') || $('.byte-panel') || byText('button', /sign in/i).length,
    'login screen (boot finished)');
  say('     \u2713 Reached the sign-in screen');

  // ---- LOGIN (blank password accepted) ----
  stepHead('Sign in');
  const pw = $('input[type="password"]');
  if (pw) await tick(() => setInputValue(pw, ''));
  const form = pw ? pw.closest('form') : null;
  if (form) await tick(() => form.dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true })));
  await waitFor(() => $('.byte-panel') || $('.byte-body'), 'Byte guide visible after login');
  say('     \u2713 Signed in; Byte guide is up');

  // ---- BYTE INTRO COPY (changes 1 & 2) ----
  stepHead('Byte intro copy — reveal all bubbles');
  // The intro auto-plays; "Skip ahead" reveals every remaining bubble at once.
  const skip = byText('.byte-hint-toggle', /skip ahead/i)[0];
  if (skip) await tick(() => click(skip));
  await waitFor(() => byText('.byte-next', /meet the team/i).length > 0, 'all intro bubbles shown');

  const bubbles = $all('.byte-line-bubble').map((b) => b.textContent || '');
  const introText = bubbles.join('  ||  ');
  assert(bubbles.length >= 1, 'Byte intro renders bubbles');
  assert(!introText.toLowerCase().includes(REMOVED_MACHINE),
    'Removed the "just like a real machine" bubble');
  assert(!introText.toLowerCase().includes(REMOVED_DRAG_1) && !introText.toLowerCase().includes(REMOVED_DRAG_2),
    'Removed the "drag me anywhere / grab my header" clause');
  assert(/ready to meet the team/i.test(introText),
    'Intro still ends with the "Ready to meet the team?" hand-off');
  assert(byText('.byte-next', /meet the team/i).length > 0,
    '"Meet the team" button present (intro flows to the team page)');

  // ---- TEAM PAGE (sanity: the hand-off works) ----
  stepHead('Intro → team page');
  await tick(() => click(byText('.byte-next', /meet the team/i)[0]));
  await waitFor(() => byText('.byte-area', /meet your team/i).length > 0, 'team page shown');
  say('     \u2713 Team page reached');

  // Start the tasks so the desktop + apps are usable.
  const startBtn = byText('.byte-next', /start|look around|begin|audit|investigat/i)[0]
    || byText('button', /start|look around|begin|audit|investigat/i)[0];
  if (startBtn) await tick(() => click(startBtn));
  await sleep(30);

  // ---- TERMCHIP OVERLAP FIX (change 3) ----
  // Open File Details (via Files) and PE Inspector — both render TermChips.
  // We can't measure pixels in jsdom, but we can assert the structural fix:
  // chips use .tchip / .tchip-one and NOT the colliding .term class.
  stepHead('TermChip renders under the collision-free .tchip class');

  // Reach into OS state to open apps directly (robust vs. clicking desktop icons).
  // The Files app's Details modal and the PE app both use <TermChip>.
  // Open PE Inspector (its Overview/Imports panels are full of chips).
  // We open via the taskbar/desktop if present, else via a synthetic open.
  const openViaDesktop = (label) => {
    const icon = byText('.dsk-icon, .desktop-icon, [data-app]', new RegExp(label, 'i'))[0];
    if (icon) { click(icon); return true; }
    return false;
  };

  // Best-effort open of PE Inspector and Files; fall back to asserting on any
  // TermChip already in the DOM (the guide/task copy also uses them).
  openViaDesktop('PE Inspector');
  openViaDesktop('Files');
  await sleep(40);

  const anyTerm = $all('.term');            // Terminal container(s) legitimately use .term
  const chips = $all('.tchip');
  const oldChips = $all('.pe-note .term, .pe-interp .term, .prop-note .term, .byte-line-bubble .term');

  assert(oldChips.length === 0,
    'No TermChip uses the old .term class (which collides with the Terminal app)');

  // A chip should exist somewhere reachable in the guide/task copy or apps.
  // If none is currently mounted, render one directly to prove the class wiring.
  if (chips.length === 0) {
    say('     · No chip mounted in current view; verifying component class wiring directly');
    const { TermChip } = await import('../src/labs/file-system-analysis/ui.jsx');
    const probe = document.createElement('div');
    probe.id = 'chip-probe';
    document.body.appendChild(probe);
    await act(async () => { createRoot(probe).render(React.createElement(TermChip, { t: 'hash' })); });
    await sleep(0);
  }
  const chip = $('.tchip');
  assert(!!chip, 'Glossary chip renders with the collision-free .tchip class');
  assert(!!(chip.querySelector('.tchip-one')), 'Chip inline label uses .tchip-one');

  // Terminal's own .term (a flex column) is fine and independent of chips.
  say(`     \u2713 Terminal .term containers: ${anyTerm.length} (unaffected by the rename)`);

  say('\nALL E2E STEPS PASSED \u2705');
  return true;
}

globalThis.__E2E = run().then(
  () => ({ ok: true, log }),
  (e) => { console.error('\n\u2718 ' + e.message); return { ok: false, error: e.message, log }; },
);
