# Security Impossible — Module 1: Welcome & Why Security Matters Here

**Onboarding Portal | Port 7070 | Module 1 of 11**

---

## 🚀 Quick Deploy

```bash
# Build and start
docker compose up -d --build

# Check status
docker compose ps

# View logs
docker compose logs -f si-onboarding-module1

# Stop
docker compose down
```

Access at: `http://localhost:7070` or `http://<AZURE-PUBLIC-IP>:7070`

---

## ☁️ Azure Deployment

### 1. Open Firewall Port

In Azure Portal → Virtual Machine → Networking → Add inbound port rule:
- **Port:** 7070
- **Protocol:** TCP
- **Action:** Allow
- **Priority:** 1010
- **Name:** Allow-SI-Onboarding-7070

### 2. Deploy

```bash
# Clone/copy project files to VM
git clone <repo> si-module1
cd si-module1

# Build and run
docker compose up -d --build

# Verify
docker compose ps
curl http://localhost:7070/health
```

### 3. Access

```
http://<YOUR-VM-PUBLIC-IP>:7070
```

---

## 📁 Project Structure

```
si-module1/
├── src/
│   ├── App.jsx                   # Root — tabs, progress, layout
│   ├── main.jsx                  # React entry point
│   ├── styles/
│   │   └── globals.css           # Dark theme variables & animations
│   └── components/
│       ├── Header.jsx            # Sticky header with clock & progress
│       ├── Sidebar.jsx           # 11-module navigation (Module 1 active)
│       ├── WelcomeSection.jsx    # Core content, stats, key principles
│       ├── ScenarioCard.jsx      # "Curious Friend" interactive scenario
│       ├── QuizSection.jsx       # 5-question knowledge check
│       ├── ByteAssistant.jsx     # Floating AI guide (Byte)
│       └── Footer.jsx            # Module completion indicator
├── Dockerfile                    # Multi-stage build (Node → nginx)
├── docker-compose.yml            # Port 7070, restart policy, healthcheck
├── nginx.conf                    # nginx server config (port 7070, SPA)
├── vite.config.js
├── package.json
└── index.html
```

---

## 🛠️ Local Development

```bash
npm install
npm run dev          # http://localhost:7070 (hot reload)
npm run build        # Production build to dist/
npm run preview      # Preview production build
```

---

## 📦 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite 5 |
| Animations | Framer Motion 11 |
| Icons | Lucide React |
| Fonts | Syne (display), Space Grotesk (body), JetBrains Mono |
| Server | nginx:alpine |
| Container | Docker multi-stage build |

---

## 📞 Support

Platform: it@securityimpossible.com.au  
Security queries: security@securityimpossible.com.au
