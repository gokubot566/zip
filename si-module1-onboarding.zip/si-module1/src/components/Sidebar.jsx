import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, Circle, Lock, ChevronRight, BookOpen } from 'lucide-react';

const MODULES = [
  { id: 1, title: 'Welcome & Why Security Matters', duration: '15 min', status: 'active', section: 'Foundation' },
  { id: 2, title: 'Confidentiality & Your Obligations', duration: '20 min', status: 'locked', section: 'Foundation' },
  { id: 3, title: 'Intellectual Property & Ownership', duration: '15 min', status: 'locked', section: 'Foundation' },
  { id: 4, title: 'Privacy & Australian Privacy Principles', duration: '25 min', status: 'locked', section: 'Compliance' },
  { id: 5, title: 'Data Classification & Handling', duration: '20 min', status: 'locked', section: 'Compliance' },
  { id: 6, title: 'Asset Management & Secure Workplace', duration: '15 min', status: 'locked', section: 'Operations' },
  { id: 7, title: 'Recognising & Responding to Threats', duration: '25 min', status: 'locked', section: 'Operations' },
  { id: 8, title: 'Acceptable Use & AI Tools', duration: '20 min', status: 'locked', section: 'Operations' },
  { id: 9, title: 'Social Media & Public Conduct', duration: '15 min', status: 'locked', section: 'Conduct' },
  { id: 10, title: 'Working with Clients & Third Parties', duration: '20 min', status: 'locked', section: 'Conduct' },
  { id: 11, title: 'Putting It Together & Your Commitment', duration: '10 min', status: 'locked', section: 'Completion' },
];

const SECTION_COLORS = {
  Foundation: 'var(--cyan)',
  Compliance: 'var(--purple)',
  Operations: 'var(--amber)',
  Conduct: 'var(--green)',
  Completion: 'var(--red)',
};

export default function Sidebar({ open, completedSections }) {
  const sections = [...new Set(MODULES.map(m => m.section))];

  return (
    <AnimatePresence>
      {open && (
        <motion.aside
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: 'var(--sidebar-w)', opacity: 1 }}
          exit={{ width: 0, opacity: 0 }}
          transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
          style={{
            height: '100%',
            background: 'var(--bg-panel)',
            borderRight: '1px solid var(--border)',
            overflowY: 'auto',
            overflowX: 'hidden',
            flexShrink: 0,
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          {/* Header */}
          <div style={{
            padding: '16px 18px 12px',
            borderBottom: '1px solid var(--border)',
            flexShrink: 0,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <BookOpen size={14} color="var(--cyan)" />
              <span style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--t3)', letterSpacing: '0.08em' }}>
                TRAINING MODULES
              </span>
            </div>

            {/* Overall progress */}
            <div style={{
              background: 'var(--bg-card)',
              border: '1px solid var(--border)',
              borderRadius: 10, padding: '10px 12px',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontSize: 11, color: 'var(--t3)' }}>Overall Progress</span>
                <span style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--cyan)' }}>1/11</span>
              </div>
              <div className="progress-track">
                <motion.div className="progress-fill" animate={{ width: '9%' }} />
              </div>
            </div>
          </div>

          {/* Module list by section */}
          <div style={{ flex: 1, padding: '10px 10px', overflowY: 'auto' }}>
            {sections.map(section => (
              <div key={section} style={{ marginBottom: 8 }}>
                <div style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  padding: '6px 8px', marginBottom: 2,
                }}>
                  <div style={{
                    width: 4, height: 4, borderRadius: '50%',
                    background: SECTION_COLORS[section],
                    boxShadow: `0 0 6px ${SECTION_COLORS[section]}`,
                  }} />
                  <span style={{
                    fontSize: 10, fontFamily: 'var(--mono)',
                    color: SECTION_COLORS[section], letterSpacing: '0.08em', fontWeight: 600,
                  }}>
                    {section.toUpperCase()}
                  </span>
                </div>

                {MODULES.filter(m => m.section === section).map((mod, i) => (
                  <motion.div
                    key={mod.id}
                    whileHover={mod.status !== 'locked' ? { x: 3 } : {}}
                    style={{
                      display: 'flex', alignItems: 'flex-start', gap: 10,
                      padding: '9px 10px', borderRadius: 8, marginBottom: 2,
                      cursor: mod.status === 'locked' ? 'not-allowed' : 'pointer',
                      background: mod.status === 'active' ? `rgba(${hexToRgb(SECTION_COLORS[section])}, 0.08)` : 'transparent',
                      border: mod.status === 'active' ? `1px solid rgba(${hexToRgb(SECTION_COLORS[section])}, 0.2)` : '1px solid transparent',
                      opacity: mod.status === 'locked' ? 0.5 : 1,
                      transition: 'all 0.2s',
                    }}
                  >
                    <div style={{ flexShrink: 0, marginTop: 1 }}>
                      {mod.status === 'complete' ? (
                        <CheckCircle2 size={14} color="var(--green)" />
                      ) : mod.status === 'locked' ? (
                        <Lock size={12} color="var(--t4)" />
                      ) : (
                        <motion.div
                          animate={{ scale: [1, 1.2, 1] }}
                          transition={{ duration: 2, repeat: Infinity }}
                        >
                          <Circle size={14} color={SECTION_COLORS[section]} fill={SECTION_COLORS[section]} />
                        </motion.div>
                      )}
                    </div>

                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{
                        fontSize: 12.5, fontWeight: mod.status === 'active' ? 600 : 400,
                        color: mod.status === 'active' ? 'var(--t1)' : 'var(--t3)',
                        lineHeight: 1.35, marginBottom: 2,
                      }}>
                        <span style={{ color: 'var(--t4)', fontFamily: 'var(--mono)', fontSize: 10, marginRight: 4 }}>
                          {String(mod.id).padStart(2, '0')}
                        </span>
                        {mod.title}
                      </div>
                      <div style={{ fontSize: 10, color: 'var(--t4)', fontFamily: 'var(--mono)' }}>
                        ⏱ {mod.duration}
                      </div>
                    </div>

                    {mod.status === 'active' && (
                      <ChevronRight size={12} color={SECTION_COLORS[section]} style={{ flexShrink: 0, marginTop: 2 }} />
                    )}
                  </motion.div>
                ))}
              </div>
            ))}
          </div>

          {/* Footer */}
          <div style={{
            padding: '12px 16px',
            borderTop: '1px solid var(--border)',
            flexShrink: 0,
          }}>
            <div style={{ fontSize: 10, color: 'var(--t4)', fontFamily: 'var(--mono)', lineHeight: 2 }}>
              <div>SI-ONBOARD-2025 v2.0</div>
              <div style={{ color: 'var(--t3)' }}>security@securityimpossible.com.au</div>
            </div>
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  );
}

function hexToRgb(color) {
  // Handle CSS var references - return defaults
  const map = {
    'var(--cyan)': '56,189,248',
    'var(--purple)': '167,139,250',
    'var(--amber)': '251,191,36',
    'var(--green)': '34,211,165',
    'var(--red)': '248,113,113',
  };
  return map[color] || '56,189,248';
}
