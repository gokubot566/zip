import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { MessageCircle, User, AlertCircle, CheckCircle2, XCircle, ChevronRight } from 'lucide-react';

const SCENARIO = {
  id: 'scenario-1',
  title: 'The Curious Friend',
  context: `It's your third week at Security Impossible. You're catching up with a close friend over coffee — someone who works in IT at another company and is generally trustworthy. They know you joined a cybersecurity firm and are curious about the work.`,
  messages: [
    { from: 'friend', name: 'Alex (Your Friend)', text: "So what's it actually like working at a security firm? I bet you deal with some crazy stuff! Any interesting client hacks you've been working on?" },
    { from: 'friend', name: 'Alex (Your Friend)', text: "Oh come on, you can tell me. I won't say anything. Which companies are you working with? Anyone I'd know?" },
  ],
  responses: [
    {
      id: 'a',
      text: "\"Ha, yeah it's fascinating! We're doing a penetration test for a bank right now — found some really serious vulnerabilities. Can't name them but it's one of the big four!\"",
      correct: false,
      feedback: "This is a confidentiality breach. You disclosed the type of engagement, the industry, and enough information to potentially identify the client. Even without naming the bank specifically, \"one of the big four\" significantly narrows it down. Conversations like this — even with trusted friends — are exactly how confidential information leaks.",
    },
    {
      id: 'b',
      text: "\"I can't really talk about specific clients or engagements — it's a confidentiality thing that applies even with people I completely trust. But I can say the work is genuinely challenging!\"",
      correct: true,
      feedback: "This is the correct response. You've acknowledged your friend's curiosity warmly, declined to share confidential information, explained why without being preachy, and redirected to something you can share. This is exactly the kind of professional discretion that builds client trust over time.",
    },
    {
      id: 'c',
      text: "\"I honestly can't talk about work at all — strict NDA. Don't ask me anything.\"",
      correct: false,
      feedback: "While this avoids a breach, the response is unnecessarily abrupt and may come across as suspicious or antisocial. You can be warm and personable while declining to share confidential specifics. 'I can't talk about NDAs' shuts down conversation unnecessarily — you can discuss the nature of your work in general terms.",
    },
    {
      id: 'd',
      text: "\"Sure, we're working with a major financial institution on their network security. I'll keep it vague but the findings were pretty alarming honestly.\"",
      correct: false,
      feedback: "Even vague disclosures like 'major financial institution' and 'alarming findings' can constitute a confidentiality breach. Describing the scope, industry, and general severity of findings without naming the client still discloses confidential information. A sophisticated listener could use this to identify the client or make market-moving inferences.",
    },
  ],
};

export default function ScenarioCard({ onComplete }) {
  const [selectedResponse, setSelectedResponse] = useState(null);
  const [revealed, setRevealed] = useState(false);
  const [completed, setCompleted] = useState(false);

  function handleSelect(response) {
    if (revealed) return;
    setSelectedResponse(response);
  }

  function handleReveal() {
    if (!selectedResponse) return;
    setRevealed(true);
    if (selectedResponse.correct && onComplete) {
      setTimeout(() => { setCompleted(true); onComplete(); }, 1000);
    }
  }

  function handleReset() {
    setSelectedResponse(null);
    setRevealed(false);
    setCompleted(false);
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      style={{ maxWidth: 900, margin: '0 auto' }}
    >
      {/* Section header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
        <MessageCircle size={16} color="var(--amber)" />
        <span style={{ fontSize: 17, fontWeight: 700, color: 'var(--t1)', fontFamily: 'var(--display)' }}>
          Workplace Scenario
        </span>
        <span className="tag tag-amber">Interactive</span>
      </div>

      <div style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border-bright)',
        borderRadius: 16, overflow: 'hidden',
      }}>
        {/* Scenario header */}
        <div style={{
          padding: '16px 20px',
          background: 'rgba(251,191,36,.05)',
          borderBottom: '1px solid rgba(251,191,36,.15)',
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <AlertCircle size={18} color="var(--amber)" />
          <div>
            <div style={{ fontSize: 12, fontFamily: 'var(--mono)', color: 'var(--amber)', marginBottom: 2, letterSpacing: '0.06em' }}>
              SCENARIO — RESPOND CAREFULLY
            </div>
            <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--t1)' }}>{SCENARIO.title}</div>
          </div>
        </div>

        {/* Context */}
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)' }}>
          <p style={{ fontSize: 13.5, color: 'var(--t2)', lineHeight: 1.75 }}>{SCENARIO.context}</p>
        </div>

        {/* Chat messages */}
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)', background: 'rgba(0,0,0,.15)' }}>
          {SCENARIO.messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 + i * 0.15 }}
              style={{ display: 'flex', gap: 12, marginBottom: i < SCENARIO.messages.length - 1 ? 14 : 0 }}
            >
              <div style={{
                width: 34, height: 34, borderRadius: '50%', flexShrink: 0,
                background: 'linear-gradient(135deg, #1e40af, #3b82f6)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 14,
              }}>
                👤
              </div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--t3)', marginBottom: 4, fontFamily: 'var(--mono)' }}>
                  {msg.name}
                </div>
                <div style={{
                  background: 'var(--bg-hover)',
                  border: '1px solid var(--border)',
                  borderRadius: '12px 12px 12px 4px',
                  padding: '10px 14px',
                  fontSize: 13.5, color: 'var(--t1)', lineHeight: 1.6,
                  maxWidth: 500,
                }}>
                  {msg.text}
                </div>
              </div>
            </motion.div>
          ))}

          {/* You respond label */}
          <div style={{
            marginTop: 16, display: 'flex', alignItems: 'center', gap: 8,
            padding: '8px 0',
          }}>
            <div style={{
              width: 34, height: 34, borderRadius: '50%', flexShrink: 0,
              background: 'linear-gradient(135deg, #065f46, #10b981)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 14,
            }}>
              🧑‍💻
            </div>
            <div style={{ fontSize: 12, color: 'var(--t3)', fontFamily: 'var(--mono)' }}>
              YOU (respond as a Security Impossible team member)
            </div>
          </div>
        </div>

        {/* Response options */}
        <div style={{ padding: '16px 20px' }}>
          <div style={{ fontSize: 12, color: 'var(--t3)', marginBottom: 12, fontFamily: 'var(--mono)' }}>
            HOW DO YOU RESPOND? Select the most appropriate reply:
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 16 }}>
            {SCENARIO.responses.map((response, i) => {
              const isSelected = selectedResponse?.id === response.id;
              let extraClass = '';
              if (revealed && isSelected) extraClass = response.correct ? 'correct' : 'wrong';
              if (revealed && !isSelected) extraClass = 'disabled';

              return (
                <motion.div
                  key={response.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + i * 0.05 }}
                  className={`quiz-option ${extraClass}`}
                  onClick={() => handleSelect(response)}
                  style={{ position: 'relative' }}
                >
                  {/* Option letter */}
                  <div style={{
                    width: 26, height: 26, borderRadius: 6, flexShrink: 0,
                    background: isSelected && !revealed ? 'var(--cyan-dim)' : 'var(--bg-hover)',
                    border: `1px solid ${isSelected && !revealed ? 'var(--cyan)' : 'var(--border)'}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 11, fontWeight: 700, fontFamily: 'var(--mono)',
                    color: isSelected && !revealed ? 'var(--cyan)' : 'var(--t3)',
                    transition: 'all 0.2s',
                  }}>
                    {response.id.toUpperCase()}
                  </div>

                  <span style={{ flex: 1, fontSize: 13.5, lineHeight: 1.5, fontStyle: 'italic' }}>
                    {response.text}
                  </span>

                  {revealed && isSelected && (
                    response.correct
                      ? <CheckCircle2 size={18} color="var(--green)" style={{ flexShrink: 0 }} />
                      : <XCircle size={18} color="var(--red)" style={{ flexShrink: 0 }} />
                  )}
                </motion.div>
              );
            })}
          </div>

          {/* Feedback */}
          <AnimatePresence>
            {revealed && selectedResponse && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                style={{
                  padding: '16px 18px', borderRadius: 12,
                  background: selectedResponse.correct ? 'rgba(34,211,165,.06)' : 'rgba(248,113,113,.06)',
                  border: `1px solid ${selectedResponse.correct ? 'rgba(34,211,165,.25)' : 'rgba(248,113,113,.25)'}`,
                  marginBottom: 14,
                }}
              >
                <div style={{
                  display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8,
                  fontSize: 13, fontWeight: 700,
                  color: selectedResponse.correct ? 'var(--green)' : 'var(--red)',
                }}>
                  {selectedResponse.correct ? <CheckCircle2 size={16} /> : <XCircle size={16} />}
                  {selectedResponse.correct ? 'Correct — well handled' : 'Not the best approach'}
                </div>
                <p style={{ fontSize: 13.5, color: 'var(--t2)', lineHeight: 1.75 }}>
                  {selectedResponse.feedback}
                </p>
                {!selectedResponse.correct && (
                  <button
                    onClick={handleReset}
                    style={{
                      marginTop: 12, padding: '7px 14px', borderRadius: 7,
                      background: 'var(--bg-hover)', border: '1px solid var(--border)',
                      color: 'var(--t2)', fontSize: 13, cursor: 'pointer', fontFamily: 'var(--body)',
                    }}
                  >
                    ↺ Try again
                  </button>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Submit / Next button */}
          {!revealed && (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleReveal}
              disabled={!selectedResponse}
              style={{
                padding: '11px 22px', borderRadius: 9,
                background: selectedResponse ? 'var(--cyan)' : 'var(--bg-hover)',
                border: 'none', cursor: selectedResponse ? 'pointer' : 'not-allowed',
                color: selectedResponse ? '#03060d' : 'var(--t4)',
                fontSize: 14, fontWeight: 700, fontFamily: 'var(--body)',
                display: 'flex', alignItems: 'center', gap: 8,
                transition: 'all 0.2s',
              }}
            >
              Check My Response <ChevronRight size={15} />
            </motion.button>
          )}

          {completed && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              style={{
                padding: '12px 16px', borderRadius: 10,
                background: 'rgba(34,211,165,.08)',
                border: '1px solid rgba(34,211,165,.2)',
                fontSize: 13, color: 'var(--green)',
                display: 'flex', alignItems: 'center', gap: 8,
              }}
            >
              <CheckCircle2 size={16} />
              Scenario complete — progress updated!
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
