import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { HelpCircle, CheckCircle2, XCircle, Award, RotateCcw, ChevronRight, Brain } from 'lucide-react';

const QUESTIONS = [
  {
    id: 1,
    question: "Why is Security Impossible considered a higher-value target for attackers than most organisations?",
    options: [
      "Because the firm has more money than typical companies",
      "Because compromising a security firm gives attackers knowledge of multiple clients' vulnerabilities",
      "Because security firms always have weaker defences due to overconfidence",
      "Because the firm stores more personal data than average businesses"
    ],
    correct: 1,
    explanation: "Security Impossible holds detailed knowledge of our clients' security postures — including their vulnerabilities. An attacker who compromises us gains a roadmap for attacking multiple high-value organisations simultaneously, making us a disproportionately valuable target.",
  },
  {
    id: 2,
    question: "Which of the following best describes what a security incident typically looks like in practice?",
    options: [
      "A sophisticated state-sponsored attack on critical infrastructure",
      "An employee who forwards a client report to their personal email for convenience",
      "A ransomware deployment by a known criminal group",
      "A zero-day exploit used against our internal systems"
    ],
    correct: 1,
    explanation: "The vast majority of security incidents are not dramatic attacks — they are ordinary acts of convenience that bypass security controls. Forwarding files to personal email is one of the most common causes of data incidents, regardless of the employee's intentions.",
  },
  {
    id: 3,
    question: "You are unsure whether a particular action complies with firm security policy. What should you do?",
    options: [
      "Proceed with the action since you are probably overthinking it",
      "Ask a colleague who seems experienced",
      "Ask your manager or the security team before proceeding",
      "Do nothing until the policy is clarified in a future training session"
    ],
    correct: 2,
    explanation: "The cost of asking is low; the cost of assuming and being wrong can be very high. Asking your manager or the security team before acting is always the correct response to uncertainty. The security team welcomes early questions far more than late incidents.",
  },
  {
    id: 4,
    question: "Your confidentiality obligations at Security Impossible apply to:",
    options: [
      "Only information marked CONFIDENTIAL or RESTRICTED",
      "All client information, plus firm information about operations, finances, and personnel",
      "Only information you personally created or collected",
      "Information classified above INTERNAL level only"
    ],
    correct: 1,
    explanation: "Confidentiality obligations apply broadly — to all client information regardless of formal classification, and to firm information including operational details, finances, and personnel matters. Information is confidential by its nature and context, not only when it carries a formal label.",
  },
  {
    id: 5,
    question: "Security culture at Security Impossible is primarily created by:",
    options: [
      "The information security team's policies and monitoring",
      "The daily decisions of every person in the organisation",
      "Regular security awareness training and certifications",
      "Technical controls like firewalls and endpoint security"
    ],
    correct: 1,
    explanation: "Security culture is not created by policy documents or technical controls alone — it is created by the cumulative effect of every individual's daily decisions. When every person exercises good security judgement consistently, that is what a genuine security culture looks like.",
  },
];

function QuizQuestion({ question, index, onAnswer }) {
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);

  function submit() {
    if (selected === null) return;
    setSubmitted(true);
    const correct = selected === question.correct;
    onAnswer(question.id, correct);
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08 }}
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border)',
        borderRadius: 14, padding: '22px 24px',
        marginBottom: 14,
      }}
    >
      <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
        <div style={{
          width: 28, height: 28, borderRadius: 7, flexShrink: 0,
          background: submitted
            ? (selected === question.correct ? 'rgba(34,211,165,.15)' : 'rgba(248,113,113,.15)')
            : 'var(--bg-hover)',
          border: `1px solid ${submitted
            ? (selected === question.correct ? 'rgba(34,211,165,.3)' : 'rgba(248,113,113,.3)')
            : 'var(--border)'}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'var(--mono)', fontSize: 12, fontWeight: 700,
          color: submitted
            ? (selected === question.correct ? 'var(--green)' : 'var(--red)')
            : 'var(--t3)',
          transition: 'all 0.3s',
        }}>
          {submitted
            ? (selected === question.correct ? '✓' : '✗')
            : `Q${question.id}`}
        </div>
        <p style={{ fontSize: 14.5, fontWeight: 600, color: 'var(--t1)', lineHeight: 1.5 }}>
          {question.question}
        </p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: submitted ? 14 : 0 }}>
        {question.options.map((opt, i) => {
          const isSelected = selected === i;
          const isCorrect = i === question.correct;

          let bg = 'var(--bg-card)', borderColor = 'var(--border)', textColor = 'var(--t2)';

          if (!submitted && isSelected) {
            bg = 'var(--cyan-dim)'; borderColor = 'rgba(56,189,248,.35)'; textColor = 'var(--t1)';
          }
          if (submitted && isCorrect) {
            bg = 'var(--green-dim)'; borderColor = 'rgba(34,211,165,.35)'; textColor = 'var(--green)';
          }
          if (submitted && isSelected && !isCorrect) {
            bg = 'var(--red-dim)'; borderColor = 'rgba(248,113,113,.35)'; textColor = 'var(--red)';
          }

          return (
            <motion.div
              key={i}
              whileHover={!submitted ? { x: 4 } : {}}
              onClick={() => !submitted && setSelected(i)}
              style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '11px 14px', borderRadius: 9,
                background: bg, border: `1px solid ${borderColor}`,
                cursor: submitted ? 'default' : 'pointer',
                transition: 'all 0.18s',
              }}
            >
              <div style={{
                width: 22, height: 22, borderRadius: 5, flexShrink: 0,
                background: isSelected && !submitted ? 'var(--cyan)' : submitted && isCorrect ? 'var(--green)' : submitted && isSelected ? 'var(--red)' : 'var(--bg-hover)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 10, fontWeight: 700, fontFamily: 'var(--mono)',
                color: (isSelected && !submitted) || (submitted && (isCorrect || isSelected)) ? '#000' : 'var(--t3)',
              }}>
                {String.fromCharCode(65 + i)}
              </div>
              <span style={{ fontSize: 13.5, color: textColor, lineHeight: 1.45 }}>{opt}</span>
              {submitted && isCorrect && <CheckCircle2 size={15} color="var(--green)" style={{ marginLeft: 'auto', flexShrink: 0 }} />}
              {submitted && isSelected && !isCorrect && <XCircle size={15} color="var(--red)" style={{ marginLeft: 'auto', flexShrink: 0 }} />}
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence>
        {submitted && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            transition={{ duration: 0.3 }}
          >
            <div style={{
              padding: '12px 14px', borderRadius: 9, marginTop: 10,
              background: selected === question.correct ? 'rgba(34,211,165,.06)' : 'rgba(248,113,113,.06)',
              border: `1px solid ${selected === question.correct ? 'rgba(34,211,165,.2)' : 'rgba(248,113,113,.2)'}`,
            }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 5, color: selected === question.correct ? 'var(--green)' : 'var(--red)', fontFamily: 'var(--mono)' }}>
                {selected === question.correct ? '✓ CORRECT' : '✗ INCORRECT'}
              </div>
              <p style={{ fontSize: 13, color: 'var(--t2)', lineHeight: 1.7 }}>{question.explanation}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {!submitted && (
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={submit}
          disabled={selected === null}
          style={{
            marginTop: 12, padding: '9px 18px', borderRadius: 8,
            background: selected !== null ? 'rgba(56,189,248,.12)' : 'var(--bg-hover)',
            border: `1px solid ${selected !== null ? 'rgba(56,189,248,.3)' : 'var(--border)'}`,
            color: selected !== null ? 'var(--cyan)' : 'var(--t4)',
            fontSize: 13, fontWeight: 600, cursor: selected !== null ? 'pointer' : 'not-allowed',
            fontFamily: 'var(--body)', display: 'flex', alignItems: 'center', gap: 6,
            transition: 'all 0.2s',
          }}
        >
          Submit Answer <ChevronRight size={13} />
        </motion.button>
      )}
    </motion.div>
  );
}

export default function QuizSection({ onComplete }) {
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);

  function handleAnswer(qId, correct) {
    setAnswers(prev => {
      const next = { ...prev, [qId]: correct };
      if (Object.keys(next).length === QUESTIONS.length) {
        setTimeout(() => setShowResults(true), 600);
      }
      return next;
    });
  }

  const answeredCount = Object.keys(answers).length;
  const correctCount = Object.values(answers).filter(Boolean).length;
  const allAnswered = answeredCount === QUESTIONS.length;
  const score = allAnswered ? Math.round((correctCount / QUESTIONS.length) * 100) : 0;

  function handleComplete() {
    if (onComplete) onComplete();
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      style={{ maxWidth: 900, margin: '0 auto' }}
    >
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
        <Brain size={16} color="var(--cyan)" />
        <span style={{ fontSize: 17, fontWeight: 700, color: 'var(--t1)', fontFamily: 'var(--display)' }}>
          Knowledge Check
        </span>
        <span className="tag tag-cyan">5 Questions</span>
        {allAnswered && (
          <span className={`tag ${score >= 80 ? 'tag-green' : 'tag-amber'}`}>
            {correctCount}/{QUESTIONS.length} correct
          </span>
        )}
      </div>

      <div style={{ fontSize: 13.5, color: 'var(--t2)', marginBottom: 20, lineHeight: 1.7 }}>
        Answer each question to confirm your understanding of Module 1. You'll get immediate feedback
        with explanations after each answer.
      </div>

      {/* Progress */}
      {answeredCount > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '10px 14px', borderRadius: 9,
            background: 'var(--bg-card)', border: '1px solid var(--border)',
            marginBottom: 16, fontSize: 13,
          }}
        >
          <span style={{ color: 'var(--t3)' }}>Progress:</span>
          <div style={{ flex: 1 }}>
            <div className="progress-track">
              <motion.div
                className="progress-fill"
                animate={{ width: `${(answeredCount / QUESTIONS.length) * 100}%` }}
              />
            </div>
          </div>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--cyan)' }}>
            {answeredCount}/{QUESTIONS.length}
          </span>
        </motion.div>
      )}

      {/* Questions */}
      {QUESTIONS.map((q, i) => (
        <QuizQuestion key={q.id} question={q} index={i} onAnswer={handleAnswer} />
      ))}

      {/* Results */}
      <AnimatePresence>
        {showResults && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            style={{
              padding: '24px 28px', borderRadius: 16,
              background: score >= 80 ? 'rgba(34,211,165,.06)' : 'rgba(251,191,36,.06)',
              border: `1px solid ${score >= 80 ? 'rgba(34,211,165,.25)' : 'rgba(251,191,36,.25)'}`,
              marginTop: 8,
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 14 }}>
              <div style={{ fontSize: 40 }}>{score >= 80 ? '🎉' : '💪'}</div>
              <div>
                <div style={{
                  fontFamily: 'var(--display)', fontSize: 22, fontWeight: 800,
                  color: score >= 80 ? 'var(--green)' : 'var(--amber)',
                  marginBottom: 4,
                }}>
                  {score}% — {score >= 80 ? 'Excellent!' : 'Good effort'}
                </div>
                <div style={{ fontSize: 13.5, color: 'var(--t2)' }}>
                  {score >= 80
                    ? `You answered ${correctCount} of ${QUESTIONS.length} questions correctly. You're ready to proceed.`
                    : `You answered ${correctCount} of ${QUESTIONS.length} correctly. Review the explanations above and consider re-reading Module 1.`
                  }
                </div>
              </div>
            </div>

            {score >= 80 ? (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleComplete}
                style={{
                  padding: '12px 24px', borderRadius: 9,
                  background: 'var(--green)', border: 'none',
                  color: '#03060d', fontSize: 14, fontWeight: 700,
                  cursor: 'pointer', fontFamily: 'var(--body)',
                  display: 'flex', alignItems: 'center', gap: 8,
                }}
              >
                <Award size={16} />
                Complete Module 1
              </motion.button>
            ) : (
              <div style={{ fontSize: 13, color: 'var(--t3)' }}>
                Review the explanations above, then scroll up to re-read the relevant sections before re-attempting.
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
