import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect } from 'react';
import { X, ChevronRight, ChevronLeft, Bot, Lightbulb, AlertCircle, CheckCircle2, Sparkles } from 'lucide-react';

const BYTE_MESSAGES = {
  welcome: {
    icon: '👋',
    title: 'Welcome to Module 1!',
    message: `I'm Byte, your AI learning guide. I'm here to help you through every step of this module.

Module 1 sets the foundation for everything else — it explains why security isn't just a box to check, but a professional obligation central to how Security Impossible operates.

Start by reading the opening content, then work through the key principles. I'll give you hints and context along the way!`,
    type: 'info',
  },
  principles: {
    icon: '🔍',
    title: 'Reading the Key Principles',
    message: `Each of the four principles can be expanded by clicking on them. I recommend reading all four carefully.

**Why it matters:** These principles explain the "why" behind every policy you'll encounter. Understanding the reasoning helps you make the right decision even in situations not covered by the rulebook.

Pro tip: The principle about "high-value targets" is particularly important — it explains why your vigilance here matters more than at most organisations.`,
    type: 'hint',
  },
  scenario: {
    icon: '⚠️',
    title: 'About the Scenario',
    message: `The "Curious Friend" scenario is based on a real pattern we see. Well-intentioned people casually share information with friends they trust — and that's exactly how information leaks happen.

**What to watch for:** The key is that confidentiality applies regardless of:
• How much you trust the person
• Whether the information seems "vague enough"
• Whether the person works in a related field

When in doubt: don't share specific details. You can be warm and professional without disclosing confidential information.`,
    type: 'warning',
  },
  quiz: {
    icon: '🧠',
    title: 'Knowledge Check Tips',
    message: `You're at the knowledge check — great progress!

**My hints for the quiz:**
• Read each question carefully — some are about policy, some about judgement
• Think about the reasoning, not just the rule
• The correct answer isn't always the most obvious one

You need 80% or higher to complete the module. If you don't get there first time, review the explanations — they're as valuable as the questions themselves.

Good luck! 🎯`,
    type: 'success',
  },
  confidentiality: {
    icon: '🔒',
    title: 'Confidentiality Reminder',
    message: `Quick reminder as you work through this module:

**Your confidentiality obligations apply right now.** From the moment you start at Security Impossible, you are bound by confidentiality — not just once you've "officially" completed onboarding.

This includes:
• Not discussing client engagements publicly
• Not sharing firm information with outside parties
• Protecting even incidental information you encounter

If you're unsure whether something is confidential: assume it is, and ask.`,
    type: 'warning',
  },
};

const STEP_MESSAGES = ['welcome', 'principles', 'scenario', 'quiz', 'confidentiality'];

const TYPE_STYLES = {
  info:    { bg: 'rgba(56,189,248,.07)',   border: 'rgba(56,189,248,.2)',   accent: 'var(--cyan)',   label: 'INFO' },
  hint:    { bg: 'rgba(167,139,250,.07)',  border: 'rgba(167,139,250,.2)',  accent: 'var(--purple)', label: 'HINT' },
  warning: { bg: 'rgba(251,191,36,.07)',   border: 'rgba(251,191,36,.2)',   accent: 'var(--amber)',  label: 'NOTE' },
  success: { bg: 'rgba(34,211,165,.07)',   border: 'rgba(34,211,165,.2)',   accent: 'var(--green)',  label: 'TIP' },
};

function formatMessage(text) {
  return text.split('\n').map((line, i) => {
    if (line.startsWith('**') && line.endsWith('**')) {
      return <div key={i} style={{ fontWeight: 700, color: 'var(--t1)', marginTop: 8, marginBottom: 2 }}>{line.slice(2, -2)}</div>;
    }
    if (line.startsWith('• ')) {
      return <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 3 }}>
        <span style={{ color: 'var(--cyan)', flexShrink: 0 }}>•</span>
        <span>{line.slice(2)}</span>
      </div>;
    }
    if (line === '') return <div key={i} style={{ height: 6 }} />;
    return <div key={i}>{line}</div>;
  });
}

export default function ByteAssistant({ currentSection }) {
  const [open, setOpen] = useState(false);
  const [msgIndex, setMsgIndex] = useState(0);
  const [typing, setTyping] = useState(false);
  const [typedMsg, setTypedMsg] = useState('');
  const [showNotification, setShowNotification] = useState(true);

  const currentKey = STEP_MESSAGES[msgIndex];
  const current = BYTE_MESSAGES[currentKey];
  const style = TYPE_STYLES[current.type];

  // Auto-suggest new messages
  useEffect(() => {
    if (!open) {
      setShowNotification(true);
      const t = setTimeout(() => setShowNotification(false), 4000);
      return () => clearTimeout(t);
    }
  }, [msgIndex]);

  function openPanel() {
    setOpen(true);
    setShowNotification(false);
  }

  function next() {
    if (msgIndex < STEP_MESSAGES.length - 1) setMsgIndex(i => i + 1);
  }

  function prev() {
    if (msgIndex > 0) setMsgIndex(i => i - 1);
  }

  return (
    <div style={{
      position: 'fixed', bottom: 28, right: 28, zIndex: 1000,
      display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 12,
    }}>
      {/* Floating notification bubble */}
      <AnimatePresence>
        {!open && showNotification && (
          <motion.div
            initial={{ opacity: 0, x: 20, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 20, scale: 0.9 }}
            transition={{ duration: 0.3 }}
            style={{
              background: 'var(--bg-panel)',
              border: '1px solid var(--border-bright)',
              borderRadius: '12px 12px 4px 12px',
              padding: '10px 14px',
              maxWidth: 220,
              cursor: 'pointer',
              boxShadow: '0 8px 32px rgba(0,0,0,.4)',
            }}
            onClick={openPanel}
          >
            <div style={{ fontSize: 11, color: 'var(--cyan)', fontFamily: 'var(--mono)', marginBottom: 4, letterSpacing: '0.06em' }}>
              BYTE GUIDE
            </div>
            <div style={{ fontSize: 12.5, color: 'var(--t2)', lineHeight: 1.5 }}>
              {current.icon} {current.title}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            className="byte-panel"
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            style={{
              width: 340,
              background: 'var(--bg-panel)',
              border: '1px solid var(--border-bright)',
              borderRadius: 16,
              overflow: 'hidden',
              boxShadow: '0 24px 60px rgba(0,0,0,.6), 0 0 0 1px rgba(56,189,248,.05)',
            }}
          >
            {/* Header */}
            <div style={{
              padding: '14px 16px',
              background: 'rgba(56,189,248,.05)',
              borderBottom: '1px solid var(--border)',
              display: 'flex', alignItems: 'center', gap: 10,
            }}>
              <div style={{
                width: 34, height: 34, borderRadius: '50%',
                background: 'linear-gradient(135deg, #0e2a4a, #1a4a6e)',
                border: '1.5px solid var(--cyan)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 16, flexShrink: 0,
              }}>
                🤖
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--t1)' }}>Byte</div>
                <div style={{ fontSize: 10, color: 'var(--green)', fontFamily: 'var(--mono)', display: 'flex', alignItems: 'center', gap: 4 }}>
                  <motion.div
                    animate={{ opacity: [1, 0.3, 1] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                    style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--green)' }}
                  />
                  AI Learning Assistant
                </div>
              </div>

              {/* Step counter */}
              <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--t3)' }}>
                {msgIndex + 1}/{STEP_MESSAGES.length}
              </div>

              <button
                onClick={() => setOpen(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--t3)', padding: 4, display: 'flex' }}
              >
                <X size={16} />
              </button>
            </div>

            {/* Message type bar */}
            <div style={{
              padding: '6px 16px',
              background: style.bg,
              borderBottom: '1px solid var(--border)',
              display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <span style={{ fontSize: 9, fontFamily: 'var(--mono)', color: style.accent, fontWeight: 700, letterSpacing: '0.1em' }}>
                {style.label}
              </span>
              <span style={{ fontSize: 12, color: style.accent }}>{current.icon} {current.title}</span>
            </div>

            {/* Progress dots */}
            <div style={{ display: 'flex', gap: 5, padding: '10px 16px 0', justifyContent: 'center' }}>
              {STEP_MESSAGES.map((_, i) => (
                <motion.div
                  key={i}
                  animate={{ scale: i === msgIndex ? 1.3 : 1 }}
                  style={{
                    width: 6, height: 6, borderRadius: '50%',
                    background: i <= msgIndex ? 'var(--cyan)' : 'var(--border)',
                    cursor: 'pointer',
                    transition: 'background 0.2s',
                  }}
                  onClick={() => setMsgIndex(i)}
                />
              ))}
            </div>

            {/* Content */}
            <div style={{
              padding: '14px 16px',
              maxHeight: 280, overflowY: 'auto',
              fontSize: 13, color: 'var(--t2)', lineHeight: 1.75,
            }}>
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentKey}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  transition={{ duration: 0.25 }}
                >
                  {formatMessage(current.message)}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Navigation */}
            <div style={{
              padding: '12px 16px',
              borderTop: '1px solid var(--border)',
              display: 'flex', gap: 8, justifyContent: 'space-between',
            }}>
              <button
                onClick={prev}
                disabled={msgIndex === 0}
                style={{
                  padding: '7px 14px', borderRadius: 7,
                  background: 'var(--bg-card)', border: '1px solid var(--border)',
                  color: msgIndex === 0 ? 'var(--t4)' : 'var(--t2)',
                  fontSize: 12, cursor: msgIndex === 0 ? 'not-allowed' : 'pointer',
                  display: 'flex', alignItems: 'center', gap: 5, fontFamily: 'var(--body)',
                }}
              >
                <ChevronLeft size={13} /> Back
              </button>

              <button
                onClick={next}
                disabled={msgIndex === STEP_MESSAGES.length - 1}
                style={{
                  padding: '7px 16px', borderRadius: 7,
                  background: msgIndex < STEP_MESSAGES.length - 1 ? 'rgba(56,189,248,.12)' : 'var(--bg-card)',
                  border: `1px solid ${msgIndex < STEP_MESSAGES.length - 1 ? 'rgba(56,189,248,.3)' : 'var(--border)'}`,
                  color: msgIndex < STEP_MESSAGES.length - 1 ? 'var(--cyan)' : 'var(--t4)',
                  fontSize: 12, cursor: msgIndex < STEP_MESSAGES.length - 1 ? 'pointer' : 'not-allowed',
                  display: 'flex', alignItems: 'center', gap: 5, fontFamily: 'var(--body)', fontWeight: 600,
                }}
              >
                Next <ChevronRight size={13} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Byte button */}
      <motion.button
        className="byte-btn"
        onClick={() => open ? setOpen(false) : openPanel()}
        whileTap={{ scale: 0.9 }}
        title="Byte — AI Learning Assistant"
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <X size={22} color="var(--cyan)" />
            </motion.div>
          ) : (
            <motion.div key="open" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
              🤖
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>
    </div>
  );
}
