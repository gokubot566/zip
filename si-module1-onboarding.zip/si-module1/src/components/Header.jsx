import { motion } from 'framer-motion';
import { Shield, Bell, ChevronRight, Clock, Wifi, Menu } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function Header({ progress, sidebarOpen, setSidebarOpen }) {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const timeStr = time.toLocaleTimeString('en-AU', {
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });

  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 100,
      height: 'var(--header-h)',
      background: 'rgba(6,12,24,0.95)',
      backdropFilter: 'blur(24px)',
      borderBottom: '1px solid var(--border)',
      display: 'flex', alignItems: 'center',
      flexShrink: 0,
    }}>
      {/* Logo zone */}
      <div style={{
        width: sidebarOpen ? 'var(--sidebar-w)' : 72,
        display: 'flex', alignItems: 'center',
        padding: '0 16px',
        borderRight: '1px solid var(--border)',
        height: '100%', gap: 10,
        transition: 'width 0.3s ease',
        overflow: 'hidden', flexShrink: 0,
      }}>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => setSidebarOpen(!sidebarOpen)}
          style={{
            background: 'none', border: 'none', cursor: 'pointer',
            color: 'var(--cyan)', display: 'flex', alignItems: 'center',
            flexShrink: 0,
          }}
        >
          <Shield size={26} strokeWidth={1.5} />
        </motion.button>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            style={{ minWidth: 0 }}
          >
            <div style={{ fontFamily: 'var(--display)', fontWeight: 800, fontSize: 12.5, color: 'var(--t1)', lineHeight: 1.2, whiteSpace: 'nowrap' }}>
              Security Impossible
            </div>
            <div style={{ fontSize: 9.5, color: 'var(--t3)', fontFamily: 'var(--mono)', letterSpacing: '0.1em', whiteSpace: 'nowrap' }}>
              ONBOARDING PORTAL
            </div>
          </motion.div>
        )}
      </div>

      {/* Breadcrumb */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 6, padding: '0 20px' }}>
        <span style={{ fontSize: 12, color: 'var(--t4)' }}>Onboarding</span>
        <ChevronRight size={11} color="var(--t4)" />
        <span style={{ fontSize: 12, color: 'var(--t3)' }}>Module 1</span>
        <ChevronRight size={11} color="var(--t4)" />
        <span style={{ fontSize: 12, color: 'var(--cyan)', fontWeight: 500 }}>
          Welcome & Why Security Matters
        </span>
      </div>

      {/* Right controls */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 20px', flexShrink: 0 }}>
        {/* Live indicator */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <motion.div
            animate={{ opacity: [1, 0.3, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--green)' }}
          />
          <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--t3)' }}>{timeStr}</span>
        </div>

        {/* Progress */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: 'var(--bg-card)', border: '1px solid var(--border)',
          borderRadius: 20, padding: '4px 12px',
        }}>
          <Clock size={11} color="var(--amber)" />
          <span style={{ fontSize: 11, color: 'var(--t2)', fontFamily: 'var(--mono)' }}>
            {Math.round(progress)}%
          </span>
          <div style={{ width: 60 }}>
            <div className="progress-track">
              <motion.div
                className="progress-fill"
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.8 }}
              />
            </div>
          </div>
        </div>

        <motion.button whileTap={{ scale: 0.9 }} style={{
          background: 'var(--bg-card)', border: '1px solid var(--border)',
          borderRadius: 8, padding: '6px', cursor: 'pointer', color: 'var(--t3)',
          display: 'flex',
        }}>
          <Bell size={15} />
        </motion.button>
      </div>
    </header>
  );
}
