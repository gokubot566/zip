import { motion } from 'framer-motion';
import { Shield, ExternalLink, ChevronRight } from 'lucide-react';

export default function Footer({ onComplete, moduleComplete }) {
  return (
    <footer style={{
      borderTop: '1px solid var(--border)',
      background: 'rgba(6,12,24,0.9)',
      backdropFilter: 'blur(12px)',
      padding: '16px 24px',
      display: 'flex', alignItems: 'center', gap: 16,
      flexShrink: 0,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <Shield size={14} color="var(--t4)" />
        <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--t4)' }}>
          SI-ONBOARD-MODULE-01
        </span>
      </div>

      <div style={{ height: 14, width: 1, background: 'var(--border)' }} />

      <span style={{ fontSize: 12, color: 'var(--t4)' }}>
        © 2025 Security Impossible Pty Ltd
      </span>

      <div style={{ flex: 1 }} />

      <span style={{ fontSize: 12, color: 'var(--t3)' }}>
        security@securityimpossible.com.au
      </span>

      {moduleComplete && (
        <motion.div
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
          style={{ display: 'flex', alignItems: 'center', gap: 8 }}
        >
          <div style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '6px 14px', borderRadius: 20,
            background: 'rgba(34,211,165,.1)',
            border: '1px solid rgba(34,211,165,.25)',
            fontSize: 12, color: 'var(--green)', fontWeight: 600,
          }}>
            ✓ Module 1 Complete — Proceed to Module 2
          </div>
          <motion.div
            animate={{ x: [0, 4, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <ChevronRight size={16} color="var(--green)" />
          </motion.div>
        </motion.div>
      )}
    </footer>
  );
}
