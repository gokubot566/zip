import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BookOpen, Layers, HelpCircle, MessageCircle, CheckCircle2 } from 'lucide-react';
import Header from './components/Header.jsx';
import Sidebar from './components/Sidebar.jsx';
import WelcomeSection from './components/WelcomeSection.jsx';
import ScenarioCard from './components/ScenarioCard.jsx';
import QuizSection from './components/QuizSection.jsx';
import ByteAssistant from './components/ByteAssistant.jsx';
import Footer from './components/Footer.jsx';

const TABS = [
  { id: 'intro',    label: 'Introduction',    icon: BookOpen,      desc: 'Core concepts and principles' },
  { id: 'scenario', label: 'Scenario',         icon: MessageCircle, desc: 'Real-world situation practice' },
  { id: 'quiz',     label: 'Knowledge Check',  icon: HelpCircle,    desc: '5 questions with instant feedback' },
];

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab]     = useState('intro');
  const [progress, setProgress]       = useState(0);
  const [tabProgress, setTabProgress] = useState({ intro: 0, scenario: 0, quiz: 0 });
  const [moduleComplete, setModuleComplete] = useState(false);

  function updateTabProgress(tab, pct) {
    setTabProgress(prev => {
      const next = { ...prev, [tab]: Math.max(prev[tab], pct) };
      const vals = Object.values(next);
      const total = Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
      setProgress(total);
      return next;
    });
  }

  function switchTab(id) {
    setActiveTab(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden', position: 'relative' }}>
      <div className="grid-bg" />
      <div className="noise-overlay" />
      <div className="orb orb-1" />
      <div className="orb orb-2" />
      <div className="scanline" />

      <Header progress={progress} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden', position: 'relative', zIndex: 10 }}>
        <Sidebar open={sidebarOpen} />

        <main style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>
          {/* Tabs */}
          <div style={{
            borderBottom: '1px solid var(--border)',
            background: 'rgba(6,12,24,0.85)',
            backdropFilter: 'blur(16px)',
            padding: '0 28px',
            display: 'flex',
            position: 'sticky', top: 0, zIndex: 50,
          }}>
            {TABS.map(tab => {
              const Icon = tab.icon;
              const tp = tabProgress[tab.id];
              const isActive = activeTab === tab.id;
              return (
                <button key={tab.id} onClick={() => switchTab(tab.id)} style={{
                  padding: '14px 18px', border: 'none', background: 'none', cursor: 'pointer',
                  color: isActive ? 'var(--cyan)' : 'var(--t3)',
                  borderBottom: `2px solid ${isActive ? 'var(--cyan)' : 'transparent'}`,
                  fontSize: 13, fontWeight: isActive ? 600 : 400,
                  display: 'flex', alignItems: 'center', gap: 7,
                  transition: 'all 0.2s', fontFamily: 'var(--body)',
                }}>
                  <Icon size={14} />
                  {tab.label}
                  {tp === 100 && (
                    <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                      <CheckCircle2 size={12} color="var(--green)" />
                    </motion.div>
                  )}
                </button>
              );
            })}
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
              <span style={{ fontSize: 11, color: 'var(--t4)', fontFamily: 'var(--mono)' }}>
                {TABS.find(t => t.id === activeTab)?.desc}
              </span>
            </div>
          </div>

          {/* Content */}
          <div style={{ flex: 1, padding: '28px 24px 40px' }}>
            <AnimatePresence mode="wait">
              {activeTab === 'intro' && (
                <motion.div key="intro"
                  initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.3 }}>
                  <WelcomeSection onProgress={(pct) => updateTabProgress('intro', pct)} />
                  <div style={{ maxWidth: 900, margin: '28px auto 0', textAlign: 'right' }}>
                    <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                      onClick={() => switchTab('scenario')}
                      style={{
                        padding: '12px 24px', borderRadius: 10, background: 'var(--cyan)',
                        border: 'none', color: '#03060d', fontSize: 14, fontWeight: 700,
                        cursor: 'pointer', fontFamily: 'var(--body)',
                        display: 'inline-flex', alignItems: 'center', gap: 8,
                      }}>
                      Continue to Scenario <Layers size={15} />
                    </motion.button>
                  </div>
                </motion.div>
              )}

              {activeTab === 'scenario' && (
                <motion.div key="scenario"
                  initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.3 }}>
                  <ScenarioCard onComplete={() => updateTabProgress('scenario', 100)} />
                  {tabProgress.scenario === 100 && (
                    <div style={{ maxWidth: 900, margin: '20px auto 0', textAlign: 'right' }}>
                      <motion.button initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                        whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                        onClick={() => switchTab('quiz')}
                        style={{
                          padding: '12px 24px', borderRadius: 10, background: 'var(--cyan)',
                          border: 'none', color: '#03060d', fontSize: 14, fontWeight: 700,
                          cursor: 'pointer', fontFamily: 'var(--body)',
                          display: 'inline-flex', alignItems: 'center', gap: 8,
                        }}>
                        Proceed to Knowledge Check <HelpCircle size={15} />
                      </motion.button>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'quiz' && (
                <motion.div key="quiz"
                  initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.3 }}>
                  <QuizSection onComplete={() => {
                    updateTabProgress('quiz', 100);
                    setModuleComplete(true);
                    setProgress(100);
                  }} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <Footer moduleComplete={moduleComplete} />
        </main>
      </div>

      <ByteAssistant currentSection={activeTab} />
    </div>
  );
}
