# Security Impossible — Onboarding & Governance Training Portal

A modern, dark-themed cybersecurity onboarding platform for Security Impossible Pty Ltd.
Covers mandatory security governance training across 11 modules for new employees, contractors, and interns.

---

## 📋 Module Overview

| Container | Port | Module |
|-----------|------|--------|
| `si-onboarding-dashboard` | **8080** | Main Dashboard — all modules, progress overview |
| `si-module-01-welcome` | **8081** | Welcome & Why Security Matters Here |
| `si-module-02-confidentiality` | **8082** | Confidentiality & Your Obligations |
| `si-module-03-ip` | **8083** | Intellectual Property & Ownership |
| `si-module-04-privacy` | **8084** | Privacy & Australian Privacy Principles |
| `si-module-05-data` | **8085** | Data Classification & Handling |
| `si-module-06-assets` | **8086** | Asset Management & Secure Workplace Practices |
| `si-module-07-threats` | **8087** | Recognising & Responding to Threats |
| `si-module-08-acceptable-use` | **8088** | Acceptable Use & AI Tools |
| `si-module-09-social` | **8089** | Social Media & Public Conduct |
| `si-module-10-clients` | **8090** | Working with Clients & Third Parties |
| `si-module-11-commitment` | **8091** | Putting It Together & Your Commitment |

---

## 🚀 Deployment

### Option A: Full deployment (all 12 containers)

```bash
# Build and start all containers
docker compose up -d --build

# Check status
docker compose ps

# View logs
docker compose logs -f

# Stop everything
docker compose down
```

### Option B: Main dashboard only (recommended for most use cases)

The main dashboard at port 8080 contains ALL 11 modules in a single container.
Individual module containers (8081–8091) are available for isolated module hosting.

```bash
# Build and run dashboard only
docker build -t si-onboarding .
docker run -d --name si-dashboard -p 8080:8080 --restart unless-stopped si-onboarding

# Access at: http://localhost:8080
```

### Option C: Single module container

```bash
# Example: Module 1 only
docker build -t si-module-01 -f Dockerfile.module8081 .
docker run -d --name si-module-01 -p 8081:8081 --restart unless-stopped si-module-01
# Access at: http://localhost:8081
```

---

## 🌐 Azure / Cloud Deployment

### Firewall rules required

Open the following inbound TCP ports in your Azure Network Security Group:

```
8080 — Main Dashboard
8081–8091 — Individual module containers (if deploying separately)
```

### Access URLs (replace with your public IP)

```
http://<YOUR-PUBLIC-IP>:8080   — Main Dashboard
http://<YOUR-PUBLIC-IP>:8081   — Module 1
http://<YOUR-PUBLIC-IP>:8082   — Module 2
... etc.
```

---

## 💻 Local Development

```bash
# Install dependencies
npm install

# Start dev server (port 3000)
npm run dev

# Build production
npm run build

# Preview production build
npm run preview
```

---

## 📁 Project Structure

```
si-onboarding/
├── src/
│   ├── App.jsx                    # Root component, routing state, localStorage
│   ├── index.css                  # Global CSS variables and utilities
│   ├── main.jsx                   # React entry point
│   ├── data/
│   │   └── modules.js             # All 11 modules with full content
│   └── components/
│       ├── Sidebar.jsx            # Navigation sidebar with progress indicators
│       ├── Dashboard.jsx          # Home page with module grid
│       ├── ModulePage.jsx         # Module viewer (handles all 11 modules)
│       └── CommitmentPage.jsx     # Final commitment and certificate page
├── docker/
│   └── nginx.conf                 # Nginx server config template
├── Dockerfile                     # Main dashboard (port 8080)
├── Dockerfile.module808X          # Per-module Dockerfiles (ports 8081–8091)
├── docker-compose.yml             # Full orchestration config
├── package.json
├── vite.config.js
└── index.html
```

---

## ✨ Features

- **11 complete training modules** with full policy-grade content
- **Progress tracking** via localStorage — survives page refreshes
- **Expandable content sections** — all sections open by default, collapsible
- **Workplace scenarios** with reveal-on-demand correct responses
- **Dual acknowledgement checkboxes** per module before completion
- **Final commitment page** with typed name signature and completion record
- **Responsive sidebar** with visual progress indicators
- **Dark cybersecurity theme** with colour-coded modules
- **Zero backend** — fully static, no authentication, no database
- **Auto-restart** containers via `unless-stopped` policy

---

## 🎯 Completion Flow

1. Employee opens dashboard at port 8080
2. Reads each module (expandable sections, workplace scenarios)
3. Checks both acknowledgement boxes per module
4. Clicks "Mark Module as Complete"
5. After all 11 modules: Final Commitment page unlocks
6. Employee enters full name and checks 3 commitment statements
7. Clicks "I Confirm My Commitment"
8. Completion certificate displayed — employee forwards to HR/manager

---

## 📞 Support

For training platform issues: it@securityimpossible.com.au
For policy questions: security@securityimpossible.com.au
