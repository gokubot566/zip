import { useState } from 'react';
import { MODULES, CONTACTS } from '../data/modules.js';

export default function CommitmentPage({ progress, onNavigate }) {
  const [checked1, setChecked1] = useState(false);
  const [checked2, setChecked2] = useState(false);
  const [checked3, setChecked3] = useState(false);
  const [committed, setCommitted] = useState(false);
  const [name, setName] = useState('');

  const totalCompleted = Object.values(progress).filter(v => v === 'complete').length;
  const canCommit = checked1 && checked2 && checked3 && name.trim().length > 2;
  const completionDate = new Date().toLocaleDateString('en-AU', {
    day: 'numeric', month: 'long', year: 'numeric'
  });

  if (committed) {
    return (
      <div style={{ maxWidth: 780, margin: '0 auto', padding: '48px 28px', textAlign: 'center' }}>
        {/* Celebration */}
        <div className="fade-up" style={{
          background: 'linear-gradient(135deg, rgba(16,185,129,.12) 0%, rgba(16,185,129,.04) 100%)',
          border: '1px solid rgba(16,185,129,.3)',
          borderRadius: 20, padding: '52px 48px', marginBottom: 32,
        }}>
          <div style={{ fontSize: 64, marginBottom: 20 }}>🎉</div>
          <h1 style={{
            fontFamily: 'var(--display)', fontWeight: 800, fontSize: 32,
            color: 'var(--green2)', marginBottom: 12,
          }}>
            Training Complete
          </h1>
          <p style={{ fontSize: 16, color: 'var(--t2)', lineHeight: 1.7, maxWidth: 480, margin: '0 auto 24px' }}>
            Congratulations, <strong style={{ color: 'var(--t1)' }}>{name}</strong>. You have completed
            all {MODULES.length} modules of the Security Impossible onboarding program and made your
            formal commitment.
          </p>

          {/* Certificate-style record */}
          <div style={{
            background: 'rgba(0,0,0,.3)', border: '1px solid rgba(16,185,129,.2)',
            borderRadius: 12, padding: '24px 28px', textAlign: 'left',
            maxWidth: 480, margin: '0 auto',
            fontFamily: 'var(--mono)', fontSize: 12, lineHeight: 2, color: 'var(--t2)',
          }}>
            <div><span style={{ color: 'var(--t3)' }}>PARTICIPANT:</span> {name}</div>
            <div><span style={{ color: 'var(--t3)' }}>PROGRAM:</span> Security & Governance Onboarding</div>
            <div><span style={{ color: 'var(--t3)' }}>MODULES:</span> {MODULES.length} / {MODULES.length} complete</div>
            <div><span style={{ color: 'var(--t3)' }}>DATE:</span> {completionDate}</div>
            <div><span style={{ color: 'var(--t3)' }}>STATUS:</span> <span style={{ color: 'var(--green2)' }}>✓ COMMITTED</span></div>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 24 }}>
          <div style={{
            background: 'var(--surface)', border: '1px solid var(--border)',
            borderRadius: 12, padding: '18px 20px', textAlign: 'left',
          }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--t1)', marginBottom: 6 }}>
              📩 What Happens Next
            </div>
            <p style={{ fontSize: 12.5, color: 'var(--t2)', lineHeight: 1.7 }}>
              A record of your completion has been saved in this browser. Forward this confirmation
              to your manager or HR contact to finalise your onboarding.
            </p>
          </div>
          <div style={{
            background: 'var(--surface)', border: '1px solid var(--border)',
            borderRadius: 12, padding: '18px 20px', textAlign: 'left',
          }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--t1)', marginBottom: 6 }}>
              🔄 Annual Renewal
            </div>
            <p style={{ fontSize: 12.5, color: 'var(--t2)', lineHeight: 1.7 }}>
              This training should be completed annually or when policies are updated.
              You will be notified when refresher training is due.
            </p>
          </div>
        </div>

        <button className="btn btn-ghost" onClick={() => onNavigate('dashboard')}>
          ← Return to Dashboard
        </button>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 780, margin: '0 auto', padding: '40px 28px' }}>
      {/* Header */}
      <div className="fade-up" style={{
        background: 'linear-gradient(135deg, rgba(16,185,129,.08) 0%, rgba(0,0,0,0) 60%), var(--surface)',
        border: '1px solid rgba(16,185,129,.2)',
        borderRadius: 16, padding: '32px 36px', marginBottom: 28,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          <span className="badge badge-green">FINAL STEP</span>
        </div>
        <h1 style={{ fontFamily: 'var(--display)', fontWeight: 800, fontSize: 28, color: 'var(--t1)', marginBottom: 10 }}>
          🎯 Your Commitment
        </h1>
        <p style={{ color: 'var(--t2)', fontSize: 14, lineHeight: 1.7 }}>
          You have completed all {MODULES.length} modules of the Security Impossible onboarding program.
          This final step asks you to confirm your understanding and formally commit to upholding our
          security standards.
        </p>
      </div>

      {/* Summary of modules */}
      <div className="fade-up fade-up-1" style={{ marginBottom: 28 }}>
        <h2 style={{ fontFamily: 'var(--display)', fontSize: 16, fontWeight: 700, marginBottom: 14, color: 'var(--t1)' }}>
          Modules You Have Completed
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 8 }}>
          {MODULES.map(mod => (
            <div key={mod.id} style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '8px 12px', borderRadius: 8,
              background: 'var(--surface)', border: '1px solid rgba(16,185,129,.2)',
              fontSize: 12, color: 'var(--t2)',
            }}>
              <span style={{ color: 'var(--green2)', flexShrink: 0 }}>✓</span>
              <span>{mod.icon} {mod.title.length > 24 ? mod.title.substring(0, 24) + '…' : mod.title}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Summary content */}
      <div className="fade-up fade-up-2 card" style={{ marginBottom: 28 }}>
        <h2 style={{ fontFamily: 'var(--display)', fontSize: 16, fontWeight: 700, marginBottom: 14, color: 'var(--t1)' }}>
          Key Principles You Are Committing To
        </h2>
        {[
          { icon: '🔒', title: 'Protect confidential information', body: 'You will handle firm and client confidential information in accordance with your obligations, using approved systems and channels, and not disclosing it to unauthorised parties.' },
          { icon: '⚖️', title: 'Respect intellectual property', body: 'You will respect the firm\'s intellectual property and that of third parties, and understand that work created in the course of your employment is owned by the firm.' },
          { icon: '🔐', title: 'Handle personal information lawfully', body: 'You will comply with the Australian Privacy Principles when collecting, using, or disclosing personal information, and report potential data breaches promptly.' },
          { icon: '📊', title: 'Apply appropriate data classification', body: 'You will classify information correctly, apply appropriate handling controls, and store information in approved systems.' },
          { icon: '⚠️', title: 'Report threats and incidents', body: 'You will report security incidents, suspected phishing, and social engineering attempts promptly, and not attempt to investigate or resolve serious incidents independently.' },
          { icon: '🤖', title: 'Use AI and technology responsibly', body: 'You will not submit confidential or client information to unapproved AI tools, and will use technology in accordance with acceptable use policies.' },
          { icon: '📱', title: 'Maintain professional conduct', body: 'You will maintain appropriate conduct in public settings and on social media, and will not share confidential information through public channels.' },
          { icon: '🤝', title: 'Act with integrity in client relationships', body: 'You will represent the firm professionally in all client interactions, stay within authorised scope, and not make commitments outside your authority.' },
        ].map((item, i) => (
          <div key={i} style={{ display: 'flex', gap: 12, marginBottom: 14 }}>
            <span style={{ fontSize: 20, flexShrink: 0, marginTop: 1 }}>{item.icon}</span>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--t1)', marginBottom: 3 }}>{item.title}</div>
              <div style={{ fontSize: 13, color: 'var(--t2)', lineHeight: 1.6 }}>{item.body}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Commitment form */}
      <div className="fade-up fade-up-3 card" style={{ marginBottom: 24 }}>
        <h2 style={{ fontFamily: 'var(--display)', fontSize: 16, fontWeight: 700, marginBottom: 6, color: 'var(--t1)' }}>
          I Understand My Responsibilities
        </h2>
        <p style={{ fontSize: 13, color: 'var(--t3)', marginBottom: 20 }}>
          Please read each statement carefully before checking the box.
        </p>

        {[
          { state: checked1, setState: setChecked1, text: 'I have read and understood all 11 modules of the Security Impossible Security & Governance Onboarding Program, including all policy references, reading material, and workplace scenarios.' },
          { state: checked2, setState: setChecked2, text: 'I understand that my obligations regarding confidentiality, privacy, intellectual property, data handling, acceptable use, and professional conduct are legally binding and form part of my conditions of engagement.' },
          { state: checked3, setState: setChecked3, text: 'I commit to upholding these obligations in my day-to-day work, to seek guidance when I am uncertain, and to report concerns or incidents promptly rather than ignoring them.' },
        ].map((item, i) => (
          <label key={i} style={{
            display: 'flex', alignItems: 'flex-start', gap: 12,
            cursor: 'pointer', marginBottom: 16, padding: '12px 14px',
            background: item.state ? 'rgba(16,185,129,.06)' : 'var(--surface2)',
            border: `1px solid ${item.state ? 'rgba(16,185,129,.2)' : 'var(--border)'}`,
            borderRadius: 8, transition: 'all 0.2s',
          }}>
            <input
              type="checkbox"
              checked={item.state}
              onChange={e => item.setState(e.target.checked)}
              style={{ marginTop: 3, width: 16, height: 16, flexShrink: 0, accentColor: '#10b981' }}
            />
            <span style={{ fontSize: 13.5, color: 'var(--t2)', lineHeight: 1.65 }}>
              {item.text}
            </span>
          </label>
        ))}

        {/* Name field */}
        <div style={{ marginTop: 4 }}>
          <label style={{ display: 'block', fontSize: 12, fontFamily: 'var(--mono)', color: 'var(--t3)', marginBottom: 8, letterSpacing: '0.06em' }}>
            YOUR FULL NAME (typed signature)
          </label>
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="Enter your full name..."
            style={{
              width: '100%', padding: '11px 14px',
              background: 'var(--surface2)', border: '1px solid var(--border2)',
              borderRadius: 8, color: 'var(--t1)', fontSize: 14,
              fontFamily: 'var(--body)', outline: 'none',
              transition: 'border-color 0.15s',
            }}
            onFocus={e => e.target.style.borderColor = '#10b981'}
            onBlur={e => e.target.style.borderColor = 'var(--border2)'}
          />
        </div>

        <div style={{ marginTop: 20, display: 'flex', gap: 12, alignItems: 'center' }}>
          <button
            className="btn btn-success"
            disabled={!canCommit}
            onClick={() => setCommitted(true)}
            style={{ fontSize: 14 }}
          >
            ✓ I Confirm My Commitment
          </button>
          {!canCommit && (
            <span style={{ fontSize: 12, color: 'var(--t3)' }}>
              Complete all checkboxes and enter your name to continue.
            </span>
          )}
        </div>
      </div>

      {/* Key contacts */}
      <div className="fade-up card">
        <h3 style={{ fontFamily: 'var(--display)', fontSize: 14, fontWeight: 700, marginBottom: 14, color: 'var(--t1)' }}>
          Key Contacts
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {CONTACTS.map((c, i) => (
            <div key={i} style={{
              padding: '10px 12px', borderRadius: 8,
              background: 'var(--surface2)', border: '1px solid var(--border)',
            }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--t1)', marginBottom: 2 }}>{c.role}</div>
              <div style={{ fontSize: 11, color: 'var(--accent2)', fontFamily: 'var(--mono)', marginBottom: 3 }}>{c.email}</div>
              <div style={{ fontSize: 11, color: 'var(--t3)' }}>{c.purpose}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
