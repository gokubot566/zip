import { useState, useEffect } from 'react';
import { MODULES } from '../data/modules.js';

function Section({ heading, body, index }) {
  const [expanded, setExpanded] = useState(true);

  return (
    <div className="fade-up" style={{
      animationDelay: `${index * 0.06}s`,
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 12, marginBottom: 16, overflow: 'hidden',
    }}>
      <button
        onClick={() => setExpanded(!expanded)}
        style={{
          width: '100%', textAlign: 'left',
          padding: '16px 20px', border: 'none', cursor: 'pointer',
          background: 'transparent',
          display: 'flex', alignItems: 'center', gap: 12,
        }}
      >
        <div style={{
          width: 28, height: 28, borderRadius: 6, flexShrink: 0,
          background: 'var(--surface3)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'var(--mono)', fontSize: 11, fontWeight: 700, color: 'var(--accent2)',
        }}>
          {String(index + 1).padStart(2, '0')}
        </div>
        <span style={{ fontFamily: 'var(--display)', fontSize: 16, fontWeight: 700, color: 'var(--t1)', flex: 1 }}>
          {heading}
        </span>
        <span style={{ color: 'var(--t3)', fontSize: 18, transition: 'transform 0.2s', transform: expanded ? 'rotate(180deg)' : 'rotate(0deg)' }}>
          ⌃
        </span>
      </button>

      {expanded && (
        <div style={{ padding: '0 20px 20px' }}>
          <div style={{ height: 1, background: 'var(--border)', marginBottom: 16 }} />
          {body.split('\n\n').map((para, i) => (
            <p key={i} style={{
              color: 'var(--t2)', fontSize: 14, lineHeight: 1.85,
              marginBottom: i < body.split('\n\n').length - 1 ? 14 : 0,
            }}>
              {para}
            </p>
          ))}
        </div>
      )}
    </div>
  );
}

function ScenarioCard({ scenario, index }) {
  const [showOutcome, setShowOutcome] = useState(false);

  return (
    <div className="fade-up" style={{
      animationDelay: `${index * 0.08}s`,
      border: '1px solid var(--border2)',
      borderRadius: 12, overflow: 'hidden', marginBottom: 14,
    }}>
      {/* Header */}
      <div style={{
        padding: '12px 18px',
        background: 'rgba(245,158,11,.07)',
        borderBottom: '1px solid rgba(245,158,11,.15)',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <span style={{ fontSize: 16 }}>⚠️</span>
        <div>
          <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--amber)', marginBottom: 1, letterSpacing: '0.08em' }}>
            WORKPLACE SCENARIO
          </div>
          <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--t1)' }}>{scenario.title}</div>
        </div>
      </div>

      {/* Situation */}
      <div style={{ padding: '16px 18px', background: 'var(--surface2)' }}>
        <div style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--t3)', marginBottom: 8, letterSpacing: '0.06em' }}>
          THE SITUATION
        </div>
        <p style={{ fontSize: 13.5, color: 'var(--t2)', lineHeight: 1.75 }}>
          {scenario.situation}
        </p>
      </div>

      {/* What should happen */}
      <div style={{ padding: '0 18px 16px', background: 'var(--surface2)' }}>
        {!showOutcome ? (
          <button
            className="btn btn-ghost"
            style={{ fontSize: 12, padding: '7px 16px', marginTop: 8 }}
            onClick={() => setShowOutcome(true)}
          >
            Show correct response →
          </button>
        ) : (
          <div style={{
            marginTop: 12, padding: '14px 16px',
            background: 'rgba(16,185,129,.06)',
            border: '1px solid rgba(16,185,129,.2)',
            borderRadius: 8,
          }}>
            <div style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--green2)', marginBottom: 8, letterSpacing: '0.06em' }}>
              ✓ WHAT SHOULD HAPPEN
            </div>
            <p style={{ fontSize: 13.5, color: 'var(--t2)', lineHeight: 1.75 }}>
              {scenario.outcome}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ModulePage({ module, progress, onComplete, onNavigate }) {
  const [acknowledged, setAcknowledged] = useState(false);
  const [policyAcked, setPolicyAcked] = useState(false);
  const [showComplete, setShowComplete] = useState(false);

  const isComplete = progress[module.id] === 'complete';
  const moduleIndex = MODULES.findIndex(m => m.id === module.id);
  const nextModule = MODULES[moduleIndex + 1];
  const prevModule = MODULES[moduleIndex - 1];

  useEffect(() => {
    setAcknowledged(false);
    setPolicyAcked(false);
    setShowComplete(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [module.id]);

  function handleComplete() {
    onComplete(module.id);
    setShowComplete(true);
    setTimeout(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 300);
  }

  return (
    <div style={{ maxWidth: 860, margin: '0 auto', padding: '32px 28px' }}>
      {/* Module header */}
      <div className="fade-up" style={{
        background: `linear-gradient(135deg, rgba(${hexToRgb(module.color)}, 0.1) 0%, rgba(0,0,0,0) 70%), var(--surface)`,
        border: `1px solid rgba(${hexToRgb(module.color)}, 0.25)`,
        borderRadius: 16, padding: '32px 36px', marginBottom: 28,
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', right: 32, top: '50%', transform: 'translateY(-50%)',
          fontSize: 80, opacity: 0.06, pointerEvents: 'none',
        }}>
          {module.icon}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          <span className="badge badge-gray" style={{ fontFamily: 'var(--mono)' }}>
            MODULE {module.id}
          </span>
          <span className="badge badge-gray">⏱ {module.duration}</span>
          {isComplete && <span className="badge badge-green">✓ COMPLETE</span>}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 8 }}>
          <span style={{ fontSize: 32 }}>{module.icon}</span>
          <h1 style={{
            fontFamily: 'var(--display)', fontWeight: 800,
            fontSize: 26, color: 'var(--t1)', lineHeight: 1.2,
          }}>
            {module.title}
          </h1>
        </div>
        <p style={{ color: 'var(--t2)', fontSize: 14, marginBottom: 0 }}>
          {module.subtitle}
        </p>
      </div>

      {/* Completion banner */}
      {(isComplete || showComplete) && (
        <div className="fade-up" style={{
          padding: '16px 20px',
          background: 'rgba(16,185,129,.07)',
          border: '1px solid rgba(16,185,129,.25)',
          borderRadius: 12, marginBottom: 24,
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <span style={{ fontSize: 24 }}>✅</span>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--green2)', marginBottom: 2 }}>
              Module Complete
            </div>
            <div style={{ fontSize: 13, color: 'var(--t2)' }}>
              Your progress has been saved. You can review this module at any time.
            </div>
          </div>
        </div>
      )}

      {/* Two-column meta */}
      <div className="fade-up fade-up-1" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 28 }}>
        {/* Objectives */}
        <div style={{
          background: 'var(--surface)', border: '1px solid var(--border)',
          borderRadius: 12, padding: '18px 20px',
        }}>
          <div style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--accent2)', marginBottom: 12, letterSpacing: '0.08em' }}>
            LEARNING OBJECTIVES
          </div>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            {module.objectives.map((obj, i) => (
              <li key={i} style={{
                display: 'flex', gap: 8, marginBottom: 8,
                fontSize: 13, color: 'var(--t2)', lineHeight: 1.5,
              }}>
                <span style={{ color: module.color, flexShrink: 0, marginTop: 2 }}>▸</span>
                {obj}
              </li>
            ))}
          </ul>
        </div>

        {/* Policy refs */}
        <div style={{
          background: 'var(--surface)', border: '1px solid var(--border)',
          borderRadius: 12, padding: '18px 20px',
        }}>
          <div style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--t3)', marginBottom: 12, letterSpacing: '0.08em' }}>
            POLICY REFERENCES
          </div>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            {module.policyRefs.map((ref, i) => (
              <li key={i} style={{
                display: 'flex', gap: 8, marginBottom: 7,
                fontSize: 12, color: 'var(--t3)', lineHeight: 1.4, fontFamily: 'var(--mono)',
              }}>
                <span style={{ color: 'var(--border2)', flexShrink: 0 }}>→</span>
                {ref}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Content sections */}
      <div className="fade-up fade-up-2" style={{ marginBottom: 28 }}>
        <h2 style={{ fontFamily: 'var(--display)', fontSize: 17, fontWeight: 700, marginBottom: 16, color: 'var(--t1)' }}>
          Reading Material
        </h2>
        {module.content.map((section, i) => (
          <Section key={i} heading={section.heading} body={section.body} index={i} />
        ))}
      </div>

      {/* Scenarios */}
      {module.scenarios && module.scenarios.length > 0 && (
        <div className="fade-up fade-up-3" style={{ marginBottom: 28 }}>
          <h2 style={{ fontFamily: 'var(--display)', fontSize: 17, fontWeight: 700, marginBottom: 16, color: 'var(--t1)' }}>
            Workplace Scenarios
          </h2>
          <p style={{ fontSize: 13, color: 'var(--t3)', marginBottom: 16 }}>
            Review each scenario and consider the correct response before revealing the answer.
          </p>
          {module.scenarios.map((scenario, i) => (
            <ScenarioCard key={i} scenario={scenario} index={i} />
          ))}
        </div>
      )}

      {/* Mark as read + policy ack */}
      {!isComplete && (
        <div className="fade-up" style={{
          background: 'var(--surface)', border: '1px solid var(--border)',
          borderRadius: 12, padding: '24px 28px', marginBottom: 24,
        }}>
          <h3 style={{ fontFamily: 'var(--display)', fontSize: 16, fontWeight: 700, marginBottom: 16, color: 'var(--t1)' }}>
            Acknowledgement
          </h3>

          <label style={{
            display: 'flex', alignItems: 'flex-start', gap: 12,
            cursor: 'pointer', marginBottom: 14,
          }}>
            <input
              type="checkbox"
              checked={acknowledged}
              onChange={e => setAcknowledged(e.target.checked)}
              style={{ marginTop: 3, width: 16, height: 16, flexShrink: 0, accentColor: module.color }}
            />
            <span style={{ fontSize: 14, color: 'var(--t2)', lineHeight: 1.6 }}>
              I have read and understood the content of this module, including all reading material and workplace scenarios.
            </span>
          </label>

          <label style={{
            display: 'flex', alignItems: 'flex-start', gap: 12,
            cursor: 'pointer', marginBottom: 20,
          }}>
            <input
              type="checkbox"
              checked={policyAcked}
              onChange={e => setPolicyAcked(e.target.checked)}
              style={{ marginTop: 3, width: 16, height: 16, flexShrink: 0, accentColor: module.color }}
            />
            <span style={{ fontSize: 14, color: 'var(--t2)', lineHeight: 1.6 }}>
              I acknowledge the policy references listed for this module and understand they form part of my obligations.
            </span>
          </label>

          <button
            className="btn btn-primary"
            disabled={!acknowledged || !policyAcked}
            onClick={handleComplete}
            style={{ fontSize: 14 }}
          >
            ✓ Mark Module as Complete
          </button>

          {(!acknowledged || !policyAcked) && (
            <p style={{ fontSize: 12, color: 'var(--t3)', marginTop: 10 }}>
              Please check both acknowledgement boxes to continue.
            </p>
          )}
        </div>
      )}

      {/* Navigation */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: 8 }}>
        <div>
          {prevModule && (
            <button
              className="btn btn-ghost"
              onClick={() => onNavigate('module', prevModule)}
              style={{ fontSize: 13 }}
            >
              ← Module {prevModule.id}
            </button>
          )}
        </div>
        <div>
          {nextModule && (
            <button
              className="btn btn-primary"
              onClick={() => onNavigate('module', nextModule)}
              style={{ fontSize: 13 }}
            >
              Module {nextModule.id}: {nextModule.title.split(' ')[0]}… →
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}`
    : '59, 130, 246';
}
