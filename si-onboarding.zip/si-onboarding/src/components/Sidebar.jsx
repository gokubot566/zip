import { MODULES } from '../data/modules.js';

export default function Sidebar({ currentView, currentModule, onNavigate, progress }) {
  const totalCompleted = Object.values(progress).filter(v => v === 'complete').length;
  const allComplete = totalCompleted === MODULES.length;

  return (
    <aside style={{
      width: 260, flexShrink: 0,
      background: 'var(--surface)',
      borderRight: '1px solid var(--border)',
      display: 'flex', flexDirection: 'column',
      height: '100vh', overflowY: 'auto',
      position: 'sticky', top: 0,
    }}>
      {/* Logo */}
      <div style={{
        padding: '20px 20px 16px',
        borderBottom: '1px solid var(--border)',
        flexShrink: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: 'linear-gradient(135deg, #1d4ed8, #3b82f6)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 16, flexShrink: 0,
          }}>🛡️</div>
          <div>
            <div style={{ fontFamily: 'var(--display)', fontWeight: 800, fontSize: 13, color: 'var(--t1)', lineHeight: 1.2 }}>
              Security Impossible
            </div>
            <div style={{ fontSize: 10, color: 'var(--t3)', fontFamily: 'var(--mono)' }}>
              ONBOARDING PORTAL
            </div>
          </div>
        </div>

        {/* Overall progress */}
        <div style={{
          marginTop: 12, padding: '10px 12px',
          background: 'var(--surface2)',
          borderRadius: 8, border: '1px solid var(--border)',
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
            <span style={{ fontSize: 11, color: 'var(--t3)', fontFamily: 'var(--mono)' }}>PROGRESS</span>
            <span style={{ fontSize: 11, color: allComplete ? 'var(--green2)' : 'var(--accent2)', fontFamily: 'var(--mono)', fontWeight: 700 }}>
              {totalCompleted}/{MODULES.length}
            </span>
          </div>
          <div style={{ height: 4, background: 'var(--border)', borderRadius: 2, overflow: 'hidden' }}>
            <div style={{
              height: '100%',
              width: `${(totalCompleted / MODULES.length) * 100}%`,
              background: allComplete
                ? 'linear-gradient(90deg, #10b981, #34d399)'
                : 'linear-gradient(90deg, #1d4ed8, #3b82f6)',
              transition: 'width 0.5s ease',
              borderRadius: 2,
            }} />
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '10px 8px', overflowY: 'auto' }}>
        {/* Dashboard link */}
        <button
          onClick={() => onNavigate('dashboard')}
          style={{
            width: '100%', textAlign: 'left',
            padding: '8px 12px', borderRadius: 7,
            border: 'none', cursor: 'pointer',
            background: currentView === 'dashboard' ? 'rgba(59,130,246,.12)' : 'transparent',
            color: currentView === 'dashboard' ? 'var(--accent2)' : 'var(--t2)',
            display: 'flex', alignItems: 'center', gap: 8,
            fontSize: 13, fontWeight: 500,
            marginBottom: 4,
            transition: 'all 0.15s',
          }}
        >
          <span style={{ fontSize: 14 }}>🏠</span>
          Dashboard
        </button>

        <div style={{ height: 1, background: 'var(--border)', margin: '6px 0 10px' }} />

        {/* Module links */}
        {MODULES.map(mod => {
          const status = progress[mod.id];
          const isActive = currentView === 'module' && currentModule?.id === mod.id;
          const isComplete = status === 'complete';
          const isStarted = status === 'started';

          return (
            <button
              key={mod.id}
              onClick={() => onNavigate('module', mod)}
              style={{
                width: '100%', textAlign: 'left',
                padding: '8px 12px', borderRadius: 7,
                border: 'none', cursor: 'pointer',
                background: isActive ? `rgba(${hexToRgb(mod.color)}, 0.12)` : 'transparent',
                color: isActive ? mod.color : isComplete ? 'var(--t2)' : 'var(--t3)',
                display: 'flex', alignItems: 'center', gap: 8,
                fontSize: 12, fontWeight: isActive ? 600 : 400,
                marginBottom: 2,
                transition: 'all 0.15s',
              }}
            >
              {/* Status indicator */}
              <div style={{
                width: 18, height: 18, borderRadius: '50%', flexShrink: 0,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: isComplete ? 'var(--green)' : isStarted ? 'var(--amber)' : 'var(--border)',
                fontSize: 9, fontWeight: 800,
                color: isComplete ? '#000' : isStarted ? '#000' : 'var(--t3)',
              }}>
                {isComplete ? '✓' : isStarted ? '…' : mod.id}
              </div>

              <span style={{ flex: 1, lineHeight: 1.3 }}>
                {mod.title.length > 28 ? mod.title.substring(0, 28) + '…' : mod.title}
              </span>

              {isActive && (
                <div style={{ width: 4, height: 4, borderRadius: '50%', background: mod.color, flexShrink: 0 }} />
              )}
            </button>
          );
        })}

        {/* Final commit link */}
        {allComplete && (
          <>
            <div style={{ height: 1, background: 'var(--border)', margin: '10px 0 6px' }} />
            <button
              onClick={() => onNavigate('commitment')}
              style={{
                width: '100%', textAlign: 'left',
                padding: '8px 12px', borderRadius: 7,
                border: '1px solid rgba(16,185,129,.3)',
                cursor: 'pointer',
                background: currentView === 'commitment' ? 'rgba(16,185,129,.12)' : 'rgba(16,185,129,.06)',
                color: 'var(--green2)',
                display: 'flex', alignItems: 'center', gap: 8,
                fontSize: 12, fontWeight: 600,
                transition: 'all 0.15s',
              }}
            >
              <span>🎯</span>
              Final Commitment
            </button>
          </>
        )}
      </nav>

      {/* Footer */}
      <div style={{
        padding: '12px 16px',
        borderTop: '1px solid var(--border)',
        flexShrink: 0,
      }}>
        <div style={{ fontSize: 10, color: 'var(--t3)', fontFamily: 'var(--mono)', lineHeight: 1.8 }}>
          <div>Security Impossible Pty Ltd</div>
          <div>Onboarding Portal v2.0</div>
          <div style={{ marginTop: 4, color: 'var(--t3)' }}>
            Questions? <span style={{ color: 'var(--accent2)' }}>security@</span>
          </div>
        </div>
      </div>
    </aside>
  );
}

function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}`
    : '59, 130, 246';
}
