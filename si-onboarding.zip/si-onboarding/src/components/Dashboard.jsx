import { MODULES } from '../data/modules.js';

export default function Dashboard({ progress, onNavigate }) {
  const totalCompleted = Object.values(progress).filter(v => v === 'complete').length;
  const nextModule = MODULES.find(m => progress[m.id] !== 'complete');
  const allComplete = totalCompleted === MODULES.length;

  return (
    <div style={{ maxWidth: 960, margin: '0 auto', padding: '40px 32px' }}>
      {/* Hero */}
      <div className="fade-up" style={{
        background: 'linear-gradient(135deg, #0f1f3d 0%, #0c1220 60%, #0a1628 100%)',
        border: '1px solid var(--border2)',
        borderRadius: 16, padding: '40px 44px',
        marginBottom: 32,
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Grid pattern decoration */}
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.04,
          backgroundImage: 'linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)',
          backgroundSize: '32px 32px',
          pointerEvents: 'none',
        }} />

        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 24, position: 'relative' }}>
          <div style={{
            width: 64, height: 64, borderRadius: 16, flexShrink: 0,
            background: 'linear-gradient(135deg, #1d4ed8, #3b82f6)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 28,
            boxShadow: '0 0 32px rgba(59,130,246,.3)',
          }}>🛡️</div>

          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--accent2)', letterSpacing: '0.1em' }}>
                SECURITY IMPOSSIBLE PTY LTD
              </span>
              <span className="badge badge-blue">ONBOARDING</span>
            </div>
            <h1 style={{
              fontFamily: 'var(--display)', fontWeight: 800,
              fontSize: 32, color: 'var(--t1)', lineHeight: 1.2, marginBottom: 12,
            }}>
              Security & Governance<br />Training Program
            </h1>
            <p style={{ color: 'var(--t2)', fontSize: 15, lineHeight: 1.7, maxWidth: 560 }}>
              Welcome to mandatory onboarding. This program covers your security obligations,
              confidentiality duties, and professional conduct standards as a member of the
              Security Impossible team.
            </p>
          </div>
        </div>

        {/* Progress bar */}
        <div style={{ marginTop: 28, padding: '16px 20px', background: 'rgba(0,0,0,.3)', borderRadius: 10, border: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: 13, color: 'var(--t2)', fontWeight: 500 }}>
              {allComplete ? '🎉 All modules complete!' : `${totalCompleted} of ${MODULES.length} modules completed`}
            </span>
            <span style={{
              fontFamily: 'var(--mono)', fontSize: 13, fontWeight: 700,
              color: allComplete ? 'var(--green2)' : 'var(--accent2)',
            }}>
              {Math.round((totalCompleted / MODULES.length) * 100)}%
            </span>
          </div>
          <div style={{ height: 6, background: 'var(--border)', borderRadius: 3, overflow: 'hidden' }}>
            <div style={{
              height: '100%',
              width: `${(totalCompleted / MODULES.length) * 100}%`,
              background: allComplete
                ? 'linear-gradient(90deg, #10b981, #34d399)'
                : 'linear-gradient(90deg, #1d4ed8, #3b82f6)',
              transition: 'width 0.8s cubic-bezier(0.4,0,0.2,1)',
              borderRadius: 3,
            }} />
          </div>
        </div>
      </div>

      {/* CTA */}
      {nextModule && (
        <div className="fade-up fade-up-1" style={{
          padding: '18px 24px',
          background: 'rgba(59,130,246,.07)',
          border: '1px solid rgba(59,130,246,.2)',
          borderRadius: 12, marginBottom: 28,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16,
        }}>
          <div>
            <div style={{ fontSize: 12, color: 'var(--t3)', marginBottom: 2, fontFamily: 'var(--mono)' }}>
              {totalCompleted === 0 ? 'START HERE' : 'CONTINUE WHERE YOU LEFT OFF'}
            </div>
            <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--t1)' }}>
              {nextModule.icon} Module {nextModule.id}: {nextModule.title}
            </div>
          </div>
          <button className="btn btn-primary" onClick={() => onNavigate('module', nextModule)}>
            {totalCompleted === 0 ? 'Begin Training' : 'Continue'} →
          </button>
        </div>
      )}

      {allComplete && (
        <div className="fade-up fade-up-1" style={{
          padding: '18px 24px',
          background: 'rgba(16,185,129,.07)',
          border: '1px solid rgba(16,185,129,.2)',
          borderRadius: 12, marginBottom: 28,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16,
        }}>
          <div>
            <div style={{ fontSize: 12, color: 'var(--green2)', marginBottom: 2, fontFamily: 'var(--mono)' }}>
              ALL MODULES COMPLETE
            </div>
            <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--t1)' }}>
              🎯 Ready to make your formal commitment
            </div>
          </div>
          <button className="btn btn-success" onClick={() => onNavigate('commitment')}>
            Final Commitment →
          </button>
        </div>
      )}

      {/* Module grid */}
      <div className="fade-up fade-up-2">
        <h2 style={{ fontFamily: 'var(--display)', fontSize: 18, fontWeight: 700, marginBottom: 16, color: 'var(--t1)' }}>
          All Modules
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
          {MODULES.map(mod => {
            const status = progress[mod.id];
            const isComplete = status === 'complete';
            const isStarted = status === 'started';

            return (
              <button
                key={mod.id}
                onClick={() => onNavigate('module', mod)}
                style={{
                  textAlign: 'left', border: 'none', cursor: 'pointer',
                  padding: '16px 18px', borderRadius: 10,
                  background: isComplete ? 'rgba(16,185,129,.05)' : 'var(--surface)',
                  border: `1px solid ${isComplete ? 'rgba(16,185,129,.2)' : 'var(--border)'}`,
                  transition: 'all 0.18s',
                  display: 'flex', flexDirection: 'column', gap: 8,
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.borderColor = isComplete ? 'rgba(16,185,129,.4)' : mod.color + '66';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.borderColor = isComplete ? 'rgba(16,185,129,.2)' : 'var(--border)';
                  e.currentTarget.style.transform = 'translateY(0)';
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: 22 }}>{mod.icon}</span>
                  {isComplete ? (
                    <span className="badge badge-green">✓ DONE</span>
                  ) : isStarted ? (
                    <span className="badge badge-amber">IN PROGRESS</span>
                  ) : (
                    <span className="badge badge-gray">MOD {mod.id}</span>
                  )}
                </div>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--t1)', lineHeight: 1.3, marginBottom: 4 }}>
                    {mod.title}
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--t3)' }}>⏱ {mod.duration}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Info cards */}
      <div className="fade-up fade-up-3" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 32 }}>
        <div className="card">
          <h3 style={{ fontFamily: 'var(--display)', fontSize: 15, fontWeight: 700, marginBottom: 10, color: 'var(--t1)' }}>
            ℹ️ About This Training
          </h3>
          <p style={{ fontSize: 13, color: 'var(--t2)', lineHeight: 1.7 }}>
            This mandatory onboarding program covers your legal and professional obligations
            as a member of the Security Impossible team. Your progress is saved automatically
            and you can return to any module at any time.
          </p>
        </div>
        <div className="card">
          <h3 style={{ fontFamily: 'var(--display)', fontSize: 15, fontWeight: 700, marginBottom: 10, color: 'var(--t1)' }}>
            📞 Need Help?
          </h3>
          <p style={{ fontSize: 13, color: 'var(--t2)', lineHeight: 1.7 }}>
            If you have questions about any policy or your obligations,
            contact the Information Security team at{' '}
            <span style={{ color: 'var(--accent2)' }}>security@securityimpossible.com.au</span>.
          </p>
        </div>
      </div>
    </div>
  );
}
