import { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar.jsx';
import Dashboard from './components/Dashboard.jsx';
import ModulePage from './components/ModulePage.jsx';
import CommitmentPage from './components/CommitmentPage.jsx';
import { MODULES } from './data/modules.js';

const STORAGE_KEY = 'si_onboarding_progress_v2';

export default function App() {
  const [view, setView]           = useState('dashboard');
  const [currentModule, setCurrentModule] = useState(null);
  const [progress, setProgress]   = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Persist progress
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch {}
  }, [progress]);

  function navigate(target, mod) {
    setView(target);
    if (mod) setCurrentModule(mod);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0 });
  }

  function completeModule(moduleId) {
    setProgress(prev => ({ ...prev, [moduleId]: 'complete' }));
    // Mark as started when first opened
  }

  function openModule(mod) {
    setProgress(prev => {
      if (!prev[mod.id]) return { ...prev, [mod.id]: 'started' };
      return prev;
    });
    navigate('module', mod);
  }

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg)' }}>
      {/* Mobile toggle */}
      <button
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        style={{
          display: 'none',
          position: 'fixed', top: 14, left: 14, zIndex: 1000,
          background: 'var(--surface)', border: '1px solid var(--border)',
          borderRadius: 8, padding: '8px 12px', cursor: 'pointer',
          color: 'var(--t1)', fontSize: 18,
        }}
        id="mobile-toggle"
      >
        ☰
      </button>

      {/* Sidebar */}
      <div style={{
        position: 'sticky', top: 0, height: '100vh', flexShrink: 0,
      }}>
        <Sidebar
          currentView={view}
          currentModule={currentModule}
          onNavigate={(target, mod) => {
            if (target === 'module') openModule(mod);
            else navigate(target);
          }}
          progress={progress}
        />
      </div>

      {/* Main content */}
      <main style={{
        flex: 1, overflowY: 'auto',
        minHeight: '100vh',
        background: 'var(--bg)',
      }}>
        {/* Subtle top bar */}
        <div style={{
          position: 'sticky', top: 0, zIndex: 100,
          background: 'rgba(7,11,18,.9)',
          backdropFilter: 'blur(12px)',
          borderBottom: '1px solid var(--border)',
          padding: '10px 28px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--t3)', letterSpacing: '0.06em' }}>
            {view === 'dashboard' && 'DASHBOARD'}
            {view === 'module' && currentModule && `MODULE ${currentModule.id} — ${currentModule.title.toUpperCase()}`}
            {view === 'commitment' && 'FINAL COMMITMENT'}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {MODULES.slice(0, 6).map(m => {
              const status = progress[m.id];
              return (
                <div key={m.id} style={{
                  width: 22, height: 4, borderRadius: 2,
                  background: status === 'complete' ? 'var(--green)' : status === 'started' ? 'var(--amber)' : 'var(--border)',
                  cursor: 'pointer', transition: 'all 0.2s',
                }} onClick={() => openModule(m)} title={m.title} />
              );
            })}
            <div style={{ width: 1, background: 'var(--border)', margin: '0 2px' }} />
            {MODULES.slice(6).map(m => {
              const status = progress[m.id];
              return (
                <div key={m.id} style={{
                  width: 22, height: 4, borderRadius: 2,
                  background: status === 'complete' ? 'var(--green)' : status === 'started' ? 'var(--amber)' : 'var(--border)',
                  cursor: 'pointer', transition: 'all 0.2s',
                }} onClick={() => openModule(m)} title={m.title} />
              );
            })}
          </div>
        </div>

        {/* Page content */}
        {view === 'dashboard' && (
          <Dashboard
            progress={progress}
            onNavigate={(target, mod) => {
              if (target === 'module') openModule(mod);
              else navigate(target);
            }}
          />
        )}
        {view === 'module' && currentModule && (
          <ModulePage
            key={currentModule.id}
            module={currentModule}
            progress={progress}
            onComplete={completeModule}
            onNavigate={(target, mod) => {
              if (target === 'module') openModule(mod);
              else navigate(target);
            }}
          />
        )}
        {view === 'commitment' && (
          <CommitmentPage
            progress={progress}
            onNavigate={navigate}
          />
        )}
      </main>

      {/* Responsive styles */}
      <style>{`
        @media (max-width: 768px) {
          #mobile-toggle { display: flex !important; }
        }
      `}</style>
    </div>
  );
}
