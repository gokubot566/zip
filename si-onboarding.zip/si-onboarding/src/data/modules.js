export const MODULES = [
  {
    id: 1,
    slug: "welcome",
    title: "Welcome & Why Security Matters Here",
    subtitle: "Your introduction to the Security Impossible security culture",
    duration: "15 min",
    color: "#3b82f6",
    icon: "🛡️",
    objectives: [
      "Understand why security is central to everything Security Impossible does",
      "Recognise your personal role in protecting the organisation and its clients",
      "Know what to do if you encounter something that doesn't feel right",
      "Understand the consequences of security failures for clients and the firm"
    ],
    policyRefs: ["SI-POL-001: Information Security Policy", "SI-POL-002: Employee Code of Conduct", "SI-POL-003: Acceptable Use Policy"],
    content: [
      {
        heading: "Why You're Here",
        body: `Welcome to Security Impossible. Before you read a single policy document, sit through a compliance briefing, or pick up a laptop, we want you to understand something important: security at this firm is not a department, a team, or a checkbox. It is a fundamental part of how we work, what we promise our clients, and who we are as an organisation.

Security Impossible provides cybersecurity consulting, assurance, and advisory services to organisations across financial services, government, infrastructure, and professional services sectors. Our clients trust us with some of their most sensitive information — not because we have clever technology, but because they believe our people understand the weight of that trust. The moment we stop earning that trust is the moment we stop being valuable.

Every person who joins this organisation — full-time staff, contractors, interns, or seconded personnel — becomes a custodian of that trust. This is not figurative language. You will genuinely be responsible for information that, if mishandled, could affect our clients' reputations, expose individuals to harm, undermine regulatory compliance, or result in financial loss. We need you to understand that from day one.`
      },
      {
        heading: "What Security Failure Actually Looks Like",
        body: `It is easy to imagine security incidents as dramatic events — hackers breaking into systems, ransomware encrypting servers, or state-sponsored attackers stealing national secrets. These things do happen, and we help our clients defend against them. But the vast majority of security incidents we see in the real world are far more ordinary.

They look like an employee forwarding a client report to their personal email so they can "work on it at home." They look like a team member discussing a sensitive engagement in a coffee shop without checking who is listening. They look like a contractor plugging a personal USB drive into a firm laptop. They look like someone clicking a link in an email that seemed legitimate but wasn't. They look like leaving a laptop unlocked on a desk when stepping away, or writing a password on a sticky note attached to a monitor.

None of these acts are malicious. Most of them are the result of convenience, habit, or a genuine belief that "it won't matter just this once." But every one of them represents a failure of the standard we hold ourselves to, and every one of them has the potential to cause real damage. We are a firm that tells our clients what good looks like. We cannot afford to fall below that standard ourselves.`
      },
      {
        heading: "Your Role in the Security Culture",
        body: `Security culture is not created by policy documents. It is created by the daily decisions of every person in an organisation. When you lock your screen before stepping away from your desk, when you ask a visitor to sign in before entering a secure area, when you pause before clicking a suspicious link, when you speak up because something feels wrong — you are the security culture. No technology, no policy, and no compliance program can substitute for people who genuinely understand why security matters and act accordingly.

At Security Impossible, we expect you to exercise professional judgement. We will give you policies and guidelines, but the goal is for you to internalise the principles behind those policies so that you make the right decision even in situations the policies do not explicitly cover. A policy cannot anticipate every scenario. Your judgement can.

This means being curious about security rather than passive. It means asking questions when you are not sure rather than assuming it will be fine. It means escalating concerns even when you are worried about inconveniencing others or seeming overly cautious. In our experience, the people who "bother" the security team with questions are almost always doing the right thing. The people who never ask questions are the ones who eventually cause problems.`
      },
      {
        heading: "The Consequences We Are Trying to Prevent",
        body: `When security fails at a cybersecurity consulting firm, the consequences are disproportionately severe. Clients come to us precisely because they cannot afford security failures. If we demonstrate that we ourselves cannot maintain the standards we advocate, we lose not just a client relationship but our professional credibility. In an industry where reputation is everything, that damage is existential.

Beyond reputational harm, security incidents can result in regulatory consequences under Australian law, including obligations under the Privacy Act 1988 and the Notifiable Data Breaches scheme. Clients may have contractual rights to seek damages if our failures expose their data. Individual employees can face disciplinary action, termination, and in serious cases, civil or criminal liability.

We are not raising these consequences to frighten you. We are raising them so that you understand the stakes clearly. Most people want to do the right thing — they simply need to understand what the right thing is and why it matters. This training program is designed to give you both the knowledge and the context you need to make sound security decisions throughout your time with us.`
      }
    ],
    scenarios: [
      {
        title: "The Friday Afternoon Email",
        situation: "It's 4:50pm on a Friday. You receive an email that appears to be from a client asking you to send them a copy of the draft report you've been working on. The email address looks slightly different from their usual one, but you've been working closely with this client and the request seems reasonable. You're about to head out.",
        outcome: "This is a classic scenario for social engineering or business email compromise. The slight difference in email address is the key indicator. Even under time pressure, the correct response is to verify the request through a separate channel — call the client directly or message them through a platform you know is secure — before sending any document. Sending the report to an incorrect email address could expose confidential client data and trigger a notifiable data breach."
      },
      {
        title: "The Overheard Conversation",
        situation: "You're having lunch at a café near the office with a colleague. You start discussing a client engagement — mentioning the client's name, the security vulnerabilities you found, and some internal tensions at the client organisation. The café is busy and other tables are occupied by people you don't know.",
        outcome: "This is an information security failure even though no digital systems are involved. Client engagements, including the identity of clients, the findings of assessments, and any internal information shared during an engagement, are confidential. Discussing these matters in public spaces where you cannot control who is listening breaches your confidentiality obligations. Even if no one present turns out to be a competitor or malicious actor, the risk is real and the standard of care has not been met."
      }
    ]
  },
  {
    id: 2,
    slug: "confidentiality",
    title: "Confidentiality & Your Obligations",
    subtitle: "Understanding what you can share, with whom, and when",
    duration: "20 min",
    color: "#8b5cf6",
    icon: "🔒",
    objectives: [
      "Understand the scope of your confidentiality obligations",
      "Know what constitutes confidential information in a consulting context",
      "Understand how to handle confidential information appropriately",
      "Know your obligations when you leave the organisation"
    ],
    policyRefs: ["SI-POL-004: Confidentiality Policy", "SI-POL-005: Information Handling Standard", "Employment Contract — Confidentiality Clause"],
    content: [
      {
        heading: "What Confidentiality Means Here",
        body: `Confidentiality is the obligation to protect information that has been shared with you in a context of trust, and to prevent its disclosure to those who have no legitimate need for it. In a professional services context, this obligation is broader and more consequential than most people initially appreciate.

When you work at Security Impossible, you will be exposed to two distinct categories of confidential information: information belonging to our clients, and information belonging to the firm itself. Both categories carry obligations, but the consequences of client information disclosure are typically more severe because the damage falls on parties who trusted us specifically to protect them.

Client confidential information includes any information shared by a client in the course of an engagement — technical architecture, security vulnerabilities, internal processes, financial data, personnel details, strategic plans, legal matters, and anything else that the client would not voluntarily make public. The classification applied to a document does not determine its confidentiality. Information is confidential by its nature and context, not only because someone has stamped "CONFIDENTIAL" on it.`
      },
      {
        heading: "Firm Confidential Information",
        body: `Firm confidential information includes our methodologies, tools, templates, pricing structures, proposal documents, employee information, financial performance data, client lists, and any intellectual property we have developed. These assets represent significant investment and competitive advantage. Protecting them is not only an ethical obligation — it is a commercial necessity.

There is a common misconception that information shared internally is not confidential in the same way client information is. This is incorrect. Salary information, performance reviews, internal investigations, disciplinary matters, and similar personnel information are confidential even within the organisation. You should only access, discuss, or share information about your colleagues that you legitimately need in the performance of your role.

Firm financial information is similarly sensitive. Do not discuss the firm's revenue, profitability, client billing rates, or cost structures with external parties. If you are asked questions you are not sure how to answer, the correct response is: "I'm not able to share that information." This is professional and appropriate. It is not rude, defensive, or suspicious.`
      },
      {
        heading: "Handling Confidential Information Correctly",
        body: `The practical requirements of handling confidential information correctly are not complicated, but they require consistent attention. Confidential information should be stored in approved systems — firm-provisioned devices, approved cloud platforms, or secure document management systems. It should not be stored in personal cloud accounts, personal devices, or any system that the firm does not manage or monitor.

When you need to share confidential information with external parties — clients, contractors, third-party specialists — you should confirm that the appropriate non-disclosure agreements are in place and that the sharing is authorised by someone with the appropriate authority. If you are not sure whether a particular piece of information can be shared, the answer is to ask before sharing, not to share and hope for the best.

Physical confidentiality matters as much as digital confidentiality. Printed documents containing confidential information should be stored securely when not in use and disposed of using approved destruction methods — cross-cut shredding or secure destruction bins. Documents should not be left on printers, desks, or in general waste. Screen privacy is also a consideration: be mindful of who can see your screen in open-plan offices, cafés, airports, or on public transport.`
      },
      {
        heading: "Your Obligations After You Leave",
        body: `Confidentiality obligations do not end when your employment or engagement ends. Your contract of employment or engagement agreement includes post-termination confidentiality provisions that continue to apply. The specific duration and scope of these obligations are set out in your contract, but as a general principle, you should treat all information you accessed during your time with us as confidential indefinitely, unless it has entered the public domain through legitimate means.

When you leave, you are required to return all firm equipment and delete any firm or client information from personal devices. You should not retain copies of client deliverables, proposals, methodologies, or any other firm materials. If you take a position with a competitor or client organisation, you must be especially careful to ensure you are not drawing on confidential information in your new role.

These obligations exist to protect clients who trusted us, to protect the firm's legitimate commercial interests, and to ensure a fair and professional exit process. They are not designed to prevent you from using your skills, experience, or general professional knowledge in your career.`
      }
    ],
    scenarios: [
      {
        title: "The Former Colleague's Request",
        situation: "A former colleague who left the firm six months ago contacts you on LinkedIn. They are now working at a competitor firm and ask if you can share the methodology we used on a particular type of engagement because they're working on something similar and think our approach was excellent.",
        outcome: "This request must be declined. Our methodologies are proprietary confidential information. Even if the person is someone you trust personally and they have a genuinely benign motive, sharing firm methodologies with a competitor is a breach of your confidentiality obligations and could cause commercial harm to the firm. The appropriate response is to politely decline and explain that you cannot share firm proprietary information."
      },
      {
        title: "The Job Interview Question",
        situation: "You are interviewing for a role at another organisation. During the interview, you are asked to describe a recent project in detail, including what you found, what the client's systems looked like, and what your recommendations were. The interviewer seems genuinely interested and you want to demonstrate your capabilities.",
        outcome: "You can discuss your general experience and skills, but you cannot disclose specific client details, findings, or information that would identify a client or reveal confidential engagement details. The professional way to handle this is to describe your work at a high level — 'I recently led a security assessment for a large financial services organisation' — without revealing client identity or specifics. If a prospective employer insists on specific confidential client details, that itself should raise questions about their professional standards."
      }
    ]
  },
  {
    id: 3,
    slug: "intellectual-property",
    title: "Intellectual Property & Ownership",
    subtitle: "Understanding who owns what you create at work",
    duration: "15 min",
    color: "#f59e0b",
    icon: "⚖️",
    objectives: [
      "Understand who owns work created during your employment or engagement",
      "Know how to handle IP owned by third parties correctly",
      "Understand the firm's open source usage policies",
      "Avoid inadvertently creating IP ownership disputes"
    ],
    policyRefs: ["SI-POL-006: Intellectual Property Policy", "Employment Contract — IP Assignment Clause", "SI-POL-007: Open Source Software Policy"],
    content: [
      {
        heading: "Who Owns What You Create",
        body: `Intellectual property created by employees in the course of their employment is generally owned by the employer under Australian law. This means that if you develop a tool, write a methodology document, create a training resource, design a process, or produce any other work product in the course of your role at Security Impossible, that work product belongs to the firm. This is true even if you created it outside of business hours, on your own device, or as a personal initiative that you then shared with the firm.

The scope of this assignment is broad but not unlimited. It applies to work that relates to the firm's business activities, uses the firm's resources or confidential information, or was created in response to a firm need or client requirement. It does not generally apply to genuinely personal projects that are completely unrelated to the firm's business. However, the boundaries can be ambiguous, and if you have a side project or personal venture that involves any aspect of cybersecurity, security tooling, or security consulting, you should disclose it to your manager and seek clarity before proceeding.

The same principles apply to contractors and consultants, whose engagement agreements will typically include explicit IP assignment provisions. If you are engaged as a contractor and you are unclear about the IP provisions of your agreement, seek clarification before beginning any substantive work.`
      },
      {
        heading: "Client-Specific IP",
        body: `The IP ownership picture becomes more complex in a client engagement context. In most cases, deliverables created specifically for a client — reports, architectures, remediation plans, custom scripts — will be owned by the client as specified in the engagement agreement. Security Impossible typically retains rights to the underlying methodologies, generic templates, and tools used to produce those deliverables, while the specific output is assigned to the client.

This distinction matters because it affects what you can and cannot do with engagement materials. You can use the lessons learned from an engagement to improve your general professional knowledge and capability. You can reference an engagement as part of your professional experience. But you cannot take a deliverable produced for one client and repurpose it directly for another client without permission — even if you created it and it seems generic enough to apply broadly. The client who paid for it has rights in it.

When you are unsure whether something you want to do with engagement materials is appropriate, ask. Do not make assumptions based on what seems reasonable to you in isolation.`
      },
      {
        heading: "Third-Party IP and Open Source",
        body: `Everything you produce should be created using tools, code, libraries, and resources that we are licensed to use. This means being careful about incorporating third-party materials into your work. When you use open source software, you must comply with its licence terms — some open source licences have "copyleft" provisions that could affect our ability to keep deliverables proprietary. When you want to use a stock image, licensed template, or third-party dataset, you must verify that the licence permits commercial use in a consulting context.

The inadvertent introduction of unlicensed third-party material into client deliverables can create legal and commercial problems that are disproportionately serious. A client who discovers that their security report incorporates open source code under a licence that requires disclosure, or that their new security framework is based on a template the firm did not have the right to use, will have legitimate grounds for concern. Avoiding these problems requires diligence at the point of creation, not after the fact.

If you are building tools, scripts, or code as part of your work, document your use of third-party libraries and run it past your manager before including it in a client deliverable. The firm has approved lists of open source dependencies and standard approaches to IP clearance that you should follow.`
      }
    ],
    scenarios: [
      {
        title: "The Personal Project Dilemma",
        situation: "Before joining Security Impossible, you spent your own time developing a threat modelling tool that you find very useful. You would like to use it in your work for clients and potentially share it with colleagues. You didn't develop it at the firm, but it's directly relevant to the work you now do.",
        outcome: "This situation requires careful handling. The fact that you developed the tool before joining does not automatically resolve the question. You should disclose the tool to your manager and seek advice from the firm's legal counsel before using it in client work. Issues to consider include: whether the tool could be mistaken for firm IP, whether using it in client work could affect your rights, and whether the firm wants to formalise the arrangement. Acting unilaterally — even with good intentions — could create confusion about IP ownership that is difficult to unwind later."
      },
      {
        title: "The Helpful Template",
        situation: "You find a very well-structured security assessment template on a GitHub repository. It's clearly labelled as open source under a GPL licence. You want to use it as the basis for a client deliverable because it would save significant time.",
        outcome: "This requires checking before proceeding. A GPL licence typically requires that derivative works also be distributed under GPL terms — which would conflict with delivering a proprietary report to a client. You should flag this with your manager and seek guidance on whether a modified version of the template could be used, whether the licence terms pose a problem, or whether an alternative approach is needed. Do not incorporate open source materials into client deliverables without confirming the licence is compatible with the firm's obligations."
      }
    ]
  },
  {
    id: 4,
    slug: "privacy",
    title: "Privacy & Australian Privacy Principles",
    subtitle: "Handling personal information with care and legal compliance",
    duration: "25 min",
    color: "#10b981",
    icon: "🔐",
    objectives: [
      "Understand what constitutes personal information under Australian law",
      "Know when and how personal information can be collected and used",
      "Understand the Notifiable Data Breaches scheme and when it applies",
      "Know how to respond when you encounter a potential privacy breach"
    ],
    policyRefs: ["SI-POL-008: Privacy Policy", "Privacy Act 1988 (Cth)", "Australian Privacy Principles", "SI-POL-009: Data Breach Response Plan"],
    content: [
      {
        heading: "What the Privacy Act Requires",
        body: `Australia's Privacy Act 1988 and the thirteen Australian Privacy Principles (APPs) that sit within it establish the framework for how organisations collect, use, store, and disclose personal information. As an APP entity — an organisation with an annual turnover above the threshold — Security Impossible is legally required to comply with these principles. More importantly, as a security consulting firm, we handle personal information belonging to our clients and their customers on a regular basis. We have both a legal and a professional obligation to treat that information with the highest standard of care.

Personal information is defined broadly under the Privacy Act: it is any information or an opinion about an identified individual, or an individual who is reasonably identifiable. This includes obvious items like names, addresses, and identification numbers, but also extends to IP addresses associated with identifiable individuals, device identifiers, behavioural data, employment records, financial information, health information, and many other categories. Sensitive information — including health, biometric, and government identifier data — attracts additional protections.

When you work on client engagements, you may encounter personal information in many forms: employee records, customer databases, access logs that identify individual users, security incident reports that name affected individuals, or configuration data that reveals personal details about system administrators. Your obligation is to handle all of this information only in the ways that are necessary for the engagement, to retain it no longer than required, and to protect it from unauthorised access or disclosure.`
      },
      {
        heading: "Key Australian Privacy Principles in Practice",
        body: `Several of the APPs are particularly relevant to daily work at a security consulting firm. APP 3 requires that personal information only be collected for a purpose that is directly related to the organisation's functions and activities. When you are scoping an engagement, you should avoid collecting personal information beyond what is genuinely needed. For example, if you are conducting a network security assessment, you may need to review access logs — but you should not retain unnecessary personal information from those logs beyond what is required for the assessment findings.

APP 6 restricts the use and disclosure of personal information to the purpose for which it was collected or a directly related secondary purpose. This means you cannot use personal information encountered during one client engagement for any other purpose — including preparing for another engagement, building internal benchmarks, or personal curiosity. Information about Client A's employees cannot be used in any context related to Client B or to the firm's general operations.

APP 11 requires that personal information be protected from misuse, interference, loss, unauthorised access, modification, or disclosure. This APP is the one most directly related to security controls — and it is directly relevant to the services we provide. We must hold ourselves to at least the same standard we recommend to clients. If we advise a client to encrypt sensitive data at rest, we must be encrypting sensitive data at rest ourselves.`
      },
      {
        heading: "Notifiable Data Breaches",
        body: `The Notifiable Data Breaches (NDB) scheme requires APP entities to notify the Office of the Australian Information Commissioner (OAIC) and affected individuals when an eligible data breach occurs. An eligible data breach is one that involves unauthorised access to or disclosure of personal information, and is likely to result in serious harm to one or more individuals.

"Serious harm" includes physical, psychological, emotional, financial, or reputational harm. The assessment of whether harm is "likely" must be made promptly — the obligation to notify arises as soon as the entity becomes aware of grounds to suspect an eligible breach has occurred, and the assessment should be completed within 30 days. Failure to notify when required is itself a breach of the Privacy Act and can attract significant civil penalties.

If you become aware of a potential data breach — whether it involves firm data or client data — you must report it to your manager and the firm's privacy officer immediately. Do not attempt to assess the severity of the breach on your own, do not delay reporting while you investigate, and do not discuss the incident beyond the appropriate internal channels. Speed and transparency in breach response are critical. The longer an organisation delays, the worse the regulatory and reputational consequences tend to be.`
      }
    ],
    scenarios: [
      {
        title: "The Misconfigured Access Log",
        situation: "During a security assessment for a client, you discover that their access control system has been logging not just access events but also the personal emails, phone numbers, and medical appointment details of employees who used certain terminals. There are months of these logs, involving hundreds of individuals.",
        outcome: "This is a potential eligible data breach in the making — or already an occurrence. The logs represent personal information (including potentially sensitive information depending on content) that has been collected beyond the scope of the system's intended purpose. You should immediately bring this to your engagement manager's attention. The client needs to be informed so they can assess their NDB obligations. The engagement team should not retain, use, or analyse this personal information beyond what is strictly necessary to document the finding. How the finding is written up should be carefully considered to avoid unnecessarily reproducing the personal information in deliverables."
      },
      {
        title: "The Accidentally Sent Email",
        situation: "A colleague means to forward a client email internally but accidentally sends it to an email address that belongs to a competitor firm. The email contains the names, contact details, and employment roles of several individuals at the client organisation.",
        outcome: "This is a security incident and potentially a notifiable data breach. The colleague should immediately notify their manager. The firm's incident response process should be triggered. Steps to take include: attempting to contact the recipient to request deletion of the email, preserving evidence of the incident, conducting an assessment of whether the disclosure constitutes an eligible data breach under the NDB scheme, and notifying the client and the OAIC if the assessment indicates notification is required. The incident should be documented even if it is assessed as not meeting the NDB threshold."
      }
    ]
  },
  {
    id: 5,
    slug: "data-classification",
    title: "Data Classification & Handling",
    subtitle: "Knowing what level of protection information requires",
    duration: "20 min",
    color: "#ef4444",
    icon: "📊",
    objectives: [
      "Understand the firm's data classification scheme and what each level means",
      "Know how to classify information you create or receive",
      "Apply the correct handling procedures to each classification level",
      "Understand the risks of misclassification"
    ],
    policyRefs: ["SI-POL-010: Data Classification Standard", "SI-POL-011: Information Handling Procedures", "SI-POL-005: Information Handling Standard"],
    content: [
      {
        heading: "Why Classification Matters",
        body: `Not all information requires the same level of protection. A document containing last year's publicly-available annual report does not need the same security controls as a client's vulnerability assessment findings. Treating everything as equally sensitive leads to one of two failure modes: either protective controls are applied so universally and uniformly that they create friction and people start circumventing them, or the sheer volume of material classified as sensitive dilutes the attention paid to the things that genuinely matter.

A well-designed classification scheme allows an organisation to apply proportionate controls — strong protection where it is warranted, lighter-touch handling where the risk is low. At Security Impossible, we use a four-level classification scheme that applies to all information we create, receive, store, or transmit. Understanding this scheme and applying it consistently is a fundamental professional responsibility.

Misclassification in either direction creates problems. Underclassifying sensitive information means it may be handled without adequate care — stored in the wrong systems, shared with the wrong people, or disposed of without the appropriate rigour. Overclassifying routine information wastes resources, creates workflow friction, and can undermine confidence in the classification system as a whole.`
      },
      {
        heading: "The Four Classification Levels",
        body: `PUBLIC information is information that has been formally approved for release to the general public or that is inherently public in nature. This includes published articles, marketing materials, publicly-available regulatory filings, and information deliberately shared through public channels. No special handling requirements apply, though this does not mean public information can be used carelessly — accuracy, attribution, and professional standards still apply.

INTERNAL information is information that is intended for use within the firm but that does not require the strong protections applied to more sensitive categories. Most day-to-day operational information falls into this category: internal process documents, general project plans, routine internal communications, and non-sensitive procedural materials. Internal information should not be shared with external parties without explicit authorisation, but can be handled through standard internal channels without exceptional security measures.

CONFIDENTIAL information is information that is sensitive and whose disclosure could cause harm to the firm, its clients, or its personnel. Client engagement materials, proposal documents, financial information, personnel information, and most information shared with us by clients falls into this category. Confidential information must be stored in approved secure systems, transmitted using encrypted channels, and shared only with those who have a legitimate need. Printed confidential materials must be stored securely and destroyed using approved methods.

RESTRICTED information is the highest classification level, reserved for information whose disclosure could cause severe harm — complete vulnerability assessment reports before remediation, exploit code, government-classified information handled under specific accreditation, or information subject to legal professional privilege. Restricted information requires the strongest available protections: encryption at rest and in transit, access controls limited to named individuals with specific authorisation, and audit trails of all access.`
      },
      {
        heading: "Practical Classification Decisions",
        body: `When you create a document, you are responsible for classifying it at the point of creation. Ask yourself: if this document were disclosed to someone who should not have it — a competitor, a journalist, or the wrong client — what could happen? If the answer is nothing significant, it is probably Internal or Public. If the answer is that a client's reputation could be damaged, business advantage could be lost, or individuals could be harmed, it is probably Confidential or Restricted.

When you receive information from a client, assume it is Confidential unless you have a specific reason to believe otherwise. Many clients do not apply formal classification markings to the information they share with us, and some of the most sensitive information we receive arrives informally — in an email, in a meeting, or in a casual conversation. The absence of a classification label does not reduce the sensitivity of the information.

Email is a particularly high-risk area for classification errors. Before sending an email containing confidential or restricted information, confirm: have you addressed it to the right recipient, have you checked the classification of any attachments, are you using an appropriate channel for this level of sensitivity, and do all recipients have authorisation to receive this information? A moment's pause before pressing send is one of the simplest and most effective security controls available to you.`
      }
    ],
    scenarios: [
      {
        title: "The Unclassified Draft",
        situation: "You have been working on a draft report that identifies 47 critical vulnerabilities in a client's financial system, including details of exploitable configurations and the specific software versions affected. A colleague asks you to share a draft for review. You send it via a personal email because you know your colleague checks that more frequently.",
        outcome: "This handling is incorrect on two levels. First, this document is Restricted — it contains a complete vulnerability assessment including exploitable details for a financial system. Second, it has been transmitted through an unapproved channel (personal email). Restricted documents must be shared through firm-approved secure channels only. The correct approach would be to share it through the firm's document management system or an approved secure file transfer mechanism. If your colleague needs faster access, that is a workflow problem to solve through approved means, not by bypassing security controls."
      },
      {
        title: "The Classification Upgrade",
        situation: "You begin an internal project planning document at the INTERNAL level. During the project, you start incorporating client-specific requirements, budget information tied to a specific client relationship, and technical details drawn from a previous engagement. The document has grown to contain a mixture of internal and confidential information.",
        outcome: "When a document's content changes to include more sensitive information, the classification must be upgraded to match the most sensitive element it now contains. In this case, once the document incorporated client-specific and financially sensitive information, it should have been reclassified as CONFIDENTIAL and moved to an appropriate storage location with the controls that apply to that level. The practice of keeping documents in a lower classification tier because they started there — rather than reviewing classification as content evolves — is a common source of mishandling."
      }
    ]
  },
  {
    id: 6,
    slug: "asset-management",
    title: "Asset Management & Secure Workplace Practices",
    subtitle: "Looking after firm resources and maintaining a secure physical environment",
    duration: "15 min",
    color: "#06b6d4",
    icon: "💻",
    objectives: [
      "Understand your responsibilities for firm-provided equipment",
      "Know the rules around using personal devices for firm work",
      "Maintain a secure physical working environment",
      "Handle equipment correctly at the end of its useful life"
    ],
    policyRefs: ["SI-POL-012: Asset Management Policy", "SI-POL-003: Acceptable Use Policy", "SI-POL-013: Clean Desk Policy", "SI-POL-014: Mobile Device Policy"],
    content: [
      {
        heading: "Your Responsibility for Firm Assets",
        body: `When you join Security Impossible, you will be provided with equipment appropriate to your role — typically a laptop and mobile phone, and sometimes additional specialised tools. These assets are assigned to you personally in the asset register, and you are responsible for their safekeeping, appropriate use, and return in good condition.

Being responsible for an asset does not make it yours. Firm assets are provided to enable you to do your job effectively, and they must be used for firm business purposes. They should be treated with reasonable care, not used in ways that could damage them, expose them to security risks, or bring them into environments where they could be lost or stolen. This is not about being bureaucratic — a laptop containing client data is a high-value target, and its loss or theft could trigger significant security and privacy obligations.

If equipment is lost, stolen, or damaged, report it immediately. The natural human impulse is to hope it turns up or to feel embarrassed about what happened, but speed is critical. If a device is lost, it may be possible to remotely wipe it before any data is compromised — but only if the loss is reported promptly. If you find a device you suspect belongs to the firm or a client, hand it in rather than attempting to investigate it yourself. Plugging in an unknown device of any kind is a significant security risk.`
      },
      {
        heading: "BYOD and Personal Devices",
        body: `The use of personal devices to access firm or client information — sometimes called "Bring Your Own Device" or BYOD — is a significant security risk that requires specific controls. Personal devices are outside the firm's management environment: they may not have current security patches, may not be encrypted, may have insecure applications installed, and may be shared with family members or others who have no authorisation to access firm information.

The firm's policy on BYOD is set out in the Mobile Device Policy and Acceptable Use Policy. In summary: accessing firm email and calendaring via an approved mobile device management profile on a personal phone is generally permitted. Storing confidential or restricted documents on personal devices is not. Processing client information on personal laptops outside of approved remote access mechanisms is not. If you are in a situation where you are tempted to use a personal device to access or store firm or client information because it would be more convenient, that convenience does not override the security requirement.

If your role genuinely requires greater flexibility in device usage, speak to your manager about the appropriate approved solution. There are often ways to accommodate legitimate operational needs while maintaining acceptable security controls.`
      },
      {
        heading: "Clean Desk and Physical Security",
        body: `Physical security is as important as digital security. The clean desk policy requires that you do not leave sensitive documents, notes, access credentials, or unlocked devices unattended on your desk — whether in the office, at a client site, or in any shared workspace. When you leave your desk, even briefly, you should lock your screen. At the end of the day, confidential documents should be in locked storage, not on your desk.

This policy exists because physical access to information is just as damaging as digital access. A photograph of a whiteboard covered in network diagrams, a glance at an unlocked screen, or the retrieval of a document from an unsecured desk can expose information just as effectively as a cyberattack. In a shared office environment or at a client site, you cannot always be certain of who has physical access to your workspace.

When working in public spaces — airports, cafés, trains, co-working spaces — additional care is required. Use a privacy screen on your laptop to prevent shoulder surfing. Be conscious of conversations that others can overhear. Do not connect to untrusted public Wi-Fi networks without using the firm VPN. If you need to step away from your device in a public space and cannot take it with you, that is not an appropriate environment for working on confidential materials.`
      }
    ],
    scenarios: [
      {
        title: "The Lost Laptop Scenario",
        situation: "You realise at 3pm that you cannot find your work laptop. You think you may have left it on the train during your morning commute. It is encrypted and password-protected, but it contains several client engagement files. You are hoping it will turn up in the lost property.",
        outcome: "Report this immediately — to your manager and the IT security team — even though you hope the laptop will be recovered. The device must be assumed lost and potentially in the hands of someone with hostile intent. IT security can initiate a remote wipe and disable access from that device. The loss must also be assessed as a potential notifiable data breach, which requires prompt action. Waiting to see if it turns up at lost property is not an acceptable approach — every hour of delay reduces the ability to mitigate the risk. Lost property will not prevent someone with technical capability from accessing data on an unwiped device."
      },
      {
        title: "The Working from Café",
        situation: "You are working from a café because you enjoy the atmosphere. You are working on a vulnerability assessment report and you are sitting at a table near other customers. Your screen is visible to people walking past, and you are discussing the report over the phone with a colleague.",
        outcome: "This situation involves two physical security failures. The visible screen means anyone passing can see client vulnerability details — this should be addressed with a privacy screen or by repositioning. The phone conversation in a public space about specific client vulnerabilities should not be happening. If you need to discuss sensitive engagement details, do so in a private location. The café is fine for internal coordination calls on non-sensitive matters, but not for client-specific technical discussions."
      }
    ]
  },
  {
    id: 7,
    slug: "threats",
    title: "Recognising & Responding to Threats",
    subtitle: "Identifying social engineering, phishing, and other attack vectors",
    duration: "25 min",
    color: "#f59e0b",
    icon: "⚠️",
    objectives: [
      "Recognise common social engineering and phishing techniques",
      "Know how to respond when you encounter a suspected threat",
      "Understand why a security firm is an attractive target",
      "Develop healthy skepticism without becoming paranoid or non-functional"
    ],
    policyRefs: ["SI-POL-015: Incident Response Policy", "SI-POL-016: Security Awareness Training Policy", "SI-POL-003: Acceptable Use Policy"],
    content: [
      {
        heading: "Why Security Impossible Is a High-Value Target",
        body: `Threat actors do not target organisations at random. They select targets based on the value of what they can obtain and the likelihood of success. Security Impossible is an unusually attractive target for several reasons that you should understand clearly.

First, we have detailed knowledge of our clients' security postures, including their vulnerabilities. An attacker who gains access to our systems and files could obtain a roadmap for attacking multiple high-value client organisations simultaneously. This makes a successful attack on us potentially worth far more than an attack on a single client.

Second, as a security firm, we represent a prestige target. Successfully compromising a cybersecurity consulting firm is a demonstration of capability that sophisticated threat actors are motivated to achieve. Some attacks on security firms are motivated by the desire to steal proprietary tools and methodologies for use against others. Some are motivated by espionage. Some are opportunistic. The common thread is that the assumption that "security people know better, so they won't be targeted" is false. We are targeted more, not less, precisely because of who we are.

This means that the security awareness and discipline we ask of you is not theoretical box-ticking. It is a genuine operational necessity.`
      },
      {
        heading: "Social Engineering and Pretexting",
        body: `Social engineering attacks exploit human psychology rather than technical vulnerabilities. The most sophisticated technical defences can be bypassed if an attacker can convince a human being to take an action they should not take. As a security firm, we are at particular risk because our people are willing to engage with technical questions, discuss security topics, and assist others — qualities that are assets in our work but that social engineers can exploit.

Pretexting involves creating a fabricated scenario to extract information or gain access. A caller might claim to be from the IT department needing your credentials to resolve an urgent issue. A visitor might claim to be a fire safety inspector who needs to see the server room. An email might appear to be from a client asking for an urgent copy of their assessment report. A colleague might appear to ask a completely reasonable question that, in context, is an attempt to gather information for a later attack.

The tell-tale signs of social engineering include: a sense of urgency designed to prevent careful thinking, requests to bypass normal procedures "just this once," appeals to authority from people you cannot independently verify, requests for information or access that are slightly outside normal channels, and pressure not to double-check or verify. When you feel these pressures, they are not reasons to comply more quickly — they are reasons to slow down and verify.`
      },
      {
        heading: "Phishing in All Its Forms",
        body: `Phishing — the use of deceptive communications to trick recipients into divulging credentials, clicking malicious links, or downloading malware — remains the most common initial access vector in the attacks we investigate for clients. Understanding how to recognise phishing is fundamental.

Classic email phishing has evolved significantly. Modern phishing emails are often personalised, using information about the recipient gathered from professional networking sites and public sources. They may perfectly mimic the visual style of legitimate organisational communications. They may arrive from addresses that are very close to legitimate addresses. They may be sent as replies to genuine email threads that have been compromised.

Spear phishing is targeted phishing directed at specific individuals. As senior staff and people with access to valuable information, some of you will be specific targets of spear phishing campaigns. Vishing is voice phishing — phone-based social engineering. Smishing uses SMS. Business email compromise involves compromising or spoofing executive email accounts to authorise fraudulent transactions or data disclosures.

The single most effective defence is to verify requests for sensitive action or information through a separate channel before acting. If you receive an email that claims to be from the CEO asking you to take an unusual action, call the CEO before doing it. Do not reply to the email asking if it is legitimate — you are just asking the attacker if they are attacking you.`
      },
      {
        heading: "Responding to Suspected Incidents",
        body: `If you believe you have been the target of a social engineering attack, received a phishing email, clicked something you should not have, or witnessed something suspicious, report it immediately to the IT security team. Do not be embarrassed about what happened. Do not try to fix it yourself. Do not wait to see if anything bad actually occurs.

The incident response process exists precisely to handle these situations in a structured, effective way. Early reporting dramatically improves outcomes. If you clicked a malicious link and report it within minutes, it may be possible to contain any compromise before it spreads. If you wait days because you are hoping nothing will happen, the damage will be far harder to contain.

After an incident, you will be asked to describe exactly what happened — what you clicked, what you typed, what you shared. Reconstruct this as accurately as you can. Precision matters in incident response. The habit of making quick mental notes when something unusual happens will serve you well.`
      }
    ],
    scenarios: [
      {
        title: "The Urgent Executive Request",
        situation: "You receive an email at 7am, apparently from the firm's CEO, asking you to urgently purchase ten $500 gift cards and email the redemption codes to an address provided. The email says the CEO is in meetings all day and cannot be reached by phone, but needs the codes by 9am for a client appreciation initiative.",
        outcome: "This is a textbook business email compromise scenario. The urgency, the inability to verify through normal channels, and the unusual request type are all red flags. The correct response is to refuse to act, to find another way to contact the CEO or their PA to verify (not by replying to the email), and to forward the email to the IT security team as a suspected phishing attempt. Do not act on the request regardless of how convincing the email appears. Gift card requests from executives via email are almost always fraudulent."
      },
      {
        title: "The Suspicious Link",
        situation: "You receive a link in a Slack message from a colleague asking you to review a document they have shared in an external document platform. You click the link but the page asks you to log in again with your firm credentials before you can view the document. This seems slightly odd since you are already logged in.",
        outcome: "Stop. Do not enter your credentials. A page that asks for authentication credentials after following a link from a messaging platform is a classic credential harvesting page — particularly if the URL is not the legitimate service's domain. Close the page, report the message and link to the IT security team immediately, and check whether your colleague genuinely sent the message (their account may have been compromised). Change your password if you have any doubt. If you already entered credentials, report this immediately — it is a security incident."
      }
    ]
  },
  {
    id: 8,
    slug: "acceptable-use",
    title: "Acceptable Use & AI Tools",
    subtitle: "Using technology responsibly and understanding AI's risks",
    duration: "20 min",
    color: "#8b5cf6",
    icon: "🤖",
    objectives: [
      "Understand what constitutes acceptable use of firm technology",
      "Know the risks of using AI tools with confidential information",
      "Understand how to use AI tools in a way that protects firm and client data",
      "Know the firm's specific policies on generative AI"
    ],
    policyRefs: ["SI-POL-003: Acceptable Use Policy", "SI-POL-017: Generative AI Usage Policy", "SI-POL-004: Confidentiality Policy"],
    content: [
      {
        heading: "The Baseline Acceptable Use Standard",
        body: `Firm technology — including devices, systems, internet access, cloud platforms, software licences, and communication tools — is provided for business purposes. A reasonable amount of incidental personal use is tolerated (for example, checking personal email or making personal purchases on a lunch break), but firm technology should not be used for activities that are illegal, that could create a security risk, that generate reputational risk for the firm, or that constitute a material distraction from professional responsibilities.

Prohibited activities include accessing illegal content of any kind, using firm systems to conduct personal business activities, using licensed software for purposes outside the scope of the licence, circumventing security controls, installing unapproved software, accessing or attempting to access systems or data you are not authorised to use, and using firm communications to send harassing, discriminatory, or otherwise inappropriate content.

The reasonable personal use allowance does not extend to activities that compete with the firm's business, that could embarrass the firm, or that involve significant use of firm resources. If you are spending hours each day on personal activities using firm systems, that is not consistent with reasonable personal use.`
      },
      {
        heading: "AI Tools: The Fundamental Risk",
        body: `Generative AI tools — including large language models like ChatGPT, Claude, Gemini, Copilot, and others — have become widely used in professional environments. They offer genuine productivity benefits and are increasingly integrated into the workflows of our people. However, they present a specific and significant information security risk that you must understand before using them.

When you submit a prompt to a commercial generative AI service, you are transmitting the content of that prompt to an external third-party server. Depending on the service and your account settings, that content may be used to train future model versions, stored for review by service staff, or retained in ways you cannot control. This is not a theoretical risk — it is the explicit operational model of most consumer-grade AI services.

The consequence of this is straightforward: you must not submit confidential or restricted information to any AI tool that you have not confirmed is approved for that purpose. Submitting client data, vulnerability assessment findings, confidential engagement details, personnel information, or firm-confidential financial or strategic information to a commercial AI service is a potential breach of confidentiality obligations and, if the information contains personal data, a potential privacy breach. The fact that it produces a useful output does not change this analysis.`
      },
      {
        heading: "Using AI Tools Responsibly",
        body: `The firm maintains an approved list of AI tools and the conditions under which each may be used. Some AI tools are available with enterprise data protection commitments — under which prompts are not used for training and are subject to contractual data protection obligations. Using AI tools configured under such agreements, for appropriate purposes, is generally permitted.

The practical guidance is: before submitting anything to an AI tool, ask yourself whether you would be comfortable emailing the same content to an external party you do not have a confidentiality agreement with. If the answer is no, you should not submit it to a consumer AI service. You can use AI for drafting general content, summarising public information, generating code in sandboxed environments, exploring ideas, and other activities that do not involve confidential information.

If you believe an AI tool could genuinely improve your work with confidential information, raise this with your manager. The firm may be able to procure an appropriate enterprise solution, configure an approved tool with appropriate data protections, or find another way to capture the productivity benefit without the information security risk. Bypassing the policy because the tool is useful does not make the risk go away.`
      }
    ],
    scenarios: [
      {
        title: "The Helpful AI Summary",
        situation: "You have just completed a lengthy client interview and have pages of notes about the client's security environment, including the names of systems, vendors, known vulnerabilities, and some details about a recent internal incident the client disclosed. You want to use a public AI chatbot to quickly summarise the notes into a structured format.",
        outcome: "This is not an appropriate use of a public AI tool. The notes contain confidential client information — specific technical details, system names, incident information, and potentially personal data about individuals involved in the incident. Submitting this content to a public AI service transmits it to an external server without confidentiality protections. The appropriate path would be to use an approved enterprise AI tool (if available) or to do the summarisation manually. If you find yourself repeatedly in situations where AI tools would genuinely help but you cannot use them safely, that is a use case to raise with your manager for a proper solution."
      },
      {
        title: "The Code Generation Shortcut",
        situation: "You are writing a script to process some log files from a client's SIEM. The log files contain actual event data including user IDs, IP addresses, and event details. You want to paste a sample of the log data into an AI coding assistant to help it understand the format and generate parsing code.",
        outcome: "Strip the actual log data before submitting it to an AI tool. You can describe the log format in general terms, use a synthetic example with made-up data that has the same structure, or use placeholder values. The AI tool does not need real data to help you write code — it needs to understand the data structure. Actual log data from a client SIEM, containing real user IDs and events, is confidential information that should not be submitted to an external service. This is a solvable problem: create a synthetic example and use that instead."
      }
    ]
  },
  {
    id: 9,
    slug: "social-media",
    title: "Social Media & Public Conduct",
    subtitle: "Maintaining professional standards in your public and online presence",
    duration: "15 min",
    color: "#ec4899",
    icon: "📱",
    objectives: [
      "Understand how your personal social media use can affect the firm",
      "Know what you can and cannot share publicly about your work",
      "Understand the OSINT risk your public profiles create",
      "Maintain appropriate professional conduct in public settings"
    ],
    policyRefs: ["SI-POL-018: Social Media Policy", "SI-POL-004: Confidentiality Policy", "SI-POL-002: Employee Code of Conduct"],
    content: [
      {
        heading: "The Professional Boundary in a Connected World",
        body: `Social media has made the boundary between professional and personal life genuinely difficult to manage. Most people's professional profiles, personal accounts, and public conduct are visible, interconnected, and permanently accessible in ways that were not true a generation ago. This creates specific obligations for people who work in security consulting.

When you identify yourself as an employee of Security Impossible — whether in a professional profile, a personal bio, a conference badge, or a casual mention in a public forum — you implicitly represent the firm in that context. Your conduct, your opinions, and the information you share reflect on the firm's reputation and professional standing. This does not mean you lose your personal voice or your right to opinions, but it does mean you must exercise professional judgement about what you share and how.

The firm does not attempt to control your personal social media accounts or your opinions expressed outside of work. What we do ask is that you apply the same professional judgement to your public conduct that you would apply in a client meeting: consider who can see this, consider how it reflects on the firm, and consider whether it discloses information that should remain confidential.`
      },
      {
        heading: "What You Cannot Share",
        body: `The confidentiality obligations described in Module 2 apply fully to social media and public communications. You cannot share client identity, engagement details, security findings, or any other confidential information through social media channels — not even as a vague hint, an anonymised example, or an inside reference that "only people who know will understand."

The security industry culture includes a strong tradition of conference presentations, blog posts, research publications, and public discourse. This is valuable and the firm supports it. But there is a meaningful distinction between sharing genuinely generalised technical knowledge and inadvertently revealing client-specific information. "Here's an interesting technique we use for privilege escalation testing" is potentially acceptable. "Last week I found this exact configuration error at a major Australian bank" is not, even if you do not name the bank.

Do not post photographs that could reveal client environments, office layouts, colleague information, device screens, or anything that could constitute an information security risk. The habit of photographing and sharing at conferences and client events is common and usually benign, but requires thought. A photograph of an interesting architecture diagram on a whiteboard at a client site is a photograph of confidential client information.`
      },
      {
        heading: "You as an OSINT Target",
        body: `Open Source Intelligence (OSINT) is the collection of publicly available information to build a profile of a target. Adversaries routinely conduct OSINT against the employees of target organisations before attempting social engineering attacks or other intrusions. As an employee of a cybersecurity firm, you are more likely to be an OSINT target than the average knowledge worker.

Consider what someone could learn about you from your public professional profiles: where you work, what clients you have worked with (if you have listed them), what technologies you specialise in, who your colleagues are, when you are travelling to conferences, and what your professional interests are. This information is the raw material for a targeted spear phishing attack, a pretexting call, or a physical social engineering attempt.

This does not mean you should scrub your professional presence from the internet — that would be impractical and professionally counterproductive. It means you should be thoughtful about what you share. Avoid listing specific client names on your professional profiles. Be careful about posting real-time location information when you are at client sites. Be mindful that conference presentations and published research tell a sophisticated observer a great deal about your knowledge, your clients, and your methodologies.`
      }
    ],
    scenarios: [
      {
        title: "The Conference Tweet",
        situation: "You are presenting at a security conference and you post a photo of your presentation slide on Twitter/X to share your content more widely. The slide contains a generic architecture diagram, but in the background of the photo, a whiteboard is visible showing the name of a client and some network information from an assessment you conducted last month.",
        outcome: "This has inadvertently disclosed confidential client information. The client's name and network details visible in the background constitute a confidentiality breach even though that was not the intent. The post should be deleted immediately. The client may need to be informed depending on what information was visible and for how long. This scenario illustrates why photographs taken in work environments — even for innocent purposes — require care. Check the background before posting."
      },
      {
        title: "The LinkedIn Accomplishment",
        situation: "You complete a particularly successful and technically challenging engagement and want to update your LinkedIn profile to reflect your experience. You write a brief description that mentions the industry of the client, the type of assessment, and a high-level finding that you are proud of having identified.",
        outcome: "This requires careful editing. Mentioning the industry (e.g., 'financial services') is generally acceptable. Describing the type of assessment in general terms is often fine. But describing a specific finding, even without naming the client, could allow the client to be identified by anyone with knowledge of their organisation, and constitutes sharing confidential engagement information. The test is: could a person familiar with the industry figure out which client this refers to? If yes, it is too specific. Describe the type of work and the skills it required, not the specific findings or circumstances."
      }
    ]
  },
  {
    id: 10,
    slug: "clients-third-parties",
    title: "Working with Clients & Third Parties",
    subtitle: "Maintaining trust and professionalism in external relationships",
    duration: "20 min",
    color: "#0ea5e9",
    icon: "🤝",
    objectives: [
      "Understand your obligations when working at client sites",
      "Know how to handle information provided by third parties appropriately",
      "Understand the limits of your authority when representing the firm",
      "Maintain appropriate boundaries in client relationships"
    ],
    policyRefs: ["SI-POL-019: Client Engagement Policy", "SI-POL-020: Third Party Risk Management Policy", "SI-POL-004: Confidentiality Policy"],
    content: [
      {
        heading: "The Client Relationship and What It Requires",
        body: `The client relationship is the foundation of our business. Every engagement we conduct is based on a client's decision to trust us with access to their systems, their people, and their most sensitive information. That decision is not made lightly, and it is validated or undermined by every interaction our people have with the client over the course of the engagement.

When you are working on a client engagement, your conduct directly shapes the client's experience of the firm. This means conducting yourself professionally, communicating clearly and responsibly, keeping commitments you make to the client, managing the client's expectations about what we can and cannot deliver, and handling their information with evident care. Clients notice when information is handled casually, when commitments are not kept, and when they feel their trust is not being taken seriously. They also notice, and remember, when they feel genuinely well cared for.

You represent Security Impossible in every client interaction. This does not mean you need to be formal or stiff — professional warmth and genuine engagement are assets. It means that your competence, your honesty, and your ethical conduct all reflect on the firm's reputation, and that reputation has real commercial value.`
      },
      {
        heading: "Conduct at Client Sites",
        body: `When you are working at a client site — whether for a day or several weeks — you are a guest in their environment. You have been granted access to areas, systems, and information for specific purposes, and you should not exceed that authorisation. If you notice something interesting or relevant that was not part of your agreed scope, the correct response is to flag it through the appropriate engagement channel — not to investigate it independently.

Client sites often contain other confidential and sensitive information beyond what relates to your engagement. You may overhear conversations, see documents on desks, or have access to systems beyond your specific assessment scope. You should treat all information encountered at a client site as confidential even if it was not deliberately shared with you. Do not record, retain, or share observations beyond what is necessary for the engagement.

The authority to expand scope, change deliverables, or make commitments to clients rests with the engagement manager or engagement director, not with individual team members. If a client asks you to do something that is outside your authorised scope, the appropriate response is: "I appreciate the request — let me check with [engagement manager name] and come back to you." Making informal commitments to clients about work that has not been scoped and authorised creates contractual and operational problems.`
      },
      {
        heading: "Third-Party Subcontractors and Partners",
        body: `Security Impossible sometimes works with specialist subcontractors and partners on engagements. When third parties are involved in delivery, the firm's confidentiality obligations extend to information shared with those parties. Before sharing any client or firm confidential information with a third party, confirm that an appropriate non-disclosure agreement or contractual data protection provision is in place.

The fact that a third party has signed an NDA does not eliminate your responsibility to handle the information exchange carefully. Share only what the third party genuinely needs for their contribution. Do not share raw engagement data, personal information, or details beyond the specific scope of the third party's involvement. Maintain records of what information has been shared and with whom.

Third-party contractors who work directly within the firm — placed contractors, seconded staff, or consultants engaged through other means — are subject to the same information security obligations as direct employees. Their NDA, their access rights, and their security training requirements should be established before they commence work, not informally accumulated over time.`
      }
    ],
    scenarios: [
      {
        title: "The Over-Eager Client Site Discovery",
        situation: "While conducting an authorised penetration test scoped to the client's external web applications, you discover what appears to be a path that would give you access to the client's internal HR systems — well outside your agreed scope. The access looks technically possible and the finding would be significant.",
        outcome: "Stop immediately and document where you are. Do not proceed further into the out-of-scope system. Report the finding to your engagement manager who will coordinate with the client to determine the appropriate response. Proceeding without authorisation — even to find something genuinely important — constitutes unauthorised access to a computer system, which is illegal regardless of your intent. The client's authorisation is the basis of your legal permission to test. The scope definition is the boundary of that permission. A genuinely useful finding reported promptly through the correct channel is far more valuable than an unauthorised intrusion into an HR system, however interesting."
      },
      {
        title: "The Informal Commitment",
        situation: "A client's CISO asks you at the end of a meeting whether the firm could also review their mobile application security as part of the current engagement. You think it sounds feasible and tell the client 'we can certainly look at including that.' The CISO takes this as a commitment and mentions it to their CEO.",
        outcome: "An informal 'we can look at that' in a client conversation can quickly be interpreted as a commitment, creating expectations that may not align with what the firm is contractually obligated to deliver or what is feasible within the current engagement budget and timeline. The correct phrase is: 'That's certainly something we'd be happy to explore — let me raise it with [engagement manager] and come back to you with a clear answer on scope and timing.' Never make commitments on deliverables, scope, or timelines without confirming with the engagement manager first."
      }
    ]
  },
  {
    id: 11,
    slug: "commitment",
    title: "Putting It Together & Your Commitment",
    subtitle: "Completing your onboarding and confirming your responsibilities",
    duration: "10 min",
    color: "#10b981",
    icon: "✅",
    objectives: [
      "Consolidate the key principles from all modules",
      "Understand how to apply good judgment in novel situations",
      "Know where to go when you need guidance",
      "Make a formal commitment to uphold Security Impossible's security standards"
    ],
    policyRefs: ["SI-POL-001: Information Security Policy", "SI-POL-002: Employee Code of Conduct", "All policies referenced in Modules 1–10"],
    content: [
      {
        heading: "The Principles That Unite Everything",
        body: `You have now worked through ten modules covering the core dimensions of security governance at Security Impossible. Before you make your formal commitment, it is worth stepping back to recognise what all of these modules have in common.

They all rest on a small number of foundational principles. The first is that you exercise professional judgment, not just rule-following. Policies and guidelines are important, but they cannot cover every situation you will encounter. The goal of this training is to give you the principles and reasoning behind the rules, so that you can apply sound judgment in situations the rules do not explicitly address.

The second principle is that you prioritise caution over convenience. Most security failures occur not because people do not know the right thing to do, but because the wrong thing is more convenient in the moment. When security feels like friction — when it would be easier to share something through an unofficial channel, to skip a step because you are busy, or to use a tool that is fast but not approved — that friction is the control working as intended. Respecting those controls even under pressure is the mark of a security-mature professional.

The third principle is that you ask rather than assume. No one expects you to know every policy in detail. What we expect is that when you are unsure, you ask. The cost of asking is low. The cost of assuming and getting it wrong can be very high.`
      },
      {
        heading: "Where to Go for Help",
        body: `You should never feel alone when navigating a difficult security decision. The firm has a range of resources available to support you.

Your manager is your first point of contact for most questions. They have experience with the types of situations you will encounter and the authority to escalate questions that exceed their own certainty. If your manager is unavailable and a situation is urgent, their manager or the duty engagement director can assist.

The Information Security team handles security incident reporting, policy queries, and questions about approved tools and controls. They welcome early reporting of potential incidents — they would always rather investigate something that turns out to be nothing than miss something significant because a report came in too late.

The Privacy Officer handles questions about personal information, data breach assessments, and privacy compliance. The Legal and Compliance team handles questions about IP, contractual obligations, and regulatory requirements.

If you observe something that concerns you but you are not sure whether it rises to the level of a reportable incident, the appropriate action is always to raise it. You will not be criticised for being cautious. The whistle-blower protections applicable to the firm mean you can raise concerns without fear of reprisal.`
      },
      {
        heading: "What Your Commitment Means",
        body: `The commitment you are about to make is not a legal formality — it is a professional declaration. It means you have engaged with the content of this training program and understand the key principles of security governance at Security Impossible. It means you accept the obligations that come with the trust placed in you by the firm, its clients, and the individuals whose information you will handle.

It also means you commit to acting on this knowledge rather than treating it as information that has been delivered and stored. Security awareness is a perishable skill. The threat landscape changes. Policies are updated. New tools introduce new risks. We expect you to stay engaged with security as an ongoing professional responsibility, not a one-time box to check.

The most important thing you can do after completing this training is to carry its principles into your daily work — to be someone who naturally and visibly takes security seriously, who asks questions when uncertain, who raises concerns when something seems wrong, and who upholds the standard that our clients pay us to embody.`
      }
    ],
    scenarios: []
  }
];

export const CONTACTS = [
  { role: "Information Security Team", email: "security@securityimpossible.com.au", purpose: "Incident reporting, policy questions, approved tools" },
  { role: "Privacy Officer", email: "privacy@securityimpossible.com.au", purpose: "Privacy queries, data breach assessment" },
  { role: "Legal & Compliance", email: "legal@securityimpossible.com.au", purpose: "IP, contracts, regulatory compliance" },
  { role: "IT Helpdesk", email: "it@securityimpossible.com.au", purpose: "Technical support, equipment issues" },
];
