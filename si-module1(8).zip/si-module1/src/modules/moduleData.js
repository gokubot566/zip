// ── Security Impossible — Onboarding Security & Governance Course v2 ──────────
// Module data aligned with Onboarding_Security_Governance_Course_v2.docx
// ─────────────────────────────────────────────────────────────────────────────

export const POLICY_LIBRARY = [
  { id: 'pol-asset',     title: 'Asset Management Policy',                  modules: [6] },
  { id: 'pol-data',      title: 'Data Handling Policy',                     modules: [2, 5, 7, 9, 10] },
  { id: 'pol-info',      title: 'Information Management Policy',            modules: [2, 3, 5, 6, 7, 8, 10] },
  { id: 'pol-ip',        title: 'Intellectual Property Handling Policy',    modules: [2, 3, 8, 9, 10] },
  { id: 'pol-social',    title: 'Social Media Sharing Policy',              modules: [9] },
  { id: 'pol-privacy',   title: 'Privacy Policy',                           modules: [4] },
  { id: 'pol-aup',       title: 'Acceptable Use Policy',                    modules: [8] },
  { id: 'pol-ir',        title: 'Incident Response Policy',                 modules: [7] },
  { id: 'pol-ai',        title: 'AI Use Policy',                            modules: [8] },
  { id: 'pol-remote',    title: 'Remote Work Policy',                       modules: [6] },
  { id: 'pol-deed',      title: 'Employee Confidentiality & IP Deed',       modules: [2, 3, 11], signed: true },
];

export const ALL_MODULES = [
  // ── Module 1 ────────────────────────────────────────────────────────────────
  {
    id: 1,
    title: 'Welcome & Why Security Matters Here',
    subtitle: 'Foundational — introduces all policies',
    duration: '15 min',
    icon: '🛡️',
    color: '#3b82f6',
    policyAck: [],   // no policy acknowledgement required for Module 1
    keyPoints: [
      'Security Impossible sells trust — our security posture is proof of our credibility',
      'A single breach harms every client relationship, not just one',
      'Your obligations apply from day one — before your first client interaction',
      'Most breaches are accidental; awareness is your best defence',
    ],
    content: [
      {
        heading: 'We Sell Trust',
        body: `Security Impossible is in the business of protecting other organisations. That means our own security posture is not just an internal matter — it is the proof of our credibility. A client will not trust us to assess their security if we cannot manage our own. Every employee is part of that proof.

Our clients — educational institutions, government bodies, and enterprises — hand us access to their data, their environments, and their people on the understanding that we hold ourselves to a higher standard than anyone else. A single confidentiality breach, leaked client relationship, or mishandled piece of personal information does not just create a legal problem; it undermines the entire premise of our business.`,
      },
      {
        heading: 'The Stakes Are Real',
        body: `Consider what we hold: client data and access from engagements, the personal information of learners on our platform, our own proprietary lab content and methodology, and commercial information about deals and pricing. If any of this leaks, is stolen, or is mishandled, the consequences range from losing a client, to legal liability under privacy law, to losing the company's reputation entirely.

In security, trust is hard to win and instant to lose. Every employee is part of that proof — which means every careless action, every casual disclosure, and every convenience shortcut carries a risk that is disproportionate to what it would mean at most other companies.`,
      },
      {
        heading: 'This Applies To You From Day One',
        body: `Your obligations around confidentiality, data handling, and acceptable use are in effect from your first day — and many of them continue after you leave. This course explains what those obligations are, in plain language, so you can meet them confidently.

You do not need to memorise every policy from day one. What you need to do is understand the principles behind them so that when you face a real situation, you make the right call instinctively. That is what this course is for.`,
      },
      {
        heading: 'What We Hold — and What That Means',
        body: `The information Security Impossible holds falls into several important categories. We handle client data and access details from live engagements. We hold the personal information of learners on our platform. We possess proprietary lab content, scenarios, walkthroughs, and methodology that represent our core commercial assets. We manage commercial information about deals, pricing, and pipeline.

Each of these categories carries legal obligations, contractual obligations, or both. Mishandling any of them — even accidentally — can trigger regulatory action, client claims, and reputational harm. Understanding this context is why Module 1 comes before everything else.`,
      },
    ],
    scenario: {
      title: 'The Coffee Shop Question',
      setup: "On your second day at Security Impossible, a friend who works at another company asks you over coffee: 'So what does Security Impossible actually do? Who are your clients?'",
      message: '"Come on, you can tell me! Who are some of your big clients? What kind of work do you actually do for them?"',
      options: [
        {
          id: 'a',
          text: "We work with some government bodies and a couple of big financial institutions. Last week we finished a red-team engagement — found some really critical stuff.",
          correct: false,
          feedback: "❌ This discloses client identity and engagement details — both are confidential. Even with a trusted friend over an informal coffee, naming clients or describing specific engagements is a breach of your obligations from day one.",
        },
        {
          id: 'b',
          text: "We do cybersecurity consulting — assessments, advisory, that kind of thing. I can't name clients or describe specific projects, but you can get a feel for the work from the public website.",
          correct: true,
          feedback: "✅ This is exactly right. You've described the company in general terms that are already public, protected confidential client relationships, and redirected your friend to a legitimate source. Professional, warm, and compliant.",
        },
        {
          id: 'c',
          text: "I can't say much, but between us — we work across finance and government mostly. Not supposed to say more than that.",
          correct: false,
          feedback: "⚠️ 'Between us' provides no legal protection, and hinting at sectors still narrows the field. Even a sector description can help an observer figure out who our clients are. When in doubt, share nothing specific.",
        },
        {
          id: 'd',
          text: "I honestly can't say anything specific about clients — it's confidential. But I can tell you about the type of work we do generally, and there's good info on the website.",
          correct: true,
          feedback: "✅ Also correct. Clear, professional, and redirects to public information without disclosing anything confidential. This is the standard to aim for.",
        },
      ],
    },
    quiz: [
      {
        q: "True or false: because we are a security company, our internal security standards can be more relaxed — we already know what we're doing.",
        opts: ["True — internal expertise reduces the need for formal controls", "False — our security posture IS our proof of credibility to clients", "True — but only for technical staff", "False — but only senior staff need to follow all controls"],
        correct: 1,
        exp: "False. A security consulting firm that cannot manage its own security is not credible to clients. Our internal standards must be at least as high as what we recommend externally.",
      },
      {
        q: "Which of the following best describes why a confidentiality breach harms Security Impossible more than it would harm a typical company?",
        opts: ["We have more data to protect", "Our entire business model is built on clients trusting us with their security — a breach undermines that premise entirely", "We face higher regulatory penalties", "Our staff are held to stricter legal standards"],
        correct: 1,
        exp: "Security Impossible sells trust. If we cannot protect information ourselves, clients have no reason to trust us with theirs. The harm to a security consulting firm is existential in a way it would not be for most businesses.",
      },
      {
        q: "Your obligations around confidentiality, data handling, and acceptable use begin:",
        opts: ["After completing all 11 onboarding modules", "On your first day", "After your probation period ends", "When you first access a client engagement"],
        correct: 1,
        exp: "Your obligations begin from day one — before your first client interaction, before you complete this course, and before you receive any explicit briefing. The employment relationship itself creates these obligations.",
      },
      {
        q: "A friend asks which clients Security Impossible works with. The best response is:",
        opts: ["Name a few well-known clients to demonstrate credibility", "Describe the company in general public terms only, and direct them to the public website", "Say you can share one or two names since they're trustworthy", "Share sector information but not specific names"],
        correct: 1,
        exp: "Client relationships are confidential. You can describe what the company does in terms already public, but must not name clients or describe specific engagements. When in doubt, share nothing specific.",
      },
    ],
    policies: [
      {
        ref: 'Foundational',
        title: 'This module introduces all policies',
        summary: 'Module 1 sets the context for the entire course. Every subsequent module maps directly to specific Security Impossible policies listed below.',
        obligations: [
          'Understand why security obligations exist before learning what they are',
          'Recognise that trust — not technology — is the firm\'s primary commercial asset',
          'Accept that obligations begin on day one and many persist after departure',
          'Know that the policy library is the authoritative source for all obligations',
        ],
      },
      {
        ref: 'Policy Library',
        title: 'Security Impossible Policy Library',
        summary: 'These are the source documents referenced throughout this course. The policies are authoritative — the course exists to help you understand them in context.',
        obligations: [
          'Asset Management Policy — covered in Module 6',
          'Data Handling Policy — covered in Modules 2, 5, 7, 9, 10',
          'Information Management Policy — covered across multiple modules',
          'Intellectual Property Handling Policy — covered in Modules 2, 3, 8, 9, 10',
          'Social Media Sharing Policy — covered in Module 9',
          'Privacy Policy — covered in Module 4',
          'Acceptable Use Policy — covered in Module 8',
          'Incident Response Policy — covered in Module 7',
          'AI Use Policy — covered in Module 8',
          'Remote Work Policy — covered in Module 6',
          'Employee Confidentiality & IP Deed — signed on commencement',
        ],
      },
      {
        ref: 'Data Classification',
        title: 'Four-Tier Classification Overview',
        summary: 'Security Impossible uses a single four-tier classification for all data: Public, Internal, Confidential, and Highly Confidential. Module 5 covers this in full detail.',
        obligations: [
          'PUBLIC — approved for release; no restrictions (e.g. published blog posts, marketing material)',
          'INTERNAL — business information not for public disclosure; keep within the company',
          'CONFIDENTIAL — all internal and client IP; strict access control; shared only with authorised people',
          'HIGHLY CONFIDENTIAL — all personal information (PII) and anything whose disclosure could critically harm the company or individuals; highest protection, encryption mandatory',
        ],
      },
    ],
  },

  // ── Module 2 ────────────────────────────────────────────────────────────────
  {
    id: 2,
    title: 'Confidentiality & Your Obligations',
    subtitle: 'Data Handling Policy · Information Management Policy · Intellectual Property Handling Policy · Employee Confidentiality & IP Deed',
    duration: '20 min',
    icon: '🔒',
    color: '#8b5cf6',
    policyAck: ['Data Handling Policy', 'Information Management Policy', 'Employee Confidentiality & IP Deed'],
    keyPoints: [
      'If unsure whether something is confidential, treat it as confidential until you confirm',
      'Client identity — the fact of who our clients are — is itself confidential',
      'Confidentiality obligations continue indefinitely after you leave',
      'Most breaches are accidental — awareness is your best defence',
    ],
    scenario: {
      title: 'The Café Video Call',
      setup: "You are working from a café and join a video call to discuss a client engagement. The person at the next table can hear your conversation, and your screen showing the client's network diagram is visible to anyone walking past.",
      message: '"I\'m on the call now — you can see my screen right? Let\'s go through the client\'s environment setup..."',
      options: [
        { id: 'a', text: "Continue the call — it's just a café, no one is paying attention.", correct: false, feedback: "❌ Both are confidentiality breaches in the making. Confidential conversations must not happen in public spaces, and screens showing confidential material must not be visible to others." },
        { id: 'b', text: "Pause the call, move to a private location, and use a privacy screen — then rejoin when the environment is secure.", correct: true, feedback: "✅ Correct. Work on client material from a private location, use a privacy screen, and never discuss client specifics where you can be overheard. Both issues need to be resolved before continuing." },
        { id: 'c', text: "Turn the screen slightly so it's harder to see, then continue.", correct: false, feedback: "⚠️ This is insufficient. 'Harder to see' is not a security control. The standard is that confidential screens must not be visible to unauthorised people — period." },
        { id: 'd', text: "Continue the audio but stop sharing your screen.", correct: false, feedback: "⚠️ Closer, but the audio conversation is still a problem if others can overhear. Confidential conversations require a private location, not just a private screen." },
      ],
    },
    quiz: [
      { q: "Which of these is confidential information at Security Impossible?", opts: ["Our published blog posts", "The identity of who our clients are", "Our public pricing page", "Job postings on our website"], correct: 1, exp: "Client identity — the very fact of who our clients are — is confidential information, regardless of whether it appears in any document. The Data Handling Policy defines this explicitly." },
      { q: "True or false: once you leave Security Impossible, your confidentiality obligations end.", opts: ["True — obligations only exist during employment", "False — confidentiality obligations continue indefinitely after departure", "True — after 12 months", "False — but only for named clients in your last engagement"], correct: 1, exp: "False. Confidentiality obligations continue indefinitely after you leave Security Impossible. You cannot take client information, lab content, or methodology to your next role, and you cannot disclose it even years later." },
      { q: "How do most confidentiality breaches happen?", opts: ["Deliberate theft by disgruntled employees", "Sophisticated hacking of company systems", "Accidentally — casual conversation, sending to personal email, discussing in public", "Competitor espionage"], correct: 2, exp: "Most confidentiality breaches are accidental. They happen through casual conversation in public spaces, sending information to personal email 'to work on later,' or leaving documents visible. Awareness is your best defence." },
      { q: "When you are unsure whether something is confidential, you should:", opts: ["Treat it as Internal until confirmed", "Share it and note you weren't sure", "Treat it as Confidential until you confirm otherwise", "Ask the recipient to sign an NDA first"], correct: 2, exp: "The Data Handling Policy is explicit: if you are unsure whether something is confidential, treat it as confidential until you confirm otherwise. Default to protection, not disclosure." },
    ],
    policies: [
      { ref: 'SI-POL-DATA', title: 'Data Handling Policy', summary: 'Governs how all data — including client data, personal information, and company IP — must be handled, stored, transmitted, and disposed of throughout its lifecycle.', obligations: ['Treat client identity as confidential by default', 'Handle data according to its classification tier', 'Never communicate confidential data informally or outside approved systems', 'Dispose of data securely when it is no longer needed'] },
      { ref: 'SI-POL-INFO', title: 'Information Management Policy', summary: 'Sets out the company-wide framework for managing information assets, including access control, retention, and the use of company systems.', obligations: ['Use company systems only for all work-related information handling', 'Apply least-privilege access — access only what your role requires', 'Do not retain information beyond its authorised retention period', 'Escalate any uncertainty about information handling to your lead'] },
      { ref: 'SI-DEED', title: 'Employee Confidentiality & IP Deed', summary: 'The signed deed that formalises your confidentiality and IP obligations. It is a legal document signed at commencement and its obligations survive employment.', obligations: ['Signed at commencement — read it in full before signing', 'Confidentiality obligations survive the end of your employment', 'All company IP created during employment belongs to the company', 'Breaching the deed may result in legal action'] },
    ],
    content: [
      { heading: 'What Counts as Confidential', body: `Confidential information is anything not already public that you encounter through your work. This includes client data and the very fact of who our clients are, internal methodology and lab content, commercial terms and pricing, colleague and employee information, and our proprietary software.\n\nIf you are unsure whether something is confidential, treat it as confidential until you confirm otherwise. This is not overcaution — it is the standard the Data Handling Policy sets, and it is the right instinct for a security company.` },
      { heading: 'Your Obligations Survive Your Employment', body: `This is critical and often misunderstood: your duty to keep information confidential does not end on your last day. Confidentiality obligations continue indefinitely after you leave Security Impossible. You cannot take client information, lab content, or methodology to your next role, and you cannot disclose it even years later.\n\nThis is formalised in the Employee Confidentiality & IP Deed that you sign at commencement. Read it carefully — it is a legal document, and its obligations are enforceable.` },
      { heading: 'How Breaches Actually Happen', body: `Most confidentiality breaches are accidental, not malicious. They happen through casual conversation in public spaces, sending information to a personal email 'to work on later,' discussing a client by name on a call where others can hear, or leaving documents visible on a screen during a video call.\n\nAwareness of these everyday risks is your best defence. The question is not 'could this be deliberate sabotage?' — it is 'could this be overheard, seen, or forwarded without authorisation?' If yes, do not do it.` },
    ],
  },

  // ── Module 3 ────────────────────────────────────────────────────────────────
  {
    id: 3,
    title: 'Intellectual Property & Ownership',
    subtitle: 'Intellectual Property Handling Policy · Information Management Policy · Employee Confidentiality & IP Deed',
    duration: '15 min',
    icon: '⚖️',
    color: '#f59e0b',
    policyAck: ['Intellectual Property Handling Policy', 'Employee Confidentiality & IP Deed'],
    keyPoints: [
      'Work created within scope of employment belongs to Security Impossible',
      'Lab content, scenarios, and methodology are core commercial assets — protect them',
      'Open-source licences must be checked before use — GPL can create real legal exposure',
      'Never input confidential or client information into public AI tools',
    ],
    scenario: {
      title: 'The GPL Lab',
      setup: "You find a great open-source vulnerable web application on GitHub. Its licence is GPL, which requires derivative works to also be open-sourced. You want to adapt it into a commercial lab.",
      message: '"This would be perfect for the lab I\'m building. Can I just incorporate it and we\'ll sort the licensing later?"',
      options: [
        { id: 'a', text: "Yes — it's open source so it's free to use however we want.", correct: false, feedback: "❌ Open source does not mean unrestricted. GPL specifically requires derivative works to also be open-sourced, which conflicts directly with our commercial licensing model." },
        { id: 'b', text: "Stop and check the licence implications. Raise it with your lead before using it — GPL may conflict with our commercial content licensing.", correct: true, feedback: "✅ Correct. A GPL share-alike obligation may conflict with how we license our commercial content. Raise it with your lead so the licensing is handled correctly — do not just incorporate it and hope. Getting open-source licensing wrong is a real legal risk." },
        { id: 'c', text: "Use it but don't tell anyone which library it came from.", correct: false, feedback: "❌ Concealing the source doesn't resolve the licence obligation — it makes the problem worse. GPL requires attribution at minimum, and concealment could constitute wilful infringement." },
        { id: 'd', text: "Incorporate it but add a note in the code that it came from a GPL source.", correct: false, feedback: "⚠️ Attribution alone doesn't satisfy GPL's share-alike requirement. You still need to raise this with your lead and get a legal determination before using it in commercial content." },
      ],
    },
    quiz: [
      { q: "Work you create during employment hours, related to your job:", opts: ["Belongs to you personally", "Belongs to Security Impossible", "Is jointly owned by you and the company", "Depends on whether you were paid overtime"], correct: 1, exp: "Work created within the scope of your employment belongs to Security Impossible. This includes labs, documentation, code, scenarios, and designs produced as part of your job." },
      { q: "What must you check before using an open-source component in company content?", opts: ["That it has more than 100 GitHub stars", "That the licence permits our commercial use and follow its requirements", "That it was published in the last 2 years", "That it is written in an approved programming language"], correct: 1, exp: "Different open-source licences carry different obligations. GPL requires share-alike. Some restrict commercial use. Using a component in a way that breaches its licence creates real legal exposure. Always confirm the licence before incorporating." },
      { q: "You use ChatGPT to help write a lab walkthrough and paste in a client's actual environment details. This is:", opts: ["Acceptable if you delete the chat history afterwards", "A serious breach — client data has been disclosed to an external party", "Fine if the client gave verbal permission", "Acceptable for internal use only"], correct: 1, exp: "Never input confidential or client information into third-party AI tools. You have just disclosed client data to an external party — a serious breach of the Data Handling Policy and potentially the engagement contract." },
      { q: "When you leave Security Impossible, you may take:", opts: ["Copies of labs you personally built", "Client engagement files from recent projects", "Your general skills and professional knowledge — not company IP", "Methodology documents you found useful"], correct: 2, exp: "You may take your general skills and professional knowledge. You may not take company IP — lab content, code, methodology, client materials, or documentation. Copying these before departure is a serious breach with legal consequences." },
    ],
    policies: [
      { ref: 'SI-POL-IP', title: 'Intellectual Property Handling Policy', summary: 'Defines who owns IP created during employment, obligations around open-source licensing, AI-generated content rules, and what employees may and may not take when they leave.', obligations: ['Company owns all IP created within scope of employment', 'Confirm open-source licence compatibility before incorporating into company products', 'AI technologies developed during employment belong to the company', 'Never take company IP when you leave — doing so has legal consequences'] },
      { ref: 'SI-POL-INFO', title: 'Information Management Policy', summary: 'Covers how proprietary company information — including lab content, methodology, and commercial IP — must be stored, accessed, and protected.', obligations: ['Lab content and methodology are classified Confidential', 'Store proprietary content only on company systems', 'Report any significant AI technology or IP you create for management review', 'Do not post screenshots of internal labs or methodology publicly'] },
    ],
    content: [
      { heading: 'Why IP Matters So Much Here', body: `Our lab content, scenarios, walkthroughs, methodology, course designs, and code are the core commercial assets of the business. They are what clients pay for. Protecting this IP — and respecting others' IP — is central to everyone's role.\n\nThe same IP that represents our competitive advantage is also a target. A competitor who gets access to our lab content has our product. A regulator who discovers we violated a third-party licence has grounds for legal action. Both scenarios are preventable through disciplined IP management.` },
      { heading: 'Open-Source Licensing — Get This Right', body: `Our platform runs on an open-source stack, which is a commercial advantage — but only if we honour the licences. Different open-source licences carry different obligations: attribution requirements, share-alike restrictions, and restrictions on commercial use.\n\nUsing an open-source component in a way that breaches its licence creates real legal exposure. When you incorporate any third-party or open-source tool, library, or content, confirm the licence permits our use and follow its requirements. When in doubt, raise it with your lead before using it — not after.` },
      { heading: 'AI Tools & AI-Generated Content', body: `AI technologies developed during your employment belong to the company. When using third-party AI tools, you must comply with their licences and never input confidential or client information into them (Module 8 covers this in detail).\n\nYou must also verify that AI-generated outputs do not infringe others' copyright or reproduce proprietary material. AI tools can reproduce training data — including potentially copyrighted content — without flagging it. The verification obligation sits with you.` },
    ],
  },

  // ── Module 4 ────────────────────────────────────────────────────────────────
  {
    id: 4,
    title: 'Privacy & the Australian Privacy Principles',
    subtitle: 'Privacy Policy · Data Handling Policy · Information Management Policy',
    duration: '25 min',
    icon: '🔐',
    color: '#10b981',
    policyAck: ['Privacy Policy'],
    keyPoints: [
      'Personal information: any info about an identified or identifiable individual',
      'Sensitive information (health, biometric, etc.) requires higher protection',
      'NDB scheme: report suspected breaches immediately — legal timeframes apply',
      'Learner email lists and client employee records are regulated personal data',
    ],
    scenario: {
      title: 'The Spreadsheet Request',
      setup: "During a client engagement you are given a spreadsheet of the client's employees, including names, emails, and in some cases health-related accommodation notes. A colleague not on the engagement asks you to forward it so they can 'have a look.'",
      message: '"Can you just forward me that spreadsheet? I\'m curious what their team structure looks like."',
      options: [
        { id: 'a', text: "Forward it — they're a trusted colleague and it's just internal.", correct: false, feedback: "❌ Do not forward it. This is personal information (names, emails) and the health notes are sensitive information under the APPs. It is classified Highly Confidential and may only be accessed by those authorised on the engagement." },
        { id: 'b', text: "Forward a version with the health notes removed.", correct: false, feedback: "⚠️ Still incorrect. The engagement data as a whole is restricted to those authorised on the engagement — the colleague has no authorisation regardless of which fields are included. Sharing it would breach access-control rules and privacy law." },
        { id: 'c', text: "Decline to forward it and explain that engagement data is restricted to authorised personnel only.", correct: true, feedback: "✅ Correct. This data may only be accessed by those authorised on the engagement and used only for the engagement purpose. Sharing it with an unauthorised colleague breaches both the access-control rules and the Privacy Act's APP 6 (use and disclosure)." },
        { id: 'd', text: "Check with the client first, then forward if they agree.", correct: false, feedback: "⚠️ Closer, but the process for expanding access to engagement data goes through your lead, not a direct client check. And informal client permission does not override the access-control framework — that authorisation needs to be documented properly." },
      ],
    },
    quiz: [
      { q: "Sensitive information under the Privacy Act includes:", opts: ["Business email addresses", "Health information, racial or ethnic origin, sexual orientation, biometric data", "Names and phone numbers", "All information stored digitally"], correct: 1, exp: "Sensitive information is a special subset of personal information that requires higher protection. It includes health information, racial or ethnic origin, political or religious beliefs, sexual orientation, criminal record, and biometric data." },
      { q: "Under the Notifiable Data Breaches scheme, who must be notified if a breach is likely to cause serious harm?", opts: ["Only the affected individuals", "Only the OAIC", "Both the affected individuals and the Office of the Australian Information Commissioner (OAIC)", "Only the company's board"], correct: 2, exp: "Under the NDB scheme, both the affected individuals and the OAIC must be notified when a breach is likely to result in serious harm. There are strict assessment and notification timeframes — which is why immediate reporting of suspected breaches is not optional." },
      { q: "A list of learner email addresses from the company's platform is:", opts: ["Public information — email addresses are widely shared", "Internal information only — no special rules apply", "Regulated personal information under the Privacy Act", "Only regulated if it contains names as well"], correct: 2, exp: "Email addresses associated with identifiable individuals are personal information under the Privacy Act 1988. A list of learner email addresses is regulated data and must be treated as Confidential at minimum." },
      { q: "The Privacy Act requires you to use personal information:", opts: ["For any company business purpose", "Only for the specific purpose for which it was collected", "Until the person asks you to stop", "As long as it remains within company systems"], correct: 1, exp: "APP 6 restricts use and disclosure of personal information to the purpose for which it was collected. Using engagement-related employee data for an unrelated purpose — even within the company — breaches this principle." },
    ],
    policies: [
      { ref: 'SI-POL-PRIV', title: 'Privacy Policy', summary: "Governs how Security Impossible collects, uses, stores, and discloses personal information in compliance with the Privacy Act 1988 and the 13 Australian Privacy Principles.", obligations: ['Collect only what you need for the specific engagement purpose', 'Use personal information only for the purpose it was collected', 'Handle sensitive information (health, biometric, etc.) with highest protection', 'Report suspected privacy breaches immediately — NDB timeframes are legally binding'] },
    ],
    content: [
      { heading: 'Why Privacy Law Applies To Us', body: `Security Impossible handles personal information — about clients' staff, about learners on our platform, and about our own employees. In Australia, the handling of personal information is governed by the Privacy Act 1988 and the 13 Australian Privacy Principles (APPs). As an organisation handling this data, we have legal obligations, and breaching them can result in regulatory action and significant penalties.\n\nThe fact that we are a security company does not exempt us — it heightens our obligations. Our clients trust us specifically because we hold ourselves to a higher standard.` },
      { heading: 'The Notifiable Data Breaches Scheme', body: `Under the NDB scheme, if a data breach is likely to result in serious harm to individuals whose personal information is involved, Security Impossible is legally required to notify both the affected individuals and the OAIC. There are strict assessment and notification timeframes.\n\nThis is why reporting a suspected breach immediately is not optional — the company's legal compliance depends on knowing quickly. Do not wait to see if something 'actually becomes a problem.' Report it and let the team assess.` },
      { heading: 'What This Means For You Day to Day', body: `When you handle any personal information — a list of learner email addresses, a client's employee records during an engagement, a colleague's details — you are handling regulated data. Treat it as Confidential or Highly Confidential, use it only for its intended purpose, and never share it beyond those authorised.\n\nThe 13 APPs do not need to be memorised in full. But you should recognise that personal information carries obligations, and that when you receive it in an engagement context, the rules around who can see it, how long you keep it, and how you dispose of it all apply immediately.` },
    ],
  },

  // ── Module 5 ────────────────────────────────────────────────────────────────
  {
    id: 5,
    title: 'Data Classification & Handling',
    subtitle: 'Data Handling Policy · Information Management Policy · Asset Management Policy',
    duration: '20 min',
    icon: '📊',
    color: '#ef4444',
    policyAck: ['Data Handling Policy', 'Information Management Policy'],
    keyPoints: [
      'Four tiers: Public, Internal, Confidential, Highly Confidential',
      'Highly Confidential = all personal information (PII) — highest protection, encryption mandatory',
      'All data lives on company systems — no personal devices, no personal cloud',
      'Never communicate confidential data informally or outside approved channels',
    ],
    scenario: {
      title: 'The Quick Share',
      setup: "You need to share a confidential lab design with a teammate quickly and think about pasting it into a personal messaging app since it's faster than the company system.",
      message: '"It\'ll only take a second — I\'ll just paste it into WhatsApp, it\'s quicker."',
      options: [
        { id: 'a', text: "Do it — it's internal, just between colleagues, and it's faster.", correct: false, feedback: "❌ Confidential data must stay within company-provided systems and be shared through approved, access-controlled channels. Moving it outside company systems breaches the Data Handling Policy regardless of who the recipient is." },
        { id: 'b', text: "Use the company-approved channel even though it's slightly slower.", correct: true, feedback: "✅ Correct. Informal communication of confidential data and moving it outside company systems both breach policy. Use the approved internal channel even if it is slightly slower. The efficiency gain is not worth the compliance risk." },
        { id: 'c', text: "Paste just the key parts, not the whole document.", correct: false, feedback: "❌ Partial disclosure of confidential data through an unapproved channel is still a breach. The issue is the channel, not the volume of content." },
        { id: 'd', text: "Ask your manager first, then use WhatsApp if they agree.", correct: false, feedback: "⚠️ A verbal manager approval doesn't override the policy requirement to use company-approved channels. Your manager also cannot approve policy breaches informally." },
      ],
    },
    quiz: [
      { q: "Put these in order from least to most restricted:", opts: ["Public → Highly Confidential → Confidential → Internal", "Internal → Public → Confidential → Highly Confidential", "Public → Internal → Confidential → Highly Confidential", "Confidential → Public → Internal → Highly Confidential"], correct: 2, exp: "The four tiers from least to most restricted: Public (no restrictions) → Internal (keep within company) → Confidential (strict access control, encryption) → Highly Confidential (all PII, encryption mandatory, tightly restricted)." },
      { q: "Which classification covers personal information?", opts: ["Internal", "Confidential", "Highly Confidential", "Public"], correct: 2, exp: "All personal information (PII) is classified Highly Confidential under Security Impossible's data classification scheme. It requires the highest level of protection, with encryption mandatory and tightly restricted access." },
      { q: "True or false: it is acceptable to use a personal messaging app to share confidential data if it is faster.", opts: ["True — speed justifies the exception", "False — confidential data must only be shared through approved company channels", "True — if both parties work at the company", "False — unless both parties sign an NDA first"], correct: 1, exp: "False. Confidential data must stay within company-provided systems and be shared through approved, access-controlled channels. No efficiency argument overrides this." },
      { q: "All work must be done on company-provided systems because:", opts: ["Personal devices are slower", "It keeps data inside controlled, monitored, secured environments", "Personal devices are not covered by company insurance", "It makes it easier for IT to provide support"], correct: 1, exp: "The use of company systems is not just a convenience rule. It keeps data inside environments the company controls, monitors, and secures. Moving data outside those environments removes all those protections." },
    ],
    policies: [
      { ref: 'SI-POL-DATA', title: 'Data Handling Policy', summary: 'The comprehensive data handling policy covering classification, storage, transmission, access control, and disposal requirements for all four data tiers.', obligations: ['Apply the four-tier classification to all data you create or receive', 'Encrypt Confidential and Highly Confidential data at rest and in transit', 'Access data on a least-privilege, need-to-know basis', 'Dispose of data securely — no informal deletion or physical waste-bin disposal'] },
      { ref: 'SI-POL-INFO', title: 'Information Management Policy', summary: 'Sets requirements for company systems use, access control, and the handling of information assets throughout their lifecycle.', obligations: ['All work must be done on company-provided virtual machines and systems', 'Data must never be transferred to personal devices or personal cloud storage', 'Apply role-based access control — access only what your role requires', 'Never store company data on inadequately protected locations or in countries without equivalent protection'] },
    ],
    content: [
      { heading: 'The Four-Tier Classification in Full', body: `Security Impossible classifies all data into four levels. Public is approved for public release — no restrictions (e.g. published blog posts, marketing material). Internal is for business use but not for outside disclosure (e.g. internal process docs, team plans). Confidential includes all internal and client IP, including lab content, methodology, and commercial terms — requires strict access control and encryption. Highly Confidential includes all personal information (PII) and anything whose disclosure could critically harm the company or individuals — highest protection, encryption mandatory, tightly restricted access.\n\nKnowing the level tells you how to handle it. When you receive or create any piece of information, determining its classification is your first obligation.` },
      { heading: 'Handling Rules That Always Apply', body: `Confidential and Highly Confidential data must be encrypted both at rest and in transit, accessed only on a least-privilege basis, and disposed of securely (secure deletion for digital, shredding for physical). Data must never be communicated informally, stored indefinitely, transferred to inadequately protected locations or countries, or distributed to unauthorised parties.\n\nUse company systems only. All work must be done on company-provided virtual machines and systems. This is a strict rule — it keeps data inside controlled, monitored, secured environments. Company data lives on company systems, full stop.` },
    ],
  },

  // ── Modules 6-11 (condensed but complete) ───────────────────────────────────
  {
    id: 6,
    title: 'Asset Management & Secure Workplace Practices',
    subtitle: 'Asset Management Policy · Information Management Policy · Remote Work Policy',
    duration: '15 min', icon: '💻', color: '#06b6d4',
    policyAck: ['Asset Management Policy', 'Remote Work Policy'],
    keyPoints: [
      'No personal devices for company work — no exceptions, ever',
      'Never transfer company data to personal devices or personal email',
      'Company systems are monitored — this protects you and the company',
      'Report lost or stolen devices immediately — speed limits the damage',
    ],
    scenario: {
      title: 'The Fast Laptop',
      setup: "Your company VM is running slowly and you are on a deadline. Your personal laptop is much faster, so you are considering copying the project files over to finish the task tonight.",
      message: '"My VM is really slow — can I just copy the files to my personal laptop to finish this tonight?"',
      options: [
        { id: 'a', text: "Yes — just for tonight, and you'll delete them after.", correct: false, feedback: "❌ Absolutely not. Using a personal device for company work and transferring company data to it are both strict breaches that can lead to termination and legal action. The rule exists precisely to prevent data ending up on uncontrolled devices." },
        { id: 'b', text: "Report the VM performance issue to IT and work within the company environment until it's resolved.", correct: true, feedback: "✅ Correct. Report the VM performance issue to IT and work within the company environment. No deadline justifies transferring company data to a personal device — the rule is absolute." },
        { id: 'c', text: "Use the personal laptop but connect through the company VPN.", correct: false, feedback: "❌ The VPN doesn't resolve the issue. The data would still be on a personal device outside the company's controlled environment. VPN protects network traffic, not device security." },
        { id: 'd', text: "Ask your manager for permission first.", correct: false, feedback: "❌ Your manager cannot grant permission to breach the Asset Management Policy. The prohibition on personal devices is non-negotiable and cannot be waived informally." },
      ],
    },
    quiz: [
      { q: "True or false: you may use your personal laptop for company work if your company VM is having problems.", opts: ["True — it's a reasonable exception for genuine technical issues", "False — personal devices may never be used for company work under any circumstances", "True — if your manager approves", "False — unless you use the VPN"], correct: 1, exp: "False. The prohibition on personal devices is absolute. Report the VM issue to IT and work within the company environment. No business urgency or technical issue creates an exception." },
      { q: "Company-provided systems are monitored because:", opts: ["The company doesn't trust employees", "It allows IT to detect threats, prevent data loss, and protect the company and employees", "It is required by government regulation", "It helps the company improve system performance"], correct: 1, exp: "Monitoring is not about distrust — it is how the company detects threats, prevents data loss, and protects both you and the organisation. By using company systems you accept this monitoring." },
      { q: "If your company device is lost or stolen, you should:", opts: ["Wait 24 hours to see if it turns up", "Report it immediately to IT and your lead", "Change all your passwords on a personal device and then report", "Buy a replacement and report at end of month"], correct: 1, exp: "Speed matters — fast reporting lets the company lock down access before damage is done. Report immediately to IT and your lead, not after waiting to see if the device turns up." },
      { q: "Working securely from home means:", opts: ["Using any Wi-Fi network available", "Keeping your screen locked when away, avoiding public Wi-Fi, keeping your work area private during calls", "Only working during normal office hours", "Not taking calls near other household members"], correct: 1, exp: "Remote work extends the security perimeter to your home. Keep your screen locked when away, avoid public Wi-Fi (or use the company VPN), keep your work area private during calls, and physically secure your company devices." },
    ],
    policies: [
      { ref: 'SI-POL-ASSET', title: 'Asset Management Policy', summary: 'Covers company device requirements, the prohibition on personal device use, monitoring obligations, and procedures for reporting lost or stolen devices.', obligations: ['All work-related tasks must be done on company-provided VMs and systems', 'Never use personal devices for company work or to access company data', 'Never transfer company data to personal devices, email, or cloud storage', 'Report lost or stolen devices immediately'] },
      { ref: 'SI-POL-REMOTE', title: 'Remote Work Policy', summary: 'Sets out the security requirements for working remotely, including device, network, and physical environment standards.', obligations: ['Keep screen locked when stepping away from your device', 'Avoid public Wi-Fi for company work — use VPN if required', 'Keep your work area private during video calls', 'Report any suspicious activity or security concerns immediately'] },
    ],
    content: [
      { heading: 'Company Devices and VMs Only — No Exceptions', body: `This is one of the strictest and most important rules, and new employees often trip over it. All work-related tasks — data processing, communication, accessing company networks — must be done on company-provided virtual machines and systems. Personal devices (personal computers, phones, tablets, external storage) must not be used for company business or to access company data under any circumstances.\n\nThis prevents data exfiltration and keeps malware out of our environment. The rule exists for everyone's protection — yours included.` },
      { heading: 'Your Assets Are Monitored', body: `Company-provided systems and devices are monitored to ensure security standards are maintained. This is not about distrust — it is how we detect threats, prevent data loss, and protect both you and the company. By using company systems you accept this monitoring.\n\nMonitoring protects you too: if an attacker compromises your account, monitoring is how we detect it quickly. If you are falsely accused of a breach, monitoring records are how you prove what actually happened.` },
    ],
  },
  {
    id: 7,
    title: 'Recognising & Responding to Threats',
    subtitle: 'Incident Response Policy · Data Handling Policy · Information Management Policy',
    duration: '25 min', icon: '⚠️', color: '#f97316',
    policyAck: ['Incident Response Policy'],
    keyPoints: [
      'We are specifically targeted because compromising us can compromise our clients',
      'Urgency, bypass requests, and slightly-wrong sender addresses are red flags',
      'Verify through a separate known channel — never reply to the suspicious message',
      'Early reporting is rewarded, never punished — report and let the team assess',
    ],
    scenario: {
      title: 'The CEO Gift Card',
      setup: "You receive an email that looks like it is from the CEO, marked urgent, asking you to buy gift cards or share a client list quickly because they are 'in a meeting and can't talk.' The sender address is slightly different from the CEO's usual address.",
      message: '"This is urgent — I need this done in the next 30 minutes. Can\'t talk right now."',
      options: [
        { id: 'a', text: "Act quickly — the CEO is busy and it's urgent.", correct: false, feedback: "❌ This is a classic business email compromise attempt. Urgency and bypassing normal process are red flags. The slightly-wrong sender address confirms it. Do not act." },
        { id: 'b', text: "Verify through a separate known channel (call the CEO directly on a known number) and report the email to IT immediately.", correct: true, feedback: "✅ Correct. Do not act on it. Verify through a separate known channel — call or message the CEO directly on a number you already have, not one provided in the suspicious email. Report the email to IT regardless." },
        { id: 'c', text: "Reply to the email asking for more information to confirm it's genuine.", correct: false, feedback: "❌ Replying to the suspicious email just communicates with the attacker. Verify through a completely separate channel — call the CEO on a known number. Never use contact details from the suspicious message." },
        { id: 'd', text: "Wait to see if the CEO follows up before acting.", correct: false, feedback: "❌ Waiting gives the attacker more time. Report it immediately to IT and verify through a known channel — the combination of slightly-wrong sender address and urgent bypass request is a strong indicator of BEC." },
      ],
    },
    quiz: [
      { q: "Why are security companies specifically targeted by attackers?", opts: ["Because they have more valuable data than other companies", "Because compromising a security company can be a path to compromising their clients", "Because their staff are more careless", "Because they invest less in defence"], correct: 1, exp: "Attackers specifically target security companies because we may have access to our clients' systems and security posture data. Compromising us can be a path to compromising multiple clients simultaneously." },
      { q: "If you receive an urgent request that bypasses normal process, you should:", opts: ["Act quickly — urgency suggests real importance", "Slow down — urgency and bypass requests are key social engineering red flags", "Escalate to your manager and act if they approve", "Ignore it — legitimate requests don't come this way"], correct: 1, exp: "Urgency designed to prevent careful thinking is one of the most reliable social engineering signals. When something pressures you to bypass normal process, that is precisely when you should slow down and verify." },
      { q: "True or false: if you accidentally click a phishing link, it is better to stay quiet and hope nothing happens.", opts: ["True — reporting might get you in trouble", "False — fast reporting limits damage and you will never be punished for reporting honestly", "True — if nothing bad happens, there's nothing to report", "False — but you should investigate it yourself first"], correct: 1, exp: "False. Early reporting is what limits damage, and it is a cultural and legal necessity. You will never be punished for reporting honestly and quickly. Staying silent out of fear is what causes real harm." },
      { q: "You accidentally clicked a link in a suspicious email. The right next step is:", opts: ["Run an antivirus scan on your computer", "Report it immediately to IT / the Incident Response Team", "Change all your passwords yourself", "Monitor your accounts for 48 hours before deciding"], correct: 1, exp: "Report it immediately. The Incident Response Team needs to know quickly to contain any compromise. You do not need to diagnose it yourself — just report fast and let the team assess." },
    ],
    policies: [
      { ref: 'SI-POL-IR', title: 'Incident Response Policy', summary: 'Defines how security incidents are classified, reported, and managed. Covers phishing, social engineering, data breaches, and lost devices.', obligations: ['Report any suspected incident immediately — do not investigate or fix it yourself', 'Report suspected phishing, malware, lost devices, accidental disclosure, or anything that feels wrong', 'Do not stay silent about mistakes — fast reporting is always the right choice', 'Incidents are categorised by severity by the IR team — you just need to report quickly'] },
    ],
    content: [
      { heading: 'We Are a Target', body: `Attackers specifically target security companies, because compromising us can be a path to compromising our clients. You should assume that you, personally, may be targeted with sophisticated phishing or social engineering precisely because you work here. This is not paranoia — it is the threat model for our industry.\n\nBusiness email compromise is a targeted form where an attacker impersonates a colleague or executive to request money, data, or access. The slightly-wrong sender address is often the only visible indicator.` },
      { heading: 'Early Reporting Is Always Rewarded', body: `This is the most important cultural message in this module: if you make a mistake — click a bad link, send something to the wrong person, lose a device — report it immediately. You will never be punished for reporting honestly and quickly. You could cause real harm by staying silent out of fear.\n\nFast reporting is what limits damage, and it is also a legal necessity under the NDB scheme. Incidents are categorised by severity by the IR team — you do not need to work out the severity yourself. Just report quickly and let the team assess.` },
    ],
  },
  {
    id: 8,
    title: 'Acceptable Use & AI Tools',
    subtitle: 'Acceptable Use Policy · AI Use Policy · Information Management Policy · Intellectual Property Handling Policy',
    duration: '20 min', icon: '🤖', color: '#8b5cf6',
    policyAck: ['Acceptable Use Policy', 'AI Use Policy'],
    keyPoints: [
      'Company systems are for company business — personal social media on company equipment is not permitted',
      'Treat an AI prompt box like a public forum — never paste confidential data',
      'AI-generated outputs may infringe copyright — verification is your responsibility',
      'Misuse can result in termination and legal action',
    ],
    scenario: {
      title: 'The AI Debug Shortcut',
      setup: "You want to use an AI assistant to help debug a piece of code from a client engagement. The fastest way is to paste the whole client code block, including their internal API keys and endpoints, into the AI tool.",
      message: '"It\'ll be so much faster to just paste the whole thing in — it\'s only going to an AI."',
      options: [
        { id: 'a', text: "Paste it in — AI tools don't store or share your prompts.", correct: false, feedback: "❌ Many AI tools do store prompts and may use them for training. More critically, you would be disclosing client confidential data and live credentials to a third-party provider — a serious breach regardless of what the AI does with it." },
        { id: 'b', text: "Remove all secrets and client-identifying details, use a sanitised or fictional version, or use only an approved enterprise AI tool the company has vetted.", correct: true, feedback: "✅ Correct. Treat the AI prompt box as public. Remove all secrets and client-identifying details before submitting. Use a sanitised or fictional version. If you genuinely need AI help with client code, use only a company-approved enterprise tool." },
        { id: 'c', text: "Paste it in but delete the conversation afterwards.", correct: false, feedback: "❌ Deleting the local conversation history does not remove data that has already been transmitted to the AI provider's servers. The disclosure has already occurred." },
        { id: 'd', text: "Only paste the part without API keys — keep the endpoint URLs.", correct: false, feedback: "⚠️ Endpoint URLs from a client environment are also confidential data. Any client-identifying or client-specific information must be removed before using a public AI tool." },
      ],
    },
    quiz: [
      { q: "Why must you never paste client code with credentials into a public AI tool?", opts: ["AI tools are too slow to be useful for debugging", "You would be disclosing client confidential data and live credentials to a third-party external provider", "The output quality won't be good enough", "AI tools can't understand client-specific code"], correct: 1, exp: "Pasting client code with credentials into a public AI tool discloses client confidential data — including potentially live secrets — to an external third party. This is a serious breach of the Data Handling Policy and potentially the engagement contract." },
      { q: "Personal social media use on company equipment is:", opts: ["Permitted during lunch breaks", "Not permitted", "Permitted for up to 30 minutes per day", "Permitted if using a personal browser profile"], correct: 1, exp: "Personal social media use on company equipment is not permitted under the Acceptable Use Policy. Company systems are provided for company business use." },
      { q: "AI-generated outputs may:", opts: ["Always be used freely as they are original by definition", "Infringe others' copyright or reproduce proprietary material — verification is your responsibility", "Only be used if the AI tool is free", "Be used without attribution since the AI is the author"], correct: 1, exp: "AI tools can reproduce training data, including copyrighted content, without flagging it. You must verify that AI-generated outputs do not infringe others' IP or reproduce proprietary material. The verification obligation sits with you." },
      { q: "When using AI tools for work tasks, you should treat the prompt box as:", opts: ["A confidential internal system", "A public forum — never paste anything you wouldn't publish publicly", "A secure channel if you're using a paid subscription", "A safe space for rough drafts"], correct: 1, exp: "Treat an AI prompt box like a public forum. Anything you type may be stored, reviewed by staff, or used for training by the AI provider. This is the AI Use Policy's core principle." },
    ],
    policies: [
      { ref: 'SI-POL-AUP', title: 'Acceptable Use Policy', summary: 'Governs appropriate use of company systems, email, internet, and equipment. Defines what is and is not permitted on company-provided resources.', obligations: ['Use company systems for company business only', 'Personal social media on company equipment is not permitted', 'Company systems are monitored — your use is subject to review', 'Misuse can result in disciplinary action up to termination'] },
      { ref: 'SI-POL-AI', title: 'AI Use Policy', summary: 'Specific requirements for the use of AI tools in company work, including what can and cannot be input into AI systems and how AI-generated content must be handled.', obligations: ['Never input confidential, client, or personal information into public AI tools', 'Treat AI prompt boxes as public forums', 'Verify AI-generated outputs do not infringe copyright or reproduce proprietary content', 'Use only company-approved enterprise AI tools for sensitive work tasks'] },
    ],
    content: [
      { heading: 'AI Tools — Handle With Care', body: `AI tools are useful, but they carry a specific and serious risk: anything you type into a third-party AI tool may be stored and used by that provider. This means you must never paste confidential information, client data, personal information, credentials, or proprietary methodology into public AI tools.\n\nTreat an AI prompt box like a public forum. Use only sanitised, fictional examples. When using AI tools, also comply with their licences and verify that AI-generated output does not infringe others' IP or reproduce proprietary content.` },
      { heading: 'Secure Coding (Where Relevant)', body: `If your role involves development, you must follow secure coding standards (OWASP Top 10, SANS Top 25, CERT). Validate and sanitise all inputs, avoid revealing system internals in error messages, use maintained and security-focused libraries (never outdated or unsupported ones), implement secure authentication and MFA, and submit code for review.\n\nDocument your compliance — records may be audited. The standards exist to protect our platform and our clients' trust in it.` },
    ],
  },
  {
    id: 9,
    title: 'Social Media & Public Conduct',
    subtitle: 'Social Media Sharing Policy · Intellectual Property Handling Policy · Data Handling Policy',
    duration: '15 min', icon: '📱', color: '#ec4899',
    policyAck: ['Social Media Sharing Policy'],
    keyPoints: [
      '"Views are my own" does NOT protect you if you leak confidential information',
      'Never reveal clients or describe client work — obvious or subtle',
      'Lab content and methodology are commercial IP — do not post screenshots',
      'During a crisis: follow official channels only, no speculation or social commentary',
    ],
    scenario: {
      title: 'The LinkedIn Post',
      setup: "You just finished an intense red-team engagement and you're proud of it. You want to post: 'Wrapped up an amazing pentest this week — popped domain admin in under 4 hours! Can't say who but they're a big name in finance.' You add 'Views are my own.'",
      message: '"This shows my skills and I didn\'t name the client — the disclaimer covers me, right?"',
      options: [
        { id: 'a', text: "Post it — you didn't name the client and you added the disclaimer.", correct: false, feedback: "❌ Do not post this. 'A big name in finance' plus the timing can identify the client, breaching confidentiality. The 'Views are my own' disclaimer is irrelevant to a confidentiality breach — it only separates personal opinion from company position." },
        { id: 'b', text: "Post it — you've been careful enough and it shows your skills.", correct: false, feedback: "❌ This is not careful enough. Sector + timing + specific technical achievement (domain admin in 4 hours) can identify the client and the engagement. Revealing methodology also exposes commercial IP." },
        { id: 'c', text: "Don't post it — 'a big name in finance' plus timing can identify the client, and the disclaimer doesn't cover confidentiality breaches.", correct: true, feedback: "✅ Correct. The disclaimer separates personal opinion from company position — it does not authorise leaking client work. Sector hints plus timing can identify a client. If you want to demonstrate skills, build something personal and unrelated to company engagements." },
        { id: 'd', text: "Post it but remove 'big name in finance' — just say you finished an engagement.", correct: false, feedback: "⚠️ 'Wrapped up an amazing pentest — popped domain admin in under 4 hours' still reveals methodology and engagement details. The threshold for what counts as client-identifying is lower than most people expect." },
      ],
    },
    quiz: [
      { q: "Does a 'Views are my own' disclaimer protect you if you leak a client's identity?", opts: ["Yes — it separates your personal posts from company statements", "No — it separates personal opinion from company position but does not authorise leaking confidential information", "Yes — if you also say you can't name the client", "Yes — for personal social media accounts"], correct: 1, exp: "A 'Views are my own' disclaimer separates your personal opinions from official company statements. It does NOT protect you or the company if you leak confidential information, disparage a client, or reveal proprietary methodology." },
      { q: "A subtle way a client relationship can be leaked on social media:", opts: ["Posting general security industry opinions", "A 'just wrapped up' post with sector hints and specific technical achievements that can narrow down who the client is", "Sharing published security research", "Discussing cybersecurity news with your network"], correct: 1, exp: "Subtle leaks include celebratory posts with sector hints, specific technical achievements, or timing that can identify a client. The threshold for client-identifying information is lower than most people assume." },
      { q: "True or false: posting a screenshot of a lab you built is a good way to show your skills publicly.", opts: ["True — it demonstrates real capability", "False — lab content is commercial IP and posting it publicly gives away the company's product", "True — if you've left the company", "False — only if it shows client data"], correct: 1, exp: "False. Lab content is company commercial IP. Posting it publicly gives away the company's product and competitive advantage. Build something personal and unrelated to company IP if you want to demonstrate skills publicly." },
      { q: "During a security incident or crisis, your role on social media is:", opts: ["To keep your network informed with what you know", "To follow company crisis communication protocols — no speculation or unverified information", "To reassure clients by being transparent", "To stay silent on all topics until further notice"], correct: 1, exp: "All public communication during a crisis goes through designated channels only. Do not speculate, comment, or share any unverified information on social media. Follow the company's established communication protocols." },
    ],
    policies: [
      { ref: 'SI-POL-SOCIAL', title: 'Social Media Sharing Policy', summary: "Governs how employees use social media in ways that may affect the company, including distinguishing personal opinions from company statements, confidentiality on social platforms, and conduct during crises.", obligations: ['Never reveal clients or describe client work on social media', 'Understand that "Views are my own" does not authorise confidentiality breaches', 'Do not post screenshots of labs, methodology, or internal content', 'During a crisis, follow official channels only — no personal social commentary'] },
    ],
    content: [
      { heading: 'Why This Has Its Own Module', body: `For a security company, social media is a uniquely high-risk channel. A single careless post — a screenshot, a celebratory message, a photo with a screen in the background — can leak a client relationship, expose methodology that is our commercial IP, or undermine an engagement. Many leaks are not malicious; they are people sharing enthusiasm without thinking about what they are revealing.` },
      { heading: 'The Limits of the Disclaimer', body: `Using a 'Views are my own' disclaimer is good practice when expressing personal opinions on industry topics. But understand its limits: a disclaimer does NOT protect you or the company if you leak confidential information, disparage a client, post something defamatory or discriminatory, or reveal proprietary methodology. The disclaimer separates personal opinion from company position — it is not a shield for things you should not say in the first place.` },
    ],
  },
  {
    id: 10,
    title: 'Working with Clients & Third Parties',
    subtitle: 'Data Handling Policy · Information Management Policy · Intellectual Property Handling Policy',
    duration: '20 min', icon: '🤝', color: '#0ea5e9',
    policyAck: [],
    keyPoints: [
      'Privileged access is for the agreed scope only — never explore beyond it',
      'Each client relationship is confidential and walled off from all others',
      'Discovering something outside scope: document, stop, escalate — do not act unilaterally',
      'Third parties must be bound by appropriate confidentiality terms before receiving data',
    ],
    scenario: {
      title: 'The Out-of-Scope Discovery',
      setup: "While doing an authorised assessment for Client A, you discover what looks like evidence that Client A was already breached months ago by an unknown attacker — something outside your engagement scope.",
      message: '"I should investigate this further so I can give the client a full picture — it\'s helpful for them."',
      options: [
        { id: 'a', text: "Investigate further — the client will be grateful for the additional finding.", correct: false, feedback: "❌ Do not investigate further on your own or act unilaterally. Going beyond scope, even with good intentions, can create serious legal and contractual problems. Document, stop, and escalate." },
        { id: 'b', text: "Document what you observed, stop, and escalate immediately to your lead.", correct: true, feedback: "✅ Correct. Document what you observed, stop, and escalate immediately to your lead. This needs to be handled carefully within the engagement terms, the client relationship, and potentially legal obligations. Your lead will determine the right next step." },
        { id: 'c', text: "Continue the engagement normally and mention it in the final report.", correct: false, feedback: "❌ This delays disclosure of a potentially time-critical finding and involves continuing to work in an environment where you know there may be an active threat actor. Escalate immediately." },
        { id: 'd', text: "Tell the client directly on your next call.", correct: false, feedback: "⚠️ Direct disclosure without coordination can create problems — the client relationship must be managed through the lead, and there may be legal implications that need to be considered first. Escalate to your lead who will handle the client communication." },
      ],
    },
    quiz: [
      { q: "True or false: you may use access granted for one engagement to explore other interesting parts of the client's network.", opts: ["True — more findings mean more value for the client", "False — access is granted for a specific purpose and scope, and must only be used for that purpose", "True — if the client hasn't explicitly restricted those areas", "False — only for production systems"], correct: 1, exp: "False. Access granted for an engagement is for the specific agreed purpose and scope only. Exploring beyond it — even with good intentions — is unauthorised access and can create serious legal and contractual problems." },
      { q: "Can you mention Client A's name to Client B to build credibility?", opts: ["Yes — if Client A is well known it's helpful context", "No — each client relationship is confidential and walled off from all others", "Yes — if you don't describe the specific work", "No — only if Client A hasn't given permission"], correct: 1, exp: "No. Each client relationship is confidential and walled off from all others. Revealing that Client A is a client, and describing their work, breaches Client A's confidentiality. Build credibility with general expertise and anonymised examples." },
      { q: "If you discover something concerning outside your engagement scope, the right action is:", opts: ["Investigate it fully so you can provide a complete picture", "Document what you observed, stop, and escalate to your lead immediately", "Add it to the final report under 'additional observations'", "Ignore it — it's outside your scope"], correct: 1, exp: "Document, stop, escalate. Going beyond scope unilaterally — even with good intentions — can create legal, contractual, and client relationship problems. Your lead will determine the appropriate response." },
      { q: "Before sharing confidential information with a third party or vendor:", opts: ["Get verbal confirmation they will keep it confidential", "Ensure they are bound by appropriate confidentiality terms and share only what is necessary", "Check they have an active LinkedIn profile", "Get your manager to approve the email before sending"], correct: 1, exp: "Third parties must be bound by appropriate confidentiality terms before receiving any confidential information. Only share what is necessary for their role. Raise any concerns about a third party's data handling practices." },
    ],
    policies: [
      { ref: 'SI-POL-DATA', title: 'Data Handling Policy', summary: 'Client data handled during engagements must be treated to the same standards as company-owned data.', obligations: ['Handle client data as Confidential or Highly Confidential', 'Use company systems only for client data processing', 'Securely dispose of client data when the engagement ends', 'Follow any additional handling requirements in the engagement contract'] },
      { ref: 'SI-POL-INFO', title: 'Information Management Policy', summary: 'Information management requirements when operating within client environments.', obligations: ['Never reveal one client to another', 'Access only data required for the agreed engagement scope', 'Escalate out-of-scope discoveries — do not act unilaterally', 'Ensure third parties are bound by appropriate confidentiality terms'] },
    ],
    content: [
      { heading: 'Privileged Access Is a Privilege', body: `During engagements — cyber drills, training, assessments — you may be given significant access to a client's systems, data, and people. This access is granted for a specific purpose and scope. Use it only for that purpose. Never explore beyond your authorised scope, never access data you do not need, and never use client access for anything other than the agreed engagement.` },
      { heading: 'Keep Clients Separate', body: `You must never reveal one client to another, or use what you learned at one client to benefit or inform work at another. Each client relationship is confidential and walled off from the others. This includes not name-dropping clients to build credibility in another client's meeting.\n\nBuild credibility with general expertise and anonymised examples, never by naming other clients. The moment you reveal a client relationship without authorisation, you have breached that client's confidentiality — regardless of how well-intentioned or informal the disclosure was.` },
    ],
  },
  {
    id: 11,
    title: "Putting It Together & Your Commitment",
    subtitle: 'All policies · Employee Confidentiality & IP Deed',
    duration: '10 min', icon: '🎯', color: '#10b981',
    policyAck: ['Employee Confidentiality & IP Deed', 'Full Policy Acknowledgement'],
    keyPoints: [
      'Real situations combine multiple modules — apply principles together',
      'When unsure, asking is always better than guessing',
      'Your commitment is both a cultural statement and a legal record',
      'Know who to contact before you need them',
    ],
    scenario: {
      title: 'The Combined Test',
      setup: "A client emails asking you to share a lab walkthrough another client commissioned. The email is slightly urgent, the sender address looks almost right, and you're working from a café on your personal laptop because your VM is slow.",
      message: '"Can you send over that lab walkthrough? It\'s urgent — I need it for a meeting in an hour."',
      options: [
        { id: 'a', text: "Send the walkthrough — the client is asking for it and it's urgent.", correct: false, feedback: "❌ Multiple issues: the lab content is company IP and the other client's work (Modules 3, 10); revealing it exists for another client breaches confidentiality (Module 2, 10); the slightly-wrong sender suggests BEC (Module 7); and you're on a personal laptop in a café (Modules 5, 6)." },
        { id: 'b', text: "Don't respond to the request. Verify the sender through a known channel, report the suspicious email, and return to your company VM in a private location.", correct: true, feedback: "✅ Correct. All four issues at once: (1) do not share the IP/client work; (2) verify and report the suspicious email; (3) stop working on the personal laptop; (4) move to a private location. This is what applying all modules together looks like." },
        { id: 'c', text: "Reply asking for more information to confirm legitimacy, then send if confirmed.", correct: false, feedback: "❌ Replying to the suspicious email communicates with a potential attacker. Verify through a known separate channel. And even if verified legitimate, you still cannot share another client's commissioned work without authorisation." },
        { id: 'd', text: "Forward the walkthrough but redact the other client's name first.", correct: false, feedback: "❌ The issue is not the client's name being visible — the issue is that lab content is company IP, it was commissioned by another client, and sharing it without authorisation is a breach regardless of what's redacted." },
      ],
    },
    quiz: [
      { q: "When a situation involves multiple policy areas at once, you should:", opts: ["Apply only the most relevant single policy", "Apply the principles from all relevant modules together — real situations don't respect module boundaries", "Escalate immediately without making any assessment", "Default to the most restrictive policy only"], correct: 1, exp: "Real situations combine multiple obligations. The combined scenario in this module tests exactly this — you need to spot and respond to all the issues simultaneously: IP, confidentiality, BEC, device policy." },
      { q: "When you are unsure about an obligation:", opts: ["Make a reasonable assumption and proceed", "Wait until you are sure", "Asking is always better than guessing — check with your lead or consult the policy", "Default to sharing nothing ever"], correct: 2, exp: "Asking is always better than guessing. Your lead and the IT/security team can help. The policy is the authoritative source. Making assumptions when unsure is how well-intentioned people cause inadvertent breaches." },
      { q: "The signed acknowledgements and Employee Confidentiality & IP Deed at the end of this course are:", opts: ["Just a formality to complete onboarding", "Both cultural commitments and legal records that protect you and the company — take them seriously", "Only relevant if you work with Highly Confidential data", "Valid for 12 months then must be renewed"], correct: 1, exp: "The signed acknowledgements are legal records, not formalities. They confirm you have read, understood, and agree to comply with the company's policies. The obligations they record — especially around confidentiality and IP — survive your employment." },
      { q: "Security obligations at Security Impossible apply:", opts: ["During business hours only", "Only to systems and information you are directly assigned", "To everything you access, observe, and handle in your professional role — and many obligations continue after you leave", "Only while on client engagements"], correct: 2, exp: "Security obligations do not clock off. They apply to everything you encounter in your professional capacity, in every setting, and many — particularly confidentiality and IP — continue after your employment ends." },
    ],
    policies: [
      { ref: 'SI-ALL', title: 'All Policies — Combined Application', summary: 'This module tests combined application of all policies covered in the course. The policy library is the authoritative source — the course exists to help you understand them in context.', obligations: ['Know where to find each policy document', 'Know who to contact for security incidents, privacy questions, IP questions, and HR matters', 'Complete the final assessment at the recommended 80% pass mark', 'Sign the Employee Confidentiality & IP Deed — it is a legal document'] },
      { ref: 'SI-DEED', title: 'Employee Confidentiality & IP Deed (to be signed)', summary: 'The formal legal commitment that finalises your onboarding. Read it in full before signing.', obligations: ["'I confirm I have read, understood, and agree to comply with Security Impossible's policies'", "'I understand my confidentiality obligations continue after my employment ends'", 'Signed acknowledgements are stored in your employee file', 'Breaching obligations confirmed in the deed may result in legal action'] },
    ],
    content: [
      { heading: 'Bringing It Together', body: `The previous ten modules each covered one area, but real situations combine them. The scenario in this module tests whether you can apply the principles together — because that is how the real world works. Read each scenario and decide what you would do before reading the guidance.\n\nWhen something feels wrong, it usually is — and it often involves multiple policy areas at once. Slowing down, identifying all the issues, and responding to all of them is the skill this course is designed to build.` },
      { heading: 'Your Commitment', body: `After completing this course, you will sign acknowledgements confirming you have read, understood, and agree to comply with Security Impossible's policies, and you will sign the Employee Confidentiality & IP Deed. These are both cultural commitments and legal records that protect you and the company. Take them seriously.\n\nThe acknowledgement statement is: 'I confirm I have read, understood, and agree to comply with Security Impossible's policies, and I understand my confidentiality obligations continue after my employment ends.'` },
      { heading: 'Where to Find Everything', body: `All policies referenced in this course are available in the company policy library. If you are ever unsure about an obligation, the policy is the authoritative source, and your lead or the IT/security team can help. Asking is always better than guessing.\n\nKnow who to contact before you need to: who handles security incidents, who handles privacy questions, who handles IP questions, and who handles HR and conduct matters. These contacts should be in your onboarding documentation.` },
    ],
  },
];
