# Access Control Lab — reviewer changes (Ahmed's feedback)

## 1. Assistant panel not fully visible
The Byte guide panel now always fits on screen:
- Its chrome (header, progress, tabs, footer with the **Next** button) is pinned
  and never shrinks; only the body scrolls. So the Next/footer controls can't be
  pushed off-screen.
- Max-height uses the dynamic viewport (`100dvh`) so mobile browser chrome
  doesn't clip it.
- A `ResizeObserver` re-clamps the panel on-screen whenever its content grows
  (expanding a step/command, intro lines animating in, switching tabs).

## 2. Auto-typing commands removed (encourage active typing)
The "tap a command to drop it into the terminal" behaviour is gone. Commands in
the guide, the Commands reference, and the Explore step are now **read-only
reference text** the learner types themselves. The ⓘ explanations (what each
command does + example) are unchanged. All the tip text was updated to say "type
each command yourself in the terminal."

## 3. Task 1 clarified + hidden-directory fixed
- The two objectives are now framed as **two views of one problem**: (1) you can
  read the HR file as `student`, and (2) a hidden `.backdoor` folder in the same
  `/srv/company` tree holds **a copy of that same HR file**. The relationship is
  explicit, and Task 1 points out `.backdoor` is what you neutralise in Task 4.
- `_backdoor` was renamed to **`.backdoor`** so it is a *genuinely* hidden
  directory (in Linux, hidden = name starts with `.`). The lab now behaves
  correctly: plain `ls` and `tree` do **not** show it; `ls -la` (or `tree -a`)
  reveals it — and Task 1 teaches exactly that.

## 4. Task 2 explains how to become `marketinguser`
Task 2 now spells out the authentication method and credentials:
- Switch with `su - marketinguser` and enter the password **`marketinguser`**
  (every lab account's password is its own username — student/student,
  marketinguser/marketinguser, etc.). The one-line `su - … -c "…"` form is shown
  as a shortcut, and `exit` returns you to `student`.

## Verified
- `npm run build` passes.
- Engine walkthrough: all 8 tasks gate and complete in order.
- Targeted checks: `.backdoor` is hidden from `ls`/`tree` but shown by
  `ls -la`/`tree -a`; recon completes; interactive `su - marketinguser` and the
  `-c` one-liner both read HR as marketing.

---

# Reviewer changes — round 2

## 5. Task 1 objectives as a numbered list + SSH credentials shown
Task 1's brief now leads with a **connection-details callout** (`.byte-creds`)
giving the host, IP, port and login the learner needs to SSH in:
Host **FILES01** at **10.50.0.11**, Port **22**, Username **student**,
Password **student**. The two objectives that follow are presented as a
**numbered list** (`<ol class="byte-obj">`) instead of one dense paragraph:
1. Log in via SSH and read `/srv/company/hr/confidential.txt` as the `student` user.
2. Reveal the hidden `.backdoor` directory in `/srv/company` and verify that it
   contains a copy of the same HR file.

## 6. `su` now prompts for a password (Task 2)
`su - marketinguser` (and `su <user>` generally) no longer switches silently.
It drops into a real, **masked** `Password:` prompt in the terminal:
- a **wrong** password prints `su: Authentication failure` and does **not**
  switch user;
- the **correct** password (`marketinguser`, matching the account name) switches
  and resets the shell to that user's home.
The one-line shortcut `su - <user> -c "<cmd>"` still runs a single command and
returns automatically (no interactive prompt). Implemented via a new `authSu`
export in `terminalEngine.js` and a `pwPrompt` state in `Terminal.jsx`.

## 7. Inconsistent tip formatting fixed + em-dashes removed
The "tap the ⓘ …" tip rendered a second ⓘ glyph next to its icon and wrapped
awkwardly (the stacked-icon look in the review screenshot). It is now a single
clean sentence referring to "the info icon", with no duplicate glyph. All
**em-dashes (—) were swept from user-facing text** across `scenario.js`,
`Byte.jsx`, `Terminal.jsx` and `terminalEngine.js` (converted to commas or
periods by context); the `·` middle-dot command separators were left as-is.

## Verified (round 2)
- `npm run build` passes.
- Engine walkthrough: all 8 tasks gate and complete in order.
- jsdom E2E (`npm run test:e2e:jsdom`): **15 steps, all assertions green**,
  including new checks that the Task 1 brief renders the credentials callout,
  the host IP, and two numbered objectives, and that the interactive `su`
  masks input, fails on a wrong password, and switches on the right one.
