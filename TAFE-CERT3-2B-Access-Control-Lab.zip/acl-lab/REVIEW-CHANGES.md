# Access Control Lab — reviewer changes (Ahmed's feedback)

## 1. Assistant panel not fully visible
The Byte guide panel now always fits on screen:
- Its chrome (header, progress, tabs, footer with the **Next** button) is pinned
  and never shrinks; only the body scrolls. So the Next/footer controls can't be
  pushed off-screen.
- Max-height uses the dynamic viewport (`100dvh`) so mobile browser chrome
  doesn't clip it.
- A `ResizeObserver` re-clamps the panel on-screen whenever its content grows
  (expanding a step/command, intro lines animating in, switching tabs).

## 2. Auto-typing commands removed (encourage active typing)
The "tap a command to drop it into the terminal" behaviour is gone. Commands in
the guide, the Commands reference, and the Explore step are now **read-only
reference text** the learner types themselves. The ⓘ explanations (what each
command does + example) are unchanged. All the tip text was updated to say "type
each command yourself in the terminal."

## 3. Task 1 clarified + hidden-directory fixed
- The two objectives are now framed as **two views of one problem**: (1) you can
  read the HR file as `student`, and (2) a hidden `.backdoor` folder in the same
  `/srv/company` tree holds **a copy of that same HR file**. The relationship is
  explicit, and Task 1 points out `.backdoor` is what you neutralise in Task 4.
- `_backdoor` was renamed to **`.backdoor`** so it is a *genuinely* hidden
  directory (in Linux, hidden = name starts with `.`). The lab now behaves
  correctly: plain `ls` and `tree` do **not** show it; `ls -la` (or `tree -a`)
  reveals it — and Task 1 teaches exactly that.

## 4. Task 2 explains how to become `marketinguser`
Task 2 now spells out the authentication method and credentials:
- Switch with `su - marketinguser` and enter the password **`marketinguser`**
  (every lab account's password is its own username — student/student,
  marketinguser/marketinguser, etc.). The one-line `su - … -c "…"` form is shown
  as a shortcut, and `exit` returns you to `student`.

## Verified
- `npm run build` passes.
- Engine walkthrough: all 8 tasks gate and complete in order.
- Targeted checks: `.backdoor` is hidden from `ls`/`tree` but shown by
  `ls -la`/`tree -a`; recon completes; interactive `su - marketinguser` and the
  `-c` one-liner both read HR as marketing.
