import React, { useState, useEffect, useCallback, useRef } from 'react';
import { LAB_META, TASK_ORDER, TASKS } from './data/scenario.js';
import { initialFS, initialEnv } from './data/fsEngine.js';
import { isTaskDone } from './data/siteLogic.js';
import Terminal from './components/Terminal.jsx';
import Byte from './components/Byte.jsx';

const STORE_KEY = LAB_META.storeKey;

const emptyProgress = () => ({
  fs: initialFS(),
  env: initialEnv(),
  flags: {},              // sticky recon flags set by the terminal
  currentTask: 0,         // index into TASK_ORDER; === length means done
  completed: {},          // taskId -> true (locked in, never reverts)
  byteOpen: true,
  introSeen: false,
  exploreSeen: false,
});

function load() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) {
      const p = JSON.parse(raw);
      // fs/env can be persisted directly (plain objects). Fall back if shape is off.
      return {
        ...emptyProgress(),
        ...p,
        fs: p.fs || initialFS(),
        env: { ...initialEnv(), ...(p.env || {}) },
        flags: p.flags || {},
        completed: p.completed || {},
      };
    }
  } catch (e) { /* ignore */ }
  return emptyProgress();
}

export default function App() {
  const [state, setState] = useState(load);
  const [seed, setSeed] = useState(0);         // bump to reset the Terminal view
  const injectRef = useRef(null);               // Terminal registers an input setter here

  useEffect(() => {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) { /* ignore */ }
  }, [state]);

  // termState bridge: Terminal mutates fs/env/flags in place then calls setTermState
  const termState = { fs: state.fs, env: state.env, flags: state.flags };
  const setTermState = useCallback((ts) => {
    setState((s) => ({ ...s, fs: ts.fs, env: ts.env, flags: ts.flags }));
  }, []);

  // merge sticky events (flags) coming from the terminal engine
  const onEvents = useCallback((events) => {
    if (!events || !events.length) return;
    setState((s) => {
      const flags = { ...s.flags };
      events.forEach((e) => { flags[e] = true; });
      return { ...s, flags };
    });
  }, []);

  const patch = useCallback((p) => setState((s) => ({ ...s, ...p })), []);

  // full lab reset (from the summary card)
  const reset = useCallback(() => {
    if (!window.confirm('Reset the entire lab and start over from Task 1?')) return;
    const fresh = emptyProgress();
    setState(fresh);
    setSeed((n) => n + 1);
    try { localStorage.setItem(STORE_KEY, JSON.stringify(fresh)); } catch (e) { /* ignore */ }
  }, []);

  // "Restart container": re-seed the machine to its broken state (fresh fs/env,
  // clears recon flags + the live shell) but KEEP task progress the student has
  // already locked in — mirrors restarting a VM without losing your place.
  const restartContainer = useCallback(() => {
    if (!window.confirm('Restart the FILES01 container?\n\nThis re-seeds the server to its original broken state and drops your SSH session. Your completed tasks are kept.')) return;
    setState((s) => ({
      ...s,
      fs: initialFS(),
      env: initialEnv(),
      flags: {},
    }));
    setSeed((n) => n + 1);
  }, []);

  // command-insert bridge: Byte -> Terminal input box
  const insertCommand = useCallback((cmd) => {
    if (injectRef.current) injectRef.current(cmd);
  }, []);

  // active task + gate (reads live shell state)
  const activeTaskId = TASK_ORDER[state.currentTask] || null;
  const activeTask = TASKS.find((t) => t.id === activeTaskId) || null;
  const activeDone = activeTaskId ? isTaskDone(activeTaskId, termState) : false;

  const advance = useCallback(() => {
    setState((s) => {
      const id = TASK_ORDER[s.currentTask];
      if (!id) return s;
      if (!isTaskDone(id, { fs: s.fs, env: s.env, flags: s.flags })) return s; // gate
      return { ...s, completed: { ...s.completed, [id]: true }, currentTask: s.currentTask + 1 };
    });
  }, []);

  // Step back to review a previous task. Progress is untouched — `completed`
  // is a separate sticky map, so moving the pointer back never un-completes
  // anything, and the student can move forward again freely.
  const goBack = useCallback(() => {
    setState((s) => (s.currentTask > 0 ? { ...s, currentTask: s.currentTask - 1 } : s));
  }, []);

  const allDone = state.currentTask >= TASK_ORDER.length;

  return (
    <div style={{ minHeight: '100vh' }}>
      <Terminal
        termState={termState}
        setTermState={setTermState}
        onEvents={onEvents}
        seed={seed}
        registerInject={(fn) => { injectRef.current = fn; }}
      />
      <Byte
        state={state}
        patch={patch}
        reset={reset}
        restartContainer={restartContainer}
        activeTask={activeTask}
        activeDone={activeDone}
        advance={advance}
        goBack={goBack}
        allDone={allDone}
      />
    </div>
  );
}
