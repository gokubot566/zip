import React, { useState, useRef, useEffect, useCallback } from 'react';
import { runCommand, runSmbCommand, authSu, authSsh } from '../data/terminalEngine.js';
import { LAB_META } from '../data/scenario.js';
import {
  TerminalSquare, RotateCcw, Wifi, WifiOff, Circle, ChevronRight,
  Copy, Check, Server, User as UserIcon,
} from 'lucide-react';

/* ============================================================
   Terminal, the full-screen "app" for this lab. A faithful
   in-browser SSH shell into FILES01. Runs real commands via
   terminalEngine, renders coloured output, tracks command
   history, and reports task-relevant events up to App.

   Fills the whole desktop; Byte floats on top and can be dragged
   anywhere over it (including over the terminal).
   ============================================================ */

const BANNER = [
  { text: '  ____                       _ _         ___                        _ _     _      ', cls: 'dim' },
  { text: ' / ___|  ___  ___ _   _ _ __(_) |_ _   _|_ _|_ __ ___  _ __   ___  ___(_) |__ | | ___ ', cls: 'dim' },
  { text: ' \\___ \\ / _ \\/ __| | | | \'__| | __| | | || || \'_ ` _ \\| \'_ \\ / _ \\/ __| | \'_ \\| |/ _ \\', cls: 'dim' },
  { text: '  ___) |  __/ (__| |_| | |  | | |_| |_| || || | | | | | |_) | (_) \\__ \\ | |_) | |  __/', cls: 'dim' },
  { text: ' |____/ \\___|\\___|\\__,_|_|  |_|\\__|\\__, |___|_| |_| |_| .__/ \\___/|___/_|_.__/|_|\\___|', cls: 'dim' },
  { text: '                                   |___/              |_|                              ', cls: 'dim' },
  { text: '', cls: '' },
  { text: '  Security Impossible. Cyber Range   ·   Lab: Access Control & Secure Sharing', cls: 'hl' },
  { text: '  Target: FILES01 (10.50.0.11)   ·   Unit: BSBXCS303', cls: 'dim' },
  { text: '', cls: '' },
  { text: "  You are the new IT support tech. This company file server is misconfigured, ", cls: '' },
  { text: "  anyone can read HR's confidential records. Your job: find every leak and", cls: '' },
  { text: "  lock it down using least-privilege access control.", cls: '' },
  { text: '', cls: '' },
  { text: '  Start by finding the box and connecting:', cls: 'ok' },
  { text: `      ip a`, cls: 'cmd-hint' },
  { text: `      ssh student@10.50.0.11 -p 22       (password: student)`, cls: 'cmd-hint' },
  { text: '', cls: '' },
  { text: "  Type  help  for a command reference. Byte (right) tracks your 8 tasks.", cls: 'dim' },
  { text: '', cls: '' },
];

export default function Terminal({ termState, setTermState, onEvents, seed, registerInject }) {
  const [history, setHistory] = useState(() => [...BANNER]);
  const [input, setInput] = useState('');
  const [cmdHistory, setCmdHistory] = useState([]);
  const [histIdx, setHistIdx] = useState(-1);
  const [smbSession, setSmbSession] = useState(null);
  const [pwPrompt, setPwPrompt] = useState(null); // interactive `su` password prompt
  const [sshPrompt, setSshPrompt] = useState(null); // interactive `ssh` password prompt
  const [copied, setCopied] = useState(false);

  const scrollRef = useRef(null);
  const inputRef = useRef(null);

  // reseed → fresh banner + clear scrollback
  useEffect(() => {
    setHistory([...BANNER]);
    setSmbSession(null);
    setPwPrompt(null);
    setSshPrompt(null);
    setInput('');
    setCmdHistory([]);
    setHistIdx(-1);
  }, [seed]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [history]);

  const focusInput = () => inputRef.current?.focus();

  // Byte pushes commands in here (click-to-insert). We set the input and focus,
  // so the student just reviews it and presses Enter.
  useEffect(() => {
    if (!registerInject) return;
    registerInject((cmd) => {
      setInput(cmd);
      setHistIdx(-1);
      requestAnimationFrame(() => {
        const el = inputRef.current;
        if (el) { el.focus(); const len = cmd.length; try { el.setSelectionRange(len, len); } catch (e) {} }
      });
    });
  }, [registerInject]);

  const env = termState.env;
  const user = env.userStack[env.userStack.length - 1];
  const host = LAB_META.host.toLowerCase();
  const shortCwd = env.cwd.replace(/^\/home\/[^/]+/, '~').replace('/root', '~');

  const promptStr = smbSession
    ? `smb: \\>`
    : (!env.loggedIn
        ? `student@kali:~$`
        : `${user}@${host}:${shortCwd}${user === 'root' ? '#' : '$'}`);

  const runLine = useCallback((raw) => {
    const line = raw;
    // echo the prompt + command into scrollback
    const echoed = { prompt: promptStr, text: line, cls: 'input-echo' };

    if (smbSession) {
      const res = runSmbCommand(line, smbSession, termState);
      if (res.events && res.events.length) {
        res.events.forEach((e) => { termState.flags[e] = true; });
        onEvents(res.events);
      }
      const outLines = res.lines.map((l) => ({ text: l.text, cls: l.cls }));
      setHistory((h) => [...h, echoed, ...outLines]);
      if (res.close) setSmbSession(null);
      setTermState({ ...termState });
      return;
    }

    const res = runCommand(line, termState);
    if (res.clear) {
      setHistory([]);
      setTermState({ ...termState });
      return;
    }
    if (res.events && res.events.length) {
      res.events.forEach((e) => { termState.flags[e] = true; });
      onEvents(res.events);
    }
    const outLines = res.lines.map((l) => ({ text: l.text, cls: l.cls }));
    setHistory((h) => [...h, echoed, ...outLines]);
    if (res.smbSession) setSmbSession(res.smbSession);
    // `su - user` (interactive) → drop into a masked password prompt
    if (res.pwPrompt) {
      setPwPrompt(res.pwPrompt);
      setHistory((h) => [...h, { text: `Password: `, cls: 'su-prompt' }]);
    }
    // `ssh student@host` (interactive) → masked password prompt
    if (res.sshPrompt) {
      setSshPrompt(res.sshPrompt);
      setHistory((h) => [...h, { text: `${res.sshPrompt.user}@${res.sshPrompt.host}'s password: `, cls: 'su-prompt' }]);
    }
    setTermState({ ...termState });
  }, [promptStr, smbSession, termState, setTermState, onEvents]);

  const onSubmit = (e) => {
    e.preventDefault();

    // Interactive `ssh` password entry, don't echo it or store it in history;
    // validate and either complete the login or show "Permission denied".
    if (sshPrompt) {
      const pw = input;
      setInput('');
      const res = authSsh(sshPrompt, pw, termState);
      setSshPrompt(null);
      if (res.events && res.events.length) {
        res.events.forEach((ev) => { termState.flags[ev] = true; });
        onEvents(res.events);
      }
      const outLines = res.lines.map((l) => ({ text: l.text, cls: l.cls }));
      setHistory((h) => [...h, ...outLines]);
      setTermState({ ...termState });
      return;
    }

    // Interactive `su` password entry, don't echo the password or store it in
    // history; validate it and either switch user or show the failure message.
    if (pwPrompt) {
      const pw = input;
      setInput('');
      const res = authSu(pwPrompt, pw, termState);
      setPwPrompt(null);
      if (res.events && res.events.length) {
        res.events.forEach((ev) => { termState.flags[ev] = true; });
        onEvents(res.events);
      }
      const outLines = res.lines.map((l) => ({ text: l.text, cls: l.cls }));
      setHistory((h) => [...h, ...outLines]);
      setTermState({ ...termState });
      return;
    }

    const line = input;
    if (line.trim()) {
      setCmdHistory((h) => [...h, line]);
    } else {
      // blank enter: just show an empty prompt line
      setHistory((h) => [...h, { prompt: promptStr, text: '', cls: 'input-echo' }]);
      setInput('');
      return;
    }
    setHistIdx(-1);
    setInput('');
    runLine(line);
  };

  const onKeyDown = (e) => {
    if (pwPrompt || sshPrompt) return; // no history recall while typing a password
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (!cmdHistory.length) return;
      const idx = histIdx === -1 ? cmdHistory.length - 1 : Math.max(0, histIdx - 1);
      setHistIdx(idx);
      setInput(cmdHistory[idx]);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (histIdx === -1) return;
      const idx = histIdx + 1;
      if (idx >= cmdHistory.length) { setHistIdx(-1); setInput(''); }
      else { setHistIdx(idx); setInput(cmdHistory[idx]); }
    } else if (e.key === 'l' && e.ctrlKey) {
      e.preventDefault();
      setHistory([]);
    }
  };

  const copyAll = () => {
    const text = history.map((l) => (l.prompt ? `${l.prompt} ${l.text}` : l.text)).join('\n');
    try {
      const ta = document.createElement('textarea');
      ta.value = text; document.body.appendChild(ta); ta.select();
      document.execCommand('copy'); document.body.removeChild(ta);
      setCopied(true); setTimeout(() => setCopied(false), 1400);
    } catch (e) { /* ignore */ }
  };

  return (
    <div className="term-root" onClick={focusInput}>
      <style>{TERM_CSS}</style>

      {/* window chrome / title bar */}
      <div className="term-bar">
        <div className="term-dots"><span className="d r" /><span className="d y" /><span className="d g" /></div>
        <div className="term-title">
          <TerminalSquare size={15} />
          <span>{user}@{host}: {env.loggedIn ? env.cwd : 'ssh session'}</span>
        </div>
        <div className="term-bar-right">
          <span className={`term-conn ${env.loggedIn ? 'on' : 'off'}`}>
            {env.loggedIn ? <><Wifi size={13} /> connected</> : <><WifiOff size={13} /> not connected</>}
          </span>
          <button className="term-copy" onClick={(e) => { e.stopPropagation(); copyAll(); }} title="Copy session">
            {copied ? <Check size={14} /> : <Copy size={14} />}
          </button>
        </div>
      </div>

      {/* status strip */}
      <div className="term-status">
        <span className="ts-item"><Server size={12} /> {LAB_META.host} · {LAB_META.ip}</span>
        <span className="ts-sep">|</span>
        <span className="ts-item"><UserIcon size={12} /> {user}{smbSession ? '  ·  smb session' : ''}</span>
        <span className="ts-sep">|</span>
        <span className="ts-item">umask {env.umask.toString(8).padStart(4, '0')}</span>
        <span className="ts-flex" />
        <span className="ts-hint">↑ history · Ctrl+L clear · type “help”</span>
      </div>

      {/* scrollback */}
      <div className="term-scroll" ref={scrollRef}>
        {history.map((l, i) => (
          <div key={i} className={`term-line ${l.cls || ''}`}>
            {l.prompt ? (
              <>
                <span className="term-prompt-inline">{l.prompt}</span>{' '}
                <span className="term-echo-text">{l.text}</span>
              </>
            ) : (
              <span>{l.text === '' ? '\u00A0' : l.text}</span>
            )}
          </div>
        ))}

        {/* live input line */}
        <form className="term-inputline" onSubmit={onSubmit}>
          {sshPrompt ? (
            <span className="term-prompt su">{sshPrompt.user}@{sshPrompt.host}'s password:</span>
          ) : pwPrompt ? (
            <span className="term-prompt su">Password:</span>
          ) : (
            <span className={`term-prompt ${smbSession ? 'smb' : ''} ${user === 'root' ? 'root' : ''}`}>{promptStr}</span>
          )}
          <input
            ref={inputRef}
            className="term-input"
            type={(pwPrompt || sshPrompt) ? 'password' : 'text'}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={onKeyDown}
            spellCheck={false}
            autoCapitalize="off"
            autoCorrect="off"
            autoComplete="off"
            aria-label={(pwPrompt || sshPrompt) ? 'password input' : 'terminal input'}
          />
          <span className="term-cursor" />
        </form>
      </div>
    </div>
  );
}

const TERM_CSS = `
.term-root{
  position:fixed; inset:0; display:flex; flex-direction:column;
  background:
    radial-gradient(140% 120% at 85% -10%, #0c1b16 0%, transparent 55%),
    linear-gradient(180deg,#05080c 0%, #060a0f 100%);
  font-family:'JetBrains Mono', ui-monospace, 'SF Mono', Menlo, monospace;
  overflow:hidden;
}
.term-bar{
  display:flex; align-items:center; gap:12px; height:42px; padding:0 14px;
  background:linear-gradient(180deg,#11161d,#0c1015);
  border-bottom:1px solid rgba(255,255,255,.07); flex:0 0 auto; user-select:none;
}
.term-dots{display:flex; gap:7px}
.term-dots .d{width:12px;height:12px;border-radius:50%}
.term-dots .r{background:#ff5f57}.term-dots .y{background:#febc2e}.term-dots .g{background:#28c840}
.term-title{display:flex; align-items:center; gap:8px; color:#8ea1b5; font-size:12.5px; font-family:'Inter',sans-serif; flex:1; justify-content:center}
.term-title svg{color:#3ddc97}
.term-bar-right{display:flex; align-items:center; gap:10px}
.term-conn{display:flex; align-items:center; gap:5px; font-family:'Inter',sans-serif; font-size:11.5px; padding:3px 9px; border-radius:999px; font-weight:600}
.term-conn.on{color:#3ddc97; background:rgba(61,220,151,.1); border:1px solid rgba(61,220,151,.25)}
.term-conn.off{color:#f0a04b; background:rgba(240,160,75,.08); border:1px solid rgba(240,160,75,.22)}
.term-copy{border:1px solid rgba(255,255,255,.12); background:rgba(255,255,255,.04); color:#9fb0c3; width:30px;height:26px;border-radius:7px; display:grid;place-items:center}
.term-copy:hover{background:rgba(255,255,255,.09); color:#e6edf3}

.term-status{
  display:flex; align-items:center; gap:10px; height:30px; padding:0 16px;
  background:#080c11; border-bottom:1px solid rgba(255,255,255,.05);
  font-family:'Inter',sans-serif; font-size:11.5px; color:#6b7d92; flex:0 0 auto;
}
.ts-item{display:flex; align-items:center; gap:5px}
.ts-item svg{opacity:.8}
.ts-sep{opacity:.3}
.ts-flex{flex:1}
.ts-hint{color:#4d5f74}

.term-scroll{
  flex:1 1 auto; min-height:0; overflow-y:auto; padding:16px 18px 8px;
  font-size:13.5px; line-height:1.55; color:#c9d6e3;
}
.term-line{white-space:pre-wrap; word-break:break-word}
.term-line.dim{color:#5d7186}
.term-line.hl{color:#3ddc97; font-weight:600}
.term-line.ok{color:#5fd79a}
.term-line.err{color:#ff6b6b}
.term-line.warn{color:#f0b849}
.term-line.cmd-hint{color:#7fd1ff}
.term-line.input-echo{color:#e6edf3}
.term-prompt-inline{color:#5fd79a; font-weight:600}
.term-line.input-echo .term-prompt-inline{color:#5fd79a}
.term-echo-text{color:#e6edf3}

.term-inputline{display:flex; align-items:center; gap:9px; padding-top:2px}
.term-prompt{color:#5fd79a; font-weight:600; white-space:nowrap; flex:0 0 auto}
.term-prompt.root{color:#ff8686}
.term-prompt.smb{color:#f0b849}
.term-prompt.su{color:#c9d6e3; font-weight:600}
.term-line.su-prompt{color:#c9d6e3}
.term-input{
  flex:1; background:transparent; border:none; outline:none; color:#e6edf3;
  font-family:inherit; font-size:13.5px; caret-color:#3ddc97; padding:0;
}
.term-cursor{display:none}

/* scrollbar */
.term-scroll::-webkit-scrollbar{width:12px}
.term-scroll::-webkit-scrollbar-thumb{background:rgba(255,255,255,.12); border-radius:8px; border:3px solid transparent; background-clip:content-box}
.term-scroll::-webkit-scrollbar-track{background:transparent}
`;
