/* ============================================================
   fsEngine.js — a small but faithful Linux permission model for
   the "Access Control & Secure Sharing" lab.

   It simulates:
     • users / groups / group membership
     • a virtual filesystem under /srv/company
     • UNIX ownership + mode bits (rwx, setgid, sticky)
     • POSIX ACLs (access + default), incl. the mask
     • umask (system-wide, via /etc/bash.bashrc)
     • a hidden .backdoor directory (dot-prefixed) with copied HR data
     • SMB (smbclient) and NFS (mount -t nfs4) access paths

   The terminal (see terminalEngine.js) mutates this state with
   real commands; siteLogic.js reads it to gate the 7 tasks.

   NOTE: this is a teaching simulation. It implements the parts of
   the permission model the lab exercises — not every POSIX corner.
   ============================================================ */

export const HR_CONFIDENTIAL =
  'CONFIDENTIAL — HR EMPLOYEE RECORDS\n' +
  '----------------------------------\n' +
  'Name: Priya Nair       Salary: $98,400   TFN: 431 ***  Address: 14 Elm St\n' +
  'Name: Tom邓 (Deng)     Salary: $87,200   TFN: 552 ***  Address: 9 River Rd\n' +
  'Name: Aisha Rahman     Salary: $102,750  TFN: 118 ***  Address: 3 Park Ave\n' +
  '\n[!] This file contains personally identifiable information (PII).\n';

/* ---- users & groups (mirrors the lab brief) ---- */
export const USERS = {
  root:          { uid: 0,    gid: 0,    groups: ['root'] },
  student:       { uid: 1001, gid: 1004, groups: ['student', 'staff'], password: 'student' },
  hruser:        { uid: 1002, gid: 1001, groups: ['hr', 'staff'],       password: 'hruser' },
  marketinguser: { uid: 1003, gid: 1002, groups: ['marketing', 'staff'],password: 'marketinguser' },
  ituser:        { uid: 1004, gid: 1003, groups: ['it', 'staff'],       password: 'ituser' },
};

export const GROUP_NAMES = {
  0: 'root', 1001: 'hr', 1002: 'marketing', 1003: 'it', 1004: 'student', 50: 'staff',
};
// name -> gid, for chown/getfacl output
export const GID_BY_NAME = { root: 0, hr: 1001, marketing: 1002, it: 1003, student: 1004, staff: 50 };

export function primaryGroupName(user) {
  const u = USERS[user];
  if (!u) return user;
  if (u.uid === 0) return 'root';
  return { 1001: 'hr', 1002: 'marketing', 1003: 'it', 1004: 'student' }[u.gid] || 'staff';
}

/* ---- a filesystem node ----
   type: 'dir' | 'file'
   owner, group: usernames/group-names
   mode: octal number (e.g. 0o755) — special bits in the high octal
   acl: { access: {u:{}, g:{}, other, mask}, default: {...} } | null
   content: string (files)
   children: { name: node } (dirs)
   hidden: cosmetic only (name starts with _ or . also treated hidden)
*/
function file(owner, group, mode, content) {
  return { type: 'file', owner, group, mode, acl: null, content };
}
function dir(owner, group, mode, children = {}) {
  return { type: 'dir', owner, group, mode, acl: null, children };
}

/* Build the intentionally-insecure initial tree. */
export function initialFS() {
  return {
    '/': dir('root', 'root', 0o755, {
      srv: dir('root', 'root', 0o755, {
        company: dir('root', 'root', 0o777, {
          // department folders — world readable/writable (the vulnerability)
          hr: dir('root', 'root', 0o777, {
            'confidential.txt': file('root', 'root', 0o666, HR_CONFIDENTIAL),
            'salaries.csv': file('root', 'root', 0o666, 'employee,salary\npriya,98400\ntom,87200\naisha,102750\n'),
          }),
          marketing: dir('root', 'root', 0o777, {
            'campaign_q3.txt': file('root', 'root', 0o666, 'Q3 launch plan — social + email. Budget $42k.\n'),
            'brand_assets.txt': file('root', 'root', 0o666, 'Logo files, colour palette, tone of voice guide.\n'),
          }),
          it: dir('root', 'root', 0o777, {
            'server_inventory.txt': file('root', 'root', 0o666, 'DC01, FILES01, WEB01 — asset tags in CMDB.\n'),
            'passwords.txt': file('root', 'root', 0o666, 'wifi: Corp-Guest-2024\nswitch admin: (see vault)\n'),
          }),
          shared: dir('root', 'root', 0o777, {
            'readme.txt': file('root', 'root', 0o666, 'Shared space for all staff. Be tidy.\n'),
          }),
          // the hidden .backdoor directory (dot-prefixed = hidden in Linux) with a COPY of HR data
          '.backdoor': dir('root', 'root', 0o777, {
            'confidential.txt': file('root', 'root', 0o666, HR_CONFIDENTIAL),
            'notes.txt': file('root', 'root', 0o666, 'copied nightly by old cron job — forgotten.\n'),
          }),
        }),
      }),
      etc: dir('root', 'root', 0o755, {
        'bash.bashrc': file('root', 'root', 0o644,
          '# System-wide .bashrc\numask 000\n'),
      }),
      home: dir('root', 'root', 0o755, {
        student: dir('student', 'student', 0o755, {}),
      }),
      mnt: dir('root', 'root', 0o755, {}),
    }),
  };
}

/* ---- Samba / NFS share definitions (the extra leak paths) ----
   Both expose /srv/company. In the initial state they honour the
   (broken) filesystem perms, so anyone can read HR through them.
   The lab doesn't require reconfiguring the daemons — securing the
   filesystem perms closes these paths automatically, which the
   engine models by re-checking FS perms at access time. */
export const SHARES = {
  smb: { name: 'company', path: '/srv/company' },
  nfs: { export: '/srv/company' },
};

/* ---- environment / machine facts ---- */
export function initialEnv() {
  return {
    ip: '10.50.0.11',          // shown by `ip a`, used in ssh
    umask: 0o000,              // live shell umask (from bash.bashrc)
    loggedIn: false,           // becomes true after ssh
    userStack: ['student'],    // su pushes/pops; top is current user
    cwd: '/home/student',
    mountedNfs: false,         // whether 127.0.0.1:/srv/company is mounted at /mnt/tmp_nfs
  };
}

/* ============================================================
   Path + permission helpers
   ============================================================ */

export function normalize(path, cwd) {
  if (!path) return cwd;
  let p = path;
  if (!p.startsWith('/')) p = (cwd === '/' ? '' : cwd) + '/' + p;
  const parts = p.split('/').filter(Boolean);
  const out = [];
  for (const seg of parts) {
    if (seg === '.') continue;
    if (seg === '..') { out.pop(); continue; }
    out.push(seg);
  }
  return '/' + out.join('/');
}

export function getNode(fs, path) {
  const abs = path === '/' ? '/' : path;
  if (abs === '/') return fs['/'];
  const parts = abs.split('/').filter(Boolean);
  let node = fs['/'];
  for (const seg of parts) {
    if (!node || node.type !== 'dir' || !node.children[seg]) return null;
    node = node.children[seg];
  }
  return node;
}

export function parentOf(path) {
  const parts = path.split('/').filter(Boolean);
  parts.pop();
  return '/' + parts.join('/');
}
export function baseName(path) {
  const parts = path.split('/').filter(Boolean);
  return parts[parts.length - 1] || '/';
}

/* mode helpers */
export function permString(node) {
  const m = node.mode;
  const type = node.type === 'dir' ? 'd' : '-';
  const set = (bits, sBit, sChar) => {
    let r = (bits & 4) ? 'r' : '-';
    let w = (bits & 2) ? 'w' : '-';
    let x = (bits & 1) ? 'x' : '-';
    if (sBit) x = (bits & 1) ? sChar.toLowerCase() : sChar.toUpperCase();
    return r + w + x;
  };
  const u = set((m >> 6) & 7, m & 0o4000, 's');
  const g = set((m >> 3) & 7, m & 0o2000, 's');
  const o = set(m & 7, m & 0o1000, 't');
  let s = type + u + g + o;
  if (node.acl && (Object.keys(node.acl.access?.g || {}).length || Object.keys(node.acl.access?.u || {}).length || node.acl.access?.mask != null)) {
    s += '+';
  }
  return s;
}

export function isGroupMember(user, group) {
  const u = USERS[user];
  if (!u) return false;
  return u.groups.includes(group);
}

/* Resolve effective permission bits (r/w/x) for `user` on `node`,
   honouring: owner > named-user ACL > owning-group / named-group ACL
   (all masked by ACL mask) > other. Root bypasses (except pure-exec
   rule that root always has if any exec bit — we treat root as all). */
export function effPerms(node, user, groupName) {
  if (user === 'root') return { r: true, w: true, x: node.type === 'dir' ? true : ((node.mode & 0o111) !== 0) || true };

  const u = USERS[user];
  const isOwner = node.owner === user;
  const acl = node.acl;

  // 1. owner
  if (isOwner) {
    const b = (node.mode >> 6) & 7;
    return bits(b);
  }

  // 2. named-user ACL entries (masked)
  if (acl && acl.access && acl.access.u && acl.access.u[user] != null) {
    return maskBits(acl.access.u[user], acl.access.mask);
  }

  // Gather candidate group perms: owning group + named group ACLs the
  // user belongs to. POSIX: if ANY matching group entry grants it, ok.
  const candidates = [];
  const belongsOwningGroup = isGroupMember(user, node.group);

  if (acl && acl.access && (Object.keys(acl.access.g || {}).length || acl.access.u && Object.keys(acl.access.u).length)) {
    // ACL present: owning-group perms come from acl.access.groupOwner if set, else mode group bits
    if (belongsOwningGroup) {
      const go = acl.access.groupOwner != null ? acl.access.groupOwner : ((node.mode >> 3) & 7);
      candidates.push(go);
    }
    for (const g of Object.keys(acl.access.g || {})) {
      if (isGroupMember(user, g)) candidates.push(acl.access.g[g]);
    }
    if (candidates.length) {
      // union of candidates, then masked
      let unioned = 0;
      candidates.forEach((c) => { unioned |= c; });
      return maskBits(unioned, acl.access.mask);
    }
  } else {
    // no ACL: plain group bit if in owning group
    if (belongsOwningGroup) return bits((node.mode >> 3) & 7);
  }

  // 3. other
  return bits(node.mode & 7);
}

function bits(b) { return { r: (b & 4) !== 0, w: (b & 2) !== 0, x: (b & 1) !== 0 }; }
function maskBits(b, mask) {
  if (mask == null) return bits(b);
  const eff = b & mask;
  return bits(eff);
}

/* Can `user` traverse into every parent dir of `path`? (needs x on each) */
export function canTraverse(fs, path, user) {
  const parts = path.split('/').filter(Boolean);
  let cur = '/';
  let node = fs['/'];
  // root dir
  if (!effPerms(node, user, null).x) return false;
  for (let i = 0; i < parts.length - 1; i++) {
    cur = cur === '/' ? '/' + parts[i] : cur + '/' + parts[i];
    node = getNode(fs, cur);
    if (!node) return false;
    if (!effPerms(node, user, null).x) return false;
  }
  return true;
}

/* Deep clone the FS (structuredClone available in modern browsers). */
export function cloneFS(fs) {
  return typeof structuredClone === 'function'
    ? structuredClone(fs)
    : JSON.parse(JSON.stringify(fs));
}
