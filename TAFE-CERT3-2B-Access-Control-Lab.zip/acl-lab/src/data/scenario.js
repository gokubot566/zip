/* ============================================================
   scenario.js, content for
   "Access Control & Secure Sharing" (Cyber Range · BSBXCS303)

   Model: a realistic in-browser SSH terminal into FILES01, a
   misconfigured company file server. The trainee runs REAL Linux
   commands to find and fix the permission problems. Byte (the only
   overlay) guides + GATES eight tasks, each must be satisfied by
   live filesystem state before the next unlocks, then shows a
   summary/report card in its own panel.
   ============================================================ */

export const LAB_META = {
  slug: 'access-control-secure-sharing',
  title: 'Access Control & Secure Sharing',
  unit: 'BSBXCS303 · Cyber Range',
  port: 8345,
  storeKey: 'si-access-control-secure-sharing-v1',
  host: 'FILES01',
  ip: '10.50.0.11',
};

/* Shared cast, same ids/colours course-wide; roles re-tagged for a
   Linux file-server / access-control context. (Never use "hannah" as
   a speaker id, the id is "auditor".) */
export const CHARACTERS = {
  elena:   { name: 'Elena Vasquez', role: 'Systems Security Trainer', color: '#6366f1' },
  marcus:  { name: 'Marcus Chen',   role: 'Linux Sysadmin Lead',       color: '#3b82f6' },
  priya:   { name: 'Priya Patel',   role: 'Data Privacy Officer',      color: '#10b981' },
  david:   { name: 'David Okafor',  role: 'Risk & Compliance Officer', color: '#f59e0b' },
  auditor: { name: 'Hannah Wong',   role: 'External Security Auditor',  color: '#06b6d4' },
};

/* The eight gated tasks. `check` names the siteLogic predicate. */
export const TASKS = [
  {
    id: 'recon', n: 1, area: 'Reconnaissance', where: 'recon', speaker: 'marcus',
    threat: 'Unknown exposure',
    brief: "Get onto the box and see how bad it is. There are two findings, and both prove the same problem: HR data isn't protected."
      + "<div class='byte-creds'>"
      + "<div class='byte-creds-title'>SSH connection details</div>"
      + "<div class='byte-creds-row'><span>Host</span><b>FILES01</b> at <b>10.50.0.11</b></div>"
      + "<div class='byte-creds-row'><span>Port</span><b>22</b></div>"
      + "<div class='byte-creds-row'><span>Username</span><b>student</b></div>"
      + "<div class='byte-creds-row'><span>Password</span><b>student</b></div>"
      + "</div>"
      + "<div class='byte-obj-label'>Complete both objectives:</div>"
      + "<ol class='byte-obj'>"
      + "<li>Log in via SSH and read <code>/srv/company/hr/confidential.txt</code> as the <b>student</b> user.</li>"
      + "<li>Reveal the hidden <code>.backdoor</code> directory in <code>/srv/company</code> and verify that it contains a copy of the same HR file.</li>"
      + "</ol>",
    goal: "Log in via SSH, then (1) read /srv/company/hr/confidential.txt as student, and (2) reveal the hidden .backdoor directory in /srv/company, which holds a copy of the same HR file.",
    hint: "ssh student@10.50.0.11 -p 22 (password: student) · cat /srv/company/hr/confidential.txt · then reveal hidden entries with ls -la /srv/company (or tree -a /srv/company). Look for .backdoor; names starting with a dot are hidden.",
    steps: [
      { cmd: 'ssh student@10.50.0.11 -p 22',
        what: 'Opens an SSH (remote shell) session to FILES01 as the low-privilege "student" account. When prompted, the password is "student".',
        why: 'You always start an assessment as an ordinary user, that shows you exactly what a normal employee (or an attacker who phished one) can reach.' },
      { cmd: 'id',
        what: 'Prints your user id, primary group and every secondary group you belong to.',
        why: 'It confirms you are just "student" with no admin rights, so anything you can read next, any staff member could read too.' },
      { cmd: 'cat /srv/company/hr/confidential.txt',
        what: 'Finding 1. Dumps the contents of the HR salaries file straight to the screen.',
        why: 'This is the whole problem in one line: a plain user with no HR role can read confidential PII. If this succeeds, the folder is mis-permissioned.' },
      { cmd: 'ls -la /srv/company',
        what: 'Finding 2. Long-lists the directory INCLUDING hidden entries. In Linux a file or folder is "hidden" when its name starts with a dot (.), plain ls / tree skip them, and the -a flag (all) reveals them.',
        why: 'That is how you uncover .backdoor, a hidden folder sitting in the same /srv/company tree. -la also shows it is world-open (777).' },
      { cmd: 'ls -la /srv/company/.backdoor',
        what: 'Lists inside the hidden folder. You will see confidential.txt, a stashed COPY of the exact HR file you just read.',
        why: 'It ties the two findings together: the leak is not just wrong permissions on HR, there is also a forgotten duplicate of the same PII. You will empty and lock this folder in Task 4.' },
      { cmd: 'tree -a /srv/company',
        what: 'Optional. Draws the whole tree; -a includes hidden (dot-prefixed) entries so .backdoor shows up in the structure too.',
        why: 'A tree view lets you eyeball every department folder and confirm .backdoor is the only thing that should not be there.' },
    ],
    successNote: "Confirmed, two views of one problem: a plain student can read HR salaries, AND a hidden .backdoor holds a copy of the same file. That's the exposure we're here to close.",
  },
  {
    id: 'crossdept', n: 2, area: 'Cross-department & share leaks', where: 'recon', speaker: 'auditor',
    threat: 'Data readable by everyone',
    brief: "Prove the leak isn't just your account. Switch to the <b>marketing</b> user and read the HR file as them, then pull the same file over <b>Samba</b>. Same secret, three different doors, that's how audits fail.<br><br><b>How to become marketinguser:</b> use <code>su</code> (switch user). It prompts for <i>that user's</i> password, the account <b>marketinguser</b> has the password <b>marketinguser</b>. (Every lab account's password is just its username: student/student, marketinguser/marketinguser, and so on.)",
    goal: "Read the HR confidential file as marketinguser (su - marketinguser, password: marketinguser), AND retrieve it via smbclient (get).",
    hint: 'su - marketinguser  (enter password: marketinguser), then: cat /srv/company/hr/confidential.txt then exit, or in one line: su - marketinguser -c "cat /srv/company/hr/confidential.txt" · then smbclient //127.0.0.1/company -U student%student and inside it: get hr/confidential.txt leaked_smb.txt',
    steps: [
      { cmd: 'su - marketinguser',
        what: 'Switches your identity to "marketinguser" (su = switch user; the "-" gives a fresh login shell). It prompts for MARKETINGUSER\'s password, type marketinguser. You stay as that user until you type exit.',
        why: 'You must act AS marketing to prove marketing can reach HR data. su is how you become another local user when you know their password.' },
      { cmd: 'cat /srv/company/hr/confidential.txt',
        what: 'Now that you are marketinguser, this prints the HR salaries file.',
        why: 'It proves the leak is not tied to your own account, a completely unrelated department can read HR data. That is a cross-department access failure.' },
      { cmd: 'exit',
        what: 'Leaves the marketinguser shell and drops you back to student. (Shortcut: su - marketinguser -c "cat ..." runs one command as them and returns automatically.)',
        why: 'Always return to your own account after testing as someone else.' },
      { cmd: 'smbclient //127.0.0.1/company -U student%student',
        what: 'Connects to the "company" Windows/Samba network share as user student (password student). You land at an "smb:\\>" prompt.',
        why: 'File servers are usually reached over a share, not SSH. You need to prove the same data leaks through the network door too.' },
      { cmd: 'get hr/confidential.txt leaked_smb.txt',
        what: 'Run this at the smb:\\> prompt. It downloads the HR file off the share and saves it locally as leaked_smb.txt.',
        why: 'A successful download over SMB confirms the third exposed path, the share hands confidential files to any authenticated user.' },
      { cmd: 'exit',
        what: 'Leaves the smbclient session and returns you to the normal shell.',
        why: 'You are done proving the leak; close the share connection cleanly before moving on to fixes.' },
    ],
    successNote: "Marketing can read HR, and SMB hands the file to anyone. Every access path is wide open, now we start closing them.",
  },
  {
    id: 'umask', n: 3, area: 'Secure default permissions (umask)', where: 'fix', speaker: 'elena',
    threat: 'New files born world-readable',
    brief: "The reason this keeps happening: the system <b>umask is 000</b>, so every new file is created 666 (everyone can read). Back up the config, set a secure <b>umask 007</b>, and reload it.",
    goal: "Change the system umask to 007 (edit /etc/bash.bashrc and source it, or set it in the shell) so the live umask is 0007.",
    hint: "sudo cp /etc/bash.bashrc /etc/bash.bashrc.bak · sudo sed is fine, or: echo \"umask 007\" | sudo tee -a /etc/bash.bashrc · source /etc/bash.bashrc · check with: umask",
    steps: [
      { cmd: 'umask',
        what: 'With no arguments, prints the current umask value (you will see 0000).',
        why: 'A umask of 000 subtracts nothing, so new files are born 666 (rw for everyone) and folders 777. This is the root cause of the leaks, always confirm the starting value before you change it.' },
      { cmd: 'sudo cp /etc/bash.bashrc /etc/bash.bashrc.bak',
        what: 'Uses sudo (run as root) to copy the system-wide shell config to a .bak backup.',
        why: 'Never edit a live system config without a rollback copy. If your change breaks logins, you can restore this file in one step.' },
      { cmd: 'echo "umask 007" | sudo tee -a /etc/bash.bashrc',
        what: 'Appends the line "umask 007" to /etc/bash.bashrc. "tee -a" writes to the file as root (sudo) and -a means append, not overwrite.',
        why: 'Putting it in /etc/bash.bashrc makes the secure default apply to every user on every new shell, so the fix survives reboots and covers everyone, not just your session.' },
      { cmd: 'source /etc/bash.bashrc',
        what: 'Re-reads the config into your current shell immediately, instead of waiting for the next login.',
        why: 'It applies the new umask right now so you (and the checker) can verify it without logging out and back in.' },
      { cmd: 'umask',
        what: 'Prints the umask again, it should now read 0007.',
        why: 'This confirms the change took effect. With umask 007, new files are created 660 (owner+group only) and folders 770, "other" gets nothing by default.' },
    ],
    successNote: "umask is 0007 now, new files land owner+group only. You've stopped the bleeding before fixing the wound.",
  },
  {
    id: 'backdoor', n: 4, area: 'Neutralize the backdoor', where: 'fix', speaker: 'david',
    threat: 'Hidden copy of HR data',
    brief: "Kill the hidden leak. Take ownership of <b>/srv/company/.backdoor</b>, wipe the copied files inside, and lock the directory down so it can't be used again.",
    goal: "Empty the .backdoor directory (remove the copied files) and restrict it (chmod 700 or 000, owned by root).",
    hint: "sudo chown root:root /srv/company/.backdoor · sudo chmod 700 /srv/company/.backdoor · sudo rm -rf /srv/company/.backdoor/* · sudo chmod 000 /srv/company/.backdoor",
    steps: [
      { cmd: 'sudo ls -la /srv/company/.backdoor',
        what: 'Lists what is actually inside the hidden folder, as root so nothing is hidden from you.',
        why: 'Before you delete anything you should see what is there, here it is a stashed copy of the HR data that must never have existed.' },
      { cmd: 'sudo chown -R root:root /srv/company/.backdoor',
        what: 'Changes the owner and group of the folder (and everything in it, -R = recursive) to root.',
        why: 'Taking ownership away from any regular user means no one but an admin can touch it while you clean it up.' },
      { cmd: 'sudo rm -rf /srv/company/.backdoor/*',
        what: 'Deletes every file and sub-folder inside .backdoor. -r recurses into folders, -f forces past prompts. Note the trailing /*, you are emptying the folder, not removing the folder itself.',
        why: 'This destroys the leaked copy of HR salaries. Removing the duplicate data is the whole point of the task.' },
      { cmd: 'sudo chmod 000 /srv/company/.backdoor',
        what: 'Sets the directory permissions to 000, no read, write or execute for owner, group or other.',
        why: 'Sealing the empty folder (700 would also pass) makes sure it can never be used as a drop-point again. The checker wants it owned by root with nothing for group/other.' },
      { cmd: 'sudo ls -la /srv/company/.backdoor',
        what: 'Re-lists the folder to confirm it is now empty and locked down.',
        why: 'Always verify a destructive fix landed the way you intended before moving on.' },
    ],
    successNote: "Backdoor emptied and sealed. The forgotten copy of HR salaries is gone for good.",
  },
  {
    id: 'baseline', n: 5, area: 'Reset ownership & base permissions', where: 'fix', speaker: 'marcus',
    threat: 'Inconsistent, over-open perms',
    brief: "Start from a clean slate. Strip any old ACLs, then give each department folder the right <b>group owner</b> and a strict base mode. HR, Marketing and IT should be <b>750</b>; leave the world with nothing.",
    goal: "Set group ownership (hr→hr, marketing→marketing, it→it) and chmod 750 on all three department folders. Clear stale ACLs first.",
    hint: "sudo setfacl -b -R /srv/company · sudo chown -R root:hr /srv/company/hr (repeat for marketing, it) · sudo chmod 750 /srv/company/hr (and marketing, it).",
    steps: [
      { cmd: 'sudo setfacl -b -R /srv/company',
        what: 'Removes (-b) all existing ACL entries, recursively (-R), from every folder and file under /srv/company.',
        why: 'The server has old, messy ACLs layered on. Wiping them first gives you a predictable baseline so the permissions you set next are the only ones in effect.' },
      { cmd: 'sudo chown -R root:hr /srv/company/hr',
        what: 'Sets the HR folder (and its contents, -R) to owner root, group hr.',
        why: 'Group ownership is what lets you grant access by department. HR files should belong to the hr group so only HR staff get in via the group bits.' },
      { cmd: 'sudo chmod 750 /srv/company/hr',
        what: 'Sets HR to mode 750, owner rwx, group r-x, other nothing.',
        why: '750 means the owning group (hr) can read and enter the folder, and "other" (everyone else) is completely shut out. This is the least-privilege baseline.' },
      { cmd: 'sudo chown -R root:marketing /srv/company/marketing',
        what: 'Sets the Marketing folder and contents to owner root, group marketing.',
        why: 'Same principle as HR, each department folder is owned by its own group so access can be scoped per team.' },
      { cmd: 'sudo chmod 750 /srv/company/marketing',
        what: 'Sets Marketing to mode 750 (owner rwx, group r-x, other none).',
        why: 'Locks "other" out of Marketing while letting the marketing group read it.' },
      { cmd: 'sudo chown -R root:it /srv/company/it',
        what: 'Sets the IT folder and contents to owner root, group it.',
        why: 'Gives the IT folder its correct group owner so IT staff get access through the group.' },
      { cmd: 'sudo chmod 750 /srv/company/it',
        what: 'Sets IT to mode 750 (owner rwx, group r-x, other none).',
        why: 'Completes the clean baseline: all three department folders are 750 with the world locked out.' },
      { cmd: 'ls -la /srv/company',
        what: 'Lists the department folders so you can confirm the new owners, groups and 750 modes.',
        why: 'Verify the baseline is uniform before layering the finer-grained ACLs on top in the next tasks.' },
    ],
    successNote: "Clean baseline: each folder owned by its department group, 750, others locked out. Now the fine-grained rules go on top.",
  },
  {
    id: 'hracl', n: 6, area: 'POSIX ACLs. HR folder', where: 'fix', speaker: 'priya',
    threat: 'IT needs read-only, not full access',
    brief: "The hard part. Basic perms can't say “HR read/write, IT read-<b>only</b>, everyone else nothing” at once, that needs <b>ACLs</b>. Apply them to HR, with inheritance so new files stay protected.",
    goal: "On /srv/company/hr set ACLs: group hr = rwX, group it = r-X (read-only), other = --- (with default/-d entries for inheritance).",
    hint: "sudo setfacl -R -m g:hr:rwX /srv/company/hr · sudo setfacl -R -m d:g:hr:rwX /srv/company/hr · same for g:it:r-X (access + d:) · sudo setfacl -R -m g:marketing:--- /srv/company/hr · o::--- and d:o::---",
    steps: [
      { cmd: 'getfacl /srv/company/hr',
        what: 'Shows the current ACL (Access Control List) on the HR folder, owner, group, and any extra user/group entries.',
        why: 'ACLs let you grant different access to more than one group at once, which plain owner/group/other bits cannot. Read the current state before changing it.' },
      { cmd: 'sudo setfacl -R -m g:hr:rwX /srv/company/hr',
        what: 'Adds (-m = modify) an ACL entry, recursively (-R), giving group hr read+write+X. Capital X grants execute on folders (so hr can enter them) but not on plain files.',
        why: 'HR owns this data, so they need full read/write. Using X instead of x is the safe habit, it avoids marking data files as executable.' },
      { cmd: 'sudo setfacl -R -m d:g:hr:rwX /srv/company/hr',
        what: 'The d: prefix sets a DEFAULT entry, a template applied to any new file or folder created here later.',
        why: 'Without a default, files created tomorrow would not inherit HR access. This makes the rule stick going forward, not just on today’s files.' },
      { cmd: 'sudo setfacl -R -m g:it:r-X /srv/company/hr',
        what: 'Gives group it read and X (enter folders) but NO write, r-X means read-only.',
        why: 'IT needs to audit/inspect HR data but must never be able to change it. This is the read-only access that basic permissions cannot express alongside HR’s read/write.' },
      { cmd: 'sudo setfacl -R -m d:g:it:r-X /srv/company/hr',
        what: 'Sets the default (inherited) version of IT’s read-only entry for new content.',
        why: 'Ensures future files stay readable by IT for auditing without ever becoming writable.' },
      { cmd: 'sudo setfacl -R -m g:marketing:--- /srv/company/hr',
        what: 'Explicitly gives group marketing no permissions (---) on HR.',
        why: 'Marketing was one of the leaking paths in Task 2. Naming them with --- makes the denial explicit and obvious to an auditor.' },
      { cmd: 'sudo setfacl -R -m o::---,d:o::--- /srv/company/hr',
        what: 'Sets "other" (everyone not in a named entry) to nothing, both as the access entry (o::---) and the default for new files (d:o::---). Commas let you apply several specs in one call.',
        why: 'This slams the door on the world. The checker specifically requires "other" to have zero access on HR.' },
      { cmd: 'getfacl /srv/company/hr',
        what: 'Re-reads the ACL so you can confirm hr=rwx, it=r-x, marketing/other=---, plus the default: lines.',
        why: 'Verifying the final ACL is how you prove HR keeps control, IT is read-only, and nobody else gets in.' },
    ],
    successNote: "Perfect. HR manages their data, IT can audit without changing anything, nobody else gets in. That's a real-world access model.",
  },
  {
    id: 'otheracl', n: 7, area: 'ACLs. Marketing, IT & Shared', where: 'fix', speaker: 'auditor',
    threat: 'Remaining folders unprotected',
    brief: "Extend the model. Give <b>Marketing</b> full access to Marketing, <b>IT</b> full access to IT, and let <b>all staff</b> share the Shared folder, each with others locked out and inheritance on.",
    goal: "Apply ACLs: marketing folder → g:marketing:rwX (+default), other ---; it folder → g:it:rwX (+default), other ---; shared folder → g:staff:rwX (+default).",
    hint: "sudo setfacl -R -m g:marketing:rwX,d:g:marketing:rwX /srv/company/marketing (o::---) · same shape for g:it on /it · sudo setfacl -R -m g:staff:rwX,d:g:staff:rwX /srv/company/shared",
    steps: [
      { cmd: 'sudo setfacl -R -m g:marketing:rwX,d:g:marketing:rwX /srv/company/marketing',
        what: 'In one call, gives group marketing full rwX on the Marketing folder and sets the matching default (d:) so new files inherit it.',
        why: 'Marketing owns and works in this folder, so they get read/write; the default keeps that true for files created later.' },
      { cmd: 'sudo setfacl -R -m o::---,d:o::--- /srv/company/marketing',
        what: 'Sets "other" to nothing now and for future files on the Marketing folder.',
        why: 'Keeps every other department (including HR) out of Marketing’s data, isolation goes both ways.' },
      { cmd: 'sudo setfacl -R -m g:it:rwX,d:g:it:rwX /srv/company/it',
        what: 'Gives group it full rwX on the IT folder plus the inherited default.',
        why: 'IT manages its own folder, so unlike the HR folder (where IT was read-only), here IT gets full control.' },
      { cmd: 'sudo setfacl -R -m o::---,d:o::--- /srv/company/it',
        what: 'Locks "other" out of the IT folder, now and by default.',
        why: 'Only IT should touch IT’s files; everyone else gets nothing.' },
      { cmd: 'sudo setfacl -R -m g:staff:rwX,d:g:staff:rwX /srv/company/shared',
        what: 'Gives the company-wide "staff" group full rwX on the Shared folder, with inheritance.',
        why: 'Shared is the one folder every employee should collaborate in, so the broad staff group gets access here on purpose, this is scoping access to the right group, not just locking everything down.' },
      { cmd: 'getfacl /srv/company/marketing /srv/company/it /srv/company/shared',
        what: 'Prints the ACLs of all three folders in one go so you can confirm each group has the intended access and the defaults are present.',
        why: 'A final read-back proves every department is isolated to its own data while Shared works for all staff.' },
    ],
    successNote: "Every department is now isolated to its own data and Shared works for all staff. The access model is complete.",
  },
  {
    id: 'validate', n: 8, area: 'Final validation', where: 'validate', speaker: 'elena',
    threat: 'Unverified fix = no fix',
    brief: "Last step, prove it. Confirm <b>no world-readable files remain</b> under /srv/company, and check that the doors you closed really are closed (try reading HR as marketing, it should fail).",
    goal: "Run: find /srv/company -perm -o+r (returns no HR/dept files) AND confirm marketinguser is denied on the HR folder.",
    hint: 'find /srv/company -perm -o+r  (should list nothing sensitive) · su - marketinguser -c "ls /srv/company/hr"  (should say Permission denied).',
    steps: [
      { cmd: 'find /srv/company -perm -o+r',
        what: 'Searches the whole tree for anything still readable by "other" (-perm -o+r matches files where the world-read bit is set).',
        why: 'This is the single best check that the leaks are closed, after your fixes it should return nothing sensitive. A clean result means no file is world-readable anymore.' },
      { cmd: 'su - marketinguser -c "ls /srv/company/hr"',
        what: 'Becomes marketinguser and tries to list the HR folder. You should get "Permission denied".',
        why: 'Task 2 proved marketing could read HR. Re-running the same attack as that user and being blocked proves the cross-department door is now shut.' },
      { cmd: 'su - marketinguser -c "cat /srv/company/hr/confidential.txt"',
        what: 'As marketinguser, attempts to read the actual HR salaries file, this should also be denied.',
        why: 'Confirms the specific file that leaked at the start is now unreadable to an outside department. Fixing without re-testing is how "fixes" silently fail.' },
      { cmd: 'getfacl /srv/company/hr',
        what: 'Prints the final HR ACL one more time for your records.',
        why: 'A clean before/after and a final permission read-back is what makes the server audit-ready, you can show exactly who has access and prove why.' },
    ],
    successNote: "Verified. No world-readable secrets, cross-department access denied. The server is secured, audit-ready.",
  },
];

export const TASK_ORDER = TASKS.map((t) => t.id);

export const BYTE_INTRO = {
  // Page 1. Byte introduces itself and the scenario. Every line here is
  // spoken by Byte (the robot mascot), so the trainee sees the robot avatar
  // first and never a human face before that person has introduced themselves.
  byteLines: [
    "Hi, I'm Byte, your guide for this access-control lab. 👋 I live in this panel and I'll walk you through every single step, so you're never stuck.",
    "Here's the situation: you've just started as an IT support tech at a company whose file server, FILES01, is a mess, anyone can read HR's confidential records. Your job is to find every leak and lock it down.",
    "Everything happens in the terminal on the left, real commands, real results. Nothing you type can break anything for real, so feel free to explore.",
    "📖 Two quick tips. Each task has a <b>Current task</b> tab with the exact commands, and there's a <b>Commands</b> tab with every command explained. In either one, tap the info icon next to a command to see what it does, with an example. You type every command yourself in the terminal, and that hands-on practice is how the commands stick.",
    "On the next screen I'll introduce the team you'll be working with. Ready?",
  ],
  // Page 2, the human cast introduce themselves, each with their own photo.
  team: [
    { s: 'elena',   t: "I'm Elena, Systems Security Trainer. I'll cover the umask fix and the final validation at the end." },
    { s: 'marcus',  t: "Marcus, Linux Sysadmin Lead. Recon and the ownership / permission reset are mine." },
    { s: 'priya',   t: "I'm Priya, Data Privacy Officer, the HR data is my responsibility, so I'll drive the HR ACLs." },
    { s: 'david',   t: "David, Risk & Compliance. I care about that hidden backdoor and where copies of PII end up." },
    { s: 'auditor', t: "And I'm Hannah, the external auditor. I'll show you the share leaks and check the other folders." },
  ],
};

export const EXPLORE_STEP = {
  speaker: 'elena',
  title: 'Get your bearings first',
  body: "The terminal on the left is a live SSH session into FILES01. Nothing you type here can break anything for real, try a few recon commands and get a feel for how open this server is before we start locking it down.",
  suggestions: [
    { cmd: 'ip a', label: 'ip a', note: 'Find the server\'s IP address (eth0)' },
    { cmd: 'ssh student@10.50.0.11 -p 22', label: 'ssh student@10.50.0.11 -p 22', note: 'Connect to the lab VM (password: student)' },
    { cmd: 'id', label: 'id', note: 'See which user and groups you are' },
    { cmd: 'ls -la /srv/company', label: 'ls -la /srv/company', note: 'List the shared company folders + perms' },
    { cmd: 'tree /srv/company', label: 'tree /srv/company', note: 'See the whole structure (spot anything hidden?)' },
  ],
  cta: "OK, I've looked around, start the tasks",
};

export const WHY_IT_MATTERS =
  "Most real breaches of sensitive data don't come from clever exploits, they come from a folder set to 777, a forgotten backup copy, or a network share that never had its permissions checked. The exact routine you run on FILES01 is what sysadmins use to protect HR, finance and customer data every day.";

export const LEARNING_OUTCOMES = [
  'Detect misconfigured file-share permissions across multiple access paths.',
  'Apply least-privilege access control with UNIX permissions and ownership.',
  'Use POSIX ACLs for role-based access basic permissions can\'t express.',
  'Secure default permissions with a sensible umask.',
  'Find and neutralise hidden copies of sensitive data.',
  'Validate access restrictions as different users before signing off.',
];

export const SUMMARY = {
  passTitle: 'Server secured, audit-ready',
  passBody:
    "You found the exposure across the local filesystem and the Samba share, stopped new files leaking with a secure umask, destroyed the hidden backdoor, reset ownership and base permissions to a clean 750 baseline, then layered POSIX ACLs so HR keep control, IT get read-only audit access, and every department is isolated, and you validated the lot. That's a complete access-control hardening, start to finish.",
  outcomesTitle: 'What you practised',
};

export const DISCLAIMER =
  'Training simulation. FILES01, “Riverton” staff records, and all users, files and network shares shown are fictional and run entirely offline inside your browser, no real systems are touched. Built for the Cyber Range unit “Securely manage PII and workplace information” (BSBXCS303).';

/* Reference command sheet shown in Byte's Commands tab.
   Each item: { cmd, desc (plain-English what it does), example }.
   The UI shows the command as a clickable chip with an ⓘ toggle that
   expands the description + example. */
export const COMMAND_REF = [
  {
    grp: 'Recon',
    items: [
      { cmd: 'ip a', desc: 'Shows every network interface on the machine and its IP address. Look at eth0 to find the server\'s address.', example: 'ip a' },
      { cmd: 'whoami', desc: 'Prints just the username you are currently logged in as, a quick way to confirm your identity.', example: 'whoami' },
      { cmd: 'id', desc: 'Prints your user ID, primary group and all secondary groups. Tells you exactly what access your account has.', example: 'id' },
      { cmd: 'groups', desc: 'Lists only the groups your user belongs to. Group membership is what usually decides which folders you can open.', example: 'groups' },
      { cmd: 'ls -la <dir>', desc: 'Long-lists a directory including hidden entries, showing owner, group and the permission bits (rwx) for each item.', example: 'ls -la /srv/company' },
      { cmd: 'tree <dir>', desc: 'Draws the whole folder structure under a directory as an indented tree, so you can see every sub-folder at a glance.', example: 'tree /srv/company' },
      { cmd: 'find <dir> -perm -o+r', desc: 'Searches a directory tree and lists every file that is readable by "other" (i.e. by everyone), a fast way to spot over-exposed files.', example: 'find /srv/company -perm -o+r' },
      { cmd: 'cat <file>', desc: 'Prints the entire contents of a text file to the screen. Used here to test whether you can read a file you shouldn\'t.', example: 'cat /srv/company/hr/confidential.txt' },
    ],
  },
  {
    grp: 'Switching users',
    items: [
      { cmd: 'su - <user>', desc: 'Switches you to another user account, loading their environment. You stay as that user until you type exit.', example: 'su - marketinguser' },
      { cmd: 'su - <user> -c "<cmd>"', desc: 'Runs a single command as another user, then returns you to your own shell. Great for testing "can THIS user read that file?".', example: 'su - marketinguser -c "cat /srv/company/hr/confidential.txt"' },
      { cmd: 'exit', desc: 'Leaves the current session, drops you back from a switched user, an SSH connection or an smbclient prompt.', example: 'exit' },
    ],
  },
  {
    grp: 'Permissions & ownership',
    items: [
      { cmd: 'chmod [-R] <mode> <path>', desc: 'Changes a file or folder\'s permission bits. The mode is three digits (owner, group, other); -R applies it to everything inside.', example: 'chmod -R 750 /srv/company/hr' },
      { cmd: 'chown [-R] <own>:<grp> <path>', desc: 'Changes who owns a file and which group it belongs to. -R applies it recursively to a whole tree.', example: 'chown -R root:hr /srv/company/hr' },
      { cmd: 'umask [mask]', desc: 'With no value, shows the current umask. With a value, sets which permission bits are stripped from every NEW file/folder you create.', example: 'umask 007' },
    ],
  },
  {
    grp: 'POSIX ACLs',
    items: [
      { cmd: 'getfacl [-R] <path>', desc: 'Displays the Access Control List for a file or folder, the fine-grained per-user / per-group rules that go beyond basic rwx.', example: 'getfacl /srv/company/hr' },
      { cmd: 'setfacl -b -R <path>', desc: 'Removes ALL extended ACL entries from a tree, resetting it back to plain UNIX permissions. A clean slate before you re-apply rules.', example: 'setfacl -b -R /srv/company' },
      { cmd: 'setfacl [-R] -m <spec> <path>', desc: 'Adds or modifies one ACL rule. The spec is like u:alice:rx (user), g:hr:rwx (group) or o::--- (other).', example: 'setfacl -R -m g:hr:rwx /srv/company/hr' },
      { cmd: 'd: prefix = default/inherited', desc: 'Prefixing a spec with d: sets a DEFAULT ACL on a folder, the rule new files created inside will automatically inherit.', example: 'setfacl -m d:g:hr:rwx /srv/company/hr' },
    ],
  },
  {
    grp: 'Network shares',
    items: [
      { cmd: 'smbclient //host/share -U user%pass', desc: 'Connects to a Windows/Samba network share and drops you at an smb:\\> prompt. Inside, use get <file> to download.', example: 'smbclient //127.0.0.1/company -U student%student' },
      { cmd: 'mount -t nfs4 host:/path /mnt/point', desc: 'Mounts a remote NFS share onto a local folder so you can browse it like normal files. Tests the NFS access path.', example: 'mount -t nfs4 127.0.0.1:/srv/company /mnt/tmp_nfs' },
    ],
  },
];
