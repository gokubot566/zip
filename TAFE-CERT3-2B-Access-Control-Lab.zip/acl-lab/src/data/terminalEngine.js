/* ============================================================
   terminalEngine.js — parses & executes shell commands against the
   simulated filesystem in fsEngine.js. Returns { lines, state } and
   mutates a working copy of state that App persists.

   Supported: ip a · whoami · id · groups · pwd · cd · ls · tree ·
   find · cat · echo · touch · mkdir · rm · cp · chmod · chown ·
   umask · getfacl · setfacl · su · sudo · source · smbclient ·
   mount · exit · clear · help · ssh (informational)

   Everything runs as the *current* user (top of env.userStack),
   with sudo elevating a single command to root.
   ============================================================ */

import {
  USERS, GID_BY_NAME, GROUP_NAMES, primaryGroupName, HR_CONFIDENTIAL,
  getNode, normalize, parentOf, baseName, permString, effPerms,
  canTraverse, isGroupMember, cloneFS,
} from './fsEngine.js';

const RESET_CMDS = new Set(['clear']);

function out(text = '', cls = '') { return { text, cls }; }
function err(text) { return { text, cls: 'err' }; }
function ok(text) { return { text, cls: 'ok' }; }

/* current user helper */
function cur(env) { return env.userStack[env.userStack.length - 1]; }

/* tokenizer: splits respecting simple double-quotes */
function tokenize(line) {
  const tokens = [];
  let i = 0, buf = '', inQ = false;
  while (i < line.length) {
    const c = line[i];
    if (c === '"') { inQ = !inQ; i++; continue; }
    if (!inQ && /\s/.test(c)) { if (buf) { tokens.push(buf); buf = ''; } i++; continue; }
    buf += c; i++;
  }
  if (buf) tokens.push(buf);
  return tokens;
}

/* octal string -> number (supports 3 or 4 digits) */
function parseMode(s) {
  if (!/^[0-7]{3,4}$/.test(s)) return null;
  return parseInt(s, 8);
}

/* ============================================================
   ACL parsing for setfacl -m specs like:
     g:hr:rwX  d:g:hr:rwX  u::rwX  o::---  g:it:r-X  m::rwx
   Returns list of {default, kind:'u'|'g'|'o'|'m', name, perms}
   ============================================================ */
function permsToBits(p, isDir) {
  // supports r,w,x,X,- ; X = x only if dir (or already has x) — we treat as x for dirs, no-x for files
  let b = 0;
  for (const ch of p) {
    if (ch === 'r') b |= 4;
    else if (ch === 'w') b |= 2;
    else if (ch === 'x') b |= 1;
    else if (ch === 'X') { if (isDir) b |= 1; }
    else if (ch === '-') { /* nothing */ }
  }
  return b;
}
function parseAclSpec(spec, isDir) {
  const entries = [];
  spec.split(',').forEach((raw) => {
    let s = raw.trim();
    if (!s) return;
    let isDefault = false;
    if (s.startsWith('d:') || s.startsWith('default:')) {
      isDefault = true;
      s = s.replace(/^d:/, '').replace(/^default:/, '');
    }
    const parts = s.split(':');
    // forms: kind:name:perms  OR kind::perms
    let kind, name, perms;
    if (parts.length === 3) { [kind, name, perms] = parts; }
    else if (parts.length === 2) { [kind, perms] = parts; name = ''; }
    else return;
    kind = kind[0]; // u/g/o/m
    entries.push({ isDefault, kind, name, bits: permsToBits(perms, isDir), rawPerms: perms });
  });
  return entries;
}

function ensureAcl(node) {
  if (!node.acl) {
    node.acl = {
      access: { u: {}, g: {}, other: null, mask: null, groupOwner: null },
      default: null,
    };
  }
  if (!node.acl.access) node.acl.access = { u: {}, g: {}, other: null, mask: null, groupOwner: null };
  return node.acl;
}

/* recompute the ACL mask = union of named users, named groups, owning group */
function recomputeMask(acl, node) {
  let m = 0;
  const a = acl.access;
  Object.values(a.u || {}).forEach((b) => { m |= b; });
  Object.values(a.g || {}).forEach((b) => { m |= b; });
  if (a.groupOwner != null) m |= a.groupOwner; else m |= (node.mode >> 3) & 7;
  a.mask = m;
}

function applyAclEntry(node, e) {
  const acl = ensureAcl(node);
  if (e.isDefault) {
    if (!acl.default) acl.default = { u: {}, g: {}, other: null, mask: null, ownerU: null, groupOwner: null };
    const d = acl.default;
    if (e.kind === 'u') { if (e.name) d.u[e.name] = e.bits; else d.ownerU = e.bits; }
    else if (e.kind === 'g') { if (e.name) d.g[e.name] = e.bits; else d.groupOwner = e.bits; }
    else if (e.kind === 'o') d.other = e.bits;
    else if (e.kind === 'm') d.mask = e.bits;
    // refresh default mask
    let m = 0;
    Object.values(d.u || {}).forEach((b) => { m |= b; });
    Object.values(d.g || {}).forEach((b) => { m |= b; });
    if (d.groupOwner != null) m |= d.groupOwner;
    if (d.mask == null) d.mask = m;
  } else {
    const a = acl.access;
    if (e.kind === 'u') { if (e.name) a.u[e.name] = e.bits; else { /* owner */ node.mode = (node.mode & ~0o700) | (e.bits << 6); } }
    else if (e.kind === 'g') { if (e.name) a.g[e.name] = e.bits; else { a.groupOwner = e.bits; } }
    else if (e.kind === 'o') { a.other = e.bits; node.mode = (node.mode & ~0o7) | e.bits; }
    else if (e.kind === 'm') { a.mask = e.bits; }
    if (e.kind !== 'm') recomputeMask(acl, node);
  }
}

/* walk a subtree applying fn(node,isRoot) */
function walk(node, fn) {
  fn(node);
  if (node.type === 'dir') {
    Object.values(node.children).forEach((c) => walk(c, fn));
  }
}

/* ============================================================
   MAIN: run one command line
   ============================================================ */
export function runCommand(rawLine, state) {
  const line = rawLine.trim();
  const env = state.env;
  const fs = state.fs;
  const lines = [];
  const events = [];
  const push = (o) => lines.push(o);
  const emit = (name) => { if (!events.includes(name)) events.push(name); };

  if (!line) return { lines, clear: false, events };
  if (RESET_CMDS.has(line)) return { lines: [], clear: true, events };

  let tokens = tokenize(line);

  // sudo: elevate this command to root
  let sudo = false;
  if (tokens[0] === 'sudo') { sudo = true; tokens = tokens.slice(1); }
  const asUser = sudo ? 'root' : cur(env);

  const cmd = tokens[0];
  const args = tokens.slice(1);

  // helper to resolve a path relative to cwd
  const rp = (p) => normalize(p, env.cwd);

  /* -------- gate: most commands need an SSH session -------- */
  const preSshAllowed = new Set(['ip', 'ssh', 'help', 'clear', 'whoami']);
  if (!env.loggedIn && !preSshAllowed.has(cmd)) {
    push(err(`bash: cannot reach target: not connected. Use: ssh student@${env.ip} -p 22`));
    return { lines, clear: false, events };
  }

  switch (cmd) {
    /* ---------------- networking / session ---------------- */
    case 'ip': {
      if (args[0] === 'a' || args[0] === 'addr' || args[0] === 'address' || args.length === 0) {
        push(out('1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN'));
        push(out('    inet 127.0.0.1/8 scope host lo'));
        push(out('2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP'));
        push(out(`    link/ether 02:42:0a:32:00:0b brd ff:ff:ff:ff:ff:ff`));
        push(out(`    inet ${env.ip}/24 brd 10.50.0.255 scope global eth0`, 'hl'));
        push(out('       valid_lft forever preferred_lft forever'));
      } else push(err(`ip: unknown option "${args.join(' ')}"`));
      return { lines, clear: false, events };
    }

    case 'ssh': {
      // ssh student@<ip> -p 22
      const target = args.find((a) => a.includes('@'));
      if (!target) { push(err('usage: ssh student@<VM-IP> -p 22')); return { lines, clear: false, events }; }
      const [uname, host] = target.split('@');
      if (uname !== 'student') { push(err(`Permission denied — only the 'student' account is provisioned for SSH.`)); return { lines, clear: false, events }; }
      if (host !== env.ip && host !== 'localhost' && host !== '127.0.0.1') {
        push(err(`ssh: connect to host ${host} port 22: No route to host (expected ${env.ip})`));
        return { lines, clear: false, events };
      }
      if (env.loggedIn) { push(out('Already connected to the lab VM.')); return { lines, clear: false, events }; }
      push(out(`The authenticity of host '${host}' can't be established.`));
      push(out('ED25519 key fingerprint is SHA256:9x2...Kp4. Adding to known_hosts.'));
      push(out(`${uname}@${host}'s password: `));
      push(ok(`\nWelcome to Security Impossible Cyber Range — FILES01 (Ubuntu 22.04 LTS)`));
      push(out('Last login: Mon from 10.50.0.4'));
      env.loggedIn = true;
      env.userStack = ['student'];
      env.cwd = '/home/student';
      return { lines, clear: false, sshConnected: true, events };
    }

    /* ---------------- identity ---------------- */
    case 'whoami': {
      push(out(cur(env)));
      return { lines, clear: false, events };
    }
    case 'id': {
      const u = USERS[cur(env)];
      if (!u) { push(out(cur(env))); return { lines, clear: false, events }; }
      const pg = primaryGroupName(cur(env));
      const grpList = u.groups.map((g) => `${GID_BY_NAME[g]}(${g})`).join(',');
      push(out(`uid=${u.uid}(${cur(env)}) gid=${u.gid}(${pg}) groups=${grpList}`));
      return { lines, clear: false, events };
    }
    case 'groups': {
      const u = USERS[cur(env)];
      push(out(u ? u.groups.join(' ') : cur(env)));
      return { lines, clear: false, events };
    }

    /* ---------------- navigation ---------------- */
    case 'pwd': { push(out(env.cwd)); return { lines, clear: false, events }; }
    case 'cd': {
      const dest = args[0] ? rp(args[0]) : '/home/student';
      const node = getNode(fs, dest);
      if (!node) { push(err(`cd: ${args[0]}: No such file or directory`)); return { lines, clear: false, events }; }
      if (node.type !== 'dir') { push(err(`cd: ${args[0]}: Not a directory`)); return { lines, clear: false, events }; }
      if (!canTraverse(fs, dest, asUser) || !effPerms(node, asUser, null).x) {
        push(err(`cd: ${args[0]}: Permission denied`)); return { lines, clear: false, events };
      }
      env.cwd = dest;
      return { lines, clear: false, events };
    }

    /* ---------------- listing ---------------- */
    case 'ls': {
      const flags = args.filter((a) => a.startsWith('-')).join('');
      const paths = args.filter((a) => !a.startsWith('-'));
      const longMode = flags.includes('l');
      const showAll = flags.includes('a');
      const dirFlag = flags.includes('d');
      const target = paths[0] ? rp(paths[0]) : env.cwd;
      const node = getNode(fs, target);
      if (!node) { push(err(`ls: cannot access '${paths[0] || target}': No such file or directory`)); return { lines, clear: false, events }; }

      // ls -d on a dir (or a file): list the entry itself
      if (dirFlag || node.type === 'file') {
        if (!canTraverse(fs, target, asUser)) { push(err(`ls: cannot access '${paths[0]}': Permission denied`)); return { lines, clear: false, events }; }
        const nm = paths[0] || target;
        if (longMode) push(out(longLine(node, baseName(target) === '/' ? target : (paths[0] || baseName(target)))));
        else push(out(nm));
        return { lines, clear: false, events };
      }

      // reading a directory needs r; entering needs x
      if (!canTraverse(fs, target, asUser)) { push(err(`ls: cannot open directory '${paths[0] || target}': Permission denied`)); return { lines, clear: false, events }; }
      if (!effPerms(node, asUser, null).r) { push(err(`ls: cannot open directory '${paths[0] || target}': Permission denied`)); return { lines, clear: false, events }; }

      let names = Object.keys(node.children);
      if (!showAll) names = names.filter((n) => !n.startsWith('.'));
      names.sort();
      if (longMode) {
        push(out(`total ${names.length * 4}`));
        if (showAll) {
          push(out(longLine(node, '.')));
          const parent = getNode(fs, parentOf(target)) || node;
          push(out(longLine(parent, '..')));
        }
        names.forEach((n) => push(out(longLine(node.children[n], n))));
      } else {
        push(out(names.join('  ')));
      }
      if (showAll && names.includes('.backdoor')) emit('sawBackdoor');
      return { lines, clear: false, events };
    }

    case 'tree': {
      const treeAll = args.includes('-a');
      const target = (args.find((a) => a && !a.startsWith('-'))) ? rp(args.find((a) => a && !a.startsWith('-'))) : env.cwd;
      const node = getNode(fs, target);
      if (!node) { push(err(`${args[0]}  [error opening dir]`)); return { lines, clear: false, events }; }
      if (!effPerms(node, asUser, null).r) { push(err(`${target}  [error opening dir]`)); return { lines, clear: false, events }; }
      push(out(target));
      let dirs = 0, files = 0;
      const recur = (n, prefix) => {
        // hidden entries (dot-prefixed) only show with -a, exactly like real `tree`
        let names = Object.keys(n.children).sort();
        if (!treeAll) names = names.filter((nm) => !nm.startsWith('.'));
        names.forEach((nm, idx) => {
          const child = n.children[nm];
          const last = idx === names.length - 1;
          const branch = last ? '└── ' : '├── ';
          const isHidden = nm.startsWith('.');
          push(out(prefix + branch + nm, isHidden ? 'hl' : ''));
          if (child.type === 'dir') { dirs++; recur(child, prefix + (last ? '    ' : '│   ')); }
          else files++;
        });
      };
      recur(node, '');
      push(out(`\n${dirs} directories, ${files} files`));
      // reveal event: the hidden .backdoor only appears with `tree -a`
      if (/\.backdoor/.test(lines.map((l) => l.text).join('\n'))) emit('sawBackdoor');
      return { lines, clear: false, events };
    }

    case 'find': {
      // supports: find <path> -perm -o+r   and plain find <path>
      const target = args[0] && !args[0].startsWith('-') ? rp(args[0]) : env.cwd;
      const permIdx = args.indexOf('-perm');
      const node = getNode(fs, target);
      if (!node) { push(err(`find: '${args[0]}': No such file or directory`)); return { lines, clear: false, events }; }
      const results = [];
      const wantWorldRead = permIdx !== -1 && /o\+r/.test(args[permIdx + 1] || '');
      const collect = (n, path) => {
        const worldR = (n.mode & 0o4) !== 0;
        if (!wantWorldRead || worldR) {
          if (!wantWorldRead || n.type === 'file' || worldR) results.push(path);
        }
        if (n.type === 'dir') Object.keys(n.children).forEach((nm) => collect(n.children[nm], path === '/' ? '/' + nm : path + '/' + nm));
      };
      collect(node, target);
      if (results.length === 0 && wantWorldRead) { /* nothing world-readable — good */ }
      results.forEach((r) => push(out(r, wantWorldRead ? 'warn' : '')));
      if (wantWorldRead && target.startsWith('/srv/company')) emit('ranFinalFind');
      return { lines, clear: false, events };
    }

    /* ---------------- reading ---------------- */
    case 'cat': {
      const p = args.find((a) => !a.startsWith('-'));
      if (!p) { push(err('cat: missing operand')); return { lines, clear: false, events }; }
      const target = rp(p);
      const node = getNode(fs, target);
      if (!node) { push(err(`cat: ${p}: No such file or directory`)); return { lines, clear: false, events }; }
      if (node.type === 'dir') { push(err(`cat: ${p}: Is a directory`)); return { lines, clear: false, events }; }
      if (!canTraverse(fs, target, asUser) || !effPerms(node, asUser, null).r) {
        push(err(`cat: ${p}: Permission denied`)); return { lines, clear: false, events };
      }
      node.content.split('\n').forEach((l) => push(out(l)));
      // sensitive-read events (by whichever user is current)
      if (/\/srv\/company\/hr\/confidential\.txt$/.test(target) || (target.includes('/hr/') && node.content === HR_CONFIDENTIAL)) {
        const who = cur(env);
        if (who === 'student') emit('readHrAsStudent');
        if (who === 'marketinguser') emit('readHrAsMarketing');
      }
      return { lines, clear: false, events };
    }

    /* ---------------- writing / creating ---------------- */
    case 'echo': {
      // support: echo "text" > file   and  echo ... | sudo tee -a file
      const redirIdx = tokens.indexOf('>');
      const appendIdx = tokens.indexOf('>>');
      const teeIdx = tokens.indexOf('tee');
      const raw = line.substring(line.indexOf('echo') + 4).trim();
      // strip redirection tail from the echoed text
      let text = raw;
      let targetPath = null, append = false;
      if (redirIdx !== -1) { targetPath = tokens[redirIdx + 1]; append = false; text = between(raw, '>'); }
      else if (appendIdx !== -1) { targetPath = tokens[appendIdx + 1]; append = true; text = between(raw, '>>'); }
      else if (teeIdx !== -1) {
        append = tokens.includes('-a');
        targetPath = tokens[teeIdx + 1] === '-a' ? tokens[teeIdx + 2] : tokens[teeIdx + 1];
        text = raw.split('|')[0].replace(/^echo\s+/, '').trim();
      }
      text = stripQuotes(text);
      if (!targetPath) { push(out(text)); return { lines, clear: false, events }; }

      // tee runs as root if sudo tee; echo>file runs as current user
      const teeSudo = teeIdx !== -1 && tokens.includes('sudo');
      const writer = teeSudo ? 'root' : asUser;
      const abs = rp(targetPath);
      const res = writeFile(fs, abs, text, append, writer, env);
      if (res.error) push(err(res.error));
      else if (teeIdx !== -1) push(out(text)); // tee echoes to stdout
      return { lines, clear: false, events };
    }

    case 'source': case '.': {
      const p = args[0];
      if (p && (p.includes('bash.bashrc'))) {
        // re-read umask from the file
        const node = getNode(fs, rp(p));
        if (node && node.type === 'file') {
          const all = [...node.content.matchAll(/umask\s+([0-7]{3,4})/g)];
          if (all.length) env.umask = parseInt(all[all.length - 1][1], 8);
          push(out(''));
        }
      }
      return { lines, clear: false, events };
    }

    case 'sed': {
      // support: sed -i '/pattern/d' <file>   (delete matching lines)
      const inPlace = args.includes('-i');
      const scriptArg = args.find((a) => /\/d\s*$/.test(a) || /^\/.*\/d$/.test(a) || a.includes('d'));
      const delMatch = (args.join(' ')).match(/'?\/([^/]+)\/d'?/);
      const p = args[args.length - 1];
      const abs = rp(p);
      const node = getNode(fs, abs);
      if (!node || node.type !== 'file') { push(err(`sed: can't read ${p}: No such file or directory`)); return { lines, clear: false, events }; }
      if (asUser !== 'root' && node.owner !== asUser && !effPerms(node, asUser, null).w) {
        push(err(`sed: cannot write ${p}: Permission denied`)); return { lines, clear: false, events };
      }
      if (delMatch && inPlace) {
        const pat = new RegExp(delMatch[1]);
        node.content = node.content.split('\n').filter((l) => !pat.test(l)).join('\n');
        if (!node.content.endsWith('\n')) node.content += '\n';
      }
      return { lines, clear: false, events };
    }

    case 'umask': {
      if (args.length === 0) {
        push(out(String(env.umask.toString(8).padStart(4, '0'))));
      } else {
        const m = parseMode(args[0]);
        if (m == null) { push(err(`umask: ${args[0]}: invalid mask`)); return { lines, clear: false, events }; }
        env.umask = m;
      }
      return { lines, clear: false, events };
    }

    case 'touch': {
      const p = args.find((a) => !a.startsWith('-'));
      if (!p) { push(err('touch: missing file operand')); return { lines, clear: false, events }; }
      const abs = rp(p);
      const existing = getNode(fs, abs);
      if (existing) return { lines, clear: false, events }; // updates mtime; no-op
      const res = createFile(fs, abs, asUser, env);
      if (res.error) push(err(res.error));
      return { lines, clear: false, events };
    }

    case 'mkdir': {
      const p = args.find((a) => !a.startsWith('-'));
      if (!p) { push(err('mkdir: missing operand')); return { lines, clear: false, events }; }
      const abs = rp(p);
      if (getNode(fs, abs)) { push(err(`mkdir: cannot create directory '${p}': File exists`)); return { lines, clear: false, events }; }
      const parent = getNode(fs, parentOf(abs));
      if (!parent || parent.type !== 'dir') { push(err(`mkdir: cannot create directory '${p}': No such file or directory`)); return { lines, clear: false, events }; }
      if (!effPerms(parent, asUser, null).w || !effPerms(parent, asUser, null).x) { push(err(`mkdir: cannot create directory '${p}': Permission denied`)); return { lines, clear: false, events }; }
      const dmode = 0o777 & ~env.umask;
      parent.children[baseName(abs)] = { type: 'dir', owner: asUser, group: primaryGroupName(asUser), mode: dmode, acl: null, children: {} };
      applyDefaultAcls(parent, parent.children[baseName(abs)], true);
      return { lines, clear: false, events };
    }

    case 'rm': {
      const recursive = args.some((a) => /^-.*r/.test(a) || a === '-rf' || a === '-fr');
      const targets = args.filter((a) => !a.startsWith('-'));
      if (targets.length === 0) { push(err('rm: missing operand')); return { lines, clear: false, events }; }
      targets.forEach((t) => {
        // handle glob "*" inside a dir
        if (t.endsWith('/*') || t === '*') {
          const dirPath = t === '*' ? env.cwd : rp(t.slice(0, -2));
          const dnode = getNode(fs, dirPath);
          if (!dnode || dnode.type !== 'dir') { push(err(`rm: cannot remove '${t}': No such file or directory`)); return; }
          if (!effPerms(dnode, asUser, null).w) { push(err(`rm: cannot remove '${t}': Permission denied`)); return; }
          Object.keys(dnode.children).forEach((nm) => { delete dnode.children[nm]; });
          return;
        }
        const abs = rp(t);
        const node = getNode(fs, abs);
        if (!node) { push(err(`rm: cannot remove '${t}': No such file or directory`)); return; }
        if (node.type === 'dir' && !recursive) { push(err(`rm: cannot remove '${t}': Is a directory`)); return; }
        const parent = getNode(fs, parentOf(abs));
        if (!parent || !effPerms(parent, asUser, null).w) { push(err(`rm: cannot remove '${t}': Permission denied`)); return; }
        delete parent.children[baseName(abs)];
      });
      return { lines, clear: false, events };
    }

    case 'cp': {
      const paths = args.filter((a) => !a.startsWith('-'));
      if (paths.length < 2) { push(err('cp: missing destination file operand')); return { lines, clear: false, events }; }
      const src = getNode(fs, rp(paths[0]));
      if (!src) { push(err(`cp: cannot stat '${paths[0]}': No such file or directory`)); return { lines, clear: false, events }; }
      const destAbs = rp(paths[1]);
      let parent = getNode(fs, parentOf(destAbs));
      let name = baseName(destAbs);
      const destNode = getNode(fs, destAbs);
      if (destNode && destNode.type === 'dir') { parent = destNode; name = baseName(rp(paths[0])); }
      if (!parent || !effPerms(parent, asUser, null).w) { push(err(`cp: cannot create '${paths[1]}': Permission denied`)); return { lines, clear: false, events }; }
      parent.children[name] = cloneFS({ x: src }).x;
      parent.children[name].owner = asUser;
      parent.children[name].group = primaryGroupName(asUser);
      return { lines, clear: false, events };
    }

    /* ---------------- ownership / mode ---------------- */
    case 'chmod': {
      const recursive = args.some((a) => a === '-R' || /^-R/.test(a));
      const rest = args.filter((a) => !a.startsWith('-'));
      const modeStr = rest[0];
      const p = rest[1];
      const m = parseMode(modeStr);
      if (m == null) { push(err(`chmod: invalid mode: '${modeStr}'`)); return { lines, clear: false, events }; }
      if (!p) { push(err('chmod: missing operand')); return { lines, clear: false, events }; }
      const abs = rp(p);
      const node = getNode(fs, abs);
      if (!node) { push(err(`chmod: cannot access '${p}': No such file or directory`)); return { lines, clear: false, events }; }
      if (asUser !== 'root' && node.owner !== asUser) { push(err(`chmod: changing permissions of '${p}': Operation not permitted`)); return { lines, clear: false, events }; }
      const apply = (n) => { n.mode = (n.mode & ~0o7777) | m; };
      if (recursive) walk(node, apply); else apply(node);
      return { lines, clear: false, events };
    }

    case 'chown': {
      const recursive = args.some((a) => a === '-R' || /^-R/.test(a));
      const rest = args.filter((a) => !a.startsWith('-'));
      const spec = rest[0];
      const p = rest[1];
      if (!spec || !p) { push(err('chown: missing operand')); return { lines, clear: false, events }; }
      if (asUser !== 'root') { push(err(`chown: changing ownership of '${p}': Operation not permitted`)); return { lines, clear: false, events }; }
      const abs = rp(p);
      const node = getNode(fs, abs);
      if (!node) { push(err(`chown: cannot access '${p}': No such file or directory`)); return { lines, clear: false, events }; }
      let [owner, group] = spec.split(':');
      const apply = (n) => {
        if (owner) n.owner = owner;
        if (group !== undefined && group !== '') n.group = group;
      };
      if (recursive) walk(node, apply); else apply(node);
      return { lines, clear: false, events };
    }

    /* ---------------- ACLs ---------------- */
    case 'getfacl': {
      const recursive = args.some((a) => a === '-R');
      const rest = args.filter((a) => !a.startsWith('-'));
      const p = rest[0];
      if (!p) { push(err('getfacl: missing operand')); return { lines, clear: false, events }; }
      const abs = rp(p);
      const node = getNode(fs, abs);
      if (!node) { push(err(`getfacl: ${p}: No such file or directory`)); return { lines, clear: false, events }; }
      const emit = (n, relPath) => {
        printFacl(n, relPath, push);
      };
      if (recursive) {
        const base = abs.replace(/^\//, '');
        const recur = (n, path) => {
          emit(n, path);
          if (n.type === 'dir') Object.keys(n.children).sort().forEach((nm) => recur(n.children[nm], path + '/' + nm));
        };
        recur(node, base);
      } else {
        emit(node, abs.replace(/^\//, ''));
      }
      return { lines, clear: false, events };
    }

    case 'setfacl': {
      const removeAll = args.includes('-b');
      const recursive = args.includes('-R');
      const modIdx = args.indexOf('-m');
      const paths = args.filter((a, i) => !a.startsWith('-') && (modIdx === -1 || i !== modIdx + 1));
      // The spec (after -m) can itself look like a non-flag; capture it explicitly
      let spec = null;
      if (modIdx !== -1) spec = args[modIdx + 1];
      const realPaths = args.filter((a) => !a.startsWith('-') && a !== spec);
      const p = realPaths[realPaths.length - 1];
      if (!p) { push(err('setfacl: missing path')); return { lines, clear: false, events }; }
      const abs = rp(p);
      const node = getNode(fs, abs);
      if (!node) { push(err(`setfacl: ${p}: No such file or directory`)); return { lines, clear: false, events }; }
      if (asUser !== 'root' && node.owner !== asUser) { push(err(`setfacl: ${p}: Operation not permitted`)); return { lines, clear: false, events }; }

      const doNode = (n) => {
        if (removeAll) { n.acl = null; return; }
        if (spec) {
          const entries = parseAclSpec(spec, n.type === 'dir');
          entries.forEach((e) => applyAclEntry(n, e));
        }
      };
      if (recursive) walk(node, doNode); else doNode(node);
      return { lines, clear: false, events };
    }

    /* ---------------- su / exit ---------------- */
    case 'su': {
      // su - user   OR   su user   OR   su - user -c "cmd"
      let uname = args.find((a) => a !== '-' && !a.startsWith('-'));
      const cIdx = args.indexOf('-c');
      let inlineCmd = null;
      if (cIdx !== -1) {
        // if -c present, the target user is the token before -c that isn't '-'
        const before = args.slice(0, cIdx).filter((a) => a !== '-');
        uname = before[before.length - 1] || 'root';
        inlineCmd = stripQuotes(args.slice(cIdx + 1).join(' '));
      }
      if (!uname) uname = 'root';
      if (!USERS[uname]) { push(err(`su: user ${uname} does not exist`)); return { lines, clear: false, events }; }
      // password prompt is cosmetic; assume correct
      if (inlineCmd) {
        // run one command as that user, don't change the stack
        const saved = env.userStack;
        env.userStack = [...saved, uname];
        const savedCwd = env.cwd;
        const sub = runCommand(inlineCmd, state);
        sub.lines.forEach(push);
        (sub.events || []).forEach(emit);
        env.userStack = saved;
        env.cwd = savedCwd;
        return { lines, clear: false, events };
      }
      env.userStack = [...env.userStack, uname];
      // su - resets cwd to home
      if (args.includes('-')) env.cwd = uname === 'root' ? '/root' : `/home/${uname}`;
      if (uname !== 'root' && !getNode(fs, `/home/${uname}`)) {
        // create a home so cd doesn't error (cosmetic)
        const homeDir = getNode(fs, '/home');
        if (homeDir) homeDir.children[uname] = { type: 'dir', owner: uname, group: primaryGroupName(uname), mode: 0o755, acl: null, children: {} };
      }
      if (args.includes('-')) env.cwd = uname === 'root' ? '/root' : `/home/${uname}`;
      else env.cwd = env.cwd; // stay
      push(ok(`(switched to ${uname})`));
      return { lines, clear: false, userChanged: true, events };
    }

    case 'exit': case 'logout': {
      if (env.userStack.length > 1) {
        env.userStack = env.userStack.slice(0, -1);
        env.cwd = cur(env) === 'student' ? '/home/student' : (cur(env) === 'root' ? '/root' : `/home/${cur(env)}`);
        push(out('logout'));
        return { lines, clear: false, userChanged: true, events };
      }
      // exiting the base session = disconnect ssh
      env.loggedIn = false;
      push(out('logout'));
      push(out(`Connection to ${env.ip} closed.`));
      return { lines, clear: false, disconnected: true, events };
    }

    /* ---------------- SMB ---------------- */
    case 'smbclient': {
      // smbclient //127.0.0.1/company -U student%student  [-c "get ..."]
      const share = args.find((a) => a.startsWith('//'));
      if (!share) { push(err('Usage: smbclient //server/share -U user%pass')); return { lines, clear: false, events }; }
      const m = share.match(/\/\/([^/]+)\/(.+)/);
      const shareName = m ? m[2] : '';
      if (shareName !== 'company') { push(err(`tree connect failed: NT_STATUS_BAD_NETWORK_NAME`)); return { lines, clear: false, events }; }
      const uarg = args.find((a) => a.startsWith('-U')) || args[args.indexOf('-U') + 1];
      const uname = ((uarg || '').replace('-U', '') || 'student').split('%')[0] || 'student';
      // -c "get hr/confidential.txt out"
      const cIdx = args.indexOf('-c');
      const script = cIdx !== -1 ? stripQuotes(args.slice(cIdx + 1).join(' ')) : null;
      push(ok(`Try "help" to get a list of possible commands.`));
      const runSmb = (smbline) => {
        const st = tokenize(smbline);
        if (st[0] === 'get') {
          const remote = st[1];
          const localName = st[2] || baseName(remote);
          const abs = '/srv/company/' + remote;
          const node = getNode(fs, abs);
          if (!node) { push(err(`NT_STATUS_OBJECT_NAME_NOT_FOUND opening remote file \\${remote}`)); return; }
          // SMB access maps to the share user's FS perms
          if (!effPerms(node, uname, null).r || !canTraverse(fs, abs, uname)) {
            push(err(`NT_STATUS_ACCESS_DENIED opening remote file \\${remote}`));
            return;
          }
          // deliver a local copy into cwd
          const parent = getNode(fs, env.cwd);
          if (parent && parent.type === 'dir') {
            parent.children[localName] = { type: 'file', owner: cur(env), group: primaryGroupName(cur(env)), mode: 0o664 & ~env.umask, acl: null, content: node.content };
          }
          const bytes = node.content.length;
          push(out(`getting file \\${remote} of size ${bytes} as ${localName} (${(bytes / 1.5).toFixed(1)} kb/s)`, 'ok'));
          if (node.content === HR_CONFIDENTIAL || /hr\/confidential/.test(remote)) emit('smbGotHr');
        } else if (st[0] === 'ls' || st[0] === 'dir') {
          const d = getNode(fs, '/srv/company');
          Object.keys(d.children).forEach((nm) => push(out(`  ${nm}`)));
        } else if (st[0] === 'exit' || st[0] === 'quit') {
          /* end */
        } else if (smbline.trim()) {
          push(out(`smb: \\> ${smbline}`));
        }
      };
      if (script) {
        script.split(';').forEach((s) => runSmb(s.trim()));
        return { lines, clear: false, events };
      }
      // interactive: open an smb sub-shell
      return { lines, clear: false, smbSession: { user: uname, share: shareName, events } };
    }

    /* ---------------- NFS mount ---------------- */
    case 'mount': {
      // mount -t nfs4 127.0.0.1:/srv/company /mnt/tmp_nfs
      if (asUser !== 'root') { push(err('mount: only root can do that')); return { lines, clear: false, events }; }
      const nfsIdx = args.findIndex((a) => a.includes(':/'));
      if (nfsIdx === -1) { push(err('mount: bad usage. Try: mount -t nfs4 127.0.0.1:/srv/company /mnt/tmp_nfs')); return { lines, clear: false, events }; }
      const exportSpec = args[nfsIdx];
      const mountPoint = args[nfsIdx + 1];
      const mp = rp(mountPoint);
      const mpNode = getNode(fs, mp);
      if (!mpNode) { push(err(`mount: mount point ${mountPoint} does not exist`)); return { lines, clear: false, events }; }
      // bind /srv/company's children under the mount point (share honours FS perms)
      const srcNode = getNode(fs, '/srv/company');
      mpNode.children = srcNode.children; // live view — securing perms closes NFS too
      mpNode._nfs = true;
      env.mountedNfs = true;
      push(out(''));
      return { lines, clear: false, events };
    }
    case 'umount': case 'unmount': {
      const mp = rp(args[0] || '');
      const mpNode = getNode(fs, mp);
      if (mpNode && mpNode._nfs) { mpNode.children = {}; delete mpNode._nfs; env.mountedNfs = false; }
      return { lines, clear: false, events };
    }
    case 'exportfs': {
      push(out('/srv/company    <world>(rw,sync,no_subtree_check)'));
      return { lines, clear: false, events };
    }

    /* ---------------- misc ---------------- */
    case 'help': {
      HELP.forEach((l) => push(out(l)));
      return { lines, clear: false, events };
    }
    case 'cp_hint': return { lines, clear: false, events };

    default:
      push(err(`${cmd}: command not found`));
      return { lines, clear: false, events };
  }
}

/* ---------- interactive smb sub-command runner (called by Terminal) ---------- */
export function runSmbCommand(smbline, session, state) {
  const fs = state.fs;
  const env = state.env;
  const lines = [];
  const push = (o) => lines.push(o);
  const st = tokenize(smbline.trim());
  const uname = session.user;
  if (!st[0]) return { lines, close: false };
  if (st[0] === 'exit' || st[0] === 'quit') return { lines, close: true };
  if (st[0] === 'help' || st[0] === '?') { push(out('get <remote> [local]   ls   exit')); return { lines, close: false }; }
  if (st[0] === 'ls' || st[0] === 'dir') {
    const d = getNode(fs, '/srv/company');
    if (!d) { push(err('NT_STATUS_ACCESS_DENIED')); return { lines, close: false }; }
    Object.keys(d.children).sort().forEach((nm) => {
      const c = d.children[nm];
      push(out(`  ${nm.padEnd(28)} ${c.type === 'dir' ? 'D' : 'N'}        0`));
    });
    return { lines, close: false };
  }
  if (st[0] === 'get') {
    const remote = st[1];
    if (!remote) { push(err('get <remote> [local]')); return { lines, close: false }; }
    const localName = st[2] || baseName(remote);
    const abs = '/srv/company/' + remote;
    const node = getNode(fs, abs);
    if (!node || node.type === 'dir') { push(err(`NT_STATUS_OBJECT_NAME_NOT_FOUND opening remote file \\${remote}`)); return { lines, close: false }; }
    if (!effPerms(node, uname, null).r || !canTraverse(fs, abs, uname)) {
      push(err(`NT_STATUS_ACCESS_DENIED opening remote file \\${remote}`));
      return { lines, close: false };
    }
    const parent = getNode(fs, env.cwd);
    if (parent && parent.type === 'dir') {
      parent.children[localName] = { type: 'file', owner: env.userStack[env.userStack.length - 1], group: primaryGroupName(env.userStack[env.userStack.length - 1]), mode: 0o664, acl: null, content: node.content };
    }
    const bytes = node.content.length;
    push(out(`getting file \\${remote} of size ${bytes} as ${localName} (${(bytes / 1.5).toFixed(1)} KiloBytes/sec)`, 'ok'));
    const evs = (node.content === HR_CONFIDENTIAL || /hr\/confidential/.test(remote)) ? ['smbGotHr'] : [];
    return { lines, close: false, events: evs };
  }
  push(out(`smb: \\> ${smbline}`));
  return { lines, close: false, events: [] };
}

/* ============================================================
   small helpers used above
   ============================================================ */
function stripQuotes(s) {
  if (!s) return '';
  return s.replace(/^["']/, '').replace(/["']$/, '');
}
function between(raw, sep) {
  // returns text before the redirection operator, minus the leading 'echo'
  const idx = raw.indexOf(sep);
  let t = idx === -1 ? raw : raw.substring(0, idx);
  return t.replace(/^echo\s+/, '').trim();
}

function longLine(node, name) {
  const perms = permString(node);
  const links = node.type === 'dir' ? Object.keys(node.children).length + 2 : 1;
  const size = node.type === 'dir' ? 4096 : (node.content ? node.content.length : 0);
  const owner = node.owner.padEnd(8);
  const group = node.group.padEnd(10);
  return `${perms} ${String(links).padStart(2)} ${owner} ${group} ${String(size).padStart(5)} Jul  1 09:00 ${name}`;
}

function writeFile(fs, abs, text, append, writer, env) {
  const existing = getNode(fs, abs);
  if (existing) {
    if (existing.type === 'dir') return { error: `bash: ${abs}: Is a directory` };
    if (!effPerms(existing, writer, null).w) return { error: `bash: ${abs}: Permission denied` };
    existing.content = append ? (existing.content + text + '\n') : (text + '\n');
    return {};
  }
  const parent = getNode(fs, parentOf(abs));
  if (!parent || parent.type !== 'dir') return { error: `bash: ${abs}: No such file or directory` };
  if (!effPerms(parent, writer, null).w) return { error: `bash: ${abs}: Permission denied` };
  const fmode = 0o666 & ~env.umask;
  parent.children[baseName(abs)] = { type: 'file', owner: writer, group: primaryGroupName(writer), mode: fmode, acl: null, content: text + '\n' };
  applyDefaultAcls(parent, parent.children[baseName(abs)], false);
  return {};
}

function createFile(fs, abs, asUser, env) {
  const parent = getNode(fs, parentOf(abs));
  if (!parent || parent.type !== 'dir') return { error: `touch: cannot touch '${abs}': No such file or directory` };
  if (!effPerms(parent, asUser, null).w || !effPerms(parent, asUser, null).x) return { error: `touch: cannot touch '${baseName(abs)}': Permission denied` };
  const fmode = 0o666 & ~env.umask;
  // setgid dir → inherit group
  const grp = (parent.mode & 0o2000) ? parent.group : primaryGroupName(asUser);
  parent.children[baseName(abs)] = { type: 'file', owner: asUser, group: grp, mode: fmode, acl: null, content: '' };
  applyDefaultAcls(parent, parent.children[baseName(abs)], false);
  return {};
}

/* When creating inside a dir with default ACLs, apply them as the
   new node's access ACL (POSIX inheritance). */
function applyDefaultAcls(parent, child, isDir) {
  if (!parent.acl || !parent.acl.default) return;
  const d = parent.acl.default;
  child.acl = { access: { u: {}, g: {}, other: null, mask: null, groupOwner: null }, default: isDir ? JSON.parse(JSON.stringify(d)) : null };
  const a = child.acl.access;
  Object.keys(d.u || {}).forEach((k) => { a.u[k] = d.u[k]; });
  Object.keys(d.g || {}).forEach((k) => { a.g[k] = d.g[k]; });
  if (d.groupOwner != null) a.groupOwner = d.groupOwner;
  if (d.other != null) { a.other = d.other; child.mode = (child.mode & ~0o7) | d.other; }
  if (d.ownerU != null) child.mode = (child.mode & ~0o700) | (d.ownerU << 6);
  // mask
  let m = 0;
  Object.values(a.u).forEach((b) => { m |= b; });
  Object.values(a.g).forEach((b) => { m |= b; });
  if (a.groupOwner != null) m |= a.groupOwner;
  a.mask = d.mask != null ? d.mask : m;
}

function bitsToStr(b) {
  return `${(b & 4) ? 'r' : '-'}${(b & 2) ? 'w' : '-'}${(b & 1) ? 'x' : '-'}`;
}

function printFacl(node, relPath, push) {
  push(out(`# file: ${relPath}`));
  push(out(`# owner: ${node.owner}`));
  push(out(`# group: ${node.group}`));
  if (node.mode & 0o1000) push(out('# flags: --t'));
  const ownerBits = (node.mode >> 6) & 7;
  const groupBits = (node.mode >> 3) & 7;
  const otherBits = node.mode & 7;
  const acl = node.acl;
  const hasAcl = acl && acl.access && (Object.keys(acl.access.u || {}).length || Object.keys(acl.access.g || {}).length || acl.access.mask != null);

  push(out(`user::${bitsToStr(ownerBits)}`));
  if (hasAcl) {
    Object.keys(acl.access.u || {}).forEach((u) => {
      const b = acl.access.u[u];
      const line = `user:${u}:${bitsToStr(b)}`;
      push(out(effAnnot(line, b, acl.access.mask)));
    });
  }
  // owning group (masked if ACL present)
  const goBits = (hasAcl && acl.access.groupOwner != null) ? acl.access.groupOwner : groupBits;
  if (hasAcl) push(out(effAnnot(`group::${bitsToStr(goBits)}`, goBits, acl.access.mask)));
  else push(out(`group::${bitsToStr(goBits)}`));
  if (hasAcl) {
    Object.keys(acl.access.g || {}).forEach((g) => {
      const b = acl.access.g[g];
      push(out(effAnnot(`group:${g}:${bitsToStr(b)}`, b, acl.access.mask)));
    });
    if (acl.access.mask != null) push(out(`mask::${bitsToStr(acl.access.mask)}`));
  }
  push(out(`other::${bitsToStr(otherBits)}`));

  // default entries
  if (acl && acl.default) {
    const d = acl.default;
    push(out(`default:user::${bitsToStr(d.ownerU != null ? d.ownerU : ownerBits)}`));
    Object.keys(d.u || {}).forEach((u) => push(out(`default:user:${u}:${bitsToStr(d.u[u])}`)));
    push(out(`default:group::${bitsToStr(d.groupOwner != null ? d.groupOwner : goBits)}`));
    Object.keys(d.g || {}).forEach((g) => push(out(`default:group:${g}:${bitsToStr(d.g[g])}`)));
    if (d.mask != null) push(out(`default:mask::${bitsToStr(d.mask)}`));
    push(out(`default:other::${bitsToStr(d.other != null ? d.other : otherBits)}`));
  }
  push(out(''));
}

function effAnnot(lineStr, bits, mask) {
  if (mask == null) return lineStr;
  const eff = bits & mask;
  if (eff !== bits) {
    // pad to column then show #effective
    return `${lineStr.padEnd(24)}#effective:${bitsToStr(eff)}`;
  }
  return lineStr;
}

const HELP = [
  'FILES01 lab shell — available commands:',
  '  Recon:    ip a · whoami · id · groups · ls -la <dir> · tree <dir> · find <dir> -perm -o+r · cat <file>',
  '  Navigate: cd <dir> · pwd',
  '  Users:    su - <user> · su - <user> -c "<cmd>" · exit',
  '  Perms:    chmod [-R] <mode> <path> · chown [-R] <owner>:<group> <path> · umask [mask]',
  '  ACLs:     getfacl [-R] <path> · setfacl -b -R <path> · setfacl [-R] -m <spec> <path>',
  '  Files:    touch <file> · mkdir <dir> · rm [-rf] <path> · echo "text" > <file> · cp <src> <dst>',
  '  Shares:   smbclient //127.0.0.1/company -U <user>%<pass> · mount -t nfs4 127.0.0.1:/srv/company /mnt/tmp_nfs',
  '  Config:   sudo cp /etc/bash.bashrc /etc/bash.bashrc.bak · source /etc/bash.bashrc',
  '  Screen:   clear · help',
  '',
  'Tip: prefix admin actions with sudo. The Byte panel (right) tracks your 8 tasks.',
];

export { tokenize };
