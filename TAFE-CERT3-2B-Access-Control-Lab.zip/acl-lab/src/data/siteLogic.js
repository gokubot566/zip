/* ============================================================
   siteLogic.js — decides whether each gated task is complete,
   based on live simulated-filesystem + terminal state.

   state = { fs, env, flags }
     flags: sticky booleans the terminal sets when a one-shot action
            happens (e.g. read HR as marketing, pulled file over SMB).
   ============================================================ */

import { getNode, effPerms, USERS, HR_CONFIDENTIAL } from './fsEngine.js';

/* helper: does group g have exactly/at-least these perms on node via ACL? */
function groupAclBits(node, g) {
  if (!node.acl || !node.acl.access || !node.acl.access.g) return null;
  const b = node.acl.access.g[g];
  if (b == null) return null;
  const mask = node.acl.access.mask;
  return mask == null ? b : (b & mask);
}
function hasDefaultGroup(node, g) {
  return !!(node.acl && node.acl.default && node.acl.default.g && node.acl.default.g[g] != null);
}
function otherBits(node) { return node.mode & 7; }

export function isTaskDone(id, state) {
  const { fs, env, flags = {} } = state;
  const company = getNode(fs, '/srv/company');
  const hr = getNode(fs, '/srv/company/hr');
  const marketing = getNode(fs, '/srv/company/marketing');
  const it = getNode(fs, '/srv/company/it');
  const shared = getNode(fs, '/srv/company/shared');
  const backdoor = getNode(fs, '/srv/company/.backdoor');

  switch (id) {
    /* 1. Recon: read HR as student + revealed the backdoor */
    case 'recon':
      return !!flags.readHrAsStudent && !!flags.sawBackdoor;

    /* 2. Cross-dept + SMB leak demonstrated */
    case 'crossdept':
      return !!flags.readHrAsMarketing && !!flags.smbGotHr;

    /* 3. umask hardened to 007 */
    case 'umask':
      return env.umask === 0o007;

    /* 4. Backdoor emptied AND locked down (owned by root, no world/other access) */
    case 'backdoor': {
      if (!backdoor) return true; // deleted entirely is also fine
      const emptied = Object.keys(backdoor.children).length === 0;
      const locked = backdoor.owner === 'root' && (backdoor.mode & 0o077) === 0; // group+other have nothing (700 or 000)
      return emptied && locked;
    }

    /* 5. Baseline: dept folders group-owned correctly, mode 750, others = 0 */
    case 'baseline': {
      const okDir = (node, grp) =>
        node && node.group === grp && ((node.mode & 0o777) === 0o750);
      return okDir(hr, 'hr') && okDir(marketing, 'marketing') && okDir(it, 'it');
    }

    /* 6. HR ACLs: hr rwX, it r-x (read, no write), other none, with inheritance */
    case 'hracl': {
      if (!hr) return false;
      const hrBits = groupAclBits(hr, 'hr');
      const itBits = groupAclBits(hr, 'it');
      const hrOk = hrBits != null && (hrBits & 4) && (hrBits & 2);          // read+write
      const itOk = itBits != null && (itBits & 4) && !(itBits & 2);          // read, NOT write
      const otherOk = otherBits(hr) === 0;
      const inheritOk = hasDefaultGroup(hr, 'hr') && hasDefaultGroup(hr, 'it');
      return hrOk && itOk && otherOk && inheritOk;
    }

    /* 7. Marketing/IT/Shared ACLs applied with inheritance + others locked */
    case 'otheracl': {
      const deptOk = (node, grp) => {
        if (!node) return false;
        const b = groupAclBits(node, grp);
        return b != null && (b & 4) && (b & 2) && otherBits(node) === 0 && hasDefaultGroup(node, grp);
      };
      const sharedOk = (() => {
        if (!shared) return false;
        const b = groupAclBits(shared, 'staff');
        return b != null && (b & 4) && (b & 2) && hasDefaultGroup(shared, 'staff');
      })();
      return deptOk(marketing, 'marketing') && deptOk(it, 'it') && sharedOk;
    }

    /* 8. Validation: no world-readable sensitive files remain AND marketing denied on HR */
    case 'validate': {
      // no world-readable files under any department folder
      const noWorldRead = (node) => {
        if (!node) return true;
        let clean = true;
        const walk = (n) => {
          if (n.type === 'file' && (n.mode & 0o4)) clean = false;
          if (n.type === 'dir') Object.values(n.children).forEach(walk);
        };
        walk(node);
        return clean;
      };
      const deptClean = noWorldRead(hr) && noWorldRead(marketing) && noWorldRead(it);
      // marketing must be denied reading the HR folder now
      const mktDeniedHr = hr ? !effPerms(hr, 'marketinguser', null).r : true;
      return deptClean && mktDeniedHr && !!flags.ranFinalFind;
    }

    default:
      return false;
  }
}
