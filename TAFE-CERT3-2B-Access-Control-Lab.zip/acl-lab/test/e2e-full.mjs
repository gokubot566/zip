import puppeteer from 'puppeteer';
import http from 'http';
import { readFileSync, existsSync, statSync } from 'fs';
import { join, extname } from 'path';

const ROOT = new URL('../build', import.meta.url).pathname;
const CHROME = '/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome';
const PORT = 8911;
const MIME = { '.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.json':'application/json','.woff':'font/woff','.woff2':'font/woff2' };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  let fp = join(ROOT, p);
  if (!existsSync(fp) || !statSync(fp).isFile()) fp = join(ROOT, 'index.html');
  const data = readFileSync(fp);
  res.writeHead(200, { 'Content-Type': MIME[extname(fp)] || 'application/octet-stream' });
  res.end(data);
});

const results = [];
const check = (name, cond, detail='') => { results.push({ name, pass: !!cond, detail }); console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function main() {
  await new Promise((r) => server.listen(PORT, r));
  const browser = await puppeteer.launch({ executablePath: CHROME, headless: 'new', args: ['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 900 });

  const errors = [];
  page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('CONSOLE: ' + m.text()); });
  page.on('dialog', async (d) => { try { await d.accept(); } catch (e) {} });

  await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'networkidle0' });
  await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'networkidle0' });
  await sleep(700);

  async function clickByText(sel, text, tries = 20) {
    for (let i = 0; i < tries; i++) {
      const clicked = await page.evaluate((s, txt) => {
        for (const el of Array.from(document.querySelectorAll(s))) {
          const r = el.getBoundingClientRect();
          if (el.textContent && el.textContent.includes(txt) && r.width > 0 && r.height > 0 && !el.disabled) { el.click(); return true; }
        }
        return false;
      }, sel, text);
      if (clicked) return true;
      await sleep(150);
    }
    return false;
  }
  async function cmd(line) {
    await page.click('.term-input');
    await page.$eval('.term-input', (el) => { el.value = ''; });
    await page.type('.term-input', line, { delay: 0 });
    await page.keyboard.press('Enter');
    await sleep(40);
    // ssh login now prompts for a password; answer it (student) if masked
    const masked = await page.$eval('.term-input', (el) => el.getAttribute('type') === 'password').catch(() => false);
    if (masked) {
      await page.type('.term-input', 'student', { delay: 0 });
      await page.keyboard.press('Enter');
      await sleep(40);
    }
  }

  // ---------- A. MOUNT ----------
  check('terminal mounts', !!(await page.$('.term-root')));
  check('byte panel mounts (intro open)', !!(await page.$('.byte-panel')));

  // ---------- B. BYTE ROBOT IN HEADER (my change #1) ----------
  // header should contain the static ByteAvatar SVG, NOT a character <img>
  const headerHasRobotSvg = await page.$('.byte-head .byte-avatar svg') !== null;
  const headerHasCastImg = await page.$('.byte-head .cast-photo img') !== null;
  check('header shows static Byte robot (SVG avatar)', headerHasRobotSvg);
  check('header does NOT show a character photo', !headerHasCastImg);

  // The intro BODY should still introduce the human cast (character imgs present in body)
  const bodyCastImgs = await page.$$eval('.byte-body .cast-photo img', els => els.length).catch(() => 0);
  check('intro body still introduces human cast', bodyCastImgs > 0, `${bodyCastImgs} character photo(s) in body`);

  // ---------- C. NAVIGATE INTRO -> EXPLORE -> TASKS ----------
  await clickByText('.byte-hint-toggle', 'Skip introductions', 10);
  await sleep(250);
  check('clicked "look around"', await clickByText('.byte-next', 'look around', 20));
  await sleep(350);
  check('clicked "start the tasks"', await clickByText('.byte-next', 'start the tasks', 20));
  await sleep(450);
  check('reached task screen (tabs visible)', !!(await page.$('.byte-tabs')));

  // Collapse the launcher to verify the launcher badge/avatar too
  // (close then reopen the panel)
  await clickByText('.byte-x', '', 5); // the X button has no text; fallback below
  // The X has an svg only; click via selector directly:
  const closeBtn = await page.$('.byte-x');
  if (closeBtn) { await closeBtn.click(); await sleep(400); }
  const launcherRobot = await page.$('.byte-launcher .byte-avatar svg') !== null;
  const launcherCastImg = await page.$('.byte-launcher .cast-photo img') !== null;
  check('collapsed launcher shows static Byte robot', launcherRobot);
  check('collapsed launcher does NOT show character photo', !launcherCastImg);
  // reopen
  const launcher = await page.$('.byte-launcher');
  if (launcher) { await launcher.click(); await sleep(400); }
  check('panel reopens after launcher click', !!(await page.$('.byte-tabs')));

  // ---------- D. STEP-BY-STEP HINTS (my change #2) ----------
  // On task 1, open "Show the commands" and verify the structured walkthrough
  await sleep(200);
  const openedHint = await clickByText('.byte-hint-toggle', 'Show the commands', 10);
  check('"Show the commands" toggle works', openedHint);
  await sleep(300);
  const stepCount = await page.$$eval('.byte-step', els => els.length).catch(() => 0);
  check('structured step-by-step walkthrough renders', stepCount > 0, `${stepCount} steps on task 1`);
  const stepData = await page.evaluate(() => {
    const steps = Array.from(document.querySelectorAll('.byte-step'));
    return {
      numbered: steps.every((s, i) => (s.querySelector('.byte-step-num')?.textContent || '') === String(i + 1)),
      allHaveCmd: steps.every(s => !!s.querySelector('.byte-hint-cmd')),
      whatCount: steps.filter(s => /What it does/.test(s.textContent)).length,
      whyCount: steps.filter(s => /Why it matters/.test(s.textContent)).length,
    };
  });
  check('steps are numbered in order', stepData.numbered);
  check('every step shows its command', stepData.allHaveCmd);
  check('every step has a "What it does" note', stepData.whatCount === stepCount, `${stepData.whatCount}/${stepCount}`);
  check('every step has a "Why it matters" note', stepData.whyCount === stepCount, `${stepData.whyCount}/${stepCount}`);

  // Item 2: commands are read-only reference — clicking one must NOT auto-type
  // it into the terminal. The learner types every command themselves.
  await page.$eval('.term-input', el => { el.value = ''; });
  await page.$eval('.byte-step .byte-hint-cmd', el => el.click());
  await sleep(150);
  const afterClick = await page.$eval('.term-input', el => el.value).catch(() => 'x');
  check('clicking a command does NOT auto-fill the terminal (hands-on typing)', afterClick === '', `input="${afterClick}"`);

  // ---------- E. FULL 8-TASK WALKTHROUGH VIA UI ----------
  const steps = [
    ['recon', ['ip a','ssh student@10.50.0.11 -p 22','cat /srv/company/hr/confidential.txt','ls -la /srv/company','ls -la /srv/company/.backdoor']],
    ['crossdept', ['su - marketinguser -c "cat /srv/company/hr/confidential.txt"','smbclient //127.0.0.1/company -U student%student','get hr/confidential.txt leaked_smb.txt','exit']],
    ['umask', ['sudo cp /etc/bash.bashrc /etc/bash.bashrc.bak',"sudo sed -i '/umask/d' /etc/bash.bashrc",'echo "umask 007" | sudo tee -a /etc/bash.bashrc','source /etc/bash.bashrc','umask']],
    ['backdoor', ['sudo chown root:root /srv/company/.backdoor','sudo chmod 700 /srv/company/.backdoor','sudo rm -rf /srv/company/.backdoor/*','sudo chmod 000 /srv/company/.backdoor']],
    ['baseline', ['sudo setfacl -b -R /srv/company','sudo chown -R root:hr /srv/company/hr','sudo chown -R root:marketing /srv/company/marketing','sudo chown -R root:it /srv/company/it','sudo chmod 750 /srv/company/hr','sudo chmod 750 /srv/company/marketing','sudo chmod 750 /srv/company/it']],
    ['hracl', ['sudo setfacl -R -m g:hr:rwX /srv/company/hr','sudo setfacl -R -m d:g:hr:rwX /srv/company/hr','sudo setfacl -R -m g:it:r-X /srv/company/hr','sudo setfacl -R -m d:g:it:r-X /srv/company/hr','sudo setfacl -R -m g:marketing:--- /srv/company/hr','sudo setfacl -R -m o::---,d:o::--- /srv/company/hr']],
    ['otheracl', ['sudo setfacl -R -m g:marketing:rwX,d:g:marketing:rwX /srv/company/marketing','sudo setfacl -R -m o::---,d:o::--- /srv/company/marketing','sudo setfacl -R -m g:it:rwX,d:g:it:rwX /srv/company/it','sudo setfacl -R -m o::---,d:o::--- /srv/company/it','sudo setfacl -R -m g:staff:rwX,d:g:staff:rwX /srv/company/shared']],
    ['validate', ['find /srv/company -perm -o+r','su - marketinguser -c "ls /srv/company/hr"','su - marketinguser -c "cat /srv/company/hr/confidential.txt"']],
  ];

  let completed = 0;
  for (const [name, cmds] of steps) {
    // make sure we're on the "Current task" tab
    await clickByText('.byte-tabs button', 'Current task', 3);
    await sleep(120);
    for (const c of cmds) await cmd(c);
    await sleep(220);
    const enabled = await page.$eval('.byte-next', el => !el.disabled).catch(() => false);
    if (enabled) {
      await clickByText('.byte-next', 'Next task', 12);
      await sleep(320);
      completed++;
      console.log(`  task ${completed}/8 (${name}) — gate opened, advanced`);
    } else {
      console.log(`  !! gate did NOT open for ${name}`);
      break;
    }
  }
  check('all 8 tasks completed via UI', completed === 8, `${completed}/8`);

  // ---------- F. SUMMARY CARD ----------
  await sleep(700);
  let summary = await page.$('.byte-summary-title');
  if (!summary) { await sleep(800); summary = await page.$('.byte-summary-title'); }
  const summaryText = summary ? await page.$eval('.byte-summary-title', el => el.textContent) : '';
  check('summary/report card appears after 8 tasks', !!summary, summaryText);
  // report rows = 8
  const reportRows = await page.$$eval('.byte-report-row', els => els.length).catch(() => 0);
  check('report card lists all 8 tasks', reportRows === 8, `${reportRows} rows`);
  // summary shows the human cast row (characters reintroduced at the end, as designed)
  const summaryCast = await page.$$eval('.byte-cast-row .cast-photo img', els => els.length).catch(() => 0);
  check('summary shows human cast row', summaryCast > 0, `${summaryCast} portraits`);

  // ---------- G. NO JS ERRORS ----------
  const realErrors = errors.filter(e => e.includes('PAGEERROR'));
  check('no uncaught page errors', realErrors.length === 0, realErrors.slice(0, 3).join(' | '));

  await browser.close();
  server.close();

  const passed = results.filter(r => r.pass).length;
  const total = results.length;
  console.log(`\n==================== E2E SUMMARY ====================`);
  console.log(`${passed}/${total} checks passed`);
  const failedChecks = results.filter(r => !r.pass);
  if (failedChecks.length) { console.log('FAILED:'); failedChecks.forEach(r => console.log('  - ' + r.name + (r.detail ? ' — ' + r.detail : ''))); }
  console.log(`RESULT: ${passed === total ? 'ALL PASS ✓' : 'FAILURES ✗'}`);
  process.exit(passed === total ? 0 : 1);
}

main().catch((e) => { console.error(e); server.close(); process.exit(1); });
