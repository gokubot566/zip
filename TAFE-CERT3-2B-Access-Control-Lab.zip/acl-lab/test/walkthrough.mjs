import { runCommand, runSmbCommand } from '../src/data/terminalEngine.js';
import { initialFS, initialEnv } from '../src/data/fsEngine.js';
import { isTaskDone } from '../src/data/siteLogic.js';
import { TASK_ORDER } from '../src/data/scenario.js';

const state = { fs: initialFS(), env: initialEnv(), flags: {} };
let smb = null;
const locked = {}; // mirrors App's completed{} — tasks lock in and never revert

function lockInPass() {
  TASK_ORDER.forEach((id) => { if (isTaskDone(id, state)) locked[id] = true; });
}

function run(line, { silent = false } = {}) {
  if (smb) {
    const r = runSmbCommand(line, smb, state);
    (r.events || []).forEach((e) => { state.flags[e] = true; });
    if (!silent) r.lines.forEach((l) => console.log('  smb>', l.text));
    if (r.close) smb = null;
    return r;
  }
  const r = runCommand(line, state);
  (r.events || []).forEach((e) => { state.flags[e] = true; });
  if (r.smbSession) smb = r.smbSession;
  if (!silent) r.lines.forEach((l) => console.log('   ', (l.cls === 'err' ? '[ERR] ' : ''), l.text));
  return r;
}

function checkAll(labelAfter) {
  lockInPass();
  const status = TASK_ORDER.map((id) => `${id}:${(locked[id] || isTaskDone(id, state)) ? '✓' : '·'}`).join('  ');
  console.log(`\n[after ${labelAfter}] ${status}\n`);
}

console.log('===== RECON =====');
run('ip a', { silent: true });
run('ssh student@10.50.0.11 -p 22', { silent: true });
run('whoami');
run('id');
run('cat /srv/company/hr/confidential.txt', { silent: true });
run('ls -la /srv/company');
checkAll('recon');
console.log('recon done?', isTaskDone('recon', state));

console.log('===== CROSS-DEPT + SMB =====');
run('su - marketinguser -c "cat /srv/company/hr/confidential.txt"', { silent: true });
run('smbclient //127.0.0.1/company -U student%student', { silent: true });
run('get hr/confidential.txt leaked_smb.txt');
run('exit');
checkAll('crossdept');

console.log('===== UMASK =====');
run('sudo cp /etc/bash.bashrc /etc/bash.bashrc.bak', { silent: true });
run("sudo sed -i '/umask/d' /etc/bash.bashrc", { silent: true });
run('echo "umask 007" | sudo tee -a /etc/bash.bashrc', { silent: true });
run('source /etc/bash.bashrc', { silent: true });
run('umask');
checkAll('umask');

console.log('===== BACKDOOR =====');
run('sudo chown root:root /srv/company/.backdoor', { silent: true });
run('sudo chmod 700 /srv/company/.backdoor', { silent: true });
run('sudo rm -rf /srv/company/.backdoor/*', { silent: true });
run('sudo chmod 000 /srv/company/.backdoor', { silent: true });
checkAll('backdoor');

console.log('===== BASELINE =====');
run('sudo setfacl -b -R /srv/company', { silent: true });
run('sudo chmod -R 755 /srv/company', { silent: true });
run('sudo chown -R root:root /srv/company', { silent: true });
run('sudo chown -R root:hr /srv/company/hr', { silent: true });
run('sudo chown -R root:marketing /srv/company/marketing', { silent: true });
run('sudo chown -R root:it /srv/company/it', { silent: true });
run('sudo chown -R root:staff /srv/company/shared', { silent: true });
run('sudo chmod 750 /srv/company/hr', { silent: true });
run('sudo chmod 750 /srv/company/marketing', { silent: true });
run('sudo chmod 750 /srv/company/it', { silent: true });
run('sudo chmod 2775 /srv/company/shared', { silent: true });
checkAll('baseline');

console.log('===== HR ACLs =====');
run('sudo setfacl -R -m g:hr:rwX /srv/company/hr', { silent: true });
run('sudo setfacl -R -m d:g:hr:rwX /srv/company/hr', { silent: true });
run('sudo setfacl -R -m g:it:r-X /srv/company/hr', { silent: true });
run('sudo setfacl -R -m d:g:it:r-X /srv/company/hr', { silent: true });
run('sudo setfacl -R -m g:marketing:--- /srv/company/hr', { silent: true });
run('sudo setfacl -R -m o::--- /srv/company/hr', { silent: true });
run('sudo setfacl -R -m d:o::--- /srv/company/hr', { silent: true });
console.log('--- getfacl /srv/company/hr ---');
run('getfacl /srv/company/hr');
checkAll('hracl');

console.log('===== OTHER ACLs =====');
run('sudo setfacl -R -m g:marketing:rwX,d:g:marketing:rwX /srv/company/marketing', { silent: true });
run('sudo setfacl -R -m o::--- /srv/company/marketing', { silent: true });
run('sudo setfacl -R -m g:it:rwX,d:g:it:rwX /srv/company/it', { silent: true });
run('sudo setfacl -R -m o::--- /srv/company/it', { silent: true });
run('sudo setfacl -R -m g:staff:rwX,d:g:staff:rwX /srv/company/shared', { silent: true });
checkAll('otheracl');

console.log('===== VALIDATE =====');
console.log('--- find world-readable ---');
run('find /srv/company -perm -o+r');
console.log('--- marketing tries HR ---');
run('su - marketinguser -c "ls /srv/company/hr"');
checkAll('validate');

console.log('\n=================================');
lockInPass();
const allDone = TASK_ORDER.every((id) => locked[id]);
console.log('ALL 8 TASKS COMPLETE (lock-in model):', allDone ? 'YES ✓' : 'NO ✗');
console.log('locked:', JSON.stringify(locked));
console.log('flags:', JSON.stringify(state.flags));
process.exit(allDone ? 0 : 1);
