import puppeteer from 'puppeteer';
import http from 'http';
import { readFileSync, existsSync, statSync } from 'fs';
import { join, extname } from 'path';

const ROOT = new URL('../build', import.meta.url).pathname;
const CHROME = '/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome';
const PORT = 8912;
const OUT = '/home/claude/shots';
const MIME = { '.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.json':'application/json','.woff':'font/woff','.woff2':'font/woff2' };

import { mkdirSync } from 'fs';
mkdirSync(OUT, { recursive: true });

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  let fp = join(ROOT, p);
  if (!existsSync(fp) || !statSync(fp).isFile()) fp = join(ROOT, 'index.html');
  const data = readFileSync(fp);
  res.writeHead(200, { 'Content-Type': MIME[extname(fp)] || 'application/octet-stream' });
  res.end(data);
});
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function main() {
  await new Promise((r) => server.listen(PORT, r));
  const browser = await puppeteer.launch({ executablePath: CHROME, headless: 'new', args: ['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 900 });
  page.on('dialog', async (d) => { try { await d.accept(); } catch (e) {} });

  await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'networkidle0' });
  await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'networkidle0' });
  await sleep(1500); // let intro animate in

  async function clickByText(sel, text, tries = 20) {
    for (let i = 0; i < tries; i++) {
      const clicked = await page.evaluate((s, txt) => {
        for (const el of Array.from(document.querySelectorAll(s))) {
          const r = el.getBoundingClientRect();
          if (el.textContent && el.textContent.includes(txt) && r.width > 0 && r.height > 0 && !el.disabled) { el.click(); return true; }
        }
        return false;
      }, sel, text);
      if (clicked) return true;
      await sleep(150);
    }
    return false;
  }

  // 1. Intro — robot on top, cast introduced in the body
  await clickByText('.byte-hint-toggle', 'Skip introductions', 10);
  await sleep(500);
  await page.screenshot({ path: join(OUT, '1-intro.png') });

  // 2. To tasks
  await clickByText('.byte-next', 'look around', 20); await sleep(400);
  await clickByText('.byte-next', 'start the tasks', 20); await sleep(500);
  await page.screenshot({ path: join(OUT, '2-task1.png') });

  // 3. Expand the step-by-step walkthrough
  await clickByText('.byte-hint-toggle', 'Show the commands', 10);
  await sleep(400);
  // scroll the byte body so steps are visible
  await page.evaluate(() => { const b = document.querySelector('.byte-body'); if (b) b.scrollTop = 220; });
  await sleep(200);
  await page.screenshot({ path: join(OUT, '3-steps.png') });
  // full-panel closeup of the steps
  const panel = await page.$('.byte-panel');
  if (panel) await panel.screenshot({ path: join(OUT, '3b-steps-panel.png') });

  // 4. Collapsed launcher (robot)
  const closeBtn = await page.$('.byte-x'); if (closeBtn) { await closeBtn.click(); await sleep(500); }
  await page.screenshot({ path: join(OUT, '4-launcher.png') });
  const launcherEl = await page.$('.byte-launcher');
  if (launcherEl) await launcherEl.screenshot({ path: join(OUT, '4b-launcher-closeup.png') });
  const l2 = await page.$('.byte-launcher'); if (l2) { await l2.click(); await sleep(400); }

  console.log('screenshots written to', OUT);
  await browser.close();
  server.close();
}
main().catch((e) => { console.error(e); server.close(); process.exit(1); });
