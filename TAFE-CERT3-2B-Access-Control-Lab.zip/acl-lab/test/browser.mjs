import puppeteer from 'puppeteer';
import http from 'http';
import { readFileSync, existsSync, statSync } from 'fs';
import { join, extname } from 'path';

const ROOT = new URL('../build', import.meta.url).pathname;
const CHROME = '/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome';
const PORT = 8899;

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.json': 'application/json' };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  let fp = join(ROOT, p);
  if (!existsSync(fp) || !statSync(fp).isFile()) fp = join(ROOT, 'index.html'); // SPA fallback
  const data = readFileSync(fp);
  res.writeHead(200, { 'Content-Type': MIME[extname(fp)] || 'application/octet-stream' });
  res.end(data);
});

async function main() {
  await new Promise((r) => server.listen(PORT, r));
  const browser = await puppeteer.launch({ executablePath: CHROME, headless: 'new', args: ['--no-sandbox'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 900 });

  const errors = [];
  page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('CONSOLE: ' + m.text()); });

  await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'networkidle0' });
  await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'networkidle0' });
  await new Promise((r) => setTimeout(r, 600));

  // 1. Terminal mounted?
  const hasTerm = await page.$('.term-root');
  console.log('terminal mounted:', !!hasTerm);

  // 2. Byte mounted with intro?
  const hasByte = await page.$('.byte-panel');
  console.log('byte panel mounted:', !!hasByte);

  // helper: type a command into the terminal input and press Enter
  async function cmd(line) {
    await page.click('.term-input');
    await page.$eval('.term-input', (el) => { el.value = ''; });
    await page.type('.term-input', line, { delay: 0 });
    await page.keyboard.press('Enter');
    await new Promise((r) => setTimeout(r, 40));
  }

  // Skip Byte intro + explore to reach the tasks
  // Intro: click "Skip introductions" then the start button; robust approach: click all byte-next/hint-toggle as they appear
  async function clickByText(sel, text, tries = 20) {
    for (let i = 0; i < tries; i++) {
      const clicked = await page.evaluate((s, txt) => {
        const els = Array.from(document.querySelectorAll(s));
        for (const el of els) {
          const r = el.getBoundingClientRect();
          if (el.textContent && el.textContent.includes(txt) && r.width > 0 && r.height > 0 && !el.disabled) {
            el.click();
            return true;
          }
        }
        return false;
      }, sel, text);
      if (clicked) return true;
      await new Promise((r) => setTimeout(r, 200));
    }
    return false;
  }

  // accept any confirm() dialogs (restart/reset)
  page.on('dialog', async (d) => { try { await d.accept(); } catch (e) {} });

  // --- Intro: skip animation, then "look around" ---
  await new Promise((r) => setTimeout(r, 400));
  await clickByText('.byte-hint-toggle', 'Skip introductions', 10);
  await new Promise((r) => setTimeout(r, 300));
  const gotLook = await clickByText('.byte-next', 'look around', 20);
  console.log('clicked "look around":', gotLook);
  await new Promise((r) => setTimeout(r, 400));
  // --- Explore: start the tasks ---
  const gotStart = await clickByText('.byte-next', 'start the tasks', 20);
  console.log('clicked "start the tasks":', gotStart);
  await new Promise((r) => setTimeout(r, 500));
  // confirm we're on a task screen (tabs visible)
  const onTasks = await page.$('.byte-tabs');
  console.log('reached task screen:', !!onTasks);

  // Read the current task label
  await new Promise((r) => setTimeout(r, 300));
  const taskLabel = await page.$eval('.byte-area', (el) => el.textContent).catch(() => '(none)');
  console.log('active task after intro:', taskLabel);

  async function advance(label) {
    const ok = await clickByText('.byte-next', 'Next task', 15);
    await new Promise((r) => setTimeout(r, 350));
    return ok;
  }

  // Full 8-task command sequence
  const steps = [
    ['recon', ['ip a', 'ssh student@10.50.0.11 -p 22', 'cat /srv/company/hr/confidential.txt', 'tree /srv/company']],
    ['crossdept', ['su - marketinguser -c "cat /srv/company/hr/confidential.txt"', 'smbclient //127.0.0.1/company -U student%student', 'get hr/confidential.txt leaked_smb.txt', 'exit']],
    ['umask', ['sudo cp /etc/bash.bashrc /etc/bash.bashrc.bak', "sudo sed -i '/umask/d' /etc/bash.bashrc", 'echo "umask 007" | sudo tee -a /etc/bash.bashrc', 'source /etc/bash.bashrc', 'umask']],
    ['backdoor', ['sudo chown root:root /srv/company/.backdoor', 'sudo chmod 700 /srv/company/.backdoor', 'sudo rm -rf /srv/company/.backdoor/*', 'sudo chmod 000 /srv/company/.backdoor']],
    ['baseline', ['sudo setfacl -b -R /srv/company', 'sudo chmod -R 755 /srv/company', 'sudo chown -R root:root /srv/company', 'sudo chown -R root:hr /srv/company/hr', 'sudo chown -R root:marketing /srv/company/marketing', 'sudo chown -R root:it /srv/company/it', 'sudo chown -R root:staff /srv/company/shared', 'sudo chmod 750 /srv/company/hr', 'sudo chmod 750 /srv/company/marketing', 'sudo chmod 750 /srv/company/it', 'sudo chmod 2775 /srv/company/shared']],
    ['hracl', ['sudo setfacl -R -m g:hr:rwX /srv/company/hr', 'sudo setfacl -R -m d:g:hr:rwX /srv/company/hr', 'sudo setfacl -R -m g:it:r-X /srv/company/hr', 'sudo setfacl -R -m d:g:it:r-X /srv/company/hr', 'sudo setfacl -R -m g:marketing:--- /srv/company/hr', 'sudo setfacl -R -m o::--- /srv/company/hr', 'sudo setfacl -R -m d:o::--- /srv/company/hr']],
    ['otheracl', ['sudo setfacl -R -m g:marketing:rwX,d:g:marketing:rwX /srv/company/marketing', 'sudo setfacl -R -m o::--- /srv/company/marketing', 'sudo setfacl -R -m g:it:rwX,d:g:it:rwX /srv/company/it', 'sudo setfacl -R -m o::--- /srv/company/it', 'sudo setfacl -R -m g:staff:rwX,d:g:staff:rwX /srv/company/shared']],
    ['validate', ['find /srv/company -perm -o+r', 'su - marketinguser -c "ls /srv/company/hr"']],
  ];

  let completed = 0;
  for (const [name, cmds] of steps) {
    for (const c of cmds) await cmd(c);
    await new Promise((r) => setTimeout(r, 200));
    const enabled = await page.$eval('.byte-next', (el) => !el.disabled).catch(() => false);
    console.log(`task ${name}: gate open = ${enabled}`);
    if (enabled) { await advance(name); completed++; }
    else { console.log(`  !! gate did NOT open for ${name}`); break; }
  }
  console.log(`\ntasks completed via UI: ${completed}/8`);

  // After 8, summary card should appear
  await new Promise((r) => setTimeout(r, 800));
  let summaryShown = await page.$('.byte-summary-title');
  if (!summaryShown) { await new Promise((r) => setTimeout(r, 800)); summaryShown = await page.$('.byte-summary-title'); }
  const summaryText = summaryShown ? await page.$eval('.byte-summary-title', (el) => el.textContent) : null;
  console.log('summary card shown:', !!summaryShown, summaryText ? `("${summaryText}")` : '');
  // debug: what does the byte sub-header say + progress pips
  const sub = await page.$eval('.byte-sub', (el) => el.textContent).catch(() => '(no sub)');
  const pips = await page.$$eval('.byte-pip', (els) => els.map((e) => e.className).join(' | ')).catch(() => '(no pips)');
  console.log('byte sub:', sub);
  console.log('pips:', pips);

  console.log('\n=== JS ERRORS ===');
  if (errors.length === 0) console.log('none ✓');
  else errors.filter((e) => !e.includes('fonts.googleapis')).slice(0, 20).forEach((e) => console.log(e));

  const realErrors = errors.filter((e) => e.includes('PAGEERROR'));
  await browser.close();
  server.close();
  const pass = completed === 8 && !!summaryShown && realErrors.length === 0;
  console.log('\nRESULT:', pass ? 'PASS ✓' : 'FAIL ✗');
  process.exit(pass ? 0 : 1);
}

main().catch((e) => { console.error(e); server.close(); process.exit(1); });
