import puppeteer from 'puppeteer';
import http from 'http';
import { readFileSync, existsSync, statSync } from 'fs';
import { join, extname } from 'path';

const ROOT = new URL('../build', import.meta.url).pathname;
const CHROME = '/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome';
const PORT = 8913;
const MIME = { '.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.json':'application/json','.woff':'font/woff','.woff2':'font/woff2' };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  let fp = join(ROOT, p);
  if (!existsSync(fp) || !statSync(fp).isFile()) fp = join(ROOT, 'index.html');
  const data = readFileSync(fp);
  res.writeHead(200, { 'Content-Type': MIME[extname(fp)] || 'application/octet-stream' });
  res.end(data);
});

const results = [];
const check = (name, cond, detail='') => { results.push({ name, pass: !!cond }); console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function main() {
  await new Promise((r) => server.listen(PORT, r));
  const browser = await puppeteer.launch({ executablePath: CHROME, headless: 'new', args: ['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 900 });
  const errors = [];
  page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message));
  page.on('dialog', async (d) => { try { await d.accept(); } catch (e) {} });

  await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'networkidle0' });
  await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'networkidle0' });
  await sleep(700);

  async function clickByText(sel, text, tries = 20) {
    for (let i = 0; i < tries; i++) {
      const clicked = await page.evaluate((s, txt) => {
        for (const el of Array.from(document.querySelectorAll(s))) {
          const r = el.getBoundingClientRect();
          if (el.textContent && el.textContent.includes(txt) && r.width > 0 && r.height > 0 && !el.disabled) { el.click(); return true; }
        }
        return false;
      }, sel, text);
      if (clicked) return true;
      await sleep(150);
    }
    return false;
  }
  async function cmd(line) {
    await page.click('.term-input');
    await page.$eval('.term-input', (el) => { el.value = ''; });
    await page.type('.term-input', line, { delay: 0 });
    await page.keyboard.press('Enter');
    await sleep(40);
  }
  const areaText = () => page.$eval('.byte-area', el => el.textContent).catch(() => '(none)');
  const backVisible = () => page.$('.byte-back').then(el => !!el);

  // reach tasks
  await clickByText('.byte-hint-toggle', 'Skip introductions', 10); await sleep(250);
  await clickByText('.byte-next', 'look around', 20); await sleep(350);
  await clickByText('.byte-next', 'start the tasks', 20); await sleep(500);

  // On task 1, there is no previous task -> NO back button
  const t1 = await areaText();
  check('on Task 1', /Task 1/.test(t1), t1);
  check('no Back button on Task 1 (nothing to go back to)', !(await backVisible()));

  // Complete task 1
  for (const c of ['ip a','ssh student@10.50.0.11 -p 22','cat /srv/company/hr/confidential.txt','tree /srv/company']) await cmd(c);
  await sleep(200);
  check('Task 1 gate open (Next enabled)', await page.$eval('.byte-next', el => !el.disabled).catch(() => false));
  await clickByText('.byte-next', 'Next task', 12); await sleep(350);

  // Now on task 2 -> Back button should appear
  const t2 = await areaText();
  check('advanced to Task 2', /Task 2/.test(t2), t2);
  check('Back button appears on Task 2', await backVisible());

  // Complete task 2 and advance to task 3
  for (const c of ['su - marketinguser -c "cat /srv/company/hr/confidential.txt"','smbclient //127.0.0.1/company -U student%student','get hr/confidential.txt leaked_smb.txt','exit']) await cmd(c);
  await sleep(200);
  await clickByText('.byte-next', 'Next task', 12); await sleep(350);
  const t3 = await areaText();
  check('advanced to Task 3', /Task 3/.test(t3), t3);

  // --- GO BACK from task 3 -> task 2 ---
  await clickByText('.byte-back', 'Back', 10); await sleep(350);
  const backTo2 = await areaText();
  check('Back navigates Task 3 -> Task 2', /Task 2/.test(backTo2), backTo2);

  // Reviewing note should show, and Next should be available (task 2 already completed)
  const reviewNote = await page.$('.byte-review-note') !== null;
  check('shows "reviewing an earlier task" note', reviewNote);
  const nextEnabledOnReview = await page.$eval('.byte-next', el => !el.disabled).catch(() => false);
  const nextLabel = await page.$eval('.byte-next', el => el.textContent).catch(() => '');
  check('Next is enabled on a reviewed completed task', nextEnabledOnReview, `label="${nextLabel.trim()}"`);
  check('Next label says "Next task" (not Locked)', /Next task/.test(nextLabel));

  // Go back again -> task 1
  await clickByText('.byte-back', 'Back', 10); await sleep(350);
  const backTo1 = await areaText();
  check('Back navigates Task 2 -> Task 1', /Task 1/.test(backTo1), backTo1);
  check('no Back button again on Task 1', !(await backVisible()));

  // Progress preserved: pips should still show 2 done
  const donePips = await page.$$eval('.byte-pip.done', els => els.length).catch(() => -1);
  check('progress preserved (2 tasks still marked done)', donePips === 2, `${donePips} done pips`);

  // Move forward again via Next twice, back to task 3
  await clickByText('.byte-next', 'Next task', 12); await sleep(300);
  await clickByText('.byte-next', 'Next task', 12); await sleep(300);
  const forwardTo3 = await areaText();
  check('can move forward again to Task 3', /Task 3/.test(forwardTo3), forwardTo3);
  // Task 3 was NOT completed, so if shell state was reset it might gate; but we didn't reset, and umask isn't done -> should be Locked
  const t3NextEnabled = await page.$eval('.byte-next', el => !el.disabled).catch(() => false);
  check('Task 3 (not yet completed) is still gated/Locked', !t3NextEnabled);

  check('no uncaught page errors', errors.filter(e => e.includes('PAGEERROR')).length === 0, errors.slice(0,2).join(' | '));

  await browser.close();
  server.close();
  const passed = results.filter(r => r.pass).length, total = results.length;
  console.log(`\n==================== BACK-NAV SUMMARY ====================`);
  console.log(`${passed}/${total} checks passed`);
  results.filter(r => !r.pass).forEach(r => console.log('  FAILED: ' + r.name));
  console.log(`RESULT: ${passed === total ? 'ALL PASS ✓' : 'FAILURES ✗'}`);
  process.exit(passed === total ? 0 : 1);
}
main().catch((e) => { console.error(e); server.close(); process.exit(1); });
