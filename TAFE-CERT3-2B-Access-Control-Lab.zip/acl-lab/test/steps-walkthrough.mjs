import { runCommand, runSmbCommand } from '../src/data/terminalEngine.js';
import { initialFS, initialEnv } from '../src/data/fsEngine.js';
import { isTaskDone } from '../src/data/siteLogic.js';
import { TASK_ORDER, TASKS } from '../src/data/scenario.js';

/* Drives the engine using ONLY the commands documented in each task's
   `steps` array — proving a student who clicks through the walkthrough,
   line by line, actually completes every gated task. Read-only verify
   commands (ls/getfacl/id/umask-with-no-arg) are harmless no-ops here. */

const state = { fs: initialFS(), env: initialEnv(), flags: {} };
let smb = null;
const locked = {};

function run(line) {
  if (smb) {
    const r = runSmbCommand(line, smb, state);
    (r.events || []).forEach((e) => { state.flags[e] = true; });
    if (r.close) smb = null;
    return r;
  }
  const r = runCommand(line, state);
  (r.events || []).forEach((e) => { state.flags[e] = true; });
  if (r.smbSession) smb = r.smbSession;
  return r;
}

let failed = false;
for (const task of TASKS) {
  for (const step of task.steps) run(step.cmd);
  TASK_ORDER.forEach((id) => { if (isTaskDone(id, state)) locked[id] = true; });
  const done = !!locked[task.id];
  console.log(`${done ? '✓' : '✗'}  ${task.id} (task ${task.n}) — ${task.steps.length} documented commands`);
  if (!done) failed = true;
}

const all = TASK_ORDER.every((id) => locked[id]);
console.log('\nDocumented steps complete every task:', all ? 'YES ✓' : 'NO ✗');
process.exit(all && !failed ? 0 : 1);
