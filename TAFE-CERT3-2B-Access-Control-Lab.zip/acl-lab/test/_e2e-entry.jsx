// Bundled + run by e2e-jsdom.mjs inside jsdom. Mounts the real <App/> and
// drives the whole lab through real DOM events: intro → explore → all 8 tasks
// typed into the terminal → completion. Also verifies Ahmed's four fixes.
import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import App from '../src/App.jsx';

const log = [];
const say = (m) => { log.push(m); console.log('  ' + m); };
let n = 0;
const step = (m) => say(`[${String(++n).padStart(2, '0')}] ${m}`);
function assert(cond, m) { if (!cond) throw new Error('ASSERT FAILED: ' + m); say('   ✓ ' + m); }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function tick(fn) { await act(async () => { if (fn) fn(); await sleep(0); }); await sleep(0); }
async function waitFor(pred, label, timeout = 12000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) { let v; try { v = pred(); } catch { v = false; } if (v) return true; await tick(); await sleep(25); }
  throw new Error('TIMEOUT waiting for: ' + label);
}

const $ = (s) => document.querySelector(s);
const $all = (s) => Array.from(document.querySelectorAll(s));
const byText = (sel, re) => $all(sel).filter((e) => re.test(e.textContent || ''));
const btn = (re) => byText('button', re).find((b) => !b.disabled) || byText('button', re)[0] || null;
function click(el) { if (!el) throw new Error('click: missing element'); el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true })); }
function setInput(el, v) {
  const set = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  set.call(el, v); el.dispatchEvent(new window.Event('input', { bubbles: true }));
}
const scrollbackText = () => ($('.term-scroll')?.textContent || '');

// Type one command into the terminal and submit the form (as a user would).
async function term(cmd) {
  const input = $('.term-input');
  if (!input) throw new Error('terminal input not found');
  await tick(() => setInput(input, cmd));
  await tick(() => { const f = input.closest('form'); f.dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true })); });
}
// Run a command and return only the NEW terminal output it produced.
async function termCapture(cmd) {
  const before = scrollbackText().length;
  await term(cmd);
  return scrollbackText().slice(before);
}
async function runAll(cmds) { for (const c of cmds) await term(c); }

// Answer an interactive `su` password prompt: the same .term-input is reused,
// but it is now a masked password field. Type the password and submit.
async function pwEntry(pw) {
  const input = $('.term-input');
  if (!input) throw new Error('password input not found');
  await tick(() => setInput(input, pw));
  await tick(() => { const f = input.closest('form'); f.dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true })); });
}

const doneCount = () => $all('.byte-pip.done').length;
async function nextTask(expectFrom) {
  const b = () => byText('.byte-next', /next task/i).find((x) => !x.disabled);
  await waitFor(() => b(), `Next unlocked after ${expectFrom}`);
  const before = doneCount();
  await tick(() => click(b()));
  await waitFor(() => doneCount() > before || $('.byte-summary-title'), `advance past ${expectFrom}`);
}

const TASKS = {
  recon: ['ssh student@10.50.0.11 -p 22', 'id', 'cat /srv/company/hr/confidential.txt', 'ls -la /srv/company'],
  crossdept: ['su - marketinguser -c "cat /srv/company/hr/confidential.txt"', 'smbclient //127.0.0.1/company -U student%student', 'get hr/confidential.txt leaked_smb.txt', 'exit'],
  umask: ['sudo cp /etc/bash.bashrc /etc/bash.bashrc.bak', 'echo "umask 007" | sudo tee -a /etc/bash.bashrc', 'source /etc/bash.bashrc', 'umask'],
  backdoor: ['sudo chown -R root:root /srv/company/.backdoor', 'sudo rm -rf /srv/company/.backdoor/*', 'sudo chmod 000 /srv/company/.backdoor'],
  baseline: ['sudo setfacl -b -R /srv/company', 'sudo chown -R root:hr /srv/company/hr', 'sudo chown -R root:marketing /srv/company/marketing', 'sudo chown -R root:it /srv/company/it', 'sudo chmod 750 /srv/company/hr', 'sudo chmod 750 /srv/company/marketing', 'sudo chmod 750 /srv/company/it'],
  hracl: ['sudo setfacl -R -m g:hr:rwX /srv/company/hr', 'sudo setfacl -R -m d:g:hr:rwX /srv/company/hr', 'sudo setfacl -R -m g:it:r-X /srv/company/hr', 'sudo setfacl -R -m d:g:it:r-X /srv/company/hr', 'sudo setfacl -R -m g:marketing:--- /srv/company/hr', 'sudo setfacl -R -m o::--- /srv/company/hr', 'sudo setfacl -R -m d:o::--- /srv/company/hr'],
  otheracl: ['sudo setfacl -R -m g:marketing:rwX,d:g:marketing:rwX /srv/company/marketing', 'sudo setfacl -R -m o::--- /srv/company/marketing', 'sudo setfacl -R -m g:it:rwX,d:g:it:rwX /srv/company/it', 'sudo setfacl -R -m o::--- /srv/company/it', 'sudo setfacl -R -m g:staff:rwX,d:g:staff:rwX /srv/company/shared'],
  validate: ['find /srv/company -perm -o+r', 'su - marketinguser -c "ls /srv/company/hr"'],
};

async function run() {
  const container = document.getElementById('root');
  await act(async () => { createRoot(container).render(React.createElement(App)); });
  await tick();

  // ---- INTRO ----
  step('Byte intro → meet the team → explore');
  await waitFor(() => btn(/skip ahead/i) || btn(/meet the team/i), 'intro page');
  if (btn(/skip ahead/i)) await tick(() => click(btn(/skip ahead/i)));
  await waitFor(() => btn(/meet the team/i), 'meet-the-team button');
  await tick(() => click(btn(/meet the team/i)));
  await waitFor(() => btn(/show everyone/i) || btn(/look around/i), 'team page');
  if (btn(/show everyone/i)) await tick(() => click(btn(/show everyone/i)));
  await waitFor(() => btn(/look around/i), 'look-around button');
  await tick(() => click(btn(/look around/i)));
  await waitFor(() => btn(/start the tasks/i), 'explore step');
  assert(!/drop it straight into the terminal|clicking a command drops/i.test(document.body.textContent), 'No "auto-type command" wording anywhere (fix 2)');
  await tick(() => click(btn(/start the tasks/i)));
  await waitFor(() => $('.byte-tabs') || byText('.byte-next', /next task|locked/i).length, 'task view');

  // ---- FIX 3: .backdoor is genuinely hidden (dot-prefixed) ----
  step('Fix 3 — .backdoor hidden from plain ls/tree, shown by ls -la');
  await term('ssh student@10.50.0.11 -p 22');
  const lsPlain = await termCapture('ls /srv/company');
  assert(!/\.backdoor/.test(lsPlain), 'plain `ls` does NOT show .backdoor');
  const treePlain = await termCapture('tree /srv/company');
  assert(!/\.backdoor/.test(treePlain), 'plain `tree` does NOT show .backdoor');
  const lsAll = await termCapture('ls -la /srv/company');
  assert(/\.backdoor/.test(lsAll), '`ls -la` reveals .backdoor');
  const treeAll = await termCapture('tree -a /srv/company');
  assert(/\.backdoor/.test(treeAll), '`tree -a` reveals .backdoor');

  // ---- FIX 2: clicking a command must NOT auto-type into the terminal ----
  step('Fix 2 — commands are read-only reference (no auto-type)');
  await tick(() => { const t = btn(/show the commands/i); if (t) click(t); });
  await waitFor(() => $('.byte-hint-cmd') || $('.byte-step'), 'command list visible');
  await tick(() => setInput($('.term-input'), ''));
  const cmdChip = $('.byte-hint-cmd') || $('.byte-cmd');
  await tick(() => click(cmdChip));
  assert(($('.term-input').value || '') === '', 'Clicking a command does NOT fill the terminal input');

  // ---- FULL 8-TASK WALKTHROUGH (typed by the "learner") ----
  step('Task 1 — Reconnaissance');
  await runAll(TASKS.recon);

  // NEW — Task 1 brief presents SSH credentials + host IP and a numbered
  // 2-item objective list (reviewer round 2).
  step('Task 1 brief — SSH credentials + numbered objectives');
  const brief = $('.byte-brief');
  assert(!!brief, 'Task 1 brief is rendered');
  assert(!!brief.querySelector('.byte-creds'), 'SSH connection-details callout present');
  assert(/10\.50\.0\.11/.test(brief.textContent), 'Host IP 10.50.0.11 shown in credentials');
  assert(/student/.test(brief.querySelector('.byte-creds').textContent), 'SSH username/password shown in credentials');
  const objList = brief.querySelector('ol.byte-obj');
  assert(!!objList, 'Objectives render as an ordered (numbered) list');
  assert(objList.querySelectorAll('li').length === 2, 'Exactly two numbered objectives');
  assert(/confidential\.txt/.test(objList.textContent) && /\.backdoor/.test(objList.textContent), 'Objectives name the HR file and the hidden .backdoor directory');

  await nextTask('recon');
  assert(doneCount() >= 1, 'Task 1 locked in');

  // NEW — interactive `su` prompts for a password through the real terminal UI
  // (reviewer round 2): wrong password fails, correct password switches.
  step('Interactive su — masked password prompt (wrong → fail, right → switch)');
  const beforeSu = scrollbackText().length;
  await term('su - marketinguser');
  await waitFor(() => /Password:/.test(scrollbackText()), 'su raises a Password: prompt');
  assert(($('.term-input').getAttribute('type') || '') === 'password', 'input is masked while entering the su password');
  await pwEntry('wrongpw');
  await waitFor(() => /Authentication failure/.test(scrollbackText()), 'wrong password → "su: Authentication failure"');
  assert(($('.term-input').getAttribute('type') || 'text') !== 'password', 'prompt cleared after a failed attempt (not switched)');
  await term('su - marketinguser');
  await waitFor(() => /Password:/.test(scrollbackText().slice(beforeSu).split('Authentication failure').pop()), 'su prompts again');
  await pwEntry('marketinguser');
  await waitFor(() => /switched to marketinguser/.test(scrollbackText()), 'correct password → switched to marketinguser');
  await term('cat /srv/company/hr/confidential.txt');
  await term('exit');

  step('Task 2 — Cross-department & SMB (su - marketinguser, fix 4)');
  await runAll(TASKS.crossdept);
  await nextTask('crossdept');
  assert(doneCount() >= 2, 'Task 2 locked in (marketinguser + SMB leak proven)');

  step('Task 3 — Secure umask');
  await runAll(TASKS.umask);
  await nextTask('umask');

  step('Task 4 — Neutralize the .backdoor');
  await runAll(TASKS.backdoor);
  await nextTask('backdoor');

  step('Task 5 — Ownership & base permissions');
  await runAll(TASKS.baseline);
  await nextTask('baseline');

  step('Task 6 — HR ACLs');
  await runAll(TASKS.hracl);
  await nextTask('hracl');

  step('Task 7 — Marketing/IT/Shared ACLs');
  await runAll(TASKS.otheracl);
  await nextTask('otheracl');

  step('Task 8 — Final validation');
  await runAll(TASKS.validate);
  await nextTask('validate');

  // ---- COMPLETION ----
  step('Completion — report card');
  await waitFor(() => $('.byte-summary-title') || /server secured/i.test(document.body.textContent), 'summary screen');
  assert(/server secured|audit-ready/i.test(document.body.textContent), 'Summary shows "Server secured — audit-ready"');
  assert(byText('button', /restart lab/i).length === 1, 'Exactly one "Restart lab" control');

  // ---- FIX 1: panel chrome is present & pinned (layout can't be pixel-measured in jsdom) ----
  step('Fix 1 — assistant panel structure (pinned chrome present)');
  assert(!!$('.byte-panel'), 'Byte panel is rendered');
  assert(!!$('.byte-foot'), 'Panel footer (pinned) is present');

  say('\nALL E2E STEPS PASSED ✅');
  return true;
}

globalThis.__E2E = run().then(
  () => ({ ok: true, log }),
  (e) => { console.error('\n✘ ' + e.message); return { ok: false, error: e.message, log }; },
);
