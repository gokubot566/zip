import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, CheckCircle, ArrowLeft, ArrowRight, ClipboardList } from 'lucide-react';
import Header from './components/Header.jsx';
import Sidebar from './components/Sidebar.jsx';
import ModuleContent from './components/ModuleContent.jsx';
import ByteAssistant from './components/ByteAssistant.jsx';
import { ALL_MODULES } from './modules/moduleData.js';

const STORAGE_KEY = 'si_onboarding_v4';

function load() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); }
  catch { return {}; }
}
function save(s) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(s)); } catch {}
}

function rgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex || '#3b82f6');
  return r ? `${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}` : '59,130,246';
}

// ── Module Hero ───────────────────────────────────────────────────────────────
function ModuleHero({ mod, isComplete }) {
  const c = mod.color;
  return (
    <motion.div
      initial={{ opacity:0, y:16 }} animate={{ opacity:1, y:0 }}
      transition={{ duration:0.45, ease:[0.16,1,0.3,1] }}
      style={{
        position:'relative', borderRadius:20, overflow:'hidden', marginBottom:24,
        background:`linear-gradient(140deg,rgba(${rgb(c)},.1) 0%,rgba(${rgb(c)},.03) 55%,transparent 100%)`,
        border:`1px solid rgba(${rgb(c)},.2)`,
        padding:'34px 38px',
      }}
    >
      {/* Grid */}
      <div style={{ position:'absolute',inset:0,opacity:.025, backgroundImage:`linear-gradient(rgba(${rgb(c)},1) 1px,transparent 1px),linear-gradient(90deg,rgba(${rgb(c)},1) 1px,transparent 1px)`, backgroundSize:'44px 44px', pointerEvents:'none' }} />
      {/* Glow */}
      <div style={{ position:'absolute',top:-100,right:-80,width:320,height:320,borderRadius:'50%', background:`radial-gradient(circle,rgba(${rgb(c)},.18) 0%,transparent 70%)`, pointerEvents:'none' }} />
      {/* Big emoji bg */}
      <div style={{ position:'absolute',right:38,top:'50%',transform:'translateY(-50%)',fontSize:80,opacity:.06,pointerEvents:'none',userSelect:'none' }}>{mod.icon}</div>

      <div style={{ position:'relative' }}>
        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:16 }}>
          <span className="label label-blue">{`MOD ${String(mod.id).padStart(2,'0')}`}</span>
          <span className="label label-gray">⏱ {mod.duration}</span>
          {isComplete && <span className="label label-green">✓ COMPLETE</span>}
        </div>

        <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:10 }}>
          <span style={{ fontSize:30, lineHeight:1 }}>{mod.icon}</span>
          <h1 style={{
            fontFamily:"'Fraunces',Georgia,serif", fontWeight:700, fontSize:28, lineHeight:1.18,
            color:'var(--t1)', letterSpacing:'-0.02em',
          }}>{mod.title}</h1>
        </div>

        {/* Policy subtitle (maps to) */}
        {mod.subtitle && (
          <p style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:11, color:'var(--t3)', marginBottom:18, letterSpacing:'0.03em' }}>
            Maps to: {mod.subtitle}
          </p>
        )}

        {/* Learning objectives */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'6px 20px' }}>
          {mod.keyPoints.map((kp,i) => (
            <div key={i} style={{ display:'flex', alignItems:'flex-start', gap:8 }}>
              <div style={{ width:4, height:4, borderRadius:'50%', background:c, marginTop:8, flexShrink:0 }} />
              <span style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, color:'var(--t2)', lineHeight:1.55 }}>{kp}</span>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

// ── Module footer gate: acknowledgements + complete button ────────────────────
// Shown at the bottom of every module, after all content has been read.
// For modules with policyAck entries the checkboxes must ALL be ticked before
// the "Mark Complete" button becomes active — mimicking a T&C accept flow.
function ModuleFooterGate({ mod, isComplete, ackedPolicies, onAck, onComplete }) {
  const hasPolicies = mod.policyAck?.length > 0;
  const allAcked    = !hasPolicies || mod.policyAck.every(p => ackedPolicies?.includes(`${mod.id}-${p}`));
  const c           = mod.color;

  if (isComplete) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1, duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      style={{
        marginTop: 28,
        borderRadius: 16,
        overflow: 'hidden',
        border: `1px solid ${allAcked ? `rgba(${rgb(c)},.25)` : 'rgba(255,255,255,.08)'}`,
        background: allAcked ? `rgba(${rgb(c)},.04)` : 'var(--s2)',
        transition: 'border-color 0.3s, background 0.3s',
      }}
    >
      {/* Section label */}
      <div style={{
        padding: '12px 22px',
        borderBottom: '1px solid rgba(255,255,255,.05)',
        background: 'rgba(255,255,255,.02)',
        display: 'flex', alignItems: 'center', gap: 9,
      }}>
        <ClipboardList size={14} color="var(--t3)" />
        <span style={{
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', color: 'var(--t3)',
        }}>
          {hasPolicies ? 'ACKNOWLEDGEMENT & COMPLETION' : 'MODULE COMPLETION'}
        </span>
      </div>

      <div style={{ padding: '20px 22px' }}>
        {/* Policy checkboxes — only shown for modules that require them */}
        {hasPolicies && (
          <div style={{ marginBottom: 20 }}>
            <p style={{
              fontFamily: "'Plus Jakarta Sans', sans-serif",
              fontSize: 13.5, color: 'var(--t2)', lineHeight: 1.7, marginBottom: 14,
            }}>
              Before completing this module, please read and acknowledge the following
              {' '}<strong style={{ color: 'var(--t1)' }}>Security Impossible policies</strong>.
              You must check all boxes to proceed.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {mod.policyAck.map((pol) => {
                const key   = `${mod.id}-${pol}`;
                const ticked = ackedPolicies?.includes(key);
                return (
                  <label
                    key={pol}
                    style={{
                      display: 'flex', alignItems: 'flex-start', gap: 12,
                      padding: '13px 16px', borderRadius: 10, cursor: 'pointer',
                      background: ticked ? 'rgba(16,185,129,.07)' : 'rgba(255,255,255,.03)',
                      border: `1px solid ${ticked ? 'rgba(16,185,129,.25)' : 'rgba(255,255,255,.08)'}`,
                      transition: 'background 0.2s, border-color 0.2s',
                      userSelect: 'none',
                    }}
                  >
                    {/* Custom-styled checkbox area */}
                    <div style={{
                      width: 20, height: 20, borderRadius: 5, flexShrink: 0, marginTop: 1,
                      background: ticked ? '#10b981' : 'rgba(255,255,255,.06)',
                      border: `1.5px solid ${ticked ? '#10b981' : 'rgba(255,255,255,.15)'}`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      transition: 'all 0.18s',
                      position: 'relative',
                    }}>
                      <input
                        type="checkbox"
                        checked={!!ticked}
                        onChange={() => onAck(key)}
                        style={{
                          position: 'absolute', inset: 0, opacity: 0,
                          cursor: 'pointer', width: '100%', height: '100%', margin: 0,
                        }}
                      />
                      {ticked && (
                        <svg width="11" height="11" viewBox="0 0 11 11" fill="none">
                          <polyline points="1.5,5.5 4.5,8.5 9.5,2.5" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      )}
                    </div>

                    <div style={{ flex: 1 }}>
                      <div style={{
                        fontFamily: "'Plus Jakarta Sans', sans-serif",
                        fontSize: 13.5, fontWeight: 600,
                        color: ticked ? 'var(--t1)' : 'var(--t2)',
                        lineHeight: 1.4, marginBottom: 3,
                      }}>
                        I have read and understood the{' '}
                        <span style={{ color: ticked ? 'var(--green2)' : `rgb(${rgb(c)})` }}>{pol}</span>
                      </div>
                      <div style={{
                        fontFamily: "'Plus Jakarta Sans', sans-serif",
                        fontSize: 12, color: 'var(--t3)', lineHeight: 1.5,
                      }}>
                        I agree to comply with the obligations set out in this policy.
                      </div>
                    </div>

                    {ticked && (
                      <CheckCircle size={15} color="var(--green2)" style={{ flexShrink: 0, marginTop: 2 }} />
                    )}
                  </label>
                );
              })}
            </div>

            {/* Progress hint */}
            {!allAcked && (
              <p style={{
                marginTop: 10, fontFamily: "'IBM Plex Mono', monospace",
                fontSize: 11, color: 'var(--t4)', letterSpacing: '0.03em',
              }}>
                {mod.policyAck.filter(p => ackedPolicies?.includes(`${mod.id}-${p}`)).length}
                {' '}/ {mod.policyAck.length} acknowledged
              </p>
            )}
          </div>
        )}

        {/* Divider between acks and the complete button */}
        {hasPolicies && (
          <div style={{ height: 1, background: 'rgba(255,255,255,.05)', marginBottom: 18 }} />
        )}

        {/* Complete button row */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
          <div>
            <div style={{
              fontFamily: "'Plus Jakarta Sans', sans-serif",
              fontWeight: 700, fontSize: 14, color: 'var(--t1)', marginBottom: 3,
            }}>
              {allAcked
                ? `Mark Module ${mod.id} as Complete`
                : hasPolicies
                  ? 'Acknowledge all policies above to continue'
                  : `Mark Module ${mod.id} as Complete`}
            </div>
            <div style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 12.5, color: 'var(--t3)' }}>
              {allAcked
                ? 'Your progress will be saved and the next module will unlock.'
                : hasPolicies
                  ? 'All required checkboxes must be ticked before you can proceed.'
                  : 'Work through the content above, then mark complete to unlock the next module.'}
            </div>
          </div>

          <button
            disabled={!allAcked}
            onClick={allAcked ? onComplete : undefined}
            style={{
              flexShrink: 0, padding: '11px 24px', borderRadius: 10,
              fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 13.5, fontWeight: 700,
              cursor: allAcked ? 'pointer' : 'not-allowed',
              transition: 'all 0.2s',
              display: 'flex', alignItems: 'center', gap: 8,
              ...(allAcked ? {
                background: `linear-gradient(135deg, ${c}, rgba(${rgb(c)},.7))`,
                border: 'none', color: '#fff',
                boxShadow: `0 0 24px rgba(${rgb(c)},.3)`,
              } : {
                background: 'rgba(255,255,255,.04)',
                border: '1px solid rgba(255,255,255,.08)',
                color: 'var(--t4)',
              }),
            }}
          >
            {allAcked
              ? <><CheckCircle size={15} /> Mark Complete</>
              : '🔒 Complete Acknowledgements First'
            }
          </button>
        </div>
      </div>
    </motion.div>
  );
}

// ── Complete Banner ───────────────────────────────────────────────────────────
function CompleteBanner({ mod, hasNext, onNext }) {
  return (
    <motion.div
      initial={{ opacity:0, scale:.97 }} animate={{ opacity:1, scale:1 }}
      style={{
        padding:'22px 26px', borderRadius:14, marginBottom:22,
        background:'rgba(16,185,129,.07)', border:'1px solid rgba(16,185,129,.22)',
        display:'flex', alignItems:'center', justifyContent:'space-between', gap:16,
      }}
    >
      <div style={{ display:'flex', alignItems:'center', gap:14 }}>
        <span style={{ fontSize:28 }}>✅</span>
        <div>
          <div style={{ fontFamily:"'Fraunces',Georgia,serif", fontWeight:700, fontSize:16, color:'var(--green2)', marginBottom:3 }}>
            Module {mod.id} Complete
          </div>
          <div style={{ fontSize:13, color:'var(--t3)' }}>
            {hasNext ? 'Your progress is saved. Continue to the next module when ready.' : 'You have completed all 11 modules!'}
          </div>
        </div>
      </div>
      {hasNext && (
        <button onClick={onNext} style={{
          padding:'9px 20px', borderRadius:9, background:'rgba(16,185,129,.15)',
          border:'1px solid rgba(16,185,129,.3)', color:'var(--green2)',
          fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, fontWeight:700,
          cursor:'pointer', display:'flex', alignItems:'center', gap:7, flexShrink:0,
        }}>Next Module <ArrowRight size={14} /></button>
      )}
    </motion.div>
  );
}

// CompleteCTA replaced by ModuleFooterGate above

// ── All Complete ──────────────────────────────────────────────────────────────
function AllComplete({ onBack }) {
  return (
    <div style={{ maxWidth:680, margin:'0 auto', padding:'52px 28px', textAlign:'center' }}>
      <motion.div initial={{ opacity:0, scale:.95 }} animate={{ opacity:1, scale:1 }} transition={{ duration:0.5 }}
        style={{ background:'linear-gradient(140deg,rgba(16,185,129,.12),rgba(16,185,129,.04)), var(--s2)', border:'1px solid rgba(16,185,129,.22)', borderRadius:24, padding:'52px 44px' }}>
        <div style={{ fontSize:60, marginBottom:16 }}>🏆</div>
        <h1 style={{ fontFamily:"'Fraunces',Georgia,serif", fontWeight:700, fontSize:30, color:'var(--green2)', marginBottom:12, letterSpacing:'-0.02em' }}>
          Training Complete
        </h1>
        <p style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:15, color:'var(--t3)', lineHeight:1.75, maxWidth:460, margin:'0 auto 28px' }}>
          You have completed all 11 modules of the Security Impossible Security & Governance Onboarding Course v2. Your commitment to these obligations begins now and continues after your employment ends.
        </p>
        <div style={{ background:'rgba(0,0,0,.3)', border:'1px solid rgba(16,185,129,.15)', borderRadius:12, padding:'20px 24px', textAlign:'left', maxWidth:420, margin:'0 auto 24px', fontFamily:"'IBM Plex Mono',monospace", fontSize:11, lineHeight:2.2, color:'var(--t3)' }}>
          <div><span style={{color:'var(--t4)'}}>PROGRAM:</span> Security & Governance Onboarding v2</div>
          <div><span style={{color:'var(--t4)'}}>MODULES:</span> 11 / 11 Complete</div>
          <div><span style={{color:'var(--t4)'}}>DATE:</span> {new Date().toLocaleDateString('en-AU',{day:'numeric',month:'long',year:'numeric'})}</div>
          <div><span style={{color:'var(--t4)'}}>STATUS:</span> <span style={{color:'var(--green2)'}}>✓ COMMITTED</span></div>
        </div>
        <div style={{ padding:'12px 16px', background:'rgba(245,158,11,.07)', border:'1px solid rgba(245,158,11,.18)', borderRadius:9, fontSize:12.5, color:'var(--t2)', marginBottom:20 }}>
          <strong style={{color:'var(--amber2)'}}>Next step:</strong> Sign the Employee Confidentiality & IP Deed with your manager and return the signed acknowledgements for your employee file.
        </div>
        <button onClick={onBack} style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, color:'var(--t3)', background:'transparent', border:'1px solid var(--b2)', borderRadius:9, padding:'8px 18px', cursor:'pointer' }}>
          ← Review modules
        </button>
      </motion.div>
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentId, setCurrentId]     = useState(1);
  const [state, setState]             = useState(load);
  const [showAll, setShowAll]         = useState(false);

  useEffect(() => { save(state); }, [state]);

  const mod           = ALL_MODULES.find(m => m.id === currentId);
  const completedSet  = new Set(Object.keys(state.completed||{}).map(Number).filter(id => state.completed[id]));
  const allDone       = completedSet.size === ALL_MODULES.length;
  const isComplete    = completedSet.has(currentId);
  const modState      = state.modules?.[currentId] || {};
  const ackedPolicies = state.ackedPolicies || [];
  const progress      = Math.round((completedSet.size / ALL_MODULES.length) * 100);
  const nextMod       = ALL_MODULES.find(m => m.id === currentId + 1);
  const prevMod       = ALL_MODULES.find(m => m.id === currentId - 1);

  function setModState(key, val) {
    setState(s => ({ ...s, modules: { ...(s.modules||{}), [currentId]: { ...(s.modules?.[currentId]||{}), [key]: val } } }));
  }
  function completeModule(id) {
    setState(s => ({ ...s, completed: { ...(s.completed||{}), [id]: true } }));
  }
  function ackPolicy(key) {
    setState(s => {
      const cur = s.ackedPolicies || [];
      return { ...s, ackedPolicies: cur.includes(key) ? cur.filter(k=>k!==key) : [...cur, key] };
    });
  }
  function goTo(id) {
    setCurrentId(id);
    setShowAll(false);
    window.scrollTo({ top:0, behavior:'smooth' });
  }

  if (showAll) {
    return (
      <div style={{ minHeight:'100vh', background:'var(--bg)' }}>
        <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} progress={progress} />
        <AllComplete onBack={() => setShowAll(false)} />
      </div>
    );
  }

  return (
    <div style={{ minHeight:'100vh', background:'var(--bg)', fontFamily:"'Plus Jakarta Sans',sans-serif", overflowX:'hidden' }}>
      {/* BG grid */}
      <div style={{ position:'fixed',inset:0,pointerEvents:'none',zIndex:0, backgroundImage:'linear-gradient(rgba(20,35,70,0.05) 1px,transparent 1px),linear-gradient(90deg,rgba(20,35,70,0.05) 1px,transparent 1px)', backgroundSize:'56px 56px' }} />
      {/* Ambient color */}
      <div style={{ position:'fixed',top:'10%',right:'14%',width:360,height:360,borderRadius:'50%', background:`radial-gradient(circle,rgba(${rgb(mod?.color)},.06) 0%,transparent 70%)`, pointerEvents:'none',zIndex:0,transition:'background .6s' }} />

      <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} progress={progress} />
      <Sidebar open={sidebarOpen} currentModuleId={currentId} completedModules={[...completedSet]} onNavigate={goTo} />

      <motion.main
        animate={{ paddingLeft: sidebarOpen ? 280 : 0 }}
        transition={{ duration:0.3, ease:[0.16,1,0.3,1] }}
        style={{ paddingTop:58, minHeight:'100vh', position:'relative', zIndex:1 }}
      >
        {/* Tab strip */}
        <div style={{ position:'sticky',top:58,zIndex:100, background:'rgba(5,8,15,0.9)', backdropFilter:'blur(14px)', borderBottom:'1px solid rgba(255,255,255,0.05)', padding:'0 28px', display:'flex', alignItems:'center', gap:0, overflowX:'auto' }}>
          {ALL_MODULES.map((m) => {
            const done    = completedSet.has(m.id);
            const active  = m.id === currentId;
            const unlocked = m.id === 1 || done || completedSet.has(m.id - 1);
            return (
              <button key={m.id} onClick={() => unlocked && goTo(m.id)} style={{
                padding:'11px 3px 9px', marginRight:16, flexShrink:0,
                borderBottom:`2px solid ${active ? m.color : 'transparent'}`,
                background:'transparent', border:'none',
                borderBottom:`2px solid ${active ? m.color : 'transparent'}`,
                color: active ? 'var(--t1)' : done ? 'var(--t4)' : unlocked ? 'var(--t4)' : 'var(--b2)',
                fontFamily:"'IBM Plex Mono',monospace", fontSize:10.5, fontWeight:700,
                cursor: unlocked ? 'pointer' : 'not-allowed', transition:'all 0.15s',
                display:'flex', alignItems:'center', gap:4, paddingBottom:9, paddingTop:11,
              }}>
                {done ? <span style={{ color:'var(--green2)', fontSize:9 }}>✓</span> : null}
                {String(m.id).padStart(2,'0')}
              </button>
            );
          })}
          <div style={{ flex:1 }} />
          <span style={{ fontSize:10, color:'var(--t4)', fontFamily:"'IBM Plex Mono',monospace", flexShrink:0 }}>
            {completedSet.size}/{ALL_MODULES.length}
          </span>
        </div>

        <div style={{ maxWidth:860, margin:'0 auto', padding:'30px 26px 56px' }}>
          <AnimatePresence mode="wait">
            <motion.div key={currentId} initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:-10 }} transition={{ duration:0.3 }}>
              <ModuleHero mod={mod} isComplete={isComplete} />

              {isComplete && <CompleteBanner mod={mod} hasNext={!!nextMod} onNext={() => nextMod && goTo(nextMod.id)} />}

              <ModuleContent
                module={mod}
                scenarioDone={modState.scenarioDone || false}
                quizDone={modState.quizDone || false}
                onScenarioDone={() => setModState('scenarioDone', true)}
                onQuizDone={() => setModState('quizDone', true)}
              />

              {/* Acknowledgement gate + complete button — always at the bottom after content */}
              <ModuleFooterGate
                mod={mod}
                isComplete={isComplete}
                ackedPolicies={ackedPolicies}
                onAck={ackPolicy}
                onComplete={() => { completeModule(currentId); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              />

              {/* Bottom nav */}
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:28, paddingTop:20, borderTop:'1px solid var(--b1)' }}>
                <div>
                  {prevMod && <button onClick={() => goTo(prevMod.id)} style={{ display:'flex', alignItems:'center', gap:7, padding:'8px 16px', borderRadius:9, background:'rgba(255,255,255,.03)', border:'1px solid var(--b1)', color:'var(--t3)', fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:12.5, cursor:'pointer' }}>
                    <ArrowLeft size={13} /> Module {prevMod.id}
                  </button>}
                </div>
                <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:10, color:'var(--t4)' }}>{mod.id} / {ALL_MODULES.length}</span>
                <div>
                  {nextMod && isComplete && <button onClick={() => goTo(nextMod.id)} style={{ display:'flex', alignItems:'center', gap:7, padding:'8px 16px', borderRadius:9, background:`rgba(${rgb(nextMod.color)},.09)`, border:`1px solid rgba(${rgb(nextMod.color)},.2)`, color:nextMod.color, fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:12.5, fontWeight:600, cursor:'pointer' }}>
                    Module {nextMod.id} <ArrowRight size={13} />
                  </button>}
                  {allDone && !nextMod && !showAll && <button onClick={() => setShowAll(true)} style={{ display:'flex', alignItems:'center', gap:7, padding:'8px 16px', borderRadius:9, background:'rgba(16,185,129,.12)', border:'1px solid rgba(16,185,129,.25)', color:'var(--green2)', fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:12.5, fontWeight:700, cursor:'pointer' }}>
                    🏆 View Completion
                  </button>}
                </div>
              </div>

              {/* All done card */}
              {allDone && (
                <motion.div initial={{ opacity:0, y:16 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.4 }}
                  style={{ marginTop:28, padding:'22px 26px', borderRadius:14, background:'rgba(16,185,129,.07)', border:'1px solid rgba(16,185,129,.18)', display:'flex', alignItems:'center', justifyContent:'space-between', gap:16 }}>
                  <div>
                    <div style={{ fontFamily:"'Fraunces',Georgia,serif", fontWeight:700, fontSize:16, color:'var(--green2)', marginBottom:4 }}>🏆 All 11 Modules Complete</div>
                    <div style={{ fontSize:13, color:'var(--t3)' }}>Sign the Employee Confidentiality & IP Deed with your manager to finalise onboarding.</div>
                  </div>
                  <button onClick={() => setShowAll(true)} style={{ padding:'9px 18px', borderRadius:9, background:'rgba(16,185,129,.15)', border:'1px solid rgba(16,185,129,.3)', color:'var(--green2)', fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, fontWeight:700, cursor:'pointer', flexShrink:0 }}>
                    View Certificate →
                  </button>
                </motion.div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </motion.main>

      <ByteAssistant currentSection={`module-${currentId}`} />
    </div>
  );
}
