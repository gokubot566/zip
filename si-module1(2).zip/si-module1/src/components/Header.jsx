import { motion } from 'framer-motion';
import { Shield, Bell, ChevronRight, Menu, X, User } from 'lucide-react';

export default function Header({ sidebarOpen, setSidebarOpen, progress }) {
  return (
    <motion.header
      initial={{ y: -64, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 200, height: 58,
        background: 'rgba(5,8,15,0.9)',
        backdropFilter: 'blur(20px) saturate(180%)',
        borderBottom: '1px solid rgba(59,130,246,0.1)',
        display: 'flex', alignItems: 'center', padding: '0 18px', gap: 14,
      }}
    >
      {/* Toggle */}
      <button onClick={() => setSidebarOpen(!sidebarOpen)} style={{
        width: 34, height: 34, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)',
        color: 'var(--t3)', cursor: 'pointer', flexShrink: 0, transition: 'all 0.18s',
      }}
        onMouseEnter={e => { e.currentTarget.style.background='rgba(59,130,246,0.1)'; e.currentTarget.style.color='var(--blue2)'; }}
        onMouseLeave={e => { e.currentTarget.style.background='rgba(255,255,255,0.04)'; e.currentTarget.style.color='var(--t3)'; }}
      >
        {sidebarOpen ? <X size={15} /> : <Menu size={15} />}
      </button>

      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, flexShrink: 0 }}>
        <div style={{
          width: 30, height: 30, borderRadius: 7,
          background: 'linear-gradient(140deg, #1d4ed8 0%, #0ea5e9 100%)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 0 16px rgba(14,165,233,0.3)',
        }}><Shield size={15} color="#fff" /></div>
        <div>
          <div style={{ fontFamily: "'Fraunces', Georgia, serif", fontWeight: 700, fontSize: 13.5, color: 'var(--t1)', lineHeight: 1.1, letterSpacing: '-0.01em' }}>
            Security Impossible
          </div>
          <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8.5, color: 'var(--t4)', letterSpacing: '0.1em', marginTop: 1 }}>
            SECURITY & GOVERNANCE ONBOARDING
          </div>
        </div>
      </div>

      {/* Breadcrumb */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginLeft: 6 }}>
        <div style={{ width: 1, height: 18, background: 'rgba(255,255,255,0.07)' }} />
        <span style={{ fontSize: 11, color: 'var(--t4)', fontFamily: "'IBM Plex Mono', monospace" }}>Onboarding</span>
        <ChevronRight size={11} color="var(--t4)" />
        <span style={{ fontSize: 11, color: 'var(--blue2)', fontFamily: "'IBM Plex Mono', monospace", fontWeight: 600 }}>v2</span>
      </div>

      <div style={{ flex: 1 }} />

      {/* Progress */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8, padding: '5px 11px',
        background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)',
        borderRadius: 20,
      }}>
        <span style={{ fontSize: 10.5, color: 'var(--t3)', fontFamily: "'IBM Plex Mono', monospace" }}>Progress</span>
        <div style={{ width: 60, height: 3, background: 'rgba(255,255,255,0.07)', borderRadius: 2, overflow: 'hidden' }}>
          <motion.div
            initial={{ width: 0 }} animate={{ width: `${progress}%` }}
            transition={{ duration: 1.2, delay: 0.6, ease: [0.16,1,0.3,1] }}
            style={{ height: '100%', background: 'linear-gradient(90deg,#1d4ed8,#0ea5e9)', borderRadius: 2 }}
          />
        </div>
        <span style={{ fontSize: 10.5, fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700,
          color: progress === 100 ? 'var(--green2)' : 'var(--blue2)', minWidth: 26 }}>{progress}%</span>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
        <button style={{ width: 30, height: 30, borderRadius: 7, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)', color: 'var(--t4)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
          <Bell size={13} />
        </button>
        <div style={{ width: 30, height: 30, borderRadius: 7, background: 'linear-gradient(135deg,#1e3a5f,#1d4ed8)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
          <User size={13} color="#93c5fd" />
        </div>
      </div>
    </motion.header>
  );
}
