import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, FileText, BookOpen, MessageCircle, HelpCircle, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

function hexRgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return r ? `${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}` : '26,86,219';
}

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { delay, duration: 0.45, ease: [0.16, 1, 0.3, 1] },
});

// ── Reading sections ──────────────────────────────────────────────────────────
function ContentSection({ heading, body, index, color }) {
  const [open, setOpen] = useState(true);
  return (
    <motion.div {...fadeUp(index * 0.06)} style={{
      borderRadius: 12, marginBottom: 12, overflow: 'hidden',
      background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.06)',
    }}>
      <button onClick={() => setOpen(!open)} style={{
        width: '100%', textAlign: 'left', padding: '14px 18px', border: 'none',
        cursor: 'pointer', background: 'transparent',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <div style={{
          width: 26, height: 26, borderRadius: 6, flexShrink: 0,
          background: `rgba(${hexRgb(color)},0.12)`, border: `1px solid rgba(${hexRgb(color)},0.2)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, fontWeight: 700, color,
        }}>{String(index + 1).padStart(2,'0')}</div>
        <span style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, fontSize: 14.5, color: '#e2e8f0', flex: 1 }}>{heading}</span>
        <motion.span animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}><ChevronDown size={14} color="#334155" /></motion.span>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }} style={{ overflow: 'hidden' }}>
            <div style={{ height: 1, background: 'rgba(255,255,255,0.05)', margin: '0 18px' }} />
            <div style={{ padding: '14px 18px 18px' }}>
              {body.split('\n\n').map((para, i) => (
                <p key={i} style={{ color: '#64748b', fontSize: 13.5, lineHeight: 1.85, marginBottom: i < body.split('\n\n').length - 1 ? 12 : 0, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{para}</p>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ── Scenario card ─────────────────────────────────────────────────────────────
function ScenarioCard({ scenario, onDone, done }) {
  const [selected, setSelected] = useState(null);
  const [revealed, setRevealed] = useState(false);

  function pick(opt) {
    setSelected(opt); setRevealed(true);
    if (opt.correct && !done) onDone();
  }

  return (
    <motion.div {...fadeUp(0)} style={{ borderRadius: 16, overflow: 'hidden', border: '1px solid rgba(255,255,255,0.07)', marginBottom: 16 }}>
      {/* Header */}
      <div style={{ padding: '16px 22px', background: 'linear-gradient(90deg,rgba(26,86,219,0.14),rgba(14,165,233,0.07))', borderBottom: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 34, height: 34, borderRadius: 9, background: 'rgba(14,165,233,0.14)', border: '1px solid rgba(14,165,233,0.24)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <MessageCircle size={16} color="#0ea5e9" />
        </div>
        <div>
          <div style={{ fontSize: 9, color: '#334155', fontFamily: "'IBM Plex Mono', monospace", letterSpacing: '0.08em', marginBottom: 1 }}>WORKPLACE SCENARIO</div>
          <div style={{ fontFamily: "'Fraunces', Georgia, serif", fontWeight: 800, fontSize: 15, color: '#e2e8f0' }}>{scenario.title}</div>
        </div>
      </div>

      <div style={{ padding: '20px 22px', background: 'rgba(255,255,255,0.015)' }}>
        {/* Setup */}
        <div style={{ padding: '12px 16px', borderRadius: 9, marginBottom: 16, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.05)' }}>
          <div style={{ fontSize: 9, color: '#334155', fontFamily: "'IBM Plex Mono', monospace", marginBottom: 5, letterSpacing: '0.06em' }}>SETTING</div>
          <p style={{ fontSize: 13, color: '#64748b', fontFamily: "'Plus Jakarta Sans', sans-serif", lineHeight: 1.7, margin: 0 }}>{scenario.setup}</p>
        </div>
        {/* Message bubble */}
        <div style={{ padding: '12px 16px', borderRadius: '6px 12px 12px 12px', marginBottom: 14, background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)', fontSize: 13.5, color: '#94a3b8', fontFamily: "'Plus Jakarta Sans', sans-serif", lineHeight: 1.65 }}>
          {scenario.message}
        </div>
        {/* Options */}
        <div style={{ fontSize: 10, color: '#334155', fontFamily: "'IBM Plex Mono', monospace", marginBottom: 8, letterSpacing: '0.06em' }}>HOW DO YOU RESPOND?</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
          {scenario.options.map((opt, i) => {
            const isSel = selected?.id === opt.id;
            return (
              <motion.button
                key={opt.id}
                whileHover={!revealed ? { x: 4 } : {}}
                onClick={() => !revealed && pick(opt)}
                style={{
                  textAlign: 'left', padding: '11px 14px', borderRadius: 9,
                  background: isSel ? (opt.correct ? 'rgba(16,185,129,0.08)' : 'rgba(239,68,68,0.06)') : 'rgba(255,255,255,0.025)',
                  border: isSel ? `1px solid ${opt.correct ? 'rgba(16,185,129,0.25)' : 'rgba(239,68,68,0.2)'}` : '1px solid rgba(255,255,255,0.06)',
                  cursor: revealed ? 'default' : 'pointer', display: 'flex', alignItems: 'flex-start', gap: 9,
                  opacity: revealed && !isSel ? 0.3 : 1, transition: 'all 0.2s',
                }}
              >
                <div style={{ width: 20, height: 20, borderRadius: 5, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: isSel ? (opt.correct ? 'rgba(16,185,129,0.2)' : 'rgba(239,68,68,0.15)') : 'rgba(255,255,255,0.05)', border: `1px solid ${isSel ? (opt.correct ? 'rgba(16,185,129,0.3)' : 'rgba(239,68,68,0.25)') : 'rgba(255,255,255,0.08)'}`, fontSize: 10, color: isSel ? (opt.correct ? '#10b981' : '#f87171') : '#475569', fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700 }}>
                  {isSel ? (opt.correct ? '✓' : '✗') : String.fromCharCode(65 + i)}
                </div>
                <span style={{ fontSize: 13, color: isSel ? (opt.correct ? '#86efac' : '#fca5a5') : '#64748b', fontFamily: "'Plus Jakarta Sans', sans-serif", lineHeight: 1.5 }}>"{opt.text}"</span>
              </motion.button>
            );
          })}
        </div>
        <AnimatePresence>
          {revealed && selected && (
            <motion.div initial={{ opacity: 0, y: 8, height: 0 }} animate={{ opacity: 1, y: 0, height: 'auto' }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}
              style={{ marginTop: 12, padding: '13px 16px', borderRadius: 9, background: selected.correct ? 'rgba(16,185,129,0.07)' : 'rgba(239,68,68,0.06)', border: `1px solid ${selected.correct ? 'rgba(16,185,129,0.2)' : 'rgba(239,68,68,0.15)'}` }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                {selected.correct ? <CheckCircle size={14} color="#10b981" style={{ marginTop: 2, flexShrink: 0 }} /> : <AlertCircle size={14} color="#f87171" style={{ marginTop: 2, flexShrink: 0 }} />}
                <div style={{ fontSize: 13, color: selected.correct ? '#6ee7b7' : '#fca5a5', fontFamily: "'Plus Jakarta Sans', sans-serif", lineHeight: 1.65 }}>{selected.feedback}</div>
              </div>
              {!selected.correct && (
                <button onClick={() => { setSelected(null); setRevealed(false); }} style={{ marginTop: 8, padding: '5px 12px', borderRadius: 6, background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)', color: '#94a3b8', fontSize: 11, fontFamily: "'Plus Jakarta Sans', sans-serif", cursor: 'pointer', fontWeight: 600 }}>Try again</button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

// ── Policy references ─────────────────────────────────────────────────────────
function PolicyRefs({ policies }) {
  const [expanded, setExpanded] = useState(null);
  return (
    <motion.div {...fadeUp(0)} style={{ borderRadius: 14, overflow: 'hidden', border: '1px solid rgba(255,255,255,0.07)', marginBottom: 16 }}>
      <div style={{ padding: '16px 22px', background: 'linear-gradient(90deg,rgba(16,185,129,0.1),rgba(5,150,105,0.05))', borderBottom: '1px solid rgba(255,255,255,0.05)', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 34, height: 34, borderRadius: 9, background: 'rgba(16,185,129,0.14)', border: '1px solid rgba(16,185,129,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <BookOpen size={16} color="#10b981" />
        </div>
        <div>
          <div style={{ fontSize: 9, color: '#334155', fontFamily: "'IBM Plex Mono', monospace", letterSpacing: '0.08em', marginBottom: 1 }}>POLICY REFERENCES</div>
          <div style={{ fontFamily: "'Fraunces', Georgia, serif", fontWeight: 800, fontSize: 15, color: '#e2e8f0' }}>Referenced Policies</div>
        </div>
        <div style={{ marginLeft: 'auto', padding: '3px 10px', borderRadius: 12, background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)', fontSize: 10, color: '#10b981', fontFamily: "'IBM Plex Mono', monospace" }}>{policies.length} POLICIES</div>
      </div>
      <div style={{ background: 'rgba(255,255,255,0.015)', padding: '14px 18px' }}>
        {policies.map((pol, i) => (
          <div key={pol.ref} style={{ marginBottom: i < policies.length - 1 ? 7 : 0 }}>
            <button onClick={() => setExpanded(expanded === pol.ref ? null : pol.ref)}
              style={{ width: '100%', textAlign: 'left', padding: '12px 14px', borderRadius: 9, background: expanded === pol.ref ? 'rgba(16,185,129,0.07)' : 'rgba(255,255,255,0.025)', border: `1px solid ${expanded === pol.ref ? 'rgba(16,185,129,0.2)' : 'rgba(255,255,255,0.06)'}`, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 10, transition: 'all 0.18s' }}>
              <div style={{ width: 32, height: 32, borderRadius: 7, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <FileText size={14} color="#64748b" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: '#10b981', fontWeight: 700, marginBottom: 2 }}>{pol.ref}</div>
                <div style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 13, fontWeight: 600, color: '#94a3b8', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{pol.title}</div>
              </div>
              <motion.div animate={{ rotate: expanded === pol.ref ? 180 : 0 }} transition={{ duration: 0.2 }}><ChevronDown size={13} color="#334155" /></motion.div>
            </button>
            <AnimatePresence>
              {expanded === pol.ref && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }} style={{ overflow: 'hidden' }}>
                  <div style={{ padding: '12px 14px', background: 'rgba(16,185,129,0.04)', border: '1px solid rgba(16,185,129,0.12)', borderTop: 'none', borderRadius: '0 0 9px 9px', marginTop: 3 }}>
                    <p style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 12.5, color: '#64748b', lineHeight: 1.7, marginBottom: 10 }}>{pol.summary}</p>
                    <div style={{ fontSize: 9.5, color: '#10b981', fontFamily: "'IBM Plex Mono', monospace", marginBottom: 6, letterSpacing: '0.06em' }}>YOUR OBLIGATIONS</div>
                    {pol.obligations.map((ob, j) => (
                      <div key={j} style={{ display: 'flex', gap: 7, marginBottom: 5 }}>
                        <div style={{ width: 4, height: 4, borderRadius: '50%', background: '#10b981', marginTop: 7, flexShrink: 0 }} />
                        <span style={{ fontSize: 12.5, color: '#64748b', fontFamily: "'Plus Jakarta Sans', sans-serif", lineHeight: 1.5 }}>{ob}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

// ── Quiz ──────────────────────────────────────────────────────────────────────
function Quiz({ questions, onDone, done }) {
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [current, setCurrent] = useState(0);
  const q = questions[current];
  const allAnswered = questions.every((_, i) => answers[i] !== undefined);
  const score = submitted ? questions.filter((q2, i) => answers[i] === q2.correct).length : 0;

  function submit() {
    setSubmitted(true);
    if (!done) onDone();
  }

  function reset() {
    setAnswers({}); setSubmitted(false); setCurrent(0);
  }

  return (
    <motion.div {...fadeUp(0)} style={{ borderRadius: 14, overflow: 'hidden', border: '1px solid rgba(255,255,255,0.07)' }}>
      <div style={{ padding: '16px 22px', background: 'linear-gradient(90deg,rgba(139,92,246,0.12),rgba(109,40,217,0.06))', borderBottom: '1px solid rgba(255,255,255,0.05)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: 'rgba(139,92,246,0.14)', border: '1px solid rgba(139,92,246,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <HelpCircle size={16} color="#a78bfa" />
          </div>
          <div>
            <div style={{ fontSize: 9, color: '#334155', fontFamily: "'IBM Plex Mono', monospace", letterSpacing: '0.08em', marginBottom: 1 }}>KNOWLEDGE CHECK</div>
            <div style={{ fontFamily: "'Fraunces', Georgia, serif", fontWeight: 800, fontSize: 15, color: '#e2e8f0' }}>{questions.length} Questions</div>
          </div>
        </div>
        {!submitted && (
          <div style={{ display: 'flex', gap: 5 }}>
            {questions.map((_, i) => (
              <button key={i} onClick={() => setCurrent(i)} style={{ width: 26, height: 26, borderRadius: 5, background: current === i ? 'rgba(139,92,246,0.2)' : answers[i] !== undefined ? 'rgba(16,185,129,0.1)' : 'rgba(255,255,255,0.04)', border: current === i ? '1px solid rgba(139,92,246,0.4)' : answers[i] !== undefined ? '1px solid rgba(16,185,129,0.25)' : '1px solid rgba(255,255,255,0.06)', color: current === i ? '#a78bfa' : answers[i] !== undefined ? '#10b981' : '#475569', fontSize: 10, fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, cursor: 'pointer' }}>{i + 1}</button>
            ))}
          </div>
        )}
      </div>

      <div style={{ padding: '22px', background: 'rgba(255,255,255,0.015)' }}>
        {!submitted ? (
          <>
            <AnimatePresence mode="wait">
              <motion.div key={current} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.2 }}>
                <div style={{ padding: '14px 18px', borderRadius: 10, marginBottom: 14, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                  <div style={{ display: 'flex', gap: 9, alignItems: 'flex-start' }}>
                    <div style={{ width: 22, height: 22, borderRadius: 5, flexShrink: 0, background: 'rgba(139,92,246,0.15)', border: '1px solid rgba(139,92,246,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, color: '#a78bfa', fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700 }}>{current + 1}</div>
                    <p style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 14, fontWeight: 600, color: '#e2e8f0', lineHeight: 1.5, margin: 0 }}>{q.q}</p>
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 7, marginBottom: 18 }}>
                  {q.opts.map((opt, i) => {
                    const isSel = answers[current] === i;
                    return (
                      <motion.button key={i} whileHover={{ x: 3 }} onClick={() => setAnswers(a => ({ ...a, [current]: i }))}
                        style={{ textAlign: 'left', padding: '11px 14px', borderRadius: 9, background: isSel ? 'rgba(139,92,246,0.1)' : 'rgba(255,255,255,0.025)', border: isSel ? '1px solid rgba(139,92,246,0.35)' : '1px solid rgba(255,255,255,0.06)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 9, transition: 'all 0.15s' }}>
                        <div style={{ width: 20, height: 20, borderRadius: 5, flexShrink: 0, background: isSel ? 'rgba(139,92,246,0.25)' : 'rgba(255,255,255,0.05)', border: isSel ? '1px solid rgba(139,92,246,0.4)' : '1px solid rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9.5, color: isSel ? '#a78bfa' : '#475569', fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700 }}>{String.fromCharCode(65 + i)}</div>
                        <span style={{ fontSize: 13, fontFamily: "'Plus Jakarta Sans', sans-serif", color: isSel ? '#c4b5fd' : '#64748b', lineHeight: 1.4 }}>{opt}</span>
                      </motion.button>
                    );
                  })}
                </div>
              </motion.div>
            </AnimatePresence>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <button onClick={() => setCurrent(c => Math.max(0, c - 1))} disabled={current === 0} style={{ padding: '8px 16px', borderRadius: 7, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', color: current === 0 ? '#1e293b' : '#64748b', fontSize: 12, fontFamily: "'Plus Jakarta Sans', sans-serif", cursor: current === 0 ? 'default' : 'pointer' }}>← Prev</button>
              {current < questions.length - 1 ? (
                <button onClick={() => setCurrent(c => c + 1)} style={{ padding: '8px 16px', borderRadius: 7, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', color: '#64748b', fontSize: 12, fontFamily: "'Plus Jakarta Sans', sans-serif", cursor: 'pointer' }}>Next →</button>
              ) : (
                <button onClick={submit} disabled={!allAnswered} style={{ padding: '8px 20px', borderRadius: 7, background: allAnswered ? 'linear-gradient(135deg,#7c3aed,#5b21b6)' : 'rgba(255,255,255,0.04)', border: 'none', color: allAnswered ? '#fff' : '#334155', fontSize: 12, fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, cursor: allAnswered ? 'pointer' : 'not-allowed' }}>Submit Answers</button>
              )}
            </div>
          </>
        ) : (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.35 }}>
            <div style={{ textAlign: 'center', padding: '20px', marginBottom: 20, borderRadius: 12, background: score === questions.length ? 'rgba(16,185,129,0.07)' : 'rgba(139,92,246,0.07)', border: `1px solid ${score === questions.length ? 'rgba(16,185,129,0.2)' : 'rgba(139,92,246,0.2)'}` }}>
              <div style={{ fontSize: 40, marginBottom: 6 }}>{score === questions.length ? '🏆' : score >= questions.length * 0.75 ? '✅' : '📚'}</div>
              <div style={{ fontFamily: "'Fraunces', Georgia, serif", fontSize: 24, fontWeight: 800, color: score === questions.length ? '#10b981' : '#a78bfa', marginBottom: 3 }}>{score} / {questions.length}</div>
              <div style={{ fontSize: 13, color: '#64748b', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{score === questions.length ? 'Perfect! Excellent understanding.' : score >= Math.ceil(questions.length * 0.75) ? 'Great work — review the explanations below.' : 'Good effort — review explanations and try again.'}</div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 18 }}>
              {questions.map((q2, i) => {
                const correct = answers[i] === q2.correct;
                return (
                  <div key={i} style={{ padding: '13px 15px', borderRadius: 10, background: correct ? 'rgba(16,185,129,0.05)' : 'rgba(239,68,68,0.05)', border: `1px solid ${correct ? 'rgba(16,185,129,0.18)' : 'rgba(239,68,68,0.15)'}` }}>
                    <div style={{ display: 'flex', gap: 7, marginBottom: 6 }}>
                      {correct ? <CheckCircle size={13} color="#10b981" style={{ flexShrink: 0, marginTop: 2 }} /> : <XCircle size={13} color="#f87171" style={{ flexShrink: 0, marginTop: 2 }} />}
                      <div style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 12.5, color: '#94a3b8', fontWeight: 600, lineHeight: 1.4 }}>{q2.q}</div>
                    </div>
                    {!correct && (
                      <div style={{ marginLeft: 20, marginBottom: 5 }}>
                        <div style={{ fontSize: 10, color: '#f87171', fontFamily: "'IBM Plex Mono', monospace", marginBottom: 1 }}>Your answer: "{q2.opts[answers[i]]}"</div>
                        <div style={{ fontSize: 10, color: '#10b981', fontFamily: "'IBM Plex Mono', monospace" }}>Correct: "{q2.opts[q2.correct]}"</div>
                      </div>
                    )}
                    <div style={{ marginLeft: 20, fontSize: 12, color: '#475569', fontFamily: "'Plus Jakarta Sans', sans-serif", lineHeight: 1.6, padding: '7px 9px', background: 'rgba(255,255,255,0.025)', borderRadius: 5, marginTop: 4 }}>💡 {q2.exp}</div>
                  </div>
                );
              })}
            </div>
            <button onClick={reset} style={{ padding: '8px 16px', borderRadius: 7, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', color: '#64748b', fontSize: 12, fontFamily: "'Plus Jakarta Sans', sans-serif", cursor: 'pointer' }}>Retake Quiz</button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}

// ── Exported module content ───────────────────────────────────────────────────
export default function ModuleContent({ module, scenarioDone, quizDone, onScenarioDone, onQuizDone }) {
  return (
    <div>
      {/* Reading content */}
      {module.content && module.content.length > 0 && (
        <div style={{ marginBottom: 8 }}>
          {module.content.map((sec, i) => (
            <ContentSection key={i} heading={sec.heading} body={sec.body} index={i} color={module.color} />
          ))}
        </div>
      )}

      {/* Scenario */}
      {module.scenario && (
        <>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12, marginTop: 8 }}>
            <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.04)' }} />
            <span style={{ fontSize: 10, color: '#1e293b', fontFamily: "'IBM Plex Mono', monospace", letterSpacing: '0.08em' }}>PRACTICAL APPLICATION</span>
            <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.04)' }} />
          </div>
          <ScenarioCard scenario={module.scenario} onDone={onScenarioDone} done={scenarioDone} />
        </>
      )}

      {/* Policies */}
      {module.policies && module.policies.length > 0 && (
        <>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12, marginTop: 8 }}>
            <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.04)' }} />
            <span style={{ fontSize: 10, color: '#1e293b', fontFamily: "'IBM Plex Mono', monospace", letterSpacing: '0.08em' }}>POLICY FRAMEWORK</span>
            <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.04)' }} />
          </div>
          <PolicyRefs policies={module.policies} />
        </>
      )}

      {/* Quiz */}
      {module.quiz && module.quiz.length > 0 && (
        <>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12, marginTop: 8 }}>
            <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.04)' }} />
            <span style={{ fontSize: 10, color: '#1e293b', fontFamily: "'IBM Plex Mono', monospace", letterSpacing: '0.08em' }}>KNOWLEDGE CHECK</span>
            <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.04)' }} />
          </div>
          <Quiz questions={module.quiz} onDone={onQuizDone} done={quizDone} />
        </>
      )}
    </div>
  );
}
