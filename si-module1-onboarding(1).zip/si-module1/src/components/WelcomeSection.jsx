import { motion } from 'framer-motion';
import { useState } from 'react';
import {
  Shield, AlertTriangle, Users, TrendingUp, Eye, Lock,
  ChevronDown, ChevronUp, ExternalLink, Star, Zap, Target
} from 'lucide-react';

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, delay, ease: [0.16, 1, 0.3, 1] }
});

const STATS = [
  { value: '94%', label: 'of breaches involve human error', icon: AlertTriangle, color: 'var(--red)' },
  { value: '287', label: 'days avg to detect a breach', icon: Eye, color: 'var(--amber)' },
  { value: '$4.9M', label: 'avg cost of a data breach (2024)', icon: TrendingUp, color: 'var(--purple)' },
  { value: '100%', label: 'client trust starts with you', icon: Star, color: 'var(--cyan)' },
];

const POLICY_REFS = [
  { id: 'SI-POL-001', title: 'Information Security Policy', desc: 'Core framework for all security obligations' },
  { id: 'SI-POL-002', title: 'Employee Code of Conduct', desc: 'Behavioural and professional standards' },
  { id: 'SI-POL-003', title: 'Acceptable Use Policy', desc: 'Rules for using firm technology and systems' },
  { id: 'SI-CONF-001', title: 'Confidentiality Agreement', desc: 'Your binding confidentiality obligations' },
];

const KEY_PRINCIPLES = [
  {
    icon: Shield,
    title: 'You Are the First Line of Defence',
    color: 'var(--cyan)',
    content: `Security Impossible is a cybersecurity firm. Our clients pay us precisely because they cannot afford security failures. If we cannot demonstrate that we protect our own information, our professional credibility is destroyed.

    Every person who joins — full-time, contractor, or intern — becomes a custodian of client trust. This is not figurative language. You will genuinely be responsible for information that, if mishandled, could harm our clients' reputations, expose individuals to harm, or result in financial loss.`
  },
  {
    icon: AlertTriangle,
    title: 'Security Failures Look Ordinary',
    color: 'var(--amber)',
    content: `Most security incidents are not dramatic cyberattacks. They look like forwarding a client report to a personal email "just to work on it at home." They look like discussing a sensitive engagement in a coffee shop. They look like leaving a laptop unlocked on a desk.

    None of these acts are malicious. Most result from convenience or the belief that "it won't matter just this once." But every one represents a failure of the standard we hold ourselves to.`
  },
  {
    icon: Target,
    title: 'We Are a High-Value Target',
    color: 'var(--red)',
    content: `Threat actors do not target organisations at random. Security Impossible is an unusually attractive target because we hold detailed knowledge of our clients' security postures — including their vulnerabilities.

    An attacker who gains access to our systems could obtain a roadmap for attacking multiple high-value client organisations simultaneously. This makes a successful attack on us potentially worth far more than an attack on a single client. Your vigilance is operationally critical.`
  },
  {
    icon: Users,
    title: 'Culture Is Built by Daily Decisions',
    color: 'var(--green)',
    content: `Security culture is not created by policy documents. It is created by the daily decisions of every person. When you lock your screen before stepping away, ask a visitor to sign in, or pause before clicking a suspicious link — you are the security culture.

    We expect you to exercise professional judgement. Policies and guidelines matter, but the goal is for you to internalise the principles so you make the right decision even in situations policies don't explicitly cover.`
  },
];

function StatCard({ stat, index }) {
  const Icon = stat.icon;
  return (
    <motion.div
      {...fadeUp(0.1 + index * 0.08)}
      whileHover={{ y: -4, scale: 1.02 }}
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border)',
        borderRadius: 14,
        padding: '20px 18px',
        display: 'flex', flexDirection: 'column', gap: 8,
        cursor: 'default',
        transition: 'border-color 0.2s',
        position: 'relative', overflow: 'hidden',
      }}
      onHoverStart={e => e.target.style && (e.target.style.borderColor = stat.color + '55')}
    >
      <div style={{
        position: 'absolute', top: -20, right: -20,
        width: 80, height: 80, borderRadius: '50%',
        background: stat.color,
        opacity: 0.04, filter: 'blur(20px)',
      }} />
      <Icon size={20} color={stat.color} />
      <div style={{ fontFamily: 'var(--display)', fontWeight: 800, fontSize: 26, color: stat.color, lineHeight: 1 }}>
        {stat.value}
      </div>
      <div style={{ fontSize: 12, color: 'var(--t3)', lineHeight: 1.4 }}>{stat.label}</div>
    </motion.div>
  );
}

function PrincipleCard({ principle, index }) {
  const [expanded, setExpanded] = useState(index === 0);
  const Icon = principle.icon;

  return (
    <motion.div
      {...fadeUp(0.2 + index * 0.06)}
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border)',
        borderRadius: 14, overflow: 'hidden',
        marginBottom: 10,
      }}
    >
      <button
        onClick={() => setExpanded(!expanded)}
        style={{
          width: '100%', background: 'none', border: 'none', cursor: 'pointer',
          padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 14,
          textAlign: 'left',
        }}
      >
        <div style={{
          width: 38, height: 38, borderRadius: 10, flexShrink: 0,
          background: `rgba(${colorToRgb(principle.color)}, 0.12)`,
          border: `1px solid rgba(${colorToRgb(principle.color)}, 0.2)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon size={18} color={principle.color} />
        </div>
        <span style={{ flex: 1, fontSize: 15, fontWeight: 600, color: 'var(--t1)', textAlign: 'left' }}>
          {principle.title}
        </span>
        <motion.div animate={{ rotate: expanded ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown size={16} color="var(--t3)" />
        </motion.div>
      </button>

      <motion.div
        initial={false}
        animate={{ height: expanded ? 'auto' : 0, opacity: expanded ? 1 : 0 }}
        transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
        style={{ overflow: 'hidden' }}
      >
        <div style={{
          padding: '0 20px 18px',
          borderTop: '1px solid var(--border)',
          paddingTop: 14,
        }}>
          {principle.content.trim().split('\n\n').map((para, i) => (
            <p key={i} style={{ fontSize: 13.5, color: 'var(--t2)', lineHeight: 1.8, marginBottom: i < 1 ? 10 : 0 }}>
              {para.trim()}
            </p>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
}

function PolicyRef({ policyRef: pref, index }) {
  const [open, setOpen] = useState(false);
  return (
    <motion.div
      {...fadeUp(0.1 + index * 0.04)}
      style={{
        display: 'flex', alignItems: 'center', gap: 12,
        padding: '10px 14px', borderRadius: 9,
        background: open ? 'var(--bg-hover)' : 'var(--bg-card)',
        border: '1px solid var(--border)',
        cursor: 'pointer', transition: 'all 0.18s',
      }}
      onClick={() => setOpen(!open)}
    >
      <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--cyan)', minWidth: 90, flexShrink: 0 }}>
        {pref.id}
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--t1)', marginBottom: 2 }}>{pref.title}</div>
        {open && <div style={{ fontSize: 12, color: 'var(--t3)' }}>{pref.desc}</div>}
      </div>
      <ExternalLink size={12} color="var(--t3)" />
    </motion.div>
  );
}

export default function WelcomeSection({ onProgress }) {
  const [readSections, setReadSections] = useState(new Set());

  function markRead(id) {
    setReadSections(prev => {
      const next = new Set([...prev, id]);
      if (onProgress) onProgress(Math.round((next.size / KEY_PRINCIPLES.length) * 40));
      return next;
    });
  }

  return (
    <div style={{ maxWidth: 900, margin: '0 auto' }}>
      {/* Hero */}
      <motion.div
        {...fadeUp(0)}
        style={{
          background: 'linear-gradient(135deg, rgba(56,189,248,.05) 0%, rgba(10,18,37,0) 50%), var(--bg-card)',
          border: '1px solid var(--border-bright)',
          borderRadius: 18, padding: '36px 40px',
          marginBottom: 28, position: 'relative', overflow: 'hidden',
        }}
      >
        {/* Animated corner accent */}
        <div style={{
          position: 'absolute', top: 0, right: 0,
          width: 200, height: 200,
          background: 'radial-gradient(circle at 100% 0%, rgba(56,189,248,.07) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />

        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
          <span className="tag tag-cyan">MODULE 01</span>
          <span className="tag tag-gray">Foundation Track</span>
          <span className="tag tag-green">⏱ 15 min</span>
        </div>

        <h1 style={{
          fontFamily: 'var(--display)', fontWeight: 800,
          fontSize: 34, lineHeight: 1.15, marginBottom: 14,
          background: 'linear-gradient(135deg, #e8f4ff 30%, #38bdf8 100%)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
        }}>
          Welcome & Why Security<br />Matters Here
        </h1>

        <p style={{ fontSize: 15, color: 'var(--t2)', lineHeight: 1.8, maxWidth: 640, marginBottom: 20 }}>
          Before you open a single policy document or pick up a laptop, you need to understand
          something fundamental: security at Security Impossible is not a department, a checklist,
          or a compliance exercise. It is the foundation of every promise we make to our clients.
        </p>

        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{
            padding: '8px 16px', borderRadius: 8,
            background: 'rgba(56,189,248,.08)',
            border: '1px solid rgba(56,189,248,.2)',
            fontSize: 13, color: 'var(--cyan)',
          }}>
            <span style={{ fontFamily: 'var(--mono)' }}>WHO: </span>
            All staff, contractors & interns
          </div>
          <div style={{
            padding: '8px 16px', borderRadius: 8,
            background: 'rgba(34,211,165,.08)',
            border: '1px solid rgba(34,211,165,.2)',
            fontSize: 13, color: 'var(--green)',
          }}>
            <span style={{ fontFamily: 'var(--mono)' }}>MANDATORY: </span>
            Day One Completion
          </div>
        </div>
      </motion.div>

      {/* Stats grid */}
      <motion.div {...fadeUp(0.1)} style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--t3)', letterSpacing: '0.1em', marginBottom: 12 }}>
          THE REALITY CHECK
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          {STATS.map((s, i) => <StatCard key={i} stat={s} index={i} />)}
        </div>
      </motion.div>

      {/* Key Principles */}
      <motion.div {...fadeUp(0.15)} style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
          <Zap size={16} color="var(--cyan)" />
          <span style={{ fontSize: 17, fontWeight: 700, color: 'var(--t1)', fontFamily: 'var(--display)' }}>
            Four Principles You Must Understand
          </span>
        </div>
        {KEY_PRINCIPLES.map((p, i) => (
          <div key={i} onClick={() => markRead(i)}>
            <PrincipleCard principle={p} index={i} />
          </div>
        ))}
        {readSections.size > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            style={{ fontSize: 12, color: 'var(--green)', fontFamily: 'var(--mono)', marginTop: 6 }}
          >
            ✓ {readSections.size}/{KEY_PRINCIPLES.length} sections read
          </motion.div>
        )}
      </motion.div>

      {/* Policy References */}
      <motion.div {...fadeUp(0.2)} style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
          <Lock size={16} color="var(--purple)" />
          <span style={{ fontSize: 17, fontWeight: 700, color: 'var(--t1)', fontFamily: 'var(--display)' }}>
            Policy References
          </span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {POLICY_REFS.map((p, i) => <PolicyRef key={i} policyRef={p} index={i} />)}
        </div>
      </motion.div>
    </div>
  );
}

function colorToRgb(color) {
  const m = {
    'var(--cyan)': '56,189,248',
    'var(--amber)': '251,191,36',
    'var(--red)': '248,113,113',
    'var(--green)': '34,211,165',
    'var(--purple)': '167,139,250',
  };
  return m[color] || '56,189,248';
}
