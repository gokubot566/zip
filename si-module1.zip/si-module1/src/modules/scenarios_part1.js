// ── Character-based scenario registry ─────────────────────────────────────────
//
// One cast-driven branching scenario per module, keyed by module id. Each entry
// has { meta, scenes, debrief } in the exact shape the original Module 1 used.
//
//   meta:    { module, kicker, title, player, summary, cast }
//   scenes:  [{ id, act, title, setting, dialogue:[{s,t}], prompt,
//               options:[{ id, text, score, reaction:{s,t}, feedback }] }]
//   debrief: { title, lines:[{s,t}], takeaways:[] }
//
// score is 'best' | 'ok' | 'poor'. Only the 'best' option advances the story.
// Speaker ids MUST be valid cast ids: elena | marcus | priya | david | auditor.
//
// Content is written to be technically accurate to each module's policies and
// learning objectives — see src/modules/moduleData.js for the source material.

/* ════════════════════════════════════════════════════════════════════════════
 * MODULE 1 — Welcome & Why Security Matters Here
 * ══════════════════════════════════════════════════════════════════════════ */
const m1 = {
  meta: {
    module: 1,
    kicker: 'Interactive Scenario',
    title: 'Day Two: The Prospect Question',
    player: 'You — Security Analyst, Week 1',
    summary:
      "It is your second day at Security Impossible. Over the next few hours you will hit four small, " +
      "ordinary moments where the right instinct protects the firm — and the wrong one quietly puts a " +
      "client relationship at risk. Work through them with the team.",
    cast: ['elena', 'marcus', 'priya', 'david', 'auditor'],
  },
  scenes: [
    {
      id: 's1', act: 'Act 1 — The Welcome', title: 'Why any of this matters',
      setting: "9:14 AM. You're in a small meeting room for your day-two induction. Elena from People & Compliance has your laptop ready; Priya, the CISO, drops in for five minutes between meetings.",
      dialogue: [
        { s: 'elena', t: "Morning. Yesterday was paperwork — today is the part that actually matters. Before any policy, I want you to understand why we're strict." },
        { s: 'priya', t: "Quick version from me, then I'll get out of your way. We're a security firm. Clients hand us their crown jewels — their networks, their weak spots, their people. The only reason they do that is trust." },
        { s: 'priya', t: "So here's the question I ask every new hire on day two…" },
      ],
      prompt: "Priya asks: \"Why do you think a confidentiality slip hurts a firm like us more than it would hurt, say, a normal software company?\"",
      options: [
        { id: 'a', text: "Because we hold more data than most companies do.", score: 'poor',
          reaction: { s: 'priya', t: "Volume isn't really it — plenty of firms hold more data than we do. Think about what we sell." },
          feedback: "Not the core reason. It isn't the quantity of data — it's that our entire product is trust. A security firm that can't keep a secret has nothing to sell." },
        { id: 'b', text: "Because our whole business is built on clients trusting us to protect them — a slip breaks that premise entirely.", score: 'best',
          reaction: { s: 'priya', t: "Exactly. We sell trust. If we can't protect information ourselves, why would anyone let us near theirs? That's existential for us in a way it isn't for most companies." },
          feedback: "Right on target. Security Impossible sells trust. A breach doesn't just cause a legal problem — it undermines the reason clients hire us at all. That's why our internal bar is higher than what we recommend to others." },
        { id: 'c', text: "Because the legal penalties for security firms are higher than for other businesses.", score: 'poor',
          reaction: { s: 'priya', t: "The law applies to everyone the same way. The harm to us is reputational and commercial — it's about credibility." },
          feedback: "Penalties aren't firm-specific. The disproportionate harm is to credibility: our value proposition is that we can be trusted with sensitive things. Lose that and the legal fine is the smaller problem." },
      ],
    },
    {
      id: 's2', act: 'Act 2 — When Do The Rules Start?', title: 'The grace-period myth',
      setting: "10:40 AM. Elena is walking you through the policy library. You mention, half-joking, that you'll \"properly read all of these once onboarding is finished.\" Marcus, Head of IT & Security Ops, overhears from the next desk.",
      dialogue: [
        { s: 'marcus', t: "Ha — sorry to eavesdrop. Just want to flag one thing people get wrong, because it's the one that bites." },
        { s: 'elena',  t: "He's right to. It's the single most common day-one misunderstanding." },
        { s: 'marcus', t: "People assume there's a grace period — that the rules switch on once you've finished the course or passed probation. So when do you think your confidentiality obligations actually begin?" },
      ],
      prompt: "Marcus asks: \"When do your obligations around confidentiality and data handling start?\"",
      options: [
        { id: 'a', text: "Once I've completed all 11 onboarding modules.", score: 'poor',
          reaction: { s: 'marcus', t: "That's the myth exactly. If that were true, your first two days would be a free-for-all — and you've already had access to things." },
          feedback: "This is the grace-period myth. Finishing the course doesn't switch obligations on — the employment relationship already did, on day one." },
        { id: 'b', text: "When I first get access to a live client engagement.", score: 'ok',
          reaction: { s: 'marcus', t: "Closer — but you don't need to be on an engagement to overhear or see confidential things. You already can." },
          feedback: "Partly right in spirit, but too narrow. You don't have to touch a client file to leak one — a hallway conversation or a visible screen counts. Obligations cover everything from day one." },
        { id: 'c', text: "On my first day — before the course, before probation, before any client work.", score: 'best',
          reaction: { s: 'marcus', t: "That's it. No grace period. The moment you walked in, you were inside the perimeter — and some of these obligations outlast your employment, too." },
          feedback: "Correct. Your obligations begin on day one and many continue after you leave. There is no warm-up period — awareness has to start immediately." },
      ],
    },
    {
      id: 's3', act: 'Act 3 — The Coffee-Shop Question', title: 'A friend asks who your clients are',
      setting: "6:30 PM. You're at a café after work. A friend from another company is genuinely curious about your new job. It's relaxed, friendly, completely informal — exactly the setting where slips happen.",
      dialogue: [
        { s: 'auditor', t: "(Hannah, SI's external auditor, happens to be at the next table reviewing files. She isn't watching you — but this is precisely the kind of moment I write up in assessments.)" },
      ],
      prompt: "Your friend leans in: \"So what does Security Impossible actually do? Who are your big clients — anyone I'd recognise?\" How do you answer?",
      options: [
        { id: 'a', text: "\"We do work for a couple of big banks and a government department. Last week we found some really critical stuff on one of them.\"", score: 'poor',
          reaction: { s: 'auditor', t: "(That just disclosed client sectors, implied identities, and a live finding. In an audit, that's a confirmed confidentiality breach — informal setting or not.)" },
          feedback: "This names sectors, hints at clients, and reveals an engagement finding. The 'friendly setting' offers no protection — this is exactly the accidental breach the policy is written to prevent." },
        { id: 'b', text: "\"Between us — mostly finance and government work. Can't say more than that.\"", score: 'poor',
          reaction: { s: 'auditor', t: "('Between us' has no legal weight, and a sector hint still narrows the field enough for someone to guess. Still a slip.)" },
          feedback: "'Between us' creates no protection, and even a sector hint helps an observer reconstruct our client base. When in doubt, share nothing specific." },
        { id: 'c', text: "\"We do cybersecurity consulting — assessments and advisory. I can't name clients or describe projects, but there's a good feel for the work on our public website.\"", score: 'best',
          reaction: { s: 'auditor', t: "(Textbook. Describes only what's already public, protects client relationships, redirects to a legitimate source. Nothing to write up.)" },
          feedback: "Exactly right. You described the firm in already-public terms, protected client identity, and pointed to a legitimate source — warm, professional, and fully compliant." },
      ],
    },
    {
      id: 's4', act: 'Act 4 — The Stakes, Made Real', title: 'What a single slip actually costs',
      setting: "Next morning, 8:55 AM. David, the Managing Director, catches you by the coffee machine. He's warm but he wants to make one thing land before you start real work.",
      dialogue: [
        { s: 'david', t: "Heard your induction went well — welcome aboard properly. One story before you dive in, because numbers don't stick but this does." },
        { s: 'david', t: "Years ago, at another firm, someone mentioned a client's name at a conference dinner. Harmless, they thought. That client heard about it, lost confidence, and walked. We lost the account and three referrals that came with it." },
        { s: 'priya', t: "And that's the part people miss — it's never just one relationship." },
      ],
      prompt: "David asks: \"So — in your own words, why does one careless comment carry so much weight here?\"",
      options: [
        { id: 'a', text: "\"Because it could lead to a regulatory fine for the company.\"", score: 'ok',
          reaction: { s: 'david', t: "A fine might come, sure. But the thing that actually ended that account wasn't a regulator — it was lost confidence." },
          feedback: "Fines are possible but secondary. The deeper cost is reputational: trust is hard to win and instant to lose, and lost trust takes clients and their referrals with it." },
        { id: 'b', text: "\"Because trust is our whole product — one slip can cost a client, their referrals, and the firm's credibility, far beyond the single careless moment.\"", score: 'best',
          reaction: { s: 'david', t: "That's exactly the instinct I want you carrying into every engagement. You've got it. Welcome to the team." },
          feedback: "Spot on. The harm is disproportionate because trust is the product. A single slip can cascade into lost clients, lost referrals, and lasting reputational damage." },
        { id: 'c', text: "\"Because most breaches are deliberate, so we have to assume bad intent everywhere.\"", score: 'poor',
          reaction: { s: 'david', t: "Other way round, actually — almost all of them are accidents. That café comment yesterday? Nobody meant harm. That's the whole point." },
          feedback: "The opposite is true: most breaches are accidental, not malicious. That's precisely why everyday awareness — not suspicion of everyone — is the real defence." },
      ],
    },
  ],
  debrief: {
    title: 'Debrief — You\u2019ve got the instinct',
    lines: [
      { s: 'elena', t: "That's the scenario. Notice none of these were dramatic — a question, a comment, a casual chat. That's where real risk lives." },
      { s: 'priya', t: "You've internalised the four things that matter most: trust is the product, obligations start on day one, client identity is confidential, and the careful instinct beats any checklist." },
      { s: 'david', t: "Carry that into every engagement and you'll do well here. On to Module 2." },
    ],
    takeaways: [
      'Security Impossible sells trust — our own security posture is the proof of our credibility.',
      'Obligations begin on day one and many survive the end of employment.',
      'Client identity — the very fact of who our clients are — is itself confidential.',
      'Most breaches are accidental; everyday awareness is your strongest defence.',
    ],
  },
};

/* ════════════════════════════════════════════════════════════════════════════
 * MODULE 2 — Confidentiality & Your Obligations
 * ══════════════════════════════════════════════════════════════════════════ */
const m2 = {
  meta: {
    module: 2,
    kicker: 'Interactive Scenario',
    title: 'The Things You Carry',
    player: 'You — Security Analyst, Week 2',
    summary:
      "Confidentiality isn't one big rule — it's a hundred small judgement calls a day. Over four moments " +
      "you'll decide what counts as confidential, how to protect it in the wild, and how far the obligation " +
      "actually reaches. The team is watching how you reason, not just what you pick.",
    cast: ['elena', 'marcus', 'priya', 'david', 'auditor'],
  },
  scenes: [
    {
      id: 's1', act: 'Act 1 — What Even Counts', title: 'The "is this confidential?" reflex',
      setting: "Monday, 9:30 AM. You're drafting a case study for the marketing team. You've got a folder of material and you're trying to work out what you're allowed to use.",
      dialogue: [
        { s: 'elena', t: "Good that you're checking first — most people don't, and that's where it goes wrong. Marketing wants something punchy, but punchy and confidential are easy to confuse." },
        { s: 'elena', t: "You've got a draft that mentions the client only as 'a large Australian bank,' plus some numbers from the engagement. Before you send it — when you're genuinely not sure whether something's confidential, what's the right default?" },
      ],
      prompt: "Elena asks: \"When you're unsure whether a piece of information is confidential, what do you do?\"",
      options: [
        { id: 'a', text: "Treat it as Internal — share it within the company but not outside.", score: 'ok',
          reaction: { s: 'elena', t: "Better than publishing it, but 'Internal' is still a guess. If you're not sure, you don't get to pick the lower tier." },
          feedback: "Defaulting to Internal is safer than disclosure, but the policy is stricter: when genuinely unsure, treat it as Confidential until you confirm — don't self-assign a lower classification." },
        { id: 'b', text: "Treat it as confidential until I confirm otherwise with the owner or my lead.", score: 'best',
          reaction: { s: 'elena', t: "Exactly. Default to protection, confirm, then downgrade if it's cleared. That instinct will keep you out of trouble for your whole career here." },
          feedback: "Correct. The Data Handling Policy is explicit: if you're unsure, treat it as confidential until you confirm. Default to protection, not disclosure." },
        { id: 'c', text: "Publish the draft — it doesn't name the client, so it's fine.", score: 'poor',
          reaction: { s: 'elena', t: "'A large Australian bank' plus those numbers? That narrows it down fast. Not naming someone isn't the same as protecting them." },
          feedback: "Not naming the client isn't enough — sector, scale, and figures can re-identify them. And acting while unsure is exactly the wrong default." },
      ],
    },
    {
      id: 's2', act: 'Act 2 — The Café Video Call', title: 'Confidentiality in public space',
      setting: "Wednesday, 2:00 PM. You're working from a café and join a video call about a client engagement. The person at the next table can hear you, and your screen — showing the client's network diagram — faces the room.",
      dialogue: [
        { s: 'marcus', t: "(on the call) Before we get into it — where are you right now? I can hear an espresso machine and your camera's picking up a lot of background." },
        { s: 'marcus', t: "I'm going to stop you there. Two problems at once: people can hear a client conversation, and your screen with their network diagram is visible to the whole room. What's your move?" },
      ],
      prompt: "Marcus asks: \"What do you do?\"",
      options: [
        { id: 'a', text: "Turn the laptop slightly so the screen's harder to see, and keep going.", score: 'poor',
          reaction: { s: 'marcus', t: "'Harder to see' isn't a control. And the audio's still wide open — the diagram's only half the problem." },
          feedback: "Angling the screen isn't a security control, and it ignores the overheard audio entirely. The standard is that confidential material must not be visible or audible to unauthorised people." },
        { id: 'b', text: "Stop sharing my screen but stay on the audio so we don't lose momentum.", score: 'ok',
          reaction: { s: 'marcus', t: "Closes one hole, leaves the other. The conversation itself is confidential — and the room can still hear it." },
          feedback: "Half a fix. The diagram is protected but the spoken conversation is still confidential and still being overheard. Both channels need to be secured." },
        { id: 'c', text: "Pause the call, move to a private space, and use a privacy screen before rejoining.", score: 'best',
          reaction: { s: 'marcus', t: "That's it. Both issues resolved before we continue. Five minutes of delay beats a confidentiality breach every time." },
          feedback: "Correct. Confidential work needs a private location, a privacy screen, and no one able to overhear. Resolve both the visual and audio exposure before continuing — never trade security for momentum." },
      ],
    },
    {
      id: 's3', act: 'Act 3 — The Old Project Folder', title: 'How long the obligation lasts',
      setting: "Thursday, 11:00 AM. A teammate, Sam, is leaving the firm next week. Over coffee they mention they're keeping \"a few sanitised project folders\" as portfolio examples for their next role.",
      dialogue: [
        { s: 'auditor', t: "(Hannah, mid-audit, looks up.) I deal with this exact situation in nearly every exit review. People assume 'sanitised' and 'I'm leaving anyway' make it fine. They don't." },
        { s: 'priya', t: "Sam's a good person who's about to make a serious mistake. You're standing right there. What's the accurate thing to tell them?" },
      ],
      prompt: "Priya asks: \"Is Sam allowed to keep sanitised client project folders for their portfolio after they leave?\"",
      options: [
        { id: 'a', text: "Yes — once it's sanitised and they've left, it's their own work to show off.", score: 'poor',
          reaction: { s: 'auditor', t: "That's the most common wrong answer I hear. Sanitising reduces one risk; it doesn't transfer ownership, and the duty doesn't end at the door." },
          feedback: "Wrong on two counts: confidentiality obligations continue indefinitely after departure, and the work itself is company IP — leaving doesn't make it theirs to take." },
        { id: 'b', text: "Yes, but only the folders that don't mention a client by name.", score: 'poor',
          reaction: { s: 'auditor', t: "Removing the name isn't the test. The methodology and the content are still the firm's — and still confidential." },
          feedback: "Removing names doesn't fix it. The methodology and content remain confidential company IP regardless of whether a client is named." },
        { id: 'c', text: "No — confidentiality and IP obligations continue after they leave; they can't take client work or methodology with them.", score: 'best',
          reaction: { s: 'priya', t: "Right. And telling them now, kindly, is a favour — better an awkward chat than a legal letter after they've started somewhere new." },
          feedback: "Correct. Confidentiality obligations survive employment, and company IP can't be taken to a new role — even sanitised. The kind thing is to flag it before they make it a real problem." },
      ],
    },
    {
      id: 's4', act: 'Act 4 — The Honest Mistake', title: 'Most breaches are accidents',
      setting: "Friday, 4:45 PM. You realise you replied-all to an external thread and accidentally attached an internal file that references a client. Your stomach drops.",
      dialogue: [
        { s: 'david', t: "(you've come to his door) Breathe. I can see your face. Tell me what happened — plainly." },
        { s: 'david', t: "Okay. This is the moment that defines whether you're someone I can trust with hard things. What do you want to do right now?" },
      ],
      prompt: "David asks: \"What's your next move?\"",
      options: [
        { id: 'a', text: "Quietly send a recall request and hope nobody opened it — no need to make a fuss.", score: 'poor',
          reaction: { s: 'david', t: "Recall almost never works, and 'hope nobody noticed' is how a small mistake becomes a cover-up. Don't do that to yourself." },
          feedback: "Staying quiet turns an accident into something worse. Recall is unreliable, and concealment is the real career risk — not the honest error." },
        { id: 'b', text: "Wait until Monday to report it so the team isn't disrupted on a Friday evening.", score: 'poor',
          reaction: { s: 'david', t: "Every hour matters for containment. A ruined Friday evening is a fair price; a weekend of unmanaged exposure isn't." },
          feedback: "Delay reduces the team's ability to contain it. Speed limits the damage — report immediately, regardless of timing." },
        { id: 'c', text: "Report it straight away to IT/security and my lead, with exactly what was sent and to whom.", score: 'best',
          reaction: { s: 'david', t: "That's exactly right, and exactly why you'll do well here. Nobody gets punished for reporting an honest mistake fast. Go — I'll back you." },
          feedback: "Correct. Most breaches are accidental; what matters is fast, honest reporting so the team can contain it. You'll never be penalised for reporting quickly — only for hiding it." },
      ],
    },
  ],
  debrief: {
    title: 'Debrief — Confidentiality is a habit, not a rule',
    lines: [
      { s: 'elena', t: "Four moments, four reflexes: default to confidential, protect it in public, remember it follows you, and own mistakes fast." },
      { s: 'priya', t: "None of those needed you to memorise a policy clause. They needed instinct — which is the whole point of the deed you've acknowledged." },
      { s: 'auditor', t: "From an auditor's seat: people who reason like you just did are the ones who never end up in my findings. Good." },
    ],
    takeaways: [
      'If unsure whether something is confidential, treat it as confidential until you confirm.',
      'Confidential conversations and screens need a private location and a privacy screen — both channels.',
      'Confidentiality and IP obligations continue indefinitely after you leave.',
      'Most breaches are accidental — report honestly and immediately; you won\u2019t be punished for it.',
    ],
  },
};

/* ════════════════════════════════════════════════════════════════════════════
 * MODULE 3 — Intellectual Property & Ownership
 * ══════════════════════════════════════════════════════════════════════════ */
const m3 = {
  meta: {
    module: 3,
    kicker: 'Interactive Scenario',
    title: 'Whose Work Is It?',
    player: 'You — Security Analyst, building a new lab',
    summary:
      "You're building a training lab — and IP questions are everywhere: who owns what you make, which open-source " +
      "licences are safe to pull in, and what you can feed into an AI tool. Four decisions decide whether the lab " +
      "ships clean or carries hidden legal exposure.",
    cast: ['elena', 'marcus', 'priya', 'david', 'auditor'],
  },
  scenes: [
    {
      id: 's1', act: 'Act 1 — The Side Project Question', title: 'Who owns what you build',
      setting: "Tuesday, 10:00 AM. You built a slick little parsing tool on a work afternoon to speed up your lab. A teammate suggests you put it on your personal GitHub \"since you wrote it.\"",
      dialogue: [
        { s: 'elena', t: "I want to catch this before it becomes a habit. The tool's genuinely useful — nice work. But there's an ownership question hiding in here." },
        { s: 'elena', t: "You wrote it on a work afternoon, to do a work task, as part of your role. Before it lands on a public personal repo — who actually owns it?" },
      ],
      prompt: "Elena asks: \"Who owns the parsing tool you built?\"",
      options: [
        { id: 'a', text: "I do — I wrote every line of it myself.", score: 'poor',
          reaction: { s: 'elena', t: "Authorship and ownership aren't the same thing in an employment context. You wrote it; that doesn't make it yours to publish." },
          feedback: "Writing the code doesn't make it yours. Work created within the scope of employment belongs to Security Impossible, per the IP Deed." },
        { id: 'b', text: "Security Impossible owns it — it was created within the scope of my employment.", score: 'best',
          reaction: { s: 'elena', t: "Correct. If you want to open-source something, that's a conversation we can have — but it starts with the company, not a personal repo." },
          feedback: "Right. Work made within the scope of employment is company IP. Publishing it personally would be giving away a company asset — any open-sourcing has to be approved first." },
        { id: 'c', text: "It's shared — half mine since I wrote it, half the company's.", score: 'poor',
          reaction: { s: 'elena', t: "There's no automatic split. The deed assigns work-scope creations to the company outright." },
          feedback: "There's no automatic co-ownership. The Employee Confidentiality & IP Deed assigns work created in your role to the company." },
      ],
    },
    {
      id: 's2', act: 'Act 2 — The GPL Library', title: 'Open-source licences carry obligations',
      setting: "Wednesday, 1:30 PM. You found a perfect open-source library for the lab. It's licensed GPL-3.0. You're about to bundle it into the lab product that ships to clients.",
      dialogue: [
        { s: 'marcus', t: "Hold on — what's the licence on that one? 'Free to use' and 'free of obligations' are very different things." },
        { s: 'marcus', t: "It's GPL-3.0. That's a copyleft licence. If we link it into a product we distribute, it can pull obligations onto our own code. So — do you just drop it in?" },
      ],
      prompt: "Marcus asks: \"It's GPL-3.0 and the lab ships to clients. What do you do?\"",
      options: [
        { id: 'a', text: "Use it — open source means free to use however we like.", score: 'poor',
          reaction: { s: 'marcus', t: "That's the assumption that creates real legal exposure. 'Open source' is not 'no strings attached.'" },
          feedback: "Open source isn't obligation-free. GPL is copyleft — distributing it inside our product can force us to release our own source. Licences must be checked before use." },
        { id: 'b', text: "Check the licence terms and clear it with the lead/legal before bundling — or find a permissively-licensed alternative (MIT/Apache).", score: 'best',
          reaction: { s: 'marcus', t: "Exactly. Either get it cleared, or swap to something permissive. Two minutes of licence-checking saves a very expensive problem." },
          feedback: "Correct. GPL can create genuine legal exposure when distributed. Verify the licence and get sign-off, or choose a permissive alternative like MIT or Apache-2.0." },
        { id: 'c', text: "Use it but add a comment crediting the original author.", score: 'poor',
          reaction: { s: 'marcus', t: "Attribution is necessary for some licences but it doesn't satisfy GPL's copyleft terms. A credit line doesn't make distribution compliant." },
          feedback: "Attribution alone doesn't satisfy GPL's copyleft conditions. The distribution terms are the issue, not credit — the licence has to be assessed properly." },
      ],
    },
    {
      id: 's3', act: 'Act 3 — The AI Shortcut', title: 'What you feed into AI tools',
      setting: "Thursday, 3:00 PM. You're stuck on a tricky function that includes some proprietary lab logic. The fastest fix is to paste the whole thing into a public AI chatbot and ask it to debug.",
      dialogue: [
        { s: 'priya', t: "I'm going to flag this before you hit enter, because it's a fast way to leak our crown jewels without meaning to." },
        { s: 'priya', t: "That function contains proprietary methodology — part of what clients pay us for. The public AI box isn't a private workspace. So what's the right approach?" },
      ],
      prompt: "Priya asks: \"How do you get AI help with this without creating a problem?\"",
      options: [
        { id: 'a', text: "Paste it in — AI tools don't really keep your prompts anyway.", score: 'poor',
          reaction: { s: 'priya', t: "Many do retain prompts, and even if one didn't, you've still handed proprietary IP to a third party. The disclosure is the breach." },
          feedback: "Many tools retain prompts for training, and the disclosure itself is the breach regardless. Never input confidential or proprietary content into public AI tools." },
        { id: 'b', text: "Reproduce the bug with a generic, non-proprietary example, or use only a company-approved enterprise AI tool.", score: 'best',
          reaction: { s: 'priya', t: "That's the move. Abstract it to a fictional example, or use a vetted enterprise tool. You keep the help without giving away the methodology." },
          feedback: "Correct. Strip out proprietary detail and reproduce the issue generically, or use a vetted enterprise AI tool. Treat any public prompt box as public." },
        { id: 'c', text: "Paste it but delete the chat afterwards.", score: 'poor',
          reaction: { s: 'priya', t: "Deleting your copy of the conversation doesn't recall what already reached their servers. It's gone the moment you send it." },
          feedback: "Deleting the local chat doesn't undo the transmission — the proprietary content already left our control. Don't send it in the first place." },
      ],
    },
    {
      id: 's4', act: 'Act 4 — The Methodology Is the Product', title: 'Protecting commercial assets',
      setting: "Friday, 11:30 AM. A vendor you're evaluating asks you to send over \"a sample lab and your scenario design template\" so they can \"understand your needs.\"",
      dialogue: [
        { s: 'david', t: "Vendors ask for this a lot, and it sounds reasonable. But our lab content and scenario methodology are core commercial assets — it's literally the product." },
        { s: 'david', t: "They're not bound by anything yet. How do you handle the request?" },
      ],
      prompt: "David asks: \"Do you send the sample lab and design template?\"",
      options: [
        { id: 'a', text: "Send it — it's just a sample and it'll help them help us.", score: 'poor',
          reaction: { s: 'david', t: "A 'sample' of our methodology is still our methodology. And they've signed nothing — there's no protection on it at all." },
          feedback: "A sample of our methodology is still a core commercial asset, and the vendor isn't bound by any confidentiality terms. That's giving the product away." },
        { id: 'b', text: "Don't share it without a confidentiality agreement and lead approval; share only what's strictly necessary, ideally non-proprietary.", score: 'best',
          reaction: { s: 'david', t: "Exactly right. Bind them first, share the minimum, keep the methodology in-house. You're thinking like an owner of the business." },
          feedback: "Correct. Third parties must be bound by appropriate confidentiality terms before receiving anything sensitive — and even then, share only the minimum, keeping proprietary methodology protected." },
        { id: 'c', text: "Send a redacted version with client names removed.", score: 'poor',
          reaction: { s: 'david', t: "The client names were never the valuable part — the design methodology is. Redaction misses what we're actually protecting." },
          feedback: "Redacting client names misses the point: the scenario design methodology itself is the commercial IP being exposed, agreement or not." },
      ],
    },
  ],
  debrief: {
    title: 'Debrief — IP is the asset you build on',
    lines: [
      { s: 'elena', t: "You held the line on all four: work-scope creations are the firm's, licences get checked, AI stays clean, and methodology stays in-house." },
      { s: 'marcus', t: "The GPL one trips up good engineers constantly. Checking a licence takes two minutes and saves a genuine legal mess." },
      { s: 'priya', t: "And the AI instinct will matter more every year. Treat that prompt box as public, every time." },
    ],
    takeaways: [
      'Work created within the scope of employment belongs to Security Impossible.',
      'Open-source licences carry obligations — check them (GPL copyleft) before use; prefer permissive licences.',
      'Never input confidential, client, or proprietary content into public AI tools.',
      'Lab content and methodology are core commercial IP — bind third parties and share only the minimum.',
    ],
  },
};

/* ════════════════════════════════════════════════════════════════════════════
 * MODULE 4 — Privacy & the Australian Privacy Principles
 * ══════════════════════════════════════════════════════════════════════════ */
const m4 = {
  meta: {
    module: 4,
    kicker: 'Interactive Scenario',
    title: 'The Spreadsheet That Knows Too Much',
    player: 'You — Security Analyst, handling personal data',
    summary:
      "Personal information is regulated, and the rules are specific. Across four moments you'll identify what counts " +
      "as personal (and sensitive) information, apply collection limits, and meet the Notifiable Data Breaches " +
      "timeline. The APPs aren't optional guidance — they're law.",
    cast: ['elena', 'marcus', 'priya', 'david', 'auditor'],
  },
  scenes: [
    {
      id: 's1', act: 'Act 1 — Is This Personal Information?', title: 'Defining the data',
      setting: "Monday, 9:45 AM. You're cleaning up a dataset of platform learners: names, emails, course progress, and a column noting some learners requested captioning for accessibility reasons.",
      dialogue: [
        { s: 'elena', t: "Quick gut-check before you do anything with that file. Two of those columns are more regulated than the others, and one of them is in a special category." },
        { s: 'elena', t: "Names and emails are clearly personal information. But that accessibility/captioning column — how should we treat it?" },
      ],
      prompt: "Elena asks: \"How should the accessibility-needs column be classified?\"",
      options: [
        { id: 'a', text: "It's fine — it's just a UI preference, not really personal data.", score: 'poor',
          reaction: { s: 'elena', t: "It can reveal something about a person's health or disability. That pushes it into a more protected category, not a lower one." },
          feedback: "An accessibility need can imply health or disability information — that's sensitive information, which requires higher protection, not less." },
        { id: 'b', text: "It's sensitive information (it can reveal health/disability) and needs higher protection than the rest.", score: 'best',
          reaction: { s: 'elena', t: "Exactly. Sensitive info gets stricter handling — tighter access, clearer purpose, extra care. Spotting it is half the battle." },
          feedback: "Correct. Information that can reveal health or disability is sensitive information under the APPs and warrants the highest protection." },
        { id: 'c', text: "It's personal information, same tier as names and emails.", score: 'ok',
          reaction: { s: 'elena', t: "Right that it's personal — but it's a notch above the rest. Sensitive information is its own, stricter category." },
          feedback: "It is personal information, but it's specifically sensitive information — a higher-protection subcategory, handled more strictly than names and emails." },
      ],
    },
    {
      id: 's2', act: 'Act 2 — The "Just In Case" Request', title: 'Collection limitation',
      setting: "Tuesday, 11:15 AM. A colleague building a webinar sign-up form asks you to add fields for date of birth and home address \"so we have richer data on attendees, just in case we need it later.\"",
      dialogue: [
        { s: 'priya', t: "I want to slow this one down. 'Just in case' is how organisations end up holding data they can't justify — and every extra field is extra liability if we're ever breached." },
        { s: 'priya', t: "It's a webinar sign-up. What do you tell them about collecting DOB and home address?" },
      ],
      prompt: "Priya asks: \"Should the form collect date of birth and home address?\"",
      options: [
        { id: 'a', text: "Yes — more data is always useful and we can delete it later if needed.", score: 'poor',
          reaction: { s: 'priya', t: "That's backwards. Under the APPs we only collect what we actually need for the stated purpose — not what might be handy someday." },
          feedback: "Collecting 'just in case' breaches the collection-limitation principle. Only collect personal information reasonably necessary for the stated purpose." },
        { id: 'b', text: "Only collect what's necessary for a webinar (name, email); leave out DOB and home address.", score: 'best',
          reaction: { s: 'priya', t: "Exactly. Minimise collection, minimise risk. Data you never collected can never be breached." },
          feedback: "Correct. The APPs require collecting only what's reasonably necessary for the purpose. A webinar needs a name and email — not DOB or home address." },
        { id: 'c', text: "Collect them but make the fields optional.", score: 'ok',
          reaction: { s: 'priya', t: "Optional is better than mandatory, but if there's no purpose for it, the cleanest answer is not to ask at all." },
          feedback: "Optional fields are an improvement, but if the data isn't needed for the purpose, the principled approach is not to collect it at all." },
      ],
    },
    {
      id: 's3', act: 'Act 3 — The Wrong Recipient', title: 'The NDB clock starts',
      setting: "Wednesday, 4:20 PM. A teammate realises they emailed a spreadsheet of learner names, emails, and accessibility flags to the wrong external distribution list an hour ago.",
      dialogue: [
        { s: 'marcus', t: "Okay — this involves personal and sensitive information going to people who shouldn't have it. That's potentially a notifiable data breach, and the clock is already running." },
        { s: 'auditor', t: "(Hannah) This is the one regulators look hardest at: not the mistake, but how fast and correctly you responded to it." },
      ],
      prompt: "Marcus asks: \"What has to happen now?\"",
      options: [
        { id: 'a', text: "Email the wrong recipients asking them to delete it, then move on.", score: 'poor',
          reaction: { s: 'marcus', t: "A delete-please email isn't a breach response. This has to be reported internally now so it can be assessed against the NDB timeframes." },
          feedback: "Asking recipients to delete isn't a compliant response. A suspected eligible breach must be reported immediately so it can be assessed under the NDB scheme's legal timeframes." },
        { id: 'b', text: "Report it immediately through the incident process so it can be assessed and notified within the NDB timeframes.", score: 'best',
          reaction: { s: 'auditor', t: "(Hannah) That's the answer I'd want to see in an audit. Fast internal reporting is what makes lawful, on-time notification possible." },
          feedback: "Correct. Suspected breaches must be reported immediately. The Notifiable Data Breaches scheme imposes legal timeframes — only fast internal escalation lets the firm assess and notify on time." },
        { id: 'c', text: "Wait to see if the recipients actually opened it before raising anything.", score: 'poor',
          reaction: { s: 'marcus', t: "Waiting burns the clock. The NDB timeframes don't pause while you hope nobody read it." },
          feedback: "Waiting wastes time against a legal deadline. The NDB clock doesn't stop for 'maybe nobody looked' — report immediately and let the team assess." },
      ],
    },
    {
      id: 's4', act: 'Act 4 — The Access Request', title: 'Individuals\u2019 rights',
      setting: "Thursday, 2:30 PM. A learner emails asking what personal information the platform holds about them and requests a correction to their recorded name.",
      dialogue: [
        { s: 'david', t: "This is a routine but important one — individuals have rights over their own data under the APPs, and how we respond reflects on the whole firm." },
        { s: 'david', t: "It's a genuine request from the person themselves. What's the right handling?" },
      ],
      prompt: "David asks: \"How do you handle the learner's access-and-correction request?\"",
      options: [
        { id: 'a', text: "Ignore it — we're not obliged to tell people what we hold.", score: 'poor',
          reaction: { s: 'david', t: "We very much are. Access and correction are core rights under the APPs — ignoring it is a compliance failure in itself." },
          feedback: "Individuals have a right to access and correct their personal information under the APPs. Ignoring a legitimate request is itself a breach." },
        { id: 'b', text: "Verify it's really them, then handle it through the proper privacy process — provide access and make the correction.", score: 'best',
          reaction: { s: 'david', t: "Exactly. Confirm identity so you're not disclosing to an impostor, then honour the request through the privacy process. Clean and compliant." },
          feedback: "Correct. Verify the requester's identity (so you don't disclose to the wrong person), then provide access and make the correction through the established privacy process." },
        { id: 'c', text: "Reply with the full data export straight away to be helpful and fast.", score: 'poor',
          reaction: { s: 'david', t: "Good instinct to be responsive — but send it before verifying identity and you might be handing someone's data to an impostor." },
          feedback: "Speed without identity verification risks disclosing personal information to an impostor. Confirm the requester is who they claim before releasing anything." },
      ],
    },
  ],
  debrief: {
    title: 'Debrief — Privacy is law, not preference',
    lines: [
      { s: 'elena', t: "You spotted sensitive information, minimised collection, started the NDB clock correctly, and honoured an individual's rights. That's the whole module." },
      { s: 'priya', t: "The 'just in case' trap catches well-meaning people constantly. Data you never collect is data you can never breach." },
      { s: 'auditor', t: "(Hannah) And the breach-response instinct — report fast, assess against the timeframes — is exactly what keeps us out of regulator trouble." },
    ],
    takeaways: [
      'Personal information is any info about an identified or identifiable individual; sensitive information (health, biometric, etc.) needs higher protection.',
      'Collect only what is reasonably necessary for the stated purpose — never "just in case".',
      'Report suspected breaches immediately — the NDB scheme imposes legal notification timeframes.',
      'Individuals have rights to access and correct their data — verify identity, then handle through the privacy process.',
    ],
  },
};

export { m1, m2, m3, m4 };
