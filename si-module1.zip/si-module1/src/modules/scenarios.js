// ── Scenario registry — modules 9 through 11 + assembled registry ────────────
// See scenarios_part1.js for the object shape and conventions.

import { m1, m2, m3, m4 } from './scenarios_part1.js';
import { m5, m6, m7, m8 } from './scenarios_part2.js';

/* ════════════════════════════════════════════════════════════════════════════
 * MODULE 9 — Social Media & Public Conduct
 * ══════════════════════════════════════════════════════════════════════════ */
const m9 = {
  meta: {
    module: 9,
    kicker: 'Interactive Scenario',
    title: 'The Post You Don\u2019t Send',
    player: 'You — Security Analyst, building a public profile',
    summary:
      "For a security firm, social media is uniquely high-risk — a single proud post can leak a client or give away " +
      "our methodology. Across four moments you'll learn what the 'views are my own' disclaimer can't do, how subtly " +
      "a client can be identified, and how to conduct yourself during a crisis.",
    cast: ['elena', 'marcus', 'priya', 'david', 'auditor'],
  },
  scenes: [
    {
      id: 's1', act: 'Act 1 — The LinkedIn Win', title: 'The disclaimer\u2019s limits',
      setting: "Monday, 5:30 PM. You just finished a great red-team engagement. You draft a LinkedIn post: 'Wrapped an amazing pentest — popped domain admin in under 4 hours! Can't say who, but a big name in finance.' You add 'Views are my own.'",
      dialogue: [
        { s: 'elena', t: "I can feel the pride in that draft, and I get it — it was good work. But read it as an outsider trying to figure out who the client is." },
        { s: 'elena', t: "You added 'Views are my own.' Does that disclaimer actually make this post safe to publish?" },
      ],
      prompt: "Elena asks: \"Does 'Views are my own' make the post okay?\"",
      options: [
        { id: 'a', text: "Yes — the disclaimer separates my personal posts from the company, so I'm covered.", score: 'poor',
          reaction: { s: 'elena', t: "That's the most common misread. The disclaimer separates opinion from company position — it does nothing about a confidentiality leak." },
          feedback: "The disclaimer only separates personal opinion from company position. It provides no protection at all against leaking confidential client information." },
        { id: 'b', text: "No — 'a big name in finance' plus the timing can identify the client, and the disclaimer doesn't cover confidentiality breaches.", score: 'best',
          reaction: { s: 'elena', t: "Exactly. Sector plus timing narrows it fast, and the disclaimer is irrelevant to that. Don't post it." },
          feedback: "Correct. Sector hints plus timing can identify the client, and the disclaimer doesn't authorise a confidentiality breach. To show skills, build something personal and unrelated to company work." },
        { id: 'c', text: "Yes, as long as I never actually name the client.", score: 'poor',
          reaction: { s: 'elena', t: "Not naming them isn't the test. 'Big name in finance' + this week + domain admin in 4 hours is plenty to identify them." },
          feedback: "Not naming the client isn't enough — sector, timing, and a specific technical achievement can re-identify them. The threshold for client-identifying detail is lower than people expect." },
      ],
    },
    {
      id: 's2', act: 'Act 2 — The Subtle Version', title: 'How little it takes to identify a client',
      setting: "Monday, 5:40 PM. You try a 'safer' version: 'Wrapped up an amazing pentest this week — popped domain admin in under 4 hours!' No sector, no name.",
      dialogue: [
        { s: 'marcus', t: "Better — you cut the 'finance' hint. But there's still more in there than you might think, and it's not just about identifying the client." },
        { s: 'marcus', t: "Is this trimmed version safe to post?" },
      ],
      prompt: "Marcus asks: \"Is the trimmed post — engagement + 'domain admin in 4 hours' — safe?\"",
      options: [
        { id: 'a', text: "Yes — with no sector or name, there's nothing identifying left.", score: 'poor',
          reaction: { s: 'marcus', t: "Timing plus a specific result can still point at a client — and 'how we got domain admin' is methodology, which is our commercial IP." },
          feedback: "Even without sector/name, timing plus a specific result can identify a client, and describing the achievement reveals methodology — which is commercial IP." },
        { id: 'b', text: "No — engagement details and the specific achievement still reveal methodology (commercial IP) and, with timing, can point at the client.", score: 'best',
          reaction: { s: 'marcus', t: "Right. The bar is lower than it feels. If it describes real engagement work, it doesn't go out." },
          feedback: "Correct. Describing real engagement work exposes methodology (our IP), and timing plus specifics can still identify the client. Keep public posts off actual engagements entirely." },
        { id: 'c', text: "Post it but drop the '4 hours' detail.", score: 'ok',
          reaction: { s: 'marcus', t: "Closer, but 'wrapped a pentest, popped domain admin' is still describing live engagement work. The cleanest answer is not to post about it at all." },
          feedback: "Removing the timing helps a little, but it still describes real engagement work and methodology. The safe approach is not to post about actual engagements." },
      ],
    },
    {
      id: 's3', act: 'Act 3 — The Lab Screenshot', title: 'Lab content is the product',
      setting: "Tuesday, 11:00 AM. You're proud of a lab you built and think a screenshot of it would make a great portfolio post to show your skills publicly.",
      dialogue: [
        { s: 'auditor', t: "(Hannah) People treat their own builds as 'mine to show.' But the lab content is the company's commercial product." },
        { s: 'priya', t: "Is a screenshot of a lab you built a good way to demonstrate your skills online?" },
      ],
      prompt: "Priya asks: \"Should you post a screenshot of a lab you built?\"",
      options: [
        { id: 'a', text: "Yes — I built it, and it shows real capability.", score: 'poor',
          reaction: { s: 'priya', t: "You built it on the job, which makes it the firm's commercial IP. Posting it gives away the product." },
          feedback: "Lab content is company commercial IP — posting it publicly gives away the product and our competitive advantage, regardless of who built it." },
        { id: 'b', text: "No — lab content is company commercial IP; I'd build something personal and unrelated to demonstrate skills.", score: 'best',
          reaction: { s: 'priya', t: "Exactly. Show your skills with a personal project that owes nothing to our IP. Best of both worlds." },
          feedback: "Correct. Lab content is the company's product and IP. To showcase skills publicly, build something personal and unrelated to company work." },
        { id: 'c', text: "Yes, if I blur any client-specific parts first.", score: 'poor',
          reaction: { s: 'priya', t: "Blurring client bits misses the point — the lab design itself is the IP we're protecting." },
          feedback: "Blurring client details misses the issue: the lab's design and content are themselves the commercial IP being exposed." },
      ],
    },
    {
      id: 's4', act: 'Act 4 — During a Crisis', title: 'Public conduct under pressure',
      setting: "Wednesday, 9:15 AM. News is breaking about a security incident that may involve a client. Your network is asking you about it, and you're tempted to share what you know to look informed and reassuring.",
      dialogue: [
        { s: 'david', t: "This is exactly when discipline matters most. In a crisis, one off-the-cuff post can do more damage than the incident itself." },
        { s: 'david', t: "People are asking you directly. What's your role on social media right now?" },
      ],
      prompt: "David asks: \"How do you conduct yourself online during the crisis?\"",
      options: [
        { id: 'a', text: "Share what I know to keep my network informed and reassured.", score: 'poor',
          reaction: { s: 'david', t: "Even well-meant, that's speculation on an active incident — and it can be wrong, or confidential, or both. Don't." },
          feedback: "Sharing during a crisis risks spreading unverified or confidential information. All crisis communication goes through official channels only." },
        { id: 'b', text: "Say nothing publicly and direct any questions to the official channels; follow the crisis communication protocol.", score: 'best',
          reaction: { s: 'david', t: "Exactly. No speculation, no commentary — point everything to the official channel and let it do its job." },
          feedback: "Correct. During a crisis, follow official channels only — no speculation, no commentary, no unverified information. Redirect questions to the designated channel." },
        { id: 'c', text: "Post a vague reassuring message without specifics.", score: 'poor',
          reaction: { s: 'david', t: "Even a vague post is unsanctioned commentary on a live incident. Stay off it entirely and let the official channel speak." },
          feedback: "Even a vague post is unauthorised commentary during a crisis. The rule is to stay off it and route everything through official channels." },
      ],
    },
  ],
  debrief: {
    title: 'Debrief — Pride is fine; posting it isn\u2019t',
    lines: [
      { s: 'elena', t: "You learned the disclaimer's real limits, saw how little it takes to identify a client, protected the lab IP, and stayed disciplined in a crisis." },
      { s: 'marcus', t: "The trimmed-post trap is the sneaky one — describing the work at all is usually enough to be a problem." },
      { s: 'priya', t: "Want to build a public profile? Build personal projects that owe nothing to our clients or our IP. Plenty of room to shine there." },
    ],
    takeaways: [
      '"Views are my own" does NOT protect you if you leak confidential information.',
      'Never reveal clients or describe client work — sector hints and timing can identify them.',
      'Lab content and methodology are commercial IP — don\u2019t post screenshots; showcase personal, unrelated projects.',
      'During a crisis: official channels only — no speculation, no commentary.',
    ],
  },
};

/* ════════════════════════════════════════════════════════════════════════════
 * MODULE 10 — Working with Clients & Third Parties
 * ══════════════════════════════════════════════════════════════════════════ */
const m10 = {
  meta: {
    module: 10,
    kicker: 'Interactive Scenario',
    title: 'Inside the Client\u2019s Walls',
    player: 'You — Security Analyst, on a live engagement',
    summary:
      "On engagements you're trusted with deep access to a client's systems and people. Across four moments you'll " +
      "stay inside scope, keep client relationships walled off from each other, handle an out-of-scope discovery " +
      "correctly, and bind third parties before sharing anything.",
    cast: ['elena', 'marcus', 'priya', 'david', 'auditor'],
  },
  scenes: [
    {
      id: 's1', act: 'Act 1 — The Tempting Door', title: 'Privileged access has a scope',
      setting: "Monday, 10:30 AM. Mid-assessment for Client A, you notice you could easily pivot into an adjacent system that's interesting but clearly outside your engagement scope.",
      dialogue: [
        { s: 'marcus', t: "That access you've got? It's a privilege, granted for one specific purpose. The fact that you can reach further doesn't mean you're allowed to." },
        { s: 'marcus', t: "The adjacent system is out of scope but wide open to you. Do you take a look?" },
      ],
      prompt: "Marcus asks: \"Do you explore the out-of-scope system?\"",
      options: [
        { id: 'a', text: "Yes — more findings mean more value for the client.", score: 'poor',
          reaction: { s: 'marcus', t: "Even with good intentions, that's unauthorised access. Scope isn't a suggestion — it's the boundary of what we're permitted to touch." },
          feedback: "Going beyond scope is unauthorised access, even when well-intentioned. Access is granted for the agreed purpose only — exploring further can create serious legal and contractual problems." },
        { id: 'b', text: "No — access is for the agreed scope only; I stay within it.", score: 'best',
          reaction: { s: 'marcus', t: "Exactly. The boundary is the boundary. If something beyond it matters, that's an escalation, not a self-authorised detour." },
          feedback: "Correct. Privileged access is for the agreed scope and purpose only. Never explore beyond it, even with good intentions — that's the core rule of engagement work." },
        { id: 'c', text: "Just a quick read-only look — I won't change anything.", score: 'poor',
          reaction: { s: 'marcus', t: "Read-only is still access you weren't authorised for. Looking is the breach, not just touching." },
          feedback: "Read-only access you weren't authorised for is still unauthorised access. Observation outside scope is itself the breach." },
      ],
    },
    {
      id: 's2', act: 'Act 2 — Name-Dropping', title: 'Clients are walled off from each other',
      setting: "Tuesday, 2:00 PM. In a meeting with prospective Client B, you're tempted to mention the great work you did for Client A (a recognisable name) to build credibility.",
      dialogue: [
        { s: 'david', t: "It's a natural sales instinct — proof you've done this before. But each client relationship is sealed off from every other one." },
        { s: 'david', t: "Do you mention Client A's name to Client B to build trust?" },
      ],
      prompt: "David asks: \"Can you reference Client A to win Client B's confidence?\"",
      options: [
        { id: 'a', text: "Yes — if Client A is well known, it's helpful, credible context.", score: 'poor',
          reaction: { s: 'david', t: "The moment you confirm Client A is a client, you've breached their confidentiality — famous or not." },
          feedback: "Revealing that Client A is a client, and describing their work, breaches Client A's confidentiality. Each client relationship is walled off from all others." },
        { id: 'b', text: "No — each client relationship is confidential; I build credibility with general expertise and anonymised examples.", score: 'best',
          reaction: { s: 'david', t: "Exactly. Anonymised examples and genuine expertise win trust without selling out another client. That's the professional way." },
          feedback: "Correct. Client relationships are confidential and walled off. Build credibility with general expertise and anonymised examples — never by naming other clients." },
        { id: 'c', text: "Yes, as long as I don't describe the specific work.", score: 'poor',
          reaction: { s: 'david', t: "Just confirming they're a client is already the breach. You don't need to describe the work to cross the line." },
          feedback: "Merely confirming Client A is a client is itself a breach — you don't have to describe the work to disclose the relationship." },
      ],
    },
    {
      id: 's3', act: 'Act 3 — The Out-of-Scope Discovery', title: 'Document, stop, escalate',
      setting: "Wednesday, 11:50 AM. During your authorised assessment for Client A, you find evidence suggesting Client A was already breached months ago by an unknown attacker — outside your engagement scope.",
      dialogue: [
        { s: 'auditor', t: "(Hannah) This is genuinely serious and genuinely delicate — there are contractual and possibly legal threads here you can't see from where you sit." },
        { s: 'priya', t: "You've found signs of a prior, unknown breach. It matters, and it's outside scope. What do you do?" },
      ],
      prompt: "Priya asks: \"How do you handle the out-of-scope breach evidence?\"",
      options: [
        { id: 'a', text: "Investigate further so I can give the client a complete picture.", score: 'poor',
          reaction: { s: 'priya', t: "No — even to help, digging in unilaterally goes beyond scope and can create legal and contractual problems. Document, stop, escalate." },
          feedback: "Investigating further unilaterally — even to help — exceeds scope and risks legal and contractual problems. The rule is document, stop, escalate." },
        { id: 'b', text: "Document what I observed, stop, and escalate immediately to my lead.", score: 'best',
          reaction: { s: 'priya', t: "Exactly. Capture what you saw, don't go further, and hand it to the lead, who'll weigh the engagement terms and legal obligations. Perfect." },
          feedback: "Correct. Document, stop, and escalate to your lead immediately. This needs careful handling within the engagement terms and possible legal obligations — your lead determines the next step." },
        { id: 'c', text: "Tell the client directly on the next call so they can act fast.", score: 'poor',
          reaction: { s: 'priya', t: "Disclosing directly without coordination can create real problems — the client relationship and legal implications have to be managed through the lead first." },
          feedback: "Direct disclosure without coordination can backfire — the client relationship and legal implications must be managed through your lead, who will handle communication." },
      ],
    },
    {
      id: 's4', act: 'Act 4 — The Vendor Hand-off', title: 'Bind third parties first',
      setting: "Thursday, 3:30 PM. A subcontractor needs some client data to do part of the work. They're helpful and trustworthy, and they're ready to start right away.",
      dialogue: [
        { s: 'elena', t: "Trustworthy is not the same as bound. Before any confidential data leaves our hands, the receiving party has to be under proper obligations." },
        { s: 'elena', t: "The subcontractor's keen to start. What has to be true before you share client data with them?" },
      ],
      prompt: "Elena asks: \"What's required before sharing client data with the subcontractor?\"",
      options: [
        { id: 'a', text: "A verbal promise to keep it confidential is enough since they're trusted.", score: 'poor',
          reaction: { s: 'elena', t: "A handshake isn't protection. They must be bound by appropriate confidentiality terms before anything is shared." },
          feedback: "A verbal promise isn't sufficient. Third parties must be bound by appropriate confidentiality terms before receiving any confidential information." },
        { id: 'b', text: "They must be bound by appropriate confidentiality terms first, and I share only what's strictly necessary.", score: 'best',
          reaction: { s: 'elena', t: "Exactly. Bind them, then share the minimum. And if anything about their data handling worries you, raise it." },
          feedback: "Correct. Ensure third parties are bound by appropriate confidentiality terms before sharing, and share only what's necessary for their role. Raise any data-handling concerns." },
        { id: 'c', text: "Share it now to keep things moving, and get the paperwork signed afterwards.", score: 'poor',
          reaction: { s: 'elena', t: "Sharing first and papering it later means the data was unprotected at the moment it mattered. Bind them before, not after." },
          feedback: "Sharing before the terms are in place leaves the data unprotected at the critical moment. The agreement must precede the disclosure, not follow it." },
      ],
    },
  ],
  debrief: {
    title: 'Debrief — Trusted access, handled with care',
    lines: [
      { s: 'marcus', t: "You stayed inside scope under temptation, which is the heart of engagement discipline." },
      { s: 'david', t: "And you kept clients walled off — no name-dropping, ever. That's how every client knows their relationship with us is sealed." },
      { s: 'auditor', t: "(Hannah) The out-of-scope discovery is the hardest call in this module, and you made exactly the right one: document, stop, escalate." },
    ],
    takeaways: [
      'Privileged access is for the agreed scope only — never explore beyond it, not even read-only.',
      'Each client relationship is confidential and walled off — never reveal one client to another.',
      'Out-of-scope discoveries: document, stop, escalate — don\u2019t act unilaterally or disclose directly.',
      'Third parties must be bound by appropriate confidentiality terms before receiving any data.',
    ],
  },
};

/* ════════════════════════════════════════════════════════════════════════════
 * MODULE 11 — Putting It Together & Your Commitment
 * ══════════════════════════════════════════════════════════════════════════ */
const m11 = {
  meta: {
    module: 11,
    kicker: 'Interactive Scenario',
    title: 'Everything At Once',
    player: 'You — Security Analyst, onboarding complete',
    summary:
      "Real situations don't respect module boundaries. This capstone throws layered problems at you — IP, " +
      "confidentiality, phishing, and device rules tangled together — then closes with the commitment that " +
      "finalises your onboarding. Spot every issue, respond to all of them, and finish.",
    cast: ['elena', 'marcus', 'priya', 'david', 'auditor'],
  },
  scenes: [
    {
      id: 's1', act: 'Act 1 — The Combined Test', title: 'Four problems in one email',
      setting: "Monday, 4:00 PM. A 'client' emails asking you to send a lab walkthrough another client commissioned. It's marked urgent, the sender address looks almost right — and you're at a café on your personal laptop because your VM is slow.",
      dialogue: [
        { s: 'priya', t: "This is the one that ties the whole course together. There isn't a single issue here — there are four, stacked on top of each other." },
        { s: 'priya', t: "Take a breath and look at all of it: the request, the sender, the device, the location. What do you do?" },
      ],
      prompt: "Priya asks: \"How do you handle the urgent request for another client's lab walkthrough?\"",
      options: [
        { id: 'a', text: "Send the walkthrough — the client's asking and it's urgent.", score: 'poor',
          reaction: { s: 'priya', t: "That single action trips four wires: it's IP and another client's work, it confirms that client exists, the sender's likely BEC, and you're on a personal laptop in public." },
          feedback: "Four breaches at once: lab content is company IP / another client's work (M3, M10); revealing it exists breaches confidentiality (M2, M10); the off sender suggests BEC (M7); and you're on a personal device in public (M5, M6)." },
        { id: 'b', text: "Don't respond. Verify the sender via a known channel, report the suspicious email, and return to my company VM in a private location — and don't share another client's work regardless.", score: 'best',
          reaction: { s: 'priya', t: "That's it — all four handled at once. Don't share the IP, verify and report the email, get off the personal laptop, move somewhere private. This is what the whole course was for." },
          feedback: "Correct. All four issues addressed: don't share the IP/client work; verify and report the suspicious email; stop using the personal laptop; move to a private location. That's applying every module together." },
        { id: 'c', text: "Reply to confirm it's legitimate, then send it if it checks out.", score: 'poor',
          reaction: { s: 'priya', t: "Replying talks to a possible attacker — and even if it were genuine, you still can't share another client's commissioned work without authorisation." },
          feedback: "Replying communicates with a possible attacker, and even if verified, you still can't share another client's commissioned work without authorisation. Multiple issues remain unaddressed." },
      ],
    },
    {
      id: 's2', act: 'Act 2 — When You\u2019re Not Sure', title: 'Asking beats guessing',
      setting: "Tuesday, 10:00 AM. A situation comes up that doesn't cleanly match anything in the course. You could make a reasonable assumption and proceed, or pause and check.",
      dialogue: [
        { s: 'elena', t: "Here's the truth nobody tells new hires: you'll regularly hit situations the modules don't spell out exactly. What matters is your default when that happens." },
        { s: 'elena', t: "You're genuinely unsure about an obligation and there's mild pressure to just get on with it. What's the right default?" },
      ],
      prompt: "Elena asks: \"When you're unsure about an obligation, what do you do?\"",
      options: [
        { id: 'a', text: "Make a reasonable assumption and proceed — over-asking looks unconfident.", score: 'poor',
          reaction: { s: 'elena', t: "That's how well-meaning people cause breaches. Nobody here thinks less of you for checking — quite the opposite." },
          feedback: "Assuming when unsure is exactly how inadvertent breaches happen. Asking is always better than guessing." },
        { id: 'b', text: "Ask — check with my lead or consult the policy; asking is always better than guessing.", score: 'best',
          reaction: { s: 'elena', t: "Exactly. The policy is the authoritative source, your lead and the security team are there to help. Asking is a strength." },
          feedback: "Correct. Asking is always better than guessing. The policy is authoritative, and your lead and the IT/security team are there to help — checking is a strength, not a weakness." },
        { id: 'c', text: "Default to doing nothing at all, forever, to be safe.", score: 'ok',
          reaction: { s: 'elena', t: "Caution's good, but freezing isn't a plan — you still need to resolve it. Ask, get the answer, then act correctly." },
          feedback: "Refusing to act isn't a real resolution — work can't just stall. The right move is to ask, get clarity, then proceed correctly." },
      ],
    },
    {
      id: 's3', act: 'Act 3 — The Commitment', title: 'What you\u2019re signing means something',
      setting: "Wednesday, 2:00 PM. You've reached the end of the course. There's an acknowledgement to sign and the Employee Confidentiality & IP Deed to commit to.",
      dialogue: [
        { s: 'david', t: "Some people click through this part on autopilot. I'd ask you not to — because it's both a cultural promise and a genuine legal record." },
        { s: 'david', t: "How should you think about the acknowledgements and the IP Deed you're about to sign?" },
      ],
      prompt: "David asks: \"What are the final acknowledgements and the IP Deed, really?\"",
      options: [
        { id: 'a', text: "A formality to tick off so onboarding shows as complete.", score: 'poor',
          reaction: { s: 'david', t: "It's far more than a tick-box. These are legal commitments that protect you and the firm, and parts of them outlast your employment." },
          feedback: "These aren't formalities. They're legal records confirming you've read, understood, and agree to comply — and key obligations (confidentiality, IP) survive your employment." },
        { id: 'b', text: "Both a cultural commitment and a legal record that protect me and the company — to be taken seriously, with obligations that continue after I leave.", score: 'best',
          reaction: { s: 'david', t: "Exactly. Read it, mean it, sign it. That mindset is what turns a course into a culture." },
          feedback: "Correct. The acknowledgement and IP Deed are cultural commitments and legal records that protect you and the firm — taken seriously, with obligations that continue after employment ends." },
        { id: 'c', text: "Only relevant if I end up working with Highly Confidential data.", score: 'poor',
          reaction: { s: 'david', t: "They apply to everyone, regardless of what data you touch. Confidentiality and IP obligations are universal here." },
          feedback: "They apply to everyone, not just those handling the top tier. Confidentiality and IP obligations are universal and don't depend on your data access." },
      ],
    },
    {
      id: 's4', act: 'Act 4 — Know Who To Call', title: 'Before you need them',
      setting: "Thursday, 9:00 AM. Your last task: make sure you know who to contact for different kinds of issues — before a real one lands.",
      dialogue: [
        { s: 'auditor', t: "(Hannah) The best-prepared people I assess have the right contact in mind before the incident, not while they're panicking through it." },
        { s: 'marcus', t: "Last question of the whole course: when should you work out who handles incidents, privacy, IP, and HR matters?" },
      ],
      prompt: "Marcus asks: \"When should you know who to contact for security, privacy, IP, and HR issues?\"",
      options: [
        { id: 'a', text: "When an issue actually comes up — no point learning it before I need it.", score: 'poor',
          reaction: { s: 'marcus', t: "In a real incident, every minute spent figuring out who to call is a minute lost. Know it in advance." },
          feedback: "Learning contacts mid-incident wastes critical time. Know who to contact before you need them, so you can act immediately." },
        { id: 'b', text: "Now — know the contacts before I need them, so I can respond fast when something happens.", score: 'best',
          reaction: { s: 'marcus', t: "Exactly. They're in your onboarding docs. Bookmark them today. That's you, fully ready." },
          feedback: "Correct. Know the right contacts for incidents, privacy, IP, and HR before you need them — they're in your onboarding documentation. Preparation is what makes fast response possible." },
        { id: 'c', text: "It's fine — I'll just ask whoever's nearest at the time.", score: 'ok',
          reaction: { s: 'marcus', t: "Asking is better than freezing, but 'whoever's nearest' may send you the wrong way on something time-critical. Know the right contacts up front." },
          feedback: "Asking around beats doing nothing, but the nearest person may not be the right one for a time-critical issue. Know the correct contacts in advance." },
      ],
    },
  ],
  debrief: {
    title: 'Debrief — Onboarding complete',
    lines: [
      { s: 'priya', t: "The combined test is the real one, and you spotted all four issues and handled them together. That's the whole point of the course." },
      { s: 'elena', t: "You also locked in the two habits that outlast any single rule: ask when unsure, and take your commitments seriously." },
      { s: 'david', t: "That's it — you're ready. Welcome to Security Impossible, properly. We're glad you're here." },
    ],
    takeaways: [
      'Real situations combine multiple modules — spot and respond to every issue at once.',
      'When unsure, asking is always better than guessing — the policy and your lead are there to help.',
      'Your acknowledgements and the IP Deed are cultural commitments and legal records — obligations continue after you leave.',
      'Know who to contact for incidents, privacy, IP, and HR matters before you need them.',
    ],
  },
};

/* ── Assembled registry ──────────────────────────────────────────────────── */
export const SCENARIOS = {
  1: m1, 2: m2, 3: m3, 4: m4, 5: m5, 6: m6,
  7: m7, 8: m8, 9: m9, 10: m10, 11: m11,
};

export function getScenario(moduleId) {
  return SCENARIOS[moduleId] || null;
}
