// ── Scenario registry — modules 5 through 8 ──────────────────────────────────
// See scenarios_part1.js for the object shape and conventions.

/* ════════════════════════════════════════════════════════════════════════════
 * MODULE 5 — Data Classification & Handling
 * ══════════════════════════════════════════════════════════════════════════ */
const m5 = {
  meta: {
    module: 5,
    kicker: 'Interactive Scenario',
    title: 'Four Tiers, One Wrong Move',
    player: 'You — Security Analyst, classifying data',
    summary:
      "Everything we hold sits in one of four tiers — Public, Internal, Confidential, Highly Confidential — and the " +
      "tier dictates how you handle it. Across four moments you'll classify correctly, keep data on approved systems, " +
      "and avoid the convenient shortcuts that quietly break the rules.",
    cast: ['elena', 'marcus', 'priya', 'david', 'auditor'],
  },
  scenes: [
    {
      id: 's1', act: 'Act 1 — Name the Tier', title: 'Classifying personal information',
      setting: "Monday, 10:00 AM. You're sorting files into the right storage locations. One is a list of platform learners with full names, emails, and dates of birth.",
      dialogue: [
        { s: 'elena', t: "Classification drives everything else — encryption, access, where it can live. So getting the tier right is the first decision, not an afterthought." },
        { s: 'elena', t: "That learner list is personal information. In our four-tier model, what tier does PII fall into?" },
      ],
      prompt: "Elena asks: \"What classification applies to a file of personal information (PII)?\"",
      options: [
        { id: 'a', text: "Internal — it's business data, kept inside the company.", score: 'poor',
          reaction: { s: 'elena', t: "Too low. PII gets the strongest tier we have, precisely because the harm if it leaks is so high." },
          feedback: "Too low a tier. All personal information is Highly Confidential in our model — the highest protection, with encryption mandatory." },
        { id: 'b', text: "Highly Confidential — all PII gets the highest protection, with encryption mandatory.", score: 'best',
          reaction: { s: 'elena', t: "Exactly. PII is always Highly Confidential. Encryption isn't optional and access is tightly controlled." },
          feedback: "Correct. All personal information is classified Highly Confidential — the highest tier, where encryption is mandatory and access is strictly limited." },
        { id: 'c', text: "Confidential — it's sensitive but not the very top tier.", score: 'ok',
          reaction: { s: 'elena', t: "Close, and a lot safer than 'Internal' — but PII specifically sits one tier higher, at Highly Confidential." },
          feedback: "Closer, but PII specifically is Highly Confidential, not Confidential. Personal information always gets the top tier and mandatory encryption." },
      ],
    },
    {
      id: 's2', act: 'Act 2 — The Quick Share', title: 'Approved channels only',
      setting: "Tuesday, 1:00 PM. You need to get a Confidential client report to a teammate fast. The quickest path is to drop it in a personal Dropbox link and message them.",
      dialogue: [
        { s: 'marcus', t: "I get the instinct — the company tools feel slower. But the moment Confidential data lands in personal cloud, it's outside everything we control." },
        { s: 'marcus', t: "How do you get that report to your teammate?" },
      ],
      prompt: "Marcus asks: \"What's the right way to share the Confidential report internally?\"",
      options: [
        { id: 'a', text: "Personal Dropbox link — it's fast and I'll delete it after.", score: 'poor',
          reaction: { s: 'marcus', t: "That's exactly the move that ends up in an audit finding. Personal cloud is outside our controls, full stop." },
          feedback: "Confidential data must stay on approved company systems. Personal cloud storage is uncontrolled — fast isn't a justification." },
        { id: 'b', text: "Share it through approved company systems with appropriate access controls.", score: 'best',
          reaction: { s: 'marcus', t: "That's it. Company systems, proper access. Slightly slower, completely defensible." },
          feedback: "Correct. All data — especially Confidential — must be shared through approved company systems with proper access controls, never personal cloud or email." },
        { id: 'c', text: "Email it to my personal account first, then forward from there.", score: 'poor',
          reaction: { s: 'marcus', t: "Routing it through your personal email is the same breach with an extra step. The data still leaves the controlled environment." },
          feedback: "Routing through personal email still moves Confidential data off approved systems — it's the same breach with extra steps." },
      ],
    },
    {
      id: 's3', act: 'Act 3 — The Mislabelled File', title: 'When the tier looks wrong',
      setting: "Wednesday, 11:40 AM. You open a shared file marked 'Internal' and realise it actually contains client credentials and a network diagram — clearly Confidential or higher, sitting in a broadly-accessible folder.",
      dialogue: [
        { s: 'auditor', t: "(Hannah, reviewing access logs nearby) This is a classic finding — sensitive content under a too-low label, in a folder half the company can open." },
        { s: 'priya', t: "You've spotted a real exposure. What do you actually do about it?" },
      ],
      prompt: "Priya asks: \"You found Confidential content mislabelled 'Internal' in an open folder. Now what?\"",
      options: [
        { id: 'a', text: "Leave it — it's not my file and not my job to reclassify other people's work.", score: 'poor',
          reaction: { s: 'priya', t: "Spotting it makes it your business. Walking past a known exposure is itself a failure." },
          feedback: "Knowing about an exposure and ignoring it is a failure in its own right. Mishandled classification is everyone's responsibility to flag." },
        { id: 'b', text: "Flag it to the file owner and my lead so it's reclassified and access is restricted.", score: 'best',
          reaction: { s: 'priya', t: "Exactly. Raise it, get it reclassified, lock down access. That's exactly the instinct an auditor wants to see." },
          feedback: "Correct. Flag it to the owner and your lead so the file is reclassified to its true tier and access is restricted. Don't silently work around it." },
        { id: 'c', text: "Quietly move it to a private folder myself and say nothing.", score: 'ok',
          reaction: { s: 'priya', t: "Your heart's in the right place, but acting alone risks breaking access others legitimately need — and nobody learns the label was wrong. Escalate it." },
          feedback: "Acting unilaterally can disrupt legitimate access and leaves the root cause (a wrong label, wrong process) unaddressed. Escalate so it's handled properly." },
      ],
    },
    {
      id: 's4', act: 'Act 4 — The Disposal Question', title: 'End of the data lifecycle',
      setting: "Thursday, 3:15 PM. An engagement has wrapped. You've got local working copies of the client's Highly Confidential data and you're deciding what to do with them.",
      dialogue: [
        { s: 'david', t: "People focus on protecting data while they're using it and forget the last step. Disposal is part of the lifecycle, and it's where stale copies come back to bite us." },
        { s: 'david', t: "The engagement's done. What happens to your local working copies of that Highly Confidential data?" },
      ],
      prompt: "David asks: \"What do you do with the leftover client data after the engagement ends?\"",
      options: [
        { id: 'a', text: "Keep it archived locally in case the client comes back with questions.", score: 'poor',
          reaction: { s: 'david', t: "Holding data 'just in case' past its purpose is exactly what we're not allowed to do. Every retained copy is live risk." },
          feedback: "Retaining data beyond its purpose breaches the handling rules — and each stale copy is ongoing risk. Don't keep working copies 'just in case'." },
        { id: 'b', text: "Securely dispose of the working copies per policy, keeping only what retention rules require, in approved storage.", score: 'best',
          reaction: { s: 'david', t: "Exactly. Securely dispose of what you don't need, keep only what's required, and only in approved storage. Clean close-out." },
          feedback: "Correct. Securely dispose of data when no longer needed; retain only what policy requires, and only in approved systems. Disposal is part of the lifecycle." },
        { id: 'c', text: "Drag them to the desktop trash and empty it.", score: 'poor',
          reaction: { s: 'david', t: "Emptying the trash isn't secure disposal for Highly Confidential data — and it sidesteps the retention rules entirely." },
          feedback: "Emptying the trash isn't secure disposal for Highly Confidential data, and it skips the retention check. Follow the secure disposal process." },
      ],
    },
  ],
  debrief: {
    title: 'Debrief — The tier decides everything',
    lines: [
      { s: 'elena', t: "You nailed the chain: classify correctly, keep it on approved systems, fix exposures, and dispose properly at the end." },
      { s: 'marcus', t: "The personal-cloud shortcut is the one I see most. It always feels harmless and it never is." },
      { s: 'priya', t: "And spotting a mislabelled file and raising it — that's the difference between someone who follows rules and someone who protects the firm." },
    ],
    takeaways: [
      'Four tiers: Public, Internal, Confidential, Highly Confidential — the tier dictates handling.',
      'All personal information (PII) is Highly Confidential, with encryption mandatory.',
      'Keep all data on approved company systems — no personal devices, email, or cloud.',
      'Dispose of data securely when no longer needed; retention and disposal are part of the lifecycle.',
    ],
  },
};

/* ════════════════════════════════════════════════════════════════════════════
 * MODULE 6 — Asset Management & Secure Workplace Practices
 * ══════════════════════════════════════════════════════════════════════════ */
const m6 = {
  meta: {
    module: 6,
    kicker: 'Interactive Scenario',
    title: 'The Device Line',
    player: 'You — Security Analyst, working anywhere',
    summary:
      "Company devices, company systems, no exceptions — it's one of the strictest rules and the one new hires trip " +
      "over first. Across four moments you'll resist convenient workarounds, understand why monitoring protects you, " +
      "and respond fast when a device goes missing.",
    cast: ['elena', 'marcus', 'priya', 'david', 'auditor'],
  },
  scenes: [
    {
      id: 's1', act: 'Act 1 — The Fast Laptop', title: 'No personal devices, ever',
      setting: "Monday, 7:30 PM. Your company VM is crawling and you're on a deadline. Your personal laptop is far faster, and copying the project files over would let you finish tonight.",
      dialogue: [
        { s: 'marcus', t: "I know the VM's frustrating right now — I've logged the performance issue. But I need to head off the obvious workaround before you reach for it." },
        { s: 'marcus', t: "Copying company project files to your personal laptop 'just for tonight' — walk me through whether that's okay." },
      ],
      prompt: "Marcus asks: \"Can you copy the files to your personal laptop to finish tonight?\"",
      options: [
        { id: 'a', text: "Just for tonight, and I'll delete them straight after.", score: 'poor',
          reaction: { s: 'marcus', t: "No — and 'just tonight' is how every one of these starts. Using a personal device for company work is a strict breach, full stop." },
          feedback: "Absolutely not. Using a personal device for company work and transferring company data to it are both strict breaches — no deadline creates an exception." },
        { id: 'b', text: "No — report the VM issue and work within the company environment until it's fixed.", score: 'best',
          reaction: { s: 'marcus', t: "Exactly. The deadline's real, but the rule is absolute. We'll sort the VM; we don't sort it by breaking the perimeter." },
          feedback: "Correct. No business urgency justifies moving company data to a personal device. Report the issue and work within the company environment — the rule is absolute." },
        { id: 'c', text: "Use the personal laptop but connect through the company VPN.", score: 'poor',
          reaction: { s: 'marcus', t: "VPN protects the network path, not the device. The data would still be sitting on an uncontrolled machine." },
          feedback: "A VPN secures network traffic, not the device. The data would still live on an uncontrolled personal machine — that's the breach." },
      ],
    },
    {
      id: 's2', act: 'Act 2 — "Can My Manager Approve It?"', title: 'Some rules can\u2019t be waived',
      setting: "Tuesday, 9:00 AM. Still blocked by the slow VM, you wonder whether your manager could just sign off on the personal-laptop workaround as a one-time exception.",
      dialogue: [
        { s: 'elena', t: "It's a reasonable question — normally a manager can approve exceptions. But this one's different, and it's worth understanding why." },
        { s: 'elena', t: "Can your manager authorise you to use a personal device for company work, even once?" },
      ],
      prompt: "Elena asks: \"Could your manager approve the personal-laptop workaround as a one-off?\"",
      options: [
        { id: 'a', text: "Yes — managers can approve reasonable exceptions for their team.", score: 'poor',
          reaction: { s: 'elena', t: "Not this rule. The personal-device prohibition isn't a manager's to waive — it's an absolute control." },
          feedback: "A manager can't grant permission to breach the Asset Management Policy. The personal-device prohibition is non-negotiable and can't be waived informally." },
        { id: 'b', text: "No — the personal-device prohibition is absolute and can't be waived informally by a manager.", score: 'best',
          reaction: { s: 'elena', t: "Right. Some controls sit above the line where local discretion applies. This is one of them." },
          feedback: "Correct. This prohibition is absolute. It exists precisely so that no local pressure or convenience can erode it — a manager can't sign it away." },
        { id: 'c', text: "Yes, if they put the approval in writing.", score: 'poor',
          reaction: { s: 'elena', t: "Writing it down doesn't grant an authority that doesn't exist. The rule can't be waived at this level, on paper or otherwise." },
          feedback: "Documenting it doesn't create authority that isn't there. The rule can't be waived at manager level, written or not." },
      ],
    },
    {
      id: 's3', act: 'Act 3 — Why It\u2019s Monitored', title: 'Monitoring protects you too',
      setting: "Wednesday, 2:00 PM. A new teammate grumbles that company monitoring of devices feels like the company doesn't trust staff. You're asked how you'd explain it.",
      dialogue: [
        { s: 'auditor', t: "(Hannah) I hear the 'they don't trust us' line in every workforce I assess. The framing is almost always wrong." },
        { s: 'priya', t: "How would you explain why we monitor company systems — in a way that's actually accurate?" },
      ],
      prompt: "Priya asks: \"What's the real reason company systems are monitored?\"",
      options: [
        { id: 'a', text: "It's mainly to check whether employees are being productive.", score: 'poor',
          reaction: { s: 'priya', t: "That's the cynical read, and it's not what this is for. Monitoring here is a security control, not a productivity tracker." },
          feedback: "Monitoring isn't a productivity tool. It exists to detect threats, prevent data loss, and protect both the company and its people." },
        { id: 'b', text: "It detects threats, prevents data loss, and protects both the company and employees — including proving what happened if you're ever wrongly accused.", score: 'best',
          reaction: { s: 'priya', t: "Exactly. If your account's compromised, monitoring is how we catch it fast — and if you're falsely blamed, it's your evidence. It protects you." },
          feedback: "Correct. Monitoring detects threats and data loss, and it protects you: it catches account compromise quickly and provides the record that clears you if you're wrongly accused." },
        { id: 'c', text: "It's a legal requirement the company has no choice about.", score: 'poor',
          reaction: { s: 'priya', t: "It's a deliberate security control, not just a box-tick. Framing it as 'we have to' misses why it genuinely helps." },
          feedback: "It's a chosen security control, not merely a legal obligation. The point is active protection — detecting threats and safeguarding staff and data." },
      ],
    },
    {
      id: 's4', act: 'Act 4 — The Missing Phone', title: 'Speed limits the damage',
      setting: "Thursday, 6:10 PM. On the train home you realise your company phone — with email and access apps — is gone. Maybe left at the café, maybe taken.",
      dialogue: [
        { s: 'david', t: "First: it happens, and you're not in trouble for losing a device. What matters now is how fast you act." },
        { s: 'david', t: "Your company phone with access to email and apps is missing. What do you do?" },
      ],
      prompt: "David asks: \"What's your immediate move?\"",
      options: [
        { id: 'a', text: "Wait until tomorrow to see if the café found it before raising anything.", score: 'poor',
          reaction: { s: 'david', t: "Every hour it's unreported is an hour someone could be using it. Don't wait on a maybe." },
          feedback: "Waiting gives an attacker time. A lost device must be reported immediately so access can be locked down — speed limits the damage." },
        { id: 'b', text: "Report it immediately to IT and my lead so access can be locked down right away.", score: 'best',
          reaction: { s: 'david', t: "Exactly. Report now, let IT revoke and wipe. If it turns up at the café tomorrow, great — but we don't gamble on that." },
          feedback: "Correct. Report lost or stolen devices immediately to IT and your lead. Fast reporting lets the team revoke access and wipe the device before harm is done." },
        { id: 'c', text: "Change my passwords on a personal device first, then report it later.", score: 'ok',
          reaction: { s: 'david', t: "Resetting credentials isn't bad — but doing it on a personal device and delaying the report both work against us. Report first; let IT lead the response." },
          feedback: "Changing passwords helps, but doing it on a personal device and delaying the report are both problems. Report immediately and let IT coordinate the full response." },
      ],
    },
  ],
  debrief: {
    title: 'Debrief — The perimeter is wherever you are',
    lines: [
      { s: 'marcus', t: "You held the device line under deadline pressure, which is the real test. Company kit, company systems, every time." },
      { s: 'elena', t: "And you understood that some rules sit above local discretion — no manager, no paperwork waives them." },
      { s: 'david', t: "Lose a device someday? You will, everyone does. Just do what you said: report it the same minute." },
    ],
    takeaways: [
      'No personal devices for company work — ever; never transfer company data to personal devices, email, or cloud.',
      'The personal-device prohibition is absolute and cannot be waived by a manager.',
      'Monitoring isn\u2019t distrust — it detects threats, prevents data loss, and protects you too.',
      'Report lost or stolen devices immediately — speed limits the damage.',
    ],
  },
};

/* ════════════════════════════════════════════════════════════════════════════
 * MODULE 7 — Recognising & Responding to Threats
 * ══════════════════════════════════════════════════════════════════════════ */
const m7 = {
  meta: {
    module: 7,
    kicker: 'Interactive Scenario',
    title: 'The Urgent Email',
    player: 'You — Security Analyst, on the front line',
    summary:
      "We're targeted precisely because compromising us can compromise our clients. Across four moments you'll spot " +
      "social-engineering red flags, verify through the right channel, and — most importantly — learn that reporting " +
      "fast is always rewarded, never punished.",
    cast: ['elena', 'marcus', 'priya', 'david', 'auditor'],
  },
  scenes: [
    {
      id: 's1', act: 'Act 1 — Why Us?', title: 'The threat model',
      setting: "Monday, 9:00 AM. A teammate wonders aloud why a mid-sized security firm would attract sophisticated attackers at all. Marcus turns it into a teaching moment.",
      dialogue: [
        { s: 'marcus', t: "Fair question, and the answer shapes how seriously you take everything else in this module." },
        { s: 'marcus', t: "Why would an attacker put real effort into targeting us specifically, rather than a random company our size?" },
      ],
      prompt: "Marcus asks: \"Why are security firms like us specifically targeted?\"",
      options: [
        { id: 'a', text: "Because we hold more data than a typical company our size.", score: 'poor',
          reaction: { s: 'marcus', t: "It's not the volume — it's the leverage. Think about what access to us could unlock." },
          feedback: "It's not about data volume. We're targeted because compromising us can be a path into our clients' systems — that leverage is what's valuable." },
        { id: 'b', text: "Because compromising us can be a path to compromising our clients — one breach can reach many.", score: 'best',
          reaction: { s: 'marcus', t: "Exactly. We're a supply-chain shortcut to multiple organisations. That's why you, personally, may be targeted with real sophistication." },
          feedback: "Correct. As a security firm we may hold access and insight into clients' environments — breaching us can compromise multiple clients at once. Assume you may be personally targeted." },
        { id: 'c', text: "Because security staff are more careless than average.", score: 'poor',
          reaction: { s: 'marcus', t: "Not it. The motivation is the leverage over clients, not an assumption about our habits." },
          feedback: "The driver is leverage over clients, not staff carelessness. We're a high-value target because of what compromising us could unlock downstream." },
      ],
    },
    {
      id: 's2', act: 'Act 2 — The CEO Gift Card', title: 'Spotting business email compromise',
      setting: "Tuesday, 11:20 AM. An email that looks like it's from the CEO, marked URGENT, asks you to buy gift cards / send a client list in the next 30 minutes because they're 'in a meeting and can't talk.' The sender address is subtly off.",
      dialogue: [
        { s: 'priya', t: "Read that one out to yourself slowly. Urgency, a request to bypass normal process, can't-talk-right-now, and a sender address that's almost — but not quite — right." },
        { s: 'priya', t: "That's a textbook pattern. What do you do?" },
      ],
      prompt: "Priya asks: \"How do you respond to the 'urgent CEO' email?\"",
      options: [
        { id: 'a', text: "Act fast — the CEO's busy and it's clearly urgent.", score: 'poor',
          reaction: { s: 'priya', t: "That's exactly what the attacker is counting on. Urgency plus a bypass request is the red flag, not a reason to hurry." },
          feedback: "This is classic business email compromise. Manufactured urgency and a request to bypass process are the warning signs — the off sender address confirms it. Don't act." },
        { id: 'b', text: "Don't act. Verify via a separate known channel (call the CEO on a number I already have) and report the email to IT.", score: 'best',
          reaction: { s: 'priya', t: "Exactly. Independent verification, then report regardless. Never use contact details from the suspicious message itself." },
          feedback: "Correct. Verify through a separate, known channel — never one supplied by the suspicious message — and report it to IT regardless of the outcome." },
        { id: 'c', text: "Reply to the email asking them to confirm it's really them.", score: 'poor',
          reaction: { s: 'priya', t: "Replying just opens a conversation with the attacker. Verify on a channel they don't control." },
          feedback: "Replying communicates with the attacker and proves nothing. Verify on a completely separate, known channel instead." },
      ],
    },
    {
      id: 's3', act: 'Act 3 — The Click', title: 'After a mistake, speed beats silence',
      setting: "Wednesday, 3:40 PM. You clicked a link in an email before realising it was likely phishing. A login-looking page flashed up. Your heart sinks and a small voice says 'maybe just say nothing.'",
      dialogue: [
        { s: 'auditor', t: "(Hannah) The thing that turns a click into a catastrophe is almost never the click. It's the silence afterwards." },
        { s: 'elena', t: "Be honest about the instinct to stay quiet — then tell me what you'll actually do." },
      ],
      prompt: "Elena asks: \"You clicked a likely phishing link. What now?\"",
      options: [
        { id: 'a', text: "Stay quiet — nothing obviously bad happened, and reporting might get me in trouble.", score: 'poor',
          reaction: { s: 'elena', t: "You will never be in trouble for reporting honestly. You could cause real harm by staying silent. Please don't carry that fear." },
          feedback: "Silence is the real danger. You'll never be punished for honest, fast reporting — but staying quiet lets a compromise spread unchecked." },
        { id: 'b', text: "Report it immediately to IT / the incident response team and let them assess.", score: 'best',
          reaction: { s: 'elena', t: "Exactly. Report fast, let the team contain it. That's not a black mark — it's exactly what a good colleague does." },
          feedback: "Correct. Report immediately so the IR team can contain any compromise. You don't need to diagnose it yourself — fast reporting is always the right call and is never punished." },
        { id: 'c', text: "Run an antivirus scan myself first, then decide whether it's worth reporting.", score: 'poor',
          reaction: { s: 'elena', t: "Don't try to triage it solo — that just burns time. Report first; the team has tools and context you don't." },
          feedback: "Self-diagnosing wastes critical containment time. Report immediately and let the IR team assess — don't gate reporting on your own investigation." },
      ],
    },
    {
      id: 's4', act: 'Act 4 — The Helpful Caller', title: 'Phone-based social engineering',
      setting: "Thursday, 10:30 AM. Someone calls claiming to be from 'IT support,' says there's an urgent account issue, and asks you to read back a verification code that just arrived on your phone.",
      dialogue: [
        { s: 'david', t: "Same playbook as the email, different channel. Urgency, authority, and a push to hand over something you should never share." },
        { s: 'david', t: "They want you to read out the code from your phone. What do you do?" },
      ],
      prompt: "David asks: \"How do you handle the 'IT support' caller asking for your code?\"",
      options: [
        { id: 'a', text: "Read it back — it's IT and the account issue sounds urgent.", score: 'poor',
          reaction: { s: 'david', t: "That code is the key to your account. Real IT will never ask you to read it out. That's the whole scam." },
          feedback: "Never share a verification code — legitimate IT won't ask for it. Urgency plus a request for your code is a social-engineering attack." },
        { id: 'b', text: "Refuse to share the code, hang up, and contact IT through a known internal channel to verify and report.", score: 'best',
          reaction: { s: 'david', t: "Exactly. Don't share, don't trust the inbound call, verify on a channel you control, and report it. Perfect." },
          feedback: "Correct. Never read out codes; hang up and verify through a known internal channel, then report. Don't trust the legitimacy of an unsolicited inbound call." },
        { id: 'c', text: "Ask them a few questions to test if they're really from IT, then decide.", score: 'ok',
          reaction: { s: 'david', t: "A determined attacker can answer screening questions. Don't try to out-interview them — just refuse and verify independently." },
          feedback: "Quizzing the caller is risky — attackers prepare for it. Don't try to vet them on the call; refuse, hang up, and verify through a channel you control." },
      ],
    },
  ],
  debrief: {
    title: 'Debrief — Slow down, verify, report',
    lines: [
      { s: 'marcus', t: "You understood why we're a target, then spotted the same manipulation across email and phone. Urgency-to-bypass is the signature." },
      { s: 'elena', t: "And the click scenario — that's the one that matters most culturally. Fast, honest reporting, every time, no fear." },
      { s: 'priya', t: "Verify on a channel the attacker doesn't control. If you remember one habit from this module, make it that." },
    ],
    takeaways: [
      'We\u2019re targeted because compromising us can compromise our clients — assume you may be personally targeted.',
      'Urgency, bypass-the-process requests, and slightly-wrong sender addresses are red flags.',
      'Verify through a separate, known channel — never reply to or trust the suspicious message/call.',
      'Early reporting is always rewarded, never punished — report fast and let the team assess.',
    ],
  },
};

/* ════════════════════════════════════════════════════════════════════════════
 * MODULE 8 — Acceptable Use & AI Tools
 * ══════════════════════════════════════════════════════════════════════════ */
const m8 = {
  meta: {
    module: 8,
    kicker: 'Interactive Scenario',
    title: 'The Prompt Box Is Public',
    player: 'You — Security Analyst, using everyday tools',
    summary:
      "Company systems are for company business, and AI tools carry a specific, serious risk. Across four moments " +
      "you'll keep confidential data out of public AI, verify AI output for IP issues, and keep company equipment " +
      "used the way the Acceptable Use Policy requires.",
    cast: ['elena', 'marcus', 'priya', 'david', 'auditor'],
  },
  scenes: [
    {
      id: 's1', act: 'Act 1 — The AI Debug Shortcut', title: 'Never paste confidential data',
      setting: "Monday, 10:15 AM. You want an AI assistant to help debug client engagement code. The fastest path is to paste the whole block — including the client's internal API keys and endpoints — into a public AI tool.",
      dialogue: [
        { s: 'priya', t: "Stop right before you paste. That block has live client credentials and endpoints in it. The prompt box isn't a private scratchpad." },
        { s: 'priya', t: "How do you get the AI help you want without leaking client data?" },
      ],
      prompt: "Priya asks: \"How do you use AI to debug the client code safely?\"",
      options: [
        { id: 'a', text: "Paste the whole thing in — AI tools don't store or share prompts.", score: 'poor',
          reaction: { s: 'priya', t: "Many do retain prompts, and either way you've just disclosed client credentials to a third party. That's the breach — what the AI does next barely matters." },
          feedback: "Many tools retain prompts, and the disclosure of client confidential data and live credentials to a third party is itself a serious breach regardless." },
        { id: 'b', text: "Remove all secrets and client-identifying details (or use a sanitised/fictional version), or use only a company-approved enterprise AI tool.", score: 'best',
          reaction: { s: 'priya', t: "Exactly. Sanitise or fictionalise, or use a vetted enterprise tool. Treat that prompt box like a public forum, always." },
          feedback: "Correct. Strip all secrets and client-identifying details, use a sanitised/fictional version, or use only a vetted enterprise tool. Treat any public AI prompt box as a public forum." },
        { id: 'c', text: "Paste it but delete the conversation afterwards.", score: 'poor',
          reaction: { s: 'priya', t: "Deleting your copy doesn't recall what reached their servers. The data left our control the moment you hit send." },
          feedback: "Deleting the local conversation doesn't remove data already transmitted to the provider. The disclosure has already happened." },
      ],
    },
    {
      id: 's2', act: 'Act 2 — "Just the Endpoints"', title: 'Client-identifying data is still confidential',
      setting: "Monday, 10:25 AM. You reconsider: maybe you can paste the code but strip the API keys, leaving the client's endpoint URLs in so the AI has 'enough context.'",
      dialogue: [
        { s: 'marcus', t: "Better instinct — but let's pressure-test it. You'd remove the keys but keep the client's endpoint URLs." },
        { s: 'marcus', t: "Are those endpoint URLs safe to paste into a public AI tool?" },
      ],
      prompt: "Marcus asks: \"Is it okay to leave the client's endpoint URLs in?\"",
      options: [
        { id: 'a', text: "Yes — without the keys, the URLs alone are harmless.", score: 'poor',
          reaction: { s: 'marcus', t: "Endpoint URLs from a client environment are confidential too — they reveal infrastructure and identify the client. Strip those as well." },
          feedback: "Endpoint URLs from a client environment are confidential data — they expose infrastructure and can identify the client. Any client-specific detail must be removed." },
        { id: 'b', text: "No — endpoint URLs are client-identifying/confidential and must also be removed before using a public AI tool.", score: 'best',
          reaction: { s: 'marcus', t: "Right. If it ties back to the client or their environment, it doesn't go in the public box. Full stop." },
          feedback: "Correct. Endpoint URLs are client-confidential. Anything client-identifying or client-specific must be stripped before a public AI tool ever sees it." },
        { id: 'c', text: "Only if I shorten the URLs so they're less recognisable.", score: 'poor',
          reaction: { s: 'marcus', t: "Obscuring isn't removing. Partial URLs can still reveal the environment. Take them out entirely." },
          feedback: "Shortening or obfuscating isn't the same as removing. Client-specific detail must be fully stripped, not lightly disguised." },
      ],
    },
    {
      id: 's3', act: 'Act 3 — The AI Wrote It', title: 'Verifying AI output for IP',
      setting: "Tuesday, 2:00 PM. An AI tool produced a neat block of code and some documentation text for the lab. It looks great and you're ready to ship it straight into the product.",
      dialogue: [
        { s: 'auditor', t: "(Hannah) AI output is convenient, but it can reproduce copyrighted training data without flagging it. That risk lands on us, not the tool." },
        { s: 'priya', t: "Before this goes into a product we ship — what's your responsibility with AI-generated output?" },
      ],
      prompt: "Priya asks: \"Can you ship the AI-generated code and text as-is?\"",
      options: [
        { id: 'a', text: "Yes — AI output is original by definition, so there's no IP risk.", score: 'poor',
          reaction: { s: 'priya', t: "Not true — these tools can regurgitate copyrighted material verbatim. 'The AI made it' is not a defence." },
          feedback: "AI output isn't automatically original — it can reproduce copyrighted or proprietary material. The verification obligation sits with you, not the tool." },
        { id: 'b', text: "No — I'm responsible for verifying it doesn't infringe copyright or reproduce proprietary material before using it.", score: 'best',
          reaction: { s: 'priya', t: "Exactly. You own the output once you use it. Verify it's clean, then ship. That's the AI Use Policy in practice." },
          feedback: "Correct. You must verify AI-generated output doesn't infringe others' IP or reproduce proprietary content before use. The responsibility is yours." },
        { id: 'c', text: "Ship it but add a note saying it was AI-generated.", score: 'poor',
          reaction: { s: 'priya', t: "A disclosure note doesn't cure an infringement. You still have to check the content is actually clean." },
          feedback: "Labelling it AI-generated doesn't remove infringement risk. You still have to verify the content doesn't reproduce protected material." },
      ],
    },
    {
      id: 's4', act: 'Act 4 — The Quick Scroll', title: 'Acceptable use of company equipment',
      setting: "Wednesday, 1:00 PM. On your lunch break, you think about logging into your personal social media on your company laptop — just for a few minutes.",
      dialogue: [
        { s: 'david', t: "Small thing, but worth being clear on, because people assume lunch breaks are a free zone for company equipment." },
        { s: 'david', t: "Personal social media on your company laptop over lunch — is that within acceptable use?" },
      ],
      prompt: "David asks: \"Is personal social media on company equipment okay during your break?\"",
      options: [
        { id: 'a', text: "Yes — it's my lunch break, so personal use is fine.", score: 'poor',
          reaction: { s: 'david', t: "Company equipment is for company business, break or not. The policy doesn't carve out lunchtime." },
          feedback: "Personal social media on company equipment isn't permitted under the Acceptable Use Policy — break time doesn't create an exception." },
        { id: 'b', text: "No — company systems are for company business; personal social media on company equipment isn't permitted.", score: 'best',
          reaction: { s: 'david', t: "Right. Keep personal browsing on personal devices. Clean separation keeps both you and the company out of trouble." },
          feedback: "Correct. Company systems are provided for company business. Personal social media on company equipment isn't permitted, and use is subject to monitoring." },
        { id: 'c', text: "Yes, as long as I use a separate personal browser profile.", score: 'poor',
          reaction: { s: 'david', t: "A separate profile doesn't change the rule — it's still personal use on company kit, still monitored." },
          feedback: "A separate browser profile doesn't change anything — it's still personal use of company equipment, which the policy doesn't allow." },
      ],
    },
  ],
  debrief: {
    title: 'Debrief — Convenience is where the risk hides',
    lines: [
      { s: 'priya', t: "Across all four you kept the prompt box public in your mind — sanitised inputs, verified outputs, clean separation of personal and work." },
      { s: 'marcus', t: "The 'just the endpoints' trap is subtle. If it ties back to the client or their environment, it doesn't go in a public tool." },
      { s: 'auditor', t: "(Hannah) And owning AI output before you ship it — that's the responsibility most teams forget. You didn't." },
    ],
    takeaways: [
      'Company systems are for company business — personal social media on company equipment isn\u2019t permitted.',
      'Treat an AI prompt box like a public forum — never paste confidential, client, or proprietary data (including endpoint URLs).',
      'AI-generated output may infringe copyright or reproduce proprietary material — verifying it is your responsibility.',
      'Use only company-approved enterprise AI tools for sensitive work tasks.',
    ],
  },
};

export { m5, m6, m7, m8 };
