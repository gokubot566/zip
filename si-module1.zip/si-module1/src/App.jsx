import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from './components/Header.jsx';
import Sidebar from './components/Sidebar.jsx';
import WelcomeSection from './components/WelcomeSection.jsx';
import ScenarioCard from './components/ScenarioCard.jsx';
import QuizSection from './components/QuizSection.jsx';
import PolicyReferences from './components/PolicyReferences.jsx';
import ByteAssistant from './components/ByteAssistant.jsx';
import Footer from './components/Footer.jsx';

const SECTIONS = [
  { id: 'intro', label: 'Introduction' },
  { id: 'scenario', label: 'Scenario' },
  { id: 'policies', label: 'Policies' },
  { id: 'quiz', label: 'Knowledge Check' },
];

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [progress, setProgress] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [scenarioDone, setScenarioDone] = useState(false);
  const [quizDone, setQuizDone] = useState(false);
  const [activeSection, setActiveSection] = useState('intro');

  // Load progress from localStorage
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('si_mod1_v1') || '{}');
      if (saved.completed) setCompleted(true);
      if (saved.scenarioDone) setScenarioDone(true);
      if (saved.quizDone) setQuizDone(true);
    } catch {}
  }, []);

  // Save progress
  useEffect(() => {
    try {
      localStorage.setItem('si_mod1_v1', JSON.stringify({ completed, scenarioDone, quizDone }));
    } catch {}
    const pct = (completed ? 100 : (scenarioDone && quizDone ? 80 : scenarioDone || quizDone ? 50 : 25));
    setProgress(pct);
  }, [completed, scenarioDone, quizDone]);

  function handleModuleComplete() {
    setCompleted(true);
    setProgress(100);
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: '#060a12',
      fontFamily: "'Space Grotesk', sans-serif",
      overflowX: 'hidden',
    }}>
      {/* Background grid */}
      <div style={{
        position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0,
        backgroundImage: 'linear-gradient(rgba(30,55,100,0.06) 1px,transparent 1px),linear-gradient(90deg,rgba(30,55,100,0.06) 1px,transparent 1px)',
        backgroundSize: '60px 60px',
      }} />
      {/* Ambient blobs */}
      <div style={{ position: 'fixed', top: '10%', right: '15%', width: 400, height: 400, borderRadius: '50%', background: 'radial-gradient(circle,rgba(26,86,219,0.07) 0%,transparent 70%)', pointerEvents: 'none', zIndex: 0 }} />
      <div style={{ position: 'fixed', bottom: '20%', left: '5%', width: 300, height: 300, borderRadius: '50%', background: 'radial-gradient(circle,rgba(14,165,233,0.05) 0%,transparent 70%)', pointerEvents: 'none', zIndex: 0 }} />

      <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} progress={progress} />
      <Sidebar open={sidebarOpen} />

      {/* Main content */}
      <motion.main
        animate={{ paddingLeft: sidebarOpen ? 280 : 0 }}
        transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
        style={{
          paddingTop: 60, minHeight: '100vh', position: 'relative', zIndex: 1,
        }}
      >
        {/* Section nav */}
        <div style={{
          position: 'sticky', top: 60, zIndex: 100,
          background: 'rgba(6,10,18,0.9)', backdropFilter: 'blur(16px)',
          borderBottom: '1px solid rgba(255,255,255,0.05)',
          padding: '0 32px', display: 'flex', alignItems: 'center', gap: 4,
        }}>
          {SECTIONS.map(s => (
            <a
              key={s.id}
              href={`#${s.id}`}
              onClick={() => setActiveSection(s.id)}
              style={{
                padding: '12px 14px',
                fontFamily: "'Space Grotesk', sans-serif", fontSize: 12.5, fontWeight: 500,
                color: activeSection === s.id ? '#e2e8f0' : '#334155',
                borderBottom: `2px solid ${activeSection === s.id ? '#1a56db' : 'transparent'}`,
                textDecoration: 'none', transition: 'all 0.15s',
                display: 'block',
              }}
            >
              {s.label}
            </a>
          ))}
          <div style={{ flex: 1 }} />
          <div style={{ fontSize: 11, color: '#1e293b', fontFamily: "'JetBrains Mono', monospace" }}>
            {progress < 100 ? `${progress}% complete` : '✓ Complete'}
          </div>
        </div>

        <div style={{ maxWidth: 860, margin: '0 auto', padding: '36px 32px 48px' }}>
          {/* Intro */}
          <section id="intro">
            <WelcomeSection />
          </section>

          {/* Scenario */}
          <section id="scenario" style={{ marginTop: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.05)' }} />
              <span style={{ fontSize: 11, color: '#334155', fontFamily: "'JetBrains Mono', monospace", letterSpacing: '0.08em' }}>PRACTICAL APPLICATION</span>
              <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.05)' }} />
            </div>
            <ScenarioCard onComplete={() => setScenarioDone(true)} completed={scenarioDone} />
          </section>

          {/* Policies */}
          <section id="policies" style={{ marginTop: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.05)' }} />
              <span style={{ fontSize: 11, color: '#334155', fontFamily: "'JetBrains Mono', monospace", letterSpacing: '0.08em' }}>POLICY FRAMEWORK</span>
              <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.05)' }} />
            </div>
            <PolicyReferences />
          </section>

          {/* Quiz */}
          <section id="quiz" style={{ marginTop: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.05)' }} />
              <span style={{ fontSize: 11, color: '#334155', fontFamily: "'JetBrains Mono', monospace", letterSpacing: '0.08em' }}>KNOWLEDGE CHECK</span>
              <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.05)' }} />
            </div>
            <QuizSection onComplete={() => setQuizDone(true)} completed={quizDone} />
          </section>

          {/* Footer */}
          <div style={{ marginTop: 32 }}>
            <Footer onComplete={handleModuleComplete} completed={completed} />
          </div>
        </div>
      </motion.main>

      <ByteAssistant currentSection={activeSection} />
    </div>
  );
}
