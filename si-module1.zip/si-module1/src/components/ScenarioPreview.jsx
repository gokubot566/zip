/* ============================================================================
 * ScenarioPreview.jsx — STANDALONE LIVE PREVIEW of every module scenario
 * ----------------------------------------------------------------------------
 * Drop this in and render <ScenarioPreview /> to verify the character-based
 * scenarios in isolation — no login gate, no module shell, no backend. A row of
 * buttons lets you jump between all 11 module scenarios; each one is the REAL
 * CharacterScenario component reading the REAL registry (src/modules/scenarios.js),
 * so what you see here is exactly what ships inside each module.
 *
 * Usage inside this project (uses the real cast portraits):
 *     // src/main.jsx
 *     import ScenarioPreview from './components/ScenarioPreview.jsx'
 *     import './index.css'
 *     ReactDOM.createRoot(document.getElementById('root'))
 *       .render(<ScenarioPreview />)
 *   then:  npm run dev   ->   open http://localhost:5173
 *
 * Restore main.jsx to render <App /> before building for deployment.
 * ========================================================================== */

import { useState } from 'react';
import CharacterScenario from './CharacterScenario.jsx';
import { SCENARIOS } from '../modules/scenarios.js';

export default function ScenarioPreview() {
  const ids = Object.keys(SCENARIOS).map(Number).sort((a, b) => a - b);
  const [moduleId, setModuleId] = useState(ids[0]);
  const meta = SCENARIOS[moduleId].meta;

  return (
    <div style={{ minHeight: '100vh', background: '#f8f9fa', padding: '28px 16px', fontFamily: "'Inter', sans-serif" }}>
      <div style={{ maxWidth: 760, margin: '0 auto' }}>
        <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#8b5cf6', letterSpacing: '0.07em', marginBottom: 12 }}>
          SECURITY IMPOSSIBLE · ONBOARDING SCENARIOS · STANDALONE PREVIEW
        </div>

        {/* Module picker */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 18 }}>
          {ids.map(id => {
            const active = id === moduleId;
            return (
              <button
                key={id}
                onClick={() => setModuleId(id)}
                title={SCENARIOS[id].meta.title}
                style={{
                  padding: '7px 13px', borderRadius: 7, cursor: 'pointer',
                  fontFamily: "'DM Mono', monospace", fontSize: 12, fontWeight: 600,
                  border: `1px solid ${active ? '#5b21b6' : '#e2e4e9'}`,
                  background: active ? '#6d28d9' : '#fff',
                  color: active ? '#fff' : '#6b7280',
                  transition: 'all 0.12s',
                }}
              >
                M{id}
              </button>
            );
          })}
        </div>

        {/* Current module label */}
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 700, fontSize: 15, color: '#0f1117' }}>
            Module {moduleId} — {meta.title}
          </div>
          <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#9ca3af' }}>
            {meta.player}
          </div>
        </div>

        {/* The real component, keyed so it resets when you switch modules */}
        <CharacterScenario key={moduleId} moduleId={moduleId} onDone={() => {}} done={false} />

        <p style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#c4c9d4', textAlign: 'center', marginTop: 16 }}>
          Standalone preview · scenarios live in src/modules/scenarios.js · wired into each module via CharacterScenario.jsx
        </p>
      </div>
    </div>
  );
}
