import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, Lock, Clock, ChevronRight, Shield } from 'lucide-react';

const MODULES = [
  { id: 1, title: 'Welcome & Why Security Matters', duration: '15 min', active: true, complete: false },
  { id: 2, title: 'Confidentiality & Your Obligations', duration: '20 min', active: false, complete: false },
  { id: 3, title: 'Intellectual Property & Ownership', duration: '15 min', active: false, complete: false },
  { id: 4, title: 'Privacy & Australian Privacy Principles', duration: '25 min', active: false, complete: false },
  { id: 5, title: 'Data Classification & Handling', duration: '20 min', active: false, complete: false },
  { id: 6, title: 'Asset Management & Secure Workplace', duration: '15 min', active: false, complete: false },
  { id: 7, title: 'Recognising & Responding to Threats', duration: '25 min', active: false, complete: false },
  { id: 8, title: 'Acceptable Use & AI Tools', duration: '20 min', active: false, complete: false },
  { id: 9, title: 'Social Media & Public Conduct', duration: '15 min', active: false, complete: false },
  { id: 10, title: 'Working with Clients & Third Parties', duration: '20 min', active: false, complete: false },
  { id: 11, title: "Putting It Together & Your Commitment", duration: '10 min', active: false, complete: false },
];

export default function Sidebar({ open }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.aside
          initial={{ x: -280, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -280, opacity: 0 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          style={{
            position: 'fixed', top: 60, left: 0, bottom: 0, zIndex: 150,
            width: 280, overflowY: 'auto',
            background: 'rgba(8,13,23,0.98)',
            backdropFilter: 'blur(20px)',
            borderRight: '1px solid rgba(255,255,255,0.06)',
            padding: '20px 0',
            scrollbarWidth: 'thin', scrollbarColor: '#1e293b transparent',
          }}
        >
          {/* Header */}
          <div style={{ padding: '0 20px 16px', borderBottom: '1px solid rgba(255,255,255,0.05)', marginBottom: 12 }}>
            <div style={{ fontSize: 10, color: '#334155', fontFamily: "'JetBrains Mono', monospace", letterSpacing: '0.1em', marginBottom: 4 }}>
              TRAINING PROGRAM
            </div>
            <div style={{ fontSize: 13, color: '#e2e8f0', fontFamily: "'Space Grotesk', sans-serif", fontWeight: 600 }}>
              Security & Governance
            </div>
            {/* Overall progress */}
            <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ flex: 1, height: 3, background: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{ width: '9%', height: '100%', background: 'linear-gradient(90deg,#1a56db,#0ea5e9)', borderRadius: 2 }} />
              </div>
              <span style={{ fontSize: 10, color: '#475569', fontFamily: "'JetBrains Mono', monospace" }}>1/11</span>
            </div>
          </div>

          {/* Module list */}
          <div style={{ padding: '0 10px' }}>
            {MODULES.map((mod, i) => (
              <motion.div
                key={mod.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.04, duration: 0.3 }}
                style={{
                  display: 'flex', alignItems: 'flex-start', gap: 10,
                  padding: '10px 10px',
                  borderRadius: 10,
                  marginBottom: 3,
                  cursor: mod.active ? 'pointer' : 'default',
                  background: mod.active ? 'rgba(26,86,219,0.14)' : 'transparent',
                  border: mod.active ? '1px solid rgba(26,86,219,0.3)' : '1px solid transparent',
                  transition: 'all 0.2s',
                  position: 'relative',
                  opacity: (!mod.active && !mod.complete) ? 0.5 : 1,
                }}
              >
                {/* Active glow */}
                {mod.active && (
                  <div style={{
                    position: 'absolute', left: 0, top: '20%', bottom: '20%',
                    width: 2, background: 'linear-gradient(180deg,#1a56db,#0ea5e9)', borderRadius: 1,
                  }} />
                )}

                {/* Icon */}
                <div style={{
                  width: 28, height: 28, borderRadius: 8, flexShrink: 0,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: mod.active ? 'rgba(26,86,219,0.25)' : mod.complete ? 'rgba(16,185,129,0.15)' : 'rgba(255,255,255,0.04)',
                  border: mod.active ? '1px solid rgba(26,86,219,0.4)' : mod.complete ? '1px solid rgba(16,185,129,0.3)' : '1px solid rgba(255,255,255,0.06)',
                  marginTop: 1,
                }}>
                  {mod.complete ? (
                    <CheckCircle size={13} color="#10b981" />
                  ) : mod.active ? (
                    <Shield size={13} color="#63b3ed" />
                  ) : (
                    <Lock size={11} color="#334155" />
                  )}
                </div>

                {/* Text */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{
                    fontFamily: "'Space Grotesk', sans-serif", fontSize: 12, fontWeight: mod.active ? 600 : 500,
                    color: mod.active ? '#e2e8f0' : mod.complete ? '#94a3b8' : '#4a5568',
                    lineHeight: 1.4, marginBottom: 3,
                  }}>
                    <span style={{ color: mod.active ? '#63b3ed' : mod.complete ? '#10b981' : '#2d3748', fontSize: 10, fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, marginRight: 5 }}>
                      {String(mod.id).padStart(2,'0')}
                    </span>
                    {mod.title}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <Clock size={10} color={mod.active ? '#475569' : '#2d3748'} />
                    <span style={{ fontSize: 10, color: mod.active ? '#475569' : '#2d3748', fontFamily: "'JetBrains Mono', monospace" }}>
                      {mod.duration}
                    </span>
                    {mod.active && (
                      <span style={{
                        marginLeft: 4, fontSize: 9, fontFamily: "'JetBrains Mono', monospace",
                        color: '#0ea5e9', background: 'rgba(14,165,233,0.12)',
                        padding: '1px 5px', borderRadius: 3, border: '1px solid rgba(14,165,233,0.2)',
                        fontWeight: 700, letterSpacing: '0.05em',
                      }}>ACTIVE</span>
                    )}
                  </div>
                </div>
                {mod.active && <ChevronRight size={12} color="#334155" style={{ marginTop: 6, flexShrink: 0 }} />}
              </motion.div>
            ))}
          </div>

          {/* Footer */}
          <div style={{ padding: '16px 20px', marginTop: 8, borderTop: '1px solid rgba(255,255,255,0.04)' }}>
            <div style={{ fontSize: 10, color: '#1e293b', fontFamily: "'JetBrains Mono', monospace", lineHeight: 1.8 }}>
              <div>Need help?</div>
              <div style={{ color: '#1a56db' }}>security@securityimpossible.com.au</div>
            </div>
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  );
}
