# Security Impossible — Module 1: Welcome & Why Security Matters Here

Interactive cybersecurity onboarding platform for Security Impossible Pty Ltd.

## Quick Start

```bash
# Clone / extract the project, then:
docker compose up -d --build

# Access at:
http://localhost:7070
http://<YOUR-AZURE-PUBLIC-IP>:7070
```

## Azure / Cloud Deployment

### 1. Open port 7070 in your NSG (Azure firewall)
- Azure Portal → Virtual Machines → your VM → Networking
- Add inbound port rule: TCP 7070 from Any

### 2. Deploy
```bash
git clone / unzip the project
cd si-module1
docker compose up -d --build
```

### 3. Verify
```bash
docker compose ps          # Check status
docker compose logs -f     # View logs
curl http://localhost:7070/health   # Health check
```

## Structure
```
si-module1/
├── src/
│   ├── App.jsx                   # Root app, layout, progress state
│   ├── main.jsx                  # React entry point
│   └── components/
│       ├── Header.jsx            # Top navigation bar with progress
│       ├── Sidebar.jsx           # Collapsible module navigation
│       ├── WelcomeSection.jsx    # Main content: intro, stats, principles
│       ├── ScenarioCard.jsx      # Interactive scenario (friend question)
│       ├── QuizSection.jsx       # 4-question knowledge check
│       ├── PolicyReferences.jsx  # Expandable policy accordion
│       ├── ByteAssistant.jsx     # Floating AI guide with chat
│       └── Footer.jsx            # Completion CTA + firm info
├── nginx/
│   └── default.conf              # Nginx config (port 7070)
├── Dockerfile                    # Multi-stage Node→nginx build
├── docker-compose.yml            # Single-service compose config
├── vite.config.js                # Vite build config
├── package.json
└── index.html
```

## Features
- Framer Motion animations throughout
- Byte AI assistant with contextual hints and chat
- Interactive scenario with 4 response options and feedback
- 4-question knowledge check with instant feedback and explanations
- Expandable policy reference accordion
- Progress tracking via localStorage (survives page refresh)
- Responsive sidebar with all 11 modules listed
- Header progress bar
- Docker health check on /health endpoint
- Gzip compression, security headers, static asset caching

## Commands
```bash
docker compose up -d --build    # Build and start
docker compose down             # Stop
docker compose restart          # Restart
docker compose logs -f          # Follow logs
docker compose ps               # Status
```

## Sign-in & Audit (added)

On every visit, users must enter **first name, last name, and work email** before
the course loads. These details are recorded for compliance/auditing.

The Node backend (`server/server.js`) serves the built app **and** exposes
`POST /api/signin`, which appends each sign-in to the audit volume:

```
./audit-data/onboarding_signins.csv     # spreadsheet-friendly
./audit-data/onboarding_signins.jsonl   # one JSON record per line
```

`./audit-data` is bind-mounted into the container (`/data`) via docker-compose,
so records persist on the Linux host and survive container restarts/rebuilds.

To review records on the host:

```bash
cat audit-data/onboarding_signins.csv
tail -f audit-data/onboarding_signins.jsonl
```

Each record contains: `timestamp, first_name, last_name, email, ip, user_agent`.

## Module completion gate (added)

Modules that contain a **Knowledge Check** can no longer be marked complete until
the quiz has been submitted. The completion panel shows a locked
"Knowledge Check required" state until the quiz is done, then unlocks.

## Run

```bash
docker compose up -d --build
# App + audit API on http://<HOST_IP>:7070
```

For local development (frontend on :5173, API proxied to the Node server on :7070):

```bash
npm install
npm start        # terminal 1 — Node audit server on :7070
npm run dev      # terminal 2 — Vite dev server on :5173
```

## Character-Based Scenarios (all 11 modules)

Every module now opens its interactive section with a **cast-driven branching scenario**
rather than a single multiple-choice card. You play an analyst; the shared cast (Elena,
Priya, Marcus, David, and Hannah the external auditor) work each situation with you across
four acts, each with in-character dialogue, a graded decision, per-option reactions, and a
closing debrief. The five characters are consistent across every module — same people,
same brand colours, same portraits — re-tagged with onboarding-appropriate roles.

Each scenario's story is written specifically for that module's topic:

| Module | Scenario title |
|--------|----------------|
| 1  | Day Two: The Prospect Question |
| 2  | The Things You Carry |
| 3  | Whose Work Is It? |
| 4  | The Spreadsheet That Knows Too Much |
| 5  | Four Tiers, One Wrong Move |
| 6  | The Device Line |
| 7  | The Urgent Email |
| 8  | The Prompt Box Is Public |
| 9  | The Post You Don't Send |
| 10 | Inside the Client's Walls |
| 11 | Everything At Once (capstone) |

### Files
```
src/assets/cast/character-1..5.png    # shared portraits (512px)
src/components/Cast.jsx               # CastPhoto — circular brand-ringed portrait
src/modules/cast.js                   # CHARACTERS roster (ids/names/brand colours)
src/modules/scenarios_part1.js        # scenarios for modules 1–4
src/modules/scenarios_part2.js        # scenarios for modules 5–8
src/modules/scenarios.js              # scenarios 9–11 + the assembled REGISTRY
src/components/CharacterScenario.jsx  # the scenario renderer (takes a moduleId prop)
src/components/ScenarioPreview.jsx    # STANDALONE live-verify harness (see below)
```

### How it's wired
All scenarios live in a single **registry** in `src/modules/scenarios.js`, keyed by
module id (`SCENARIOS[1]` … `SCENARIOS[11]`) with a `getScenario(moduleId)` helper.
`src/components/ModuleContent.jsx` calls `getScenario(module.id)`; if a scenario exists
for that module it renders `<CharacterScenario moduleId={module.id} />`, otherwise it
falls back to the original single-card scenario. Because it's registry-driven, no
per-module flag is needed — adding or removing a module's scenario is a one-line change
in the registry.

Each scenario object has the shape `{ meta, scenes, debrief }`. Every scene has exactly
one "best" option (which advances the story); "ok"/"poor" options show coaching feedback
and let you try again.

### Verifying the scenarios live, on their own
`src/components/ScenarioPreview.jsx` is a self-contained harness — no login gate, no
module shell, no backend. It shows a row of buttons (M1–M11) so you can flip through
every module's scenario:

```bash
# temporarily point the entry at the preview:
#   src/main.jsx →  import ScenarioPreview from './components/ScenarioPreview.jsx'
#                   ReactDOM.createRoot(...).render(<ScenarioPreview />)
npm install
npm run dev          # open http://localhost:5173
```

Restore `main.jsx` to render `App.jsx` before building for deployment.

> Note: `src/main.jsx` imports `./index.css`, which loads the shared cast portrait
> styles (and previously-unused badge / section-divider classes).
