import React, { createContext, useContext, useReducer, useEffect, useRef, useMemo } from 'react';
import { reducer, createInitialState, hydrate, serialize } from './reducer.js';
import * as FS from './fs.js';
import { getApp } from '../apps/registry.js';
import { getActiveLab } from '../labs/index.js';
import {
  PLATFORM_STORE_KEY, DEFAULT_PROFILE, DEFAULT_SETTINGS, buildBaseFs,
} from '../config/platform.js';
import { BRANDING } from '../config/branding.jsx';

const OSContext = createContext(null);

// Resolve the active lab (if any) into a seed the reducer understands. The
// platform builds a base desktop; a lab layers its profile, files and data on
// top. With no lab, this yields a clean generic desktop.
function buildSeed() {
  const lab = getActiveLab();
  const now = Date.now();
  const profile = { ...DEFAULT_PROFILE, ...(lab?.profile ?? {}) };

  let fs = buildBaseFs(profile, now);
  if (lab?.seed) {
    const helpers = {
      now,
      profile,
      writeFile: (tree, p, c, m) => FS.writeFile(tree, p, c, { now, ...m }),
      mkdir: (tree, p, m) => FS.mkdir(tree, p, { now, ...m }),
    };
    fs = lab.seed(fs, helpers) ?? fs;
  }

  return {
    now,
    profile,
    fs,
    data: lab?.data ?? {},
    notifications: (lab?.notifications ?? []).map((n) => ({ ...n })),
    settings: { ...DEFAULT_SETTINGS },
    labId: lab?.id ?? null,
  };
}

function storeKey() {
  return getActiveLab()?.storeKey ?? PLATFORM_STORE_KEY;
}

function init() {
  const seed = buildSeed();
  let saved = null;
  try {
    const raw = localStorage.getItem(storeKey());
    saved = raw ? JSON.parse(raw) : null;
  } catch {
    /* ignore */
  }
  return hydrate(seed, saved);
}

export function OSProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, undefined, init);
  const viewportRef = useRef({ w: window.innerWidth, h: window.innerHeight });
  const saveTimer = useRef(null);

  useEffect(() => {
    const onResize = () => { viewportRef.current = { w: window.innerWidth, h: window.innerHeight }; };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  useEffect(() => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      try { localStorage.setItem(storeKey(), JSON.stringify(serialize(state))); } catch { /* full/unavailable */ }
    }, 250);
    return () => clearTimeout(saveTimer.current);
  }, [state]);

  const actions = useMemo(() => {
    const open = (appId, args) => {
      const app = getApp(appId);
      if (app) dispatch({ type: 'OPEN_WINDOW', app, args, viewport: viewportRef.current });
    };
    return {
      dispatch,
      openApp: open,
      closeWindow: (id) => dispatch({ type: 'CLOSE_WINDOW', id }),
      focusWindow: (id) => dispatch({ type: 'FOCUS_WINDOW', id }),
      minimizeWindow: (id) => dispatch({ type: 'MINIMIZE_WINDOW', id }),
      toggleMinimize: (id) => dispatch({ type: 'TOGGLE_MINIMIZE', id }),
      toggleMaximize: (id) => dispatch({ type: 'TOGGLE_MAXIMIZE', id }),
      setBounds: (id, bounds) => dispatch({ type: 'SET_BOUNDS', id, bounds }),
      setWindowTitle: (id, title) => dispatch({ type: 'SET_WINDOW_TITLE', id, title }),
      setWindowArgs: (id, args) => dispatch({ type: 'SET_WINDOW_ARGS', id, args }),

      login: () => dispatch({ type: 'LOGIN' }),
      lock: () => dispatch({ type: 'LOCK' }),
      unlock: () => dispatch({ type: 'UNLOCK' }),
      logout: () => dispatch({ type: 'LOGOUT' }),
      bootDone: () => dispatch({ type: 'BOOT_DONE' }),

      // filesystem
      writeFile: (path, content, meta) => dispatch({ type: 'FS_WRITE', path, content, meta }),
      mkdir: (path, meta) => dispatch({ type: 'FS_MKDIR', path, meta }),
      renamePath: (path, newName) => dispatch({ type: 'FS_RENAME', path, newName }),
      movePath: (from, toDir) => dispatch({ type: 'FS_MOVE', from, toDir }),
      copyPath: (path, toDir) => dispatch({ type: 'FS_COPY', path, toDir }),
      deletePath: (path) => dispatch({ type: 'FS_DELETE', path, now: Date.now() }),
      restoreFromBin: (id) => dispatch({ type: 'FS_RESTORE', id }),
      removeFromBin: (id) => dispatch({ type: 'FS_BIN_DELETE', id }),
      emptyBin: () => dispatch({ type: 'FS_EMPTY_BIN' }),

      // notifications
      notify: (opts) => dispatch({ type: 'NOTIFY', now: Date.now(), ...opts }),
      dismissToast: (id) => dispatch({ type: 'DISMISS_TOAST', id }),
      markNotificationsRead: () => dispatch({ type: 'MARK_NOTIFICATIONS_READ' }),
      removeNotification: (id) => dispatch({ type: 'REMOVE_NOTIFICATION', id }),
      clearNotifications: () => dispatch({ type: 'CLEAR_NOTIFICATIONS' }),

      // settings
      setSetting: (key, value) => dispatch({ type: 'SET_SETTING', key, value }),

      // generic activity / OS operations (labs interpret these)
      recordOpenFile: (path) => dispatch({ type: 'RECORD_OPEN_FILE', path }),
      recordActivity: (token) => dispatch({ type: 'RECORD_ACTIVITY', token }),
      killProcess: (pid) => dispatch({ type: 'KILL_PROCESS', pid }),
      toggleStartup: (id) => dispatch({ type: 'TOGGLE_STARTUP', id }),
      quarantineThreats: (ids) => dispatch({ type: 'QUARANTINE_THREATS', ids }),
      setNetworkIsolated: (value) => dispatch({ type: 'SET_NETWORK_ISOLATED', value }),
      recordScan: () => dispatch({ type: 'RECORD_SCAN' }),

      // opaque lab-app state
      setLabState: (key, value) => dispatch({ type: 'SET_LAB_STATE', key, value }),
      mergeLabState: (patch) => dispatch({ type: 'MERGE_LAB_STATE', patch }),

      resetSession: () => {
        try { localStorage.removeItem(storeKey()); } catch { /* ignore */ }
        dispatch({ type: 'REPLACE_STATE', state: { ...init(), session: { booted: true, loggedIn: true, locked: false } } });
      },
    };
  }, []);

  const value = useMemo(() => ({ state, branding: BRANDING, ...actions }), [state, actions]);
  return <OSContext.Provider value={value}>{children}</OSContext.Provider>;
}

export function useOS() {
  const ctx = useContext(OSContext);
  if (!ctx) throw new Error('useOS must be used within OSProvider');
  return ctx;
}

export function useClock(intervalMs = 1000) {
  const [now, setNow] = React.useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}
