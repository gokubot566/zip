// ===========================================================================
// LAB REGISTRY — the platform's extension point for training labs.
//
// This template ships with NO labs, so the OS boots as a clean generic desktop.
// To add a lab:
//   1. Create src/labs/<your-lab>/index.js exporting a lab package
//      (see the "Create a new lab" guide in README.md / CLAUDE.md):
//        { id, storeKey, meta, profile, seed, data, desktopShortcuts, apps }
//   2. Import it here and add it to LABS.
//   3. Set ACTIVE_LAB_ID to its id.
//
// The rest of the platform touches labs only through getActiveLab()/getLab(),
// so nothing else needs to change.
// ===========================================================================

import eboxLab from './ebox/index.js';

export const LABS = [eboxLab];

// Which lab this deployment runs. `null` → generic, lab-free desktop.
export const ACTIVE_LAB_ID = 'ebox';

export function getActiveLab() {
  return LABS.find((l) => l.id === ACTIVE_LAB_ID) ?? null;
}

export function getLab(id) {
  return LABS.find((l) => l.id === id) ?? null;
}
