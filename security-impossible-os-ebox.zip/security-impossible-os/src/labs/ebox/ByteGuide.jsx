import React, { useState, useEffect, useRef } from 'react';
import { X, ChevronRight, ChevronLeft, Check, Lock, Lightbulb, BookOpen, ExternalLink, Trophy, RotateCcw, GripHorizontal, Compass } from 'lucide-react';
import { useOS } from '../../core/OSContext.jsx';
import { ByteAvatar } from './ByteAvatar.jsx';
import marcusPhoto from './assets/marcus.png';
import priyaPhoto from './assets/priya.png';

// ===========================================================================
// Byte — the whole-lab guide, living on the DESKTOP (draggable, on top).
// Page 1: Byte introduces itself + the case.  Page 2: meet the team (appears
// as a short conversation).  Pages 3+: five gated steps focused on HEADER
// ANALYSIS — each unlocks the next only once the learner performs it.
// ===========================================================================

const CH = {
  marcus: { name: 'Marcus Chen', role: 'SOC Manager',           color: '#3b82f6', photo: marcusPhoto },
  priya:  { name: 'Priya Patel', role: 'Email Security Analyst', color: '#34d399', photo: priyaPhoto },
};

const P = { bg:'#0e1020', panel:'#171a2e', line:'#2a2f4a', text:'#eef1fb', dim:'#c3c9e6', mute:'#8a90b5', accent:'#8b7ff5', mint:'#2dd4bf', mintInk:'#04241c', teal:'#34d399', good:'#34d399', bad:'#ff6b7d', warn:'#f5a524' };

// ---- Page 1: Byte introduction (detailed) ----
const INTRO = [
  `Hi, I'm <b>Byte</b> — your guide inside Security Impossible OS. 👋 I float on top of the desktop and I'll walk you through every step, so you're never stuck.`,
  `Here's the case: the SOC flagged a <b>suspicious email</b> sitting in a staff mailbox. It looks like a routine "your password expires" notice — but something feels off. Your job is to investigate it and <b>prove</b> whether it's genuine or a phishing attempt.`,
  `You'll open the <b>Ebox</b> mailbox, take a look around, read the message's real headers, then run them through <b>MailProbe</b> — our email-investigation tool. Nothing here can harm a real computer; it's all simulated in your browser.`,
  `📖 One habit that helps: whenever you meet a technical word like <b>SPF</b> or <b>DMARC</b>, I'll put a definition right here — just tap <b>"What does this mean?"</b> on any step.`,
];

// ---- Page 2: the team (revealed as a conversation) ----
const TEAM_INTRO = `A couple of colleagues are on this case with you — each will chime in as you go.`;
const TEAM = [
  { who:'marcus', line:`Marcus, SOC Manager. My analysts raised the alert that started all this — thanks for picking it up.` },
  { who:'priya',  line:`I'm Priya, Email Security Analyst. Reading headers is my world — I'll be with you through the analysis.` },
];

// ---- Pages 3+: five gated steps (header-analysis focused) ----
const TASKS = [
  {
    id:'open', speaker:'marcus', title:'Open the mailbox',
    body:`Everything starts in <b>Ebox</b> — the staff mailbox. Open it from the desktop icon (or the button below) and <b>sign in</b> (the address is filled in; any password works for this demo). Once you're in, <b>feel free to explore</b> — click around the folders and other messages like you would in any inbox.`,
    app:'ebox', appLabel:'Open Ebox',
    hint:`Double-click the blue <b>Ebox</b> mailbox icon on the desktop, then press <b>Sign in</b>. Have a look around the Inbox, Spam and Sent folders.`,
    defs:[{ term:'Webmail', text:`Email you read through a browser instead of an installed app — like Ebox here.` }],
    doneWhen:(p)=>p.signedIn, unlockedNote:`Signed in — take a moment to explore, then let's find the suspicious one.`,
  },
  {
    id:'find', speaker:'priya', title:'Find the suspicious message',
    body:`In the Inbox, open <b>"[Action Required] Your password expires in 24 hours"</b> from "Microsoft 365 Security". It looks routine — we'll prove otherwise from the evidence. I've highlighted it for you.`,
    highlight:'row-m2',
    hint:`It's the second message in the Inbox — the amber-glowing one from "Microsoft 365 Security".`,
    defs:[{ term:'Phishing', text:`A message that impersonates someone you trust to trick you into clicking a link or handing over credentials.` }],
    doneWhen:(p)=>p.openedM2, unlockedNote:`Message open. First impressions look fine — now let's look under the hood.`,
  },
  {
    id:'source', speaker:'priya', title:'Read the raw headers',
    body:`Open the message's <b>⋮ menu → View source</b>. That shows the raw <code>.eml</code> — every <b>header</b> the mail servers stamped on, with no hints. I'll break down the important ones below once it's open.`,
    highlight:'kebab',
    hint:`Click the <b>⋮</b> (three dots) at the top-right of the open message, then <b>View source</b>.`,
    defs:[
      { term:'Email headers', text:`The hidden metadata every mail server adds to a message — who sent it, the servers it passed through, and the results of authentication checks. The visible name and subject are easy to fake; headers are much harder to.` },
      { term:'Header analysis', text:`Reading those headers to decide whether a message is genuine — checking the true origin, whether authentication passed, and whether the sender's identity is consistent across the headers.` },
    ],
    headers:[
      { name:'Received', flag:'bad', text:`Read the chain <b>bottom-to-top</b> to find the true origin — a random VPS (<b>vps-4471.hostwind-cloud.ru</b>), nothing to do with Microsoft.` },
      { name:'Authentication-Results', flag:'bad', text:`<b>SPF fail</b>, <b>DKIM none</b>, <b>DMARC fail</b> — all three reject it. The strongest technical proof of spoofing.` },
      { name:'From', flag:'bad', text:`Real address is <b>micros0ft-support.com</b> — a zero for the "o", not microsoft.com.` },
      { name:'Reply-To / Return-Path', flag:'bad', text:`Point to unrelated look-alike domains — the impersonation is baked into the envelope.` },
    ],
    doneWhen:(p)=>p.viewedSrc, unlockedNote:`That's the real envelope. Now let's confirm it with MailProbe.`,
  },
  {
    id:'probe', speaker:'byte', title:'Open MailProbe',
    body:`Reading by eye is slow. <b>MailProbe</b> parses the header for you and gives a clear verdict. Open it from the desktop (or the button below) — the suspicious message is pre-loaded.`,
    app:'mailprobe', appLabel:'Open MailProbe',
    hint:`Double-click the cyan <b>MailProbe</b> radar icon on the desktop.`,
    defs:[
      { term:'What MailProbe does', text:`It reads a raw email header and breaks it down — the routing (relay hops), the sender details, and the authentication results — then gives a plain-language verdict on whether the sender is genuine.` },
      { term:'What it contains', text:`Three tabs: Header analysis, DNS & mail servers, and Reputation. All three are active and available to explore.` },
      { term:'Focus of this lab', text:`We'll use the Header analysis tab — that's the core skill here. The DNS and Reputation tabs are there if you'd like to go further, but you don't need them to reach the verdict.` },
    ],
    doneWhen:(p)=>p.mailprobeOpen, unlockedNote:`MailProbe is open on the Header analysis tab — the sample is loaded.`,
  },
  {
    id:'header', speaker:'priya', title:'Analyse the header',
    body:`On MailProbe's <b>Header analysis</b> tab, press <b>Inspect header</b>. Review the <b>routing</b> (relay hops), the <b>sender details</b> (From / Reply-To / Return-Path) and the <b>authentication results</b>. Then read the verdict — that's your conclusion.`,
    hint:`If you don't see a result yet, press the blue <b>Inspect header</b> button on the Header analysis tab.`,
    defs:[
      { term:'SPF (Sender Policy Framework)', text:`Checks whether the server that sent the message is one the domain owner authorised. SPF fail = an unauthorised server sent it.` },
      { term:'DKIM (DomainKeys Identified Mail)', text:`A cryptographic signature from the sending domain. A valid DKIM proves the message wasn't tampered with and really came from that domain. DKIM none/fail = no such proof.` },
      { term:'DMARC (Domain-based Auth, Reporting & Conformance)', text:`Ties SPF and DKIM back to the visible From address and tells receivers what to do on failure. DMARC fail = the From identity can't be trusted.` },
      { term:'When & why a header is flagged as malicious', text:`A header is treated as malicious when authentication fails (SPF / DKIM / DMARC), when identity headers (From, Reply-To, Return-Path, Message-ID) point to different or look-alike domains, or when the routing origin is an unrelated / suspicious host. Each is a sign the sender is not who they claim — i.e. spoofing.` },
      { term:'Reading the result', text:`MailProbe's verdict banner is green when everything aligns and red when checks fail. Here every check fails and the identity headers disagree with the From domain, so the verdict is "spoofed" — a phishing email.` },
    ],
    doneWhen:(p)=>p.header, unlockedNote:`Authentication fails across the board and the identities don't match — verdict: phishing.`,
  },
];

const OUTCOMES = [
  `Sign in to a mailbox and locate a suspicious message`,
  `Open and read an email's raw headers`,
  `Explain what email headers are and why they matter`,
  `Analyse routing, sender details and SPF / DKIM / DMARC results`,
  `Decide when a header indicates spoofing and reach an evidence-based verdict`,
];

const GAP = 14;

function Avatar({ who, size = 30, speaking }) {
  if (who === 'byte') return <ByteAvatar size={size} speaking={speaking} />;
  const c = CH[who];
  return <img src={c.photo} alt={c.name} draggable="false" style={{ width:size, height:size, borderRadius:'50%', objectFit:'cover', boxShadow:`0 0 0 2px ${c.color}` }} />;
}

export default function ByteGuide() {
  const { state, openApp } = useOS();
  const [open, setOpen] = useState(true);
  const [page, setPage] = useState('intro');       // intro | team | tasks | done
  const [shown, setShown] = useState(0);           // intro bubbles revealed
  const [typing, setTyping] = useState(false);
  const [teamShown, setTeamShown] = useState(0);   // team bubbles revealed
  const [teamTyping, setTeamTyping] = useState(false);
  const [step, setStep] = useState(0);             // task index
  const [showHint, setShowHint] = useState(false);
  const [showDef, setShowDef] = useState(false);
  const [prog, setProg] = useState({ signedIn:false, openedM2:false, viewedSrc:false, header:false });
  const endRef = useRef(null);
  const panelRef = useRef(null);

  // ---- draggable (grab the header OR the minimised icon) ----
  const [pos, setPos] = useState(null);
  const drag = useRef(null);
  const didDrag = useRef(false);
  const onHeadDown = (e) => {
    const el = panelRef.current; if (!el) return;
    const r = el.getBoundingClientRect();
    drag.current = { dx: e.clientX - r.left, dy: e.clientY - r.top };
    didDrag.current = false;
    e.preventDefault();
  };
  useEffect(() => {
    const move = (e) => {
      if (!drag.current) return;
      const el = panelRef.current; if (!el) return;
      didDrag.current = true;
      const w = el.offsetWidth, h = el.offsetHeight;
      let left = e.clientX - drag.current.dx, top = e.clientY - drag.current.dy;
      left = Math.max(GAP, Math.min(left, window.innerWidth - w - GAP));
      top = Math.max(GAP, Math.min(top, window.innerHeight - h - GAP));
      setPos({ left, top });
    };
    const up = () => { drag.current = null; };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    return () => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
  }, []);

  // ---- detect the mailbox iframe messages ----
  useEffect(() => {
    const onMsg = (e) => {
      const d = e.data;
      if (!d || d.source !== 'ebox') return;
      if (d.event === 'signed-in') setProg((p) => ({ ...p, signedIn:true }));
      if (d.event === 'open' && d.id === 'm2') setProg((p) => ({ ...p, openedM2:true }));
      if (d.event === 'viewsource' && d.id === 'm2') setProg((p) => ({ ...p, viewedSrc:true }));
    };
    window.addEventListener('message', onMsg);
    return () => window.removeEventListener('message', onMsg);
  }, []);

  // ---- detect MailProbe header analysis (same document, custom event) ----
  useEffect(() => {
    const h = () => setProg((p) => ({ ...p, header:true }));
    window.addEventListener('mailprobe:header', h);
    return () => window.removeEventListener('mailprobe:header', h);
  }, []);

  const mailprobeOpen = (state?.windows ?? []).some((w) => w.appId === 'mailprobe');
  const eboxOpen = (state?.windows ?? []).some((w) => w.appId === 'ebox');
  const fullProg = { ...prog, mailprobeOpen, eboxOpen };

  const cur = TASKS[step];
  const taskDone = page === 'tasks' && cur.doneWhen(fullProg);

  // auto-play the intro conversation
  useEffect(() => {
    if (page !== 'intro' || shown >= INTRO.length) return;
    setTyping(true);
    const t = setTimeout(() => { setTyping(false); setShown((n) => n + 1); }, Math.min(1700, 600 + INTRO[shown].length * 7));
    return () => clearTimeout(t);
  }, [page, shown]);

  // auto-play the team conversation
  useEffect(() => {
    if (page !== 'team' || teamShown >= TEAM.length) return;
    setTeamTyping(true);
    const t = setTimeout(() => { setTeamTyping(false); setTeamShown((n) => n + 1); }, 1100);
    return () => clearTimeout(t);
  }, [page, teamShown]);

  useEffect(() => { endRef.current?.scrollIntoView({ block:'end' }); }, [shown, typing, teamShown, teamTyping, step, page]);
  useEffect(() => { setShowHint(false); setShowDef(false); }, [step, page]);

  // highlight the right spot inside Ebox when a task needs it
  useEffect(() => {
    const frame = document.querySelector('iframe[title="Ebox — Mailbox"]');
    const target = page === 'tasks' ? (cur.highlight ?? null) : null;
    try { frame?.contentWindow?.postMessage({ source:'byte', action:'highlight', target }, '*'); } catch {}
  }, [page, step]);

  const restart = () => {
    setPage('intro'); setShown(0); setStep(0); setTyping(false); setTeamShown(0); setTeamTyping(false);
    setProg({ signedIn:false, openedM2:false, viewedSrc:false, header:false });
  };

  if (!state?.session?.loggedIn) return null;

  if (!open) {
    const launchStyle = pos
      ? { left: Math.max(GAP, Math.min(pos.left, window.innerWidth - 60 - GAP)), top: Math.max(GAP, Math.min(pos.top, window.innerHeight - 60 - GAP)), right: 'auto', bottom: 'auto' }
      : { right: 18, bottom: 60 };
    return (
      <button
        ref={panelRef}
        onMouseDown={onHeadDown}
        onClick={() => { if (didDrag.current) { didDrag.current = false; return; } setOpen(true); }}
        title="Open Byte — drag to move"
        style={{ position:'fixed', ...launchStyle, zIndex:9000, width:60, height:60, borderRadius:'50%', border:0, cursor:'grab', background:'transparent', filter:'drop-shadow(0 6px 16px rgba(0,0,0,.5))' }}>
        <ByteAvatar size={56} speaking />
      </button>
    );
  }

  const posStyle = pos
    ? { left: Math.max(GAP, Math.min(pos.left, window.innerWidth - 390 - GAP)), top: Math.max(GAP, Math.min(pos.top, window.innerHeight - 160 - GAP)), right: 'auto', bottom: 'auto' }
    : { right: 18, bottom: 56 };
  const introDone = shown >= INTRO.length;
  const teamDone = teamShown >= TEAM.length;

  const bubble = (who, text, live) => (
    <div style={{ display:'flex', gap:9, alignItems:'flex-start' }}>
      <Avatar who={who} size={30} speaking={live} />
      <div>
        <div style={{ fontSize:12.5, fontWeight:700, marginBottom:3, color: who==='byte' ? P.teal : CH[who].color }}>
          {who==='byte' ? 'Byte' : <>{CH[who].name} <span style={{ color:P.mute, fontWeight:600 }}>· {CH[who].role}</span></>}
        </div>
        <div style={{ fontSize:13, lineHeight:1.55, color:P.dim, background:P.panel, border:`1px solid ${P.line}`, borderRadius:'3px 12px 12px 12px', padding:'9px 12px' }} dangerouslySetInnerHTML={{ __html:text }} />
      </div>
    </div>
  );

  const typingDots = (who) => (
    <div style={{ display:'flex', gap:9, alignItems:'flex-start' }}>
      <Avatar who={who} size={30} speaking />
      <div style={{ background:P.panel, border:`1px solid ${P.line}`, borderRadius:'3px 12px 12px 12px', padding:'11px 13px', color:P.mute, letterSpacing:2 }}>•••</div>
    </div>
  );

  const btn = (label, onClick, { primary=true, icon=null, iconRight=null, disabled=false } = {}) => (
    <button onClick={onClick} disabled={disabled}
      style={{ display:'inline-flex', alignItems:'center', justifyContent:'center', gap:7, padding:'10px 14px', borderRadius:10,
        border: primary ? 0 : `1px solid ${P.line}`, background: disabled ? '#20243c' : primary ? P.mint : 'transparent',
        color: disabled ? P.mute : primary ? P.mintInk : P.dim, fontWeight:700, fontSize:13.5, cursor: disabled ? 'not-allowed' : 'pointer' }}>
      {icon}{label}{iconRight}
    </button>
  );

  const sectionLabel = (emoji, txt) => (
    <div style={{ fontSize:12.5, fontWeight:800, letterSpacing:.6, textTransform:'uppercase', color:P.teal, margin:'0 0 12px' }}>{emoji} {txt}</div>
  );

  const subtitle = page==='intro' ? 'Introduction' : page==='team' ? 'Meet the team' : page==='done' ? 'Analysis complete' : `Task ${step+1} of ${TASKS.length} · ${CH[cur.speaker]?.name ?? 'Byte'}`;

  return (
    <div ref={panelRef} style={{ position:'fixed', ...posStyle, zIndex:9000, width:390, maxHeight:'calc(100vh - 96px)', display:'flex', flexDirection:'column',
      background:P.bg, border:`1px solid ${P.line}`, borderRadius:16, boxShadow:'0 18px 50px rgba(0,0,0,.55)', overflow:'hidden' }}>

      {/* draggable header */}
      <div onMouseDown={onHeadDown} title="Drag to move" style={{ display:'flex', alignItems:'center', gap:10, padding:'12px 14px', borderBottom:`1px solid ${P.line}`, background:'linear-gradient(180deg,#1c2044,#12142a)', cursor:'grab', userSelect:'none' }}>
        <ByteAvatar size={38} speaking />
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontWeight:800, fontSize:15, color:P.text }}>Byte · Lab Guide</div>
          <div style={{ fontSize:12, color:P.mute }}>{subtitle}</div>
        </div>
        <GripHorizontal size={18} color={P.mute} />
        <button onClick={() => setOpen(false)} title="Minimise" style={{ background:'transparent', border:0, color:P.mute, cursor:'pointer', padding:2 }}><X size={18} /></button>
      </div>

      {/* task progress pips */}
      {page==='tasks' && (
        <div style={{ display:'flex', gap:5, padding:'11px 14px 0' }}>
          {TASKS.map((t, i) => <span key={i} style={{ flex:1, height:5, borderRadius:999, background: (i<step || (i===step && taskDone)) ? P.mint : i===step ? 'rgba(45,212,191,.5)' : '#2a2f4a' }} />)}
        </div>
      )}

      {/* body */}
      <div style={{ padding:14, overflowY:'auto', flex:1, minHeight:0 }}>
        {page==='intro' && (
          <>
            {sectionLabel('👋','Meet Byte, your guide')}
            <div style={{ display:'flex', flexDirection:'column', gap:11 }}>
              {INTRO.slice(0, shown).map((t, i) => <React.Fragment key={i}>{bubble('byte', t, i===shown-1 && !typing)}</React.Fragment>)}
              {typing && !introDone && typingDots('byte')}
              <div ref={endRef} />
              {introDone && <div style={{ marginTop:4 }}>{btn('Meet the team →', () => { setPage('team'); setTeamShown(0); })}</div>}
            </div>
          </>
        )}

        {page==='team' && (
          <>
            {sectionLabel('🧑‍💼','Meet your team')}
            <p style={{ fontSize:13, lineHeight:1.55, color:P.dim, margin:'0 0 14px' }}>{TEAM_INTRO}</p>
            <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
              {TEAM.slice(0, teamShown).map((m, i) => <React.Fragment key={i}>{bubble(m.who, m.line, i===teamShown-1 && !teamTyping)}</React.Fragment>)}
              {teamTyping && !teamDone && typingDots(TEAM[teamShown]?.who || 'marcus')}
              <div ref={endRef} />
            </div>
            {teamDone && (
              <div style={{ display:'flex', gap:8, marginTop:16 }}>
                {btn('Back', () => setPage('intro'), { primary:false, icon:<ChevronLeft size={15} /> })}
                <div style={{ flex:1 }} />
                {btn('Start the analysis →', () => { setPage('tasks'); setStep(0); })}
              </div>
            )}
          </>
        )}

        {page==='tasks' && (
          <>
            <div style={{ fontSize:11, fontWeight:800, letterSpacing:.8, textTransform:'uppercase', color:P.teal, marginBottom:8 }}>Step {step+1} · {cur.title}</div>
            <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:10 }}>
              <Avatar who={cur.speaker} size={26} />
              <div style={{ fontSize:12.5, fontWeight:700, color: cur.speaker==='byte' ? P.teal : CH[cur.speaker].color }}>
                {cur.speaker==='byte' ? 'Byte' : <>{CH[cur.speaker].name} <span style={{ color:P.mute, fontWeight:600 }}>· {CH[cur.speaker].role}</span></>}
              </div>
            </div>
            <p style={{ fontSize:13.5, lineHeight:1.6, color:P.dim, margin:'0 0 12px' }} dangerouslySetInnerHTML={{ __html:cur.body }} />

            {cur.app && <div style={{ marginBottom:12 }}><button onClick={() => openApp(cur.app)} style={{ display:'inline-flex', alignItems:'center', justifyContent:'center', gap:8, width:'100%', padding:'11px 14px', borderRadius:10, background:'rgba(139,127,245,.12)', border:`1px solid rgba(139,127,245,.4)`, color:P.accent, fontWeight:700, fontSize:13.5, cursor:'pointer' }}><ExternalLink size={15} /> {cur.appLabel}</button></div>}

            {/* header reference (step 3) — shown once source is open */}
            {cur.headers && prog.viewedSrc && (
              <div style={{ display:'flex', flexDirection:'column', gap:8, margin:'0 0 12px' }}>
                {cur.headers.map((h, i) => {
                  const col = h.flag==='bad' ? P.bad : h.flag==='warn' ? P.warn : P.good;
                  const bg = h.flag==='bad' ? 'rgba(255,107,125,.12)' : h.flag==='warn' ? 'rgba(245,165,36,.12)' : 'rgba(52,211,153,.12)';
                  return (
                    <div key={i} style={{ borderLeft:`3px solid ${col}`, background:P.panel, borderRadius:'0 8px 8px 0', padding:'8px 10px' }}>
                      <div style={{ fontSize:12, fontWeight:800, color:col, marginBottom:2, fontFamily:'ui-monospace,monospace' }}>{h.name} <span style={{ background:bg, color:col, borderRadius:999, padding:'1px 7px', fontSize:9.5, marginLeft:4 }}>{h.flag==='bad'?'MISMATCH':h.flag==='warn'?'CHECK':'ALIGNED'}</span></div>
                      <div style={{ fontSize:12.5, lineHeight:1.5, color:P.dim }} dangerouslySetInnerHTML={{ __html:h.text }} />
                    </div>
                  );
                })}
              </div>
            )}

            {/* hint + definitions toggles */}
            <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:10 }}>
              {cur.hint && (
                <button onClick={() => setShowHint((v) => !v)} style={{ display:'inline-flex', alignItems:'center', gap:6, background:'transparent', border:`1px solid ${P.line}`, color:P.teal, borderRadius:8, padding:'6px 10px', fontSize:12, cursor:'pointer' }}>
                  <Lightbulb size={14} /> {showHint ? 'Hide hint' : 'Need a hint?'}
                </button>
              )}
              {cur.defs?.length > 0 && (
                <button onClick={() => setShowDef((v) => !v)} style={{ display:'inline-flex', alignItems:'center', gap:6, background:'transparent', border:`1px solid ${P.line}`, color:P.accent, borderRadius:8, padding:'6px 10px', fontSize:12, cursor:'pointer' }}>
                  <BookOpen size={14} /> {showDef ? 'Hide definitions' : 'What does this mean?'}
                </button>
              )}
            </div>
            {showHint && cur.hint && <div style={{ fontSize:12.5, lineHeight:1.5, color:P.dim, background:'rgba(52,211,153,.1)', border:`1px solid rgba(52,211,153,.3)`, borderRadius:8, padding:'8px 10px', marginBottom:10 }} dangerouslySetInnerHTML={{ __html:cur.hint }} />}
            {showDef && cur.defs?.length > 0 && (
              <div style={{ display:'flex', flexDirection:'column', gap:8, marginBottom:10 }}>
                {cur.defs.map((d, i) => (
                  <div key={i} style={{ fontSize:12.5, lineHeight:1.5, color:P.dim, background:'rgba(139,127,245,.1)', border:`1px solid rgba(139,127,245,.3)`, borderRadius:8, padding:'8px 10px' }}>
                    <b style={{ color:P.text }}>{d.term}:</b> <span dangerouslySetInnerHTML={{ __html:d.text }} />
                  </div>
                ))}
              </div>
            )}

            {/* status: locked until performed */}
            <div style={{ display:'flex', alignItems:'center', gap:8, fontSize:12.5, borderRadius:8, padding:'9px 11px', marginBottom:12,
              background: taskDone ? 'rgba(52,211,153,.12)' : 'rgba(255,255,255,.04)', color: taskDone ? P.good : P.mute, border:`1px solid ${taskDone ? 'rgba(52,211,153,.3)' : P.line}` }}>
              {taskDone ? <Check size={15} /> : <Lock size={14} />}
              <span dangerouslySetInnerHTML={{ __html: taskDone ? cur.unlockedNote : 'Do this in the app to unlock the next task.' }} />
            </div>

            <div style={{ display:'flex', gap:8 }}>
              {step > 0 && btn('Back', () => setStep((s) => s-1), { primary:false, icon:<ChevronLeft size={15} /> })}
              <div style={{ flex:1 }} />
              {!taskDone
                ? btn('Locked', () => {}, { iconRight:<Lock size={14} />, disabled:true })
                : step < TASKS.length-1
                  ? btn('Next task', () => setStep((s) => s+1), { iconRight:<ChevronRight size={15} /> })
                  : btn('Finish', () => setPage('done'), { icon:<Check size={15} /> })}
            </div>
            <div ref={endRef} />
          </>
        )}

        {page==='done' && (
          <>
            <div style={{ width:52, height:52, borderRadius:'50%', background:P.good, color:'#04140d', display:'grid', placeItems:'center', margin:'4px auto 12px' }}><Trophy size={26} /></div>
            <div style={{ textAlign:'center', fontWeight:800, fontSize:16, color:P.text, marginBottom:6 }}>Analysis complete</div>
            <p style={{ textAlign:'center', fontSize:12.5, color:P.dim, margin:'0 0 12px' }}>The header analysis is conclusive — failed authentication and mismatched identities make this a <b style={{ color:P.bad }}>phishing attempt</b>. Nicely done.</p>
            <div style={{ fontSize:11, fontWeight:800, letterSpacing:.6, textTransform:'uppercase', color:P.teal, margin:'10px 0 8px' }}>What you learned</div>
            <ul style={{ margin:0, padding:0, listStyle:'none', display:'flex', flexDirection:'column', gap:8 }}>
              {OUTCOMES.map((o, i) => <li key={i} style={{ display:'flex', gap:8, fontSize:12.5, color:P.dim, lineHeight:1.5 }}><Check size={15} color={P.good} style={{ flex:'0 0 auto', marginTop:1 }} /><span>{o}</span></li>)}
            </ul>
          </>
        )}
      </div>

      {/* footer: restart + workstation label */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 14px', borderTop:`1px solid ${P.line}`, background:'#0b0d1a' }}>
        <button onClick={restart} style={{ display:'inline-flex', alignItems:'center', gap:7, background:'transparent', border:`1px solid ${P.line}`, color:P.dim, borderRadius:9, padding:'8px 12px', fontSize:12.5, cursor:'pointer' }}>
          <RotateCcw size={14} /> Restart lab
        </button>
        <span style={{ fontSize:11, letterSpacing:1, color:P.mute, fontFamily:'ui-monospace,monospace' }}>{state?.profile?.hostname ?? 'WORKSTATION'}</span>
      </div>
    </div>
  );
}
