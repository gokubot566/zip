import { Mailbox, Radar } from 'lucide-react';
import EboxApp from './EboxApp.jsx';
import MailProbe from './MailProbe.jsx';
import ByteGuide from './ByteGuide.jsx';

// ===========================================================================
// EBOX — email header analysis lab package.
//
// Adds two desktop apps and a desktop-level guide:
//   • Ebox        — a realistic mailbox (Jordan Blake's inbox). The message
//                   viewer's "View source" shows every header with a plain
//                   explanation. No torch, no analyzer inside — just mail.
//   • MailProbe   — an email-investigation app (headers, DNS, reputation) with its own desktop icon.
//   • Byte        — a guide that lives on the DESKTOP and walks the learner
//                   across both apps (rendered via the `guide` field).
//
// The OS login is intentionally left as the platform default (no `profile`
// override) — only the mailbox *inside* Ebox belongs to Jordan Blake.
// ===========================================================================
export default {
  id: 'ebox',
  storeKey: 'security-impossible-os.lab.ebox.v2',

  meta: {
    name: 'Email Header Analysis',
    category: 'Email Security',
    difficulty: 'Beginner',
    summary:
      'Open Ebox (the mailbox) to read an email\u2019s headers, then confirm your findings in MailProbe \u2014 guided end to end by Byte on the desktop.',
  },

  // No `profile` override → the OS keeps its default login (SI User).

  // Leave a friendly pointer on the (default) user's desktop.
  seed(fs, { writeFile, profile }) {
    const desktop = `C:/Users/${profile.username}/Desktop/Start here - Byte.txt`;
    return writeFile(
      fs,
      desktop,
      'Byte (bottom-right of the desktop) guides this lab.\n' +
        'Open the "Ebox" mailbox icon to begin, and use "MailProbe"\n' +
        'to inspect a message\u2019s headers.',
      {},
    );
  },

  data: {},

  // Desktop icons for both apps.
  desktopShortcuts: [
    { id: 'd-ebox', type: 'app', appId: 'ebox', label: 'Ebox' },
    { id: 'd-mailprobe', type: 'app', appId: 'mailprobe', label: 'MailProbe' },
  ],

  // Byte — the whole-lab guide, rendered at desktop level by the shell.
  guide: ByteGuide,

  // The apps this lab contributes.
  apps: [
    {
      id: 'ebox',
      name: 'Ebox',
      icon: Mailbox,
      color: '#4c8dff',
      category: 'Productivity',
      singleton: true,
      defaultSize: { w: 1200, h: 800 },
      startMaximized: true,
      component: EboxApp,
    },
    {
      id: 'mailprobe',
      name: 'MailProbe',
      icon: Radar,
      color: '#22d3ee',
      category: 'Tools',
      singleton: true,
      defaultSize: { w: 960, h: 740 },
      component: MailProbe,
    },
  ],
};
