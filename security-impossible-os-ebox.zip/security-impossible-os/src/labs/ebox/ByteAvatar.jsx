/* ByteAvatar — a static, self-contained SVG robot mascot for the guide ("Byte").
   Inline SVG so it needs no network/asset fetch (works on isolated lab networks)
   and inherits the lab's indigo/cyan palette. Ported from the SocialNest lab so
   Byte is visually identical across the course. */
export function ByteAvatar({ size = 84, speaking = false }) {
  return (
    <span
      className={`byte-avatar ${speaking ? 'speaking' : ''}`}
      style={{ width: size, height: size }}
      title="Byte — your lab guide"
      aria-label="Byte, your lab guide"
    >
      <svg viewBox="0 0 64 64" width="100%" height="100%" role="img" aria-hidden="true">
        <defs>
          <linearGradient id="byteBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#1c2438" />
            <stop offset="1" stopColor="#0f1422" />
          </linearGradient>
          <linearGradient id="byteHead" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#2b3350" />
            <stop offset="1" stopColor="#1a2138" />
          </linearGradient>
          <radialGradient id="byteEye" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#7fe9ff" />
            <stop offset="0.6" stopColor="#06b6d4" />
            <stop offset="1" stopColor="#0587a0" />
          </radialGradient>
        </defs>

        {/* backdrop */}
        <circle cx="32" cy="32" r="32" fill="url(#byteBg)" />

        {/* antenna */}
        <line x1="32" y1="15" x2="32" y2="9" stroke="#6366f1" strokeWidth="2.4" strokeLinecap="round" />
        <circle cx="32" cy="8" r="3" fill="#818cf8" />

        {/* head shell */}
        <rect x="14" y="16" width="36" height="30" rx="10" fill="url(#byteHead)" stroke="#6366f1" strokeWidth="1.6" />

        {/* ears / side pods */}
        <rect x="10" y="26" width="4.5" height="10" rx="2.2" fill="#6366f1" />
        <rect x="49.5" y="26" width="4.5" height="10" rx="2.2" fill="#6366f1" />

        {/* face screen */}
        <rect x="19" y="21" width="26" height="20" rx="7" fill="#0b0f1a" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />

        {/* eyes */}
        <circle className="byte-eye" cx="26.5" cy="30.5" r="3.6" fill="url(#byteEye)" />
        <circle className="byte-eye" cx="37.5" cy="30.5" r="3.6" fill="url(#byteEye)" />
        <circle cx="27.6" cy="29.4" r="1.1" fill="#eafcff" />
        <circle cx="38.6" cy="29.4" r="1.1" fill="#eafcff" />

        {/* smile */}
        <path d="M25 36 Q32 40 39 36" fill="none" stroke="#10b981" strokeWidth="2" strokeLinecap="round" />
      </svg>
    </span>
  )
}
