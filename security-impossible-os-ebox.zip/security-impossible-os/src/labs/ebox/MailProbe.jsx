import React, { useState } from 'react';
import { Search, ShieldCheck, ShieldAlert, Route, Fingerprint, FileText, Globe, Server, Radar, AlertTriangle, RotateCcw } from 'lucide-react';

// ===========================================================================
// MailProbe — an email-investigation tool (renamed from the header-only tool).
// Three activities, each on its own tab:
//   1) Header analysis  — routing, sender details, authentication results
//   2) DNS & mail servers — MX / TXT / SPF / DKIM / DMARC + authorised servers
//   3) Reputation        — is the sender IP / domain reported for abuse?
// Emits window events (mailprobe:header|dns|reputation) so the desktop guide
// (Byte) can unlock the matching step. Fully simulated — no real network.
// ===========================================================================

const SAMPLE = `From: Microsoft 365 Security <account-security@micros0ft-support.com>
To: jordan.blake@arclight-logistics.com
Subject: [Action Required] Your password expires in 24 hours
Date: Mon, 3 Mar 2025 03:47:51 +0000
Reply-To: recovery@mail-verify-portal.com
Return-Path: <bounce@sendmail.micros0ft-support.com>
Message-ID: <a7f3c1@mail-verify-portal.com>
Received: from vps-4471.hostwind-cloud.ru (185.220.101.42)
  by mx01.arclight-logistics.com with ESMTP
  Mon, 03 Mar 2025 03:47:52 +0000
Authentication-Results: mx01.arclight-logistics.com;
  spf=fail (sender IP not authorised) smtp.mailfrom=micros0ft-support.com;
  dkim=none;
  dmarc=fail`;

const domOf = (s) => { const m = String(s).match(/@([\w.-]+)/); return m ? m[1] : (String(s).match(/([\w-]+\.[\w.-]+)/)?.[1] || '—'); };
const field = (raw, name) => {
  const lines = String(raw).split('\n'); const re = new RegExp('^' + name + ':\\s*(.*)$', 'i');
  for (let i = 0; i < lines.length; i++) { const m = lines[i].match(re); if (m) { let out = m[1]; let j = i + 1; while (j < lines.length && /^[ \t]/.test(lines[j])) { out += '\n' + lines[j].trim(); j++; } return out.trim(); } }
  return '';
};
const authVal = (v, re) => { const m = String(v).match(re); return m ? m[1].toLowerCase() : 'n/a'; };
const tone = (r) => (r === 'pass' ? 'good' : (r === 'none' || r === 'softfail' || r === 'neutral' || r === 'n/a') ? 'warn' : 'bad');
const MEANING = {
  spf: { pass: 'Sent by a server the domain authorises.', fail: 'Sent by a server the domain does NOT authorise.', softfail: 'Probably not authorised.', none: 'No SPF record to check.', 'n/a': 'Not present.' },
  dkim: { pass: 'Valid signature — content untampered.', fail: 'Signature present but did not verify.', none: 'The message was not signed.', 'n/a': 'Not present.' },
  dmarc: { pass: 'From domain is backed by an aligned check.', fail: 'From domain is not authenticated.', none: 'No DMARC policy published.', 'n/a': 'Not present.' },
};

// simulated DNS + reputation intelligence for the sample's domains/IPs
const DNS_DB = {
  'micros0ft-support.com': {
    registered: 'Registered 6 days ago (2025-02-25)', ns: 'ns1.cheap-dns-host.ru',
    records: [
      { type: 'MX', value: '— none published —', verdict: 'bad', note: 'No MX record: the domain cannot receive mail. Typical of a throwaway, send-only spoofing domain.' },
      { type: 'TXT/SPF', value: 'v=spf1 +all', verdict: 'bad', note: '“+all” authorises ANY server to send as this domain — effectively no protection. Legitimate domains never do this.' },
      { type: 'DKIM', value: '— no public key —', verdict: 'bad', note: 'No DKIM selector published, so mail can’t be cryptographically verified.' },
      { type: 'DMARC', value: '— no record —', verdict: 'bad', note: 'No DMARC policy: the owner sets no rule for messages that fail authentication.' },
    ],
    mxAuth: 'No mail servers are authorised to receive mail for this domain (no MX).',
    verdict: 'The sender domain has essentially no legitimate mail infrastructure — a hallmark of a spoofing domain.',
  },
  'arclight-logistics.com': {
    registered: 'Registered 7 years ago (2018-04-11)', ns: 'ns1.arclight-logistics.com',
    records: [
      { type: 'MX', value: '10 mx01.arclight-logistics.com', verdict: 'good', note: 'A published, on-domain mail server.' },
      { type: 'TXT/SPF', value: 'v=spf1 include:_spf.arclight-logistics.com -all', verdict: 'good', note: '“-all” — only listed servers may send. Correctly restrictive.' },
      { type: 'DKIM', value: 'selector1._domainkey (2048-bit key)', verdict: 'good', note: 'Valid DKIM public key published.' },
      { type: 'DMARC', value: 'v=DMARC1; p=reject', verdict: 'good', note: 'Strict DMARC policy — failing mail is rejected.' },
    ],
    mxAuth: 'mx01.arclight-logistics.com is authorised to receive mail for this domain.',
    verdict: 'Complete, well-configured mail infrastructure — a legitimate domain.',
  },
};
const REP_DB = {
  ip: {
    '185.220.101.42': { listed: true, lists: ['Spamhaus SBL', 'Barracuda BRBL', 'SORBS', 'Tor exit node list'], note: 'Known abusive host — a Tor exit relay listed on multiple blocklists. No legitimate corporate mail originates here.' },
  },
  domain: {
    'micros0ft-support.com': { listed: true, lists: ['Google Safe Browsing (phishing)', 'PhishTank', 'Spamhaus DBL'], note: 'Reported for phishing and typosquatting the Microsoft brand.' },
  },
};

const C = { bg: '#0b0f17', panel: '#111827', line: '#243049', text: '#e8edf6', dim: '#aeb8c9', mute: '#7d8aa3',
  good: '#3ddc84', goodBg: 'rgba(61,220,132,.14)', warn: '#f5a524', warnBg: 'rgba(245,165,36,.14)', bad: '#ff6b7d', badBg: 'rgba(255,107,125,.14)', accent: '#22d3ee' };

function Badge({ r }) {
  const t = tone(r); const col = t === 'good' ? C.good : t === 'warn' ? C.warn : C.bad; const bg = t === 'good' ? C.goodBg : t === 'warn' ? C.warnBg : C.badBg;
  return <span style={{ fontFamily: 'ui-monospace,monospace', fontSize: 11, fontWeight: 800, color: col, background: bg, padding: '2px 9px', borderRadius: 999 }}>{r}</span>;
}
function Card({ icon, title, children }) {
  return (
    <div style={{ border: `1px solid ${C.line}`, borderRadius: 12, marginBottom: 12, overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 12px', background: '#0d1526', color: C.text, fontWeight: 700, fontSize: 12.5 }}>{icon}{title}</div>
      <div style={{ padding: '4px 12px 10px' }}>{children}</div>
    </div>
  );
}
function Verdict({ bad, children }) {
  return (
    <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start', borderRadius: 12, padding: '13px 15px', marginBottom: 14, fontSize: 13.5, lineHeight: 1.5, fontWeight: 600,
      color: bad ? C.bad : C.good, background: bad ? C.badBg : C.goodBg, border: `1px solid ${(bad ? C.bad : C.good)}55` }}>
      {bad ? <ShieldAlert size={20} /> : <ShieldCheck size={20} />}<span>{children}</span>
    </div>
  );
}

const TABS = [
  { id: 'header', label: 'Header analysis', icon: <Search size={15} /> },
  { id: 'dns', label: 'DNS & mail servers', icon: <Globe size={15} /> },
  { id: 'rep', label: 'Reputation', icon: <AlertTriangle size={15} /> },
];

export default function MailProbe() {
  const [raw, setRaw] = useState(SAMPLE);
  const [tab, setTab] = useState('header');
  const [res, setRes] = useState(null);
  const [dns, setDns] = useState(null);
  const [rep, setRep] = useState(null);

  const senderDom = domOf(field(raw, 'From') || '');
  const senderIp = field(raw, 'Received').match(/\(([\d.]+)\)/)?.[1] || '—';

  const analyze = () => {
    const from = field(raw, 'From') || ''; const fromDom = domOf(from);
    const av = field(raw, 'Authentication-Results');
    const auth = { spf: authVal(av, /spf=(\w+)/i), dkim: authVal(av, /dkim=(\w+)/i), dmarc: authVal(av, /dmarc=(\w+)/i) };
    const hops = [...raw.matchAll(/Received:\s*([\s\S]*?)(?=\n\S|$)/gi)].map((m) => { const v = m[1]; return { from: v.match(/from\s+([^\s(]+)/i)?.[1] || '—', ip: v.match(/\(([\d.]+)\)/)?.[1] || '—', by: v.match(/by\s+([^\s]+)/i)?.[1] || '—' }; });
    const identity = [
      { k: 'From', v: from, d: fromDom }, { k: 'Reply-To', v: field(raw, 'Reply-To') || '(none)', d: domOf(field(raw, 'Reply-To')) },
      { k: 'Return-Path', v: field(raw, 'Return-Path') || '(none)', d: domOf(field(raw, 'Return-Path')) }, { k: 'Message-ID', v: field(raw, 'Message-ID') || '(none)', d: domOf(field(raw, 'Message-ID')) },
    ].map((r) => ({ ...r, mismatch: r.k !== 'From' && r.d !== '—' && r.d !== fromDom }));
    const ok = ['spf', 'dkim', 'dmarc'].every((k) => auth[k] === 'pass'); const mism = identity.filter((r) => r.mismatch).length;
    setRes({ fromDom, auth, hops, identity, ok, mism, fields: { From: from, To: field(raw, 'To'), Subject: field(raw, 'Subject'), Date: field(raw, 'Date') } });
    window.dispatchEvent(new CustomEvent('mailprobe:header'));
  };
  const runDns = () => {
    const d = DNS_DB[senderDom] || { registered: '— (simulated: no data) —', ns: '—', records: [
      { type: 'MX', value: '— no data —', verdict: 'warn', note: 'No simulated data for this domain.' },
    ], mxAuth: 'No data for this domain in the simulated resolver.', verdict: 'No records available for this domain in the lab resolver.' };
    setDns({ dom: senderDom, ...d }); window.dispatchEvent(new CustomEvent('mailprobe:dns'));
  };
  const runRep = () => {
    const ip = REP_DB.ip[senderIp]; const dm = REP_DB.domain[senderDom];
    setRep({ ip: senderIp, dom: senderDom, ipRep: ip || { listed: false, lists: [], note: 'Not present on the simulated blocklists.' }, domRep: dm || { listed: false, lists: [], note: 'Not present on the simulated blocklists.' } });
    window.dispatchEvent(new CustomEvent('mailprobe:reputation'));
  };
  const resetAll = () => { setRaw(SAMPLE); setRes(null); setDns(null); setRep(null); setTab('header'); };

  const th = { textAlign: 'left', fontSize: 10.5, textTransform: 'uppercase', letterSpacing: .5, color: C.mute, padding: '7px 10px', borderBottom: `1px solid ${C.line}` };
  const td = { padding: '7px 10px', borderBottom: `1px solid ${C.line}`, color: C.dim, fontSize: 12.5, verticalAlign: 'top' };
  const runBtn = (label, onClick) => (
    <button onClick={onClick} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: C.accent, color: '#04121a', border: 0, borderRadius: 9, padding: '9px 18px', fontWeight: 800, fontSize: 13.5, cursor: 'pointer' }}><Radar size={16} /> {label}</button>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0, background: C.bg, color: C.text }}>
      {/* title */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 16px', borderBottom: `1px solid ${C.line}`, background: '#0d1526' }}>
        <Radar size={20} color={C.accent} />
        <div>
          <div style={{ fontWeight: 800, fontSize: 15 }}>MailProbe</div>
          <div style={{ fontSize: 11.5, color: C.mute }}>Email investigation · headers · DNS &amp; mail servers · sender reputation</div>
        </div>
      </div>

      {/* tabs */}
      <div style={{ display: 'flex', gap: 4, padding: '8px 12px 0', borderBottom: `1px solid ${C.line}`, background: '#0b0f17' }}>
        {TABS.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 13px', border: 0, borderBottom: `2px solid ${tab === t.id ? C.accent : 'transparent'}`,
            background: 'transparent', color: tab === t.id ? C.text : C.mute, fontWeight: 700, fontSize: 12.5, cursor: 'pointer' }}>{t.icon}{t.label}</button>
        ))}
      </div>

      <div style={{ padding: 16, overflowY: 'auto', flex: 1, minHeight: 0 }}>
        {/* shared raw header input */}
        <div style={{ fontSize: 11, color: C.mute, textTransform: 'uppercase', letterSpacing: .5, marginBottom: 6 }}>Raw message header (edit or paste your own)</div>
        <textarea value={raw} onChange={(e) => setRaw(e.target.value)} spellCheck={false}
          style={{ width: '100%', minHeight: 120, resize: 'vertical', background: '#070d18', color: C.dim, border: `1px solid ${C.line}`, borderRadius: 10, padding: 12, fontFamily: 'ui-monospace,monospace', fontSize: 12, lineHeight: 1.5 }} />
        <div style={{ display: 'flex', gap: 10, margin: '10px 0 4px', flexWrap: 'wrap' }}>
          {tab === 'header' && runBtn('Inspect header', analyze)}
          {tab === 'dns' && runBtn('Run DNS lookup', runDns)}
          {tab === 'rep' && runBtn('Run reputation check', runRep)}
          <button onClick={resetAll} style={{ display: 'inline-flex', alignItems: 'center', gap: 7, background: 'transparent', color: C.dim, border: `1px solid ${C.line}`, borderRadius: 9, padding: '9px 14px', fontSize: 13, cursor: 'pointer' }}>
            <RotateCcw size={15} /> Reset to sample
          </button>
        </div>
        <div style={{ fontSize: 11.5, color: C.mute, marginBottom: 12 }}>Sender domain: <b style={{ color: C.dim }}>{senderDom}</b> · Sending IP: <b style={{ color: C.dim }}>{senderIp}</b></div>

        {/* ---- HEADER TAB ---- */}
        {tab === 'header' && res && (
          <>
            <Verdict bad={!res.ok}>{res.ok
              ? 'All authentication checks passed and the identity headers are consistent — this sender is verified.'
              : `Not verified: the From domain (${res.fromDom}) does not pass authentication (SPF=${res.auth.spf}, DKIM=${res.auth.dkim}, DMARC=${res.auth.dmarc})${res.mism ? `, and ${res.mism} identity header(s) point to a different domain` : ''}. Treat this message as spoofed.`}</Verdict>
            <Card icon={<FileText size={15} />} title="Sender details">
              <table style={{ width: '100%', borderCollapse: 'collapse' }}><tbody>
                {Object.entries(res.fields).map(([k, v]) => (<tr key={k}><td style={{ ...td, width: 92, color: C.mute }}>{k}</td><td style={{ ...td, fontFamily: 'ui-monospace,monospace', color: C.text }}>{v || '—'}</td></tr>))}
              </tbody></table>
            </Card>
            <Card icon={<ShieldCheck size={15} />} title="Authentication results">
              {[['SPF', 'spf'], ['DKIM', 'dkim'], ['DMARC', 'dmarc']].map(([label, k]) => (
                <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '7px 0', borderBottom: `1px solid ${C.line}` }}>
                  <b style={{ width: 58, fontSize: 13 }}>{label}</b><Badge r={res.auth[k]} /><span style={{ fontSize: 12.5, color: C.dim }}>{MEANING[k][res.auth[k]] || '—'}</span>
                </div>
              ))}
            </Card>
            <Card icon={<Route size={15} />} title="Routing (origin → your server)">
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead><tr><th style={th}>Hop</th><th style={th}>Origin host</th><th style={th}>IP</th><th style={th}>Received by</th></tr></thead>
                <tbody>{res.hops.length ? res.hops.map((h, i) => (<tr key={i}><td style={td}>{i + 1}</td><td style={{ ...td, fontFamily: 'ui-monospace,monospace' }}>{h.from}</td><td style={{ ...td, fontFamily: 'ui-monospace,monospace' }}>{h.ip}</td><td style={{ ...td, fontFamily: 'ui-monospace,monospace' }}>{h.by}</td></tr>)) : <tr><td style={{ ...td, color: C.mute }} colSpan={4}>No Received hops found.</td></tr>}</tbody>
              </table>
            </Card>
            <Card icon={<Fingerprint size={15} />} title="Identity check (should share the From domain)">
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead><tr><th style={th}>Header</th><th style={th}>Domain</th></tr></thead>
                <tbody>{res.identity.map((r) => (<tr key={r.k}><td style={td}>{r.k}</td><td style={{ ...td, color: r.mismatch ? C.bad : C.dim }}>{r.d}{r.mismatch && <span style={{ marginLeft: 8, fontSize: 10.5, fontWeight: 700, color: C.bad, background: C.badBg, padding: '1px 7px', borderRadius: 999 }}>differs from From</span>}</td></tr>))}</tbody>
              </table>
            </Card>
          </>
        )}
        {tab === 'header' && !res && <p style={{ fontSize: 13, color: C.mute }}>Press <b style={{ color: C.dim }}>Inspect header</b> to parse the routing, sender details and authentication results.</p>}

        {/* ---- DNS TAB ---- */}
        {tab === 'dns' && dns && (
          <>
            <Verdict bad={dns.records.some((r) => r.verdict === 'bad')}>{dns.verdict}</Verdict>
            <div style={{ fontSize: 12, color: C.mute, marginBottom: 10 }}>Domain <b style={{ color: C.dim }}>{dns.dom}</b> · {dns.registered} · NS {dns.ns}</div>
            <Card icon={<Globe size={15} />} title="DNS records (MX · TXT/SPF · DKIM · DMARC)">
              {dns.records.map((r, i) => (
                <div key={i} style={{ padding: '8px 0', borderBottom: `1px solid ${C.line}` }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><b style={{ width: 74, fontSize: 12.5, fontFamily: 'ui-monospace,monospace' }}>{r.type}</b><Badge r={r.verdict === 'good' ? 'pass' : r.verdict === 'warn' ? 'none' : 'fail'} /><span style={{ fontSize: 12.5, color: C.text, fontFamily: 'ui-monospace,monospace' }}>{r.value}</span></div>
                  <div style={{ fontSize: 12, color: C.dim, marginTop: 4, paddingLeft: 82 }}>{r.note}</div>
                </div>
              ))}
            </Card>
            <Card icon={<Server size={15} />} title="Authorised mail servers (MX)">
              <div style={{ fontSize: 12.5, color: C.dim, lineHeight: 1.5 }}>{dns.mxAuth}</div>
            </Card>
          </>
        )}
        {tab === 'dns' && !dns && <p style={{ fontSize: 13, color: C.mute }}>Press <b style={{ color: C.dim }}>Run DNS lookup</b> to verify the sender domain's MX, TXT, SPF, DKIM and DMARC records, and confirm which mail servers are authorised for it.</p>}

        {/* ---- REPUTATION TAB ---- */}
        {tab === 'rep' && rep && (
          <>
            <Verdict bad={rep.ipRep.listed || rep.domRep.listed}>{(rep.ipRep.listed || rep.domRep.listed)
              ? `Flagged: the sending IP and/or domain are reported for abuse. Combined with failed authentication, treat this as malicious.`
              : `Neither the sending IP nor the domain appears on the simulated blocklists.`}</Verdict>
            <Card icon={<AlertTriangle size={15} />} title={`Sending IP · ${rep.ip}`}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}><Badge r={rep.ipRep.listed ? 'fail' : 'pass'} /><span style={{ fontSize: 12.5, color: C.dim }}>{rep.ipRep.listed ? `Listed on ${rep.ipRep.lists.length} blocklist(s)` : 'Not listed'}</span></div>
              {rep.ipRep.listed && <div style={{ fontSize: 12, color: C.dim, marginBottom: 6 }}>{rep.ipRep.lists.map((l, i) => <span key={i} style={{ display: 'inline-block', background: C.badBg, color: C.bad, borderRadius: 999, padding: '2px 9px', margin: '0 6px 6px 0', fontSize: 11 }}>{l}</span>)}</div>}
              <div style={{ fontSize: 12, color: C.dim }}>{rep.ipRep.note}</div>
            </Card>
            <Card icon={<Globe size={15} />} title={`Sender domain · ${rep.dom}`}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}><Badge r={rep.domRep.listed ? 'fail' : 'pass'} /><span style={{ fontSize: 12.5, color: C.dim }}>{rep.domRep.listed ? `Reported on ${rep.domRep.lists.length} service(s)` : 'Not reported'}</span></div>
              {rep.domRep.listed && <div style={{ fontSize: 12, color: C.dim, marginBottom: 6 }}>{rep.domRep.lists.map((l, i) => <span key={i} style={{ display: 'inline-block', background: C.badBg, color: C.bad, borderRadius: 999, padding: '2px 9px', margin: '0 6px 6px 0', fontSize: 11 }}>{l}</span>)}</div>}
              <div style={{ fontSize: 12, color: C.dim }}>{rep.domRep.note}</div>
            </Card>
          </>
        )}
        {tab === 'rep' && !rep && <p style={{ fontSize: 13, color: C.mute }}>Press <b style={{ color: C.dim }}>Run reputation check</b> to see whether the sender's IP address or domain has been reported for spam or malicious activity.</p>}
      </div>
    </div>
  );
}
