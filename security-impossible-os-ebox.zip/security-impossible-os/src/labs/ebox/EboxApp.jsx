import React, { useState } from 'react';
import { Inbox } from 'lucide-react';

// Ebox — the mailbox app. It hosts the self-contained "Introduction to Email
// Header Analysis" lab (a standalone build served from /ebox/), shown in a
// full-window frame. The OS provides the window chrome; this fills it.
export default function EboxApp() {
  const [loaded, setLoaded] = useState(false);

  return (
    <div style={{ position: 'relative', display: 'flex', flex: 1, minHeight: 0, background: '#0b0f17' }}>
      {!loaded && (
        <div
          style={{
            position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
            gap: 10, color: 'var(--text-secondary)', fontSize: 13, zIndex: 1, pointerEvents: 'none',
          }}
        >
          <Inbox size={18} color="var(--accent)" />
          Opening Ebox…
        </div>
      )}
      <iframe
        src="ebox/index.html"
        title="Ebox — Mailbox"
        onLoad={() => setLoaded(true)}
        style={{ flex: 1, width: '100%', height: '100%', border: 0, display: 'block' }}
      />
    </div>
  );
}
