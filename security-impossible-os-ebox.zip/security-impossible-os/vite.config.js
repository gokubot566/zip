import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The designated lab port. Override with LAB_PORT=xxxx if the lab
// infrastructure assigns a different one — dev, preview and the nginx
// container (see Dockerfile / nginx.conf) all use the same value.
const LAB_PORT = Number(process.env.LAB_PORT || 3000);

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'build',
  },
  server: {
    host: '0.0.0.0',
    port: LAB_PORT,
    strictPort: true,
  },
  preview: {
    host: '0.0.0.0',
    port: LAB_PORT,
    strictPort: true,
  },
});
