#!/bin/sh
# Inject the per-container lab id (set via the LAB env var) into the static bundle.
# nginx's official image runs every script in /docker-entrypoint.d/ before starting.
set -e
LAB_VALUE="${LAB:-}"
CONFIG_FILE="/usr/share/nginx/html/lab-config.js"
echo "window.__LAB__ = \"${LAB_VALUE}\";" > "$CONFIG_FILE"
echo "[inject-lab] LAB=${LAB_VALUE:-<none, showing index>} -> ${CONFIG_FILE}"
