# Security Impossible — OSINT Lab Range

An interactive, hands-on OSINT training application. One shared React app, served as **10 Docker containers** — one lab per port (**6061–6070**). Built on the Meridian Financial Services storyline, ethics-first, using only fictional/self-contained datasets.

## The 10 labs

| Port | Lab | Tier | Focus |
|------|-----|------|-------|
| 6061 | 01 — OSINT Foundations & Intelligence Cycle | Foundational | Cycle stages, passive/active/out-of-scope |
| 6062 | 02 — Search Engine Mastery & Source Documentation | Foundational | Operators, archives, reproducible source records |
| 6063 | 03 — Username, Email & Account Enumeration | Foundational | Identity pivoting + confidence rating |
| 6064 | 04 — Domain, DNS & Infrastructure Investigation | Applied | WHOIS/DNS, cert-transparency clustering, IOCs |
| 6065 | 05 — Social Media Intelligence (SOCMINT) | Applied | Passive attack-surface profiling, pretext demo |
| 6066 | 06 — Image & Geolocation Analysis (GEOINT) | Applied | EXIF, reverse-image, visual geolocation |
| 6067 | 07 — Corporate & People OSINT for Due Diligence | Applied | Beneficial ownership, same-name traps |
| 6068 | 08 — OSINT Collection Plan & Toolchain | Applied | Reusable plans, peer review |
| 6069 | 09 — Intelligence Reporting & Analytic Standards | Applied | BLUF, probability lexicon, fact vs judgement |
| 6070 | 10 — Multi-Source OSINT Capstone | Complex | Fuses Labs 3/4/6 into one attribution |

## Teaching cast & gated module checkpoints

Every lab is now taught by the shared Security Impossible cast — the same five
people across the whole course catalogue:

| Instructor | Role in this course |
|------------|---------------------|
| Elena Vasquez | OSINT Team Lead — primary mentor |
| Priya Patel | Head of Threat Intelligence |
| Marcus Chen | Infrastructure & Network Analyst |
| David Okafor | Legal & Risk Counsel |
| Hannah Wong | External Verification Reviewer |

Each lab opens with a **lesson** (a cast member teaches the core concept) and a
**team dialogue** (the cast works the scenario together), then runs the
interactive tasks, and finishes with a **module checkpoint**: a 5-question quiz
drawn from the tasks just performed. The checkpoint is a **hard gate** — you must
score **4/5 (80%)** to complete the lab and unlock the next module. Retries are
unlimited; every question gives instant feedback and an explanation. Progress
(including checkpoint status) persists per-lab in `localStorage`.

## Run with Docker (recommended)

```bash
docker compose up -d --build
```

Then open `http://localhost:6061` (Lab 1) through `http://localhost:6070` (Lab 10).

Each container runs the same image; the `LAB` env var (set per service in `docker-compose.yml`) pins it to one lab. The entrypoint writes that value into `lab-config.js` at startup, and the app reads `window.__LAB__` to render the right lab. Leave `LAB` empty to serve the full index of all labs.

Stop everything:

```bash
docker compose down
```

## Run locally (dev, no Docker)

```bash
npm install
npm run dev
```

The dev server starts on `http://localhost:6061`. With no lab pinned it shows the index; open a specific lab with `?lab=N`, e.g. `http://localhost:6061/?lab=4`.

## How a lab is resolved (priority order)

1. `window.__LAB__` — injected at container start from the `LAB` env var (Docker path)
2. `VITE_LAB` — build-time env (optional)
3. `/lab/N` in the path
4. `?lab=N` query string
5. none → the index page

## Stack

React 18 · Vite · Framer Motion · Lucide icons · nginx (serve) · Docker Compose.

## Project layout

```
src/
  main.jsx               app entry + lab resolution
  Index.jsx              landing page (all 10 labs)
  index.css             design system (dark "intelligence terminal")
  data/labs.js           lab metadata (ports, tiers, titles)
  components/
    kit.jsx              interactive primitives (Quiz, Classifier, Terminal, …)
    LabShell.jsx         header, progress rail, scoring, completion
  labs/
    Lab1.jsx … Lab10.jsx individual lab content
    registry.jsx         id -> lab definition
public/lab-config.js     runtime config (overwritten per container)
Dockerfile               multi-stage build -> nginx
docker-entrypoint.sh     injects LAB into lab-config.js
nginx.conf               SPA fallback + no-cache for lab-config
docker-compose.yml       10 services on ports 6061–6070
```

## Ethics

Every dataset is fictional and self-contained. The labs teach **passive, lawful** collection of publicly available information, full source documentation, and calibrated reporting. Active engagement, deception, and unauthorised access are explicitly taught as out-of-scope, with hard ethics gates throughout.
