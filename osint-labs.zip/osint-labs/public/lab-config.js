// Overwritten at container startup by docker-entrypoint.sh from the $LAB env var.
// Default (empty) => the app shows the index of all 10 labs.
window.__LAB__ = "";
