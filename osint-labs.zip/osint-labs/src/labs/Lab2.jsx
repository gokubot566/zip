import React from 'react';
import { Panel, Scenario, Briefing, Quiz, AnswerCheck, Reflection, StepBody, Terminal } from '../components/kit.jsx';
import { TeachingIntro, makeCheckpoint } from '../components/teaching.jsx';
import { Search, FileSearch, Camera, BookOpen, Archive } from 'lucide-react';

function Brief() {
  return (
    <StepBody>
      
      <TeachingIntro labId={2} />
<Panel icon={Search} label="Practice Tasking · Acme Logistics">
        <Scenario who="Sarah, Team Lead"
          text={'"Most people think they know how to search. They do not. A good analyst finds in three queries what a junior spends an hour on — and can prove where every finding came from. Work this practice tasking against our fictional training company, Acme Logistics. Use operators, not luck. And for every fact, give me a source record: the exact query, the URL, the date, a screenshot. Hand me a findings log another analyst could reproduce exactly."'} />
      </Panel>
      <Panel icon={BookOpen} label="Operator reference">
        <Terminal title="reference://search-operators.md" lines={[
          '<span class="cmd">site:</span>acme-logistics.example        only results on this domain',
          '<span class="cmd">filetype:</span>pdf budget                 only PDF files',
          '<span class="cmd">intitle:</span>"price list"               phrase must be in the page title',
          '<span class="cmd">inurl:</span>admin                        term must be in the URL',
          '<span class="cmd">"exact phrase"</span>                      match the phrase verbatim',
          '<span class="cmd">-careers</span>                            exclude results with this word',
          '<span class="cmd">cache:</span> / Wayback Machine            recover changed or deleted pages',
        ]} />
      </Panel>
    </StepBody>
  );
}

function Operators({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={FileSearch} label="Section 1 · Build the right query">
        <p>Translate each objective into a single precise query. (Type the operator query; we match on the key operators used.)</p>
        <AnswerCheck
          prompt="Find only PDF files on acme-logistics.example that mention 'tariff'"
          placeholder="your query…"
          accepts={['site:acme-logistics.example filetype:pdf tariff', 'filetype:pdf site:acme-logistics.example tariff', 'site:acme-logistics.example tariff filetype:pdf']}
          hint="You need site:, filetype:, and the keyword. Order is flexible."
          explain="site:acme-logistics.example filetype:pdf tariff — scoping to the domain AND the file type collapses thousands of results to a handful."
          onResolved={(ok) => recordScore('l2-q1', ok)}
        />
        <AnswerCheck
          prompt="Find pages whose TITLE contains the exact phrase Price List, anywhere on the web"
          placeholder="your query…"
          accepts={['intitle:"price list"', 'intitle: "price list"', 'intitle:price list']}
          hint="intitle: with a quoted phrase."
          explain="intitle:&quot;price list&quot; — targeting the title field finds the document itself rather than pages that merely mention it."
          onResolved={(ok) => recordScore('l2-q2', ok)}
        />
      </Panel>
    </StepBody>
  );
}

function ArchiveStep({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Archive} label="Section 2 · Recover what was removed">
        <p>The Acme staff page once listed an operations manager, then the page was scrubbed. The live page now 404s.</p>
        <Terminal title="wayback://acme-logistics.example/team" lines={[
          '<span class="cmt">Snapshots captured for /team:</span>',
          '2025-03-11  200  OK   <span class="hl">"Operations Manager: J. Halloran — j.halloran@acme-logistics.example"</span>',
          '2025-05-02  200  OK   "Operations Manager: (vacant)"',
          '2025-06-01  404  Not Found  <span class="alert">page removed</span>',
        ]} />
        <AnswerCheck
          prompt="Who was the Operations Manager named on the 11 March 2025 snapshot?"
          placeholder="surname is enough…"
          accepts={['halloran', 'j. halloran', 'j halloran']}
          hint="Read the earliest 200 OK snapshot."
          explain="Halloran. Archived snapshots routinely recover names, emails, and pages that organisations later remove — which is exactly why you screenshot and cite the snapshot URL and capture date."
          onResolved={(ok) => recordScore('l2-arch', ok)}
        />
        <Quiz
          onResolved={(ok) => recordScore('l2-cite', ok)}
          q={{
            prompt: 'When you put this finding in your report, what is the correct source citation?',
            options: [
              { id: 'a', label: '"I saw it on the Acme website."' },
              { id: 'b', label: 'The archive snapshot URL + the capture date (2025-03-11) + a screenshot.' },
              { id: 'c', label: 'The live /team URL, because that is the real source.' },
            ],
            correct: 'b',
            explain: 'The live URL 404s — citing it is unreproducible. Cite the exact snapshot URL, its capture date, and keep a screenshot. Web content changes; your record must let another analyst see exactly what you saw.',
          }}
        />
      </Panel>
    </StepBody>
  );
}

function FindingsLog({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Camera} label="Section 3 · The source record">
        <p>A finding without a source is a rumour. Every record needs four fields.</p>
        <Quiz multi
          onResolved={(ok) => recordScore('l2-fields', ok)}
          q={{
            prompt: 'Select the fields a complete source record must contain (choose all):',
            options: [
              { id: 'a', label: 'Exact query used' },
              { id: 'b', label: 'Result URL' },
              { id: 'c', label: 'Date/time of access' },
              { id: 'd', label: 'Screenshot or archived snapshot' },
              { id: 'e', label: 'Your personal opinion of the source' },
            ],
            correct: ['a', 'b', 'c', 'd'],
            explain: 'Query + URL + access timestamp + capture make a finding reproducible. Opinion belongs in the analysis section, never mixed into the evidence record.',
          }}
        />
      </Panel>
      <Panel label="The discipline that protects you">
        <Reflection
          prompt={'You find a forum post that perfectly supports your theory, but you cannot trace it to a primary source. How do you treat it in the report?'}
          placeholder="Write 2–3 sentences…"
          min={60}
          model={'Record it as an unconfirmed lead, clearly separated from verified findings, and note that it could not be corroborated to a primary source. Do not present it as fact. Treating an attractive but unverified claim as evidence is how confirmation bias and defamation slip in.'}
          onResolved={(ok) => recordScore('l2-reflect', ok)}
        />
      </Panel>
    </StepBody>
  );
}

const Checkpoint2 = makeCheckpoint(2);

export const lab2 = {
  steps: [
    { label: 'Briefing', taskCount: 0, component: Brief },
    { label: 'Operators', taskCount: 2, component: Operators },
    { label: 'Archive', taskCount: 2, component: ArchiveStep },
    { label: 'Source Record', taskCount: 2, component: FindingsLog },
    { label: 'Checkpoint', taskCount: 0, isQuiz: true, component: Checkpoint2 },
  ],
};
