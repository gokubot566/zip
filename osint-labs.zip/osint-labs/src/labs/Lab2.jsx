import React, { useState } from 'react';
import { Panel, Scenario, Briefing, StepBody, Terminal } from '../components/kit.jsx';
import { SearchConsole, SimTerminal, FieldProbe, ObjectiveBar } from '../components/simkit.jsx';
import { TeachingIntro, makeCheckpoint } from '../components/teaching.jsx';
import { Search, FileSearch, BookOpen, Archive, Camera } from 'lucide-react';

function Brief() {
  return (
    <StepBody>
      <TeachingIntro labId={2} />
      <Panel icon={Search} label="Practice Tasking · Acme Logistics">
        <Scenario who="Elena, OSINT Team Lead"
          text={'"Enough theory. You have an analyst workstation in front of you. Work this live against our fictional training company, Acme Logistics. I want you to actually run the queries — operators, not luck — recover what they deleted, and pull the real artefacts. Every objective below has to go green before you move on."'} />
      </Panel>
      <Panel icon={BookOpen} label="Operator reference">
        <Terminal title="reference://search-operators.md" lines={[
          '<span class="cmd">site:</span>acme-logistics.example        only results on this domain',
          '<span class="cmd">filetype:</span>pdf budget                 only PDF files',
          '<span class="cmd">intitle:</span>"price list"               phrase must be in the page title',
          '<span class="cmd">inurl:</span>admin                        term must be in the URL',
          '<span class="cmd">"exact phrase"</span>                      match the phrase verbatim',
          '<span class="cmd">-careers</span>                            exclude results with this word',
        ]} />
      </Panel>
    </StepBody>
  );
}

/* ---- Practical 1: live search console ---- */
function SearchPractical({ recordScore, onStepSolved }) {
  const corpus = [
    {
      title: 'Acme Logistics — 2025 Tariff Schedule (PDF)',
      url: 'acme-logistics.example/docs/tariff-2025.pdf',
      badge: 'PDF',
      requires: ['site:acme-logistics.example', 'filetype:pdf', 'tariff'],
      snippet: 'Effective 2025 freight <span class="hl">tariff</span> bands by zone and weight. Internal distribution — Finance & Ops.',
    },
    {
      title: 'Tariff FAQ — Acme Help Centre',
      url: 'acme-logistics.example/help/tariff-faq',
      requires: ['site:acme-logistics.example', 'tariff'],
      snippet: 'General customer questions about our <span class="hl">tariff</span> structure. (HTML page, not the schedule itself.)',
    },
    {
      title: 'Price List — Wholesale (page title match)',
      url: 'acme-logistics.example/wholesale',
      requires: ['intitle:"price list"'],
      badge: 'title hit',
      snippet: 'The page &lt;title&gt; contains the exact phrase <span class="hl">Price List</span> — this is the document itself, not a page that merely mentions pricing.',
    },
    {
      title: 'Industry blog: "comparing logistics price lists"',
      url: 'freightblog.example/compare',
      requires: ['price list'],
      snippet: 'A third-party blog that mentions price lists in the body text. Note: NOT on the Acme domain, and the phrase is not in the title.',
    },
  ];
  const [done, setDone] = useState(false);
  return (
    <StepBody>
      <Panel icon={FileSearch} label="Practical 1 · Run the searches">
        <p>Use the workstation search tool. Translate each objective into a precise operator query and run it. Results only surface when your query is tight enough.</p>
        <ObjectiveBar done={done} label="Surface the tariff PDF and the price-list title hit" />
        <SearchConsole
          corpus={corpus}
          placeholder='e.g. site:acme-logistics.example filetype:pdf tariff'
          hints={[
            'For the schedule itself, combine <span class="cmd">site:</span>, <span class="cmd">filetype:pdf</span> and the keyword <span class="cmd">tariff</span>.',
            'For the document whose <i>title</i> is the price list, use <span class="cmd">intitle:"price list"</span> — quotes force the exact phrase.',
          ]}
          objectives={[
            { id: 'pdf', label: 'Find the <b>tariff PDF</b> on the Acme domain',
              test: (q, res) => res.some(r => r.url.endsWith('tariff-2025.pdf')) },
            { id: 'title', label: 'Find the page whose <b>title</b> is &ldquo;Price List&rdquo;',
              test: (q, res) => res.some(r => r.url.endsWith('/wholesale')) },
          ]}
          onSolved={() => { setDone(true); recordScore('l2-search', true); onStepSolved && onStepSolved(); }}
        />
      </Panel>
    </StepBody>
  );
}

/* ---- Practical 2: live Wayback terminal ---- */
function ArchivePractical({ recordScore, onStepSolved }) {
  const [recovered, setRecovered] = useState(false);
  const [named, setNamed] = useState(false);
  const finish = () => { if (recovered && named) onStepSolved && onStepSolved(); };
  return (
    <StepBody>
      <Panel icon={Archive} label="Practical 2 · Recover what was removed">
        <p>The Acme staff page once named an operations manager, then it was scrubbed and the live page now 404s. Use the archive CLI to list snapshots and read the earliest live capture.</p>
        <SimTerminal
          prompt="analyst@osint:~$"
          height={300}
          intro={[
            'wayback-cli ready. The target is acme-logistics.example/team',
            'Try:  wayback list acme-logistics.example/team   then   wayback get <date> acme-logistics.example/team',
          ]}
          hints={[
            'List snapshots first: <span class="cmd">wayback list acme-logistics.example/team</span>',
            'Then read the earliest <span class="cmd">200 OK</span> capture: <span class="cmd">wayback get 2025-03-11 acme-logistics.example/team</span>',
          ]}
          commands={[
            { help: 'wayback list <url>', match: /^wayback\s+list\s+.*team/i, out: [
              '<span class="cmt">Snapshots for acme-logistics.example/team:</span>',
              '2025-03-11  <span class="hl">200 OK</span>',
              '2025-05-02  200 OK',
              '2025-06-01  <span class="alert">404 Not Found  (page removed)</span>',
            ] },
            { help: 'wayback get <date> <url>', match: /^wayback\s+get\s+2025-03-11\s+.*team/i, out: [
              '<span class="cmt"># snapshot 2025-03-11 — acme-logistics.example/team</span>',
              'Operations Manager: <span class="hl">J. Halloran</span> — j.halloran@acme-logistics.example',
              'Logistics Coordinator: P. Adeyemi',
            ] },
            { match: /^wayback\s+get\s+2025-06-01/i, out: ['<span class="alert">404 — that snapshot is the removed page; nothing to read.</span>'] },
            { match: /^wayback\s+get\s+2025-05-02/i, out: ['Operations Manager: <span class="cmt">(vacant)</span>  — the name was already gone by this capture.'] },
          ]}
          objectives={[
            { id: 'list', label: 'List the snapshots for <span class="cmd">/team</span>',
              test: (log) => log.some(c => /wayback\s+list/i.test(c)) },
            { id: 'read', label: 'Read the earliest <b>200 OK</b> capture (2025-03-11)',
              test: (log) => log.some(c => /wayback\s+get\s+2025-03-11/i.test(c)) },
          ]}
          onSolved={() => { setRecovered(true); recordScore('l2-arch', true); finish(); }}
        />
        <FieldProbe
          prompt="Read the snapshot above. Name the Operations Manager (surname is enough):"
          accepts={['halloran', 'j. halloran', 'j halloran']}
          placeholder="surname…"
          explain="Halloran. Archived captures routinely recover names, emails, and pages an org later deletes — which is exactly why you cite the snapshot URL + capture date and keep a screenshot, never the live URL that now 404s."
          onSolved={() => { setNamed(true); recordScore('l2-name', true); finish(); }}
        />
      </Panel>
    </StepBody>
  );
}

/* ---- Practical 3: build a source record ---- */
function SourceRecord({ recordScore, onStepSolved }) {
  const [ok, setOk] = useState(false);
  return (
    <StepBody>
      <Panel icon={Camera} label="Practical 3 · Write the source record">
        <p>A finding without a source is a rumour. Reconstruct the citation for the Halloran finding the way another analyst could reproduce it. Type the citation — it must reference the <b>snapshot</b> and the <b>capture date</b> (not the live URL).</p>
        <ObjectiveBar done={ok} label="Produce a reproducible source record" />
        <FieldProbe
          prompt="Citation for the Operations Manager finding:"
          mono={false}
          placeholder="e.g. wayback snapshot of /team captured 2025-03-11, screenshot saved…"
          accepts={['2025-03-11', 'snapshot 2025-03-11', 'wayback 2025-03-11', 'capture 2025-03-11']}
          explain="A complete record = exact source (the archive snapshot of /team), the capture date 2025-03-11, and a screenshot. Citing the live /team URL is unreproducible because it now 404s — the content is gone unless you pinned the snapshot."
          onSolved={() => { setOk(true); recordScore('l2-cite', true); onStepSolved && onStepSolved(); }}
        />
      </Panel>
    </StepBody>
  );
}

const Checkpoint2 = makeCheckpoint(2);

export const lab2 = {
  steps: [
    { label: 'Briefing', taskCount: 0, component: Brief },
    { label: 'Search', taskCount: 1, gated: true, component: SearchPractical },
    { label: 'Archive', taskCount: 2, gated: true, component: ArchivePractical },
    { label: 'Source Record', taskCount: 1, gated: true, component: SourceRecord },
    { label: 'Checkpoint', taskCount: 0, isQuiz: true, component: Checkpoint2 },
  ],
};
