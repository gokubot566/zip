import React from 'react';
import { Panel, Scenario, Briefing, Quiz, AnswerCheck, DataTable, Classifier, Reflection, StepBody, Terminal } from '../components/kit.jsx';
import { TeachingIntro, makeCheckpoint } from '../components/teaching.jsx';
import { Globe, Server, GitFork, ListTree, BookOpen } from 'lucide-react';

function Brief() {
  return (
    <StepBody>
      
      <TeachingIntro labId={4} />
<Panel icon={Globe} label="SOC Hand-off · Phishing Attribution">
        <Scenario who="Sarah, Team Lead"
          text={'"Someone registered a domain to target us — merid1an-secure.com — and ran a phishing campaign. The campaign is over; I want attribution. Learn everything we can from public records: who registered it, on what hosting, behind which name servers, sharing which IP, and whether it is part of a bigger cluster of lookalikes. Build the infrastructure picture and a clean IOC list for the SOC to block."'} />
      </Panel>
      <Panel icon={BookOpen} label="Objectives">
        <Briefing items={[
          'Interpret WHOIS / DNS even when registration is privacy-protected',
          'Use passive DNS, reverse-IP, and certificate transparency to find related infrastructure',
          'Pivot on shared artefacts to surface the adversary\u2019s domain cluster',
          'Produce an IOC list ready for SOC blocking',
        ]} />
      </Panel>
    </StepBody>
  );
}

function Recon({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Server} label="Section 1 · Registration & DNS">
        <Terminal title="whois merid1an-secure.com" lines={[
          'Domain Name:   MERID1AN-SECURE.COM',
          'Registrar:     CheapNames LLC',
          'Created:       2025-05-28      <span class="cmt"># 3 days before the campaign</span>',
          'Registrant:    <span class="alert">REDACTED FOR PRIVACY</span>',
          'Name Server:   NS1.BULLETHOST.example',
          'Name Server:   NS2.BULLETHOST.example',
        ]} />
        <Terminal title="dig merid1an-secure.com ANY +short" lines={[
          'A      <span class="hl">185.62.44.10</span>',
          'MX     mail.bullethost.example',
          'TXT    "v=spf1 include:bullethost.example ~all"',
        ]} />
        <AnswerCheck
          prompt="Registration is privacy-redacted. What hosting IP does the domain resolve to (a usable pivot point)?"
          placeholder="IPv4…"
          accepts={['185.62.44.10']}
          hint="Read the A record."
          explain="185.62.44.10. When the registrant is hidden, you pivot on what is NOT hidden: the IP, name servers, and certificates. Privacy protection rarely defeats correlation."
          onResolved={(ok) => recordScore('l4-ip', ok)}
        />
      </Panel>
    </StepBody>
  );
}

function Pivot({ recordScore }) {
  const cols = [
    { key: 'dom', label: 'Domain' }, { key: 'ip', label: 'IP' },
    { key: 'ns', label: 'Name server' }, { key: 'cert', label: 'Cert fingerprint' },
  ];
  const rows = [
    { dom: 'merid1an-secure.com', ip: '185.62.44.10', ns: 'BULLETHOST', cert: 'a91f…', _cls: { dom: 'flag' } },
    { dom: 'merid1an-docs.com', ip: '185.62.44.10', ns: 'BULLETHOST', cert: 'a91f…', _cls: { dom: 'flag' } },
    { dom: 'meridian-portal-login.com', ip: '185.62.44.10', ns: 'BULLETHOST', cert: 'a91f…', _cls: { dom: 'flag' } },
    { dom: 'meridiancareers.com.au', ip: '52.18.7.3', ns: 'AWS-DNS', cert: 'c70b…', _cls: { dom: '' } },
    { dom: 'meridian-invest.net', ip: '185.62.44.10', ns: 'BULLETHOST', cert: 'a91f…', _cls: { dom: 'flag' } },
  ];
  return (
    <StepBody>
      <Panel icon={GitFork} label="Section 2 · Reverse-IP & certificate transparency">
        <p>Reverse-IP on 185.62.44.10 and the certificate-transparency log both returned this set. Find the cluster.</p>
        <DataTable columns={cols} rows={rows} />
        <Quiz multi
          onResolved={(ok) => recordScore('l4-cluster', ok)}
          q={{
            prompt: 'Which domains belong to the SAME adversary cluster (shared IP + name server + cert)? Select all.',
            options: [
              { id: 'a', label: 'merid1an-secure.com' },
              { id: 'b', label: 'merid1an-docs.com' },
              { id: 'c', label: 'meridian-portal-login.com' },
              { id: 'd', label: 'meridiancareers.com.au' },
              { id: 'e', label: 'meridian-invest.net' },
            ],
            correct: ['a', 'b', 'c', 'e'],
            explain: 'Four domains share IP 185.62.44.10, the BULLETHOST name servers, and certificate a91f… — that triple match clusters them to one actor. meridiancareers.com.au is on different AWS infrastructure with a different cert: a legitimate (or unrelated) domain, not part of the cluster. Pivoting on one domain just exposed four.',
          }}
        />
      </Panel>
    </StepBody>
  );
}

function IOCStep({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={ListTree} label="Section 3 · Build the IOC package">
        <p>Classify each candidate as a blockable IOC or NOT (to avoid blocking a legitimate asset).</p>
        <Classifier
          onResolved={(ok) => recordScore('l4-ioc', ok)}
          categories={[{ id: 'ioc', label: 'Block (IOC)' }, { id: 'no', label: 'Do NOT block' }]}
          items={[
            { id: 'a', text: '185.62.44.10 (host of four lookalike domains)' },
            { id: 'b', text: 'merid1an-docs.com' },
            { id: 'c', text: 'NS1/NS2.BULLETHOST.example (cluster name servers)' },
            { id: 'd', text: 'meridiancareers.com.au (different infra, different cert)' },
            { id: 'e', text: 'cert fingerprint a91f… (shared by the cluster)' },
          ]}
          answer={{ a: 'ioc', b: 'ioc', c: 'ioc', d: 'no', e: 'ioc' }}
          explain={'Block the shared IP, the lookalike domains, the cluster name servers, and the shared cert. Do NOT block meridiancareers.com.au — different infrastructure and certificate; blocking it could take down a legitimate service and is a classic false-positive from sloppy clustering.'}
        />
      </Panel>
      <Panel label="Analyst note">
        <Reflection
          prompt={'The WHOIS was fully privacy-protected. Name the public data points you used instead to attribute related infrastructure, and why correlation beats relying on a name in WHOIS.'}
          placeholder="Write 2–3 sentences…"
          min={70}
          model={'I pivoted on the hosting IP, the shared name servers, and the certificate-transparency fingerprint — none of which privacy protection hides. Modern attribution is correlation: shared infrastructure and reused certificates link domains far more reliably than a registrant name, which is usually redacted or fake anyway.'}
          onResolved={(ok) => recordScore('l4-note', ok)}
        />
      </Panel>
    </StepBody>
  );
}

const Checkpoint4 = makeCheckpoint(4);

export const lab4 = {
  steps: [
    { label: 'Briefing', taskCount: 0, component: Brief },
    { label: 'Recon', taskCount: 1, component: Recon },
    { label: 'Pivot & Cluster', taskCount: 1, component: Pivot },
    { label: 'IOC Package', taskCount: 2, component: IOCStep },
    { label: 'Checkpoint', taskCount: 0, isQuiz: true, component: Checkpoint4 },
  ],
};
