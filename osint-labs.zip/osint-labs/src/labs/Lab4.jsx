import React, { useState } from 'react';
import { Panel, Scenario, Briefing, DataTable, Classifier, StepBody } from '../components/kit.jsx';
import { SimTerminal, FieldProbe, ObjectiveBar } from '../components/simkit.jsx';
import { TeachingIntro, makeCheckpoint } from '../components/teaching.jsx';
import { Globe, Server, GitFork, ListTree, BookOpen } from 'lucide-react';

function Brief() {
  return (
    <StepBody>
      <TeachingIntro labId={4} />
      <Panel icon={Globe} label="SOC Hand-off · Phishing Attribution">
        <Scenario who="Marcus, Infrastructure & Network Analyst"
          text={'"Someone registered merid1an-secure.com and phished us. Campaign is over; I want attribution. You have a live recon shell — actually run the lookups. Pull the registration and DNS, pivot on the IP and the certificate, and surface the rest of the cluster. Then hand me a clean IOC list. Do not block anything legitimate."'} />
      </Panel>
      <Panel icon={BookOpen} label="Recon shell — available tools">
        <Briefing items={[
          'whois <domain> — registration record (often privacy-redacted)',
          'dig <domain> [ANY|A|MX|TXT] — DNS records',
          'reverse-ip <ip> — other domains hosted on the same IP',
          'ct-logs <domain> — certificate-transparency search for shared certs',
        ]} />
      </Panel>
    </StepBody>
  );
}

/* ---- Practical 1: live whois + dig ---- */
function ReconPractical({ recordScore, onStepSolved }) {
  const [ipFound, setIpFound] = useState(false);
  const [probed, setProbed] = useState(false);
  const finish = () => { if (ipFound && probed) onStepSolved && onStepSolved(); };
  return (
    <StepBody>
      <Panel icon={Server} label="Practical 1 · Registration & DNS">
        <p>Run <span className="kbd">whois</span> then <span className="kbd">dig</span> on the phishing domain. The registrant is privacy-protected — find the pivot points that are <i>not</i> hidden.</p>
        <SimTerminal
          prompt="analyst@recon:~$"
          height={340}
          intro={['Recon shell. Target: merid1an-secure.com', 'Type  help  for tools, or start with  whois merid1an-secure.com']}
          hints={[
            'Registration: <span class="cmd">whois merid1an-secure.com</span>',
            'DNS / hosting IP: <span class="cmd">dig merid1an-secure.com ANY</span> (or <span class="cmd">dig merid1an-secure.com A</span>)',
          ]}
          commands={[
            { help: 'whois <domain>', match: /^whois\s+merid1an-secure\.com/i, out: [
              'Domain Name:   MERID1AN-SECURE.COM',
              'Registrar:     CheapNames LLC',
              'Created:       2025-05-28   <span class="cmt"># 3 days before the campaign</span>',
              'Registrant:    <span class="alert">REDACTED FOR PRIVACY</span>',
              'Name Server:   NS1.BULLETHOST.example',
              'Name Server:   NS2.BULLETHOST.example',
            ] },
            { help: 'dig <domain> [TYPE]', match: /^dig\s+merid1an-secure\.com/i, out: [
              ';; ANSWER SECTION:',
              'merid1an-secure.com.   A     <span class="hl">185.62.44.10</span>',
              'merid1an-secure.com.   MX    mail.bullethost.example',
              'merid1an-secure.com.   TXT   "v=spf1 include:bullethost.example ~all"',
            ] },
            { match: /^whois\s+/i, out: ['<span class="alert">No record / out of scope for this exercise. Target is merid1an-secure.com</span>'] },
            { match: /^dig\s+/i, out: ['<span class="alert">No answer. Target is merid1an-secure.com</span>'] },
          ]}
          objectives={[
            { id: 'whois', label: 'Run <span class="cmd">whois</span> on the phishing domain',
              test: (log) => log.some(c => /^whois\s+merid1an-secure\.com/i.test(c)) },
            { id: 'dig', label: 'Resolve its DNS with <span class="cmd">dig</span>',
              test: (log) => log.some(c => /^dig\s+merid1an-secure\.com/i.test(c)) },
          ]}
          onSolved={() => { setIpFound(true); recordScore('l4-recon', true); finish(); }}
        />
        <FieldProbe
          prompt="Registration is redacted. What hosting IP does the domain resolve to (your pivot point)?"
          accepts={['185.62.44.10']}
          placeholder="IPv4…"
          explain="185.62.44.10. When the registrant is hidden you pivot on what is not: the IP, the name servers, and certificates. Privacy protection rarely defeats correlation."
          onSolved={() => { setProbed(true); recordScore('l4-ip', true); finish(); }}
        />
      </Panel>
    </StepBody>
  );
}

/* ---- Practical 2: pivot via reverse-ip + ct-logs ---- */
function PivotPractical({ recordScore, onStepSolved }) {
  const [ran, setRan] = useState(false);
  const [clustered, setClustered] = useState(false);
  const finish = () => { if (ran && clustered) onStepSolved && onStepSolved(); };
  const cols = [
    { key: 'dom', label: 'Domain' }, { key: 'ip', label: 'IP' },
    { key: 'ns', label: 'Name server' }, { key: 'cert', label: 'Cert' },
  ];
  const rows = [
    { dom: 'merid1an-secure.com', ip: '185.62.44.10', ns: 'BULLETHOST', cert: 'a91f…', _cls: { dom: 'flag' } },
    { dom: 'merid1an-docs.com', ip: '185.62.44.10', ns: 'BULLETHOST', cert: 'a91f…', _cls: { dom: 'flag' } },
    { dom: 'meridian-portal-login.com', ip: '185.62.44.10', ns: 'BULLETHOST', cert: 'a91f…', _cls: { dom: 'flag' } },
    { dom: 'meridiancareers.com.au', ip: '52.18.7.3', ns: 'AWS-DNS', cert: 'c70b…', _cls: { dom: '' } },
    { dom: 'meridian-invest.net', ip: '185.62.44.10', ns: 'BULLETHOST', cert: 'a91f…', _cls: { dom: 'flag' } },
  ];
  return (
    <StepBody>
      <Panel icon={GitFork} label="Practical 2 · Reverse-IP & certificate transparency">
        <p>Pivot on the IP and the cert. Run both lookups, read the table they return, then identify the cluster.</p>
        <SimTerminal
          prompt="analyst@recon:~$"
          height={300}
          intro={['Pivot on 185.62.44.10 and the cert from merid1an-secure.com.']}
          hints={[
            'Other domains on the IP: <span class="cmd">reverse-ip 185.62.44.10</span>',
            'Shared certificates: <span class="cmd">ct-logs merid1an-secure.com</span>',
          ]}
          commands={[
            { help: 'reverse-ip <ip>', match: /^reverse-ip\s+185\.62\.44\.10/i, out: [
              '<span class="cmt">Domains resolving to 185.62.44.10:</span>',
              'merid1an-secure.com',
              'merid1an-docs.com',
              'meridian-portal-login.com',
              'meridian-invest.net',
              '<span class="cmt"># 4 domains share this host</span>',
            ] },
            { help: 'ct-logs <domain>', match: /^ct-logs\s+merid1an-secure\.com/i, out: [
              '<span class="cmt">Certificate-transparency matches (fingerprint a91f…):</span>',
              'merid1an-secure.com, merid1an-docs.com, meridian-portal-login.com, meridian-invest.net',
              '<span class="cmt"># meridiancareers.com.au uses a DIFFERENT cert (c70b…) on AWS</span>',
            ] },
            { match: /^reverse-ip\s+/i, out: ['No shared hosts found for that IP in scope.'] },
            { match: /^ct-logs\s+/i, out: ['No CT matches for that domain in scope.'] },
          ]}
          objectives={[
            { id: 'rip', label: 'Run <span class="cmd">reverse-ip</span> on the hosting IP',
              test: (log) => log.some(c => /^reverse-ip\s+185\.62\.44\.10/i.test(c)) },
            { id: 'ct', label: 'Search certificate transparency with <span class="cmd">ct-logs</span>',
              test: (log) => log.some(c => /^ct-logs\s+merid1an-secure\.com/i.test(c)) },
          ]}
          onSolved={() => { setRan(true); recordScore('l4-pivot', true); finish(); }}
        />
        <Panel label="Consolidated infrastructure view" soft>
          <DataTable columns={cols} rows={rows} />
          <Classifier
            onResolved={(ok) => { recordScore('l4-cluster', ok); if (ok) { setClustered(true); finish(); } }}
            categories={[{ id: 'in', label: 'Same cluster' }, { id: 'out', label: 'Unrelated' }]}
            items={[
              { id: 'a', text: 'merid1an-secure.com' },
              { id: 'b', text: 'merid1an-docs.com' },
              { id: 'c', text: 'meridian-portal-login.com' },
              { id: 'd', text: 'meridiancareers.com.au' },
              { id: 'e', text: 'meridian-invest.net' },
            ]}
            answer={{ a: 'in', b: 'in', c: 'in', d: 'out', e: 'in' }}
            explain={'Four domains share IP 185.62.44.10, the BULLETHOST name servers AND certificate a91f… — that triple match clusters them to one actor. meridiancareers.com.au is on separate AWS infrastructure with a different cert: not part of the cluster. One pivot exposed four.'}
          />
        </Panel>
      </Panel>
    </StepBody>
  );
}

/* ---- Practical 3: IOC package ---- */
function IOCStep({ recordScore, onStepSolved }) {
  return (
    <StepBody>
      <Panel icon={ListTree} label="Practical 3 · Build the IOC package">
        <p>Classify each candidate as a blockable IOC or NOT — blocking a legitimate asset is a real incident in itself.</p>
        <Classifier
          onResolved={(ok) => { recordScore('l4-ioc', ok); if (ok) onStepSolved && onStepSolved(); }}
          categories={[{ id: 'ioc', label: 'Block (IOC)' }, { id: 'no', label: 'Do NOT block' }]}
          items={[
            { id: 'a', text: '185.62.44.10 (host of four lookalike domains)' },
            { id: 'b', text: 'merid1an-docs.com' },
            { id: 'c', text: 'NS1/NS2.BULLETHOST.example (cluster name servers)' },
            { id: 'd', text: 'meridiancareers.com.au (different infra, different cert)' },
            { id: 'e', text: 'cert fingerprint a91f… (shared by the cluster)' },
          ]}
          answer={{ a: 'ioc', b: 'ioc', c: 'ioc', d: 'no', e: 'ioc' }}
          explain={'Block the shared IP, the lookalike domains, the cluster name servers, and the shared cert. Do NOT block meridiancareers.com.au — different infrastructure and certificate; blocking it could take down a legitimate service, the classic false-positive from sloppy clustering.'}
        />
      </Panel>
    </StepBody>
  );
}

const Checkpoint4 = makeCheckpoint(4);

export const lab4 = {
  steps: [
    { label: 'Briefing', taskCount: 0, component: Brief },
    { label: 'Recon', taskCount: 2, gated: true, component: ReconPractical },
    { label: 'Pivot & Cluster', taskCount: 2, gated: true, component: PivotPractical },
    { label: 'IOC Package', taskCount: 1, gated: true, component: IOCStep },
    { label: 'Checkpoint', taskCount: 0, isQuiz: true, component: Checkpoint4 },
  ],
};
