import React from 'react';
import { Panel, Scenario, Briefing, Quiz, AnswerCheck, DataTable, Classifier, Reflection, EthicsGate, StepBody, Terminal } from '../components/kit.jsx';
import { Briefcase, Layers, AlertTriangle, FileCheck, BookOpen } from 'lucide-react';

function Brief() {
  return (
    <StepBody>
      <Panel icon={Briefcase} label="Deals Team · Counterparty Due Diligence">
        <Scenario who="Sarah, Team Lead"
          text={'"This one is for the deals team, and it stays professional and lawful. Meridian is considering a partnership with Northwind Capital. Before any money moves, leadership wants independent due diligence from public sources. Who really owns and controls this company? Are the directors who they claim to be? Any litigation, sanctions, adverse media, red flags? And critically — separate what you can prove from what is merely rumour. I need a defensible report, not gossip. Document every source."'} />
      </Panel>
      <Panel icon={BookOpen} label="Objectives">
        <Briefing items={[
          'Verify registration, structure, and beneficial ownership from public registries',
          'Check litigation, insolvency, sanctions, and adverse media',
          'Avoid same-name misattribution — the cardinal sin of people OSINT',
          'Separate verified fact from unconfirmed lead, with full citations',
        ]} />
      </Panel>
    </StepBody>
  );
}

function Ownership({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Layers} label="Section 1 · Beneficial ownership">
        <Terminal title="registry://northwind-capital" lines={[
          'Northwind Capital Pty Ltd',
          '  Director:        R. Mosely',
          '  Shareholder:     <span class="hl">Aldgate Nominees Pty Ltd  (100%)</span>',
          '',
          'Aldgate Nominees Pty Ltd',
          '  Director:        R. Mosely',
          '  Shareholder:     <span class="hl">Greyfields Holdings Ltd (BVI)  (100%)</span>',
          '',
          'Greyfields Holdings Ltd (BVI)',
          '  Beneficial owner: <span class="alert">V. Castellan</span>  (per BVI register extract)',
        ]} />
        <AnswerCheck
          prompt="Trace the chain: who is the ultimate beneficial owner behind the nominee layers?"
          placeholder="name…"
          accepts={['castellan', 'v. castellan', 'v castellan']}
          hint="Follow the 100% shareholder up each level to the BVI register."
          explain="V. Castellan. The director (Mosely) is the visible face; the real control runs Northwind → Aldgate Nominees → Greyfields (BVI) → Castellan. Nominee and offshore layers are exactly what beneficial-ownership tracing is for."
          onResolved={(ok) => recordScore('l7-ubo', ok)}
        />
      </Panel>
    </StepBody>
  );
}

function Risk({ recordScore }) {
  const cols = [{ key: 'hit', label: 'Adverse-media / screen hit' }, { key: 'detail', label: 'Detail' }];
  const rows = [
    { hit: 'Court record', detail: 'Northwind Capital Pty Ltd — 2023 contract dispute, settled', _cls: { hit: 'flag' } },
    { hit: 'News article', detail: '"V. Castellan" fraud conviction — but a 71yo in Ohio, USA', _cls: { hit: 'bad' } },
    { hit: 'Sanctions screen', detail: '"Viktor Castellan" on a watchlist — DOB 1958, Russia', _cls: { hit: 'bad' } },
    { hit: 'Adverse media', detail: 'Our V. Castellan (DOB 1979, Sydney) — prior insolvency, 2019', _cls: { hit: 'flag' } },
  ];
  return (
    <StepBody>
      <Panel icon={AlertTriangle} label="Section 2 · Risk & the same-name trap">
        <DataTable columns={cols} rows={rows} />
        <Classifier
          onResolved={(ok) => recordScore('l7-samename', ok)}
          categories={[{ id: 'real', label: 'Same person (use)' }, { id: 'decoy', label: 'Same-name decoy (exclude)' }]}
          items={[
            { id: 'a', text: 'The 2023 contract dispute naming Northwind Capital Pty Ltd directly.' },
            { id: 'b', text: 'The fraud-conviction article about a 71-year-old V. Castellan in Ohio.' },
            { id: 'c', text: 'The sanctions hit on Viktor Castellan, DOB 1958, Russia.' },
            { id: 'd', text: 'The 2019 insolvency of our V. Castellan, DOB 1979, Sydney.' },
          ]}
          answer={{ a: 'real', b: 'decoy', c: 'decoy', d: 'real' }}
          explain={'The contract dispute names the entity itself, and the 2019 insolvency matches our subject\u2019s DOB and city — both usable. The Ohio fraud and the Russian sanctions entry share only the NAME; different age, country, identifiers. Reporting them would defame an innocent party and could sink a legitimate deal. Verify identity before recording any adverse hit.'}
        />
      </Panel>
      <EthicsGate
        scenario={'The sanctions hit on "Viktor Castellan" would make leadership kill the deal instantly. It is tempting to include it. What is correct?'}
        options={[
          { id: 'a', label: 'Include it — let leadership decide; better safe than sorry.' },
          { id: 'b', label: 'Exclude it; the DOB/country do not match our subject. Note it was checked and ruled out as a same-name false positive.' },
          { id: 'c', label: 'Include it but in small print.' },
        ]}
        correct="b"
        explain={'Including an unmatched sanctions entry as if it were the subject is a serious misattribution that could defame someone and expose Meridian to liability. The professional record states that the watchlist was screened and the hit was excluded on identity grounds.'}
        onResolved={(ok) => recordScore('l7-ethics', ok)}
      />
    </StepBody>
  );
}

function Report({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={FileCheck} label="Section 3 · Defensible report">
        <Quiz
          onResolved={(ok) => recordScore('l7-struct', ok)}
          q={{
            prompt: 'Which statement belongs in the "verified facts" section, not "unconfirmed leads"?',
            options: [
              { id: 'a', label: '"A forum user claims Castellan is being investigated overseas."' },
              { id: 'b', label: '"Greyfields Holdings (BVI) is the 100% parent of Aldgate Nominees, per the registry extracts dated 2025-06-02."' },
              { id: 'c', label: '"Castellan is probably hiding assets."' },
            ],
            correct: 'b',
            explain: 'Only (b) is sourced and verifiable. (a) is an unconfirmed lead — kept separate. (c) is a judgement/speculation, not a fact, and must be labelled as analysis with stated confidence if included at all.',
          }}
        />
      </Panel>
      <Panel label="Write the bottom line">
        <Reflection
          prompt={'Draft the report\u2019s overall risk assessment: verified ownership/risk facts, the excluded same-name hits, and one clearly-labelled judgement.'}
          placeholder="Verified: UBO is V. Castellan (Sydney, DOB 1979) via Greyfields BVI; 2019 insolvency; 2023 settled dispute. Excluded as same-name: …"
          min={100}
          model={'Verified facts (cited): ultimate beneficial owner is V. Castellan (Sydney, DOB 1979) via a nominee/BVI chain; one prior personal insolvency (2019); one settled corporate contract dispute (2023). Screened and excluded as same-name false positives: an Ohio fraud conviction and a Russian sanctions entry — different DOB and country. Judgement (moderate confidence): the offshore nominee structure plus the prior insolvency warrant enhanced terms and a beneficial-ownership warranty before proceeding — this is analysis, not proof of wrongdoing.'}
          onResolved={(ok) => recordScore('l7-report', ok)}
        />
      </Panel>
    </StepBody>
  );
}

export const lab7 = {
  steps: [
    { label: 'Briefing', taskCount: 0, component: Brief },
    { label: 'Ownership', taskCount: 1, component: Ownership },
    { label: 'Risk & Same-name', taskCount: 2, component: Risk },
    { label: 'Report', taskCount: 2, component: Report },
  ],
};
