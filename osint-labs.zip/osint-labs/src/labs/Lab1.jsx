import React from 'react';
import { Panel, Scenario, Briefing, Quiz, Classifier, Reflection, EthicsGate, StepBody, Terminal } from '../components/kit.jsx';
import { Compass, BookOpen, Scale, GitBranch, PenLine } from 'lucide-react';

function Brief() {
  return (
    <StepBody>
      <Panel icon={Compass} label="Day One · Tasking">
        <Scenario who="Sarah, Threat Intelligence Team Lead"
          text={'"Before you run a single search, I need you to understand how we actually do OSINT here. It is not just Googling people. We follow the intelligence cycle — we plan, we collect, we process, we analyse, and we disseminate. Read our methodology and our legal-and-ethics policy, then map three past requests to the right stage of the cycle. If you can tell me where we were at each decision point — and which collection was in-scope versus off-limits — you are ready for real tasking."'} />
      </Panel>
      <Panel icon={BookOpen} label="What you will master">
        <Briefing items={[
          'The five stages of the OSINT intelligence cycle and what happens in each',
          'The difference between passive collection, active collection, and out-of-scope actions',
          'Classifying a request by sensitivity and applying the correct handling rules',
          'Why a structured method and hard ethical boundaries beat ad-hoc searching',
        ]} />
      </Panel>
    </StepBody>
  );
}

function CycleStudy({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={GitBranch} label="Section 1 · The Intelligence Cycle">
        <p>Five stages, repeated as a loop. Read the reference, then place each activity.</p>
        <Terminal title="reference://intelligence-cycle.md" lines={[
          '<span class="hl">1. PLANNING & DIRECTION</span>  define the question, scope, and ethics boundaries',
          '<span class="hl">2. COLLECTION</span>           gather raw public data from sources',
          '<span class="hl">3. PROCESSING</span>           organise, translate, dedupe, structure the raw data',
          '<span class="hl">4. ANALYSIS</span>             turn processed data into assessed, sourced findings',
          '<span class="hl">5. DISSEMINATION</span>        deliver the product to the decision-maker; gather feedback',
        ]} />
      </Panel>
      <Panel label="Place each activity in the right stage">
        <Classifier
          onResolved={(ok) => recordScore('l1-cycle', ok)}
          categories={[
            { id: 'plan', label: 'Planning' }, { id: 'coll', label: 'Collection' },
            { id: 'proc', label: 'Processing' }, { id: 'ana', label: 'Analysis' }, { id: 'diss', label: 'Dissemination' },
          ]}
          items={[
            { id: 'a', text: 'Agreeing with the fraud team exactly what they need to know and what is off-limits.' },
            { id: 'b', text: 'Running WHOIS, archive, and username searches and saving the raw results.' },
            { id: 'c', text: 'De-duplicating 200 saved results and normalising timestamps to UTC.' },
            { id: 'd', text: 'Concluding the vendor is "probably the same actor as the phishing domain, moderate confidence".' },
            { id: 'e', text: 'Sending the briefing to leadership and asking what else they need next.' },
          ]}
          answer={{ a: 'plan', b: 'coll', c: 'proc', d: 'ana', e: 'diss' }}
          explain={'The cycle is not always linear in practice, but you should always know which stage you are in. Concluding before processing, or collecting before planning scope, is how investigations go wrong.'}
        />
      </Panel>
    </StepBody>
  );
}

function PassiveActive({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Scale} label="Section 2 · Passive · Active · Out-of-scope">
        <p>OSINT is publicly available information collected lawfully and without deception. Classify each proposed action.</p>
        <Classifier
          onResolved={(ok) => recordScore('l1-pa', ok)}
          categories={[
            { id: 'pass', label: 'Passive (OK)' },
            { id: 'act', label: 'Active (caution)' },
            { id: 'out', label: 'Out-of-scope (NO)' },
          ]}
          items={[
            { id: 'a', text: 'Reading a subject\u2019s public LinkedIn posts without an account.' },
            { id: 'b', text: 'Sending the subject a connection request from a fake persona to see more.' },
            { id: 'c', text: 'Trying the subject\u2019s leaked password against their live email account.' },
            { id: 'd', text: 'Emailing a company\u2019s public sales line to ask which CRM they use.' },
            { id: 'e', text: 'Viewing cached copies of a deleted page via the Wayback Machine.' },
          ]}
          answer={{ a: 'pass', b: 'out', c: 'out', d: 'act', e: 'pass' }}
          explain={'Fake-account engagement and credential testing are not OSINT — they are deception and unauthorised access. Direct contact (the sales call) is "active": sometimes legitimate, but it touches the target and must be authorised and lawful. Passive observation of public data and archives is the safe default.'}
        />
      </Panel>
      <EthicsGate
        scenario={'Mid-investigation you realise that creating one fake social account and friend-requesting the subject would unlock everything you need in five minutes. The deadline is tight. What do you do?'}
        options={[
          { id: 'a', label: 'Create the account just this once — the value is too high to pass up.' },
          { id: 'b', label: 'Do not. Document the limit, report what public sources allow, and flag the gap to the requester.' },
          { id: 'c', label: 'Ask a colleague to do it so it is not on your account.' },
        ]}
        correct="b"
        explain={'The moment you deceive a target to gain access, it stops being OSINT and may be unlawful and a platform-terms violation — regardless of who clicks the button or how valuable the data is. The professional move is to state the boundary and report the gap.'}
        onResolved={(ok) => recordScore('l1-ethics', ok)}
      />
    </StepBody>
  );
}

function CaseMap({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={BookOpen} label="Section 3 · Case Review">
        <p>Past request: <b>brand-impersonation investigation</b>. Classify it by sensitivity, then catch the analyst\u2019s mistake.</p>
        <Quiz
          onResolved={(ok) => recordScore('l1-sens', ok)}
          q={{
            prompt: 'The request involves naming individuals who may be running a fraud, and findings may go to legal. How should it be classified for handling?',
            options: [
              { id: 'a', label: 'Routine — public info, no special handling.' },
              { id: 'b', label: 'Sensitive — name third parties, restrict access, evidence-grade sourcing, legal hold likely.' },
              { id: 'c', label: 'Public — can be shared freely once complete.' },
            ],
            correct: 'b',
            explain: 'Anything that names individuals, may affect employment or legal proceedings, or could defame a third party demands the highest handling discipline: restricted access, full source records, and clean fact/judgement separation.',
          }}
        />
      </Panel>
      <Panel label="Spot the boundary breach in the case timeline">
        <Quiz
          onResolved={(ok) => recordScore('l1-breach', ok)}
          q={{
            prompt: 'Which timeline entry should have been stopped and flagged?',
            options: [
              { id: 'a', label: '09:10 — Searched certificate-transparency logs for the lookalike domain.' },
              { id: 'b', label: '09:35 — Created a burner Instagram and DM\u2019d the suspected operator posing as a customer.' },
              { id: 'c', label: '10:02 — Saved screenshots of the public spoofed brand page with timestamps.' },
            ],
            correct: 'b',
            explain: 'Posing as a customer to engage the target is pretexting / active deception — out of scope for OSINT. The other two are passive, lawful, well-documented collection.',
          }}
        />
      </Panel>
      <Panel icon={PenLine} label="Reflection">
        <Reflection
          prompt={'In your own words: why does a structured cycle plus hard ethical boundaries produce better outcomes than "just searching"?'}
          placeholder="Write 2–3 sentences…"
          min={60}
          model={'A defined question and scope stop you boiling the ocean; processing before analysis stops premature conclusions; documented sourcing makes findings defensible; and a hard ethics line keeps the work lawful and protects innocent third parties. Together they turn curiosity into intelligence leadership can act on.'}
          onResolved={(ok) => recordScore('l1-reflect', ok)}
        />
      </Panel>
    </StepBody>
  );
}

export const lab1 = {
  steps: [
    { label: 'Briefing', taskCount: 0, component: Brief },
    { label: 'The Cycle', taskCount: 1, component: CycleStudy },
    { label: 'Boundaries', taskCount: 2, component: PassiveActive },
    { label: 'Case Review', taskCount: 3, component: CaseMap },
  ],
};
