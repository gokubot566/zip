import React from 'react';
import { Panel, Scenario, Briefing, Quiz, Classifier, EthicsGate, DataTable, Reflection, StepBody, Terminal } from '../components/kit.jsx';
import { TeachingIntro, makeCheckpoint } from '../components/teaching.jsx';
import { Users, Building2, EyeOff, Megaphone, BookOpen } from 'lucide-react';

function Brief() {
  return (
    <StepBody>
      
      <TeachingIntro labId={5} />
<Panel icon={Users} label="Awareness Programme · Internal, Consented">
        <Scenario who="Sarah, Team Lead"
          text={'"Our awareness team wants a report on how much our own org leaks through staff social media — with consent, this is an internal exercise. Profile our attack surface the way an attacker would: what could an outsider learn about our org chart, offices, tech, and people\u2019s routines from public posts? Build the picture an attacker would use for a spear-phish. But stay strictly passive — no contact, no following, no fake accounts. Public view only."'} />
      </Panel>
      <Panel icon={BookOpen} label="Objectives">
        <Briefing items={[
          'Collect and analyse public social content passively, without engagement',
          'Infer structure, roles, technologies, and locations from public signals',
          'Identify OPSEC weaknesses (oversharing of schedules, badges, screens)',
          'Assemble signals into a realistic spear-phishing pretext to demonstrate risk',
        ]} />
      </Panel>
    </StepBody>
  );
}

function Rules({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={EyeOff} label="Section 1 · Rules of engagement">
        <p>SOCMINT has the sharpest ethical edge in OSINT. Classify each action before you begin.</p>
        <Classifier
          onResolved={(ok) => recordScore('l5-roe', ok)}
          categories={[{ id: 'in', label: 'In scope (passive)' }, { id: 'out', label: 'Out of scope' }]}
          items={[
            { id: 'a', text: 'Reading public posts and profiles without logging in.' },
            { id: 'b', text: 'Following the staff member to unlock their friends-only posts.' },
            { id: 'c', text: 'Saving a public conference photo that shows a building badge.' },
            { id: 'd', text: 'Creating a fake recruiter account to DM an employee.' },
            { id: 'e', text: 'Noting a job ad that lists the company\u2019s internal tooling.' },
          ]}
          answer={{ a: 'in', b: 'out', c: 'in', d: 'out', e: 'in' }}
          explain={'Passive observation of public content and public job ads is in scope. Following to unlock restricted content, and any fake-account contact, is active engagement — out of scope, against platform terms, and outside the consented exercise.'}
        />
      </Panel>
    </StepBody>
  );
}

function Surface({ recordScore }) {
  const cols = [{ key: 'src', label: 'Public source' }, { key: 'signal', label: 'Leaked signal' }];
  const rows = [
    { src: 'Job ad — "Sr. Engineer"', signal: 'Stack: Okta SSO, CrowdStrike, internal "MeridPay" app', _cls: { signal: 'flag' } },
    { src: 'CFO public post', signal: '"Excited to open our new Brisbane office next month!"', _cls: { signal: 'flag' } },
    { src: 'Intern selfie at desk', signal: 'Monitor visible: ticketing URL helpdesk.meridian.example', _cls: { signal: 'flag' } },
    { src: 'Team offsite photo', signal: '"Whole finance team out Fri 14th — back Monday"', _cls: { signal: 'bad' } },
  ];
  return (
    <StepBody>
      <Panel icon={Building2} label="Section 2 · What the public posts reveal">
        <DataTable columns={cols} rows={rows} />
        <Quiz multi
          onResolved={(ok) => recordScore('l5-signals', ok)}
          q={{
            prompt: 'Which of these are usable by an attacker to build a targeted phish? Select all.',
            options: [
              { id: 'a', label: 'The named security stack (Okta, CrowdStrike, MeridPay) — pretext + bypass planning.' },
              { id: 'b', label: 'The new Brisbane office — a credible context for a fake "IT setup" email.' },
              { id: 'c', label: 'The helpdesk URL on the monitor — a target to spoof for a fake ticket.' },
              { id: 'd', label: 'The finance team out Fri 14th — timing a BEC when approvers are away.' },
            ],
            correct: ['a', 'b', 'c', 'd'],
            explain: 'All four. Individually each looks harmless; assembled, they let an attacker name the right tools, pick a believable pretext, spoof the right portal, and strike when finance approvers are unavailable. That aggregation IS the attack surface.',
          }}
        />
      </Panel>
    </StepBody>
  );
}

function Pretext({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Megaphone} label="Section 3 · Demonstrate the risk">
        <p>Assemble the leaked signals into one realistic spear-phishing pretext — to show the awareness team the impact.</p>
        <Reflection
          prompt={'Draft the pretext: who it impersonates, the hook, and which leaked signals make it credible.'}
          placeholder="e.g. Posing as IT, emailing finance on Fri 14th about 'Brisbane office Okta migration', linking a spoofed helpdesk.meridian.example login…"
          min={90}
          model={'Impersonate IT Helpdesk, email the finance team on Friday 14th (when approvers are away), referencing the genuine new Brisbane office and an "Okta SSO migration" — both publicly posted. The hook: "verify your account before Monday at helpdesk-meridian.example". It is credible precisely because every detail (tooling, office, helpdesk URL, timing) was leaked publicly. That is the report\u2019s punchline: reduce the surface, not just train the click.'}
          onResolved={(ok) => recordScore('l5-pretext', ok)}
        />
      </Panel>
      <EthicsGate
        scenario={'To "prove" the pretext works, a colleague suggests actually sending it to three finance staff without telling anyone. Right call?'}
        options={[
          { id: 'a', label: 'Yes — a real test is the only convincing proof.' },
          { id: 'b', label: 'No — unauthorised phishing of colleagues is out of scope; any simulation needs explicit sign-off and a defined process.' },
          { id: 'c', label: 'Only if you debrief them afterwards.' },
        ]}
        correct="b"
        explain={'The exercise was scoped as passive collection. Launching even a simulated phish without authorisation crosses into active engagement and can breach policy and trust. Document the pretext as a finding; a live simulation is a separate, sanctioned programme.'}
        onResolved={(ok) => recordScore('l5-ethics', ok)}
      />
    </StepBody>
  );
}

const Checkpoint5 = makeCheckpoint(5);

export const lab5 = {
  steps: [
    { label: 'Briefing', taskCount: 0, component: Brief },
    { label: 'Rules', taskCount: 1, component: Rules },
    { label: 'Attack Surface', taskCount: 1, component: Surface },
    { label: 'Pretext & Ethics', taskCount: 2, component: Pretext },
    { label: 'Checkpoint', taskCount: 0, isQuiz: true, component: Checkpoint5 },
  ],
};
