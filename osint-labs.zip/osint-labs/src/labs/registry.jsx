import { lab1 } from './Lab1.jsx';
import { lab2 } from './Lab2.jsx';
import { lab3 } from './Lab3.jsx';
import { lab4 } from './Lab4.jsx';
import { lab5 } from './Lab5.jsx';
import { lab6 } from './Lab6.jsx';
import { lab7 } from './Lab7.jsx';
import { lab8 } from './Lab8.jsx';
import { lab9 } from './Lab9.jsx';
import { lab10 } from './Lab10.jsx';

export const LAB_REGISTRY = {
  1: lab1, 2: lab2, 3: lab3, 4: lab4, 5: lab5,
  6: lab6, 7: lab7, 8: lab8, 9: lab9, 10: lab10,
};
