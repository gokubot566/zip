import React from 'react';
import { Panel, Scenario, Briefing, Quiz, Classifier, AnswerCheck, DataTable, Reflection, StepBody, Terminal } from '../components/kit.jsx';
import { Crosshair, Layers3, GitMerge, ShieldQuestion, FileWarning, Radar } from 'lucide-react';

function Brief() {
  return (
    <StepBody>
      <Panel icon={Crosshair} label="Major Investigation · Coordinated Impersonation">
        <Scenario who="CISO, Meridian Financial Services"
          text={'"We are under coordinated attack — not the kind that trips a SIEM. A lookalike domain hosts a fake document portal. A fabricated profile impersonates our CFO and is messaging staff and clients. A spoofed brand page collects \u2018investor enquiries.\u2019 Photos of a supposed new branch office are circulating to lend it credibility. I think one actor is behind all of it. Tie it together if you can, give me an IOC and takedown package, and brief the board in 45 minutes. And tell me your confidence — honestly."'} />
      </Panel>
      <Panel icon={Radar} label="The four elements">
        <Briefing items={[
          'Domain & infrastructure — the fake document portal (Lab 4 skills)',
          'Fake executive accounts impersonating the CFO (Lab 3 skills)',
          'Spoofed brand page collecting investor PII (Lab 5 / Lab 4)',
          'Branch-office photos used as social proof (Lab 6 skills)',
        ]} />
        <p className="hint">This capstone fuses everything: infrastructure pivoting, account enumeration, image geolocation, source documentation, and calibrated reporting — under time pressure, within ethical bounds.</p>
      </Panel>
    </StepBody>
  );
}

function Collect({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Layers3} label="Phase 1 · Multi-source collection">
        <Terminal title="case://osint-10/evidence-pack" lines={[
          '<span class="hl">[DOMAIN]</span>  meridian-docs-secure.com  A=91.214.8.7  NS=DARKPOOL  cert=<span class="hl">f3c2…</span>',
          '<span class="hl">[BRAND]</span>   meridian-investor-portal.com  A=91.214.8.7  NS=DARKPOOL  cert=<span class="hl">f3c2…</span>',
          '          page contact: <span class="hl">invest@m-castellan.example</span>',
          '<span class="hl">[PROFILE]</span> "Robert Mosely, CFO @ Meridian"  handle=<span class="hl">r.mosely_fin</span>',
          '          listed contact: <span class="hl">invest@m-castellan.example</span>',
          '<span class="hl">[PHOTO]</span>  branch_office.jpg  reverse-image: <span class="alert">2021 stock, "modern bank lobby"</span>',
          '          EXIF handle field: <span class="hl">r.mosely_fin</span>',
          '<span class="cmt"># red herrings present — verify before linking</span>',
          '<span class="cmt">[NOISE] meridian-jobs.com.au  A=13.55.x.x  NS=AWS  cert=8b10…  (unrelated)</span>',
        ]} />
        <AnswerCheck
          prompt="Which single shared identifier appears across the brand page, the fake profile, AND the photo's EXIF — the strongest cross-element link?"
          placeholder="email or handle…"
          accepts={['invest@m-castellan.example', 'r.mosely_fin', 'm-castellan', 'mosely_fin']}
          hint="Look for a value repeated in three of the four elements."
          explain="The handle r.mosely_fin (and the email invest@m-castellan.example) recur across elements. A distinctive identifier reused across three independent assets is hard to explain as coincidence — it is the spine of the attribution."
          onResolved={(ok) => recordScore('l10-link', ok)}
        />
      </Panel>
    </StepBody>
  );
}

function Attribute({ recordScore }) {
  const cols = [{ key: 'el', label: 'Element' }, { key: 'sig', label: 'Linking signal' }, { key: 'str', label: 'Strength' }];
  const rows = [
    { el: 'Domain ↔ Brand', sig: 'Same IP 91.214.8.7 + NS DARKPOOL + cert f3c2…', str: 'Strong', _cls: { str: 'flag' } },
    { el: 'Brand ↔ Profile', sig: 'Same contact email invest@m-castellan.example', str: 'Strong', _cls: { str: 'flag' } },
    { el: 'Profile ↔ Photo', sig: 'Same handle r.mosely_fin in EXIF field', str: 'Moderate', _cls: { str: '' } },
    { el: 'meridian-jobs.com.au', sig: 'Different IP / NS / cert', str: 'Unrelated', _cls: { str: 'bad' } },
  ];
  return (
    <StepBody>
      <Panel icon={GitMerge} label="Phase 2 · Link & attribute">
        <DataTable columns={cols} rows={rows} />
        <Quiz
          onResolved={(ok) => recordScore('l10-attr', ok)}
          q={{
            prompt: 'Given the link table, what is the best-calibrated attribution judgement?',
            options: [
              { id: 'a', label: 'All four elements are certainly one actor — case closed.' },
              { id: 'b', label: 'The domain, brand page, profile, and photo are very likely one actor (moderate-high confidence); meridian-jobs.com.au is unrelated. The profile↔photo link is the weakest.' },
              { id: 'c', label: 'There is no way to connect any of them.' },
            ],
            correct: 'b',
            explain: 'Three elements share hard infrastructure/identifier links (strong); the photo link rests on a single EXIF field (moderate). "Very likely, moderate-high confidence" fits — and you must exclude the jobs domain and flag the weakest link rather than overclaiming certainty.',
          }}
        />
        <Classifier
          onResolved={(ok) => recordScore('l10-herring', ok)}
          categories={[{ id: 'in', label: 'In the cluster' }, { id: 'out', label: 'Red herring / exclude' }]}
          items={[
            { id: 'a', text: 'meridian-docs-secure.com (IP 91.214.8.7, cert f3c2…)' },
            { id: 'b', text: 'meridian-investor-portal.com (IP 91.214.8.7, cert f3c2…)' },
            { id: 'c', text: 'meridian-jobs.com.au (AWS, cert 8b10…)' },
            { id: 'd', text: 'branch_office.jpg (2021 stock photo, EXIF handle r.mosely_fin)' },
          ]}
          answer={{ a: 'in', b: 'in', c: 'out', d: 'in' }}
          explain={'The two domains and the photo tie to the actor by shared infrastructure and a reused handle. meridian-jobs.com.au is the planted red herring — different infrastructure entirely. Including it would pollute the takedown package and risk a legitimate asset.'}
        />
      </Panel>
    </StepBody>
  );
}

function Impact({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={ShieldQuestion} label="Phase 3 · Impact & breach assessment">
        <Terminal title="case://osint-10/impact" lines={[
          'spoofed brand page form fields collected:',
          '  full name, email, phone, <span class="alert">investment amount, passport number</span>',
          'submissions observed (page analytics leak): <span class="alert">23 individuals</span>',
          '<span class="cmt"># personal information of identifiable individuals = AU Privacy Act in scope</span>',
        ]} />
        <Quiz
          onResolved={(ok) => recordScore('l10-breach', ok)}
          q={{
            prompt: 'The fraud page harvested names, contact details, and passport numbers from 23 people. Under the Australian Privacy Act notifiable-data-breach scheme, what is the right assessment?',
            options: [
              { id: 'a', label: 'No obligation — it was the attacker\u2019s page, not ours.' },
              { id: 'b', label: 'Likely notifiable: personal/sensitive information (incl. passport numbers) of identifiable individuals was compromised with risk of serious harm; assess and, if confirmed, notify the OAIC and affected individuals.' },
              { id: 'c', label: 'Wait a year and see if anyone complains.' },
            ],
            correct: 'b',
            explain: 'The scheme turns on unauthorised access to personal information likely to cause serious harm to identifiable individuals — passport numbers and investment data clear that bar. Even though the actor ran the page, Meridian must assess notification obligations and engage legal/OAIC. (General guidance, not legal advice.)',
          }}
        />
      </Panel>
    </StepBody>
  );
}

function Brief2({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={FileWarning} label="Phase 4 · IOC / takedown package">
        <Classifier
          onResolved={(ok) => recordScore('l10-ioc', ok)}
          categories={[{ id: 'pkg', label: 'In takedown package' }, { id: 'no', label: 'Exclude' }]}
          items={[
            { id: 'a', text: 'IP 91.214.8.7 + NS DARKPOOL + cert f3c2…' },
            { id: 'b', text: 'meridian-docs-secure.com & meridian-investor-portal.com' },
            { id: 'c', text: 'Fake profile URL (handle r.mosely_fin) + email invest@m-castellan.example' },
            { id: 'd', text: 'meridian-jobs.com.au' },
          ]}
          answer={{ a: 'pkg', b: 'pkg', c: 'pkg', d: 'no' }}
          explain={'The shared infrastructure, both lookalike domains, and the fake account/email go to the SOC, hosting abuse desks, and the platform for takedown. The jobs domain stays out — excluding red herrings is as important as including real IOCs.'}
        />
      </Panel>
      <Panel icon={Crosshair} label="Phase 5 · Board brief">
        <Reflection
          prompt={'Write the one-page executive brief opener for the CISO: what is happening, attribution + confidence, impact, and the single most urgent recommended action.'}
          placeholder="A single threat actor is very likely (moderate-high confidence) running a coordinated Meridian impersonation across two lookalike domains, a fake CFO profile, and a fraudulent investor page that has harvested PII from 23 individuals…"
          min={120}
          model={'BLUF: A single threat actor is very likely (moderate-high confidence) running a coordinated Meridian impersonation — two lookalike domains, a fake CFO profile, and a fraudulent investor-enquiry page — linked by shared hosting infrastructure (IP/NS/cert) and a reused identifier. Impact: the fraud page has harvested PII including passport numbers from 23 identifiable individuals, very likely triggering Privacy Act notification obligations. Most urgent action: initiate takedown of the two domains and the fake profile via hosting/platform abuse channels, block the IOC set at the perimeter, and stand up the data-breach assessment with legal today. One unrelated domain (meridian-jobs.com.au) was checked and excluded.'}
          onResolved={(ok) => recordScore('l10-board', ok)}
        />
      </Panel>
      <Panel label="Honest about the weak link">
        <Quiz
          onResolved={(ok) => recordScore('l10-honest', ok)}
          q={{
            prompt: 'The board asks: "Are you 100% sure it is one person?" Best answer?',
            options: [
              { id: 'a', label: '"Yes, completely certain."' },
              { id: 'b', label: '"Very likely one actor at moderate-high confidence — three elements share hard links; the photo connection is weaker. One more identifier would raise it to high confidence."' },
              { id: 'c', label: '"No idea, honestly."' },
            ],
            correct: 'b',
            explain: 'Honest calibration: state the judgement, the confidence, what is strong, what is weak, and what would resolve it. Neither false certainty nor unhelpful shrugging — that is the whole point of the course.',
          }}
        />
      </Panel>
    </StepBody>
  );
}

export const lab10 = {
  steps: [
    { label: 'Briefing', taskCount: 0, component: Brief },
    { label: 'Collection', taskCount: 1, component: Collect },
    { label: 'Attribution', taskCount: 2, component: Attribute },
    { label: 'Impact', taskCount: 1, component: Impact },
    { label: 'Package & Brief', taskCount: 3, component: Brief2 },
  ],
};
