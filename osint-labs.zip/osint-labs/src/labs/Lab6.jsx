import React from 'react';
import { Panel, Scenario, Briefing, Quiz, AnswerCheck, Reflection, StepBody, Terminal } from '../components/kit.jsx';
import { TeachingIntro, makeCheckpoint } from '../components/teaching.jsx';
import { Image as ImageIcon, MapPin, Copy, Clock, BookOpen } from 'lucide-react';

function Brief() {
  return (
    <StepBody>
      
      <TeachingIntro labId={6} />
<Panel icon={ImageIcon} label="Fraud Investigation · Photo Verification">
        <Scenario who="Sarah, Team Lead"
          text={'"A counterparty claims to run a warehouse and sent photos to prove it — but the numbers do not add up. Tell me whether these photos are what they say they are. Where were they actually taken? When? Are they original, or pulled from elsewhere on the web? Use the metadata, use what is in the frame, verify against mapping imagery. Give me a geolocation with a confidence level and the reasoning."'} />
      </Panel>
      <Panel icon={BookOpen} label="Objectives">
        <Briefing items={[
          'Extract and interpret EXIF metadata (timestamps, GPS where present)',
          'Use reverse-image search to detect reused or stock photos',
          'Geolocate from visual cues and verify against satellite/street imagery',
          'Apply chronolocation (shadows, sun) and report with an explicit confidence level',
        ]} />
      </Panel>
    </StepBody>
  );
}

function Exif({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={MapPin} label="Section 1 · Metadata">
        <Terminal title="exiftool IMG_warehouse_01.jpg" lines={[
          'Make            Apple',
          'Model           iPhone 13',
          'Create Date     2024-11-03 14:22:10',
          'GPS Latitude    <span class="hl">-27.4698 S</span>',
          'GPS Longitude   <span class="hl">153.0251 E</span>',
          '<span class="cmt"># -27.4698, 153.0251 ...</span>',
        ]} />
        <AnswerCheck
          prompt="Those coordinates (-27.4698, 153.0251) place the photo in which city? (verify against mapping imagery)"
          placeholder="city name…"
          accepts={['brisbane']}
          hint="Southern hemisphere, eastern Australia."
          explain="Brisbane, Australia. But note: the counterparty claimed the warehouse is in Perth — already a contradiction. GPS EXIF, when present, is the fastest possible geolocation. Always confirm the coordinates resolve where the subject claims."
          onResolved={(ok) => recordScore('l6-gps', ok)}
        />
      </Panel>
    </StepBody>
  );
}

function Reuse({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Copy} label="Section 2 · Reverse-image check">
        <Terminal title="reverse-image IMG_warehouse_02.jpg" lines={[
          'matches found: <span class="alert">7</span>',
          'top result: stockphotos-bulk.example/large-warehouse-interior  (uploaded 2019)',
          'also seen on: 4 unrelated "logistics company" websites',
          '<span class="cmt"># this is a stock photo reused as "proof"</span>',
        ]} />
        <Quiz
          onResolved={(ok) => recordScore('l6-reuse', ok)}
          q={{
            prompt: 'Image 02 appears as a 2019 stock photo on multiple sites. What does this establish?',
            options: [
              { id: 'a', label: 'Nothing — stock photos are common.' },
              { id: 'b', label: 'It cannot be an original "proof" of this counterparty\u2019s facility; presenting it as such is misrepresentation.' },
              { id: 'c', label: 'The counterparty owns the stock photo company.' },
            ],
            correct: 'b',
            explain: 'A photo that predates the counterparty and appears on unrelated sites is not evidence of their warehouse. Reverse-image search is the fastest way to catch fabricated "proof" in fraud and disinformation.',
          }}
        />
      </Panel>
    </StepBody>
  );
}

function Geo({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Clock} label="Section 3 · Visual geolocation (no metadata)">
        <p>Image 03 has stripped EXIF. You must place it from the frame.</p>
        <Terminal title="visual-cues IMG_warehouse_03.jpg" lines={[
          'signage:    "LADBROKE ST" street sign, text in English',
          'plates:     yellow rear plates, format ABC-123 (QLD style)',
          'vehicles:   driving on the LEFT',
          'sun/shadow: long shadows pointing SE, low sun  <span class="cmt"># morning</span>',
          'building:   matches Ladbroke St, Milton (Brisbane) on street-view',
        ]} />
        <AnswerCheck
          prompt="From the street name, plate style, side-of-road, and street-view match — what city is this, contradicting the Perth claim?"
          placeholder="city…"
          accepts={['brisbane']}
          hint="Same city the GPS photo pointed to."
          explain="Brisbane again. Even with metadata stripped, signage + plate format + drive-side + a street-view match pin the location — and chronolocation (long SE shadows, low sun) tells you it was morning. Three images, none supporting the Perth story."
          onResolved={(ok) => recordScore('l6-visual', ok)}
        />
        <Quiz
          onResolved={(ok) => recordScore('l6-conf', ok)}
          q={{
            prompt: 'How should you state the geolocation of Image 03 in the report?',
            options: [
              { id: 'a', label: '"Brisbane" — full stop.' },
              { id: 'b', label: '"Brisbane (Milton), high confidence — corroborated by street sign, plate format, drive-side, and a street-view building match."' },
              { id: 'c', label: '"Possibly Australia, low confidence."' },
            ],
            correct: 'b',
            explain: 'State the location, the confidence level, and the evidence chain. Multiple independent, mutually-reinforcing cues justify high confidence — and "low confidence" would understate strong evidence just as badly as a bare assertion would overstate weak evidence.',
          }}
        />
      </Panel>
      <Panel label="Verdict">
        <Reflection
          prompt={'Does the image set support or contradict the counterparty\u2019s "Perth warehouse" claim? Summarise per image.'}
          placeholder="Image 01: GPS = Brisbane. Image 02: reused stock. Image 03: visually Brisbane…"
          min={80}
          model={'The set contradicts the claim. Image 01\u2019s GPS EXIF resolves to Brisbane, not Perth. Image 02 is a 2019 stock photo reused on unrelated sites — not their facility at all. Image 03, with EXIF stripped, geolocates to Brisbane (Milton) by signage, plate format, drive-side, and a street-view match. No image supports a Perth warehouse; high confidence the claim is false.'}
          onResolved={(ok) => recordScore('l6-verdict', ok)}
        />
      </Panel>
    </StepBody>
  );
}

const Checkpoint6 = makeCheckpoint(6);

export const lab6 = {
  steps: [
    { label: 'Briefing', taskCount: 0, component: Brief },
    { label: 'Metadata', taskCount: 1, component: Exif },
    { label: 'Reuse Check', taskCount: 1, component: Reuse },
    { label: 'Geolocation', taskCount: 3, component: Geo },
    { label: 'Checkpoint', taskCount: 0, isQuiz: true, component: Checkpoint6 },
  ],
};
