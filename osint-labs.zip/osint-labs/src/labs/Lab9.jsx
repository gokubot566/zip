import React from 'react';
import { Panel, Scenario, Briefing, Quiz, Classifier, AnswerCheck, Reflection, StepBody, Terminal } from '../components/kit.jsx';
import { TeachingIntro, makeCheckpoint } from '../components/teaching.jsx';
import { FileText, Gauge, Scale, SplitSquareVertical, BookOpen } from 'lucide-react';

function Brief() {
  return (
    <StepBody>
      
      <TeachingIntro labId={9} />
<Panel icon={FileText} label="From Collector to Analyst">
        <Scenario who="Sarah, Team Lead"
          text={'"Collection is the easy part. Now turn it into intelligence leadership can act on. I want a finished report: a bottom-line assessment up front, your confidence stated in proper analytic language, sources cited, alternative explanations considered, and findings separated cleanly from your judgements. Write it the way a professional intelligence shop would — calibrated, sourced, and honest about what we do not know."'} />
      </Panel>
      <Panel icon={BookOpen} label="Objectives">
        <Briefing items={[
          'Lead with a bottom-line-up-front (BLUF) key judgement',
          'Apply calibrated probability language consistently',
          'Separate underlying facts from analytic judgements; cite both',
          'Use a structured technique (lightweight ACH) and an alternative hypothesis',
        ]} />
      </Panel>
    </StepBody>
  );
}

function Lexicon({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Gauge} label="Section 1 · The probability lexicon">
        <Terminal title="reference://confidence-lexicon" lines={[
          'remote / very unlikely     ~ 5–20%',
          'unlikely                   ~ 20–40%',
          'roughly even chance        ~ 40–60%',
          '<span class="hl">likely / probable</span>          ~ 60–80%',
          '<span class="hl">very likely / almost certain</span> ~ 80–95%+',
          '<span class="cmt"># "confidence" (low/mod/high) describes evidence quality, separately from probability</span>',
        ]} />
        <Quiz
          onResolved={(ok) => recordScore('l9-lex', ok)}
          q={{
            prompt: 'Your evidence: one strong shared identifier plus consistent but circumstantial context. Which phrasing is best calibrated?',
            options: [
              { id: 'a', label: '"It is certain the two accounts are the same actor."' },
              { id: 'b', label: '"The two accounts are very likely the same actor (moderate-to-high confidence)."' },
              { id: 'c', label: '"The accounts might possibly perhaps be related."' },
            ],
            correct: 'b',
            explain: '"Certain" overstates circumstantial evidence; the vague version understates a strong identifier. Calibrated language pairs a probability ("very likely") with a confidence level reflecting evidence quality.',
          }}
        />
      </Panel>
    </StepBody>
  );
}

function FactJudge({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={SplitSquareVertical} label="Section 2 · Fact vs judgement">
        <p>Tag each statement. Facts must be sourced; judgements must carry confidence.</p>
        <Classifier
          onResolved={(ok) => recordScore('l9-fj', ok)}
          categories={[{ id: 'fact', label: 'Fact (cite)' }, { id: 'judge', label: 'Judgement (confidence)' }]}
          items={[
            { id: 'a', text: 'The lookalike domain and the brand-page host share IP 185.62.44.10 (per passive DNS, 2025-06-02).' },
            { id: 'b', text: 'A single actor is very likely behind both assets.' },
            { id: 'c', text: 'The fake profile reuses the username nw_logistics22 (observed on two platforms).' },
            { id: 'd', text: 'The actor probably intends to defraud Meridian\u2019s investors.' },
          ]}
          answer={{ a: 'fact', b: 'judge', c: 'fact', d: 'judge' }}
          explain={'(a) and (c) are observable, sourced facts. (b) and (d) are analytic conclusions drawn FROM those facts — they must be labelled as judgements with explicit confidence, never blended into the evidence as if proven.'}
        />
      </Panel>
    </StepBody>
  );
}

function ACH({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Scale} label="Section 3 · Alternatives & BLUF">
        <p>Lightweight Analysis of Competing Hypotheses: which evidence is diagnostic (favours one hypothesis over another)?</p>
        <Quiz
          onResolved={(ok) => recordScore('l9-ach', ok)}
          q={{
            prompt: 'H1: same actor controls domain + fake profile. H2: two unrelated actors. Which finding is MOST diagnostic for H1?',
            options: [
              { id: 'a', label: 'Both assets impersonate Meridian (consistent with H1 and H2 — not diagnostic).' },
              { id: 'b', label: 'The domain registration contact email reuses the exact handle found on the fake profile.' },
              { id: 'c', label: 'Both were created in 2025 (weakly consistent with either).' },
            ],
            correct: 'b',
            explain: 'A shared, distinctive identifier across both assets is hard to explain under H2 (two unrelated actors) — that makes it diagnostic for H1. Evidence consistent with both hypotheses (impersonation, timing) carries little weight in choosing between them.',
          }}
        />
        <AnswerCheck
          prompt="Write a one-line BLUF for the report (lead with the judgement + a calibrated probability word)."
          area
          placeholder="e.g. A single threat actor is very likely (moderate-high confidence) running a coordinated Meridian impersonation across a lookalike domain and a fake executive profile…"
          accepts={['likely', 'almost certain', 'probable']}
          hint="It must contain a calibrated probability term (likely / very likely / almost certain)."
          explain="Good — a BLUF leads with the assessment and a calibrated probability so a busy reader gets the bottom line in one sentence, with the detail and confidence following."
          onResolved={(ok) => recordScore('l9-bluf', ok)}
        />
      </Panel>
      <Panel label="The hard part: honest uncertainty">
        <Reflection
          prompt={'Your evidence strongly suggests one conclusion but is also consistent with an innocent explanation. How do you word the key judgement so leadership is neither misled nor paralysed?'}
          placeholder="Write 2–3 sentences…"
          min={70}
          model={'State the most likely judgement with a calibrated probability ("very likely"), explicitly name the less-likely alternative and why it is less supported, and identify the single piece of collection that would resolve the ambiguity. That lets leadership act on the balance of evidence while understanding the residual risk — the opposite of both false certainty and useless hedging.'}
          onResolved={(ok) => recordScore('l9-reflect', ok)}
        />
      </Panel>
    </StepBody>
  );
}

const Checkpoint9 = makeCheckpoint(9);

export const lab9 = {
  steps: [
    { label: 'Briefing', taskCount: 0, component: Brief },
    { label: 'Lexicon', taskCount: 1, component: Lexicon },
    { label: 'Fact vs Judgement', taskCount: 1, component: FactJudge },
    { label: 'ACH & BLUF', taskCount: 3, component: ACH },
    { label: 'Checkpoint', taskCount: 0, isQuiz: true, component: Checkpoint9 },
  ],
};
