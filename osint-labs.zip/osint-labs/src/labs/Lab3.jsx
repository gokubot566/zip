import React from 'react';
import { Panel, Scenario, Briefing, Quiz, Classifier, DataTable, AnswerCheck, Reflection, StepBody, Terminal } from '../components/kit.jsx';
import { TeachingIntro, makeCheckpoint } from '../components/teaching.jsx';
import { UserSearch, Network, ShieldAlert, GitMerge, BookOpen } from 'lucide-react';

function Brief() {
  return (
    <StepBody>
      
      <TeachingIntro labId={3} />
<Panel icon={UserSearch} label="Fraud Team · Vendor Verification">
        <Scenario who="Sarah, Team Lead"
          text={'"A suspicious vendor just onboarded to our supplier portal. We have three identifiers from the application: an email, a display name, and a support-ticket username. Find every account that plausibly belongs to the same entity — and tell me your confidence in each link. Do not assume two accounts are the same just because the username matches. Show me the corroboration."'} />
      </Panel>
      <Panel icon={BookOpen} label="Seed identifiers">
        <Terminal title="case://vendor-verification/seeds" lines={[
          'username   <span class="hl">nw_logistics22</span>',
          'email      <span class="hl">accounts@northwind-frgt.example</span>',
          'display    <span class="hl">Northwind Freight Co</span>',
          '<span class="cmt"># pivot from each seed; corroborate before you link</span>',
        ]} />
        <Briefing items={[
          'Enumerate accounts across platforms from a seed username, email, and name',
          'Rate each identity link with an explicit confidence level and evidence',
          'Distinguish strong corroboration (photos, bios, cross-refs) from a common-username coincidence',
        ]} />
      </Panel>
    </StepBody>
  );
}

const rubric = [
  { lvl: 'Confirmed', _cls: { lvl: 'flag' }, ev: 'Multiple independent matches: same photo + bio + cross-link' },
  { lvl: 'Probable', ev: 'Strong but not conclusive: matching email or distinctive reused handle + context' },
  { lvl: 'Possible', ev: 'Weak signal: a match that could be coincidence (common username alone)' },
  { lvl: 'Unsupported', _cls: { lvl: 'bad' }, ev: 'No corroborating evidence beyond the surface match' },
];

function Pivot({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Network} label="Section 1 · Confidence rubric">
        <DataTable columns={[{ key: 'lvl', label: 'Level' }, { key: 'ev', label: 'Evidence required' }]} rows={rubric} />
      </Panel>
      <Panel label="Username enumeration results">
        <Terminal title="usercheck nw_logistics22" lines={[
          'platform        status   notes',
          'b2b-directory   <span class="hl">FOUND</span>    logo + same email accounts@northwind-frgt.example',
          'shipping-forum  <span class="hl">FOUND</span>    avatar = company logo, signature links to brand-page',
          'gamer-portal    <span class="hl">FOUND</span>    profile: 17yo in another country, gaming clips only',
          'code-host       not found',
        ]} />
        <Classifier
          onResolved={(ok) => recordScore('l3-rate', ok)}
          categories={[
            { id: 'conf', label: 'Confirmed' }, { id: 'prob', label: 'Probable' },
            { id: 'poss', label: 'Possible' }, { id: 'unsup', label: 'Unsupported' },
          ]}
          items={[
            { id: 'a', text: 'b2b-directory account — logo matches AND it lists the same seed email.' },
            { id: 'b', text: 'shipping-forum account — company logo avatar and a signature linking to the brand page.' },
            { id: 'c', text: 'gamer-portal account — same username, but a teenager in another country posting gaming clips.' },
          ]}
          answer={{ a: 'conf', b: 'prob', c: 'unsup' }}
          explain={'The b2b match is Confirmed by an independent identifier (the email) plus the logo. The forum is Probable — strong contextual links but no shared hard identifier. The gamer account is Unsupported: a reused common-ish handle by an unrelated person. Linking it would be a false attribution.'}
        />
      </Panel>
    </StepBody>
  );
}

function Pitfall({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={ShieldAlert} label="Section 2 · The false-match trap">
        <Quiz
          onResolved={(ok) => recordScore('l3-trap', ok)}
          q={{
            prompt: 'A username matches your subject on five platforms, but the profile photos and writing styles clearly differ. What is the correct conclusion?',
            options: [
              { id: 'a', label: 'Five matches is overwhelming — confirm the link and move on.' },
              { id: 'b', label: 'The differing photos/style suggest these are different people reusing a handle; downgrade to Possible/Unsupported and seek a hard identifier.' },
              { id: 'c', label: 'Photos do not matter; the username is the identity.' },
            ],
            correct: 'b',
            explain: 'Count of matches means little when the corroborating signals contradict each other. A reused common username links strangers all the time. Misattributing accounts to an innocent person is one of the most damaging OSINT errors.',
          }}
        />
      </Panel>
      <Panel label="Email pivot">
        <Terminal title="breach-lookup accounts@northwind-frgt.example  (training dataset)" lines={[
          '<span class="cmt"># lawful check against the provided training breach set only</span>',
          'exposure: 1 record  source: "freight-board-2024 dump"',
          'associated handle in dump: <span class="hl">nw_logistics22</span>',
          'associated recovery hint: <span class="hl">n***@northwind-frgt.example</span>',
        ]} />
        <AnswerCheck
          prompt="The breach record ties the seed email to which username — strengthening the link?"
          placeholder="username…"
          accepts={['nw_logistics22']}
          hint="Read the 'associated handle in dump' line."
          explain="nw_logistics22 — the email and username now co-occur in an independent dataset, which raises the b2b and forum accounts toward Confirmed. That is corroboration: a second, independent source pointing the same way."
          onResolved={(ok) => recordScore('l3-email', ok)}
        />
      </Panel>
    </StepBody>
  );
}

function LinkChart({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={GitMerge} label="Section 3 · Attribution assessment">
        <p>Write the assessment Sarah asked for: which links you are confident in, which are weak, and what would raise confidence.</p>
        <Reflection
          prompt={'Summarise your attribution for the vendor identity. State confidence per account and the single biggest evidence gap.'}
          placeholder="e.g. Confirmed: b2b-directory (shared email + logo). Probable: shipping-forum (logo + brand link). Unsupported: gamer-portal (different person). Gap: …"
          min={90}
          model={'Confirmed: the b2b-directory account (shared seed email + logo, corroborated by the training breach record). Probable: the shipping-forum account (logo avatar + brand-page link, but no hard shared identifier). Unsupported: the gamer-portal account (same handle but a different, unrelated person). Biggest gap: no independent confirmation of who controls the email itself — a registration record or a second platform tying a real identity to the address would move the whole cluster to Confirmed.'}
          onResolved={(ok) => recordScore('l3-assess', ok)}
        />
      </Panel>
      <Panel label="Why it matters">
        <Quiz
          onResolved={(ok) => recordScore('l3-why', ok)}
          q={{
            prompt: 'Why must each link in an identity chart carry an explicit confidence level rather than just being "connected"?',
            options: [
              { id: 'a', label: 'It looks more professional in the report.' },
              { id: 'b', label: 'Because findings may drive fraud, HR, or legal action — and a weak link presented as fact can harm an innocent third party and discredit the whole case.' },
              { id: 'c', label: 'Confidence levels are optional once you have enough links.' },
            ],
            correct: 'b',
            explain: 'Confidence is not decoration. It tells the decision-maker how much weight each link can bear and protects both the case and any wrongly-implicated person.',
          }}
        />
      </Panel>
    </StepBody>
  );
}

const Checkpoint3 = makeCheckpoint(3);

export const lab3 = {
  steps: [
    { label: 'Briefing', taskCount: 0, component: Brief },
    { label: 'Pivot & Rate', taskCount: 1, component: Pivot },
    { label: 'False Matches', taskCount: 2, component: Pitfall },
    { label: 'Attribution', taskCount: 2, component: LinkChart },
    { label: 'Checkpoint', taskCount: 0, isQuiz: true, component: Checkpoint3 },
  ],
};
