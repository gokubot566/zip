import React from 'react';
import { Panel, Scenario, Briefing, Quiz, Classifier, Reflection, StepBody, Terminal } from '../components/kit.jsx';
import { ClipboardList, Wrench, SearchCheck, MessagesSquare, BookOpen } from 'lucide-react';

function Brief() {
  return (
    <StepBody>
      <Panel icon={ClipboardList} label="Standardisation · Build the Playbook">
        <Scenario who="Sarah, Team Lead"
          text={'"Every analyst approaches a new tasking differently. Some forget to define scope and boil the ocean. Others skip source documentation and we cannot defend the findings. Write me a reusable collection plan for one tasking type — brand and executive-impersonation monitoring — that any analyst can follow: objectives, scope and ethics boundaries, source-and-tool matrix, workflow, documentation standard. Then peer-review someone else\u2019s plan for a phishing-domain investigation and give structured feedback."'} />
      </Panel>
      <Panel icon={BookOpen} label="A collection plan answers, before you start">
        <Briefing items={[
          'What question are we answering? (objective + key information requirements)',
          'What is in and out of scope — and where are the ethical/legal lines?',
          'Which sources and tools apply to each requirement?',
          'How is every finding documented, and when do we stop / escalate?',
        ]} />
      </Panel>
    </StepBody>
  );
}

function Matrix({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={Wrench} label="Section 1 · Source-and-tool matrix">
        <p>Map each information requirement to the right capability — deliberately, not by habit.</p>
        <Classifier
          onResolved={(ok) => recordScore('l8-matrix', ok)}
          categories={[
            { id: 'dns', label: 'DNS / cert-transparency' },
            { id: 'acct', label: 'Account / username search' },
            { id: 'img', label: 'Image / reverse-image' },
          ]}
          items={[
            { id: 'a', text: 'Requirement: detect lookalike domains impersonating the brand.' },
            { id: 'b', text: 'Requirement: find fake executive profiles using the CEO\u2019s name/photo.' },
            { id: 'c', text: 'Requirement: catch the company logo misused on spoofed pages.' },
          ]}
          answer={{ a: 'dns', b: 'acct', c: 'img' }}
          explain={'Lookalike domains → DNS + certificate transparency. Fake executive profiles → account/username enumeration. Logo misuse → reverse-image search. A good matrix means analysts reach for the right tool per requirement instead of whatever they happen to like.'}
        />
      </Panel>
    </StepBody>
  );
}

function PlanSections({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={SearchCheck} label="Section 2 · Scope & stop criteria">
        <Quiz multi
          onResolved={(ok) => recordScore('l8-scope', ok)}
          q={{
            prompt: 'Which belong in the scope & ethics section of the plan? Select all.',
            options: [
              { id: 'a', label: 'Passive-only rule — no contact, no fake accounts, no engaging targets.' },
              { id: 'b', label: 'Lawful sources only; comply with platform terms.' },
              { id: 'c', label: 'Data-handling & retention rules for anything collected on individuals.' },
              { id: 'd', label: 'A clever trick to get past a private-profile setting.' },
            ],
            correct: ['a', 'b', 'c'],
            explain: 'Boundaries, lawful sourcing, and data handling are the heart of the scope section. A technique to defeat privacy settings is precisely what a collection plan exists to forbid.',
          }}
        />
        <Quiz
          onResolved={(ok) => recordScore('l8-stop', ok)}
          q={{
            prompt: 'What is a good "stop / escalate" criterion for impersonation monitoring?',
            options: [
              { id: 'a', label: '"Keep searching until you run out of ideas."' },
              { id: 'b', label: '"When a confirmed lookalike is actively phishing customers, freeze collection and hand the IOC package to the SOC/legal as an incident."' },
              { id: 'c', label: '"Stop when your shift ends."' },
            ],
            correct: 'b',
            explain: 'A stop/escalate criterion converts a finding into action and prevents open-ended rabbit-holing. When monitoring uncovers a live threat, it becomes an incident with a defined hand-off.',
          }}
        />
      </Panel>
    </StepBody>
  );
}

function PeerReview({ recordScore }) {
  return (
    <StepBody>
      <Panel icon={MessagesSquare} label="Section 3 · Peer review">
        <p>Review the colleague\u2019s phishing-domain collection plan and find the gaps.</p>
        <Terminal title="review://phishing-domain-plan.md" lines={[
          '## Objective',
          'Find phishing domains targeting us.',
          '## Tools',
          'whois, dig, a username checker, exiftool, "various"',
          '## Workflow',
          '1. Search for lookalike domains.  2. Write them down.',
          '<span class="cmt"># (no scope/ethics section)</span>',
          '<span class="cmt"># (no documentation standard)</span>',
          '<span class="cmt"># (no stop/escalate criteria)</span>',
        ]} />
        <Quiz multi
          onResolved={(ok) => recordScore('l8-gaps', ok)}
          q={{
            prompt: 'Identify the real gaps in this plan. Select all that apply.',
            options: [
              { id: 'a', label: 'No scope / ethics boundary section.' },
              { id: 'b', label: 'No documentation / source-record standard.' },
              { id: 'c', label: 'Tools listed but not mapped to requirements ("various", exiftool is irrelevant here).' },
              { id: 'd', label: 'No stop / escalate criteria.' },
              { id: 'e', label: 'It uses the word "domain" too often.' },
            ],
            correct: ['a', 'b', 'c', 'd'],
            explain: 'Four substantive gaps: missing boundaries, no documentation standard, an unmapped/irrelevant tool list, and no stop criteria. (e) is not a real issue — peer review must be specific and substantive, not stylistic nitpicking.',
          }}
        />
      </Panel>
      <Panel label="Reflection">
        <Reflection
          prompt={'Which section of your own plan was hardest to write, and what did reviewing someone else\u2019s teach you about your own?'}
          placeholder="Write 2–3 sentences…"
          min={60}
          model={'The scope/ethics boundaries were hardest — being specific about what NOT to do forces you to anticipate temptation under pressure. Reviewing another plan made the absence of a documentation standard and stop criteria glaringly obvious, which sent me back to tighten those exact sections in my own.'}
          onResolved={(ok) => recordScore('l8-reflect', ok)}
        />
      </Panel>
    </StepBody>
  );
}

export const lab8 = {
  steps: [
    { label: 'Briefing', taskCount: 0, component: Brief },
    { label: 'Tool Matrix', taskCount: 1, component: Matrix },
    { label: 'Scope & Stop', taskCount: 2, component: PlanSections },
    { label: 'Peer Review', taskCount: 2, component: PeerReview },
  ],
};
