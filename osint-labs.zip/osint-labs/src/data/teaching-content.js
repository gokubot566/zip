// Teaching content per lab: a Lesson (one cast member teaches the concept)
// and a DialogueScene (the team works the scenario). Rendered in each Brief.

export const LAB_TEACHING = {
  1: {
    lesson: {
      speaker: 'elena', title: 'The intelligence cycle is the whole job',
      intro: 'Before you run a single search, internalise the loop we work in. OSINT is not "Googling people" — it is a disciplined cycle that turns a question into a defensible answer.',
      points: [
        '<b>Planning &amp; Direction</b> — define the question, the scope, and the ethics boundaries first.',
        '<b>Collection</b> — gather raw, public data from sources, passively and lawfully.',
        '<b>Processing</b> — organise, de-duplicate, normalise before you interpret anything.',
        '<b>Analysis</b> — turn processed data into assessed, sourced findings with confidence.',
        '<b>Dissemination</b> — deliver to the decision-maker and take feedback into the next loop.',
      ],
      aside: { speaker: 'david', text: 'And the hard line: the moment you deceive a target or touch a system without authorisation, it stops being OSINT — and may be unlawful. I enforce that line.' },
    },
    dialogue: { title: 'Day one · #ti-team', lines: [
      { s: 'elena', t: 'Welcome to the team. You are shadowing a brand-impersonation case. First rule: tell me which stage of the cycle you are in at every decision point.' },
      { s: 'priya', t: 'And separate what you <b>know</b> from what you <b>think</b>. We grade on calibrated, sourced findings — not vibes.' },
      { s: 'david', t: 'If a shortcut requires a fake account or contacting the target, the answer is no. Document the limit and report the gap.' },
    ] },
  },
  2: {
    lesson: {
      speaker: 'elena', title: 'Find it in three queries — and prove it',
      intro: 'A strong analyst finds in three precise queries what a junior spends an hour on, and can <b>prove</b> where every finding came from. Two skills: operators, and source records.',
      points: [
        '<b>site:</b> restricts results to one domain; <b>"exact phrase"</b> forces literal matches.',
        '<b>filetype:</b> and <b>intitle:</b> narrow to documents or page titles fast.',
        'When a page is deleted, cite the <b>Wayback snapshot URL + capture date + screenshot</b>.',
        'A source record = exact query + result URL + access timestamp + screenshot/snapshot.',
        'The test of a good findings log: another analyst can reproduce every finding exactly.',
      ],
      aside: { speaker: 'auditor', text: 'When I review your work, I do not re-investigate — I re-run your source records. If they do not reproduce, the finding does not stand.' },
    },
    dialogue: { title: 'Practice tasking · Acme Logistics', lines: [
      { s: 'elena', t: 'Work this against our fictional training company. Operators, not luck — and a findings log I could hand to anyone.' },
      { s: 'marcus', t: 'A lot of what you want is in cached and archived pages. Learn the Wayback Machine early; it is half the job.' },
    ] },
  },
  3: {
    lesson: {
      speaker: 'elena', title: 'Pivot on identifiers — rate every link',
      intro: 'From a few seed identifiers (email, display name, username) you can pivot to linked accounts. But never assume two accounts are the same just because a handle matches. Rate every link.',
      points: [
        '<b>Confirmed</b> — a hard shared identifier (verified recovery email/phone) plus corroboration.',
        '<b>Probable</b> — corroborated but not nailed by a hard identifier.',
        '<b>Possible</b> — weak, reusable signals only (matching handle, similar bio).',
        '<b>Unsupported</b> — differing photos/writing style break an apparent match.',
        'Usernames are <b>reused</b> constantly — handle reuse alone is the classic false-match trap.',
      ],
      aside: { speaker: 'david', text: 'These charts can drive fraud, HR or legal action. A weak link presented as fact can defame an innocent person and discredit the whole case. Label confidence on every edge.' },
    },
    dialogue: { title: 'Supplier-portal alert', lines: [
      { s: 'priya', t: 'A suspicious vendor just onboarded. We have an email, a display name, and a support-ticket username. Find the linked accounts.' },
      { s: 'elena', t: 'And tell me your confidence in each link, with the corroboration. "Connected" is not a finding.' },
    ] },
  },
  4: {
    lesson: {
      speaker: 'marcus', title: 'Cluster the infrastructure, build clean IOCs',
      intro: 'A phishing domain rarely stands alone. Public records let you pivot from one lookalike to the whole adversary cluster — without ever touching their systems.',
      points: [
        'Pivot on <b>shared hosting IP</b>, <b>name servers</b>, and <b>TLS cert fingerprints</b> to cluster domains.',
        '<b>Certificate-transparency logs</b> and <b>passive DNS</b> are public — fully passive collection.',
        'Beware <b>shared CDN IPs</b>: legitimate sites share them. A shared CDN IP is not attribution.',
        'Never block a verified legitimate domain — verify ownership before adding any IOC.',
        'Ship the SOC an IOC package <b>with provenance</b>, so each indicator can be triaged and trusted.',
      ],
      aside: { speaker: 'priya', text: 'I have seen a team block their own careers site because it shared a CDN IP with a phish. Verify ownership first — every time.' },
    },
    dialogue: { title: 'Post-incident attribution', lines: [
      { s: 'marcus', t: 'merid1an-secure.com ran a phishing campaign against us. The campaign is over; I want the infrastructure picture.' },
      { s: 'elena', t: 'Map who registered it, the hosting, the name servers, the cert — and whether it is part of a bigger lookalike cluster.' },
    ] },
  },
  5: {
    lesson: {
      speaker: 'elena', title: 'Profile your own attack surface — passively',
      intro: 'This is a consented internal exercise: profile what an attacker could learn about us from public posts. The discipline is staying strictly passive — public view only, no contact.',
      points: [
        'In scope: <b>public posts viewed without an account, no action taken</b>.',
        'Out of scope: following, fake accounts, DMs, or any contact with people.',
        'Attackers harvest <b>named tooling</b> (Okta, CrowdStrike), <b>office changes</b>, <b>routines</b>.',
        '"Finance team out Friday" is <b>BEC fuel</b> — timing a fraud when approvers are away.',
        'Deliverable: the picture an attacker could build, plus the exposure to reduce.',
      ],
      aside: { speaker: 'david', text: 'Even internally: do not actually send a test phish to staff without explicit sign-off and a defined process. Mapping exposure is fine; live-phishing colleagues is not.' },
    },
    dialogue: { title: 'Awareness-team request', lines: [
      { s: 'priya', t: 'How much does our own org leak through staff social media? Build the picture an attacker would use for a spear-phish.' },
      { s: 'elena', t: 'Strictly passive. No contact, no following, no fake accounts. Public view only.' },
    ] },
  },
  6: {
    lesson: {
      speaker: 'marcus', title: 'Read the metadata, then prove it with the frame',
      intro: 'Images carry two kinds of evidence: metadata you read, and clues inside the frame you interpret. EXIF GPS is a strong lead — but it is spoofable, so corroborate it visually.',
      points: [
        '<b>EXIF</b> may hold GPS, device, and timestamps — treat GPS as a lead, not gospel.',
        'EXIF can be <b>stripped, faked, or wrong</b>; never report coordinates alone.',
        '<b>Reverse-image search</b> catches reused/stock photos — a reused image is not original proof.',
        'Geolocate from <b>street signs, plate formats, drive side, building matches</b> — combined.',
        'Report location <b>with confidence and the corroborating cues</b> that justify it.',
      ],
      aside: { speaker: 'auditor', text: 'If a counterparty offers a "photo of our facility" that turns out to be a 2019 stock image, that is not just weak evidence — presenting it as proof is misrepresentation.' },
    },
    dialogue: { title: 'Counterparty verification', lines: [
      { s: 'priya', t: 'A counterparty sent images to back up their claims. Tell me what is real, what is reused, and where these were actually taken.' },
      { s: 'marcus', t: 'Start with EXIF, then verify visually. I want a confidence level on every geolocation.' },
    ] },
  },
  7: {
    lesson: {
      speaker: 'auditor', title: 'Trace ownership, screen risk, never defame',
      intro: 'Due diligence asks three things: who really owns this, what risk attaches to them, and have we mistaken them for someone else. The discipline is separating fact from rumour.',
      points: [
        '<b>Beneficial owner (UBO)</b> = the natural person who ultimately controls the entity, behind nominees/layers.',
        'Trace ownership through <b>registry extracts</b> — sourced and dated facts.',
        '<b>Same-name traps</b>: a sanctions/adverse hit with a different DOB/country is a different person.',
        'A mismatched hit is <b>checked and ruled out</b> — recorded, not included as if it applied.',
        'Split <b>verified facts</b> from <b>unconfirmed leads</b> — never defame on rumour.',
      ],
      aside: { speaker: 'david', text: 'Including a sanctions hit that belongs to a same-name stranger could kill a legitimate deal and defame an innocent person. Match the identifiers before you write a word.' },
    },
    dialogue: { title: 'Pre-deal due diligence', lines: [
      { s: 'priya', t: 'We are about to onboard a counterparty. Verify who really owns it and screen the principals for risk.' },
      { s: 'auditor', t: 'And be ruthless about same-name decoys. The cost of a false positive here is a lawsuit.' },
    ] },
  },
  8: {
    lesson: {
      speaker: 'elena', title: 'A plan beats improvisation',
      intro: 'Repeatable investigations need a collection plan: requirements mapped to methods and tools, a hard scope/ethics boundary, a documentation standard, and defined stop/escalate points.',
      points: [
        'Map each <b>requirement</b> to the right <b>method</b> (DNS/CT for infra, username search for identity, EXIF for images).',
        'Scope &amp; ethics: <b>passive-only</b>, lawful sources, platform-terms compliant, data-retention rules.',
        'Tools must be <b>mapped to requirements</b> — "various" and irrelevant tools are a red flag.',
        'Define a <b>documentation / source-record standard</b> up front.',
        'Define <b>stop / escalate</b> criteria — e.g. a live phish hands off to SOC/legal as an incident.',
      ],
      aside: { speaker: 'auditor', text: 'When I peer-review a plan, the first thing I look for is whether the tools actually map to the requirements — and whether there is a stop criterion. Most weak plans fail both.' },
    },
    dialogue: { title: 'Build the playbook', lines: [
      { s: 'priya', t: 'I want a reusable OSINT collection plan for impersonation monitoring — not a one-off.' },
      { s: 'elena', t: 'Then you will peer-review another analyst\u2019s plan. Finding the gaps is half the skill.' },
    ] },
  },
  9: {
    lesson: {
      speaker: 'priya', title: 'Calibrated language is the product',
      intro: 'Raw findings are not intelligence. Intelligence is a calibrated, sourced judgement a decision-maker can act on. The words you choose carry the confidence.',
      points: [
        'Use a fixed <b>probability lexicon</b> ("likely", "very likely") so confidence reads the same to everyone.',
        'Separate <b>fact</b> (cite the source) from <b>judgement</b> (assign a confidence band).',
        'Lead with a <b>BLUF</b> — the assessed answer and confidence first, detail after.',
        'Favour <b>diagnostic</b> findings (ACH): evidence that fits one hypothesis and not the others.',
        'Never overstate — "certain" is almost never honest in OSINT attribution.',
      ],
      aside: { speaker: 'auditor', text: 'A captured, dated observation is a fact. "Probably hiding assets" is a judgement. Mixing them is the fastest way to lose a reader\u2019s trust.' },
    },
    dialogue: { title: 'Turning findings into a product', lines: [
      { s: 'priya', t: 'You have the findings from the impersonation case. Now write it up so leadership can act — BLUF first, calibrated throughout.' },
      { s: 'elena', t: 'Watch your probability words. "Likely" and "very likely" are not interchangeable.' },
    ] },
  },
  10: {
    lesson: {
      speaker: 'elena', title: 'Fuse the sources — stay honest about confidence',
      intro: 'The capstone fuses everything: identity, infrastructure, imagery and reporting into one attribution. The hard part is not finding links — it is rating them honestly and excluding red herrings.',
      points: [
        'Build a <b>link table</b>: each element, its linking signal, and the strength of that link.',
        'A <b>shared generic CDN IP alone</b> is not a link — exclude red herrings explicitly.',
        'State attribution with a <b>confidence band</b> and name the <b>weakest</b> link.',
        'Assess <b>real-world impact</b> — e.g. an Australian notifiable data breach (passport numbers).',
        'Ship a <b>takedown/IOC package with provenance</b>, and brief the board honestly.',
      ],
      aside: { speaker: 'david', text: 'When the board asks "are you 100% sure?", the right answer is calibrated: what is strong, what is weak, and what one more identifier would change. Never "completely certain".' },
    },
    dialogue: { title: 'Major investigation · capstone', lines: [
      { s: 'priya', t: 'Four impersonation elements, one question: is this one actor? Fuse the sources and give me a defensible attribution.' },
      { s: 'david', t: 'There are real-world consequences here — including a possible notifiable data breach. Get the impact assessment right.' },
      { s: 'auditor', t: 'I will review the weakest link in your chain. Be honest about it before I find it.' },
    ] },
  },
};
