// Shared cast — same five people across every Security Impossible course.
// ids, names, brand colors and portraits are CONSTANT; only role is re-tagged
// per course to fit the scenario. Valid speaker ids: elena, marcus, priya,
// david, auditor  (the 5th is "auditor", never "hannah").
export const CHARACTERS = {
  elena:   { name: 'Elena Vasquez', role: 'OSINT Team Lead — your mentor',     color: '#6366f1' },
  marcus:  { name: 'Marcus Chen',   role: 'Infrastructure & Network Analyst',  color: '#3b82f6' },
  priya:   { name: 'Priya Patel',   role: 'Head of Threat Intelligence',       color: '#10b981' },
  david:   { name: 'David Okafor',  role: 'Legal & Risk Counsel',              color: '#f59e0b' },
  auditor: { name: 'Hannah Wong',   role: 'External Verification Reviewer',    color: '#06b6d4' },
};

export const castName = (id) => (CHARACTERS[id] || CHARACTERS.elena).name;
