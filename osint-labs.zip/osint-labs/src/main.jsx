import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import { labById } from './data/labs.js';
import Index from './Index.jsx';
import LabShell from './components/LabShell.jsx';
import { LAB_REGISTRY } from './labs/registry.jsx';

function resolveLabId() {
  // 0) runtime-injected (nginx entrypoint writes window.__LAB__ from $LAB env)
  if (typeof window !== 'undefined' && window.__LAB__ && window.__LAB__ !== '__LAB__') {
    return Number(window.__LAB__);
  }
  // 1) build-time env (set per container): VITE_LAB=1..10
  const envLab = import.meta.env.VITE_LAB;
  if (envLab) return Number(envLab);
  // 2) path /lab/3
  const m = window.location.pathname.match(/lab\/(\d+)/);
  if (m) return Number(m[1]);
  // 3) ?lab=3
  const q = new URLSearchParams(window.location.search).get('lab');
  if (q) return Number(q);
  return null;
}

function App() {
  const id = resolveLabId();
  if (!id) return <Index />;
  const lab = labById(id);
  const def = LAB_REGISTRY[id];
  if (!lab || !def) return <Index />;
  return <LabShell lab={lab} steps={def.steps} />;
}

createRoot(document.getElementById('root')).render(<App />);
