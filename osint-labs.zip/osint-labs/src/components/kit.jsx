import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Terminal as TermIcon, CheckCircle2, XCircle, ChevronRight, Lightbulb,
  ShieldCheck, Lock
} from 'lucide-react';

/* ============ Panel ============ */
export function Panel({ icon: Icon, label, children, soft }) {
  return (
    <div className={`panel ${soft ? 'panel-soft' : ''}`}>
      {label && (
        <div className="panel-head">
          {Icon && <Icon size={15} />} {label}
        </div>
      )}
      {children}
    </div>
  );
}

/* ============ Scenario quote ============ */
export function Scenario({ text, who }) {
  return (
    <div className="scenario-quote">
      {text}
      {who && <span className="who">— {who}</span>}
    </div>
  );
}

/* ============ Briefing list ============ */
export function Briefing({ items }) {
  return (
    <ul className="brief-list">
      {items.map((it, i) => (
        <li key={i}><ShieldCheck size={15} /> <span>{it}</span></li>
      ))}
    </ul>
  );
}

/* ============ Terminal / evidence viewer ============ */
export function Terminal({ title, lines }) {
  return (
    <div className="terminal">
      <div className="terminal-bar">
        <span className="dot" style={{ background: '#ff5d5d' }} />
        <span className="dot" style={{ background: '#ffb547' }} />
        <span className="dot" style={{ background: '#4ade80' }} />
        <span style={{ marginLeft: 8 }}>{title || 'evidence://session'}</span>
      </div>
      <div className="terminal-body">
        {lines.map((l, i) => <div key={i} dangerouslySetInnerHTML={{ __html: l }} />)}
      </div>
    </div>
  );
}

/* ============ Data table ============ */
export function DataTable({ columns, rows }) {
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead><tr>{columns.map((c, i) => <th key={i}>{c.label}</th>)}</tr></thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              {columns.map((c, j) => (
                <td key={j} className={r._cls?.[c.key] || ''}>{r[c.key]}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ============ Single/Multi choice quiz ============
   q = { prompt, options:[{id,label}], correct: id | [ids], explain }  */
export function Quiz({ q, multi = false, onResolved }) {
  const [sel, setSel] = useState(multi ? [] : null);
  const [checked, setChecked] = useState(false);

  const correctSet = useMemo(
    () => new Set(Array.isArray(q.correct) ? q.correct : [q.correct]),
    [q]
  );

  const toggle = (id) => {
    if (checked) return;
    if (multi) setSel(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
    else setSel(id);
  };

  const isRight = useMemo(() => {
    if (multi) {
      const s = new Set(sel);
      return s.size === correctSet.size && [...s].every(x => correctSet.has(x));
    }
    return correctSet.has(sel);
  }, [sel, checked, multi, correctSet]);

  const check = () => {
    setChecked(true);
    onResolved && onResolved(isRight);
  };

  return (
    <div>
      <p style={{ color: 'var(--ink)', fontSize: 15, marginBottom: 16 }}>{q.prompt}</p>
      <div className="choices">
        {q.options.map((o) => {
          let cls = 'choice';
          const picked = multi ? sel.includes(o.id) : sel === o.id;
          if (!checked && picked) cls += ' selected';
          if (checked) {
            if (correctSet.has(o.id)) cls += ' correct';
            else if (picked) cls += ' wrong';
          }
          return (
            <button key={o.id} className={cls} onClick={() => toggle(o.id)}>
              <span className="marker">
                {checked && correctSet.has(o.id) ? <CheckCircle2 size={13} />
                  : checked && picked ? <XCircle size={13} />
                  : o.id.toUpperCase()}
              </span>
              <span>{o.label}</span>
            </button>
          );
        })}
      </div>
      {!checked ? (
        <div className="btn-row">
          <button className="btn btn-primary" disabled={multi ? sel.length === 0 : sel === null} onClick={check}>
            Check answer <ChevronRight size={15} />
          </button>
        </div>
      ) : (
        <div className={`feedback ${isRight ? 'ok' : 'no'}`}>
          <b>{isRight ? 'Correct.' : 'Not quite.'}</b> {q.explain}
        </div>
      )}
    </div>
  );
}

/* ============ Classifier — drag-free: assign each item a category ============
   items=[{id,text}], categories=[{id,label}], answer={itemId:catId}, explain */
export function Classifier({ items, categories, answer, explain, onResolved }) {
  const [assign, setAssign] = useState({});
  const [checked, setChecked] = useState(false);
  const allDone = items.every(it => assign[it.id]);
  const score = items.filter(it => assign[it.id] === answer[it.id]).length;

  const check = () => { setChecked(true); onResolved && onResolved(score === items.length); };

  return (
    <div>
      <div style={{ display: 'grid', gap: 12 }}>
        {items.map(it => {
          const right = checked && assign[it.id] === answer[it.id];
          const wrong = checked && assign[it.id] && assign[it.id] !== answer[it.id];
          return (
            <div key={it.id} className="panel-soft" style={{
              padding: 14, borderRadius: 10, border: '1px solid',
              borderColor: right ? 'var(--signal-dim)' : wrong ? 'var(--alert-dim)' : 'var(--line)',
              background: 'var(--bg-2)'
            }}>
              <div style={{ fontSize: 14, color: 'var(--ink)', marginBottom: 10 }}>{it.text}</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {categories.map(c => (
                  <button key={c.id}
                    className={`btn ${assign[it.id] === c.id ? 'btn-primary' : 'btn-ghost'}`}
                    style={{ padding: '7px 12px', fontSize: 12 }}
                    disabled={checked}
                    onClick={() => setAssign(a => ({ ...a, [it.id]: c.id }))}>
                    {c.label}
                  </button>
                ))}
              </div>
              {checked && wrong && (
                <div className="note-inline" style={{ marginTop: 8, color: 'var(--signal)' }}>
                  Correct: {categories.find(c => c.id === answer[it.id])?.label}
                </div>
              )}
            </div>
          );
        })}
      </div>
      {!checked ? (
        <div className="btn-row">
          <button className="btn btn-primary" disabled={!allDone} onClick={check}>
            Submit classification <ChevronRight size={15} />
          </button>
        </div>
      ) : (
        <div className={`feedback ${score === items.length ? 'ok' : 'info'}`}>
          <b>{score}/{items.length} correct.</b> {explain}
        </div>
      )}
    </div>
  );
}

/* ============ Exact / keyword answer checker ============
   accepts: array of acceptable substrings (lowercased match), normalize */
export function AnswerCheck({ prompt, placeholder, accepts, explain, hint, onResolved, mono = true, area = false }) {
  const [val, setVal] = useState('');
  const [checked, setChecked] = useState(false);
  const [showHint, setShowHint] = useState(false);

  const norm = (s) => s.toLowerCase().replace(/\s+/g, ' ').trim();
  const right = useMemo(() => {
    const v = norm(val);
    return accepts.some(a => v.includes(norm(a)));
  }, [val, checked]);

  const check = () => { setChecked(true); onResolved && onResolved(right); };

  return (
    <div className="field">
      {prompt && <label>{prompt}</label>}
      {area
        ? <textarea className="textarea" placeholder={placeholder} value={val}
            onChange={e => { setVal(e.target.value); setChecked(false); }} />
        : <input className="input" placeholder={placeholder} value={val}
            style={{ fontFamily: mono ? 'var(--mono)' : 'var(--display)' }}
            onChange={e => { setVal(e.target.value); setChecked(false); }} />}
      <div className="btn-row">
        <button className="btn btn-primary" disabled={!val.trim()} onClick={check}>
          Verify <ChevronRight size={15} />
        </button>
        {hint && <button className="btn btn-ghost" onClick={() => setShowHint(h => !h)}>
          <Lightbulb size={14} /> Hint
        </button>}
      </div>
      {showHint && hint && <div className="hint">{hint}</div>}
      {checked && (
        <div className={`feedback ${right ? 'ok' : 'no'}`}>
          <b>{right ? 'Verified.' : 'Keep looking.'}</b> {right ? explain : 'That doesn\u2019t match the evidence yet. Re-check your sources and try again.'}
        </div>
      )}
    </div>
  );
}

/* ============ Free-text reflection (always "accepts", min length) ============ */
export function Reflection({ prompt, placeholder, min = 40, model, onResolved }) {
  const [val, setVal] = useState('');
  const [done, setDone] = useState(false);
  const ok = val.trim().length >= min;
  return (
    <div className="field">
      <label>{prompt}</label>
      <textarea className="textarea" placeholder={placeholder} value={val}
        style={{ fontFamily: 'var(--display)', minHeight: 120 }}
        onChange={e => setVal(e.target.value)} />
      <div className="note-inline" style={{ marginTop: 6 }}>{val.trim().length} chars {ok ? '\u2713' : `(min ${min})`}</div>
      <div className="btn-row">
        <button className="btn btn-primary" disabled={!ok} onClick={() => { setDone(true); onResolved && onResolved(true); }}>
          Submit & see model answer
        </button>
      </div>
      {done && model && (
        <div className="feedback info">
          <b>Model approach:</b> {model}
        </div>
      )}
    </div>
  );
}

/* ============ Ethics gate — a hard yes/no boundary check ============ */
export function EthicsGate({ scenario, options, correct, explain, onResolved }) {
  const [sel, setSel] = useState(null);
  const [checked, setChecked] = useState(false);
  return (
    <Panel icon={Lock} label="Ethics & Legal Boundary" soft>
      <p style={{ color: 'var(--ink)' }}>{scenario}</p>
      <div className="choices" style={{ marginTop: 14 }}>
        {options.map(o => {
          let cls = 'choice';
          if (!checked && sel === o.id) cls += ' selected';
          if (checked) { if (o.id === correct) cls += ' correct'; else if (sel === o.id) cls += ' wrong'; }
          return (
            <button key={o.id} className={cls} disabled={checked} onClick={() => setSel(o.id)}>
              <span className="marker">{checked && o.id === correct ? <CheckCircle2 size={13} /> : o.id.toUpperCase()}</span>
              <span>{o.label}</span>
            </button>
          );
        })}
      </div>
      {!checked ? (
        <div className="btn-row"><button className="btn btn-primary" disabled={!sel} onClick={() => { setChecked(true); onResolved && onResolved(sel === correct); }}>Decide</button></div>
      ) : (
        <div className={`feedback ${sel === correct ? 'ok' : 'no'}`}>
          <b>{sel === correct ? 'Right call.' : 'That crosses the line.'}</b> {explain}
        </div>
      )}
    </Panel>
  );
}

/* ============ Step container with completion tracking ============ */
export function StepBody({ children }) {
  return (
    <motion.div className="fade-stack"
      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
      {children}
    </motion.div>
  );
}
