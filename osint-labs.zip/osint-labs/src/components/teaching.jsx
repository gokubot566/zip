import React, { useState, useMemo, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CheckCircle2, XCircle, ChevronRight, RotateCcw, Lock, Unlock,
  GraduationCap, MessageSquare, Award,
} from 'lucide-react';
import { CastPhoto } from './Cast.jsx';
import { CHARACTERS } from '../data/cast.js';

/* ============ Lesson — one cast member teaching a concept ============
   speaker = cast id; title; points = [html strings]; aside? = {speaker,text} */
export function Lesson({ speaker = 'elena', title, intro, points = [], aside }) {
  const c = CHARACTERS[speaker];
  return (
    <div className="lesson">
      <div className="lesson-head">
        <CastPhoto id={speaker} size={56} speaking />
        <div>
          <div className="lesson-teacher" style={{ color: c.color }}>{c.name}</div>
          <div className="lesson-role">{c.role}</div>
        </div>
        <GraduationCap size={18} style={{ marginLeft: 'auto', color: 'var(--ink-faint)' }} />
      </div>
      {title && <div className="lesson-title">{title}</div>}
      {intro && <p className="lesson-intro" dangerouslySetInnerHTML={{ __html: intro }} />}
      {points.length > 0 && (
        <ul className="lesson-points">
          {points.map((p, i) => (
            <li key={i}><span className="lp-dot" style={{ background: c.color }} />
              <span dangerouslySetInnerHTML={{ __html: p }} /></li>
          ))}
        </ul>
      )}
      {aside && (
        <div className="lesson-aside">
          <CastPhoto id={aside.speaker} size={34} />
          <div><b style={{ color: CHARACTERS[aside.speaker].color }}>{CHARACTERS[aside.speaker].name}:</b>{' '}
            <span dangerouslySetInnerHTML={{ __html: aside.text }} /></div>
        </div>
      )}
    </div>
  );
}

/* ============ DialogueScene — the team working the scenario ============
   lines = [{ s:'<castId>', t:'<text>' }] */
export function DialogueScene({ lines = [], title = 'Team channel' }) {
  return (
    <div className="dialogue">
      <div className="dialogue-head"><MessageSquare size={14} /> {title}</div>
      <div className="dialogue-body">
        {lines.map((l, i) => {
          const c = CHARACTERS[l.s] || CHARACTERS.elena;
          return (
            <div key={i} className="dline">
              <CastPhoto id={l.s} size={38} speaking />
              <div className="dbubble">
                <div className="dname" style={{ color: c.color }}>{c.name} <span className="drole">{c.role}</span></div>
                <div className="dtext" dangerouslySetInnerHTML={{ __html: l.t }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ============ ModuleQuiz — 5 questions, gated at 80% (4/5) ============
   questions = [{ id, q, options:[{id,label}], correct:id, explain, asker? }]
   onPass(scorePct) fires once when 4/5+ reached. Unlimited retries. */
export function ModuleQuiz({ questions, passNeeded = 4, onPass, onAttempt }) {
  const [answers, setAnswers] = useState({});   // qid -> optionId
  const [submitted, setSubmitted] = useState(false);
  const [attempt, setAttempt] = useState(1);
  const resultRef = useRef(null);

  const total = questions.length;
  const correctCount = useMemo(
    () => questions.filter(q => answers[q.id] === q.correct).length,
    [answers, submitted, questions]
  );
  const passed = correctCount >= passNeeded;
  const allAnswered = questions.every(q => answers[q.id] != null);

  useEffect(() => {
    if (submitted) {
      if (typeof resultRef.current?.scrollIntoView === 'function') {
        resultRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      onAttempt && onAttempt(correctCount, passed);
      if (passed) onPass && onPass(Math.round((correctCount / total) * 100));
    }
  }, [submitted]);

  const pick = (qid, oid) => { if (submitted) return; setAnswers(a => ({ ...a, [qid]: oid })); };
  const submit = () => setSubmitted(true);
  const retry = () => { setAnswers({}); setSubmitted(false); setAttempt(a => a + 1); };

  return (
    <div className="mquiz">
      <div className="mquiz-head">
        <div className="mquiz-title">
          <Award size={16} /> Module checkpoint
          <span className="mquiz-gate">Pass mark {passNeeded}/{total} (80%)</span>
        </div>
        <div className="mquiz-attempt">Attempt {attempt}</div>
      </div>

      <div className="mquiz-list">
        {questions.map((q, qi) => {
          const picked = answers[q.id];
          return (
            <div key={q.id} className="mq">
              <div className="mq-prompt">
                <span className="mq-num">{qi + 1}</span>
                <span dangerouslySetInnerHTML={{ __html: q.q }} />
              </div>
              {q.asker && (
                <div className="mq-asker">
                  <CastPhoto id={q.asker} size={28} />
                  <span style={{ color: CHARACTERS[q.asker].color }}>{CHARACTERS[q.asker].name} asks</span>
                </div>
              )}
              <div className="choices">
                {q.options.map(o => {
                  let cls = 'choice';
                  const isPicked = picked === o.id;
                  if (!submitted && isPicked) cls += ' selected';
                  if (submitted) {
                    if (o.id === q.correct) cls += ' correct';
                    else if (isPicked) cls += ' wrong';
                  }
                  return (
                    <button key={o.id} className={cls} disabled={submitted} onClick={() => pick(q.id, o.id)}>
                      <span className="marker">
                        {submitted && o.id === q.correct ? <CheckCircle2 size={13} />
                          : submitted && isPicked ? <XCircle size={13} />
                          : o.id.toUpperCase()}
                      </span>
                      <span>{o.label}</span>
                    </button>
                  );
                })}
              </div>
              {submitted && (
                <div className={`feedback ${picked === q.correct ? 'ok' : 'no'}`} style={{ marginTop: 10 }}>
                  <b>{picked === q.correct ? 'Correct.' : 'Incorrect.'}</b> {q.explain}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {!submitted ? (
        <div className="btn-row">
          <button className="btn btn-primary" disabled={!allAnswered} onClick={submit}>
            Submit checkpoint <ChevronRight size={15} />
          </button>
          {!allAnswered && <span className="note-inline">Answer all {total} to submit.</span>}
        </div>
      ) : (
        <motion.div ref={resultRef} className={`mquiz-result ${passed ? 'pass' : 'fail'}`}
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          {passed ? <Unlock size={26} /> : <Lock size={26} />}
          <div style={{ flex: 1 }}>
            <div className="mqr-score">{correctCount}/{total} correct · {Math.round(correctCount / total * 100)}%</div>
            <div className="mqr-msg">
              {passed
                ? 'Checkpoint passed — the next module is unlocked.'
                : `You need ${passNeeded}/${total} to unlock the next module. Review the explanations above and try again.`}
            </div>
          </div>
          {!passed && (
            <button className="btn btn-ghost" onClick={retry}>
              <RotateCcw size={14} /> Retry checkpoint
            </button>
          )}
        </motion.div>
      )}
    </div>
  );
}

/* ============ Factories wired to per-lab data ============ */
import { LAB_TEACHING } from '../data/teaching-content.js';
import { LAB_QUIZZES } from '../data/quizzes.js';
import { StepBody } from './kit.jsx';

// Renders the teaching block (lesson + team dialogue) for a given lab id.
export function TeachingIntro({ labId }) {
  const t = LAB_TEACHING[labId];
  if (!t) return null;
  return (
    <>
      {t.lesson && <Lesson {...t.lesson} />}
      {t.dialogue && <DialogueScene title={t.dialogue.title} lines={t.dialogue.lines} />}
    </>
  );
}

// The gated checkpoint step for a given lab id. Calls onQuizPass(pct) up to the
// shell, which unlocks completion + any locked follow-on steps.
export function makeCheckpoint(labId) {
  return function Checkpoint({ onQuizPass, recordScore, quizPassed }) {
    const questions = LAB_QUIZZES[labId] || [];
    return (
      <StepBody>
        <div className="lesson" style={{ marginBottom: 18 }}>
          <div className="lesson-head">
            <GraduationCap size={18} style={{ color: 'var(--amber)' }} />
            <div>
              <div className="lesson-title" style={{ margin: 0 }}>Module checkpoint</div>
              <div className="lesson-role">Answer all five. You need 4/5 (80%) to unlock the next module.</div>
            </div>
          </div>
        </div>
        <ModuleQuiz
          questions={questions}
          passNeeded={4}
          onAttempt={(correct) => recordScore && recordScore(`l${labId}-checkpoint`, correct >= 4)}
          onPass={(pct) => onQuizPass && onQuizPass(pct)}
        />
        {quizPassed && (
          <div className="feedback ok" style={{ marginTop: 16 }}>
            <b>Checkpoint cleared.</b> You can now complete the lab and move to the next module.
          </div>
        )}
      </StepBody>
    );
  };
}
