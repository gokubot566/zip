import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Terminal as TermIcon, Search, ChevronRight, CornerDownLeft, CheckCircle2,
  Circle, Target, Image as ImageIcon, Network, Lightbulb, AlertTriangle,
} from 'lucide-react';

/* =================================================================
   GatedTask — wraps a practical and reports completion upward.
   The lab marks the STEP as gated; LabShell blocks "continue" until
   onObjective(true) has fired. Shows a live objective banner.
   ================================================================= */
export function ObjectiveBar({ done, label }) {
  return (
    <div className={`obj-bar ${done ? 'done' : ''}`}>
      {done ? <CheckCircle2 size={15} /> : <Target size={15} />}
      <span>{done ? 'Objective complete' : label}</span>
    </div>
  );
}

/* =================================================================
   SimTerminal — a REAL prompt. The trainee types commands; we match
   against a per-lab command table and stream the output back.
   - commands: [{ match: RegExp|fn(input)->bool, out: [lines] | fn(input)->[lines], note? }]
   - objectives: optional list of { id, test: (cmdHistory)=>bool, label }
   - onSolved(): fires when every objective satisfied
   Lines may contain HTML (spans for .hl/.cmt/.alert/.cmd).
   ================================================================= */
export function SimTerminal({
  prompt = 'analyst@osint:~$', intro = [], commands = [], hints = [],
  objectives = [], onSolved, height = 320, autoFocus = false,
}) {
  const [history, setHistory] = useState(() =>
    intro.map(t => ({ type: 'sys', text: t })));
  const [input, setInput] = useState('');
  const [cmdLog, setCmdLog] = useState([]);
  const [past, setPast] = useState([]);     // for up-arrow recall
  const [pIdx, setPIdx] = useState(-1);
  const [solvedIds, setSolvedIds] = useState({});
  const [hintOpen, setHintOpen] = useState(false);
  const bodyRef = useRef(null);
  const inRef = useRef(null);

  const allDone = objectives.length > 0 && objectives.every(o => solvedIds[o.id]);
  const firedRef = useRef(false);
  useEffect(() => {
    if (allDone && !firedRef.current) { firedRef.current = true; onSolved && onSolved(); }
  }, [allDone, onSolved]);

  useEffect(() => {
    if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
  }, [history]);
  useEffect(() => { if (autoFocus) inRef.current?.focus(); }, [autoFocus]);

  const run = useCallback((raw) => {
    const cmd = raw.trim();
    if (!cmd) return;
    const lines = [{ type: 'in', text: cmd }];
    const newLog = [...cmdLog, cmd];

    let matched = null;
    for (const c of commands) {
      const hit = typeof c.match === 'function' ? c.match(cmd) : c.match.test(cmd);
      if (hit) { matched = c; break; }
    }
    if (matched) {
      const out = typeof matched.out === 'function' ? matched.out(cmd) : matched.out;
      out.forEach(l => lines.push({ type: 'out', text: l }));
    } else if (/^(help|\?)$/i.test(cmd)) {
      lines.push({ type: 'out', text: 'Available tools in this exercise:' });
      commands.forEach(c => c.help && lines.push({ type: 'out', text: '  <span class="cmd">' + c.help + '</span>' }));
    } else if (/^clear$/i.test(cmd)) {
      setHistory([]); setInput(''); setCmdLog(newLog); setPast(p => [...p, cmd]); setPIdx(-1);
      return;
    } else {
      lines.push({ type: 'err', text: `command not found: ${cmd.split(' ')[0]} — type <span class="cmd">help</span> for available tools` });
    }

    setHistory(h => [...h, ...lines]);
    setCmdLog(newLog);
    setPast(p => [...p, cmd]); setPIdx(-1);

    // re-evaluate objectives against the full command log
    setSolvedIds(prev => {
      const next = { ...prev };
      objectives.forEach(o => { if (!next[o.id] && o.test(newLog, cmd)) next[o.id] = true; });
      return next;
    });
  }, [commands, cmdLog, objectives]);

  const onKey = (e) => {
    if (e.key === 'Enter') { run(input); setInput(''); }
    else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (!past.length) return;
      const ni = pIdx < 0 ? past.length - 1 : Math.max(0, pIdx - 1);
      setPIdx(ni); setInput(past[ni]);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (pIdx < 0) return;
      const ni = pIdx + 1;
      if (ni >= past.length) { setPIdx(-1); setInput(''); } else { setPIdx(ni); setInput(past[ni]); }
    }
  };

  return (
    <div className="sim-term-wrap">
      {objectives.length > 0 && (
        <div className="sim-obj-list">
          {objectives.map(o => (
            <div key={o.id} className={`sim-obj ${solvedIds[o.id] ? 'done' : ''}`}>
              {solvedIds[o.id] ? <CheckCircle2 size={14} /> : <Circle size={14} />}
              <span dangerouslySetInnerHTML={{ __html: o.label }} />
            </div>
          ))}
        </div>
      )}
      <div className="sim-term" style={{ height }} onClick={() => inRef.current?.focus()}>
        <div className="sim-term-bar">
          <span className="dot" style={{ background: '#ff5d5d' }} />
          <span className="dot" style={{ background: '#ffb547' }} />
          <span className="dot" style={{ background: '#4ade80' }} />
          <span style={{ marginLeft: 8 }}><TermIcon size={12} style={{ verticalAlign: 'middle' }} /> analyst workstation — bash</span>
        </div>
        <div className="sim-term-body" ref={bodyRef}>
          {history.map((l, i) => (
            <div key={i} className={`tl tl-${l.type}`}>
              {l.type === 'in' && <span className="tl-prompt">{prompt}</span>}
              <span dangerouslySetInnerHTML={{ __html: l.text }} />
            </div>
          ))}
          <div className="tl tl-live">
            <span className="tl-prompt">{prompt}</span>
            <input
              ref={inRef} className="sim-term-input" value={input}
              onChange={e => setInput(e.target.value)} onKeyDown={onKey}
              spellCheck={false} autoComplete="off" placeholder="type a command, then Enter…"
            />
          </div>
        </div>
      </div>
      {hints.length > 0 && (
        <div className="sim-hint-row">
          <button className="btn btn-ghost btn-sm" onClick={() => setHintOpen(o => !o)}>
            <Lightbulb size={13} /> {hintOpen ? 'Hide' : 'Show'} hints
          </button>
          {hintOpen && (
            <ul className="sim-hints">
              {hints.map((h, i) => <li key={i} dangerouslySetInnerHTML={{ __html: h }} />)}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

/* =================================================================
   SearchConsole — a fake search engine. The trainee types a query;
   results only surface when the query is precise enough (operators).
   - corpus: [{ title, url, snippet, requires:[tokens], badge? }]
     a result shows only if every token in `requires` is present in the query
   - objectives: [{ id, test:(query, shownResults)=>bool, label }]
   ================================================================= */
export function SearchConsole({ corpus = [], objectives = [], placeholder = 'search…', onSolved, hints = [] }) {
  const [q, setQ] = useState('');
  const [submitted, setSubmitted] = useState('');
  const [solved, setSolved] = useState({});
  const [hintOpen, setHintOpen] = useState(false);

  const norm = (s) => s.toLowerCase();
  const shown = useMemo(() => {
    if (!submitted.trim()) return null;
    const ql = norm(submitted);
    return corpus.filter(r => (r.requires || []).every(t => ql.includes(norm(t))));
  }, [submitted, corpus]);

  const allDone = objectives.length > 0 && objectives.every(o => solved[o.id]);
  const firedRef = useRef(false);
  useEffect(() => { if (allDone && !firedRef.current) { firedRef.current = true; onSolved && onSolved(); } }, [allDone, onSolved]);

  const search = () => {
    setSubmitted(q);
    const ql = norm(q);
    const results = corpus.filter(r => (r.requires || []).every(t => ql.includes(norm(t))));
    setSolved(prev => {
      const next = { ...prev };
      objectives.forEach(o => { if (!next[o.id] && o.test(ql, results)) next[o.id] = true; });
      return next;
    });
  };

  return (
    <div className="sc-wrap">
      {objectives.length > 0 && (
        <div className="sim-obj-list">
          {objectives.map(o => (
            <div key={o.id} className={`sim-obj ${solved[o.id] ? 'done' : ''}`}>
              {solved[o.id] ? <CheckCircle2 size={14} /> : <Circle size={14} />}
              <span dangerouslySetInnerHTML={{ __html: o.label }} />
            </div>
          ))}
        </div>
      )}
      <div className="sc-bar">
        <Search size={16} />
        <input className="sc-input" value={q} placeholder={placeholder} spellCheck={false}
          onChange={e => setQ(e.target.value)} onKeyDown={e => e.key === 'Enter' && search()} />
        <button className="btn btn-primary btn-sm" onClick={search}>Search <CornerDownLeft size={13} /></button>
      </div>
      {shown !== null && (
        <div className="sc-results">
          <div className="sc-stat">{shown.length === 0
            ? 'No results — your query is too broad or has no matching documents. Try tighter operators.'
            : `${shown.length} result${shown.length > 1 ? 's' : ''} for: ${submitted}`}</div>
          {shown.map((r, i) => (
            <motion.div key={i} className="sc-result" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
              <div className="sc-url">{r.url} {r.badge && <span className="sc-badge">{r.badge}</span>}</div>
              <div className="sc-title">{r.title}</div>
              <div className="sc-snip" dangerouslySetInnerHTML={{ __html: r.snippet }} />
            </motion.div>
          ))}
        </div>
      )}
      {hints.length > 0 && (
        <div className="sim-hint-row">
          <button className="btn btn-ghost btn-sm" onClick={() => setHintOpen(o => !o)}>
            <Lightbulb size={13} /> {hintOpen ? 'Hide' : 'Show'} hints
          </button>
          {hintOpen && <ul className="sim-hints">{hints.map((h, i) => <li key={i} dangerouslySetInnerHTML={{ __html: h }} />)}</ul>}
        </div>
      )}
    </div>
  );
}

/* =================================================================
   FieldProbe — a generic "read the data, type the answer" gate that
   feeds the objective system. Used to confirm the trainee extracted
   the right value from a simulator's output.
   ================================================================= */
export function FieldProbe({ prompt, accepts = [], placeholder = 'answer…', explain, onSolved, mono = true }) {
  const [val, setVal] = useState('');
  const [checked, setChecked] = useState(false);
  const norm = (s) => s.toLowerCase().replace(/\s+/g, ' ').trim();
  const right = useMemo(() => accepts.some(a => norm(val).includes(norm(a))), [val, accepts]);
  const firedRef = useRef(false);
  const check = () => {
    setChecked(true);
    if (right && !firedRef.current) { firedRef.current = true; onSolved && onSolved(); }
  };
  return (
    <div className="field probe">
      {prompt && <label>{prompt}</label>}
      <div className="probe-row">
        <input className="input" value={val} placeholder={placeholder} spellCheck={false}
          style={{ fontFamily: mono ? 'var(--mono)' : 'var(--display)' }}
          onChange={e => { setVal(e.target.value); setChecked(false); }}
          onKeyDown={e => e.key === 'Enter' && check()} />
        <button className="btn btn-primary btn-sm" disabled={!val.trim()} onClick={check}>Verify</button>
      </div>
      {checked && (
        <div className={`feedback ${right ? 'ok' : 'no'}`}>
          <b>{right ? 'Verified.' : 'Not yet.'}</b> {right ? explain : 'That does not match what the tool returned. Re-read the output and try again.'}
        </div>
      )}
    </div>
  );
}
