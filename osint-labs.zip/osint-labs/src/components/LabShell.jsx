import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Crosshair, Award, RotateCcw, ChevronRight, ChevronLeft, ArrowLeft, Lock } from 'lucide-react';

const tierClass = (t) =>
  t === 'Foundational' ? 'tier-foundational' : t === 'Applied' ? 'tier-applied' : 'tier-complex';

export default function LabShell({ lab, steps }) {
  const STORE_KEY = `si-osint-lab-${lab.id}`;

  const [active, setActive] = useState(0);
  const [done, setDone] = useState({});
  const [scores, setScores] = useState({});
  const [quizPassed, setQuizPassed] = useState(false);
  const [quizPct, setQuizPct] = useState(0);
  const [solvedSteps, setSolvedSteps] = useState({});   // stepIndex -> bool (gated practicals)
  const topRef = useRef(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) {
        const s = JSON.parse(raw);
        setDone(s.done || {}); setScores(s.scores || {});
        setQuizPassed(!!s.quizPassed); setQuizPct(s.quizPct || 0);
        setSolvedSteps(s.solvedSteps || {});
      }
    } catch {}
  }, [STORE_KEY]);

  useEffect(() => {
    try { localStorage.setItem(STORE_KEY, JSON.stringify({ done, scores, quizPassed, quizPct, solvedSteps })); } catch {}
  }, [done, scores, quizPassed, quizPct, solvedSteps, STORE_KEY]);

  useEffect(() => { if (typeof topRef.current?.scrollIntoView === 'function') topRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, [active]);

  const markStep = (i) => setDone(d => ({ ...d, [i]: true }));
  const recordScore = (key, ok) => setScores(s => ({ ...s, [key]: ok }));

  const totalTasks = steps.reduce((n, s) => n + (s.taskCount || 0), 0);
  const correctTasks = Object.values(scores).filter(Boolean).length;
  const answeredTasks = Object.keys(scores).length;

  const quizIndex = steps.findIndex(s => s.isQuiz);
  const isStepLocked = (i) => {
    if (quizIndex >= 0 && i > quizIndex && !quizPassed) return true;
    return false;
  };

  const StepComp = steps[active].component;
  const isQuizStep = steps[active].isQuiz;
  const isGatedStep = !!steps[active].gated;
  const currentSolved = solvedSteps[active];
  const blockContinue = isGatedStep && !currentSolved;
  const isLast = active === steps.length - 1;
  const allComplete = quizPassed && Object.keys(done).length >= steps.length;

  return (
    <div className="app-shell" ref={topRef}>
      <div className="topbar">
        <span className="brand-mark">SI · OSINT</span>
        <span className="brand-text"><b>Security Impossible</b> &mdash; Threat Intelligence Lab Range</span>
        <span className="topbar-spacer" />
        <a href="/" className="chip" style={{ textDecoration: 'none' }}><ArrowLeft size={12} /> All labs</a>
        <span className="port-chip">:{lab.port}</span>
        <span className="classification">INTERNAL · TRAINING</span>
      </div>

      <div className="lab-head">
        <div className="lab-eyebrow">
          <span>Lab {String(lab.id).padStart(2, '0')}</span>
          <span className={`tier-pill ${tierClass(lab.tier)}`}>{lab.tier}</span>
          <span>{lab.sfia}</span>
          <span>· {lab.dur}</span>
        </div>
        <h1 className="lab-title"><span className="num">{String(lab.id).padStart(2, '0')} /</span> {lab.title}</h1>
        <div className="lab-meta-row">
          <span>Primary skill <b>{lab.skill}</b></span>
          <span>Platform <b>OSINT analyst workstation</b></span>
          <span>Org <b>Meridian Financial Services</b></span>
        </div>
      </div>

      <div className="progress-rail">
        {steps.map((s, i) => {
          const locked = isStepLocked(i);
          return (
            <button key={i}
              className={`step-dot ${i === active ? 'active' : ''} ${done[i] ? 'done' : ''} ${locked ? 'locked' : ''}`}
              onClick={() => { if (!locked) setActive(i); }}
              title={locked ? 'Pass the module checkpoint to unlock' : ''}>
              <span className="idx">{locked ? <Lock size={11} /> : i + 1}</span>{s.label}
            </button>
          );
        })}
      </div>

      {totalTasks > 0 && (
        <div style={{ fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--ink-faint)', marginBottom: 18 }}>
          Progress · {answeredTasks}/{totalTasks} tasks attempted · {correctTasks} correct
          {quizPassed && <> · <span style={{ color: 'var(--signal)' }}>checkpoint passed {quizPct}%</span></>}
        </div>
      )}

      <motion.div key={active} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
        {isStepLocked(active) ? (
          <div className="step-locked-note">
            <Lock size={26} /><div>This module is locked. Pass the checkpoint quiz to continue.</div>
          </div>
        ) : (
          <StepComp
            recordScore={recordScore}
            markDone={() => markStep(active)}
            onQuizPass={(pct) => { setQuizPassed(true); setQuizPct(pct); markStep(active); }}
            onStepSolved={() => setSolvedSteps(s => ({ ...s, [active]: true }))}
            stepSolved={!!currentSolved}
            quizPassed={quizPassed}
          />)}
      </motion.div>

      <div className="btn-row" style={{ justifyContent: 'space-between', marginTop: 30 }}>
        <button className="btn btn-ghost" disabled={active === 0} onClick={() => setActive(a => a - 1)}>
          <ChevronLeft size={15} /> Previous
        </button>
        {!isLast ? (
          isQuizStep && !quizPassed ? (
            <button className="btn btn-primary" disabled style={{ opacity: 0.5 }}>
              <Lock size={15} /> Pass the checkpoint to continue
            </button>
          ) : blockContinue ? (
            <button className="btn btn-primary" disabled style={{ opacity: 0.5 }}>
              <Lock size={15} /> Complete the practical to continue
            </button>
          ) : (
            <button className="btn btn-primary"
              onClick={() => { markStep(active); const n = active + 1; if (!isStepLocked(n)) setActive(n); }}>
              Mark section done & continue <ChevronRight size={15} />
            </button>
          )
        ) : (
          <button className="btn btn-primary" disabled={!quizPassed} style={!quizPassed ? { opacity: 0.5 } : {}}
            onClick={() => markStep(active)}>
            {quizPassed ? <><Award size={15} /> Complete lab</> : <><Lock size={15} /> Pass the checkpoint first</>}
          </button>
        )}
      </div>

      {allComplete && (
        <motion.div className="score-banner" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} style={{ marginTop: 28 }}>
          <Award size={34} color="var(--amber)" />
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 600, fontSize: 17 }}>Lab {String(lab.id).padStart(2, '0')} complete</div>
            <div style={{ color: 'var(--ink-dim)', fontSize: 14 }}>
              Checkpoint passed at <b style={{ color: 'var(--signal)' }}>{quizPct}%</b>; {correctTasks}/{totalTasks} interactive tasks correct.
              {lab.id < 10 && <> Next: continue on <span className="kbd">:{lab.port + 1}</span> for Lab {lab.id + 1}.</>}
            </div>
          </div>
          <button className="btn btn-ghost" onClick={() => {
            setDone({}); setScores({}); setQuizPassed(false); setQuizPct(0); setActive(0);
            try { localStorage.removeItem(STORE_KEY); } catch {}
          }}>
            <RotateCcw size={14} /> Restart
          </button>
        </motion.div>
      )}

      <div style={{ marginTop: 50, fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-faint)', textAlign: 'center' }}>
        <Crosshair size={11} style={{ verticalAlign: 'middle' }} /> All data in this range is fictional and self-contained · OSINT = publicly available information, collected lawfully · No real persons or live infrastructure targeted
      </div>
    </div>
  );
}
