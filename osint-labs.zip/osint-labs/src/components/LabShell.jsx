import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Crosshair, Award, RotateCcw, ChevronRight, ChevronLeft, ArrowLeft } from 'lucide-react';

const tierClass = (t) =>
  t === 'Foundational' ? 'tier-foundational' : t === 'Applied' ? 'tier-applied' : 'tier-complex';

export default function LabShell({ lab, steps }) {
  const [active, setActive] = useState(0);
  const [done, setDone] = useState({});          // stepIndex -> bool
  const [scores, setScores] = useState({});      // taskKey -> bool (correct)
  const topRef = useRef(null);

  useEffect(() => { topRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, [active]);

  const markStep = (i) => setDone(d => ({ ...d, [i]: true }));
  const recordScore = (key, ok) => setScores(s => ({ ...s, [key]: ok }));

  const totalTasks = steps.reduce((n, s) => n + (s.taskCount || 0), 0);
  const correctTasks = Object.values(scores).filter(Boolean).length;
  const answeredTasks = Object.keys(scores).length;

  const StepComp = steps[active].component;
  const isLast = active === steps.length - 1;
  const allComplete = Object.keys(done).length >= steps.length;

  return (
    <div className="app-shell" ref={topRef}>
      <div className="topbar">
        <span className="brand-mark">SI · OSINT</span>
        <span className="brand-text"><b>Security Impossible</b> — Threat Intelligence Lab Range</span>
        <span className="topbar-spacer" />
        <a href="/" className="chip" style={{ textDecoration: 'none' }}><ArrowLeft size={12} /> All labs</a>
        <span className="port-chip">:{lab.port}</span>
        <span className="classification">INTERNAL · TRAINING</span>
      </div>

      {/* Header */}
      <div className="lab-head">
        <div className="lab-eyebrow">
          <span>Lab {String(lab.id).padStart(2, '0')}</span>
          <span className={`tier-pill ${tierClass(lab.tier)}`}>{lab.tier}</span>
          <span>{lab.sfia}</span>
          <span>· {lab.dur}</span>
        </div>
        <h1 className="lab-title"><span className="num">{String(lab.id).padStart(2, '0')} /</span> {lab.title}</h1>
        <div className="lab-meta-row">
          <span>Primary skill <b>{lab.skill}</b></span>
          <span>Platform <b>DFIR-IRIS + analyst VM</b></span>
          <span>Org <b>Meridian Financial Services</b></span>
        </div>
      </div>

      {/* Progress rail */}
      <div className="progress-rail">
        {steps.map((s, i) => (
          <button key={i}
            className={`step-dot ${i === active ? 'active' : ''} ${done[i] ? 'done' : ''}`}
            onClick={() => setActive(i)}>
            <span className="idx">{i + 1}</span>{s.label}
          </button>
        ))}
      </div>

      {/* Live score */}
      {totalTasks > 0 && (
        <div style={{ fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--ink-faint)', marginBottom: 18 }}>
          Progress · {answeredTasks}/{totalTasks} tasks attempted · {correctTasks} correct
        </div>
      )}

      {/* Active step */}
      <motion.div key={active} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
        <StepComp recordScore={recordScore} markDone={() => markStep(active)} />
      </motion.div>

      {/* Footer nav */}
      <div className="btn-row" style={{ justifyContent: 'space-between', marginTop: 30 }}>
        <button className="btn btn-ghost" disabled={active === 0} onClick={() => setActive(a => a - 1)}>
          <ChevronLeft size={15} /> Previous
        </button>
        {!isLast ? (
          <button className="btn btn-primary" onClick={() => { markStep(active); setActive(a => a + 1); }}>
            Mark section done & continue <ChevronRight size={15} />
          </button>
        ) : (
          <button className="btn btn-primary" onClick={() => markStep(active)}>
            <Award size={15} /> Complete lab
          </button>
        )}
      </div>

      {/* Completion banner */}
      {allComplete && (
        <motion.div className="score-banner" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} style={{ marginTop: 28 }}>
          <Award size={34} color="var(--amber)" />
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 600, fontSize: 17 }}>Lab {String(lab.id).padStart(2, '0')} complete</div>
            <div style={{ color: 'var(--ink-dim)', fontSize: 14 }}>
              You scored <b style={{ color: 'var(--amber)' }}>{correctTasks}/{totalTasks}</b> across the interactive tasks.
              {lab.id < 10 && <> Next: continue on <span className="kbd">:{lab.port + 1}</span> for Lab {lab.id + 1}.</>}
            </div>
          </div>
          <button className="btn btn-ghost" onClick={() => { setDone({}); setScores({}); setActive(0); }}>
            <RotateCcw size={14} /> Restart
          </button>
        </motion.div>
      )}

      <div style={{ marginTop: 50, fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-faint)', textAlign: 'center' }}>
        <Crosshair size={11} style={{ verticalAlign: 'middle' }} /> All data in this range is fictional and self-contained · OSINT = publicly available information, collected lawfully · No real persons or live infrastructure targeted
      </div>
    </div>
  );
}
