import React from 'react';
import { motion } from 'framer-motion';
import { LABS } from './data/labs.js';
import { CastPhoto } from './components/Cast.jsx';
import { CHARACTERS } from './data/cast.js';
import { Crosshair, ArrowUpRight, ShieldCheck, Users } from 'lucide-react';

const INSTRUCTORS = ['elena', 'priya', 'marcus', 'david', 'auditor'];

const tierClass = (t) =>
  t === 'Foundational' ? 'tier-foundational' : t === 'Applied' ? 'tier-applied' : 'tier-complex';

export default function Index() {
  return (
    <div className="app-shell">
      <div className="topbar">
        <span className="brand-mark">SI · OSINT</span>
        <span className="brand-text"><b>Security Impossible</b> — Threat Intelligence Lab Range</span>
        <span className="topbar-spacer" />
        <span className="classification">INTERNAL · TRAINING</span>
      </div>

      <motion.div className="index-hero" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <div className="lab-eyebrow"><Crosshair size={13} /> OPEN-SOURCE INTELLIGENCE · 10 LABS · SFIA 2–4</div>
        <h1>Learn to see what the <span className="accent">open web</span> already knows.</h1>
        <p>
          A hands-on OSINT range built on the Meridian Financial Services storyline. Each lab runs as its own
          container on a dedicated port (6061–6070). Work passive, lawful collection against controlled datasets,
          document every source, and build calibrated, decision-ready intelligence.
        </p>
        <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginTop: 18 }}>
          <span className="chip ok"><ShieldCheck size={12} /> Ethics-first · public info only</span>
          <span className="chip warn">Foundational → Applied → Complex</span>
          <span className="chip">Ports 6061–6070</span>
        </div>
      </motion.div>

      <div className="instructors">
        <div className="instructors-label"><Users size={13} /> Your instructors</div>
        <div className="instructors-row">
          {INSTRUCTORS.map((id) => (
            <div key={id} className="instructor">
              <CastPhoto id={id} size={58} />
              <div className="instructor-meta">
                <div className="instructor-name" style={{ color: CHARACTERS[id].color }}>{CHARACTERS[id].name}</div>
                <div className="instructor-role">{CHARACTERS[id].role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="lab-grid">
        {LABS.map((l, i) => (
          <motion.a key={l.id} className="lab-card"
            href={`/?lab=${l.id}`}
            initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.04 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span className="lc-num">LAB {String(l.id).padStart(2, '0')}</span>
              <span className="lc-port">:{l.port} <ArrowUpRight size={12} style={{ verticalAlign: 'middle' }} /></span>
            </div>
            <h3>{l.title}</h3>
            <p>{l.blurb}</p>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 4 }}>
              <span className={`tier-pill ${tierClass(l.tier)}`}>{l.tier}</span>
              <span className="chip">{l.dur}</span>
            </div>
          </motion.a>
        ))}
      </div>

      <div style={{ marginTop: 46, fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-faint)', textAlign: 'center' }}>
        Each container is launched with <span className="kbd">VITE_LAB=N</span> and published on its own port.
        Open <span className="kbd">localhost:6061</span> for Lab 1 … <span className="kbd">localhost:6070</span> for Lab 10.
      </div>
    </div>
  );
}
