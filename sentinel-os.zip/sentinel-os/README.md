# Sentinel OS — File System Analysis & Metadata Extraction

A self-contained, browser-based **desktop operating system** that hosts a hands-on
**malware-triage lab**. The trainee plays a security analyst on `WORKSTATION-07`,
finds a suspicious file dropped in a temp folder, collects it safely, fingerprints
it, checks it against threat intelligence, performs static analysis, and reaches a
defensible verdict — all guided by **Byte**, a floating assistant.

Everything runs **offline in the browser**. No real files, hashes, systems, or
network calls are involved — the file system, tools, hashes and detections are all
simulated for training.

---

## Run it (one command)

```bash
unzip sentinel-os.zip && cd sentinel-os
docker compose up -d --build
# open http://localhost:8346   (or http://<server-ip>:8346)
```

The container is set to **`restart: always`**, so it comes back automatically after
a reboot or crash.

### Alternative (plain Docker)

```bash
unzip sentinel-os.zip && cd sentinel-os
docker build --no-cache -t sentinel-os:latest .
docker run -d --name sentinel-os -p 8346:8346 --restart always sentinel-os:latest
# open http://<server-ip>:8346
```

On a cloud VM, open **inbound TCP 8346** in the security group / firewall.

Health check: `GET /health` returns `ok`.

### Local development

```bash
npm install
npm run dev      # http://localhost:8346
```

---

## The lab flow (7 gated tasks)

Byte walks the trainee through the investigation. Each task unlocks the next only
once it's actually completed in the right app.

1. **Locate** — find `crack.exe` in `/tmp` using the **Files** app (malware hides in temp folders).
2. **Collect** — restore the auto-quarantined sample from **Sentinel Security** (only ever done inside a sandbox).
3. **Inspect** — read the file's metadata via **Properties** (tiny size, no publisher, temp path).
4. **Fingerprint** — compute the **SHA-256 hash** in the **Terminal** (`sha256sum /tmp/crack.exe`).
5. **Threat intel** — look the hash up in **Threat Lookup** (58/70 engines flag it; Trojan / Keylogger / RAT).
6. **Static analysis** — open **PE Inspector** and review the imports (keyboard hooks, process injection, anti-kill).
7. **Verdict** — conclude it's a keylogging **RAT** and confirm the **Indicators of Compromise (IOCs)**.

Learners meet plain-word explanations for jargon (hash → *fingerprint*, IOC → *clue*,
PE → *Windows-program*, static analysis → *look-don't-run*, and more). Every term has
an inline one-word tag plus a fuller pop-up, and Byte has a full **Glossary** tab.

---

## What's in the desktop

- **Boot + sign-in** screen, **top status bar**, **dock**, draggable/resizable
  **windows** (minimize / maximize / close), and a desktop **case-file widget**.
- Six apps: **Files**, **Terminal**, **Sentinel Security**, **Threat Lookup**,
  **PE Inspector**, **Triage Report**.
- **Byte**, the floating guide: a robot avatar introduces itself on page 1, the
  five-person team is introduced on page 2, then it drives the gated tasks. **Byte
  can be dragged anywhere** on screen (left, right, middle) and stays where you drop it.
- Progress is saved to `localStorage`, so a refresh keeps the trainee's place.
  "Restart lab" clears it and starts fresh.

---

## Tech

Vite + React 18, pure CSS variables (dark theme), `lucide-react` icons. Multi-stage
Docker build (`node:22-alpine` → `nginx:1.27-alpine`) serving the static `build/` on
port **8346**.

## Project structure

```
sentinel-os/
├── Dockerfile · docker-compose.yml · nginx.conf   # container + serving (port 8346)
├── index.html · vite.config.js · package.json
└── src/
    ├── main.jsx · App.jsx · index.css             # mount, root state, design system
    ├── assets/cast/character-1..5.png             # shared cast portraits
    └── components/
        ├── BootScreen.jsx                         # boot + sign-in
        ├── Desktop.jsx                            # OS shell: top bar, dock, window mgr
        ├── Window.jsx                             # draggable/resizable window chrome
        ├── apps.jsx                               # the six applications
        ├── Byte.jsx                               # floating guide (intro, tasks, glossary)
        ├── ByteAvatar.jsx                         # inline SVG robot mascot
        ├── Cast.jsx                               # shared cast portraits
        └── ui.jsx                                 # inline jargon explainer (TermChip)
    └── data/
        └── scenario.js                            # ALL lab content (file system, suspect, tasks, glossary)
```

*Training simulation only — all systems, files, users, hashes and domains are fictional.*
