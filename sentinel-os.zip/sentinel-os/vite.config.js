import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Sentinel OS — browser-based forensics workstation lab.
// Builds to build/, served by nginx in the container on port 8346.
export default defineConfig({
  plugins: [react()],
  build: { outDir: 'build', chunkSizeWarningLimit: 1500 },
  server: { host: '0.0.0.0', port: 8346 },
  preview: { host: '0.0.0.0', port: 8346 },
});
