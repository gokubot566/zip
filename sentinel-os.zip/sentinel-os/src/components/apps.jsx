import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Folder, FileText, FileCode, FileArchive, FileSpreadsheet, Image as ImageIcon,
  File as FileIcon, ChevronRight, Home, AlertTriangle, X, Shield, Clock, HardDrive,
  User, Hash as HashIcon, Search, CornerUpLeft, Trash2, TerminalSquare, RotateCcw,
  Globe, Bug, CheckCircle2, Copy, Check, ListChecks, Fingerprint, ShieldAlert,
  ScanLine, FileWarning, Info,
} from 'lucide-react';
import { FILE_SYSTEM, FILE_INFO, SUSPECT, SUMMARY } from '../data/scenario.js';
import { TermChip } from './ui.jsx';

/* ---------- helpers ---------- */
function iconFor(name, isDir) {
  if (isDir) return Folder;
  const n = name.toLowerCase();
  if (n.endsWith('.exe')) return FileWarning;
  if (n.endsWith('.md') || n.endsWith('.txt') || n.endsWith('.log')) return FileText;
  if (n.endsWith('.pdf')) return FileText;
  if (n.endsWith('.zip')) return FileArchive;
  if (n.endsWith('.xlsx') || n.endsWith('.csv')) return FileSpreadsheet;
  if (n.endsWith('.png') || n.endsWith('.jpg')) return ImageIcon;
  if (n.endsWith('.msi')) return FileCode;
  return FileIcon;
}
const isSuspect = (path) => path === SUSPECT.path;

/* =============================================================================
   FILES — browse the virtual file system, find the suspicious file, open
   Properties. Reflects quarantine state: while quarantined, crack.exe shows a
   "quarantined" tag and Properties nudges the student to OmniGuard.
   ============================================================================= */
export function FilesApp({ lab, patchLab, openApp }) {
  const [cwd, setCwd] = useState('/'); // start at root — the student navigates into /tmp themselves
  const [sel, setSel] = useState(null);
  const [props, setProps] = useState(null); // path shown in details
  const [query, setQuery] = useState('');
  const [menu, setMenu] = useState(null); // { path, x, y } right-click context menu

  // close the context menu on any outside click / escape
  useEffect(() => {
    if (!menu) return;
    const close = () => setMenu(null);
    const onKey = (e) => { if (e.key === 'Escape') setMenu(null); };
    window.addEventListener('click', close);
    window.addEventListener('keydown', onKey);
    return () => { window.removeEventListener('click', close); window.removeEventListener('keydown', onKey); };
  }, [menu]);

  const entries = useMemo(() => {
    const items = FILE_SYSTEM[cwd] || [];
    return items
      .map((name) => {
        const full = cwd === '/' ? `/${name}` : `${cwd}/${name}`;
        const isDir = !!FILE_SYSTEM[full];
        return { name, full, isDir };
      })
      .filter((e) => !query || e.name.toLowerCase().includes(query.toLowerCase()))
      .sort((a, b) => (a.isDir === b.isDir ? a.name.localeCompare(b.name) : a.isDir ? -1 : 1));
  }, [cwd, query]);

  const crumbs = cwd === '/' ? [''] : cwd.split('/');

  const open = (e) => {
    if (e.isDir) { setCwd(e.full); setSel(null); return; }
    setSel(e.full);
    // opening the suspect's folder / selecting it counts as "located"
    if (isSuspect(e.full) && !lab.foundFile) patchLab({ foundFile: true });
  };

  const openProps = (path) => {
    setProps(path);
    if (isSuspect(path)) {
      if (!lab.foundFile) patchLab({ foundFile: true });
      if (lab.restored && !lab.inspected) patchLab({ inspected: true });
    }
  };

  // mark located if they land in /tmp and see the file
  useEffect(() => {
    if (cwd === '/tmp' && !lab.foundFile) patchLab({ foundFile: true });
  }, [cwd]); // eslint-disable-line

  const goUp = () => { if (cwd !== '/') { const p = cwd.split('/').slice(0, -1).join('/') || '/'; setCwd(p); setSel(null); } };

  const quick = [
    { label: 'Home', path: '/home/analyst', Icon: Home },
    { label: 'Downloads', path: '/home/analyst/Downloads', Icon: FileArchive },
    { label: 'Temp (/tmp)', path: '/tmp', Icon: Clock, hot: true },
    { label: 'System logs', path: '/var/log', Icon: FileText },
    { label: 'Root', path: '/', Icon: HardDrive },
  ];

  return (
    <div className="app files">
      <style>{FILES_CSS}</style>
      <div className="files-side">
        <div className="files-side-h">Locations</div>
        {quick.map((q) => (
          <button key={q.path} className={`files-q ${cwd === q.path ? 'on' : ''} ${q.hot ? 'hot' : ''}`} onClick={() => { setCwd(q.path); setSel(null); }}>
            <q.Icon size={15} /> {q.label}
          </button>
        ))}
        <div className="files-about">
          <b>Files</b> lets you browse the workstation’s folders. Right-click a file to see its details.
        </div>
      </div>

      <div className="files-main">
        <div className="files-bar">
          <button className="files-nav" onClick={goUp} disabled={cwd === '/'} title="Up one folder"><CornerUpLeft size={15} /></button>
          <div className="files-crumbs">
            <button onClick={() => setCwd('/')}><HardDrive size={13} /></button>
            {crumbs.filter(Boolean).map((c, i) => {
              const path = '/' + crumbs.filter(Boolean).slice(0, i + 1).join('/');
              return <React.Fragment key={path}><ChevronRight size={12} className="crumb-sep" /><button onClick={() => setCwd(path)}>{c}</button></React.Fragment>;
            })}
          </div>
          <div className="files-search">
            <Search size={13} />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search this folder" />
          </div>
        </div>

        <div className="files-grid">
          {entries.length === 0 && <div className="files-empty">Nothing here.</div>}
          {entries.map((e) => {
            const Ic = iconFor(e.name, e.isDir);
            const suspect = isSuspect(e.full);
            const quarantined = suspect && !lab.restored;
            return (
              <button
                key={e.full}
                className={`file ${sel === e.full ? 'sel' : ''} ${suspect ? 'suspect' : ''}`}
                onClick={() => open(e)}
                onDoubleClick={() => (e.isDir ? open(e) : openProps(e.full))}
                onContextMenu={(ev) => {
                  ev.preventDefault(); ev.stopPropagation();
                  setSel(e.full);
                  if (!e.isDir) setMenu({ path: e.full, x: ev.clientX, y: ev.clientY });
                }}
                title={e.isDir ? e.name : 'Right-click to see details'}
              >
                <span className={`file-ic ${suspect ? 'sic' : ''}`}><Ic size={26} /></span>
                <span className="file-name">{e.name}</span>
                {quarantined && <span className="file-tag q"><Shield size={10} /> quarantined</span>}
                {suspect && lab.restored && <span className="file-tag r"><AlertTriangle size={10} /> suspicious</span>}
              </button>
            );
          })}
        </div>

        <div className="files-foot">
          {sel ? (
            <>
              <span className="foot-name">{sel.split('/').pop()}</span>
              <button className="foot-btn" onClick={() => openProps(sel)}>Details</button>
              {isSuspect(sel) && (
                <button className="foot-btn primary" onClick={() => openApp('terminal')}><TerminalSquare size={13} /> Open in Terminal</button>
              )}
            </>
          ) : <span className="foot-hint">{entries.length} items · right-click a file to see details</span>}
        </div>
      </div>

      {menu && (
        <div className="ctx" style={{ left: menu.x, top: menu.y }} onClick={(e) => e.stopPropagation()}>
          <button className="ctx-item" onClick={() => { openProps(menu.path); setMenu(null); }}>
            <Info size={14} /> Open details
          </button>
          {isSuspect(menu.path) && (
            <button className="ctx-item" onClick={() => { openApp('terminal'); setMenu(null); }}>
              <TerminalSquare size={14} /> Open in Terminal
            </button>
          )}
        </div>
      )}

      {props && (
        <DetailsModal path={props} lab={lab} onClose={() => setProps(null)} openApp={openApp} />
      )}
    </div>
  );
}

function DetailsModal({ path, lab, onClose, openApp }) {
  const name = path.split('/').pop();
  const suspect = isSuspect(path);
  const info = FILE_INFO[path];
  return (
    <div className="prop-scrim" onClick={onClose}>
      <div className="prop" onClick={(e) => e.stopPropagation()}>
        <div className="prop-h">
          <div className={`prop-ic ${suspect ? 'sic' : ''}`}>{suspect ? <FileWarning size={20} /> : <FileIcon size={20} />}</div>
          <div style={{ flex: 1 }}>
            <div className="prop-name">{name}</div>
            <div className="prop-sub">Details · {suspect ? SUSPECT.pe.fileType : (info?.kind || 'File')}</div>
          </div>
          <button className="prop-x" onClick={onClose}><X size={16} /></button>
        </div>

        {suspect ? (
          <div className="prop-body">
            <Row Icon={HardDrive} k="Location" v={SUSPECT.displayPath} mono />
            <Row Icon={HashIcon} k="Size" v={`${SUSPECT.sizeHuman} (${SUSPECT.sizeBytes.toLocaleString()} bytes)`} />
            <Row Icon={Clock} k="Created" v={SUSPECT.created} mono />
            <Row Icon={Clock} k="Modified" v={SUSPECT.modified} mono />
            <Row Icon={User} k="Owner" v={SUSPECT.owner} />
            <Row Icon={Shield} k="Publisher" v="Unknown — no digital signature" warn />
            <Row Icon={Shield} k="Matches installed software?" v="No" warn />
            <div className="prop-note">
              <AlertTriangle size={14} />
              <span>
                Tiny size, a <TermChip t="temp folder">temp</TermChip> location, identical create/modify times and no publisher.
                That’s a classic pattern for a <TermChip t="dropper" /> or loader. Next: fingerprint it with the <TermChip t="hash" /> in the Terminal.
              </span>
            </div>
            {!lab.restored && (
              <div className="prop-warn">
                <Shield size={14} /> This file is in <b>quarantine</b>. Restore it from <b>OmniGuard</b> before deeper analysis.
                <button className="prop-open" onClick={() => { onClose(); openApp('security'); }}>Open OmniGuard</button>
              </div>
            )}
          </div>
        ) : (
          <div className="prop-body">
            <Row Icon={HardDrive} k="Location" v={path} mono />
            <Row Icon={FileIcon} k="Type" v={info?.kind || 'File'} />
            <div className="prop-note ok">
              <CheckCircle2 size={14} />
              <span>{info?.note || 'Nothing unusual about this file.'}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
function Row({ Icon, k, v, mono, warn }) {
  return (
    <div className="prow">
      <div className="prow-k"><Icon size={13} /> {k}</div>
      <div className={`prow-v ${mono ? 'mono' : ''} ${warn ? 'warn' : ''}`}>{v}</div>
    </div>
  );
}

const FILES_CSS = `
.files{display:flex;height:100%;background:var(--bg-1)}
.files-side{width:186px;flex-shrink:0;border-right:1px solid var(--line);padding:12px 10px;display:flex;flex-direction:column;gap:3px;background:var(--bg-2)}
.files-side-h{font-size:10.5px;font-weight:800;letter-spacing:.7px;text-transform:uppercase;color:var(--txt-3);padding:2px 8px 6px}
.files-q{display:flex;align-items:center;gap:9px;padding:8px 10px;border:none;border-radius:9px;background:transparent;color:var(--txt-1);font-size:13px;font-weight:500;cursor:pointer;text-align:left;width:100%}
.files-q:hover{background:var(--bg-3s)}
.files-q.on{background:var(--accent-soft);color:var(--txt-0)}
.files-q.hot svg{color:var(--warn)}
.files-q svg{color:var(--txt-2);flex-shrink:0}
.files-q.on svg{color:var(--accent)}
.files-tip{margin-top:auto;font-size:11px;line-height:1.5;color:var(--txt-2);background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.2);border-radius:10px;padding:9px 10px;display:flex;gap:7px;align-items:flex-start}
.files-tip svg{color:var(--warn);flex-shrink:0;margin-top:1px}
.files-main{flex:1;display:flex;flex-direction:column;min-width:0}
.files-bar{display:flex;align-items:center;gap:10px;padding:10px 12px;border-bottom:1px solid var(--line)}
.files-nav{width:30px;height:30px;border-radius:8px;border:1px solid var(--line);background:var(--bg-2);color:var(--txt-1);display:grid;place-items:center;cursor:pointer;flex-shrink:0}
.files-nav:disabled{opacity:.4;cursor:default}
.files-crumbs{display:flex;align-items:center;gap:2px;flex:1;min-width:0;overflow:hidden}
.files-crumbs button{background:transparent;border:none;color:var(--txt-1);font-size:13px;font-weight:600;padding:4px 6px;border-radius:6px;cursor:pointer;white-space:nowrap}
.files-crumbs button:hover{background:var(--bg-3s);color:var(--txt-0)}
.crumb-sep{color:var(--txt-3);flex-shrink:0}
.files-search{display:flex;align-items:center;gap:6px;background:var(--bg-2);border:1px solid var(--line);border-radius:8px;padding:6px 10px;width:190px}
.files-search svg{color:var(--txt-3)}
.files-search input{background:transparent;border:none;outline:none;color:var(--txt-0);font-size:12.5px;width:100%;font-family:inherit}
.files-grid{flex:1;overflow-y:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:6px;padding:14px;align-content:start}
.files-empty{color:var(--txt-3);padding:20px;font-size:13px}
.file{display:flex;flex-direction:column;align-items:center;gap:7px;padding:14px 8px 10px;border-radius:12px;border:1px solid transparent;background:transparent;color:var(--txt-1);cursor:pointer;position:relative;transition:background .12s,border-color .12s}
.file:hover{background:var(--bg-2)}
.file.sel{background:var(--accent-soft);border-color:rgba(34,211,179,.3)}
.file-ic{color:var(--txt-2)}
.file-ic svg{filter:drop-shadow(0 4px 8px rgba(0,0,0,.3))}
.file .file-ic{color:#7fb2ff}
.file-name{font-size:12px;text-align:center;word-break:break-word;line-height:1.3;max-width:100%}
.file.suspect .file-ic.sic{color:var(--bad)}
.file.suspect{background:rgba(242,84,91,.06)}
.file.suspect:hover{background:rgba(242,84,91,.1)}
.file-tag{position:absolute;top:6px;right:6px;display:inline-flex;align-items:center;gap:3px;font-size:9px;font-weight:700;padding:2px 5px;border-radius:5px;line-height:1}
.file-tag.q{background:rgba(124,108,240,.2);color:#b3a9f7}
.file-tag.r{background:rgba(242,84,91,.16);color:#ffb0b3}
.files-foot{display:flex;align-items:center;gap:10px;padding:9px 14px;border-top:1px solid var(--line);min-height:44px;background:var(--bg-2)}
.foot-name{font-size:12.5px;font-weight:600;font-family:var(--mono)}
.foot-hint{font-size:12px;color:var(--txt-3)}
.foot-btn{margin-left:auto;display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border:1px solid var(--line-2);border-radius:8px;background:var(--bg-3s);color:var(--txt-1);font-size:12px;font-weight:600;cursor:pointer}
.foot-btn+.foot-btn{margin-left:0}
.foot-btn:hover{background:var(--bg-4)}
.foot-btn.primary{background:var(--accent-soft);border-color:rgba(34,211,179,.35);color:var(--accent)}

.prop-scrim{position:absolute;inset:0;background:rgba(3,6,12,.6);backdrop-filter:blur(2px);display:grid;place-items:center;z-index:30;padding:20px}
.prop{width:min(460px,100%);background:var(--bg-2);border:1px solid var(--line-2);border-radius:16px;box-shadow:0 30px 80px rgba(0,0,0,.6);overflow:hidden;animation:fadeUp .2s ease both}
.prop-h{display:flex;align-items:center;gap:12px;padding:16px;border-bottom:1px solid var(--line)}
.prop-ic{width:44px;height:44px;border-radius:11px;display:grid;place-items:center;background:var(--bg-3s);color:#7fb2ff}
.prop-ic.sic{background:rgba(242,84,91,.14);color:var(--bad)}
.prop-name{font-size:15px;font-weight:700;font-family:var(--mono)}.prop-sub{font-size:11.5px;color:var(--txt-3);margin-top:2px}
.prop-x{margin-left:auto;width:30px;height:30px;border:none;background:transparent;color:var(--txt-2);border-radius:8px;cursor:pointer;display:grid;place-items:center}
.prop-x:hover{background:var(--bg-3s);color:var(--txt-0)}
.prop-body{padding:14px 16px 16px;max-height:60vh;overflow-y:auto}
.prow{display:flex;gap:12px;padding:8px 0;border-bottom:1px solid var(--line);font-size:13px}
.prow:last-of-type{border-bottom:none}
.prow-k{display:flex;align-items:center;gap:7px;color:var(--txt-2);width:170px;flex-shrink:0}
.prow-k svg{color:var(--txt-3)}
.prow-v{color:var(--txt-0);word-break:break-word}
.prow-v.mono{font-family:var(--mono);font-size:12px}
.prow-v.warn{color:var(--warn);font-weight:600}
.prop-note{display:flex;gap:9px;margin-top:14px;padding:11px 13px;border-radius:10px;font-size:12.5px;line-height:1.55;background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.2);color:var(--txt-1)}
.prop-note svg{color:var(--warn);flex-shrink:0;margin-top:1px}
.prop-note.ok{background:rgba(52,211,153,.08);border-color:rgba(52,211,153,.22)}
.prop-note.ok svg{color:var(--good)}
.prop-warn{display:flex;flex-wrap:wrap;align-items:center;gap:9px;margin-top:10px;padding:11px 13px;border-radius:10px;font-size:12.5px;line-height:1.5;background:var(--violet-soft);border:1px solid rgba(124,108,240,.3);color:var(--txt-1)}
.prop-warn svg{color:var(--accent-2);flex-shrink:0}
.prop-open{margin-left:auto;padding:6px 12px;border:none;border-radius:8px;background:var(--accent-2);color:#fff;font-size:12px;font-weight:700;cursor:pointer}
.ctx{position:fixed;z-index:40;min-width:170px;background:var(--bg-2);border:1px solid var(--line-2);border-radius:10px;box-shadow:0 16px 44px rgba(0,0,0,.6);padding:5px;animation:fadeIn .12s ease both}
.ctx-item{display:flex;align-items:center;gap:10px;width:100%;text-align:left;padding:9px 11px;border:none;border-radius:7px;background:transparent;color:var(--txt-1);font-size:13px;font-weight:500;cursor:pointer}
.ctx-item:hover{background:var(--accent-soft);color:var(--txt-0)}
.ctx-item svg{color:var(--txt-2)}
.ctx-item:hover svg{color:var(--accent)}
.files-about{margin-top:auto;font-size:11px;line-height:1.5;color:var(--txt-3);border-top:1px solid var(--line);padding-top:11px}
.files-about b{color:var(--txt-1)}
`;

/* =============================================================================
   TERMINAL — a small simulated shell over the same VFS. Supports: help, ls, cd,
   pwd, cat, file, clear, sha256sum, md5sum, sha1sum. Running a hash on the
   suspect marks the "hashed" gate and reveals the fingerprint to copy.
   ============================================================================= */
export function TerminalApp({ lab, patchLab }) {
  const [lines, setLines] = useState(() => ([
    { t: `Sentinel OS shell — WORKSTATION-07`, cls: 'sys' },
    { t: `Type "help" for commands. Investigate the file in /tmp.`, cls: 'dim' },
    { t: '', cls: '' },
  ]));
  const [cwd, setCwd] = useState('/tmp');
  const [input, setInput] = useState('');
  const [hist, setHist] = useState([]);
  const [hi, setHi] = useState(-1);
  const [copied, setCopied] = useState(null); // which hash string was just copied
  const endRef = useRef(null);
  const inRef = useRef(null);

  const copyHash = async (hash) => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(hash);
      } else {
        // fallback for non-secure contexts
        const ta = document.createElement('textarea');
        ta.value = hash; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        document.execCommand('copy'); document.body.removeChild(ta);
      }
    } catch { /* clipboard blocked — user can still select manually */ }
    setCopied(hash);
    setTimeout(() => setCopied((c) => (c === hash ? null : c)), 1600);
  };

  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }); }, [lines]);

  const push = (arr) => setLines((l) => [...l, ...arr]);
  const resolve = (arg) => {
    if (!arg) return cwd;
    if (arg === '/') return '/';
    let base = arg.startsWith('/') ? '' : cwd;
    let parts = (base + '/' + arg).split('/').filter(Boolean);
    const out = [];
    for (const p of parts) { if (p === '.') continue; if (p === '..') out.pop(); else out.push(p); }
    return '/' + out.join('/');
  };
  const listing = (dir) => FILE_SYSTEM[dir];
  const fileExists = (path) => {
    const parent = path.split('/').slice(0, -1).join('/') || '/';
    const name = path.split('/').pop();
    return (FILE_SYSTEM[parent] || []).includes(name);
  };

  const run = (raw) => {
    const cmd = raw.trim();
    push([{ t: `${prompt(cwd)} ${cmd}`, cls: 'cmd' }]);
    if (!cmd) return;
    setHist((h) => [cmd, ...h]); setHi(-1);
    const [c, ...args] = cmd.split(/\s+/);
    const arg = args.join(' ');

    switch (c) {
      case 'help':
        push([
          { t: 'Available commands:', cls: 'sys' },
          { t: '  ls [dir]           list files', cls: '' },
          { t: '  cd <dir>           change directory', cls: '' },
          { t: '  pwd                show current directory', cls: '' },
          { t: '  cat <file>         show a text file', cls: '' },
          { t: '  file <file>        identify a file type', cls: '' },
          { t: '  sha256sum <file>   compute the SHA-256 hash (fingerprint)', cls: '' },
          { t: '  md5sum / sha1sum   other hashes', cls: '' },
          { t: '  clear              clear the screen', cls: '' },
          { t: '', cls: '' },
        ]);
        break;
      case 'pwd': push([{ t: cwd, cls: '' }, { t: '', cls: '' }]); break;
      case 'clear': setLines([]); break;
      case 'ls': {
        const dir = resolve(arg);
        const items = listing(dir);
        if (!items) { push([{ t: `ls: cannot access '${arg || dir}': No such directory`, cls: 'err' }, { t: '', cls: '' }]); break; }
        const rows = items.map((n) => {
          const full = dir === '/' ? `/${n}` : `${dir}/${n}`;
          const isDir = !!FILE_SYSTEM[full];
          const suspect = isSuspect(full);
          return { t: (isDir ? 'd ' : '- ') + n + (isDir ? '/' : '') + (suspect ? '   ← unexpected executable' : ''), cls: suspect ? 'bad' : (isDir ? 'dir' : '') };
        });
        push([...rows, { t: '', cls: '' }]);
        if (dir === '/tmp' && !lab.foundFile) patchLab({ foundFile: true });
        break;
      }
      case 'cd': {
        if (!arg || arg === '~') { setCwd('/home/analyst'); break; }
        const dir = resolve(arg);
        if (!FILE_SYSTEM[dir]) { push([{ t: `cd: no such directory: ${arg}`, cls: 'err' }, { t: '', cls: '' }]); break; }
        setCwd(dir);
        if (dir === '/tmp' && !lab.foundFile) patchLab({ foundFile: true });
        break;
      }
      case 'cat': {
        const path = resolve(arg);
        if (isSuspect(path)) { push([{ t: 'cat: crack.exe: binary file — use sha256sum or the PE Inspector, do not print it.', cls: 'err' }, { t: '', cls: '' }]); break; }
        if (!fileExists(path)) { push([{ t: `cat: ${arg}: No such file`, cls: 'err' }, { t: '', cls: '' }]); break; }
        const canned = CAT[path];
        push([{ t: canned || '(empty file)', cls: canned ? '' : 'dim' }, { t: '', cls: '' }]);
        break;
      }
      case 'file': {
        const path = resolve(arg);
        if (!fileExists(path)) { push([{ t: `file: ${arg}: No such file`, cls: 'err' }, { t: '', cls: '' }]); break; }
        if (isSuspect(path)) { push([{ t: `${SUSPECT.name}: ${SUSPECT.pe.fileType}, ${SUSPECT.pe.subsystem}, .NET assembly — 32-bit`, cls: 'bad' }, { t: '', cls: '' }]); break; }
        push([{ t: `${path.split('/').pop()}: data`, cls: 'dim' }, { t: '', cls: '' }]);
        break;
      }
      case 'sha256sum':
      case 'md5sum':
      case 'sha1sum': {
        const path = resolve(arg);
        if (!arg) { push([{ t: `${c}: missing file operand`, cls: 'err' }, { t: '', cls: '' }]); break; }
        if (!fileExists(path)) { push([{ t: `${c}: ${arg}: No such file`, cls: 'err' }, { t: '', cls: '' }]); break; }
        if (isSuspect(path) && !lab.restored) {
          push([{ t: `${c}: ${arg}: Permission denied — file is in quarantine.`, cls: 'err' },
                { t: `Restore it from OmniGuard first.`, cls: 'dim' }, { t: '', cls: '' }]);
          break;
        }
        const hash = isSuspect(path)
          ? (c === 'sha256sum' ? SUSPECT.hashes.sha256 : c === 'md5sum' ? SUSPECT.hashes.md5 : SUSPECT.hashes.sha1)
          : fakeHash(path, c);
        push([{ t: `${hash}  ${path.split('/').pop()}`, cls: isSuspect(path) ? 'hash' : '', copy: isSuspect(path) ? hash : null }, { t: '', cls: '' }]);
        if (isSuspect(path) && c === 'sha256sum') {
          if (!lab.hashed) patchLab({ hashed: true });
          push([{ t: `↑ SHA-256 fingerprint computed. Tap “Copy” on the line above, then open Threat Lookup.`, cls: 'ok' }, { t: '', cls: '' }]);
        }
        break;
      }
      default:
        push([{ t: `command not found: ${c}  (try "help")`, cls: 'err' }, { t: '', cls: '' }]);
    }
  };

  const onKey = (e) => {
    if (e.key === 'Enter') { run(input); setInput(''); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); const ni = Math.min(hi + 1, hist.length - 1); if (hist[ni] !== undefined) { setHi(ni); setInput(hist[ni]); } }
    else if (e.key === 'ArrowDown') { e.preventDefault(); const ni = hi - 1; if (ni < 0) { setHi(-1); setInput(''); } else { setHi(ni); setInput(hist[ni] || ''); } }
  };

  return (
    <div className="app term" onClick={() => inRef.current?.focus()}>
      <style>{TERM_CSS}</style>
      <div className="term-quick">
        <span>Quick:</span>
        {['ls', 'cd /tmp', 'sha256sum /tmp/crack.exe'].map((q) => (
          <button key={q} onClick={() => { setInput(q); inRef.current?.focus(); }}>{q}</button>
        ))}
      </div>
      <div className="term-screen">
        {lines.map((l, i) => (
          l.copy ? (
            <div key={i} className={`tline ${l.cls} tline-copy`}>
              <span className="tline-hash">{l.t}</span>
              <button className="tcopy" onClick={(e) => { e.stopPropagation(); copyHash(l.copy); }} title="Copy the hash">
                {copied === l.copy ? <><Check size={12} /> Copied</> : <><Copy size={12} /> Copy</>}
              </button>
            </div>
          ) : (
            <div key={i} className={`tline ${l.cls}`}>{l.t || '\u00a0'}</div>
          )
        ))}
        <div className="term-input-row">
          <span className="term-prompt">{prompt(cwd)}</span>
          <input ref={inRef} value={input} autoFocus spellCheck={false}
            onChange={(e) => setInput(e.target.value)} onKeyDown={onKey} className="term-input" />
        </div>
        <div ref={endRef} />
      </div>
    </div>
  );
}
const prompt = (cwd) => `analyst@ws07:${cwd}$`;
function fakeHash(path, algo) {
  let h = 0; for (const ch of path + algo) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const len = algo === 'sha256sum' ? 64 : algo === 'sha1sum' ? 40 : 32;
  let s = ''; let x = h; while (s.length < len) { x = (x * 1103515245 + 12345) >>> 0; s += x.toString(16).padStart(8, '0'); }
  return s.slice(0, len);
}
const CAT = {
  '/home/analyst/notes.txt': 'Reminder: rotate SOC on-call. Ticket SOC-4471 still open re: odd temp-folder activity on WS-07.',
  '/home/analyst/report-draft.md': '# Draft — WS-07 alert\n- Marcus flagged suspicious process spawning from a temp path.\n- TODO: collect the artefact and triage.',
  '/etc/hosts': '127.0.0.1  localhost\n127.0.1.1  WORKSTATION-07',
  '/var/log/defender.log': '[quarantine] C:\\Windows\\Temp\\crack.exe :: Trojan:MSIL/Agent :: action=quarantined',
  '/var/log/auth.log': 'session opened for user analyst\naccepted keyboard-interactive for analyst',
  '/opt/tools/README.md': 'Analyst tools live here. Use the PE Inspector for static analysis.',
};

const TERM_CSS = `
.term{display:flex;flex-direction:column;height:100%;background:#060a12;font-family:var(--mono)}
.term-quick{display:flex;align-items:center;gap:7px;padding:8px 12px;border-bottom:1px solid var(--line);background:var(--bg-2);flex-wrap:wrap}
.term-quick span{font-size:11px;color:var(--txt-3);font-family:var(--font)}
.term-quick button{font-family:var(--mono);font-size:11.5px;padding:4px 9px;border:1px solid var(--line);border-radius:6px;background:var(--bg-3s);color:#7fe9d6;cursor:pointer}
.term-quick button:hover{border-color:var(--accent);background:#0f1a26}
.term-screen{flex:1;overflow-y:auto;padding:14px 16px;font-size:13px;line-height:1.55}
.tline{white-space:pre-wrap;word-break:break-word;color:#c8d4e6}
.tline.sys{color:#7fe9d6}
.tline.dim{color:var(--txt-3)}
.tline.err{color:#ff8b90}
.tline.ok{color:#5fe0a8}
.tline.dir{color:#7fb2ff}
.tline.bad{color:#ff9a9f}
.tline.cmd{color:#eef3fb}
.tline.hash{color:#ffd27f;word-break:break-all}
.term-input-row{display:flex;align-items:baseline;gap:8px;margin-top:2px}
.term-prompt{color:#5fe0a8;white-space:nowrap}
.term-input{flex:1;background:transparent;border:none;outline:none;color:#eef3fb;font-family:var(--mono);font-size:13px}
.tline-copy{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.tline-hash{color:#ffd27f;word-break:break-all}
.tcopy{display:inline-flex;align-items:center;gap:5px;font-family:var(--font);font-size:11px;font-weight:700;padding:3px 9px;border-radius:6px;border:1px solid rgba(34,211,179,.4);background:var(--accent-soft);color:var(--accent);cursor:pointer;flex-shrink:0}
.tcopy:hover{background:rgba(34,211,179,.22)}
.tcopy svg{flex-shrink:0}
`;

/* =============================================================================
   SENTINEL SECURITY — protection app. Shows the quarantined sample; the student
   opens Protection history, selects crack.exe and restores it (into an isolated
   analysis area). Restoring marks the "restored" gate.
   ============================================================================= */
export function SecurityApp({ lab, patchLab }) {
  const [tab, setTab] = useState(lab.restored ? 'status' : 'history');
  const [sel, setSel] = useState(false);
  const restored = lab.restored;

  return (
    <div className="app sec">
      <style>{SEC_CSS}</style>
      <div className="sec-side">
        <div className="sec-brand"><Shield size={18} /> OmniGuard</div>
        <button className={`sec-nav ${tab === 'status' ? 'on' : ''}`} onClick={() => setTab('status')}><ShieldAlert size={15} /> Protection status</button>
        <button className={`sec-nav ${tab === 'history' ? 'on' : ''}`} onClick={() => setTab('history')}>
          <ListChecks size={15} /> Protection history {!restored && <span className="sec-badge">1</span>}
        </button>
      </div>

      <div className="sec-main">
        {tab === 'status' ? (
          <div className="sec-status fade-in">
            <div className={`sec-shield ${restored ? 'warn' : 'ok'}`}>
              {restored ? <ShieldAlert size={34} /> : <CheckCircle2 size={34} />}
            </div>
            <h3>{restored ? 'A threat has been released for analysis' : 'Your device is protected'}</h3>
            <p>{restored
              ? 'crack.exe has been restored to /tmp inside this isolated analysis workstation. In a real environment you would only ever do this inside a sandbox.'
              : 'Real-time protection is on. 1 threat is currently held in quarantine.'}</p>
            {!restored && <button className="sec-cta" onClick={() => setTab('history')}>Review quarantined item</button>}
          </div>
        ) : (
          <div className="sec-history fade-in">
            <div className="sec-h">Protection history</div>
            {restored ? (
              <div className="sec-empty"><CheckCircle2 size={16} /> The quarantined item was restored for analysis. No items remain in quarantine.</div>
            ) : (
              <>
                <button className={`sec-item ${sel ? 'sel' : ''}`} onClick={() => setSel(true)}>
                  <div className="sec-item-ic"><Bug size={18} /></div>
                  <div className="sec-item-main">
                    <div className="sec-item-t">Threat quarantined<span className="sev">Severe</span></div>
                    <div className="sec-item-s">Trojan:MSIL/Agent — <span className="mono">crack.exe</span></div>
                    <div className="sec-item-m">Detected in C:\\Windows\\Temp · today</div>
                  </div>
                  <ChevronRight size={16} />
                </button>

                {sel && (
                  <div className="sec-detail fade-up">
                    <div className="sec-drow"><span>Detected file</span><b className="mono">C:\\Windows\\Temp\\crack.exe</b></div>
                    <div className="sec-drow"><span>Classification</span><b>Trojan · Keylogger · RAT</b></div>
                    <div className="sec-drow"><span>Status</span><b style={{ color: 'var(--accent-2)' }}>Quarantined (locked away)</b></div>
                    <div className="sec-actions">
                      <div className="sec-warn"><AlertTriangle size={13} /> Only restore malware inside an isolated analysis machine.</div>
                      <button className="sec-restore" onClick={() => { patchLab({ restored: true }); setTab('status'); }}>
                        <RotateCcw size={14} /> Restore for analysis
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

const SEC_CSS = `
.sec{display:flex;height:100%;background:var(--bg-1)}
.sec-side{width:210px;flex-shrink:0;border-right:1px solid var(--line);padding:14px 10px;background:var(--bg-2);display:flex;flex-direction:column;gap:4px}
.sec-brand{display:flex;align-items:center;gap:9px;font-weight:800;font-size:14px;padding:4px 8px 14px;color:var(--txt-0)}
.sec-brand svg{color:var(--accent)}
.sec-nav{display:flex;align-items:center;gap:9px;padding:9px 10px;border:none;border-radius:9px;background:transparent;color:var(--txt-1);font-size:13px;font-weight:600;cursor:pointer;text-align:left}
.sec-nav:hover{background:var(--bg-3s)}
.sec-nav.on{background:var(--accent-soft);color:var(--txt-0)}
.sec-nav svg{color:var(--txt-2)}
.sec-nav.on svg{color:var(--accent)}
.sec-badge{margin-left:auto;background:var(--bad);color:#fff;font-size:10px;font-weight:800;border-radius:999px;padding:1px 7px}
.sec-main{flex:1;overflow-y:auto;padding:24px}
.sec-status{max-width:440px;margin:20px auto 0;text-align:center;display:flex;flex-direction:column;align-items:center;gap:10px}
.sec-shield{width:80px;height:80px;border-radius:50%;display:grid;place-items:center}
.sec-shield.ok{background:rgba(52,211,153,.14);color:var(--good)}
.sec-shield.warn{background:rgba(245,158,11,.14);color:var(--warn)}
.sec-status h3{margin:6px 0 0;font-size:18px}
.sec-status p{margin:0;color:var(--txt-2);font-size:13px;line-height:1.6}
.sec-cta{margin-top:10px;padding:10px 18px;border:none;border-radius:10px;background:var(--accent-2);color:#fff;font-weight:700;font-size:13px;cursor:pointer}
.sec-h{font-size:12px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;color:var(--txt-3);margin-bottom:12px}
.sec-empty{display:flex;align-items:center;gap:9px;color:var(--txt-2);font-size:13px;background:rgba(52,211,153,.08);border:1px solid rgba(52,211,153,.2);border-radius:12px;padding:14px}
.sec-empty svg{color:var(--good)}
.sec-item{display:flex;align-items:center;gap:12px;width:100%;text-align:left;padding:14px;border:1px solid var(--line);border-radius:12px;background:var(--bg-2);color:var(--txt-1);cursor:pointer;transition:border-color .14s,background .14s}
.sec-item:hover{border-color:var(--line-2);background:var(--bg-3s)}
.sec-item.sel{border-color:rgba(242,84,91,.4);background:rgba(242,84,91,.05)}
.sec-item-ic{width:42px;height:42px;border-radius:11px;display:grid;place-items:center;background:rgba(242,84,91,.14);color:var(--bad);flex-shrink:0}
.sec-item-main{flex:1;min-width:0}
.sec-item-t{font-size:14px;font-weight:700;display:flex;align-items:center;gap:8px}
.sev{font-size:10px;font-weight:800;color:var(--bad);background:rgba(242,84,91,.14);padding:2px 7px;border-radius:5px}
.sec-item-s{font-size:12.5px;color:var(--txt-1);margin-top:3px}
.sec-item-m{font-size:11.5px;color:var(--txt-3);margin-top:2px}
.mono{font-family:var(--mono)}
.sec-detail{margin-top:12px;border:1px solid var(--line);border-radius:12px;background:var(--bg-2);padding:6px 16px 16px}
.sec-drow{display:flex;justify-content:space-between;gap:12px;padding:11px 0;border-bottom:1px solid var(--line);font-size:13px}
.sec-drow span{color:var(--txt-2)}
.sec-drow b{color:var(--txt-0);text-align:right}
.sec-actions{display:flex;align-items:center;gap:12px;margin-top:14px;flex-wrap:wrap}
.sec-warn{display:flex;align-items:center;gap:7px;font-size:11.5px;color:var(--warn)}
.sec-restore{margin-left:auto;display:inline-flex;align-items:center;gap:8px;padding:10px 16px;border:none;border-radius:10px;background:linear-gradient(135deg,#22d3b3,#1fb89d);color:#04140f;font-weight:700;font-size:13px;cursor:pointer}
.sec-restore:hover{filter:brightness(1.06)}
`;

/* =============================================================================
   THREAT LOOKUP — paste the SHA-256 and "search". Shows detection ratio, vendor
   labels, reputation and network IOCs. Searching the correct hash marks
   "intelDone". Simulated — no real network.
   ============================================================================= */
export function IntelApp({ lab, patchLab }) {
  const [q, setQ] = useState('');
  const [result, setResult] = useState(lab.intelDone ? 'hit' : null);
  const [searching, setSearching] = useState(false);
  const target = SUSPECT.hashes.sha256;

  const search = () => {
    const val = q.trim().toLowerCase();
    if (!val) return;
    setSearching(true);
    setTimeout(() => {
      setSearching(false);
      if (val === target) { setResult('hit'); if (!lab.hashed) patchLab({ hashed: true, intelDone: true }); else patchLab({ intelDone: true }); }
      else setResult('miss');
    }, 700);
  };

  const ratio = SUSPECT.intel.detectionHits / SUSPECT.intel.detectionEngines;

  return (
    <div className="app intel">
      <style>{INTEL_CSS}</style>
      <div className="intel-top">
        <div className="intel-brand"><Globe size={17} /> Threat Lookup <span>hash reputation</span></div>
        <div className="intel-searchrow">
          <div className="intel-input">
            <Search size={15} />
            <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && search()}
              placeholder="Paste a file hash (fingerprint) — e.g. SHA-256" spellCheck={false} />
          </div>
          <button className="intel-go" onClick={search} disabled={searching}>{searching ? 'Searching…' : 'Search'}</button>
        </div>
        <div className="intel-hint">
          Tip: get the hash from the Terminal — <span className="mono">sha256sum /tmp/crack.exe</span> — then paste it here.
        </div>
      </div>

      <div className="intel-body">
        {!result && (
          <div className="intel-blank">
            <Fingerprint size={40} />
            <p>Look up a file by its <TermChip t="hash" /> to see if the world already knows it — no need to run the file.</p>
          </div>
        )}
        {result === 'miss' && (
          <div className="intel-miss fade-in"><AlertTriangle size={18} /> No results for that value. Make sure you pasted the full SHA-256 from the Terminal.</div>
        )}
        {result === 'hit' && (
          <div className="intel-hit fade-in">
            <div className="intel-verdict">
              <div className="iv-ring" style={{ '--p': `${Math.round(ratio * 100)}` }}>
                <div className="iv-num">{SUSPECT.intel.detectionHits}<span>/{SUSPECT.intel.detectionEngines}</span></div>
              </div>
              <div className="iv-main">
                <div className="iv-flag"><ShieldAlert size={16} /> Malicious</div>
                <div className="iv-sub"><b><TermChip t="detection ratio">Detection ratio</TermChip></b> — {SUSPECT.intel.detectionHits} of {SUSPECT.intel.detectionEngines} engines flagged this file.</div>
                <div className="iv-meta">First seen {SUSPECT.intel.firstSeen} · Community reputation <b className="neg">{SUSPECT.intel.reputation}</b></div>
              </div>
            </div>

            <div className="intel-sec">
              <div className="intel-sec-h">Security vendor labels</div>
              <div className="intel-labels">
                {SUSPECT.intel.labels.map((l) => <span key={l} className="ilabel">{l}</span>)}
              </div>
              <div className="intel-fam">Consensus family: <b>{SUSPECT.intel.family}</b></div>
            </div>

            <div className="intel-sec">
              <div className="intel-sec-h">Network indicators <span className="ioc-tag"><TermChip t="IOC">IOCs</TermChip></span></div>
              {SUSPECT.network.map((n) => (
                <div key={n.ioc} className="intel-ioc">
                  <Globe size={13} /><span className="mono">{n.ioc}</span><em>{n.note}</em>
                </div>
              ))}
            </div>

            <div className="intel-done"><CheckCircle2 size={15} /> Threat intel confirms a bad reputation. Next: prove intent from the file’s own code in PE Inspector.</div>
          </div>
        )}
      </div>
    </div>
  );
}

const INTEL_CSS = `
.intel{display:flex;flex-direction:column;height:100%;background:var(--bg-1)}
.intel-top{padding:16px 18px;border-bottom:1px solid var(--line);background:var(--bg-2)}
.intel-brand{display:flex;align-items:center;gap:9px;font-weight:800;font-size:15px}
.intel-brand svg{color:var(--accent)}
.intel-brand span{font-weight:500;font-size:12px;color:var(--txt-3);font-family:var(--font)}
.intel-searchrow{display:flex;gap:9px;margin-top:12px}
.intel-input{flex:1;display:flex;align-items:center;gap:9px;background:var(--bg-1);border:1px solid var(--line-2);border-radius:10px;padding:10px 13px}
.intel-input svg{color:var(--txt-3)}
.intel-input input{flex:1;background:transparent;border:none;outline:none;color:var(--txt-0);font-family:var(--mono);font-size:12.5px}
.intel-go{padding:0 20px;border:none;border-radius:10px;background:var(--accent);color:#04140f;font-weight:700;font-size:13px;cursor:pointer}
.intel-go:disabled{opacity:.6;cursor:default}
.intel-hint{font-size:11.5px;color:var(--txt-3);margin-top:9px}
.intel-body{flex:1;overflow-y:auto;padding:18px}
.intel-blank{max-width:360px;margin:36px auto 0;text-align:center;color:var(--txt-2)}
.intel-blank svg{color:var(--txt-3);margin-bottom:12px}
.intel-blank p{font-size:13.5px;line-height:1.6}
.intel-miss{display:flex;align-items:center;gap:9px;color:var(--warn);background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.22);border-radius:12px;padding:14px;font-size:13px}
.intel-hit{max-width:640px;margin:0 auto;display:flex;flex-direction:column;gap:16px}
.intel-verdict{display:flex;align-items:center;gap:18px;padding:18px;border-radius:14px;background:rgba(242,84,91,.06);border:1px solid rgba(242,84,91,.22)}
.iv-ring{width:84px;height:84px;border-radius:50%;flex-shrink:0;display:grid;place-items:center;
  background:conic-gradient(var(--bad) calc(var(--p)*1%), var(--bg-4) 0);position:relative}
.iv-ring::after{content:"";position:absolute;inset:8px;border-radius:50%;background:var(--bg-1)}
.iv-num{position:relative;z-index:1;font-weight:800;font-size:20px;color:#fff}
.iv-num span{font-size:12px;color:var(--txt-3);font-weight:600}
.iv-flag{display:inline-flex;align-items:center;gap:7px;font-size:16px;font-weight:800;color:var(--bad)}
.iv-sub{font-size:13px;color:var(--txt-1);margin-top:6px;line-height:1.5}
.iv-meta{font-size:12px;color:var(--txt-3);margin-top:6px}
.neg{color:var(--bad)}
.intel-sec{border:1px solid var(--line);border-radius:12px;background:var(--bg-2);padding:14px 16px}
.intel-sec-h{font-size:11px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;color:var(--txt-3);margin-bottom:11px;display:flex;align-items:center;gap:8px}
.ioc-tag{font-size:10px;background:var(--accent-soft);color:var(--accent);padding:2px 7px;border-radius:5px;letter-spacing:0}
.intel-labels{display:flex;flex-wrap:wrap;gap:7px}
.ilabel{font-size:12px;font-weight:600;padding:5px 11px;border-radius:7px;background:rgba(242,84,91,.12);color:#ff9ba0;border:1px solid rgba(242,84,91,.2)}
.intel-fam{font-size:12.5px;color:var(--txt-2);margin-top:11px}
.intel-ioc{display:flex;align-items:center;gap:9px;padding:8px 0;border-bottom:1px solid var(--line);font-size:12.5px}
.intel-ioc:last-child{border-bottom:none}
.intel-ioc svg{color:var(--txt-3);flex-shrink:0}
.intel-ioc .mono{color:var(--txt-0)}
.intel-ioc em{color:var(--txt-3);font-style:normal;margin-left:auto;text-align:right}
.intel-done{display:flex;align-items:center;gap:9px;font-size:12.5px;color:var(--good);background:rgba(52,211,153,.08);border:1px solid rgba(52,211,153,.2);border-radius:12px;padding:13px}
`;

/* =============================================================================
   PE INSPECTOR — static analysis of the PE without running it. Tabs: Overview,
   Imports (flagged APIs), Strings. Opening + viewing imports marks "staticDone".
   ============================================================================= */
export function PEApp({ lab, patchLab }) {
  const [tab, setTab] = useState('overview');
  const gated = !lab.restored;

  useEffect(() => {
    // reviewing imports is the key learning moment → completes the gate
    if (!gated && tab === 'imports' && !lab.staticDone) patchLab({ staticDone: true });
  }, [tab, gated]); // eslint-disable-line

  if (gated) {
    return (
      <div className="app pe">
        <style>{PE_CSS}</style>
        <div className="pe-locked">
          <ScanLine size={38} />
          <h3>No sample loaded</h3>
          <p>crack.exe is still in <b>quarantine</b>. Restore it from <b>OmniGuard</b>, then reopen the PE Inspector to analyse it.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="app pe">
      <style>{PE_CSS}</style>
      <div className="pe-head">
        <div className="pe-file"><FileWarning size={16} /> <span className="mono">crack.exe</span><span className="pe-badge">loaded · not executed</span></div>
        <div className="pe-tabs">
          {[['overview', 'Overview'], ['imports', 'Imports'], ['strings', 'Strings']].map(([k, l]) => (
            <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}{k === 'imports' && <span className="pe-flag">{SUSPECT.pe.importsFlagged}</span>}</button>
          ))}
        </div>
      </div>

      <div className="pe-body">
        {tab === 'overview' && (
          <div className="fade-in">
            <div className="pe-note">
              <ScanLine size={14} /> <span><b><TermChip t="Static analysis" /></b>: reading the file’s structure <b>without running it</b>. Safe, and it reveals intent.</span>
            </div>
            <div className="pe-grid">
              <PECard k="File type" v={SUSPECT.pe.fileType} />
              <PECard k="Subsystem" v={SUSPECT.pe.subsystem} />
              <PECard k="Architecture" v={`${SUSPECT.pe.bits}-bit`} />
              <PECard k=".NET assembly" v={SUSPECT.pe.dotnet ? 'Yes' : 'No'} warn={SUSPECT.pe.dotnet} />
              <PECard k="Packed / obfuscated" v={SUSPECT.pe.packed ? 'Likely' : 'No'} warn={SUSPECT.pe.packed} />
              <PECard k="Sections" v={SUSPECT.pe.sections.join('  ')} mono />
              <PECard k="DOS header" v={`Present (${SUSPECT.pe.dosHeaderBytes} bytes)`} />
              <PECard k="Flagged imports" v={`${SUSPECT.pe.importsFlagged} (red)`} warn />
            </div>
            <div className="pe-interp">
              <b>Interpretation.</b> A valid Windows <TermChip t="PE" /> file — multiple sections, GUI subsystem. That alone is normal.
              What isn’t normal is the flagged import list. Open the <b>Imports</b> tab.
            </div>
          </div>
        )}

        {tab === 'imports' && (
          <div className="fade-in">
            <div className="pe-note bad">
              <AlertTriangle size={14} /> <span>PE Inspector flags <b>{SUSPECT.pe.importsFlagged}</b> imports commonly abused by malware. <TermChip t="Import">Imports</TermChip> are the Windows functions a program calls.</span>
            </div>
            <div className="pe-imp-h">Flagged functions</div>
            {SUSPECT.pe.suspiciousImports.map((im) => (
              <div key={im.api} className="pe-imp">
                <code>{im.api}</code>
                <span>{im.flag}</span>
              </div>
            ))}
            <div className="pe-imp-h normal">Also imported (normal for a windowed app)</div>
            <div className="pe-normal">
              {SUSPECT.pe.normalImports.map((n) => <code key={n}>{n}</code>)}
            </div>
            <div className="pe-interp">
              <b>Interpretation.</b> Keyboard hooks + key-state reads = <TermChip t="keylogger" />. Remote-thread creation = <TermChip t="process injection" />.
              Anti-kill + a network call = it wants to persist and phone home. This is a <TermChip t="RAT" /> with keylogging.
            </div>
          </div>
        )}

        {tab === 'strings' && (
          <div className="fade-in">
            <div className="pe-note"><HashIcon size={14} /> <span><b>{SUSPECT.pe.stringsCount.toLocaleString()}</b> readable strings found. Strings are human-readable text inside a file — URLs, commands, filenames.</span></div>
            <div className="pe-strings">
              {['GetKeyboardState', 'log.txt', 'ip-api.com/json', 'sentinel-c2-node.duckdns.org', 'Software\\Microsoft\\Windows\\CurrentVersion\\Run', 'AsyncClient', 'Keylogger started', 'CONNECT %s:%d', 'InstallStub', 'DisableTaskMgr'].map((s, i) => (
                <div key={i} className="pe-str"><span className="pe-str-i">{String(i * 137 + 44).padStart(5, '0')}</span><code>{s}</code></div>
              ))}
              <div className="pe-str more">…{(SUSPECT.pe.stringsCount - 10).toLocaleString()} more</div>
            </div>
            <div className="pe-interp">
              <b>Interpretation.</b> The strings corroborate the imports: a keylog output file, an IP-geolocation lookup, a <TermChip t="C2">command-and-control</TermChip> domain, and a <b>Run</b> registry key for persistence.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
function PECard({ k, v, warn, mono }) {
  return (
    <div className={`pe-card ${warn ? 'warn' : ''}`}>
      <div className="pe-card-k">{k}</div>
      <div className={`pe-card-v ${mono ? 'mono' : ''}`}>{v}</div>
    </div>
  );
}

const PE_CSS = `
.pe{display:flex;flex-direction:column;height:100%;background:var(--bg-1)}
.pe-locked{max-width:380px;margin:44px auto 0;text-align:center;color:var(--txt-2)}
.pe-locked svg{color:var(--txt-3);margin-bottom:12px}
.pe-locked h3{margin:0 0 6px;color:var(--txt-0)}
.pe-locked p{font-size:13px;line-height:1.6}
.pe-head{border-bottom:1px solid var(--line);background:var(--bg-2);padding:12px 16px 0}
.pe-file{display:flex;align-items:center;gap:9px;font-size:14px;font-weight:700}
.pe-file svg{color:var(--bad)}
.pe-badge{font-size:10.5px;font-weight:700;color:var(--good);background:rgba(52,211,153,.12);padding:2px 8px;border-radius:5px;font-family:var(--font)}
.pe-tabs{display:flex;gap:4px;margin-top:12px}
.pe-tabs button{position:relative;padding:9px 15px;border:none;background:transparent;color:var(--txt-2);font-weight:600;font-size:13px;cursor:pointer;border-bottom:2px solid transparent}
.pe-tabs button:hover{color:var(--txt-0)}
.pe-tabs button.on{color:var(--txt-0);border-bottom-color:var(--accent)}
.pe-flag,.pe-badge{margin-left:6px}
.pe-flag{font-size:10px;font-weight:800;background:var(--bad);color:#fff;border-radius:999px;padding:1px 6px}
.pe-body{flex:1;overflow-y:auto;padding:16px 18px}
.pe-note{display:flex;gap:9px;padding:11px 13px;border-radius:10px;font-size:12.5px;line-height:1.5;background:var(--bg-2);border:1px solid var(--line);color:var(--txt-1);margin-bottom:14px}
.pe-note svg{color:var(--accent);flex-shrink:0;margin-top:1px}
.pe-note.bad{background:rgba(242,84,91,.07);border-color:rgba(242,84,91,.22)}
.pe-note.bad svg{color:var(--bad)}
.pe-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:9px}
.pe-card{border:1px solid var(--line);border-radius:11px;background:var(--bg-2);padding:12px 13px}
.pe-card.warn{border-color:rgba(245,158,11,.3);background:rgba(245,158,11,.05)}
.pe-card-k{font-size:11px;color:var(--txt-3);font-weight:600;margin-bottom:5px}
.pe-card-v{font-size:14px;font-weight:700;color:var(--txt-0)}
.pe-card.warn .pe-card-v{color:var(--warn)}
.pe-card-v.mono{font-family:var(--mono);font-size:12.5px;font-weight:500}
.pe-interp{margin-top:16px;padding:13px 15px;border-radius:11px;background:var(--violet-soft);border:1px solid rgba(124,108,240,.25);font-size:13px;line-height:1.65;color:var(--txt-1)}
.pe-imp-h{font-size:11px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;color:var(--bad);margin:4px 0 9px}
.pe-imp-h.normal{color:var(--txt-3);margin-top:18px}
.pe-imp{display:flex;gap:14px;align-items:baseline;padding:9px 11px;border:1px solid rgba(242,84,91,.16);border-left:3px solid var(--bad);border-radius:8px;background:rgba(242,84,91,.04);margin-bottom:6px}
.pe-imp code{font-family:var(--mono);font-size:12.5px;color:#ff9ba0;font-weight:600;flex-shrink:0;min-width:180px}
.pe-imp span{font-size:12.5px;color:var(--txt-1);line-height:1.5}
.pe-normal{display:flex;flex-wrap:wrap;gap:7px}
.pe-normal code{font-family:var(--mono);font-size:12px;color:var(--txt-2);background:var(--bg-2);border:1px solid var(--line);border-radius:6px;padding:5px 9px}
.pe-strings{border:1px solid var(--line);border-radius:11px;overflow:hidden;background:#060a12}
.pe-str{display:flex;gap:14px;align-items:center;padding:7px 13px;border-bottom:1px solid var(--line);font-family:var(--mono);font-size:12.5px}
.pe-str:last-child{border-bottom:none}
.pe-str-i{color:var(--txt-3);font-size:11px}
.pe-str code{color:#cfe0f2}
.pe-str.more{color:var(--txt-3);justify-content:center;font-style:italic}
`;

/* =============================================================================
   REPORT — the verdict + IOC confirmation. Choosing "malicious" and confirming
   the IOC list satisfies the final gate.
   ============================================================================= */
export function ReportApp({ lab, patchLab, allDone }) {
  const [choice, setChoice] = useState(lab.verdict);
  const [confirmed, setConfirmed] = useState(lab.iocsConfirmed);
  const { verdict, iocs } = SUMMARY;

  const submit = () => {
    patchLab({ verdict: choice, iocsConfirmed: choice === 'malicious' ? confirmed : false });
  };
  const done = lab.verdict === 'malicious' && lab.iocsConfirmed;

  return (
    <div className="app report">
      <style>{REPORT_CSS}</style>
      <div className="rep-inner">
        <div className="rep-head">
          <div className="rep-ic"><FileText size={18} /></div>
          <div>
            <div className="rep-title">Triage report — crack.exe</div>
            <div className="rep-sub">Record your verdict and the Indicators of Compromise.</div>
          </div>
        </div>

        <div className="rep-evi">
          <div className="rep-evi-h">Evidence collected</div>
          <EvItem ok={lab.foundFile} t="Located crack.exe in /tmp (temp folder)" />
          <EvItem ok={lab.restored} t="Collected the sample safely (restored from quarantine)" />
          <EvItem ok={lab.inspected} t="Reviewed file metadata (173 KB, no publisher)" />
          <EvItem ok={lab.hashed} t="Computed the SHA-256 fingerprint" />
          <EvItem ok={lab.intelDone} t={`Threat intel: ${SUSPECT.intel.detectionHits}/${SUSPECT.intel.detectionEngines} engines flagged it`} />
          <EvItem ok={lab.staticDone} t="Static analysis: 27 malicious imports (keylogging, injection, anti-kill)" />
        </div>

        <div className="rep-q">
          <div className="rep-q-t">{verdict.prompt}</div>
          <div className="rep-opts">
            {verdict.options.map((o) => (
              <button key={o.value} className={`rep-opt ${choice === o.value ? 'sel' : ''} ${o.value}`} onClick={() => setChoice(o.value)}>
                <span className="rep-radio" />{o.label}
              </button>
            ))}
          </div>
          {choice && choice !== 'malicious' && <div className="rep-wrong"><AlertTriangle size={14} /> {verdict.wrongNote}</div>}
        </div>

        {choice === 'malicious' && (
          <div className="rep-ioc fade-up">
            <div className="rep-q-t">Confirm the Indicators of Compromise (<TermChip t="IOC">IOCs</TermChip>)</div>
            <div className="rep-ioc-list">
              {iocs.map((i) => (
                <div key={i.k} className="rep-ioc-row"><span className="rioc-k">{i.k}</span><span className="rioc-v mono">{i.v}</span></div>
              ))}
            </div>
            <label className="rep-confirm">
              <input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
              <span>These IOCs are accurate and can be shared with the team to hunt this threat elsewhere.</span>
            </label>
          </div>
        )}

        <button className="rep-submit" disabled={!choice || (choice === 'malicious' && !confirmed)} onClick={submit}>
          {done ? <><Check size={16} /> Verdict recorded</> : 'Submit verdict'}
        </button>

        {done && (
          <div className="rep-final fade-up">
            <CheckCircle2 size={16} /> {SUMMARY.passBody}
          </div>
        )}
      </div>
    </div>
  );
}
function EvItem({ ok, t }) {
  return <div className={`ev ${ok ? 'ok' : ''}`}>{ok ? <CheckCircle2 size={14} /> : <span className="ev-dot" />} {t}</div>;
}

const REPORT_CSS = `
.report{height:100%;overflow-y:auto;background:var(--bg-1)}
.rep-inner{max-width:620px;margin:0 auto;padding:22px}
.rep-head{display:flex;align-items:center;gap:12px;margin-bottom:18px}
.rep-ic{width:44px;height:44px;border-radius:12px;display:grid;place-items:center;background:var(--accent-soft);color:var(--accent)}
.rep-title{font-size:16px;font-weight:800}
.rep-sub{font-size:12.5px;color:var(--txt-2);margin-top:2px}
.rep-evi{border:1px solid var(--line);border-radius:12px;background:var(--bg-2);padding:14px 16px;margin-bottom:18px}
.rep-evi-h{font-size:11px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;color:var(--txt-3);margin-bottom:10px}
.ev{display:flex;align-items:center;gap:9px;font-size:12.5px;color:var(--txt-3);padding:5px 0}
.ev.ok{color:var(--txt-1)}
.ev.ok svg{color:var(--good)}
.ev-dot{width:14px;height:14px;border-radius:50%;border:2px solid var(--txt-3);display:inline-block}
.rep-q{margin-bottom:16px}
.rep-q-t{font-size:14px;font-weight:700;margin-bottom:11px}
.rep-opts{display:flex;flex-direction:column;gap:8px}
.rep-opt{display:flex;align-items:center;gap:11px;padding:13px 15px;border:1px solid var(--line-2);border-radius:11px;background:var(--bg-2);color:var(--txt-1);font-size:13.5px;font-weight:600;cursor:pointer;text-align:left;transition:border-color .14s,background .14s}
.rep-opt:hover{border-color:var(--txt-2)}
.rep-radio{width:17px;height:17px;border-radius:50%;border:2px solid var(--txt-3);flex-shrink:0;transition:border-color .14s}
.rep-opt.sel{border-color:var(--accent);background:var(--accent-soft)}
.rep-opt.sel.malicious{border-color:var(--bad);background:rgba(242,84,91,.08)}
.rep-opt.sel .rep-radio{border-color:var(--accent);border-width:5px}
.rep-opt.sel.malicious .rep-radio{border-color:var(--bad)}
.rep-wrong{display:flex;align-items:center;gap:8px;margin-top:10px;font-size:12px;color:var(--warn);background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.2);border-radius:9px;padding:9px 12px}
.rep-ioc{margin-bottom:16px}
.rep-ioc-list{border:1px solid var(--line);border-radius:11px;overflow:hidden;background:var(--bg-2);margin-bottom:12px}
.rep-ioc-row{display:flex;gap:12px;padding:10px 14px;border-bottom:1px solid var(--line);font-size:12.5px}
.rep-ioc-row:last-child{border-bottom:none}
.rioc-k{color:var(--txt-2);width:150px;flex-shrink:0}
.rioc-v{color:var(--txt-0);word-break:break-all}
.rep-confirm{display:flex;gap:10px;align-items:flex-start;font-size:12.5px;color:var(--txt-1);line-height:1.5;cursor:pointer}
.rep-confirm input{margin-top:2px;width:16px;height:16px;accent-color:var(--accent);flex-shrink:0}
.rep-submit{width:100%;margin-top:8px;padding:13px;border:none;border-radius:11px;background:linear-gradient(135deg,#22d3b3,#1fb89d);color:#04140f;font-weight:800;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px}
.rep-submit:disabled{background:var(--bg-4);color:var(--txt-3);cursor:not-allowed}
.rep-final{display:flex;gap:10px;margin-top:16px;padding:14px 16px;border-radius:12px;background:rgba(52,211,153,.08);border:1px solid rgba(52,211,153,.22);font-size:13px;line-height:1.6;color:var(--txt-1)}
.rep-final svg{color:var(--good);flex-shrink:0;margin-top:2px}
`;
