import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  FolderOpen, TerminalSquare, ShieldCheck, Globe, ScanLine, FileText,
  Wifi, Volume2, BatteryMedium, Search as SearchIcon, Bug, ChevronRight,
  CircleHelp, X,
} from 'lucide-react';
import { LAB_META, TASKS, TASK_ORDER, SUSPECT } from '../data/scenario.js';
import Window from './Window.jsx';
import Byte from './Byte.jsx';
import { FilesApp, TerminalApp, SecurityApp, IntelApp, PEApp, ReportApp } from './apps.jsx';

/* App registry — id → metadata + component. The dock and window manager both
   read from this so adding an app is a one-line change. */
const APP_DEFS = {
  files:    { title: 'Files',            Icon: FolderOpen,    color: '#3b82f6', w: 760, h: 520, Comp: FilesApp },
  terminal: { title: 'Terminal',         Icon: TerminalSquare,color: '#22d3b3', w: 680, h: 440, Comp: TerminalApp },
  security: { title: 'Sentinel Security',Icon: ShieldCheck,   color: '#7c6cf0', w: 720, h: 500, Comp: SecurityApp },
  intel:    { title: 'Threat Lookup',    Icon: Globe,         color: '#06b6d4', w: 720, h: 560, Comp: IntelApp },
  pe:       { title: 'PE Inspector',     Icon: ScanLine,      color: '#f59e0b', w: 720, h: 560, Comp: PEApp },
  report:   { title: 'Triage Report',    Icon: FileText,      color: '#34d399', w: 680, h: 620, Comp: ReportApp },
};
const DOCK_ORDER = ['files', 'terminal', 'security', 'intel', 'pe', 'report'];

let zCounter = 10;

export default function Desktop({ lab, patchLab, resetLab, isTaskDone }) {
  const [wins, setWins] = useState({});   // id -> window state
  const [focus, setFocus] = useState(null);
  const [clock, setClock] = useState(new Date());
  const [showHelp, setShowHelp] = useState(false);

  const allDone = TASK_ORDER.every((_, i) => isTaskDone(TASKS[i]));

  useEffect(() => {
    const i = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(i);
  }, []);

  const openApp = useCallback((id) => {
    const def = APP_DEFS[id]; if (!def) return;
    setWins((w) => {
      if (w[id]) {
        // already open — un-minimise + focus
        return { ...w, [id]: { ...w[id], min: false, z: ++zCounter } };
      }
      // cascade new windows a little
      const n = Object.keys(w).length;
      const vw = window.innerWidth, vh = window.innerHeight;
      const width = Math.min(def.w, vw - 60);
      const height = Math.min(def.h, vh - 160);
      const x = Math.max(20, Math.min(80 + n * 28, vw - width - 20));
      const y = Math.max(52, Math.min(64 + n * 24, vh - height - 90));
      return { ...w, [id]: { id, ...def, x, y, w: width, h: height, z: ++zCounter, min: false, max: false } };
    });
    setFocus(id);
  }, []);

  const closeApp = (id) => setWins((w) => { const n = { ...w }; delete n[id]; return n; });
  const focusApp = (id) => { setFocus(id); setWins((w) => (w[id] ? { ...w, [id]: { ...w[id], z: ++zCounter } } : w)); };
  const minimizeApp = (id) => setWins((w) => ({ ...w, [id]: { ...w[id], min: true } }));
  const toggleMax = (id) => setWins((w) => ({ ...w, [id]: { ...w[id], max: !w[id].max, z: ++zCounter } }));
  const changeWin = (id, patch) => setWins((w) => ({ ...w, [id]: { ...w[id], ...patch } }));

  const doneCount = TASK_ORDER.filter((_, i) => isTaskDone(TASKS[i])).length;

  const time = clock.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="os">
      <style>{OS_CSS}</style>

      {/* wallpaper */}
      <div className="wall" />
      <div className="wall-grid" />

      {/* top status bar */}
      <div className="topbar">
        <div className="tb-left">
          <span className="tb-logo"><ShieldCheck size={15} /></span>
          <span className="tb-os">{LAB_META.os}</span>
          <span className="tb-sep">·</span>
          <span className="tb-host">{LAB_META.host}</span>
        </div>
        <div className="tb-center">
          {focus && APP_DEFS[focus] && wins[focus] && !wins[focus].min
            ? <span className="tb-active">{APP_DEFS[focus].title}</span>
            : <span className="tb-active dim">Desktop</span>}
        </div>
        <div className="tb-right">
          <button className="tb-help" onClick={() => setShowHelp(true)} title="About this lab"><CircleHelp size={15} /></button>
          <span className="tb-ic"><Wifi size={15} /></span>
          <span className="tb-ic"><Volume2 size={15} /></span>
          <span className="tb-ic"><BatteryMedium size={15} /></span>
          <span className="tb-clock">{time}</span>
        </div>
      </div>

      {/* desktop case-file widget */}
      <div className="case-widget">
        <div className="cw-h"><Bug size={15} /> Active case</div>
        <div className="cw-title">Suspicious file on {LAB_META.host}</div>
        <div className="cw-body">
          The SOC flagged odd activity. Something was dropped in a temp folder.
          Find it, collect it safely, and decide if it’s malware.
        </div>
        <div className="cw-progress">
          <div className="cw-bar"><span style={{ width: `${(doneCount / TASK_ORDER.length) * 100}%` }} /></div>
          <span className="cw-count">{doneCount}/{TASK_ORDER.length} steps</span>
        </div>
        <button className="cw-open" onClick={() => openApp('files')}>Open Files <ChevronRight size={14} /></button>
        <div className="cw-hint">Guided by <b>Byte</b> — drag the assistant anywhere.</div>
      </div>

      {/* windows */}
      {DOCK_ORDER.map((id) => {
        const win = wins[id];
        if (!win || win.min) return null;
        const Comp = APP_DEFS[id].Comp;
        return (
          <Window
            key={id}
            win={win}
            focused={focus === id}
            onFocus={() => focusApp(id)}
            onClose={() => closeApp(id)}
            onMinimize={() => minimizeApp(id)}
            onToggleMax={() => toggleMax(id)}
            onChange={(patch) => changeWin(id, patch)}
          >
            <Comp lab={lab} patchLab={patchLab} openApp={openApp} allDone={allDone} />
          </Window>
        );
      })}

      {/* dock */}
      <div className="dock">
        {DOCK_ORDER.map((id) => {
          const def = APP_DEFS[id];
          const isOpen = !!wins[id];
          // pulse the app the current task points to (nudge)
          const activeTask = TASKS[lab.currentTask];
          const nudge = lab.introSeen && !allDone && activeTask && activeTask.app === id && !isTaskDone(activeTask);
          return (
            <button
              key={id}
              className={`dock-app ${isOpen ? 'open' : ''} ${nudge ? 'nudge' : ''}`}
              style={{ '--ac': def.color }}
              onClick={() => (isOpen && !wins[id].min && focus === id ? minimizeApp(id) : openApp(id))}
              title={def.title}
            >
              <def.Icon size={22} />
              <span className="dock-label">{def.title}</span>
              {isOpen && <span className="dock-dot" />}
            </button>
          );
        })}
      </div>

      {/* the floating guide */}
      <Byte
        lab={lab} patchLab={patchLab} resetLab={resetLab}
        isTaskDone={isTaskDone} openApp={openApp} allDone={allDone}
      />

      {showHelp && <HelpModal onClose={() => setShowHelp(false)} onReset={resetLab} />}
    </div>
  );
}

function HelpModal({ onClose, onReset }) {
  return (
    <div className="help-scrim" onClick={onClose}>
      <div className="help" onClick={(e) => e.stopPropagation()}>
        <div className="help-h">
          <span className="help-ic"><ShieldCheck size={18} /></span>
          <div style={{ flex: 1 }}>
            <div className="help-t">{LAB_META.os} {LAB_META.version}</div>
            <div className="help-s">{LAB_META.title}</div>
          </div>
          <button className="help-x" onClick={onClose}><X size={16} /></button>
        </div>
        <div className="help-body">
          <p>This is a browser-based forensics workstation. Work through the case with <b>Byte</b>, your floating guide (drag it anywhere). Each task unlocks the next once you complete it in the right app.</p>
          <p className="help-flow">Locate → Collect → Inspect → Fingerprint → Threat intel → Static analysis → Verdict</p>
          <p className="help-dim">Everything is simulated offline in your browser — no real files, hashes, or systems are involved.</p>
          <button className="help-reset" onClick={() => { onReset(); }}>Restart lab from the beginning</button>
        </div>
      </div>
    </div>
  );
}

const OS_CSS = `
.os{position:fixed;inset:0;overflow:hidden}
.wall{position:absolute;inset:0;background:
  radial-gradient(1100px 700px at 78% -8%, #0f2d40 0%, transparent 52%),
  radial-gradient(900px 640px at 8% 108%, #1c1a44 0%, transparent 50%),
  radial-gradient(700px 500px at 60% 120%, #0c2e2a 0%, transparent 55%),
  #070b13}
.wall-grid{position:absolute;inset:0;background-image:
  linear-gradient(rgba(255,255,255,.022) 1px, transparent 1px),
  linear-gradient(90deg, rgba(255,255,255,.022) 1px, transparent 1px);
  background-size:44px 44px;mask-image:radial-gradient(circle at 50% 42%, black, transparent 78%);pointer-events:none}

.topbar{position:absolute;top:0;left:0;right:0;height:36px;display:flex;align-items:center;justify-content:space-between;
  padding:0 14px;background:rgba(7,11,19,.72);backdrop-filter:blur(16px);border-bottom:1px solid var(--line);z-index:500}
.tb-left,.tb-right{display:flex;align-items:center;gap:10px}
.tb-center{position:absolute;left:50%;transform:translateX(-50%)}
.tb-logo{display:grid;place-items:center;color:var(--accent)}
.tb-os{font-weight:800;font-size:13px}
.tb-sep{color:var(--txt-3)}
.tb-host{font-family:var(--mono);font-size:11.5px;color:var(--txt-2)}
.tb-active{font-size:12.5px;font-weight:600;color:var(--txt-1)}
.tb-active.dim{color:var(--txt-3)}
.tb-ic{color:var(--txt-2);display:grid;place-items:center}
.tb-help{border:none;background:transparent;color:var(--txt-2);cursor:pointer;display:grid;place-items:center;padding:4px;border-radius:6px}
.tb-help:hover{background:var(--bg-3s);color:var(--txt-0)}
.tb-clock{font-size:12.5px;font-weight:700;font-variant-numeric:tabular-nums;margin-left:2px}

.case-widget{position:absolute;top:60px;left:24px;width:290px;padding:16px;border-radius:16px;
  background:rgba(13,18,32,.66);backdrop-filter:blur(14px);border:1px solid var(--line);box-shadow:0 20px 50px rgba(0,0,0,.4);z-index:5}
.cw-h{display:flex;align-items:center;gap:8px;font-size:11px;font-weight:800;letter-spacing:.6px;text-transform:uppercase;color:var(--warn)}
.cw-title{font-size:15px;font-weight:800;margin-top:8px}
.cw-body{font-size:12.5px;color:var(--txt-2);line-height:1.55;margin-top:6px}
.cw-progress{display:flex;align-items:center;gap:9px;margin-top:14px}
.cw-bar{flex:1;height:6px;border-radius:999px;background:var(--bg-4);overflow:hidden}
.cw-bar span{display:block;height:100%;background:linear-gradient(90deg,#22d3b3,#7c6cf0);border-radius:999px;transition:width .4s ease}
.cw-count{font-size:11px;color:var(--txt-3);font-weight:600;white-space:nowrap}
.cw-open{margin-top:14px;width:100%;display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:9px;border:none;border-radius:10px;
  background:var(--accent);color:#04140f;font-weight:700;font-size:13px;cursor:pointer}
.cw-open:hover{filter:brightness(1.06)}
.cw-hint{font-size:11px;color:var(--txt-3);margin-top:10px;text-align:center}
.cw-hint b{color:var(--txt-1)}

/* windows */
.win{position:absolute;display:flex;flex-direction:column;background:var(--bg-1);border:1px solid var(--line-2);border-radius:12px;
  box-shadow:0 24px 70px rgba(0,0,0,.5);overflow:hidden;min-width:380px;min-height:260px}
.win.focused{box-shadow:0 30px 90px rgba(0,0,0,.62),0 0 0 1px rgba(34,211,179,.18)}
.win.maxed{border-radius:0}
.win-bar{display:flex;align-items:center;gap:10px;height:40px;padding:0 10px 0 12px;background:var(--bg-2);border-bottom:1px solid var(--line);cursor:grab;user-select:none;flex-shrink:0}
.win-bar:active{cursor:grabbing}
.win-ic{width:22px;height:22px;border-radius:6px;display:grid;place-items:center;color:#04140f;flex-shrink:0}
.win-title{flex:1;font-size:13px;font-weight:700;color:var(--txt-0);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.win-ctrls{display:flex;gap:5px}
.wc{width:26px;height:26px;border:none;border-radius:7px;background:transparent;color:var(--txt-2);cursor:pointer;display:grid;place-items:center}
.wc:hover{background:var(--bg-4);color:var(--txt-0)}
.wc-close:hover{background:var(--bad);color:#fff}
.win-body{flex:1;overflow:hidden;min-height:0;position:relative}
.app{height:100%;width:100%}
.rz{position:absolute;z-index:2}
.rz-e{top:8px;bottom:8px;right:0;width:6px;cursor:ew-resize}
.rz-w{top:8px;bottom:8px;left:0;width:6px;cursor:ew-resize}
.rz-s{left:8px;right:8px;bottom:0;height:6px;cursor:ns-resize}
.rz-n{left:8px;right:8px;top:0;height:6px;cursor:ns-resize}
.rz-se{right:0;bottom:0;width:14px;height:14px;cursor:nwse-resize}
.rz-sw{left:0;bottom:0;width:14px;height:14px;cursor:nesw-resize}
.rz-ne{right:0;top:0;width:14px;height:14px;cursor:nesw-resize}
.rz-nw{left:0;top:0;width:14px;height:14px;cursor:nwse-resize}

/* dock */
.dock{position:absolute;bottom:14px;left:50%;transform:translateX(-50%);display:flex;align-items:flex-end;gap:8px;
  padding:9px 12px;border-radius:18px;background:rgba(10,15,26,.7);backdrop-filter:blur(18px);border:1px solid var(--line-2);
  box-shadow:0 18px 50px rgba(0,0,0,.5);z-index:520}
.dock-app{position:relative;width:48px;height:48px;border:none;border-radius:13px;background:var(--bg-3s);color:var(--ac);
  display:grid;place-items:center;cursor:pointer;transition:transform .16s ease,background .16s;}
.dock-app:hover{transform:translateY(-6px) scale(1.06);background:var(--bg-4)}
.dock-app.open{background:linear-gradient(135deg,color-mix(in srgb,var(--ac) 22%,transparent),var(--bg-3s))}
.dock-label{position:absolute;bottom:calc(100% + 10px);left:50%;transform:translateX(-50%);white-space:nowrap;
  font-size:11.5px;font-weight:600;padding:5px 10px;border-radius:8px;background:var(--bg-0);border:1px solid var(--line-2);color:var(--txt-0);
  opacity:0;pointer-events:none;transition:opacity .14s}
.dock-app:hover .dock-label{opacity:1}
.dock-dot{position:absolute;bottom:-5px;left:50%;transform:translateX(-50%);width:4px;height:4px;border-radius:50%;background:var(--ac)}
.dock-app.nudge{animation:dockNudge 1.6s ease-in-out infinite;box-shadow:0 0 0 2px color-mix(in srgb,var(--ac) 55%,transparent)}
@keyframes dockNudge{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}

/* help modal */
.help-scrim{position:fixed;inset:0;background:rgba(3,6,12,.6);backdrop-filter:blur(3px);display:grid;place-items:center;z-index:800;padding:20px}
.help{width:min(460px,100%);background:var(--bg-2);border:1px solid var(--line-2);border-radius:16px;box-shadow:0 30px 80px rgba(0,0,0,.6);overflow:hidden;animation:fadeUp .2s ease both}
.help-h{display:flex;align-items:center;gap:12px;padding:16px;border-bottom:1px solid var(--line)}
.help-ic{width:42px;height:42px;border-radius:11px;display:grid;place-items:center;color:#04140f;background:linear-gradient(135deg,#22d3b3,#7c6cf0)}
.help-t{font-size:15px;font-weight:800}
.help-s{font-size:12px;color:var(--txt-2);margin-top:2px}
.help-x{margin-left:auto;width:30px;height:30px;border:none;background:transparent;color:var(--txt-2);border-radius:8px;cursor:pointer;display:grid;place-items:center}
.help-x:hover{background:var(--bg-3s);color:var(--txt-0)}
.help-body{padding:16px}
.help-body p{font-size:13px;line-height:1.6;color:var(--txt-1);margin:0 0 12px}
.help-flow{font-family:var(--mono);font-size:12px;color:var(--accent);background:var(--bg-1);border:1px solid var(--line);border-radius:9px;padding:11px 13px}
.help-dim{color:var(--txt-3)!important;font-size:12px!important}
.help-reset{width:100%;padding:10px;border:1px solid var(--line-2);border-radius:10px;background:var(--bg-3s);color:var(--txt-1);font-weight:600;font-size:13px;cursor:pointer}
.help-reset:hover{background:var(--bg-4);color:var(--txt-0)}

@media (max-width:720px){
  .case-widget{display:none}
  .dock{gap:5px;padding:7px 9px}
  .dock-app{width:42px;height:42px}
}
`;
