import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Minus, Square, X, Copy } from 'lucide-react';

/* A real draggable/resizable desktop window. Controlled by Desktop.jsx which
   owns the window registry (position, size, z-index, min/max state). This
   component renders the chrome + handles drag/resize gestures and reports
   changes up via callbacks. */
export default function Window({
  win, focused, onFocus, onClose, onMinimize, onToggleMax, onChange, children,
}) {
  const ref = useRef(null);
  const drag = useRef(null);

  const startDrag = (e) => {
    if (win.max) return;
    onFocus();
    const pt = e.touches ? e.touches[0] : e;
    drag.current = { mode: 'move', sx: pt.clientX, sy: pt.clientY, ox: win.x, oy: win.y };
    attach();
    e.preventDefault();
  };
  const startResize = (dir) => (e) => {
    if (win.max) return;
    onFocus();
    const pt = e.touches ? e.touches[0] : e;
    drag.current = { mode: 'resize', dir, sx: pt.clientX, sy: pt.clientY, ox: win.x, oy: win.y, ow: win.w, oh: win.h };
    attach();
    e.stopPropagation();
    e.preventDefault();
  };

  const onMove = useCallback((e) => {
    const d = drag.current; if (!d) return;
    if (e.cancelable) e.preventDefault();
    const pt = e.touches ? e.touches[0] : e;
    const dx = pt.clientX - d.sx, dy = pt.clientY - d.sy;
    const vw = window.innerWidth, vh = window.innerHeight;
    if (d.mode === 'move') {
      const x = Math.max(-40, Math.min(d.ox + dx, vw - 80));
      const y = Math.max(36, Math.min(d.oy + dy, vh - 60)); // keep below top bar
      onChange({ x, y });
    } else {
      let { ox, oy, ow, oh } = d;
      let x = ox, y = oy, w = ow, h = oh;
      const minW = 380, minH = 260;
      if (d.dir.includes('e')) w = Math.max(minW, ow + dx);
      if (d.dir.includes('s')) h = Math.max(minH, oh + dy);
      if (d.dir.includes('w')) { w = Math.max(minW, ow - dx); x = ox + (ow - w); }
      if (d.dir.includes('n')) { h = Math.max(minH, oh - dy); y = Math.max(36, oy + (oh - h)); }
      onChange({ x, y, w, h });
    }
  }, [onChange]);

  const onUp = useCallback(() => { drag.current = null; detach(); }, []);

  function attach() {
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    document.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('touchend', onUp);
  }
  function detach() {
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup', onUp);
    document.removeEventListener('touchmove', onMove);
    document.removeEventListener('touchend', onUp);
  }
  useEffect(() => detach, []); // cleanup on unmount

  const style = win.max
    ? { left: 0, top: 36, width: '100vw', height: 'calc(100vh - 36px - 74px)', zIndex: win.z }
    : { left: win.x, top: win.y, width: win.w, height: win.h, zIndex: win.z };

  return (
    <div
      ref={ref}
      className={`win ${focused ? 'focused' : ''} ${win.max ? 'maxed' : ''}`}
      style={style}
      onMouseDown={onFocus}
    >
      <div className="win-bar" onMouseDown={startDrag} onTouchStart={startDrag}
        onDoubleClick={onToggleMax}>
        <div className="win-ic" style={{ background: win.color || 'var(--accent)' }}>
          {win.Icon ? <win.Icon size={13} /> : null}
        </div>
        <div className="win-title">{win.title}</div>
        <div className="win-ctrls">
          <button className="wc wc-min" title="Minimize" onClick={(e) => { e.stopPropagation(); onMinimize(); }}><Minus size={14} /></button>
          <button className="wc wc-max" title={win.max ? 'Restore' : 'Maximize'} onClick={(e) => { e.stopPropagation(); onToggleMax(); }}>
            {win.max ? <Copy size={12} /> : <Square size={11} />}
          </button>
          <button className="wc wc-close" title="Close" onClick={(e) => { e.stopPropagation(); onClose(); }}><X size={14} /></button>
        </div>
      </div>
      <div className="win-body">{children}</div>

      {!win.max && (
        <>
          <span className="rz rz-e" onMouseDown={startResize('e')} onTouchStart={startResize('e')} />
          <span className="rz rz-s" onMouseDown={startResize('s')} onTouchStart={startResize('s')} />
          <span className="rz rz-w" onMouseDown={startResize('w')} onTouchStart={startResize('w')} />
          <span className="rz rz-n" onMouseDown={startResize('n')} onTouchStart={startResize('n')} />
          <span className="rz rz-se" onMouseDown={startResize('se')} onTouchStart={startResize('se')} />
          <span className="rz rz-sw" onMouseDown={startResize('sw')} onTouchStart={startResize('sw')} />
          <span className="rz rz-ne" onMouseDown={startResize('ne')} onTouchStart={startResize('ne')} />
          <span className="rz rz-nw" onMouseDown={startResize('nw')} onTouchStart={startResize('nw')} />
        </>
      )}
    </div>
  );
}
