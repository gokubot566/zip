import React, { useState, useEffect } from 'react';
import { ShieldCheck, ChevronRight, Lock } from 'lucide-react';
import { LAB_META } from '../data/scenario.js';

/* An original boot + sign-in screen. Two phases:
   1) a brief animated "power on" with the Sentinel mark,
   2) a lock screen where the analyst signs in to enter the desktop.
   No real auth — pressing Enter/Unlock boots the workstation. */
export default function BootScreen({ onEnter, host }) {
  const [phase, setPhase] = useState('power'); // power | lock
  const [clock, setClock] = useState(new Date());

  useEffect(() => {
    const t = setTimeout(() => setPhase('lock'), 1600);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => {
    const i = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(i);
  }, []);

  const time = clock.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const date = clock.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });

  return (
    <div className="boot">
      <style>{CSS}</style>
      <div className="boot-glow" />
      {phase === 'power' ? (
        <div className="boot-power fade-in">
          <div className="boot-mark"><ShieldCheck size={44} /></div>
          <div className="boot-name">Sentinel<span>OS</span></div>
          <div className="boot-dots"><i /><i /><i /></div>
        </div>
      ) : (
        <div className="lock fade-up">
          <div className="lock-clock">{time}</div>
          <div className="lock-date">{date}</div>

          <div className="lock-card">
            <div className="lock-avatar"><ShieldCheck size={30} /></div>
            <div className="lock-user">Security Analyst</div>
            <div className="lock-host">{host}</div>
            <button className="lock-enter" onClick={onEnter} autoFocus
              onKeyDown={(e) => { if (e.key === 'Enter') onEnter(); }}>
              <Lock size={15} /> Sign in to workstation <ChevronRight size={16} />
            </button>
            <div className="lock-note">Isolated analysis environment · {LAB_META.os} {LAB_META.version}</div>
          </div>
        </div>
      )}
    </div>
  );
}

const CSS = `
.boot{position:fixed;inset:0;display:grid;place-items:center;background:
  radial-gradient(1200px 700px at 70% -10%, #10243b 0%, transparent 55%),
  radial-gradient(900px 600px at 10% 110%, #1a1740 0%, transparent 50%),
  #070b13;overflow:hidden}
.boot-glow{position:absolute;inset:0;background:
  radial-gradient(600px 400px at 50% 40%, rgba(34,211,179,.06), transparent 60%);pointer-events:none}
.boot-power{display:flex;flex-direction:column;align-items:center;gap:16px}
.boot-mark{width:88px;height:88px;border-radius:24px;display:grid;place-items:center;color:#04140f;
  background:linear-gradient(135deg,#22d3b3,#7c6cf0);box-shadow:0 20px 60px rgba(34,211,179,.3)}
.boot-name{font-size:30px;font-weight:800;letter-spacing:-.5px}
.boot-name span{color:var(--accent);margin-left:2px}
.boot-dots{display:flex;gap:7px;margin-top:6px}
.boot-dots i{width:8px;height:8px;border-radius:50%;background:var(--accent);opacity:.4;animation:bd 1.1s infinite ease-in-out}
.boot-dots i:nth-child(2){animation-delay:.18s}
.boot-dots i:nth-child(3){animation-delay:.36s}
@keyframes bd{0%,100%{opacity:.25;transform:translateY(0)}50%{opacity:1;transform:translateY(-5px)}}

.lock{display:flex;flex-direction:column;align-items:center;text-align:center;z-index:1}
.lock-clock{font-size:74px;font-weight:800;letter-spacing:-2px;line-height:1}
.lock-date{font-size:16px;color:var(--txt-2);margin-top:4px;margin-bottom:44px}
.lock-card{display:flex;flex-direction:column;align-items:center;gap:10px;padding:30px 34px;border-radius:20px;
  background:var(--glass);backdrop-filter:blur(20px);border:1px solid var(--line);box-shadow:0 30px 80px rgba(0,0,0,.5);min-width:320px}
.lock-avatar{width:72px;height:72px;border-radius:50%;display:grid;place-items:center;color:#04140f;
  background:linear-gradient(135deg,#22d3b3,#7c6cf0);margin-bottom:4px}
.lock-user{font-size:18px;font-weight:700}
.lock-host{font-family:var(--mono);font-size:12px;color:var(--txt-3);letter-spacing:.5px}
.lock-enter{margin-top:14px;display:inline-flex;align-items:center;gap:9px;padding:12px 20px;border:none;border-radius:12px;
  background:linear-gradient(135deg,#22d3b3,#1fb89d);color:#04140f;font-weight:700;font-size:14px;cursor:pointer;transition:filter .15s,transform .1s}
.lock-enter:hover{filter:brightness(1.06)}
.lock-enter:active{transform:translateY(1px)}
.lock-note{font-size:11px;color:var(--txt-3);margin-top:12px}
`;
