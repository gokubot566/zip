import React, { useState } from 'react';
import { GLOSSARY } from '../data/scenario.js';

const MAP = Object.fromEntries(GLOSSARY.map((g) => [g.term.toLowerCase(), g]));

/* TermChip — wraps a jargon word and shows its one-word meaning inline, with a
   fuller explanation on hover/tap. Usage: <TermChip t="hash" /> or
   <TermChip t="IOC">IOCs</TermChip> to control the visible label. */
export function TermChip({ t, children }) {
  const g = MAP[(t || '').toLowerCase()];
  const [open, setOpen] = useState(false);
  const label = children || t;
  if (!g) return <>{label}</>;
  return (
    <span
      className={`term ${open ? 'open' : ''}`}
      tabIndex={0}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
      onClick={(e) => { e.stopPropagation(); setOpen((o) => !o); }}
    >
      {label}
      <span className="term-one">{g.one}</span>
      {open && (
        <span className="term-pop">
          <b>{g.term}</b> — <em>{g.one}</em>
          <span>{g.long}</span>
        </span>
      )}
    </span>
  );
}
