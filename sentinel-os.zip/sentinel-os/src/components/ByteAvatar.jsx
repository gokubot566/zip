import React from 'react';

/* ByteAvatar — a static, self-contained SVG robot mascot for the guide
   ("Byte"). Inline SVG so it needs no network/asset fetch and inherits the
   OS palette. This is intentionally NOT one of the human CHARACTERS: the
   launcher + panel header always show Byte the robot, and the trainee never
   sees a human face before that person has introduced themselves. */
export function ByteAvatar({ size = 84, speaking = false }) {
  return (
    <span
      className={`byte-avatar ${speaking ? 'speaking' : ''}`}
      style={{ width: size, height: size }}
      title="Byte — your lab guide"
      aria-label="Byte, your lab guide"
    >
      <svg viewBox="0 0 64 64" width="100%" height="100%" role="img" aria-hidden="true">
        <defs>
          <linearGradient id="byteBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#12243a" />
            <stop offset="1" stopColor="#0a0f1a" />
          </linearGradient>
          <linearGradient id="byteHead" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#1d3550" />
            <stop offset="1" stopColor="#122238" />
          </linearGradient>
          <radialGradient id="byteEye" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#8ff5e6" />
            <stop offset="0.6" stopColor="#22d3b3" />
            <stop offset="1" stopColor="#0e9e86" />
          </radialGradient>
        </defs>

        {/* backdrop */}
        <circle cx="32" cy="32" r="32" fill="url(#byteBg)" />

        {/* antenna */}
        <line x1="32" y1="15" x2="32" y2="9" stroke="#7c6cf0" strokeWidth="2.4" strokeLinecap="round" />
        <circle cx="32" cy="8" r="3" fill="#9a8cf5" />

        {/* head shell */}
        <rect x="14" y="16" width="36" height="30" rx="10" fill="url(#byteHead)" stroke="#7c6cf0" strokeWidth="1.6" />

        {/* ears / side pods */}
        <rect x="10" y="26" width="4.5" height="10" rx="2.2" fill="#7c6cf0" />
        <rect x="49.5" y="26" width="4.5" height="10" rx="2.2" fill="#7c6cf0" />

        {/* face screen */}
        <rect x="19" y="21" width="26" height="20" rx="7" fill="#070b13" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />

        {/* eyes */}
        <circle className="byte-eye" cx="26.5" cy="30.5" r="3.6" fill="url(#byteEye)" />
        <circle className="byte-eye" cx="37.5" cy="30.5" r="3.6" fill="url(#byteEye)" />
        <circle cx="27.6" cy="29.4" r="1.1" fill="#eafffb" />
        <circle cx="38.6" cy="29.4" r="1.1" fill="#eafffb" />

        {/* smile */}
        <path d="M25 36 Q32 40 39 36" fill="none" stroke="#22d3b3" strokeWidth="2" strokeLinecap="round" />
      </svg>
    </span>
  );
}
