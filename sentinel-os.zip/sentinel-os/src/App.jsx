import React, { useState, useEffect, useCallback, useRef } from 'react';
import { LAB_META, TASKS, TASK_ORDER } from './data/scenario.js';
import BootScreen from './components/BootScreen.jsx';
import Desktop from './components/Desktop.jsx';

const STORE_KEY = 'sentinel-os-forensics-lab-v1';

/* Global lab state that every app + the guide share. This is the single source
   of truth for investigation progress. Persisted to localStorage so a refresh
   doesn't wipe the trainee's work. */
const FRESH = {
  // investigation flags (set by the apps as the student acts)
  foundFile: false,        // opened /tmp/crack.exe location in Files
  restored: false,         // released it from quarantine
  inspected: false,        // opened Properties
  hashed: false,           // ran sha256sum on it
  intelDone: false,        // ran the threat-intel lookup
  staticDone: false,       // reviewed imports in PE Inspector
  verdict: null,           // 'malicious' etc.
  iocsConfirmed: false,
  // guide state
  introSeen: false,
  currentTask: 0,
  byteOpen: true,
};

function loadState() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return { ...FRESH };
    return { ...FRESH, ...JSON.parse(raw) };
  } catch {
    return { ...FRESH };
  }
}

export default function App() {
  const [booted, setBooted] = useState(false);
  const [lab, setLab] = useState(loadState);

  // persist lab state
  useEffect(() => {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(lab)); } catch { /* ignore */ }
  }, [lab]);

  const patchLab = useCallback((p) => {
    setLab((s) => ({ ...s, ...(typeof p === 'function' ? p(s) : p) }));
  }, []);

  const resetLab = useCallback(() => {
    try { localStorage.removeItem(STORE_KEY); } catch { /* ignore */ }
    setLab({ ...FRESH });
    setBooted(false);
  }, []);

  // ---- derive which task is satisfied, for the guide's gating ----
  const isTaskDone = useCallback((task, s = lab) => {
    const c = task.check;
    switch (c.type) {
      case 'foundFile': return s.foundFile;
      case 'restored': return s.restored;
      case 'inspected': return s.inspected;
      case 'command': return s.hashed;
      case 'intelLookup': return s.intelDone;
      case 'staticAnalysis': return s.staticDone;
      case 'verdict': return s.verdict === 'malicious' && s.iocsConfirmed;
      default: return false;
    }
  }, [lab]);

  return (
    <>
      {!booted ? (
        <BootScreen onEnter={() => setBooted(true)} host={LAB_META.host} />
      ) : (
        <Desktop lab={lab} patchLab={patchLab} resetLab={resetLab} isTaskDone={isTaskDone} />
      )}
    </>
  );
}
