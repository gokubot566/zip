import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, MessageSquare, BookOpen, HelpCircle, Check, X } from 'lucide-react';

/* ── Section divider ─────────────────────────────────────────────────────── */
function SectionDivider({ label }) {
  return (
    <div className="section-divider">
      <span>{label}</span>
    </div>
  );
}

/* ── Expandable reading section ─────────────────────────────────────────── */
function ContentSection({ heading, body, index }) {
  const [open, setOpen] = useState(true);
  return (
    <div style={{
      background: '#fff', border: '1px solid #e2e4e9', borderRadius: 8,
      marginBottom: 8, overflow: 'hidden',
      boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
    }}>
      <button onClick={() => setOpen(!open)} style={{
        width: '100%', textAlign: 'left', padding: '14px 18px',
        border: 'none', background: 'transparent', cursor: 'pointer',
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <span style={{
          fontFamily: "'DM Mono', monospace", fontSize: 10.5, fontWeight: 500,
          color: '#c4c9d4', minWidth: 24, flexShrink: 0,
        }}>{String(index + 1).padStart(2, '0')}</span>
        <span style={{
          fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 14.5,
          color: '#0f1117', flex: 1, textAlign: 'left',
        }}>{heading}</span>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.16 }}>
          <ChevronDown size={15} color="#9ca3af"/>
        </motion.div>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }}
            style={{ overflow: 'hidden' }}
          >
            <div style={{ height: 1, background: '#f0f1f3', margin: '0 18px' }}/>
            <div style={{ padding: '16px 18px 20px' }}>
              {body.split('\n\n').map((para, i, arr) => (
                <p key={i} style={{
                  fontFamily: "'Inter', sans-serif", fontSize: 14.5, color: '#3d4350',
                  lineHeight: 1.8, marginBottom: i < arr.length - 1 ? 14 : 0,
                }}>{para}</p>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ── Scenario card ───────────────────────────────────────────────────────── */
function ScenarioCard({ scenario, onDone, done }) {
  const [selected, setSelected] = useState(null);
  const [revealed, setRevealed] = useState(false);

  function pick(opt) {
    setSelected(opt);
    setRevealed(true);
    if (opt.correct && !done) onDone();
  }

  return (
    <div style={{
      background: '#fff', border: '1px solid #e2e4e9', borderRadius: 8,
      overflow: 'hidden', boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
    }}>
      {/* Header */}
      <div style={{
        padding: '12px 18px', background: '#f8f9fa', borderBottom: '1px solid #e2e4e9',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <MessageSquare size={13} color="#9ca3af"/>
        <span style={{
          fontFamily: "'DM Mono', monospace", fontSize: 10.5,
          color: '#9ca3af', letterSpacing: '0.06em',
        }}>WORKPLACE SCENARIO</span>
        <div style={{ flex: 1 }}/>
        <span style={{
          fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 14, color: '#0f1117',
        }}>{scenario.title}</span>
      </div>

      <div style={{ padding: '20px 18px' }}>
        {/* Situation */}
        <div style={{
          padding: '12px 15px', background: '#f8f9fa',
          border: '1px solid #e2e4e9', borderRadius: 7, marginBottom: 14,
        }}>
          <div style={{
            fontFamily: "'DM Mono', monospace", fontSize: 10.5,
            color: '#9ca3af', marginBottom: 7, letterSpacing: '0.06em',
          }}>SITUATION</div>
          <p style={{
            fontFamily: "'Inter', sans-serif", fontSize: 14.5,
            color: '#3d4350', lineHeight: 1.75, margin: 0,
          }}>{scenario.setup}</p>
        </div>

        {/* Message bubble */}
        <div style={{
          padding: '13px 16px', background: '#f3f0ff',
          border: '1px solid #c4b5fd',
          borderRadius: '4px 10px 10px 10px', marginBottom: 18,
          fontFamily: "'Inter', sans-serif", fontSize: 14.5,
          fontStyle: 'italic', color: '#3d1a78', lineHeight: 1.65,
        }}>{scenario.message}</div>

        {/* Prompt */}
        <div style={{
          fontFamily: "'DM Mono', monospace", fontSize: 10.5,
          color: '#9ca3af', marginBottom: 10, letterSpacing: '0.06em',
        }}>HOW DO YOU RESPOND?</div>

        {/* Options */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {scenario.options.map((opt, i) => {
            const isSel  = selected?.id === opt.id;
            const dimmed = revealed && !isSel;
            return (
              <button key={opt.id} onClick={() => !revealed && pick(opt)} style={{
                textAlign: 'left', padding: '12px 15px', borderRadius: 7,
                border: `1px solid ${
                  isSel
                    ? opt.correct ? '#86efac' : '#fca5a5'
                    : '#e2e4e9'
                }`,
                background: isSel
                  ? opt.correct ? '#f0fdf4' : '#fef2f2'
                  : '#f8f9fa',
                cursor: revealed ? 'default' : 'pointer',
                display: 'flex', alignItems: 'flex-start', gap: 12,
                opacity: dimmed ? 0.3 : 1,
                transition: 'all 0.14s',
              }}
                onMouseEnter={e => { if (!revealed) { e.currentTarget.style.borderColor = '#6d28d9'; e.currentTarget.style.background = '#faf8ff'; } }}
                onMouseLeave={e => { if (!revealed) { e.currentTarget.style.borderColor = '#e2e4e9'; e.currentTarget.style.background = '#f8f9fa'; } }}
              >
                <div style={{
                  width: 24, height: 24, borderRadius: 5, flexShrink: 0,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: isSel
                    ? opt.correct ? '#dcfce7' : '#fee2e2'
                    : '#fff',
                  border: `1px solid ${
                    isSel
                      ? opt.correct ? '#86efac' : '#fca5a5'
                      : '#e2e4e9'
                  }`,
                  fontFamily: "'DM Mono', monospace", fontSize: 10.5, fontWeight: 600,
                  color: isSel
                    ? opt.correct ? '#16a34a' : '#dc2626'
                    : '#9ca3af',
                }}>
                  {isSel ? (opt.correct ? '✓' : '✗') : String.fromCharCode(65 + i)}
                </div>
                <span style={{
                  fontFamily: "'Inter', sans-serif", fontSize: 14.5, lineHeight: 1.55,
                  color: isSel
                    ? opt.correct ? '#166534' : '#991b1b'
                    : '#3d4350',
                }}>"{opt.text}"</span>
              </button>
            );
          })}
        </div>

        {/* Feedback */}
        <AnimatePresence>
          {revealed && selected && (
            <motion.div
              initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }} transition={{ duration: 0.2 }}
              style={{
                marginTop: 12, padding: '14px 16px', borderRadius: 8,
                background: selected.correct ? '#f0fdf4' : '#fef2f2',
                border: `1px solid ${selected.correct ? '#86efac' : '#fca5a5'}`,
              }}
            >
              <p style={{
                fontFamily: "'Inter', sans-serif", fontSize: 14.5, lineHeight: 1.7, margin: 0,
                color: selected.correct ? '#166534' : '#991b1b',
              }}>{selected.feedback}</p>
              {!selected.correct && (
                <button onClick={() => { setSelected(null); setRevealed(false); }} style={{
                  marginTop: 10, padding: '6px 14px', borderRadius: 6,
                  background: '#fff', border: '1px solid #e2e4e9',
                  color: '#6b7280', fontFamily: "'Inter', sans-serif", fontSize: 13,
                  cursor: 'pointer',
                }}>Try again</button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ── Policy references ───────────────────────────────────────────────────── */
function PolicyRefs({ policies }) {
  const [expanded, setExpanded] = useState(null);
  return (
    <div style={{
      background: '#fff', border: '1px solid #e2e4e9', borderRadius: 8,
      overflow: 'hidden', boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
    }}>
      {/* Header */}
      <div style={{
        padding: '12px 18px', background: '#f8f9fa', borderBottom: '1px solid #e2e4e9',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <BookOpen size={13} color="#9ca3af"/>
        <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', letterSpacing: '0.06em' }}>
          POLICY REFERENCES
        </span>
        <div style={{ flex: 1 }}/>
        <span className="badge badge-default">
          {policies.length} {policies.length === 1 ? 'policy' : 'policies'}
        </span>
      </div>

      <div style={{ padding: '8px 10px' }}>
        {policies.map(pol => (
          <div key={pol.ref} style={{ marginBottom: 4 }}>
            <button
              onClick={() => setExpanded(expanded === pol.ref ? null : pol.ref)}
              style={{
                width: '100%', textAlign: 'left', padding: '11px 12px', borderRadius: 7,
                background: expanded === pol.ref ? '#f3f0ff' : 'transparent',
                border: `1px solid ${expanded === pol.ref ? '#c4b5fd' : 'transparent'}`,
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12,
                transition: 'all 0.15s',
              }}
              onMouseEnter={e => { if (expanded !== pol.ref) { e.currentTarget.style.background = '#f8f9fa'; e.currentTarget.style.borderColor = '#e2e4e9'; } }}
              onMouseLeave={e => { if (expanded !== pol.ref) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.borderColor = 'transparent'; } }}
            >
              <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#6d28d9', minWidth: 96, fontWeight: 500 }}>
                {pol.ref}
              </span>
              <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, fontWeight: 500, color: '#0f1117', flex: 1 }}>
                {pol.title}
              </span>
              <motion.div animate={{ rotate: expanded === pol.ref ? 180 : 0 }} transition={{ duration: 0.15 }}>
                <ChevronDown size={14} color="#9ca3af"/>
              </motion.div>
            </button>

            <AnimatePresence>
              {expanded === pol.ref && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }}
                  style={{ overflow: 'hidden' }}
                >
                  <div style={{ padding: '10px 12px 14px', paddingLeft: 120 }}>
                    <p style={{
                      fontFamily: "'Inter', sans-serif", fontSize: 14, color: '#3d4350',
                      lineHeight: 1.75, marginBottom: 12,
                    }}>{pol.summary}</p>
                    <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', marginBottom: 9, letterSpacing: '0.06em' }}>
                      YOUR OBLIGATIONS
                    </div>
                    {pol.obligations.map((ob, j) => (
                      <div key={j} style={{ display: 'flex', gap: 10, marginBottom: 7 }}>
                        <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#c4b5fd', marginTop: 8, flexShrink: 0 }}/>
                        <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: '#3d4350', lineHeight: 1.6 }}>
                          {ob}
                        </span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── Quiz ────────────────────────────────────────────────────────────────── */
function Quiz({ questions, onDone, done }) {
  const [answers,   setAnswers]   = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [current,   setCurrent]   = useState(0);

  const q           = questions[current];
  const allAnswered = questions.every((_, i) => answers[i] !== undefined);
  const score       = submitted
    ? questions.filter((_, i) => answers[i] === questions[i].correct).length
    : 0;

  function submit() { setSubmitted(true); if (!done) onDone(); }
  function reset()  { setAnswers({}); setSubmitted(false); setCurrent(0); }

  return (
    <div style={{
      background: '#fff', border: '1px solid #e2e4e9', borderRadius: 8,
      overflow: 'hidden', boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
    }}>
      {/* Header */}
      <div style={{
        padding: '12px 18px', background: '#f8f9fa', borderBottom: '1px solid #e2e4e9',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <HelpCircle size={13} color="#9ca3af"/>
          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 10.5, color: '#9ca3af', letterSpacing: '0.06em' }}>
            KNOWLEDGE CHECK
          </span>
        </div>
        {!submitted && (
          <div style={{ display: 'flex', gap: 5 }}>
            {questions.map((_, i) => (
              <button key={i} onClick={() => setCurrent(i)} style={{
                width: 28, height: 28, borderRadius: 5,
                background: current === i ? '#6d28d9'
                  : answers[i] !== undefined ? '#f0fdf4' : '#fff',
                border: current === i ? '1px solid #5b21b6'
                  : answers[i] !== undefined ? '1px solid #86efac' : '1px solid #e2e4e9',
                color: current === i ? '#fff'
                  : answers[i] !== undefined ? '#16a34a' : '#6b7280',
                fontFamily: "'DM Mono', monospace", fontSize: 11, fontWeight: 500,
                cursor: 'pointer', transition: 'all 0.12s',
              }}>{i + 1}</button>
            ))}
          </div>
        )}
      </div>

      <div style={{ padding: '20px 18px' }}>
        {!submitted ? (
          <>
            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -8 }} transition={{ duration: 0.16 }}
              >
                {/* Question */}
                <div style={{
                  padding: '15px 17px', background: '#f8f9fa',
                  border: '1px solid #e2e4e9', borderRadius: 8, marginBottom: 13,
                }}>
                  <div style={{ display: 'flex', gap: 11, alignItems: 'flex-start' }}>
                    <span style={{
                      fontFamily: "'DM Mono', monospace", fontSize: 11.5, fontWeight: 600,
                      color: '#6d28d9', flexShrink: 0, marginTop: 2,
                    }}>Q{current + 1}</span>
                    <p style={{
                      fontFamily: "'Inter', sans-serif", fontWeight: 600,
                      fontSize: 15, color: '#0f1117', lineHeight: 1.5, margin: 0,
                    }}>{q.q}</p>
                  </div>
                </div>

                {/* Options */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 7, marginBottom: 18 }}>
                  {q.opts.map((opt, i) => {
                    const sel = answers[current] === i;
                    return (
                      <button key={i}
                        onClick={() => setAnswers(a => ({ ...a, [current]: i }))}
                        style={{
                          textAlign: 'left', padding: '12px 15px', borderRadius: 7,
                          background: sel ? '#f3f0ff' : '#f8f9fa',
                          border: `1px solid ${sel ? '#c4b5fd' : '#e2e4e9'}`,
                          cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12,
                          transition: 'all 0.12s',
                        }}
                        onMouseEnter={e => { if (!sel) { e.currentTarget.style.borderColor = '#c4b5fd'; e.currentTarget.style.background = '#faf8ff'; } }}
                        onMouseLeave={e => { if (!sel) { e.currentTarget.style.borderColor = '#e2e4e9'; e.currentTarget.style.background = '#f8f9fa'; } }}
                      >
                        <div style={{
                          width: 24, height: 24, borderRadius: 5, flexShrink: 0,
                          background: sel ? '#ede9fe' : '#fff',
                          border: `1px solid ${sel ? '#c4b5fd' : '#e2e4e9'}`,
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontFamily: "'DM Mono', monospace", fontSize: 11, fontWeight: 600,
                          color: sel ? '#6d28d9' : '#9ca3af',
                        }}>{String.fromCharCode(65 + i)}</div>
                        <span style={{
                          fontFamily: "'Inter', sans-serif", fontSize: 14.5, lineHeight: 1.5,
                          color: sel ? '#3d1a78' : '#3d4350',
                        }}>{opt}</span>
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Nav */}
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <button
                onClick={() => setCurrent(c => Math.max(0, c - 1))}
                disabled={current === 0}
                style={{
                  padding: '8px 16px', borderRadius: 7, background: '#fff',
                  border: '1px solid #e2e4e9',
                  color: current === 0 ? '#d1d4db' : '#6b7280',
                  fontFamily: "'Inter', sans-serif", fontSize: 13,
                  cursor: current === 0 ? 'default' : 'pointer',
                }}
              >← Back</button>
              {current < questions.length - 1 ? (
                <button onClick={() => setCurrent(c => c + 1)} style={{
                  padding: '8px 16px', borderRadius: 7, background: '#fff',
                  border: '1px solid #e2e4e9', color: '#6b7280',
                  fontFamily: "'Inter', sans-serif", fontSize: 13, cursor: 'pointer',
                }}>Next →</button>
              ) : (
                <button onClick={submit} disabled={!allAnswered} style={{
                  padding: '8px 22px', borderRadius: 7,
                  background: allAnswered ? '#6d28d9' : '#f4f5f7',
                  border: `1px solid ${allAnswered ? '#5b21b6' : '#e2e4e9'}`,
                  color: allAnswered ? '#fff' : '#c4c9d4',
                  fontFamily: "'Inter', sans-serif", fontSize: 13, fontWeight: 600,
                  cursor: allAnswered ? 'pointer' : 'not-allowed',
                }}>Submit answers</button>
              )}
            </div>
          </>
        ) : (
          /* Results */
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.25 }}>
            {/* Score */}
            <div style={{
              textAlign: 'center', padding: '24px',
              background: '#f8f9fa', border: '1px solid #e2e4e9', borderRadius: 8, marginBottom: 18,
            }}>
              <div style={{
                fontFamily: "'Inter', sans-serif", fontWeight: 700, fontSize: 36,
                letterSpacing: '-0.04em', marginBottom: 6,
                color: score === questions.length ? '#166534' : '#0f1117',
              }}>{score} / {questions.length}</div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: '#6b7280' }}>
                {score === questions.length
                  ? 'All correct — excellent understanding.'
                  : score >= Math.ceil(questions.length * 0.75)
                    ? 'Good result. Review the explanations below.'
                    : 'Review the explanations and try again.'}
              </div>
            </div>

            {/* Per-question */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 18 }}>
              {questions.map((q2, i) => {
                const correct = answers[i] === q2.correct;
                return (
                  <div key={i} style={{
                    padding: '13px 15px', borderRadius: 8,
                    background: correct ? '#f0fdf4' : '#fef2f2',
                    border: `1px solid ${correct ? '#86efac' : '#fca5a5'}`,
                  }}>
                    <div style={{ display: 'flex', gap: 9, marginBottom: 7, alignItems: 'flex-start' }}>
                      {correct
                        ? <Check size={14} color="#16a34a" strokeWidth={2.5} style={{ flexShrink: 0, marginTop: 2 }}/>
                        : <X size={14} color="#dc2626" style={{ flexShrink: 0, marginTop: 2 }}/>
                      }
                      <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 14, color: '#0f1117', lineHeight: 1.45 }}>
                        {q2.q}
                      </div>
                    </div>
                    {!correct && (
                      <div style={{ marginLeft: 23, marginBottom: 8 }}>
                        <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 11.5, color: '#dc2626', marginBottom: 2 }}>
                          Your answer: "{q2.opts[answers[i]]}"
                        </div>
                        <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 11.5, color: '#16a34a' }}>
                          Correct: "{q2.opts[q2.correct]}"
                        </div>
                      </div>
                    )}
                    <div style={{
                      marginLeft: 23, padding: '9px 12px',
                      background: '#fff', borderRadius: 6,
                      border: '1px solid #e2e4e9',
                      fontFamily: "'Inter', sans-serif", fontSize: 14, color: '#3d4350', lineHeight: 1.7,
                    }}>{q2.exp}</div>
                  </div>
                );
              })}
            </div>

            <button onClick={reset} style={{
              padding: '8px 16px', borderRadius: 7, background: '#fff',
              border: '1px solid #e2e4e9', color: '#6b7280',
              fontFamily: "'Inter', sans-serif", fontSize: 13, cursor: 'pointer',
              transition: 'all 0.15s',
            }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = '#6d28d9'; e.currentTarget.style.color = '#6d28d9'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = '#e2e4e9'; e.currentTarget.style.color = '#6b7280'; }}
            >Retake quiz</button>
          </motion.div>
        )}
      </div>
    </div>
  );
}

/* ── Exported composite ─────────────────────────────────────────────────── */
export default function ModuleContent({ module, scenarioDone, quizDone, onScenarioDone, onQuizDone }) {
  return (
    <div>
      {module.content?.length > 0 && (
        <>
          <SectionDivider label="READING"/>
          {module.content.map((sec, i) => (
            <ContentSection key={i} heading={sec.heading} body={sec.body} index={i}/>
          ))}
        </>
      )}
      {module.scenario && (
        <>
          <SectionDivider label="WORKPLACE SCENARIO"/>
          <ScenarioCard scenario={module.scenario} onDone={onScenarioDone} done={scenarioDone}/>
        </>
      )}
      {module.policies?.length > 0 && (
        <>
          <SectionDivider label="POLICY REFERENCES"/>
          <PolicyRefs policies={module.policies}/>
        </>
      )}
      {module.quiz?.length > 0 && (
        <>
          <SectionDivider label="KNOWLEDGE CHECK"/>
          <Quiz questions={module.quiz} onDone={onQuizDone} done={quizDone}/>
        </>
      )}
    </div>
  );
}
