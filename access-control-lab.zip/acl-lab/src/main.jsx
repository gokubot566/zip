import React from 'react';
import { createRoot } from 'react-dom/client';
// Self-hosted fonts (bundled locally for isolated/air-gapped lab networks).
import '@fontsource/inter/400.css';
import '@fontsource/inter/500.css';
import '@fontsource/inter/600.css';
import '@fontsource/inter/700.css';
import '@fontsource/inter/800.css';
import '@fontsource/jetbrains-mono/400.css';
import '@fontsource/jetbrains-mono/500.css';
import '@fontsource/jetbrains-mono/600.css';
import '@fontsource/jetbrains-mono/700.css';
import './index.css';
import App from './App.jsx';
createRoot(document.getElementById('root')).render(<App />);
