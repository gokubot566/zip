/* ============================================================
   scenario.js — content for
   "Access Control & Secure Sharing" (Cyber Range · BSBXCS303)

   Model: a realistic in-browser SSH terminal into FILES01, a
   misconfigured company file server. The trainee runs REAL Linux
   commands to find and fix the permission problems. Byte (the only
   overlay) guides + GATES eight tasks — each must be satisfied by
   live filesystem state before the next unlocks — then shows a
   summary/report card in its own panel.
   ============================================================ */

export const LAB_META = {
  slug: 'access-control-secure-sharing',
  title: 'Access Control & Secure Sharing',
  unit: 'BSBXCS303 · Cyber Range',
  port: 8345,
  storeKey: 'si-access-control-secure-sharing-v1',
  host: 'FILES01',
  ip: '10.50.0.11',
};

/* Shared cast — same ids/colours course-wide; roles re-tagged for a
   Linux file-server / access-control context. (Never use "hannah" as
   a speaker id — the id is "auditor".) */
export const CHARACTERS = {
  elena:   { name: 'Elena Vasquez', role: 'Systems Security Trainer', color: '#6366f1' },
  marcus:  { name: 'Marcus Chen',   role: 'Linux Sysadmin Lead',       color: '#3b82f6' },
  priya:   { name: 'Priya Patel',   role: 'Data Privacy Officer',      color: '#10b981' },
  david:   { name: 'David Okafor',  role: 'Risk & Compliance Officer', color: '#f59e0b' },
  auditor: { name: 'Hannah Wong',   role: 'External Security Auditor',  color: '#06b6d4' },
};

/* The eight gated tasks. `check` names the siteLogic predicate. */
export const TASKS = [
  {
    id: 'recon', n: 1, area: 'Reconnaissance', where: 'recon', speaker: 'marcus',
    threat: 'Unknown exposure',
    brief: "First, get onto the box and see how bad it is. Connect over SSH, confirm who you are, and read an HR file <b>as the student user</b> — you shouldn't be able to, but you can. Then walk the tree and spot the hidden folder.",
    goal: "Log in via SSH, then read /srv/company/hr/confidential.txt as student AND reveal the hidden _backdoor directory (tree or ls -la).",
    hint: "ssh student@10.50.0.11 -p 22 · then: cat /srv/company/hr/confidential.txt · tree /srv/company (look for a name starting with _).",
    successNote: "Confirmed. A plain student can read HR salaries and there's a hidden copy in _backdoor. That's exactly the exposure we're here to close.",
  },
  {
    id: 'crossdept', n: 2, area: 'Cross-department & share leaks', where: 'recon', speaker: 'auditor',
    threat: 'Data readable by everyone',
    brief: "Prove the leak isn't just one path. Read the HR file <b>as the marketing user</b>, then pull it over <b>Samba</b>. Same secret, three different doors — that's how audits fail.",
    goal: "Read the HR confidential file as marketinguser, AND retrieve it via smbclient (get).",
    hint: 'su - marketinguser -c "cat /srv/company/hr/confidential.txt" · then smbclient //127.0.0.1/company -U student%student and inside it: get hr/confidential.txt leaked_smb.txt',
    successNote: "Marketing can read HR, and SMB hands the file to anyone. Every access path is wide open — now we start closing them.",
  },
  {
    id: 'umask', n: 3, area: 'Secure default permissions (umask)', where: 'fix', speaker: 'elena',
    threat: 'New files born world-readable',
    brief: "The reason this keeps happening: the system <b>umask is 000</b>, so every new file is created 666 (everyone can read). Back up the config, set a secure <b>umask 007</b>, and reload it.",
    goal: "Change the system umask to 007 (edit /etc/bash.bashrc and source it, or set it in the shell) so the live umask is 0007.",
    hint: "sudo cp /etc/bash.bashrc /etc/bash.bashrc.bak · sudo sed is fine, or: echo \"umask 007\" | sudo tee -a /etc/bash.bashrc · source /etc/bash.bashrc · check with: umask",
    successNote: "umask is 0007 now — new files land owner+group only. You've stopped the bleeding before fixing the wound.",
  },
  {
    id: 'backdoor', n: 4, area: 'Neutralize the backdoor', where: 'fix', speaker: 'david',
    threat: 'Hidden copy of HR data',
    brief: "Kill the hidden leak. Take ownership of <b>/srv/company/_backdoor</b>, wipe the copied files inside, and lock the directory down so it can't be used again.",
    goal: "Empty the _backdoor directory (remove the copied files) and restrict it (chmod 700 or 000, owned by root).",
    hint: "sudo chown root:root /srv/company/_backdoor · sudo chmod 700 /srv/company/_backdoor · sudo rm -rf /srv/company/_backdoor/* · sudo chmod 000 /srv/company/_backdoor",
    successNote: "Backdoor emptied and sealed. The forgotten copy of HR salaries is gone for good.",
  },
  {
    id: 'baseline', n: 5, area: 'Reset ownership & base permissions', where: 'fix', speaker: 'marcus',
    threat: 'Inconsistent, over-open perms',
    brief: "Start from a clean slate. Strip any old ACLs, then give each department folder the right <b>group owner</b> and a strict base mode. HR, Marketing and IT should be <b>750</b>; leave the world with nothing.",
    goal: "Set group ownership (hr→hr, marketing→marketing, it→it) and chmod 750 on all three department folders. Clear stale ACLs first.",
    hint: "sudo setfacl -b -R /srv/company · sudo chown -R root:hr /srv/company/hr (repeat for marketing, it) · sudo chmod 750 /srv/company/hr (and marketing, it).",
    successNote: "Clean baseline: each folder owned by its department group, 750, others locked out. Now the fine-grained rules go on top.",
  },
  {
    id: 'hracl', n: 6, area: 'POSIX ACLs — HR folder', where: 'fix', speaker: 'priya',
    threat: 'IT needs read-only, not full access',
    brief: "The hard part. Basic perms can't say “HR read/write, IT read-<b>only</b>, everyone else nothing” at once — that needs <b>ACLs</b>. Apply them to HR, with inheritance so new files stay protected.",
    goal: "On /srv/company/hr set ACLs: group hr = rwX, group it = r-X (read-only), other = --- (with default/-d entries for inheritance).",
    hint: "sudo setfacl -R -m g:hr:rwX /srv/company/hr · sudo setfacl -R -m d:g:hr:rwX /srv/company/hr · same for g:it:r-X (access + d:) · sudo setfacl -R -m g:marketing:--- /srv/company/hr · o::--- and d:o::---",
    successNote: "Perfect — HR manages their data, IT can audit without changing anything, nobody else gets in. That's a real-world access model.",
  },
  {
    id: 'otheracl', n: 7, area: 'ACLs — Marketing, IT & Shared', where: 'fix', speaker: 'auditor',
    threat: 'Remaining folders unprotected',
    brief: "Extend the model. Give <b>Marketing</b> full access to Marketing, <b>IT</b> full access to IT, and let <b>all staff</b> share the Shared folder — each with others locked out and inheritance on.",
    goal: "Apply ACLs: marketing folder → g:marketing:rwX (+default), other ---; it folder → g:it:rwX (+default), other ---; shared folder → g:staff:rwX (+default).",
    hint: "sudo setfacl -R -m g:marketing:rwX,d:g:marketing:rwX /srv/company/marketing (o::---) · same shape for g:it on /it · sudo setfacl -R -m g:staff:rwX,d:g:staff:rwX /srv/company/shared",
    successNote: "Every department is now isolated to its own data and Shared works for all staff. The access model is complete.",
  },
  {
    id: 'validate', n: 8, area: 'Final validation', where: 'validate', speaker: 'elena',
    threat: 'Unverified fix = no fix',
    brief: "Last step — prove it. Confirm <b>no world-readable files remain</b> under /srv/company, and check that the doors you closed really are closed (try reading HR as marketing — it should fail).",
    goal: "Run: find /srv/company -perm -o+r (returns no HR/dept files) AND confirm marketinguser is denied on the HR folder.",
    hint: 'find /srv/company -perm -o+r  (should list nothing sensitive) · su - marketinguser -c "ls /srv/company/hr"  (should say Permission denied).',
    successNote: "Verified. No world-readable secrets, cross-department access denied. The server is secured — audit-ready.",
  },
];

export const TASK_ORDER = TASKS.map((t) => t.id);

export const BYTE_INTRO = {
  speaker: 'elena',
  lines: [
    { s: 'elena', t: "Hi, I'm Byte — your guide for this access-control lab. 👋 I live in this panel and I'll walk you through every step, so you're never stuck." },
    { s: 'elena', t: "You've been brought in as a new IT support tech at a company whose file server, FILES01, is a mess. Meet the team you'll hear from:" },
    { s: 'elena', t: "I'm Elena, Systems Security Trainer — I cover umask and final validation." },
    { s: 'marcus', t: "Marcus, Linux Sysadmin Lead. Recon and the ownership/permission reset are mine." },
    { s: 'priya', t: "I'm Priya, Data Privacy Officer — the HR data is my responsibility, so I'll drive the HR ACLs." },
    { s: 'david', t: "David, Risk & Compliance. I care about that hidden backdoor and where copies of PII end up." },
    { s: 'auditor', t: "And I'm Hannah, the external auditor. I'll show you the share leaks and check the other folders." },
    { s: 'elena', t: "Everything happens in the terminal on the left — real commands, real results. Before you change anything, have a look around and see how exposed this box is." },
  ],
};

export const EXPLORE_STEP = {
  speaker: 'elena',
  title: 'Get your bearings first',
  body: "The terminal on the left is a live SSH session into FILES01. Nothing you type here can break anything for real — try a few recon commands and get a feel for how open this server is before we start locking it down.",
  suggestions: [
    { cmd: 'ip a', label: 'ip a', note: 'Find the server\'s IP address (eth0)' },
    { cmd: 'ssh student@10.50.0.11 -p 22', label: 'ssh student@10.50.0.11 -p 22', note: 'Connect to the lab VM (password: student)' },
    { cmd: 'id', label: 'id', note: 'See which user and groups you are' },
    { cmd: 'ls -la /srv/company', label: 'ls -la /srv/company', note: 'List the shared company folders + perms' },
    { cmd: 'tree /srv/company', label: 'tree /srv/company', note: 'See the whole structure (spot anything hidden?)' },
  ],
  cta: "OK, I've looked around — start the tasks",
};

export const WHY_IT_MATTERS =
  "Most real breaches of sensitive data don't come from clever exploits — they come from a folder set to 777, a forgotten backup copy, or a network share that never had its permissions checked. The exact routine you run on FILES01 is what sysadmins use to protect HR, finance and customer data every day.";

export const LEARNING_OUTCOMES = [
  'Detect misconfigured file-share permissions across multiple access paths.',
  'Apply least-privilege access control with UNIX permissions and ownership.',
  'Use POSIX ACLs for role-based access basic permissions can\'t express.',
  'Secure default permissions with a sensible umask.',
  'Find and neutralise hidden copies of sensitive data.',
  'Validate access restrictions as different users before signing off.',
];

export const SUMMARY = {
  passTitle: 'Server secured — audit-ready',
  passBody:
    "You found the exposure across the local filesystem and the Samba share, stopped new files leaking with a secure umask, destroyed the hidden backdoor, reset ownership and base permissions to a clean 750 baseline, then layered POSIX ACLs so HR keep control, IT get read-only audit access, and every department is isolated — and you validated the lot. That's a complete access-control hardening, start to finish.",
  outcomesTitle: 'What you practised',
};

export const DISCLAIMER =
  'Training simulation. FILES01, “Riverton” staff records, and all users, files and network shares shown are fictional and run entirely offline inside your browser — no real systems are touched. Built for the Cyber Range unit “Securely manage PII and workplace information” (BSBXCS303).';

/* Reference command sheet shown in Byte's Commands tab. */
export const COMMAND_REF = [
  { grp: 'Recon', items: ['ip a', 'whoami / id / groups', 'ls -la <dir>', 'tree <dir>', 'find <dir> -perm -o+r', 'cat <file>'] },
  { grp: 'Users', items: ['su - <user>', 'su - <user> -c "<cmd>"', 'exit'] },
  { grp: 'Permissions', items: ['chmod [-R] <mode> <path>', 'chown [-R] <own>:<grp> <path>', 'umask [mask]'] },
  { grp: 'POSIX ACLs', items: ['getfacl [-R] <path>', 'setfacl -b -R <path>', 'setfacl [-R] -m <spec> <path>', 'd: prefix = default/inherited'] },
  { grp: 'Shares', items: ['smbclient //127.0.0.1/company -U u%p', 'mount -t nfs4 127.0.0.1:/srv/company /mnt/tmp_nfs'] },
];
