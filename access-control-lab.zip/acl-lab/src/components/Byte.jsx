import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  TASKS, TASK_ORDER, CHARACTERS, BYTE_INTRO, EXPLORE_STEP, WHY_IT_MATTERS,
  LEARNING_OUTCOMES, SUMMARY, DISCLAIMER, COMMAND_REF, LAB_META,
} from '../data/scenario.js';
import { CastPhoto } from './Cast.jsx';
import { ByteAvatar } from './ByteAvatar.jsx';
import {
  ChevronRight, Check, Lock, Lightbulb, ArrowRight, ArrowLeft, X, Terminal as TermIcon,
  RotateCcw, Trophy, GripHorizontal, Compass, Play, ListChecks, BookOpen,
  AlertTriangle, RefreshCw, Info, ChevronDown,
} from 'lucide-react';

const GAP = 16;
const LAUNCHER = 64;

/* Byte — the only lab overlay. Draggable + edge-snapping, floats over
   the whole terminal desktop. Intros the scenario, GATES the 8 tasks
   (next unlocks only when the live shell state satisfies the goal),
   offers a command reference, a "run in terminal" shortcut, a Restart
   Container control, and the final report card. */
export default function Byte({
  state, patch, reset, restartContainer, activeTask, activeDone, advance, goBack,
  allDone, insertCommand,
}) {
  const open = state.byteOpen;
  const [showHint, setShowHint] = useState(false);
  const [tab, setTab] = useState('guide'); // guide | commands
  useEffect(() => { setShowHint(false); }, [activeTask?.id]);

  const doneCount = TASK_ORDER.filter((id) => state.completed[id]).length;
  const speaker = allDone ? 'elena' : (activeTask?.speaker || 'elena');

  // --- task navigation flags ---
  // A task counts as "cleared" if the live shell satisfies it now OR it was
  // already locked in earlier (so a Restart Container that wipes the shell
  // doesn't strip the Next button when reviewing a past task).
  const activeCleared = !!(activeTask && (activeDone || state.completed[activeTask.id]));
  const canGoBack = state.currentTask > 0;                 // a previous task exists to review
  const canGoNext = activeCleared;                          // move forward once this task is cleared
  const isReviewing = !!(activeTask && state.completed[activeTask.id]); // sitting on an already-completed task

  // ---- draggable / edge-snapping positioning ----
  const wRef = useRef(null);
  const [edge, setEdge] = useState('right');
  const [vRatio, setVRatio] = useState(0.5);
  const [winSize, setWinSize] = useState({ w: window.innerWidth, h: window.innerHeight });
  const dragging = useRef(false);
  const shouldAnimateRef = useRef(false);
  const dragData = useRef(null);

  const snapToEdge = useCallback((animate, forceEdge) => {
    const w = wRef.current; if (!w) return;
    const curEdge = forceEdge || edge;
    if (forceEdge && forceEdge !== edge) setEdge(forceEdge);
    const vw = window.innerWidth, vh = window.innerHeight;
    const wH = w.offsetHeight || (open ? 520 : LAUNCHER);
    const rawTop = vRatio * vh - wH / 2;
    const maxTop = vh - wH - GAP;
    const top = maxTop <= GAP ? GAP : Math.max(GAP, Math.min(rawTop, maxTop));
    const targetLeft = curEdge === 'left' ? GAP : vw - w.offsetWidth - GAP;
    w.style.transition = animate ? 'left .28s ease, top .28s ease' : 'none';
    w.style.left = targetLeft + 'px';
    w.style.top = top + 'px';
    w.style.right = 'auto';
    w.style.bottom = 'auto';
    window.clearTimeout(w._lockT);
    w._lockT = window.setTimeout(() => {
      if (!wRef.current) return;
      const el = wRef.current;
      el.style.transition = 'none';
      if (curEdge === 'left') { el.style.left = GAP + 'px'; el.style.right = 'auto'; }
      else { el.style.left = 'auto'; el.style.right = GAP + 'px'; }
    }, animate ? 300 : 0);
  }, [edge, vRatio, open]);

  useEffect(() => {
    const onResize = () => setWinSize({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  useEffect(() => {
    if (dragging.current) return;
    const animate = shouldAnimateRef.current;
    shouldAnimateRef.current = false;
    snapToEdge(animate);
  }, [open, edge, vRatio, winSize, snapToEdge, state.introSeen, state.exploreSeen, state.currentTask, allDone, tab, showHint]);

  const onDragStart = (e) => {
    const w = wRef.current; if (!w) return;
    const pt = e.touches ? e.touches[0] : e;
    const rect = w.getBoundingClientRect();
    dragging.current = true;
    dragData.current = { offX: pt.clientX - rect.left, offY: pt.clientY - rect.top };
    w.style.transition = 'none';
    document.addEventListener('mousemove', onDragMove);
    document.addEventListener('mouseup', onDragEnd);
    document.addEventListener('touchmove', onDragMove, { passive: false });
    document.addEventListener('touchend', onDragEnd);
    e.preventDefault();
  };
  const onDragMove = (e) => {
    const w = wRef.current; if (!w || !dragging.current) return;
    if (e.cancelable) e.preventDefault();
    const pt = e.touches ? e.touches[0] : e;
    w.style.left = (pt.clientX - dragData.current.offX) + 'px';
    w.style.top = (pt.clientY - dragData.current.offY) + 'px';
    w.style.right = 'auto';
    w.style.bottom = 'auto';
  };
  const onDragEnd = () => {
    const w = wRef.current;
    document.removeEventListener('mousemove', onDragMove);
    document.removeEventListener('mouseup', onDragEnd);
    document.removeEventListener('touchmove', onDragMove);
    document.removeEventListener('touchend', onDragEnd);
    if (!w) { dragging.current = false; return; }
    const rect = w.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const newEdge = centerX < window.innerWidth / 2 ? 'left' : 'right';
    setVRatio(Math.max(0, Math.min(1, rect.top / window.innerHeight)));
    dragging.current = false;
    snapToEdge(true, newEdge);
  };

  return (
    <>
      <style>{BYTE_CSS}</style>
      <div className={`byte-root ${open ? 'is-open' : ''}`} ref={wRef}>
        {!open && (
          <button className="byte-launcher" onMouseDown={onDragStart} onTouchStart={onDragStart}
            onClick={() => { if (!dragData.current || !dragging.current) { shouldAnimateRef.current = true; patch({ byteOpen: true }); } }}
            title="Open Byte (drag to move)">
            <ByteAvatar size={54} speaking />
            {!allDone && <span className="byte-launch-badge">{doneCount}/{TASK_ORDER.length}</span>}
          </button>
        )}

        {open && (
          <div className="byte-panel">
            <div className="byte-head" onMouseDown={onDragStart} onTouchStart={onDragStart}>
              <ByteAvatar size={40} speaking />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="byte-title">Byte · Lab Guide</div>
                <div className="byte-sub">{allDone ? 'Lab complete' : `Task ${activeTask?.n} of ${TASK_ORDER.length} · ${CHARACTERS[speaker].name}`}</div>
              </div>
              <span className="byte-grip" title="Drag to move"><GripHorizontal size={16} /></span>
              <button className="byte-x" onClick={() => { shouldAnimateRef.current = true; patch({ byteOpen: false }); }}><X size={17} /></button>
            </div>

            <div className="byte-progress">
              {TASK_ORDER.map((id, i) => {
                const done = state.completed[id];
                const cur = !allDone && i === state.currentTask;
                return <span key={id} className={`byte-pip ${done ? 'done' : cur ? 'cur' : ''}`} />;
              })}
            </div>

            {!state.introSeen ? (
              <Intro onStart={() => patch({ introSeen: true })} />
            ) : !state.exploreSeen ? (
              <ExploreStep insertCommand={insertCommand} onStart={() => patch({ exploreSeen: true })} />
            ) : allDone ? (
              <Summary reset={reset} />
            ) : (
              <>
                <div className="byte-tabs">
                  <button className={tab === 'guide' ? 'on' : ''} onClick={() => setTab('guide')}><ListChecks size={13} /> Current task</button>
                  <button className={tab === 'commands' ? 'on' : ''} onClick={() => setTab('commands')}><BookOpen size={13} /> Commands</button>
                </div>

                <div className="byte-body">
                  {tab === 'guide' && activeTask && (
                    <div className="byte-fade">
                      <div className="byte-area">Task {activeTask.n} · {activeTask.area}</div>
                      <div className="byte-speaker">
                        <CastPhoto id={activeTask.speaker} size={30} speaking />
                        <span>{CHARACTERS[activeTask.speaker].name} · {CHARACTERS[activeTask.speaker].role}</span>
                      </div>
                      <p className="byte-brief" dangerouslySetInnerHTML={{ __html: activeTask.brief }} />

                      <div className="byte-goal">
                        <div className="byte-goal-label">Your task</div>
                        {activeTask.goal}
                      </div>

                      <button className="byte-hint-toggle" onClick={() => setShowHint((h) => !h)}>
                        <Lightbulb size={14} /> {showHint ? 'Hide commands' : 'Show the commands'}
                      </button>
                      {showHint && <HintBlock task={activeTask} insertCommand={insertCommand} />}

                      <div className={`byte-status ${activeDone ? 'ok' : ''}`}>
                        {activeDone
                          ? <><Check size={16} /> {activeTask.successNote}</>
                          : <><Lock size={15} /> Complete this in the terminal to unlock the next task.</>}
                      </div>

                      {isReviewing && (
                        <div className="byte-review-note">
                          <RotateCcw size={13} /> You're reviewing an earlier task — your progress is saved.
                        </div>
                      )}

                      <div className="byte-nav">
                        {canGoBack && (
                          <button className="byte-back" onClick={goBack}>
                            <ArrowLeft size={16} /> Back
                          </button>
                        )}
                        <button className="byte-next" disabled={!canGoNext} onClick={advance} style={canGoBack ? { marginTop: 0 } : undefined}>
                          {canGoNext ? <>Next task <ArrowRight size={16} /></> : <>Locked <Lock size={15} /></>}
                        </button>
                      </div>
                    </div>
                  )}

                  {tab === 'commands' && (
                    <div className="byte-fade">
                      <p className="byte-why">{WHY_IT_MATTERS}</p>
                      <p className="byte-cmdref-tip">
                        <Info size={13} /> Tap the <b>ⓘ</b> on any command to see what it does and an example. Tap the command text itself to drop it straight into the terminal.
                      </p>
                      <div className="byte-cmdref">
                        {COMMAND_REF.map((grp) => (
                          <div key={grp.grp} className="byte-cmdgrp">
                            <div className="byte-cmdgrp-title">{grp.grp}</div>
                            {grp.items.map((it) => (
                              <CommandRow key={it.cmd} item={it} insertCommand={insertCommand} />
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}

            {/* footer: container controls (always available) */}
            <div className="byte-foot">
              <button className="byte-foot-btn" onClick={restartContainer} title="Re-seed the lab to its broken starting state">
                <RefreshCw size={13} /> Restart container
              </button>
              <span className="byte-foot-host">{LAB_META.host} · {LAB_META.ip}</span>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

/* Renders the full, step-by-step walkthrough for a task. Prefers the
   structured `steps` array (numbered command + what-it-does + why-it-matters,
   no lines skipped); falls back to the legacy `hint` string if a task has
   no steps defined. */
function HintBlock({ task, insertCommand }) {
  if (task && Array.isArray(task.steps) && task.steps.length) {
    return (
      <div className="byte-steps">
        <div className="byte-steps-head">
          <ListChecks size={13} /> Step-by-step — every command explained
        </div>
        {task.steps.map((s, i) => (
          <div key={i} className="byte-step">
            <div className="byte-step-num">{i + 1}</div>
            <div className="byte-step-main">
              <code className="byte-hint-cmd" onClick={() => insertCommand(s.cmd)} title="Click to put this command in the terminal">
                <Play size={11} /> {s.cmd}
              </code>
              {s.what && (
                <p className="byte-step-what"><span className="byte-step-tag">What it does</span> {s.what}</p>
              )}
              {s.why && (
                <p className="byte-step-why"><span className="byte-step-tag why">Why it matters</span> {s.why}</p>
              )}
            </div>
          </div>
        ))}
        <p className="byte-steps-tip">Click any command to drop it into the terminal, then press Enter. Run them in order — don't skip a line.</p>
      </div>
    );
  }

  // legacy fallback: split the hint string on "·"
  const parts = (task?.hint || '').split('·').map((s) => s.trim()).filter(Boolean);
  return (
    <div className="byte-hint">
      {parts.map((p, i) => {
        const cmd = extractCmd(p);
        return (
          <div key={i} className="byte-hint-row">
            {cmd
              ? <code className="byte-hint-cmd" onClick={() => insertCommand(cmd)} title="Click to put in terminal"><Play size={11} /> {cmd}</code>
              : <span className="byte-hint-note">{p}</span>}
          </div>
        );
      })}
    </div>
  );
}

function firstCmd(s) {
  // strip descriptive parens/placeholders for a runnable-ish stub
  return s.replace(/\s*\(.*?\)\s*/g, ' ').trim();
}

/* A single row in the Commands reference tab. Shows the command as a
   clickable chip (click text -> drop into terminal) plus an ⓘ toggle
   that expands a plain-English description and a copyable example. */
function CommandRow({ item, insertCommand }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`byte-cmdrow ${open ? 'open' : ''}`}>
      <div className="byte-cmdrow-head">
        <code className="byte-cmd" onClick={() => insertCommand(firstCmd(item.cmd))} title="Click to put in terminal">
          {item.cmd}
        </code>
        <button
          className="byte-cmd-info"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          title={open ? 'Hide explanation' : 'What does this do?'}
        >
          <Info size={14} />
          <ChevronDown size={13} className="byte-cmd-chev" />
        </button>
      </div>
      {open && (
        <div className="byte-cmd-detail byte-fade">
          <p className="byte-cmd-desc">{item.desc}</p>
          {item.example && (
            <div className="byte-cmd-example">
              <span className="byte-cmd-example-tag">Example</span>
              <code onClick={() => insertCommand(firstCmd(item.example))} title="Click to put in terminal">
                <Play size={10} /> {item.example}
              </code>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function extractCmd(p) {
  // Heuristic: treat as a command if it starts with a known verb
  const verbs = /^(ssh|ip|whoami|id|groups|ls|tree|find|cat|cd|pwd|su|sudo|chmod|chown|umask|getfacl|setfacl|touch|mkdir|rm|echo|cp|source|smbclient|mount|exit|get)\b/;
  const cleaned = p.replace(/\s*\(.*?\)\s*/g, ' ').trim();
  return verbs.test(cleaned) ? cleaned : null;
}

function Intro({ onStart }) {
  const [shown, setShown] = useState(1);
  const lines = BYTE_INTRO.lines;
  const endRef = useRef(null);
  const allShown = shown >= lines.length;
  useEffect(() => {
    if (shown >= lines.length) return;
    const t = setTimeout(() => setShown((n) => n + 1), 950);
    return () => clearTimeout(t);
  }, [shown, lines.length]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, [shown]);
  return (
    <div className="byte-body">
      <div className="byte-area">👋 Meet your guide & team</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, margin: '4px 0 14px' }}>
        {lines.slice(0, shown).map((ln, i) => (
          <div key={i} className="byte-fade" style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <CastPhoto id={ln.s} size={30} speaking={i === shown - 1} />
            <div>
              <div className="byte-line-name" style={{ color: CHARACTERS[ln.s].color }}>{i === 0 ? 'Byte' : CHARACTERS[ln.s].name}</div>
              <div className="byte-line-bubble">{ln.t}</div>
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>
      {!allShown && <button className="byte-hint-toggle" onClick={() => setShown(lines.length)}>Skip introductions</button>}
      {allShown && <button className="byte-next byte-fade" onClick={onStart} style={{ marginTop: 8 }}>Let’s look around FILES01 <ArrowRight size={16} /></button>}
    </div>
  );
}

function ExploreStep({ insertCommand, onStart }) {
  return (
    <div className="byte-body byte-fade">
      <div className="byte-area"><Compass size={13} style={{ verticalAlign: '-2px', marginRight: 4 }} /> Explore first</div>
      <div className="byte-speaker">
        <CastPhoto id={EXPLORE_STEP.speaker} size={30} speaking />
        <span>Byte · your guide</span>
      </div>
      <p className="byte-brief">{EXPLORE_STEP.body}</p>
      <div className="byte-explore-list">
        {EXPLORE_STEP.suggestions.map((s) => (
          <button key={s.cmd} className="byte-explore-item" onClick={() => insertCommand(s.cmd)}>
            <div>
              <code className="byte-explore-cmd">{s.label}</code>
              <div className="byte-explore-note">{s.note}</div>
            </div>
            <Play size={15} />
          </button>
        ))}
      </div>
      <p className="byte-explore-tip">Tip: clicking a command drops it into the terminal — just press Enter.</p>
      <button className="byte-next" onClick={onStart} style={{ marginTop: 12 }}>{EXPLORE_STEP.cta} <ArrowRight size={16} /></button>
    </div>
  );
}

function Summary({ reset }) {
  return (
    <div className="byte-body byte-fade">
      <div className="byte-trophy"><Trophy size={30} color="#04140d" /></div>
      <div className="byte-area" style={{ textAlign: 'center', color: 'var(--good)' }}>All eight secured</div>
      <h3 className="byte-summary-title">{SUMMARY.passTitle}</h3>
      <p className="byte-summary-body">{SUMMARY.passBody}</p>

      <div className="byte-report">
        <div className="byte-report-head">Report card</div>
        {TASKS.map((t) => (
          <div key={t.id} className="byte-report-row">
            <Check size={15} color="var(--good)" />
            <div>
              <div className="byte-report-area">{t.area}</div>
              <div className="byte-report-threat">{t.threat} — resolved</div>
            </div>
          </div>
        ))}
      </div>

      <div className="byte-outcomes-title">{SUMMARY.outcomesTitle}</div>
      <ul className="byte-outcomes">
        {LEARNING_OUTCOMES.map((o, i) => <li key={i}><Check size={13} color="var(--good)" /> {o}</li>)}
      </ul>

      <div className="byte-cast-row">
        {['elena', 'marcus', 'priya', 'david', 'auditor'].map((id) => <CastPhoto key={id} id={id} size={34} />)}
      </div>
      <p className="byte-team-note">Your security team — nicely done.</p>

      <button className="byte-next ghost" onClick={reset}><RotateCcw size={15} /> Restart lab</button>
      <p className="byte-disclaimer">{DISCLAIMER}</p>
    </div>
  );
}

const BYTE_CSS = `
.byte-root{position:fixed;top:50vh;right:16px;z-index:400;width:auto}
.byte-root.is-open{width:400px;max-width:calc(100vw - 32px)}
.byte-launcher{position:relative;z-index:400;border:none;background:transparent;cursor:grab;padding:0;border-radius:50%;filter:drop-shadow(0 8px 24px rgba(0,0,0,.5));touch-action:none}
.byte-launcher:active{cursor:grabbing}
.byte-launch-badge{position:absolute;bottom:-2px;right:-4px;background:var(--accent);color:#fff;font-size:11px;font-weight:800;border-radius:999px;padding:2px 7px;border:2px solid var(--bg-0)}
.byte-panel{position:relative;z-index:400;width:400px;max-width:calc(100vw - 32px);max-height:calc(100vh - 32px);display:flex;flex-direction:column;background:var(--bg-1);border:1px solid var(--line-2);border-radius:16px;box-shadow:0 24px 70px rgba(0,0,0,.6);overflow:hidden;animation:byteIn .2s ease}
@keyframes byteIn{from{opacity:0;transform:translateY(18px) scale(.98)}to{opacity:1;transform:none}}
.byte-head{display:flex;align-items:center;gap:11px;padding:13px 14px;background:linear-gradient(135deg,rgba(99,102,241,.2),rgba(6,182,212,.06));border-bottom:1px solid var(--line);cursor:grab;user-select:none;touch-action:none}
.byte-head:active{cursor:grabbing}
.byte-grip{color:var(--txt-3);display:grid;place-items:center;flex-shrink:0}
.byte-title{font-size:13.5px;font-weight:800}
.byte-sub{font-size:11.5px;color:var(--txt-2);margin-top:1px}
.byte-x{border:none;background:transparent;color:var(--txt-2);cursor:pointer;width:30px;height:30px;border-radius:8px;display:grid;place-items:center}
.byte-x:hover{background:var(--bg-3);color:var(--txt-0)}
.byte-progress{display:flex;gap:4px;padding:11px 14px 0}
.byte-pip{flex:1;height:5px;border-radius:999px;background:var(--bg-4)}
.byte-pip.done{background:var(--good)}
.byte-pip.cur{background:var(--accent)}
.byte-tabs{display:flex;gap:4px;padding:12px 14px 0}
.byte-tabs button{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;padding:8px;border:none;border-radius:8px;background:var(--bg-3);color:var(--txt-2);font-weight:700;font-size:12.5px;cursor:pointer}
.byte-tabs button.on{background:var(--accent-soft);color:var(--txt-0)}
.byte-body{padding:14px;overflow-y:auto;flex:1 1 auto;min-height:0}
.byte-fade{animation:fadeUp .25s ease both}
.byte-area{font-size:11px;font-weight:800;letter-spacing:.8px;text-transform:uppercase;color:var(--accent-2);margin-bottom:8px}
.byte-speaker{display:flex;align-items:center;gap:9px;font-size:12px;color:var(--txt-2);margin-bottom:10px}
.byte-brief{font-size:13.5px;line-height:1.6;color:var(--txt-1);margin:0 0 12px}
.byte-brief b{color:var(--txt-0);font-weight:700}
.byte-explore-list{display:flex;flex-direction:column;gap:7px}
.byte-explore-item{display:flex;align-items:center;justify-content:space-between;gap:10px;width:100%;text-align:left;padding:10px 13px;border-radius:10px;border:1px solid var(--line);background:var(--bg-2);color:var(--txt-1);cursor:pointer;transition:background .14s,border-color .14s}
.byte-explore-item:hover{background:var(--bg-3);border-color:var(--accent)}
.byte-explore-item svg{color:var(--accent-2);flex-shrink:0}
.byte-explore-cmd{font-family:'JetBrains Mono',monospace;font-size:12.5px;color:#7fd1ff;font-weight:600}
.byte-explore-note{font-size:11.5px;color:var(--txt-3);margin-top:3px;font-family:var(--font)}
.byte-explore-tip{font-size:11px;color:var(--txt-3);margin:10px 2px 0;font-style:italic}
.byte-goal{background:var(--bg-3);border:1px solid var(--line);border-left:3px solid var(--accent);border-radius:8px;padding:11px 13px;font-size:13px;color:var(--txt-1);line-height:1.5}
.byte-goal-label{font-size:10.5px;font-weight:800;letter-spacing:.6px;text-transform:uppercase;color:var(--accent);margin-bottom:4px}
.byte-hint-toggle{display:inline-flex;align-items:center;gap:7px;margin-top:11px;background:transparent;border:none;color:var(--accent-2);font-weight:600;font-size:12.5px;cursor:pointer;padding:0}
.byte-hint{margin-top:10px;background:rgba(6,182,212,.06);border:1px solid rgba(6,182,212,.2);border-radius:8px;padding:10px;display:flex;flex-direction:column;gap:6px}
.byte-hint-row{display:flex}
.byte-hint-cmd{display:inline-flex;align-items:center;gap:7px;font-family:'JetBrains Mono',monospace;font-size:12px;color:#8fe0b0;background:rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.08);border-radius:6px;padding:6px 9px;cursor:pointer;width:100%;line-height:1.4;word-break:break-all;transition:border-color .14s,background .14s}
.byte-hint-cmd:hover{border-color:var(--good);background:rgba(0,0,0,.5)}
.byte-hint-cmd svg{color:var(--good);flex-shrink:0}
.byte-hint-note{font-size:12px;color:var(--txt-2);line-height:1.5;padding:2px 0}
.byte-steps{margin-top:10px;display:flex;flex-direction:column;gap:10px}
.byte-steps-head{display:flex;align-items:center;gap:7px;font-size:11px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;color:var(--accent-2)}
.byte-steps-head svg{flex-shrink:0}
.byte-step{display:flex;gap:10px;align-items:flex-start;background:var(--bg-2);border:1px solid var(--line);border-radius:10px;padding:10px 11px}
.byte-step-num{flex-shrink:0;width:20px;height:20px;border-radius:50%;background:var(--accent);color:#fff;font-size:11.5px;font-weight:800;display:grid;place-items:center;margin-top:1px}
.byte-step-main{flex:1;min-width:0;display:flex;flex-direction:column;gap:7px}
.byte-step-main .byte-hint-cmd{margin:0}
.byte-step-what,.byte-step-why{margin:0;font-size:12px;line-height:1.5;color:var(--txt-1)}
.byte-step-why{color:var(--txt-2)}
.byte-step-tag{display:inline-block;font-size:9.5px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;color:var(--accent-2);background:var(--accent-soft);border-radius:4px;padding:1px 6px;margin-right:6px;vertical-align:1px}
.byte-step-tag.why{color:var(--warn);background:rgba(245,158,11,.12)}
.byte-steps-tip{font-size:11px;color:var(--txt-3);margin:2px 2px 0;font-style:italic;line-height:1.5}
.byte-status{display:flex;align-items:flex-start;gap:8px;margin-top:14px;padding:11px 13px;border-radius:8px;font-size:12.5px;line-height:1.5;background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.22);color:var(--warn)}
.byte-status.ok{background:rgba(16,185,129,.08);border-color:rgba(16,185,129,.25);color:var(--good)}
.byte-status svg{flex-shrink:0;margin-top:1px}
.byte-next{width:100%;margin-top:14px;display:flex;align-items:center;justify-content:center;gap:8px;padding:12px;border:none;border-radius:10px;background:var(--accent);color:#fff;font-weight:700;font-size:14px;cursor:pointer}
.byte-next:hover:not(:disabled){filter:brightness(1.08)}
.byte-next:disabled{background:var(--bg-4);color:var(--txt-3);cursor:not-allowed}
.byte-next.ghost{background:transparent;border:1px solid var(--line-2);color:var(--txt-1)}
.byte-nav{display:flex;gap:8px;margin-top:14px;align-items:stretch}
.byte-nav .byte-next{margin-top:0;flex:1}
.byte-back{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:12px 14px;border:1px solid var(--line-2);border-radius:10px;background:var(--bg-3);color:var(--txt-1);font-weight:700;font-size:14px;cursor:pointer;flex-shrink:0;transition:background .14s,border-color .14s}
.byte-back:hover{background:var(--bg-4);border-color:var(--accent);color:var(--txt-0)}
.byte-back svg{color:var(--accent-2)}
.byte-review-note{display:flex;align-items:center;gap:8px;margin-top:12px;padding:9px 12px;border-radius:8px;font-size:12px;line-height:1.4;background:var(--accent-soft);border:1px solid rgba(99,102,241,.3);color:var(--txt-1)}
.byte-review-note svg{color:var(--accent-2);flex-shrink:0}
.byte-why{font-size:12.5px;color:var(--txt-2);line-height:1.6;margin:0 0 14px}
.byte-cmdref{display:flex;flex-direction:column;gap:12px}
.byte-cmdgrp-title{font-size:11px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;color:var(--accent-2);margin-bottom:6px}
.byte-cmd{display:block;font-family:'JetBrains Mono',monospace;font-size:12px;color:#c9d6e3;background:var(--bg-2);border:1px solid var(--line);border-radius:6px;padding:7px 10px;margin-bottom:5px;cursor:pointer;transition:border-color .14s,color .14s;word-break:break-all}
.byte-cmd:hover{border-color:var(--accent);color:#7fd1ff}
.byte-cmdref-tip{display:flex;align-items:flex-start;gap:8px;font-size:11.5px;line-height:1.5;color:var(--txt-2);background:var(--accent-soft);border:1px solid rgba(99,102,241,.28);border-radius:8px;padding:9px 11px;margin:0 0 14px}
.byte-cmdref-tip svg{color:var(--accent-2);flex-shrink:0;margin-top:1px}
.byte-cmdref-tip b{color:var(--txt-0)}
.byte-cmdrow{margin-bottom:6px}
.byte-cmdrow-head{display:flex;align-items:stretch;gap:6px}
.byte-cmdrow-head .byte-cmd{flex:1;margin-bottom:0}
.byte-cmd-info{flex-shrink:0;display:inline-flex;align-items:center;gap:2px;padding:0 8px;border-radius:6px;border:1px solid var(--line);background:var(--bg-2);color:var(--txt-2);cursor:pointer;transition:border-color .14s,color .14s,background .14s}
.byte-cmd-info:hover{border-color:var(--accent-2);color:var(--accent-2);background:var(--bg-3)}
.byte-cmd-chev{transition:transform .18s ease}
.byte-cmdrow.open .byte-cmd-info{border-color:var(--accent-2);color:var(--accent-2);background:var(--accent-soft)}
.byte-cmdrow.open .byte-cmd-chev{transform:rotate(180deg)}
.byte-cmd-detail{margin-top:6px;background:rgba(6,182,212,.05);border:1px solid rgba(6,182,212,.18);border-radius:8px;padding:10px 12px}
.byte-cmd-desc{margin:0;font-size:12px;line-height:1.55;color:var(--txt-1)}
.byte-cmd-example{margin-top:9px}
.byte-cmd-example-tag{display:inline-block;font-size:9.5px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;color:var(--accent-2);background:var(--accent-soft);border-radius:4px;padding:1px 6px;margin-bottom:5px}
.byte-cmd-example code{display:flex;align-items:center;gap:6px;font-family:'JetBrains Mono',monospace;font-size:11.5px;color:#8fe0b0;background:rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.08);border-radius:6px;padding:6px 9px;cursor:pointer;line-height:1.4;word-break:break-all;transition:border-color .14s,background .14s}
.byte-cmd-example code:hover{border-color:var(--good);background:rgba(0,0,0,.5)}
.byte-cmd-example code svg{color:var(--good);flex-shrink:0}
.byte-line-name{font-size:11.5px;font-weight:700;margin-bottom:3px}
.byte-line-bubble{font-size:13px;line-height:1.5;color:var(--txt-1);background:var(--bg-3);border:1px solid var(--line);border-radius:3px 11px 11px 11px;padding:9px 12px;display:inline-block}
.byte-trophy{width:56px;height:56px;border-radius:50%;background:var(--good);display:grid;place-items:center;margin:4px auto 12px}
.byte-summary-title{font-size:17px;font-weight:800;text-align:center;margin:0 0 8px}
.byte-summary-body{font-size:12.5px;color:var(--txt-2);line-height:1.6;text-align:center;margin:0 0 16px}
.byte-report{background:var(--bg-2);border:1px solid var(--line);border-radius:10px;overflow:hidden;margin-bottom:16px}
.byte-report-head{font-size:11px;font-weight:800;letter-spacing:.6px;text-transform:uppercase;color:var(--txt-3);padding:10px 13px;border-bottom:1px solid var(--line)}
.byte-report-row{display:flex;gap:10px;align-items:center;padding:9px 13px;border-bottom:1px solid var(--line)}
.byte-report-row:last-child{border-bottom:none}
.byte-report-area{font-size:13px;font-weight:600}
.byte-report-threat{font-size:11.5px;color:var(--txt-3)}
.byte-outcomes-title{font-size:12.5px;font-weight:700;margin-bottom:8px}
.byte-outcomes{list-style:none;padding:0;margin:0 0 16px;display:flex;flex-direction:column;gap:6px}
.byte-outcomes li{display:flex;gap:8px;align-items:flex-start;font-size:12.5px;color:var(--txt-1);line-height:1.5}
.byte-outcomes li svg{flex-shrink:0;margin-top:3px}
.byte-cast-row{display:flex;justify-content:center;gap:7px;margin-top:6px}
.byte-team-note{text-align:center;font-size:11.5px;color:var(--txt-3);margin:8px 0 12px}
.byte-disclaimer{font-size:10.5px;color:var(--txt-3);line-height:1.5;text-align:center;margin-top:14px;border-top:1px solid var(--line);padding-top:12px}
.byte-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 14px;border-top:1px solid var(--line);background:var(--bg-0)}
.byte-foot-btn{display:inline-flex;align-items:center;gap:7px;background:var(--bg-3);border:1px solid var(--line-2);color:var(--txt-1);font-size:12px;font-weight:600;padding:7px 12px;border-radius:8px;cursor:pointer}
.byte-foot-btn:hover{background:var(--bg-4);color:var(--txt-0)}
.byte-foot-btn svg{color:var(--accent-2)}
.byte-foot-host{font-family:'JetBrains Mono',monospace;font-size:10.5px;color:var(--txt-3)}
`;
