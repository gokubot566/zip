/* ============================================================
   positioning.mjs — E2E regression test for the Byte overlay's
   layout behaviour. Targets the four known root-cause bugs:

   1. Resize float/disappearance  (widget must stay glued to an edge,
      fully on-screen, after the window is resized — open AND closed)
   2. Drag-release sticking in the middle  (dropping on the SAME side
      must still snap flush to that edge)
   3. Viewport clipping  (on small viewports the widget must stay
      fully within bounds; the closed launcher must not be pushed
      off-screen by phantom panel height)
   4. Edge-relative CSS locking  (after snapping right, the element
      should be pinned via `right`, not a stale `left` pixel value)
   ============================================================ */
import puppeteer from 'puppeteer';
import http from 'http';
import { readFileSync, existsSync, statSync } from 'fs';
import { join, extname } from 'path';

const ROOT = new URL('../build', import.meta.url).pathname;
const CHROME = '/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome';
const PORT = 8901;
const GAP = 16;      // must match Byte.jsx GAP
const TOL = 3;       // px tolerance for sub-pixel / rounding

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.json': 'application/json' };
const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  let fp = join(ROOT, p);
  if (!existsSync(fp) || !statSync(fp).isFile()) fp = join(ROOT, 'index.html');
  res.writeHead(200, { 'Content-Type': MIME[extname(fp)] || 'application/octet-stream' });
  res.end(readFileSync(fp));
});

const results = [];
function check(name, cond, detail = '') {
  results.push({ name, pass: !!cond, detail });
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

// Return the launcher-or-panel rect + which element is present + viewport
async function measure(page) {
  return page.evaluate(() => {
    const panel = document.querySelector('.byte-panel');
    const launcher = document.querySelector('.byte-launcher');
    const root = document.querySelector('.byte-root');
    const el = panel || launcher;
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(root);
    return {
      kind: panel ? 'panel' : 'launcher',
      left: r.left, right: r.right, top: r.top, bottom: r.bottom, width: r.width, height: r.height,
      styleLeft: root.style.left, styleRight: root.style.right, styleTop: root.style.top,
      vw: window.innerWidth, vh: window.innerHeight,
    };
  });
}

async function settle(ms = 650) { await new Promise((r) => setTimeout(r, ms)); }

// helper: robust in-page click by visible text
async function clickText(page, sel, text, tries = 25) {
  for (let i = 0; i < tries; i++) {
    const ok = await page.evaluate((s, t) => {
      for (const el of document.querySelectorAll(s)) {
        const r = el.getBoundingClientRect();
        if (el.textContent && el.textContent.includes(t) && r.width > 0 && r.height > 0 && !el.disabled) { el.click(); return true; }
      }
      return false;
    }, sel, text);
    if (ok) return true;
    await new Promise((r) => setTimeout(r, 150));
  }
  return false;
}

// Drag the panel header from its current center to an absolute (x,y) via real mouse events
async function dragHeaderTo(page, x, y) {
  const box = await page.evaluate(() => {
    const h = document.querySelector('.byte-head') || document.querySelector('.byte-launcher');
    const r = h.getBoundingClientRect();
    return { cx: r.left + r.width / 2, cy: r.top + r.height / 2 };
  });
  await page.mouse.move(box.cx, box.cy);
  await page.mouse.down();
  // move in steps so dragmove handlers fire
  const steps = 8;
  for (let i = 1; i <= steps; i++) {
    await page.mouse.move(box.cx + (x - box.cx) * i / steps, box.cy + (y - box.cy) * i / steps);
    await new Promise((r) => setTimeout(r, 12));
  }
  await page.mouse.up();
}

async function main() {
  await new Promise((r) => server.listen(PORT, r));
  const browser = await puppeteer.launch({ executablePath: CHROME, headless: 'new', args: ['--no-sandbox'] });
  const page = await browser.newPage();
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(e.message));

  await page.setViewport({ width: 1400, height: 900 });
  await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'networkidle0' });
  await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'networkidle0' });
  await settle();

  // ---------------------------------------------------------
  // A. OPEN PANEL — initial snap flush to the right edge
  // ---------------------------------------------------------
  let m = await measure(page);
  check('A1 panel present initially', m.kind === 'panel', m.kind);
  check('A2 panel flush to right edge', Math.abs(m.vw - m.right - GAP) <= TOL, `gap=${(m.vw - m.right).toFixed(1)}`);
  check('A3 panel fully on-screen (top>=GAP, bottom<=vh)', m.top >= GAP - TOL && m.bottom <= m.vh + TOL, `top=${m.top.toFixed(0)} bottom=${m.bottom.toFixed(0)} vh=${m.vh}`);

  // ---------------------------------------------------------
  // B. RESIZE while OPEN — must re-glue to right edge, stay on-screen
  //    (root cause #1: hardcoded left px floated on resize)
  // ---------------------------------------------------------
  await page.setViewport({ width: 980, height: 720 });
  await settle();
  m = await measure(page);
  check('B1 after shrink: still flush right', Math.abs(m.vw - m.right - GAP) <= TOL, `gap=${(m.vw - m.right).toFixed(1)} vw=${m.vw}`);
  check('B2 after shrink: not floating in middle', m.right > m.vw / 2, `right=${m.right.toFixed(0)} vw=${m.vw}`);
  check('B3 after shrink: fully on-screen vertically', m.top >= GAP - TOL && m.bottom <= m.vh + TOL, `top=${m.top.toFixed(0)} bottom=${m.bottom.toFixed(0)}`);
  check('B4 edge-relative lock uses right (left=auto)', m.styleRight && m.styleRight !== 'auto' && (m.styleLeft === 'auto' || m.styleLeft === ''), `left="${m.styleLeft}" right="${m.styleRight}"`);

  // grow again
  await page.setViewport({ width: 1500, height: 950 });
  await settle();
  m = await measure(page);
  check('B5 after grow: re-glued to right', Math.abs(m.vw - m.right - GAP) <= TOL, `gap=${(m.vw - m.right).toFixed(1)} vw=${m.vw}`);

  // ---------------------------------------------------------
  // C. DRAG-RELEASE on the SAME side — must snap flush, not stick mid
  //    (root cause #2: same-edge drop bypassed snapping)
  // ---------------------------------------------------------
  // Panel starts on the right. Drag it toward the middle-right but keep its
  // center on the right half, then release — it must snap flush to the right.
  await dragHeaderTo(page, Math.round(1500 * 0.62), 300);
  await settle();
  m = await measure(page);
  check('C1 same-side (right) drop snaps flush right', Math.abs(m.vw - m.right - GAP) <= TOL, `gap=${(m.vw - m.right).toFixed(1)}`);
  check('C2 not stuck in middle after same-side drop', (m.vw - m.right) < 120, `distance-from-right=${(m.vw - m.right).toFixed(0)}`);

  // Now drag to the LEFT half and release — should snap flush left.
  await dragHeaderTo(page, Math.round(1500 * 0.25), 260);
  await settle();
  m = await measure(page);
  check('C3 cross to left: snaps flush left', Math.abs(m.left - GAP) <= TOL, `left=${m.left.toFixed(1)}`);
  check('C4 edge-relative lock uses left (right=auto)', m.styleLeft && m.styleLeft !== 'auto' && (m.styleRight === 'auto' || m.styleRight === ''), `left="${m.styleLeft}" right="${m.styleRight}"`);

  // Drag within the LEFT half again (same-side) — must stay flush left.
  await dragHeaderTo(page, Math.round(1500 * 0.30), 400);
  await settle();
  m = await measure(page);
  check('C5 same-side (left) drop stays flush left', Math.abs(m.left - GAP) <= TOL, `left=${m.left.toFixed(1)}`);

  // ---------------------------------------------------------
  // D. SMALL VIEWPORT clamping — panel open
  //    (root cause #3: clamp used 520 phantom height)
  // ---------------------------------------------------------
  await page.setViewport({ width: 700, height: 560 });
  await settle();
  m = await measure(page);
  check('D1 small vp: panel within viewport bounds', m.top >= GAP - TOL && m.bottom <= m.vh + TOL && m.left >= -TOL && m.right <= m.vw + TOL,
    `top=${m.top.toFixed(0)} bottom=${m.bottom.toFixed(0)} left=${m.left.toFixed(0)} right=${m.right.toFixed(0)} vp=${m.vw}x${m.vh}`);

  // ---------------------------------------------------------
  // E. CLOSED LAUNCHER — must not be pushed off-screen by phantom
  //    panel height, and must re-glue on resize while closed.
  //    (root cause #3 + #1 for the minimized state)
  // ---------------------------------------------------------
  // close the panel
  await clickText(page, '.byte-x', '', 5); // X button has no text; fallback below
  // the X button has an svg only; click it directly
  await page.evaluate(() => { const b = document.querySelector('.byte-x'); if (b) b.click(); });
  await settle();
  m = await measure(page);
  check('E1 launcher shown after close', m.kind === 'launcher', m.kind);
  check('E2 small vp: launcher fully on-screen', m.top >= GAP - TOL && m.bottom <= m.vh + TOL && m.right <= m.vw + TOL && m.left >= -TOL,
    `top=${m.top.toFixed(0)} bottom=${m.bottom.toFixed(0)} right=${m.right.toFixed(0)} vp=${m.vw}x${m.vh}`);

  // resize while CLOSED, then verify launcher re-glues to the edge on-screen
  await page.setViewport({ width: 1200, height: 800 });
  await settle();
  m = await measure(page);
  check('E3 resize while closed: launcher re-glued to an edge & on-screen',
    (Math.abs(m.left - GAP) <= 40 || Math.abs(m.vw - m.right - GAP) <= 40) && m.bottom <= m.vh + TOL && m.top >= GAP - TOL,
    `left=${m.left.toFixed(0)} right-gap=${(m.vw - m.right).toFixed(0)} top=${m.top.toFixed(0)} bottom=${m.bottom.toFixed(0)}`);

  // reopen and confirm it still snaps cleanly (no leftover middle position)
  await page.evaluate(() => { const b = document.querySelector('.byte-launcher'); if (b) b.click(); });
  await settle();
  m = await measure(page);
  check('E4 reopened panel snaps to an edge', Math.abs(m.left - GAP) <= TOL || Math.abs(m.vw - m.right - GAP) <= TOL,
    `left=${m.left.toFixed(0)} right-gap=${(m.vw - m.right).toFixed(0)}`);

  // ---------------------------------------------------------
  // F. no runtime errors throughout
  // ---------------------------------------------------------
  check('F1 no page errors during positioning tests', pageErrors.length === 0, pageErrors.slice(0, 3).join(' | '));

  await browser.close();
  server.close();

  const failed = results.filter((r) => !r.pass);
  console.log(`\n${results.length - failed.length}/${results.length} positioning checks passed`);
  if (failed.length) { console.log('FAILED:', failed.map((f) => f.name).join(', ')); process.exit(1); }
  console.log('POSITIONING: PASS ✓');
  process.exit(0);
}

main().catch((e) => { console.error(e); server.close(); process.exit(1); });
