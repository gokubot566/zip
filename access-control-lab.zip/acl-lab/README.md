# Access Control & Secure Sharing — Interactive Cyber Range Lab

An in-browser, hands-on lab for **BSBXCS303 – Securely manage personally
identifiable information and workplace information**. Students SSH into a
misconfigured company file server (`FILES01`) using a **realistic simulated
Linux terminal** and run real commands (`chmod`, `chown`, `setfacl`, `getfacl`,
`umask`, `su`, `smbclient`, `mount`, …) to find and fix permission problems on
shared departmental folders (HR / Marketing / IT / Shared).

Built to match the Security Impossible lab pattern: a full-screen realistic
"app" plus the draggable **Byte** guide overlay that gates the tasks. No quiz —
progression is earned by actually fixing the server.

---

## What the student does

Everything happens in a browser tab. The left side is a live terminal into
`FILES01 (10.50.0.11)`; **Byte** floats on top (drag it anywhere, snaps to
either edge) and walks through eight sequential tasks. Each task is **locked
until the previous one is genuinely completed on the box** — the lab inspects
the live simulated filesystem/ACL state to decide, so students can't skip ahead.

### The eight tasks
1. **Reconnaissance** — SSH in, read an HR file as `student` (you shouldn't be able to), discover the hidden `_backdoor` directory.
2. **Cross-department & share leaks** — read HR as `marketinguser`, then pull the file over Samba (`smbclient`).
3. **Secure default permissions (umask)** — the system `umask` is `000`; back up `/etc/bash.bashrc`, set `umask 007`, reload.
4. **Neutralize the backdoor** — take ownership, wipe the copied HR files, lock the directory down.
5. **Reset ownership & base permissions** — clear stale ACLs, set correct group owners, apply strict `750` base modes.
6. **POSIX ACLs — HR folder** — HR `rwX`, IT read-only `r-X`, everyone else nothing, with default (inherited) entries.
7. **ACLs — Marketing, IT & Shared** — extend the model; each department isolated, Shared open to all staff.
8. **Final validation** — prove no world-readable files remain and that cross-department access is denied.

A **Restart container** control (in Byte's footer) re-seeds `FILES01` to its
original broken state — styled as a container restart — while keeping the
student's completed-task progress.

---

## Running it

### Docker (recommended)
```bash
docker compose up --build
# open http://localhost:8345
```
or manually:
```bash
docker build -t access-control-lab:latest .
docker run --rm -p 8345:8345 access-control-lab:latest
```

### Local development
```bash
npm install
npm run dev      # http://localhost:8345
npm run build    # production build into ./build
```

The lab serves on **port 8345**. A `/health` endpoint returns `ok` for
healthchecks.

---

## Notes for instructors

- **Fully offline / self-contained.** The Linux environment is *simulated* in
  the browser — there is no real VM, no shell escape, and no network egress.
  Fonts are bundled locally so it renders correctly on isolated cyber-range
  networks. Nothing on the host or network is touched.
- **Realistic command behaviour.** The engine models UNIX mode bits (including
  setgid/sticky), POSIX ACLs (access + default + mask, with `#effective`
  annotations in `getfacl`), `umask` inheritance, group membership, and the
  SMB/NFS access paths. Securing the filesystem permissions automatically
  closes the share leaks, exactly as it would on a real host.
- **Progress persists** in the browser (localStorage). "Restart lab" on the
  final card wipes progress; "Restart container" only re-seeds the box.
- All names, records, users and shares are fictional.

---

## Project layout
```
src/
  App.jsx                  top-level state, task gating, persistence, restart
  main.jsx                 entry point (+ local font imports)
  index.css                theme + cast portrait styles
  components/
    Terminal.jsx           full-screen simulated SSH terminal (the "app")
    Byte.jsx               draggable guide overlay; gates the 8 tasks
    Cast.jsx               mentor portrait component (shared across labs)
  data/
    fsEngine.js            simulated filesystem + UNIX/ACL permission model
    terminalEngine.js      command parser/executor (chmod, setfacl, su, …)
    scenario.js            lab content: cast, the 8 tasks, intro/summary
    siteLogic.js           per-task completion predicates (the gate)
test/
  walkthrough.mjs          headless engine test — all 8 tasks via commands
  browser.mjs              full browser E2E (Puppeteer) through the UI
  positioning.mjs          Byte overlay layout regression (resize, drag, clamp)
```

## Tests

```bash
npm install
PUPPETEER_SKIP_DOWNLOAD=1 npm install --no-save puppeteer   # for the browser tests
npm test          # build + all three suites
```

Individually:
- `npm run test:engine` — drives the permission engine through all 8 tasks with the documented Linux commands.
- `npm run test:e2e` — full Puppeteer run through the real UI: intro → explore → 8 gated tasks → summary card; asserts each gate opens only when the fix is genuinely done, and that there are no runtime errors.
- `npm run test:layout` — 19 checks on the draggable **Byte** overlay covering the known layout pitfalls: staying glued to an edge on window resize (open *and* minimized), snapping flush when dropped on the same side (no sticking mid-screen), and staying fully on-screen on small viewports.

