# Lab 10: Major Incident – Multi-Vector Attack Response
## Security Impossible DFIR Training Platform

### Quick Start (Single Command)

```bash
docker compose up -d
```

Access: **http://<YOUR_IP>:8085**

---

### Requirements

| Item | Requirement |
|------|-------------|
| Docker | 24+ with Docker Compose v2 |
| RAM | 4 GB minimum |
| Port | 8085 (TCP) must be open |

---

### Deployment by Environment

**Local (laptop/desktop)**
```bash
docker compose up -d
# Open: http://localhost:8085
```

**Classroom server (LAN)**
```bash
docker compose up -d
# Open: http://<SERVER_LAN_IP>:8085
# Firewall: sudo ufw allow 8085/tcp
```

**Cloud VM (AWS / Azure / GCP)**
```bash
docker compose up -d
# 1. Open port 8085 in cloud security group / firewall rule
# 2. Open: http://<PUBLIC_IP>:8085
```

---

### Management Commands

```bash
# Start
docker compose up -d

# Stop
docker compose down

# Restart
docker compose restart

# View logs
docker compose logs -f lab10-dfir

# Force rebuild (after any source changes)
docker compose down
docker compose up -d --build

# Check status
docker compose ps
```

---

### Troubleshooting

| Problem | Fix |
|---------|-----|
| Page not loading | Run `docker compose ps` — check container is `Up`. Run `docker compose logs lab10-dfir` for errors. |
| Port conflict | Edit `docker-compose.yml` — change `8085:8085` to `8086:8085` (left = host port) |
| White screen | Hard refresh: Ctrl+Shift+R (Win/Linux) or Cmd+Shift+R (Mac) |
| Container won't start | Run `docker compose up --build` to force fresh build |
| Firewall blocking access | Run `sudo ufw allow 8085/tcp && sudo ufw reload` |

---

### Platform Ports

| Component | Port | Notes |
|-----------|------|-------|
| Nginx (inside container) | 8085 | Configured in nginx/default.conf |
| Host binding | 0.0.0.0:8085 | Accessible on all network interfaces |

---

*Security Impossible Pty Ltd — Lab 10 v1.0*
