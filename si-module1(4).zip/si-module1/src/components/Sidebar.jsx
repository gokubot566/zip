import { motion, AnimatePresence } from 'framer-motion';
import { Check, Lock } from 'lucide-react';
import { ALL_MODULES } from '../modules/moduleData.js';

export default function Sidebar({ open, currentModuleId, completedModules, onNavigate }) {
  const done  = new Set(completedModules || []);
  const total = ALL_MODULES.length;
  const pct   = Math.round((done.size / total) * 100);

  return (
    <AnimatePresence>
      {open && (
        <motion.aside
          initial={{ x: -260, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -260, opacity: 0 }}
          transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
          style={{
            position: 'fixed', top: 56, left: 0, bottom: 0, zIndex: 150,
            width: 260,
            background: '#000',
            borderRight: '1px solid #1a1a1a',
            display: 'flex', flexDirection: 'column',
            overflowY: 'auto',
            scrollbarWidth: 'thin',
            scrollbarColor: '#1a1a1a transparent',
          }}
        >
          {/* Progress block */}
          <div style={{ padding:'20px 18px 16px', borderBottom:'1px solid #111' }}>
            <div style={{
              display:'flex', justifyContent:'space-between', alignItems:'baseline',
              marginBottom:10,
            }}>
              <span style={{
                fontFamily:"'Inter',sans-serif", fontSize:13, fontWeight:600, color:'#d4d4d4',
              }}>Course Progress</span>
              <span style={{
                fontFamily:"'DM Mono',monospace", fontSize:11,
                color: pct===100 ? '#22c55e' : '#555',
              }}>{done.size}/{total}</span>
            </div>
            {/* Track */}
            <div style={{ height:2, background:'#111', borderRadius:1, overflow:'hidden' }}>
              <motion.div
                initial={{ width:0 }}
                animate={{ width:`${pct}%` }}
                transition={{ duration:0.7, ease:'easeOut' }}
                style={{
                  height:'100%', borderRadius:1,
                  background: pct===100 ? '#22c55e' : 'linear-gradient(90deg,#7c3aed,#9333ea)',
                }}
              />
            </div>
          </div>

          {/* Module list */}
          <nav style={{ flex:1, padding:'6px 0 20px' }}>
            {ALL_MODULES.map((mod) => {
              const active    = mod.id === currentModuleId;
              const isDone    = done.has(mod.id);
              const unlocked  = mod.id === 1 || isDone || done.has(mod.id - 1);
              const hasAck    = mod.policyAck?.length > 0;

              return (
                <button
                  key={mod.id}
                  onClick={() => unlocked && onNavigate(mod.id)}
                  disabled={!unlocked}
                  style={{
                    width: '100%', textAlign: 'left',
                    display: 'block', border: 'none',
                    borderLeft: `2px solid ${active ? '#8b5cf6' : 'transparent'}`,
                    background: active ? '#0c0c0c' : 'transparent',
                    cursor: unlocked ? 'pointer' : 'default',
                    padding: '0 16px 0 14px',
                    transition: 'background 0.12s',
                  }}
                  onMouseEnter={e => { if(unlocked && !active) e.currentTarget.style.background='#080808'; }}
                  onMouseLeave={e => { if(!active) e.currentTarget.style.background='transparent'; }}
                >
                  <div style={{
                    display:'flex', alignItems:'center', gap:10,
                    padding:'10px 0',
                    borderBottom:'1px solid #0e0e0e',
                    opacity: unlocked ? 1 : 0.22,
                  }}>
                    {/* Status icon */}
                    <div style={{
                      width:24, height:24, borderRadius:5, flexShrink:0,
                      display:'flex', alignItems:'center', justifyContent:'center',
                      background: isDone
                        ? 'rgba(34,197,94,0.08)'
                        : active
                          ? 'rgba(139,92,246,0.10)'
                          : '#0a0a0a',
                      border: isDone
                        ? '1px solid rgba(34,197,94,0.20)'
                        : active
                          ? '1px solid rgba(139,92,246,0.25)'
                          : '1px solid #1a1a1a',
                    }}>
                      {isDone ? (
                        <Check size={11} color="#22c55e" strokeWidth={2.5}/>
                      ) : !unlocked ? (
                        <Lock size={9} color="#252525"/>
                      ) : (
                        <span style={{
                          fontFamily:"'DM Mono',monospace", fontSize:9, fontWeight:500,
                          color: active ? '#8b5cf6' : '#2e2e2e',
                        }}>
                          {String(mod.id).padStart(2,'0')}
                        </span>
                      )}
                    </div>

                    {/* Text */}
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{
                        fontFamily:"'Inter',sans-serif",
                        fontSize:12.5,
                        fontWeight: active ? 600 : 400,
                        color: isDone
                          ? '#444'
                          : active ? '#fff'
                          : unlocked ? '#777' : '#2a2a2a',
                        lineHeight:1.3,
                        whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis',
                        marginBottom:3,
                      }}>
                        {mod.title}
                      </div>
                      <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                        <span style={{
                          fontFamily:"'DM Mono',monospace", fontSize:9.5, color:'#252525',
                        }}>{mod.duration}</span>
                        {hasAck && unlocked && !isDone && (
                          <span style={{
                            fontFamily:"'DM Mono',monospace", fontSize:8.5,
                            color:'rgba(245,158,11,0.5)',
                            background:'rgba(245,158,11,0.05)',
                            border:'1px solid rgba(245,158,11,0.12)',
                            padding:'0 4px', borderRadius:3,
                          }}>ACK</span>
                        )}
                        {active && (
                          <span style={{
                            fontFamily:"'DM Mono',monospace", fontSize:8.5,
                            color:'rgba(139,92,246,0.6)',
                            background:'rgba(139,92,246,0.06)',
                            border:'1px solid rgba(139,92,246,0.15)',
                            padding:'0 4px', borderRadius:3,
                          }}>NOW</span>
                        )}
                      </div>
                    </div>

                    {isDone && (
                      <span style={{
                        fontFamily:"'DM Mono',monospace", fontSize:9,
                        color:'#22c55e', flexShrink:0,
                      }}>✓</span>
                    )}
                  </div>
                </button>
              );
            })}
          </nav>

          {/* Footer */}
          <div style={{ padding:'14px 18px', borderTop:'1px solid #0e0e0e' }}>
            <div style={{
              fontFamily:"'Inter',sans-serif", fontSize:12, color:'#2a2a2a',
              lineHeight:1.9,
            }}>
              <div>Questions about this training?</div>
              <div style={{ color:'#3d2b6b' }}>contact@securityimpossible.com</div>
            </div>
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  );
}
