import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, MessageSquare, BookOpen, HelpCircle, Check, X } from 'lucide-react';

/* ── Shared text styles ─────────────────────────────────────────────────────── */
const body  = { fontFamily:"'Inter',sans-serif", fontSize:14.5, color:'#d4d4d4', lineHeight:1.8 };
const label = { fontFamily:"'DM Mono',monospace", fontSize:10,  color:'#2e2e2e', letterSpacing:'0.08em' };
const sm    = { fontFamily:"'Inter',sans-serif",  fontSize:13,  color:'#555' };

/* ── Section divider with centred label ─────────────────────────────────────── */
function SectionLabel({ text }) {
  return (
    <div className="section-label" style={{ margin:'24px 0 14px' }}>
      <span>{text}</span>
    </div>
  );
}

/* ── Expandable reading section ─────────────────────────────────────────────── */
function ContentSection({ heading, body: bodyText, index }) {
  const [open, setOpen] = useState(true);
  return (
    <div style={{
      border:'1px solid #1a1a1a', borderRadius:6,
      marginBottom:6, overflow:'hidden',
      background:'#0c0c0c',
    }}>
      <button
        onClick={() => setOpen(!open)}
        style={{
          width:'100%', textAlign:'left',
          padding:'14px 18px', border:'none',
          background:'transparent', cursor:'pointer',
          display:'flex', alignItems:'center', gap:12,
        }}
      >
        <span style={{ ...label, minWidth:22, fontSize:10, color:'#252525' }}>
          {String(index+1).padStart(2,'0')}
        </span>
        <span style={{
          fontFamily:"'Inter',sans-serif", fontWeight:600, fontSize:14,
          color:'#d4d4d4', flex:1, textAlign:'left',
        }}>{heading}</span>
        <motion.div animate={{ rotate: open?180:0 }} transition={{ duration:0.16 }}>
          <ChevronDown size={14} color="#2e2e2e"/>
        </motion.div>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height:0, opacity:0 }}
            animate={{ height:'auto', opacity:1 }}
            exit={{ height:0, opacity:0 }}
            transition={{ duration:0.2 }}
            style={{ overflow:'hidden' }}
          >
            <div style={{ height:1, background:'#141414', margin:'0 18px' }}/>
            <div style={{ padding:'16px 18px 20px' }}>
              {bodyText.split('\n\n').map((para, i, arr) => (
                <p key={i} style={{
                  ...body,
                  marginBottom: i < arr.length-1 ? 14 : 0,
                }}>{para}</p>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ── Scenario card ──────────────────────────────────────────────────────────── */
function ScenarioCard({ scenario, onDone, done }) {
  const [selected, setSelected] = useState(null);
  const [revealed, setRevealed] = useState(false);

  function pick(opt) {
    setSelected(opt);
    setRevealed(true);
    if (opt.correct && !done) onDone();
  }

  return (
    <div style={{
      border:'1px solid #1a1a1a', borderRadius:6,
      overflow:'hidden', background:'#0c0c0c',
    }}>
      {/* Card header */}
      <div style={{
        padding:'12px 18px', background:'#111',
        borderBottom:'1px solid #141414',
        display:'flex', alignItems:'center', gap:10,
      }}>
        <MessageSquare size={12} color="#3a3a3a"/>
        <span style={{ ...label }}>WORKPLACE SCENARIO</span>
        <div style={{ flex:1 }}/>
        <span style={{
          fontFamily:"'Inter',sans-serif", fontWeight:600, fontSize:13.5, color:'#d4d4d4',
        }}>{scenario.title}</span>
      </div>

      <div style={{ padding:'20px 18px' }}>
        {/* Situation */}
        <div style={{
          padding:'12px 15px', background:'#111',
          border:'1px solid #1a1a1a', borderRadius:5, marginBottom:14,
        }}>
          <div style={{ ...label, marginBottom:6 }}>SITUATION</div>
          <p style={{ ...body, fontSize:14, margin:0 }}>{scenario.setup}</p>
        </div>

        {/* Message bubble */}
        <div style={{
          padding:'12px 15px', background:'#111',
          border:'1px solid #1a1a1a',
          borderRadius:'4px 10px 10px 10px', marginBottom:16,
          fontFamily:"'Inter',sans-serif", fontSize:14, fontStyle:'italic',
          color:'#909090', lineHeight:1.65,
        }}>
          {scenario.message}
        </div>

        {/* Options */}
        <div style={{ ...label, marginBottom:10 }}>HOW DO YOU RESPOND?</div>
        <div style={{ display:'flex', flexDirection:'column', gap:7 }}>
          {scenario.options.map((opt, i) => {
            const isSel  = selected?.id === opt.id;
            const dimmed = revealed && !isSel;
            return (
              <button
                key={opt.id}
                onClick={() => !revealed && pick(opt)}
                style={{
                  textAlign:'left', padding:'12px 14px', borderRadius:5,
                  border:`1px solid ${
                    isSel
                      ? opt.correct ? 'rgba(34,197,94,0.3)' : 'rgba(239,68,68,0.25)'
                      : '#1a1a1a'
                  }`,
                  background: isSel
                    ? opt.correct ? 'rgba(34,197,94,0.05)' : 'rgba(239,68,68,0.04)'
                    : '#111',
                  cursor: revealed ? 'default' : 'pointer',
                  display:'flex', alignItems:'flex-start', gap:11,
                  opacity: dimmed ? 0.22 : 1,
                  transition:'all 0.14s',
                }}
              >
                {/* Letter / result mark */}
                <div style={{
                  width:22, height:22, borderRadius:4, flexShrink:0,
                  display:'flex', alignItems:'center', justifyContent:'center',
                  background: isSel
                    ? opt.correct ? 'rgba(34,197,94,0.14)' : 'rgba(239,68,68,0.10)'
                    : '#0a0a0a',
                  border:`1px solid ${
                    isSel
                      ? opt.correct ? 'rgba(34,197,94,0.30)' : 'rgba(239,68,68,0.25)'
                      : '#222'
                  }`,
                  fontFamily:"'DM Mono',monospace", fontSize:10, fontWeight:500,
                  color: isSel ? (opt.correct?'#22c55e':'#ef4444') : '#2e2e2e',
                }}>
                  {isSel ? (opt.correct?'✓':'✗') : String.fromCharCode(65+i)}
                </div>
                <span style={{
                  fontFamily:"'Inter',sans-serif", fontSize:14, lineHeight:1.55,
                  color: isSel
                    ? opt.correct ? '#6ee7b7' : '#fca5a5'
                    : '#909090',
                }}>
                  "{opt.text}"
                </span>
              </button>
            );
          })}
        </div>

        {/* Feedback */}
        <AnimatePresence>
          {revealed && selected && (
            <motion.div
              initial={{ opacity:0, y:5 }} animate={{ opacity:1, y:0 }}
              exit={{ opacity:0 }} transition={{ duration:0.2 }}
              style={{
                marginTop:12, padding:'13px 15px', borderRadius:5,
                background: selected.correct ? 'rgba(34,197,94,0.04)' : 'rgba(239,68,68,0.04)',
                border:`1px solid ${selected.correct ? 'rgba(34,197,94,0.20)' : 'rgba(239,68,68,0.18)'}`,
              }}
            >
              <p style={{
                ...body, fontSize:14, margin:0,
                color: selected.correct ? '#6ee7b7' : '#fca5a5',
              }}>
                {selected.feedback}
              </p>
              {!selected.correct && (
                <button
                  onClick={() => { setSelected(null); setRevealed(false); }}
                  style={{
                    marginTop:10, padding:'5px 12px', borderRadius:4,
                    background:'transparent', border:'1px solid #1e1e1e',
                    color:'#555', fontFamily:"'Inter',sans-serif", fontSize:12,
                    cursor:'pointer',
                  }}
                >Try again</button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ── Policy references ──────────────────────────────────────────────────────── */
function PolicyRefs({ policies }) {
  const [expanded, setExpanded] = useState(null);
  return (
    <div style={{
      border:'1px solid #1a1a1a', borderRadius:6, overflow:'hidden', background:'#0c0c0c',
    }}>
      <div style={{
        padding:'12px 18px', background:'#111', borderBottom:'1px solid #141414',
        display:'flex', alignItems:'center', gap:10,
      }}>
        <BookOpen size={12} color="#3a3a3a"/>
        <span style={{ ...label }}>POLICY REFERENCES</span>
        <div style={{ flex:1 }}/>
        <span style={{ ...label }}>
          {policies.length} {policies.length===1?'policy':'policies'}
        </span>
      </div>

      <div style={{ padding:'8px 10px' }}>
        {policies.map(pol => (
          <div key={pol.ref} style={{ marginBottom:3 }}>
            <button
              onClick={() => setExpanded(expanded===pol.ref ? null : pol.ref)}
              style={{
                width:'100%', textAlign:'left',
                padding:'10px 12px', borderRadius:5,
                background: expanded===pol.ref ? '#111' : 'transparent',
                border:'1px solid transparent',
                cursor:'pointer',
                display:'flex', alignItems:'center', gap:12,
                transition:'background 0.12s',
              }}
              onMouseEnter={e => e.currentTarget.style.background='#111'}
              onMouseLeave={e => { if(expanded!==pol.ref) e.currentTarget.style.background='transparent'; }}
            >
              <span style={{ ...label, fontSize:10, minWidth:80, color:'#2e2e2e' }}>{pol.ref}</span>
              <span style={{
                fontFamily:"'Inter',sans-serif", fontSize:13.5, fontWeight:500,
                color:'#909090', flex:1,
              }}>{pol.title}</span>
              <motion.div animate={{ rotate: expanded===pol.ref?180:0 }} transition={{ duration:0.14 }}>
                <ChevronDown size={12} color="#252525"/>
              </motion.div>
            </button>

            <AnimatePresence>
              {expanded===pol.ref && (
                <motion.div
                  initial={{ height:0, opacity:0 }}
                  animate={{ height:'auto', opacity:1 }}
                  exit={{ height:0, opacity:0 }}
                  transition={{ duration:0.18 }}
                  style={{ overflow:'hidden' }}
                >
                  <div style={{ padding:'10px 12px 14px', paddingLeft:104 }}>
                    <p style={{ ...body, fontSize:13.5, color:'#666', marginBottom:10 }}>{pol.summary}</p>
                    <div style={{ ...label, marginBottom:8 }}>YOUR OBLIGATIONS</div>
                    {pol.obligations.map((ob, j) => (
                      <div key={j} style={{ display:'flex', gap:9, marginBottom:6 }}>
                        <div style={{
                          width:4, height:4, borderRadius:'50%', background:'#222',
                          marginTop:9, flexShrink:0,
                        }}/>
                        <span style={{ ...body, fontSize:13.5, color:'#666' }}>{ob}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── Knowledge check quiz ───────────────────────────────────────────────────── */
function Quiz({ questions, onDone, done }) {
  const [answers,   setAnswers]   = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [current,   setCurrent]   = useState(0);

  const q           = questions[current];
  const allAnswered = questions.every((_,i) => answers[i] !== undefined);
  const score       = submitted
    ? questions.filter((_,i) => answers[i] === questions[i].correct).length
    : 0;

  function submit() { setSubmitted(true); if (!done) onDone(); }
  function reset()  { setAnswers({}); setSubmitted(false); setCurrent(0); }

  return (
    <div style={{ border:'1px solid #1a1a1a', borderRadius:6, overflow:'hidden', background:'#0c0c0c' }}>
      {/* Header */}
      <div style={{
        padding:'12px 18px', background:'#111', borderBottom:'1px solid #141414',
        display:'flex', alignItems:'center', justifyContent:'space-between',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <HelpCircle size={12} color="#3a3a3a"/>
          <span style={{ ...label }}>KNOWLEDGE CHECK</span>
        </div>
        {!submitted && (
          <div style={{ display:'flex', gap:4 }}>
            {questions.map((_, i) => (
              <button key={i} onClick={() => setCurrent(i)} style={{
                width:26, height:26, borderRadius:4,
                background: current===i
                  ? '#7c3aed'
                  : answers[i]!==undefined ? 'rgba(34,197,94,0.10)' : '#0a0a0a',
                border: current===i
                  ? '1px solid #6d28d9'
                  : answers[i]!==undefined ? '1px solid rgba(34,197,94,0.22)' : '1px solid #1a1a1a',
                color: current===i ? '#fff' : answers[i]!==undefined ? '#22c55e' : '#252525',
                fontFamily:"'DM Mono',monospace", fontSize:10, fontWeight:500,
                cursor:'pointer', transition:'all 0.12s',
              }}>{i+1}</button>
            ))}
          </div>
        )}
      </div>

      <div style={{ padding:'20px 18px' }}>
        {!submitted ? (
          <>
            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity:0, x:8 }} animate={{ opacity:1, x:0 }}
                exit={{ opacity:0, x:-8 }} transition={{ duration:0.16 }}
              >
                {/* Question */}
                <div style={{
                  padding:'14px 16px', background:'#111',
                  border:'1px solid #1a1a1a', borderRadius:5, marginBottom:12,
                }}>
                  <div style={{ display:'flex', gap:10, alignItems:'flex-start' }}>
                    <span style={{
                      fontFamily:"'DM Mono',monospace", fontSize:11,
                      color:'#8b5cf6', fontWeight:500, flexShrink:0, marginTop:2,
                    }}>Q{current+1}</span>
                    <p style={{
                      fontFamily:"'Inter',sans-serif", fontWeight:500,
                      fontSize:14.5, color:'#fff', lineHeight:1.5, margin:0,
                    }}>{q.q}</p>
                  </div>
                </div>

                {/* Options */}
                <div style={{ display:'flex', flexDirection:'column', gap:6, marginBottom:16 }}>
                  {q.opts.map((opt, i) => {
                    const sel = answers[current] === i;
                    return (
                      <button
                        key={i}
                        onClick={() => setAnswers(a => ({...a,[current]:i}))}
                        style={{
                          textAlign:'left', padding:'11px 14px', borderRadius:5,
                          background: sel ? 'rgba(139,92,246,0.07)' : '#111',
                          border:`1px solid ${sel ? 'rgba(139,92,246,0.28)' : '#1a1a1a'}`,
                          cursor:'pointer',
                          display:'flex', alignItems:'center', gap:11,
                          transition:'all 0.12s',
                        }}
                        onMouseEnter={e => { if(!sel) e.currentTarget.style.borderColor='#222'; }}
                        onMouseLeave={e => { if(!sel) e.currentTarget.style.borderColor='#1a1a1a'; }}
                      >
                        <div style={{
                          width:22, height:22, borderRadius:4, flexShrink:0,
                          background: sel ? 'rgba(139,92,246,0.18)' : 'transparent',
                          border:`1px solid ${sel ? 'rgba(139,92,246,0.38)' : '#222'}`,
                          display:'flex', alignItems:'center', justifyContent:'center',
                          fontFamily:"'DM Mono',monospace", fontSize:10,
                          color: sel ? '#a78bfa' : '#252525', fontWeight:500,
                        }}>
                          {String.fromCharCode(65+i)}
                        </div>
                        <span style={{
                          fontFamily:"'Inter',sans-serif", fontSize:14, lineHeight:1.5,
                          color: sel ? '#c4b5fd' : '#909090',
                        }}>{opt}</span>
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Nav */}
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <button
                onClick={() => setCurrent(c => Math.max(0,c-1))}
                disabled={current===0}
                style={{
                  padding:'7px 14px', borderRadius:5, background:'transparent',
                  border:'1px solid #1a1a1a',
                  color: current===0 ? '#1e1e1e' : '#555',
                  fontFamily:"'Inter',sans-serif", fontSize:13,
                  cursor: current===0 ? 'default' : 'pointer',
                }}
              >← Back</button>

              {current < questions.length-1 ? (
                <button
                  onClick={() => setCurrent(c => c+1)}
                  style={{
                    padding:'7px 14px', borderRadius:5,
                    background:'transparent', border:'1px solid #1a1a1a',
                    color:'#555', fontFamily:"'Inter',sans-serif", fontSize:13, cursor:'pointer',
                  }}
                >Next →</button>
              ) : (
                <button
                  onClick={submit} disabled={!allAnswered}
                  style={{
                    padding:'7px 20px', borderRadius:5,
                    background: allAnswered ? '#7c3aed' : 'transparent',
                    border: allAnswered ? '1px solid #6d28d9' : '1px solid #1a1a1a',
                    color: allAnswered ? '#fff' : '#252525',
                    fontFamily:"'Inter',sans-serif", fontSize:13, fontWeight:600,
                    cursor: allAnswered ? 'pointer' : 'not-allowed',
                    transition:'all 0.12s',
                  }}
                >Submit answers</button>
              )}
            </div>
          </>
        ) : (
          /* Results */
          <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ duration:0.25 }}>
            {/* Score card */}
            <div style={{
              textAlign:'center', padding:'22px',
              background:'#111', border:'1px solid #1a1a1a', borderRadius:5,
              marginBottom:18,
            }}>
              <div style={{
                fontFamily:"'Inter',sans-serif", fontWeight:700, fontSize:32,
                letterSpacing:'-0.03em', marginBottom:5,
                color: score===questions.length ? '#22c55e' : '#fff',
              }}>
                {score} / {questions.length}
              </div>
              <div style={{ ...sm }}>
                {score===questions.length
                  ? 'All correct — excellent understanding.'
                  : score >= Math.ceil(questions.length*0.75)
                    ? 'Good result. Review the explanations below.'
                    : 'Review the explanations and try again.'}
              </div>
            </div>

            {/* Per-question results */}
            <div style={{ display:'flex', flexDirection:'column', gap:7, marginBottom:16 }}>
              {questions.map((q2, i) => {
                const correct = answers[i] === q2.correct;
                return (
                  <div key={i} style={{
                    padding:'13px 15px', borderRadius:5,
                    background:'#111',
                    border:`1px solid ${correct ? 'rgba(34,197,94,0.14)' : 'rgba(239,68,68,0.14)'}`,
                  }}>
                    <div style={{ display:'flex', gap:9, marginBottom:7, alignItems:'flex-start' }}>
                      {correct
                        ? <Check size={13} color="#22c55e" strokeWidth={2.5} style={{ flexShrink:0,marginTop:2 }}/>
                        : <X size={13} color="#ef4444" style={{ flexShrink:0,marginTop:2 }}/>
                      }
                      <div style={{
                        fontFamily:"'Inter',sans-serif", fontWeight:500,
                        fontSize:14, color:'#d4d4d4', lineHeight:1.45,
                      }}>{q2.q}</div>
                    </div>
                    {!correct && (
                      <div style={{ marginLeft:22, marginBottom:6 }}>
                        <div style={{ fontFamily:"'DM Mono',monospace", fontSize:11, color:'#6b2020', marginBottom:2 }}>
                          Your answer: "{q2.opts[answers[i]]}"
                        </div>
                        <div style={{ fontFamily:"'DM Mono',monospace", fontSize:11, color:'#1e5c30' }}>
                          Correct: "{q2.opts[q2.correct]}"
                        </div>
                      </div>
                    )}
                    <div style={{
                      marginLeft:22, padding:'8px 11px',
                      background:'#0a0a0a', borderRadius:4,
                      fontFamily:"'Inter',sans-serif", fontSize:13,
                      color:'#666', lineHeight:1.65,
                    }}>{q2.exp}</div>
                  </div>
                );
              })}
            </div>

            <button onClick={reset} style={{
              padding:'7px 14px', borderRadius:5, background:'transparent',
              border:'1px solid #1a1a1a', color:'#555',
              fontFamily:"'Inter',sans-serif", fontSize:13, cursor:'pointer',
              transition:'border-color 0.12s, color 0.12s',
            }}
              onMouseEnter={e => { e.currentTarget.style.borderColor='#2a2a2a'; e.currentTarget.style.color='#d4d4d4'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor='#1a1a1a'; e.currentTarget.style.color='#555'; }}
            >Retake quiz</button>
          </motion.div>
        )}
      </div>
    </div>
  );
}

/* ── Exported composite ─────────────────────────────────────────────────────── */
export default function ModuleContent({ module, scenarioDone, quizDone, onScenarioDone, onQuizDone }) {
  return (
    <div>
      {module.content?.length > 0 && (
        <>
          <SectionLabel text="READING"/>
          {module.content.map((sec, i) => (
            <ContentSection key={i} heading={sec.heading} body={sec.body} index={i}/>
          ))}
        </>
      )}
      {module.scenario && (
        <>
          <SectionLabel text="WORKPLACE SCENARIO"/>
          <ScenarioCard scenario={module.scenario} onDone={onScenarioDone} done={scenarioDone}/>
        </>
      )}
      {module.policies?.length > 0 && (
        <>
          <SectionLabel text="POLICY REFERENCES"/>
          <PolicyRefs policies={module.policies}/>
        </>
      )}
      {module.quiz?.length > 0 && (
        <>
          <SectionLabel text="KNOWLEDGE CHECK"/>
          <Quiz questions={module.quiz} onDone={onQuizDone} done={quizDone}/>
        </>
      )}
    </div>
  );
}
