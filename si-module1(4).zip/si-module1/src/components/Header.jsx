import { motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';

function SILogoMark({ size = 28 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <defs>
        <linearGradient id="siG" x1="0" y1="0" x2="32" y2="32">
          <stop offset="0%"   stopColor="#7c3aed"/>
          <stop offset="55%"  stopColor="#9333ea"/>
          <stop offset="100%" stopColor="#db2777"/>
        </linearGradient>
      </defs>
      <path
        d="M16 2L28 7.5V19C28 26 16 30 16 30C16 30 4 26 4 19V7.5L16 2Z"
        fill="url(#siG)"
      />
      <text
        x="16" y="21" textAnchor="middle"
        fontFamily="Inter,sans-serif" fontWeight="700"
        fontSize="10.5" fill="#fff" letterSpacing="-0.5"
      >SI</text>
    </svg>
  );
}

export default function Header({ sidebarOpen, setSidebarOpen, progress }) {
  return (
    <motion.header
      initial={{ y: -58, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 200,
        height: 56,
        background: '#000',
        borderBottom: '1px solid #1a1a1a',
        display: 'flex', alignItems: 'center',
        padding: '0 22px', gap: 16,
      }}
    >
      {/* Toggle */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        style={{
          width: 34, height: 34, borderRadius: 6,
          background: 'transparent', border: '1px solid #1e1e1e',
          color: '#444', cursor: 'pointer', flexShrink: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'border-color 0.15s, color 0.15s',
        }}
        onMouseEnter={e => { e.currentTarget.style.borderColor='#333'; e.currentTarget.style.color='#fff'; }}
        onMouseLeave={e => { e.currentTarget.style.borderColor='#1e1e1e'; e.currentTarget.style.color='#444'; }}
      >
        {sidebarOpen ? <X size={14}/> : <Menu size={14}/>}
      </button>

      {/* Logo */}
      <div style={{ display:'flex', alignItems:'center', gap:10, flexShrink:0 }}>
        <SILogoMark size={28}/>
        <div>
          <div style={{
            fontFamily:"'Inter',sans-serif", fontWeight:700, fontSize:14,
            color:'#fff', letterSpacing:'-0.02em', lineHeight:1.2,
          }}>
            Security Impossible
          </div>
          <div style={{
            fontFamily:"'DM Mono',monospace", fontSize:9,
            color:'#2e2e2e', letterSpacing:'0.11em', marginTop:1,
          }}>
            SECURITY & GOVERNANCE ONBOARDING
          </div>
        </div>
      </div>

      {/* Separator */}
      <div style={{ width:1, height:18, background:'#1e1e1e', flexShrink:0 }}/>

      {/* Breadcrumb */}
      <span style={{
        fontFamily:"'DM Mono',monospace", fontSize:11,
        color:'#2e2e2e', letterSpacing:'0.03em',
      }}>
        Onboarding v2.0
      </span>

      <div style={{ flex:1 }}/>

      {/* Progress pill */}
      <div style={{
        display:'flex', alignItems:'center', gap:10,
        height:34, padding:'0 14px',
        background:'#0c0c0c', border:'1px solid #1e1e1e', borderRadius:6,
        marginRight:10,
      }}>
        <span style={{
          fontFamily:"'DM Mono',monospace", fontSize:10,
          color:'#2e2e2e', letterSpacing:'0.07em',
        }}>PROGRESS</span>
        <div style={{ width:80, height:2, background:'#1a1a1a', borderRadius:1, overflow:'hidden' }}>
          <motion.div
            initial={{ width:0 }}
            animate={{ width:`${progress}%` }}
            transition={{ duration:1.1, delay:0.5, ease:[0.16,1,0.3,1] }}
            style={{
              height:'100%', borderRadius:1,
              background: progress === 100 ? '#22c55e' : 'linear-gradient(90deg,#7c3aed,#9333ea)',
            }}
          />
        </div>
        <span style={{
          fontFamily:"'DM Mono',monospace", fontSize:11, fontWeight:500,
          color: progress === 100 ? '#22c55e' : '#d4d4d4',
          minWidth:28, textAlign:'right',
        }}>{progress}%</span>
      </div>

      {/* User chip */}
      <div style={{
        display:'flex', alignItems:'center', gap:9,
        height:34, padding:'0 12px',
        background:'#0c0c0c', border:'1px solid #1e1e1e', borderRadius:6,
        cursor:'pointer',
      }}>
        <div style={{
          width:22, height:22, borderRadius:'50%',
          background:'linear-gradient(135deg,#7c3aed,#db2777)',
          display:'flex', alignItems:'center', justifyContent:'center',
          fontSize:10, fontWeight:700, color:'#fff', fontFamily:'Inter,sans-serif',
        }}>N</div>
        <span style={{
          fontFamily:"'Inter',sans-serif", fontSize:13,
          color:'#555', letterSpacing:'-0.01em',
        }}>New Employee</span>
      </div>
    </motion.header>
  );
}
