import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, ArrowLeft, ArrowRight, ClipboardList, Check, Lock } from 'lucide-react';
import Header from './components/Header.jsx';
import Sidebar from './components/Sidebar.jsx';
import ModuleContent from './components/ModuleContent.jsx';
import ByteAssistant from './components/ByteAssistant.jsx';
import { ALL_MODULES } from './modules/moduleData.js';

const STORAGE_KEY = 'si_onboarding_v5';
const load = () => { try { return JSON.parse(localStorage.getItem(STORAGE_KEY)||'{}'); } catch { return {}; } };
const save = s => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(s)); } catch {} };

/* ─── Typography constants ──────────────────────────────────────────────────── */
const T = {
  h1:   { fontFamily:"'Inter',sans-serif", fontWeight:700, fontSize:26, color:'#fff', letterSpacing:'-0.025em', lineHeight:1.22 },
  h2:   { fontFamily:"'Inter',sans-serif", fontWeight:600, fontSize:18, color:'#fff', letterSpacing:'-0.02em'  },
  body: { fontFamily:"'Inter',sans-serif", fontSize:15,   color:'#d4d4d4', lineHeight:1.7 },
  sm:   { fontFamily:"'Inter',sans-serif", fontSize:13,   color:'#909090' },
  mono: { fontFamily:"'DM Mono',monospace",fontSize:10.5, color:'#2e2e2e', letterSpacing:'0.07em' },
  tag:  { fontFamily:"'DM Mono',monospace",fontSize:10,   color:'#2e2e2e', letterSpacing:'0.08em' },
};

/* ─── Module hero ───────────────────────────────────────────────────────────── */
function ModuleHero({ mod, isComplete }) {
  const hasPol = mod.policyAck?.length > 0;
  return (
    <div style={{
      padding:'32px 36px 30px',
      background:'#0c0c0c',
      border:'1px solid #1e1e1e',
      borderRadius:8,
      marginBottom:20,
    }}>
      {/* Tag row */}
      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:18, flexWrap:'wrap' }}>
        <span className="tag tag-default">Module {String(mod.id).padStart(2,'0')}</span>
        <span className="tag tag-default">{mod.duration}</span>
        {isComplete  && <span className="tag tag-green">✓ Complete</span>}
        {hasPol && !isComplete && <span className="tag tag-amber">Acknowledgement required</span>}
      </div>

      {/* Title */}
      <h1 style={{ ...T.h1, marginBottom:6 }}>{mod.title}</h1>

      {/* Maps to */}
      <p style={{ ...T.mono, fontSize:11, marginBottom:22, color:'#333' }}>
        {mod.subtitle}
      </p>

      <div style={{ height:1, background:'#1a1a1a', marginBottom:22 }}/>

      {/* Objectives */}
      <div>
        <div style={{ ...T.tag, marginBottom:12 }}>LEARNING OBJECTIVES</div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'10px 28px' }}>
          {mod.keyPoints.map((kp, i) => (
            <div key={i} style={{ display:'flex', alignItems:'flex-start', gap:10 }}>
              <div style={{
                width:5, height:5, borderRadius:'50%', background:'#7c3aed',
                marginTop:8, flexShrink:0,
              }}/>
              <span style={{ ...T.body, fontSize:13.5, color:'#909090' }}>{kp}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── Module complete banner ────────────────────────────────────────────────── */
function CompleteBanner({ mod, hasNext, onNext }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', justifyContent:'space-between', gap:16,
      padding:'16px 22px',
      background:'#0c0c0c', border:'1px solid #1c3a1c', borderRadius:8,
      marginBottom:20,
    }}>
      <div style={{ display:'flex', alignItems:'center', gap:12 }}>
        <div style={{
          width:34, height:34, borderRadius:6, flexShrink:0,
          background:'rgba(34,197,94,0.08)', border:'1px solid rgba(34,197,94,0.18)',
          display:'flex', alignItems:'center', justifyContent:'center',
        }}>
          <Check size={15} color="#22c55e" strokeWidth={2.5}/>
        </div>
        <div>
          <div style={{ fontFamily:"'Inter',sans-serif", fontWeight:600, fontSize:14, color:'#fff', marginBottom:2 }}>
            Module {mod.id} complete
          </div>
          <div style={{ ...T.sm }}>
            {hasNext
              ? 'Your progress has been saved. Continue when ready.'
              : 'You have completed all 11 modules.'}
          </div>
        </div>
      </div>
      {hasNext && (
        <button onClick={onNext} style={{
          display:'flex', alignItems:'center', gap:7,
          padding:'8px 18px', borderRadius:6,
          background:'rgba(34,197,94,0.08)', border:'1px solid rgba(34,197,94,0.20)',
          color:'#22c55e', fontFamily:"'Inter',sans-serif", fontSize:13, fontWeight:600,
          cursor:'pointer', flexShrink:0, transition:'background 0.15s',
        }}
          onMouseEnter={e => e.currentTarget.style.background='rgba(34,197,94,0.14)'}
          onMouseLeave={e => e.currentTarget.style.background='rgba(34,197,94,0.08)'}
        >
          Next module <ArrowRight size={14}/>
        </button>
      )}
    </div>
  );
}

/* ─── Policy acknowledgement + completion gate ──────────────────────────────── *
 * Placed at the very bottom, after all content.                                 *
 * Modules with policyAck entries must have all boxes ticked before the          *
 * "Mark Complete" button enables — same UX as a T&C acceptance flow.            */
function ModuleFooterGate({ mod, isComplete, ackedPolicies, onAck, onComplete }) {
  if (isComplete) return null;

  const hasPol     = mod.policyAck?.length > 0;
  const allAcked   = !hasPol || mod.policyAck.every(p => ackedPolicies?.includes(`${mod.id}-${p}`));
  const ackedCount = hasPol
    ? mod.policyAck.filter(p => ackedPolicies?.includes(`${mod.id}-${p}`)).length
    : 0;

  return (
    <div style={{
      marginTop:28,
      border:'1px solid #1e1e1e',
      borderRadius:8, overflow:'hidden',
      background:'#0c0c0c',
    }}>
      {/* Section header */}
      <div style={{
        padding:'11px 22px',
        background:'#111', borderBottom:'1px solid #141414',
        display:'flex', alignItems:'center', gap:8,
      }}>
        <ClipboardList size={13} color="#333"/>
        <span style={{ ...T.mono, color:'#333' }}>
          {hasPol ? 'POLICY ACKNOWLEDGEMENT & COMPLETION' : 'MODULE COMPLETION'}
        </span>
      </div>

      <div style={{ padding:'24px 22px' }}>

        {/* ── Acknowledgement checkboxes ── */}
        {hasPol && (
          <div style={{ marginBottom:24 }}>
            <p style={{ ...T.body, fontSize:14, marginBottom:18 }}>
              Before completing this module, please read and acknowledge each of the following
              {' '}<strong style={{ color:'#fff', fontWeight:600 }}>Security Impossible policies</strong>.
              {' '}All boxes must be ticked to proceed.
            </p>

            <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:14 }}>
              {mod.policyAck.map(pol => {
                const key    = `${mod.id}-${pol}`;
                const ticked = ackedPolicies?.includes(key);
                return (
                  <label
                    key={pol}
                    style={{
                      display:'flex', alignItems:'flex-start', gap:14,
                      padding:'14px 16px', borderRadius:6,
                      background: ticked ? 'rgba(34,197,94,0.04)' : '#111',
                      border:`1px solid ${ticked ? 'rgba(34,197,94,0.22)' : '#1e1e1e'}`,
                      cursor:'pointer', userSelect:'none',
                      transition:'border-color 0.18s, background 0.18s',
                    }}
                  >
                    {/* Checkbox */}
                    <div style={{
                      width:20, height:20, borderRadius:4,
                      flexShrink:0, marginTop:2, position:'relative',
                      background: ticked ? '#22c55e' : 'transparent',
                      border:`1.5px solid ${ticked ? '#22c55e' : '#2a2a2a'}`,
                      display:'flex', alignItems:'center', justifyContent:'center',
                      transition:'all 0.16s',
                    }}>
                      <input
                        type="checkbox"
                        checked={!!ticked}
                        onChange={() => onAck(key)}
                        style={{
                          position:'absolute', inset:0, opacity:0,
                          cursor:'pointer', width:'100%', height:'100%', margin:0,
                        }}
                      />
                      {ticked && (
                        <svg width="11" height="11" viewBox="0 0 11 11" fill="none">
                          <polyline points="1.5,5.5 4.5,8.5 9.5,2.5"
                            stroke="#fff" strokeWidth="1.8"
                            strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      )}
                    </div>

                    {/* Text */}
                    <div style={{ flex:1 }}>
                      <div style={{
                        fontFamily:"'Inter',sans-serif", fontSize:14, fontWeight:500,
                        color: ticked ? '#fff' : '#d4d4d4',
                        lineHeight:1.4, marginBottom:4,
                      }}>
                        I have read and understood the{' '}
                        <span style={{
                          fontWeight:600,
                          color: ticked ? '#22c55e' : '#8b5cf6',
                        }}>{pol}</span>
                      </div>
                      <div style={{ fontFamily:"'Inter',sans-serif", fontSize:13, color:'#555', lineHeight:1.5 }}>
                        I agree to comply with the obligations set out in this policy.
                      </div>
                    </div>

                    {ticked && (
                      <Check size={15} color="#22c55e" strokeWidth={2.5}
                        style={{ flexShrink:0, marginTop:3 }}/>
                    )}
                  </label>
                );
              })}
            </div>

            {/* Count */}
            {!allAcked && (
              <p style={{ ...T.sm, fontSize:12, color:'#333' }}>
                {ackedCount} of {mod.policyAck.length} acknowledged
              </p>
            )}

            <div style={{ height:1, background:'#141414', marginTop:20 }}/>
          </div>
        )}

        {/* ── Complete row ── */}
        <div style={{
          display:'flex', alignItems:'center',
          justifyContent:'space-between', gap:16,
          marginTop: hasPol ? 20 : 0,
        }}>
          <div>
            <div style={{
              fontFamily:"'Inter',sans-serif", fontWeight:600, fontSize:15,
              color: allAcked ? '#fff' : '#3a3a3a', marginBottom:4,
            }}>
              {allAcked
                ? `Mark Module ${mod.id} as complete`
                : hasPol
                  ? 'Acknowledge all policies above to continue'
                  : `Mark Module ${mod.id} as complete`}
            </div>
            <div style={{ fontFamily:"'Inter',sans-serif", fontSize:13, color:'#555' }}>
              {allAcked
                ? 'Your progress will be saved and the next module will unlock.'
                : hasPol
                  ? 'Every checkbox must be ticked before you can mark this module complete.'
                  : 'Work through the content above, then mark complete to unlock the next module.'}
            </div>
          </div>

          <button
            disabled={!allAcked}
            onClick={allAcked ? onComplete : undefined}
            style={{
              flexShrink:0, padding:'11px 24px', borderRadius:6,
              fontFamily:"'Inter',sans-serif", fontSize:14, fontWeight:600,
              cursor: allAcked ? 'pointer' : 'not-allowed',
              display:'flex', alignItems:'center', gap:8,
              transition:'background 0.15s, box-shadow 0.15s',
              ...(allAcked ? {
                background:'#7c3aed',
                border:'1px solid #6d28d9',
                color:'#fff',
                boxShadow:'0 1px 8px rgba(124,58,237,0.35)',
              } : {
                background:'transparent',
                border:'1px solid #1e1e1e',
                color:'#2e2e2e',
              }),
            }}
            onMouseEnter={e => { if(allAcked){ e.currentTarget.style.background='#6d28d9'; }}}
            onMouseLeave={e => { if(allAcked){ e.currentTarget.style.background='#7c3aed'; }}}
          >
            {allAcked
              ? <><CheckCircle size={15}/> Mark Complete</>
              : <><Lock size={13}/> Acknowledgements required</>}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Completion certificate ────────────────────────────────────────────────── */
function AllComplete({ onBack }) {
  return (
    <div style={{ maxWidth:620, margin:'0 auto', padding:'52px 24px' }}>
      <div style={{
        padding:'44px 48px', textAlign:'center',
        background:'#0c0c0c', border:'1px solid #1c3a1c', borderRadius:8,
      }}>
        <div style={{
          width:56, height:56, borderRadius:8, margin:'0 auto 24px',
          background:'rgba(34,197,94,0.08)', border:'1px solid rgba(34,197,94,0.20)',
          display:'flex', alignItems:'center', justifyContent:'center',
        }}>
          <Check size={26} color="#22c55e" strokeWidth={2}/>
        </div>

        <h1 style={{ ...T.h1, fontSize:28, marginBottom:12, textAlign:'center' }}>
          Training Complete
        </h1>
        <p style={{ ...T.body, fontSize:14, color:'#666', maxWidth:400, margin:'0 auto 28px', textAlign:'center' }}>
          You have completed all 11 modules of the Security Impossible Security &amp;
          Governance Onboarding Course. Your obligations begin now and survive your employment.
        </p>

        {/* Record table */}
        <div style={{
          padding:'16px 20px', background:'#111',
          border:'1px solid #1e1e1e', borderRadius:6,
          textAlign:'left', marginBottom:22,
          fontFamily:"'DM Mono',monospace", fontSize:11.5, lineHeight:2.3,
        }}>
          {[
            ['PROGRAM', 'Security & Governance Onboarding v2'],
            ['MODULES', '11 / 11 Complete'],
            ['DATE',    new Date().toLocaleDateString('en-AU',{day:'numeric',month:'long',year:'numeric'})],
            ['STATUS',  '✓ COMMITTED'],
          ].map(([k,v]) => (
            <div key={k} style={{ display:'flex', gap:20 }}>
              <span style={{ color:'#252525', minWidth:70 }}>{k}</span>
              <span style={{ color: k==='STATUS' ? '#22c55e' : '#777' }}>{v}</span>
            </div>
          ))}
        </div>

        {/* Next step note */}
        <div style={{
          padding:'12px 16px', textAlign:'left',
          background:'rgba(245,158,11,0.05)', border:'1px solid rgba(245,158,11,0.14)',
          borderRadius:6, marginBottom:24,
          fontFamily:"'Inter',sans-serif", fontSize:13, color:'#777', lineHeight:1.65,
        }}>
          <strong style={{ color:'#f59e0b', fontWeight:600 }}>Next step:</strong>{' '}
          Sign the Employee Confidentiality &amp; IP Deed with your manager to finalise
          your onboarding record.
        </div>

        <button onClick={onBack} style={{
          fontFamily:"'Inter',sans-serif", fontSize:13, color:'#555',
          background:'transparent', border:'1px solid #1e1e1e',
          borderRadius:6, padding:'8px 18px', cursor:'pointer',
          transition:'border-color 0.15s, color 0.15s',
        }}
          onMouseEnter={e => { e.currentTarget.style.borderColor='#333'; e.currentTarget.style.color='#d4d4d4'; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor='#1e1e1e'; e.currentTarget.style.color='#555'; }}
        >← Review modules</button>
      </div>
    </div>
  );
}

/* ─── Root app ──────────────────────────────────────────────────────────────── */
export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentId,   setCurrentId]   = useState(1);
  const [state,       setState]       = useState(load);
  const [showAll,     setShowAll]     = useState(false);

  useEffect(() => { save(state); }, [state]);

  const mod           = ALL_MODULES.find(m => m.id === currentId);
  const completedSet  = new Set(Object.keys(state.completed||{}).map(Number).filter(id => state.completed[id]));
  const allDone       = completedSet.size === ALL_MODULES.length;
  const isComplete    = completedSet.has(currentId);
  const modState      = state.modules?.[currentId] || {};
  const ackedPolicies = state.ackedPolicies || [];
  const progress      = Math.round((completedSet.size / ALL_MODULES.length) * 100);
  const nextMod       = ALL_MODULES.find(m => m.id === currentId + 1);
  const prevMod       = ALL_MODULES.find(m => m.id === currentId - 1);

  function setModState(key, val) {
    setState(s => ({
      ...s,
      modules: { ...(s.modules||{}), [currentId]: { ...(s.modules?.[currentId]||{}), [key]: val } },
    }));
  }
  function completeModule(id) {
    setState(s => ({ ...s, completed: { ...(s.completed||{}), [id]: true } }));
  }
  function ackPolicy(key) {
    setState(s => {
      const cur = s.ackedPolicies || [];
      return { ...s, ackedPolicies: cur.includes(key) ? cur.filter(k=>k!==key) : [...cur, key] };
    });
  }
  function goTo(id) {
    setCurrentId(id);
    setShowAll(false);
    window.scrollTo({ top:0, behavior:'smooth' });
  }

  if (showAll) {
    return (
      <div style={{ minHeight:'100vh', background:'#000' }}>
        <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} progress={progress}/>
        <div style={{ paddingTop:56 }}>
          <AllComplete onBack={() => setShowAll(false)}/>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight:'100vh', background:'#000', fontFamily:"'Inter',sans-serif" }}>
      <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} progress={progress}/>
      <Sidebar
        open={sidebarOpen}
        currentModuleId={currentId}
        completedModules={[...completedSet]}
        onNavigate={goTo}
      />

      {/* Main — shifts right when sidebar open */}
      <motion.main
        animate={{ paddingLeft: sidebarOpen ? 260 : 0 }}
        transition={{ duration:0.24, ease:[0.16,1,0.3,1] }}
        style={{ paddingTop:56, minHeight:'100vh' }}
      >
        {/* Module tab strip */}
        <div style={{
          position:'sticky', top:56, zIndex:100,
          background:'#000', borderBottom:'1px solid #111',
          padding:'0 22px',
          display:'flex', alignItems:'center', gap:0,
          overflowX:'auto',
        }}>
          {ALL_MODULES.map(m => {
            const isDone   = completedSet.has(m.id);
            const active   = m.id === currentId;
            const unlocked = m.id===1 || isDone || completedSet.has(m.id-1);
            return (
              <button key={m.id}
                onClick={() => unlocked && goTo(m.id)}
                title={m.title}
                style={{
                  padding:'0 2px', height:40, flexShrink:0,
                  marginRight:12, border:'none',
                  borderBottom:`2px solid ${active ? '#8b5cf6' : 'transparent'}`,
                  background:'transparent',
                  fontFamily:"'DM Mono',monospace", fontSize:10.5, fontWeight:500,
                  color: active ? '#d4d4d4' : isDone ? '#252525' : unlocked ? '#252525' : '#181818',
                  cursor: unlocked ? 'pointer' : 'default',
                  transition:'color 0.12s',
                  display:'flex', alignItems:'center', gap:4, paddingBottom:2,
                }}
                onMouseEnter={e => { if(unlocked&&!active) e.currentTarget.style.color='#555'; }}
                onMouseLeave={e => { if(!active) e.currentTarget.style.color = isDone?'#252525':unlocked?'#252525':'#181818'; }}
              >
                {isDone && <Check size={9} color="#22c55e" strokeWidth={2.5}/>}
                {String(m.id).padStart(2,'0')}
              </button>
            );
          })}
          <div style={{ flex:1 }}/>
          <span style={{ fontFamily:"'DM Mono',monospace", fontSize:10, color:'#1e1e1e', flexShrink:0 }}>
            {completedSet.size}/{ALL_MODULES.length}
          </span>
        </div>

        {/* Page body */}
        <div style={{ maxWidth:840, margin:'0 auto', padding:'28px 22px 64px' }}>
          <AnimatePresence mode="wait">
            <motion.div
              key={currentId}
              initial={{ opacity:0, y:8 }}
              animate={{ opacity:1, y:0 }}
              exit={{ opacity:0, y:-8 }}
              transition={{ duration:0.22 }}
            >
              <ModuleHero mod={mod} isComplete={isComplete}/>

              {isComplete && (
                <CompleteBanner
                  mod={mod} hasNext={!!nextMod}
                  onNext={() => nextMod && goTo(nextMod.id)}
                />
              )}

              <ModuleContent
                module={mod}
                scenarioDone={modState.scenarioDone || false}
                quizDone={modState.quizDone || false}
                onScenarioDone={() => setModState('scenarioDone', true)}
                onQuizDone={() => setModState('quizDone', true)}
              />

              <ModuleFooterGate
                mod={mod} isComplete={isComplete}
                ackedPolicies={ackedPolicies}
                onAck={ackPolicy}
                onComplete={() => {
                  completeModule(currentId);
                  window.scrollTo({ top:0, behavior:'smooth' });
                }}
              />

              {/* Prev / Next navigation */}
              <div style={{
                display:'flex', justifyContent:'space-between', alignItems:'center',
                marginTop:24, paddingTop:20, borderTop:'1px solid #111',
              }}>
                <div>
                  {prevMod && (
                    <button onClick={() => goTo(prevMod.id)} style={{
                      display:'flex', alignItems:'center', gap:7,
                      padding:'7px 14px', borderRadius:6,
                      background:'transparent', border:'1px solid #1e1e1e',
                      color:'#555', fontFamily:"'Inter',sans-serif", fontSize:13,
                      cursor:'pointer', transition:'border-color 0.15s, color 0.15s',
                    }}
                      onMouseEnter={e => { e.currentTarget.style.borderColor='#2a2a2a'; e.currentTarget.style.color='#d4d4d4'; }}
                      onMouseLeave={e => { e.currentTarget.style.borderColor='#1e1e1e'; e.currentTarget.style.color='#555'; }}
                    >
                      <ArrowLeft size={13}/> Module {prevMod.id}
                    </button>
                  )}
                </div>

                <span style={{ fontFamily:"'DM Mono',monospace", fontSize:10, color:'#1e1e1e' }}>
                  {mod.id} / {ALL_MODULES.length}
                </span>

                <div style={{ display:'flex', gap:8 }}>
                  {nextMod && isComplete && (
                    <button onClick={() => goTo(nextMod.id)} style={{
                      display:'flex', alignItems:'center', gap:7,
                      padding:'7px 14px', borderRadius:6,
                      background:'transparent', border:'1px solid #1e1e1e',
                      color:'#555', fontFamily:"'Inter',sans-serif", fontSize:13,
                      cursor:'pointer', transition:'border-color 0.15s, color 0.15s',
                    }}
                      onMouseEnter={e => { e.currentTarget.style.borderColor='#2a2a2a'; e.currentTarget.style.color='#d4d4d4'; }}
                      onMouseLeave={e => { e.currentTarget.style.borderColor='#1e1e1e'; e.currentTarget.style.color='#555'; }}
                    >
                      Module {nextMod.id} <ArrowRight size={13}/>
                    </button>
                  )}
                  {allDone && !nextMod && (
                    <button onClick={() => setShowAll(true)} style={{
                      padding:'7px 16px', borderRadius:6,
                      background:'#7c3aed', border:'1px solid #6d28d9',
                      color:'#fff', fontFamily:"'Inter',sans-serif", fontSize:13, fontWeight:600,
                      cursor:'pointer',
                    }}>
                      View certificate →
                    </button>
                  )}
                </div>
              </div>

              {/* All done inline banner */}
              {allDone && (
                <motion.div
                  initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }}
                  transition={{ delay:0.25 }}
                  style={{
                    marginTop:18, padding:'16px 20px',
                    background:'#0c0c0c', border:'1px solid #1c3a1c', borderRadius:6,
                    display:'flex', alignItems:'center', justifyContent:'space-between', gap:16,
                  }}
                >
                  <div>
                    <div style={{ fontFamily:"'Inter',sans-serif", fontWeight:600, fontSize:14, color:'#fff', marginBottom:3 }}>
                      All 11 modules complete
                    </div>
                    <div style={{ fontFamily:"'Inter',sans-serif", fontSize:13, color:'#555' }}>
                      Sign the Employee Confidentiality &amp; IP Deed with your manager to finalise onboarding.
                    </div>
                  </div>
                  <button onClick={() => setShowAll(true)} style={{
                    padding:'7px 16px', borderRadius:6, flexShrink:0,
                    background:'rgba(34,197,94,0.08)', border:'1px solid rgba(34,197,94,0.20)',
                    color:'#22c55e', fontFamily:"'Inter',sans-serif", fontSize:13, fontWeight:600,
                    cursor:'pointer',
                  }}>
                    View certificate →
                  </button>
                </motion.div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </motion.main>

      <ByteAssistant currentSection={`module-${currentId}`}/>
    </div>
  );
}
