import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { LAB_META, TASK_ORDER, TASKS, initialSite } from './data/scenario.js';
import { isTaskDone } from './data/siteLogic.js';
import Linkup from './components/Linkup.jsx';
import Byte from './components/Byte.jsx';

const STORE_KEY = LAB_META.storeKey;

const emptyProgress = () => ({
  site: initialSite(),
  currentTask: 0,      // index into TASK_ORDER; === length means all done
  completed: {},       // taskId -> true (locked in)
  byteOpen: true,
  introSeen: false,
  view: 'profile',     // which Linkup tab is showing
});

function load() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) {
      const p = JSON.parse(raw);
      return { ...emptyProgress(), ...p, site: { ...initialSite(), ...(p.site || {}) } };
    }
  } catch (e) { /* ignore */ }
  return emptyProgress();
}

export default function App() {
  const [state, setState] = useState(load);

  useEffect(() => {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) { /* ignore */ }
  }, [state]);

  const setSite = useCallback((updater) => {
    setState((s) => ({ ...s, site: typeof updater === 'function' ? updater(s.site) : updater }));
  }, []);

  const patch = useCallback((p) => setState((s) => ({ ...s, ...p })), []);

  const setView = useCallback((view) => setState((s) => ({ ...s, view })), []);

  const reset = useCallback(() => {
    if (!window.confirm('Reset the lab and start over?')) return;
    const fresh = emptyProgress();
    setState(fresh);
    try { localStorage.setItem(STORE_KEY, JSON.stringify(fresh)); } catch (e) { /* ignore */ }
  }, []);

  // Which task is active right now?
  const activeTaskId = TASK_ORDER[state.currentTask] || null;
  const activeTask = TASKS.find((t) => t.id === activeTaskId) || null;

  // Is the active task's goal satisfied by current site state?
  const activeDone = activeTaskId ? isTaskDone(activeTaskId, state.site) : false;

  // Advance to the next task (called by Byte's "Next" once activeDone).
  const advance = useCallback(() => {
    setState((s) => {
      const id = TASK_ORDER[s.currentTask];
      if (!id) return s;
      if (!isTaskDone(id, s.site)) return s; // gate
      return { ...s, completed: { ...s.completed, [id]: true }, currentTask: s.currentTask + 1 };
    });
  }, []);

  const allDone = state.currentTask >= TASK_ORDER.length;

  return (
    <div style={{ minHeight: '100vh' }}>
      <Linkup
        site={state.site}
        setSite={setSite}
        view={state.view}
        setView={setView}
        activeTaskId={activeTaskId}
        completed={state.completed}
      />
      <Byte
        state={state}
        patch={patch}
        reset={reset}
        activeTask={activeTask}
        activeDone={activeDone}
        advance={advance}
        allDone={allDone}
        setView={setView}
      />
    </div>
  );
}
