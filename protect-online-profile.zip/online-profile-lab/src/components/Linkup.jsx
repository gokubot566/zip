import React, { useState } from 'react';
import { ACCOUNT } from '../data/scenario.js';
import { isStrongPassword } from '../data/siteLogic.js';
import {
  Home, User, MessageCircle, Bell, Search, Settings, Shield,
  MonitorSmartphone, Grid3x3, Receipt, Globe, Lock, Users, Trash2,
  AlertTriangle, Check, MoreHorizontal, LogOut, ThumbsUp, MessageSquare, Share2,
} from 'lucide-react';

/* ============================================================
   Linkup — a realistic social platform (full screen).
   No lab chrome; the trainee performs real fixes here.
   ============================================================ */

const NAV = [
  { id: 'feed', label: 'Home', icon: Home },
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'messages', label: 'Messages', icon: MessageCircle },
  { id: 'security', label: 'Settings', icon: Settings },
  { id: 'sessions', label: 'Login activity', icon: MonitorSmartphone },
  { id: 'apps', label: 'Connected apps', icon: Grid3x3 },
  { id: 'activity', label: 'Account activity', icon: Receipt },
];

// map internal task "where" values to nav ids
const VIEW_ALIAS = { messages: 'messages', security: 'security', profile: 'profile', activity: 'activity', apps: 'apps' };

export default function Linkup({ site, setSite, view, setView, activeTaskId, completed }) {
  const nav = VIEW_ALIAS[view] || view;
  return (
    <div style={{ background: 'var(--lk-bg)', minHeight: '100vh', color: 'var(--lk-text)' }}>
      <style>{LINKUP_CSS}</style>

      {/* top bar */}
      <header className="lk-top">
        <div className="lk-top-inner">
          <div className="lk-brand">
            <div className="lk-logo">in</div>
            <span className="lk-brandname">Linkup</span>
          </div>
          <div className="lk-search">
            <Search size={16} />
            <input placeholder="Search Linkup" />
          </div>
          <div className="lk-topicons">
            <button className="lk-iconbtn"><Home size={20} /></button>
            <button className="lk-iconbtn"><Bell size={20} /><span className="lk-dot">3</span></button>
            <button className="lk-iconbtn"><MessageCircle size={20} /><span className="lk-dot">2</span></button>
            <div className="lk-avatar-sm">{ACCOUNT.initials}</div>
          </div>
        </div>
      </header>

      <div className="lk-shell">
        {/* left nav */}
        <aside className="lk-left">
          <div className="lk-profilecard">
            <div className="lk-cover" />
            <div className="lk-avatar-lg">{ACCOUNT.initials}</div>
            <div className="lk-name">{ACCOUNT.name}</div>
            <div className="lk-handle">{ACCOUNT.handle}</div>
            <div className="lk-bio">{ACCOUNT.bio}</div>
          </div>
          <nav className="lk-nav">
            {NAV.map((n) => {
              const Icon = n.icon;
              const active = nav === n.id;
              return (
                <button key={n.id} className={`lk-navitem ${active ? 'active' : ''}`} onClick={() => setView(n.id)}>
                  <Icon size={19} /> <span>{n.label}</span>
                </button>
              );
            })}
          </nav>
          <div className="lk-footlinks">Privacy · Terms · Help · © 2026 Linkup (demo)</div>
        </aside>

        {/* main column */}
        <main className="lk-main">
          {nav === 'feed' && <Feed />}
          {nav === 'profile' && <Profile site={site} setSite={setSite} />}
          {nav === 'messages' && <Messages site={site} setSite={setSite} />}
          {nav === 'security' && <SecuritySettings site={site} setSite={setSite} />}
          {nav === 'sessions' && <Sessions site={site} setSite={setSite} />}
          {nav === 'apps' && <ConnectedApps site={site} setSite={setSite} />}
          {nav === 'activity' && <Activity site={site} setSite={setSite} />}
        </main>
      </div>
    </div>
  );
}

/* ---------- FEED ---------- */
function Feed() {
  const posts = [
    { who: 'Riverton College', when: '2h', text: 'Enrolments for semester 2 electives close Friday. Don’t miss out!', likes: 34, comments: 5 },
    { who: 'Sam', when: '5h', text: 'that new sci-fi film is actually really good, who’s in for friday', likes: 12, comments: 3 },
    { who: 'Campus Music Society', when: '1d', text: 'Open mic night next Thursday — sign up at the SU desk 🎸', likes: 58, comments: 9 },
  ];
  return (
    <div className="lk-col">
      <div className="lk-composer">
        <div className="lk-avatar-sm">{ACCOUNT.initials}</div>
        <div className="lk-composer-input">What’s on your mind, Jordan?</div>
      </div>
      {posts.map((p, i) => (
        <article key={i} className="lk-post">
          <div className="lk-post-head">
            <div className="lk-avatar-sm alt">{p.who[0]}</div>
            <div><div className="lk-post-who">{p.who}</div><div className="lk-post-when">{p.when} · <Globe size={11} /></div></div>
          </div>
          <div className="lk-post-text">{p.text}</div>
          <div className="lk-post-actions">
            <button><ThumbsUp size={16} /> {p.likes}</button>
            <button><MessageSquare size={16} /> {p.comments}</button>
            <button><Share2 size={16} /> Share</button>
          </div>
        </article>
      ))}
    </div>
  );
}

/* ---------- PROFILE (task 1) ---------- */
const VIS = [
  { v: 'public', label: 'Public', icon: Globe },
  { v: 'friends', label: 'Friends only', icon: Users },
  { v: 'private', label: 'Only me', icon: Lock },
];
function VisPicker({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const cur = VIS.find((x) => x.v === value) || VIS[0];
  const Icon = cur.icon;
  return (
    <div className="lk-vis">
      <button className={`lk-vis-btn ${value === 'public' ? 'warn' : 'ok'}`} onClick={() => setOpen((o) => !o)}>
        <Icon size={13} /> {cur.label} <span className="lk-caret">▾</span>
      </button>
      {open && (
        <div className="lk-vis-menu" onMouseLeave={() => setOpen(false)}>
          {VIS.map((o) => {
            const OIcon = o.icon;
            return (
              <button key={o.v} onClick={() => { onChange(o.v); setOpen(false); }} className={o.v === value ? 'sel' : ''}>
                <OIcon size={14} /> {o.label}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
function Profile({ site, setSite }) {
  const setVis = (field, v) => setSite((s) => ({ ...s, visibility: { ...s.visibility, [field]: v } }));
  const rows = [
    ['dob', 'Date of birth', ACCOUNT.dob],
    ['mobile', 'Mobile', ACCOUNT.mobile],
    ['suburb', 'Home suburb', ACCOUNT.suburb],
    ['school', 'School', ACCOUNT.school],
  ];
  return (
    <div className="lk-col">
      <SectionTitle icon={User} title="Profile" sub="What people can see about you, and who can see it." />
      <div className="lk-card">
        <div className="lk-about-head">About</div>
        {rows.map(([key, label, val]) => (
          <div key={key} className="lk-about-row">
            <div><div className="lk-about-label">{label}</div><div className="lk-about-val">{val}</div></div>
            <VisPicker value={site.visibility[key]} onChange={(v) => setVis(key, v)} />
          </div>
        ))}
        <div className="lk-about-row">
          <div><div className="lk-about-label">Email</div><div className="lk-about-val">{ACCOUNT.email}</div></div>
          <span className="lk-vis-btn ok" style={{ cursor: 'default' }}><Lock size={13} /> Only me</span>
        </div>
      </div>

      <div className="lk-card">
        <div className="lk-about-head">Your posts</div>
        {!site.awayPostDeleted ? (
          <PostRow
            text="So excited — away on holiday all next week! House to myself when I’m back 🎉"
            when="Yesterday"
            onDelete={() => setSite((s) => ({ ...s, awayPostDeleted: true }))}
          />
        ) : (
          <div className="lk-empty"><Check size={16} color="var(--good)" /> That post was deleted.</div>
        )}
        <PostRow text="Study playlist is carrying me through exams 🎧" when="4 days ago" />
      </div>
    </div>
  );
}
function PostRow({ text, when, onDelete }) {
  const [menu, setMenu] = useState(false);
  return (
    <div className="lk-postrow">
      <div className="lk-avatar-sm">{ACCOUNT.initials}</div>
      <div style={{ flex: 1 }}>
        <div className="lk-post-who">{ACCOUNT.name} <span className="lk-post-when">· {when} · <Globe size={11} /></span></div>
        <div className="lk-post-text" style={{ marginTop: 4 }}>{text}</div>
      </div>
      {onDelete && (
        <div className="lk-menu-wrap">
          <button className="lk-iconbtn sm" onClick={() => setMenu((m) => !m)}><MoreHorizontal size={18} /></button>
          {menu && (
            <div className="lk-vis-menu right" onMouseLeave={() => setMenu(false)}>
              <button onClick={onDelete} className="danger"><Trash2 size={14} /> Delete post</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ---------- MESSAGES (task 2) ---------- */
function Messages({ site, setSite }) {
  const [openId, setOpenId] = useState(null);
  const report = (id) => {
    setSite((s) => ({ ...s, messages: s.messages.map((m) => m.id === id ? { ...m, status: 'reported' } : m) }));
    setOpenId(null);
  };
  const inbox = site.messages.filter((m) => m.status === 'inbox');
  const open = site.messages.find((m) => m.id === openId);
  return (
    <div className="lk-col">
      <SectionTitle icon={MessageCircle} title="Messages" sub="Your inbox. Some messages aren’t what they claim to be." />
      <div className="lk-card lk-msglist">
        {inbox.length === 0 && <div className="lk-empty"><Check size={16} color="var(--good)" /> Inbox clear. Phishing reported.</div>}
        {inbox.map((m) => (
          <div key={m.id} className={`lk-msg ${m.phishing ? 'phish' : ''}`} onClick={() => setOpenId(m.id)}>
            <div className="lk-avatar-sm alt">{m.from[0]}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="lk-msg-from">{m.from} <span className="lk-msg-addr">&lt;{m.addr}&gt;</span></div>
              <div className="lk-msg-subj">{m.subject}</div>
            </div>
            <button className="lk-report" onClick={(e) => { e.stopPropagation(); report(m.id); }}>
              <AlertTriangle size={14} /> Report
            </button>
          </div>
        ))}
      </div>

      {open && (
        <div className="lk-modal-bg" onClick={() => setOpenId(null)}>
          <div className="lk-modal" onClick={(e) => e.stopPropagation()}>
            <div className="lk-msg-from" style={{ marginBottom: 2 }}>{open.from}</div>
            <div className="lk-msg-addr" style={{ marginBottom: 12 }}>&lt;{open.addr}&gt;</div>
            <div style={{ fontWeight: 700, marginBottom: 8 }}>{open.subject}</div>
            <p style={{ color: 'var(--lk-sub)', lineHeight: 1.6 }}>{open.body}</p>
            {open.phishing && <div className="lk-warnbar"><AlertTriangle size={15} /> This looks like phishing. Don’t click links or share your password — report it.</div>}
            <div style={{ display: 'flex', gap: 8, marginTop: 16, justifyContent: 'flex-end' }}>
              <button className="lk-btn" onClick={() => setOpenId(null)}>Close</button>
              <button className="lk-btn danger" onClick={() => report(open.id)}><AlertTriangle size={14} /> Report as phishing</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- SECURITY (tasks 3,4,5-recovery) ---------- */
function SecuritySettings({ site, setSite }) {
  const [pwOpen, setPwOpen] = useState(false);
  const [pw, setPw] = useState('');
  const [recOpen, setRecOpen] = useState(false);
  const [rec, setRec] = useState('');
  const strong = isStrongPassword(pw);

  const savePw = () => {
    if (!strong) return;
    setSite((s) => ({ ...s, password: pw, passwordStrong: true }));
    setPwOpen(false); setPw('');
  };
  const saveRec = () => {
    if (!/@/.test(rec) || /old-address/.test(rec)) return;
    setSite((s) => ({ ...s, recoveryEmail: rec, recoveryFixed: true }));
    setRecOpen(false); setRec('');
  };
  const setTwofa = (v) => setSite((s) => ({ ...s, twofa: v }));

  return (
    <div className="lk-col">
      <SectionTitle icon={Shield} title="Settings · Security" sub="Passwords, two-factor authentication, and account recovery." />

      {/* password */}
      <div className="lk-card lk-setrow">
        <div>
          <div className="lk-set-label">Password</div>
          <div className="lk-set-sub">{site.passwordStrong ? 'Strong, unique password set.' : 'Currently: ' + '•'.repeat(10) + ' — short and reused on other sites.'}</div>
        </div>
        {site.passwordStrong
          ? <span className="lk-badge ok"><Check size={13} /> Strong</span>
          : <button className="lk-btn" onClick={() => setPwOpen(true)}>Change password</button>}
      </div>

      {/* 2fa */}
      <div className="lk-card">
        <div className="lk-setrow" style={{ borderBottom: '1px solid var(--lk-line)' }}>
          <div>
            <div className="lk-set-label">Two-factor authentication</div>
            <div className="lk-set-sub">{site.twofa === 'off' ? 'Off — your password is the only thing protecting this account.' : site.twofa === 'app' ? 'On — using an authenticator app.' : 'On — using SMS text codes.'}</div>
          </div>
          <span className={`lk-badge ${site.twofa === 'app' ? 'ok' : site.twofa === 'sms' ? 'warn' : 'bad'}`}>
            {site.twofa === 'off' ? 'Off' : site.twofa === 'app' ? 'App' : 'SMS'}
          </span>
        </div>
        <div style={{ display: 'flex', gap: 8, padding: 14, flexWrap: 'wrap' }}>
          <button className={`lk-btn ${site.twofa === 'app' ? 'primary' : ''}`} onClick={() => setTwofa('app')}>Use authenticator app</button>
          <button className="lk-btn" onClick={() => setTwofa('sms')}>Use SMS</button>
          {site.twofa !== 'off' && <button className="lk-btn ghost" onClick={() => setTwofa('off')}>Turn off</button>}
        </div>
      </div>

      {/* recovery */}
      <div className="lk-card lk-setrow">
        <div>
          <div className="lk-set-label">Recovery email</div>
          <div className="lk-set-sub" style={{ color: site.recoveryFixed ? 'var(--lk-sub)' : 'var(--bad)' }}>
            {site.recoveryEmail}{!site.recoveryFixed && ' — you no longer control this inbox'}
          </div>
        </div>
        {site.recoveryFixed
          ? <span className="lk-badge ok"><Check size={13} /> Updated</span>
          : <button className="lk-btn" onClick={() => setRecOpen(true)}>Update</button>}
      </div>

      {/* change password modal */}
      {pwOpen && (
        <div className="lk-modal-bg" onClick={() => setPwOpen(false)}>
          <div className="lk-modal" onClick={(e) => e.stopPropagation()}>
            <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 12 }}>Change password</div>
            <input className="lk-input" type="text" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="New password or passphrase" autoFocus />
            <div className="lk-strength">
              <div className={`lk-strength-bar ${strong ? 'good' : pw.length > 0 ? 'weak' : ''}`} style={{ width: `${Math.min(100, pw.length * 7)}%` }} />
            </div>
            <div className="lk-set-sub" style={{ marginTop: 6, color: strong ? 'var(--good)' : 'var(--lk-sub)' }}>
              {pw.length === 0 ? 'Use 12+ characters. A few unrelated words work well. Don’t reuse an old one.'
                : strong ? '✓ Strong and unique.' : 'Too weak — make it longer and avoid the name/year.'}
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 16, justifyContent: 'flex-end' }}>
              <button className="lk-btn" onClick={() => setPwOpen(false)}>Cancel</button>
              <button className="lk-btn primary" disabled={!strong} onClick={savePw}>Save password</button>
            </div>
          </div>
        </div>
      )}

      {/* recovery modal */}
      {recOpen && (
        <div className="lk-modal-bg" onClick={() => setRecOpen(false)}>
          <div className="lk-modal" onClick={(e) => e.stopPropagation()}>
            <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 12 }}>Update recovery email</div>
            <input className="lk-input" type="email" value={rec} onChange={(e) => setRec(e.target.value)} placeholder="current-email@example.com" autoFocus />
            <div className="lk-set-sub" style={{ marginTop: 6 }}>Use an inbox you control today — this is your “forgot password” path.</div>
            <div style={{ display: 'flex', gap: 8, marginTop: 16, justifyContent: 'flex-end' }}>
              <button className="lk-btn" onClick={() => setRecOpen(false)}>Cancel</button>
              <button className="lk-btn primary" disabled={!/@/.test(rec) || /old-address/.test(rec)} onClick={saveRec}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- SESSIONS (task 5-sessions) ---------- */
function Sessions({ site, setSite }) {
  const signOut = (id) => setSite((s) => ({ ...s, sessions: s.sessions.map((x) => x.id === id ? { ...x, active: false } : x) }));
  return (
    <div className="lk-col">
      <SectionTitle icon={MonitorSmartphone} title="Login activity" sub="Where your account is signed in. Sign out anything you don’t recognise." />
      <div className="lk-card">
        {site.sessions.map((s) => {
          const gone = s.active === false && s.kind !== 'current';
          const tone = s.kind === 'current' ? 'ok' : s.kind === 'unknown' ? 'bad' : 'warn';
          return (
            <div key={s.id} className="lk-session">
              <div className={`lk-session-dot ${tone}`} />
              <div style={{ flex: 1 }}>
                <div className="lk-set-label">{s.device}</div>
                <div className="lk-set-sub">{s.loc} · {s.when}{s.kind === 'unknown' && ' · not recognised'}</div>
              </div>
              {s.kind === 'current'
                ? <span className="lk-badge ok">This device</span>
                : gone
                  ? <span className="lk-badge ok"><Check size={13} /> Signed out</span>
                  : <button className="lk-btn" onClick={() => signOut(s.id)}><LogOut size={14} /> Sign out</button>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- CONNECTED APPS (task 6) ---------- */
function ConnectedApps({ site, setSite }) {
  const remove = (id) => setSite((s) => ({ ...s, apps: s.apps.map((a) => a.id === id ? { ...a, connected: false } : a) }));
  return (
    <div className="lk-col">
      <SectionTitle icon={Grid3x3} title="Connected apps" sub="Apps that can access your account. Remove anything you don’t use." />
      <div className="lk-card">
        {site.apps.filter((a) => a.connected).map((a) => (
          <div key={a.id} className="lk-session">
            <div className={`lk-appicon ${a.unused ? 'warn' : ''}`}>{a.name[0]}</div>
            <div style={{ flex: 1 }}>
              <div className="lk-set-label">{a.name}</div>
              <div className="lk-set-sub" style={{ color: a.unused ? 'var(--warn)' : 'var(--lk-sub)' }}>{a.access} · last used {a.used}</div>
            </div>
            <button className="lk-btn danger" onClick={() => remove(a.id)}><Trash2 size={14} /> Remove access</button>
          </div>
        ))}
        {site.apps.some((a) => !a.connected) && (
          <div className="lk-empty" style={{ justifyContent: 'flex-start' }}>
            <Check size={15} color="var(--good)" /> Removed: {site.apps.filter((a) => !a.connected).map((a) => a.name).join(', ')}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------- ACTIVITY (task 7) ---------- */
function Activity({ site, setSite }) {
  const reportTheft = () => setSite((s) => ({
    ...s,
    reportedTheft: true,
    activity: s.activity.map((r) => r.flag ? { ...r, reported: true } : r),
  }));
  return (
    <div className="lk-col">
      <SectionTitle icon={Receipt} title="Account activity" sub="Recent charges and logins. Small odd entries can be early signs of theft." />
      <div className="lk-card">
        {site.activity.map((r) => (
          <div key={r.id} className={`lk-actrow ${r.flag || ''}`}>
            <div style={{ flex: 1 }}>
              <div className="lk-set-label">{r.label} <span className="lk-set-sub" style={{ fontWeight: 400 }}>· {r.desc}</span></div>
              <div className="lk-set-sub">{r.when}{r.flag === 'bad' && ' · tiny unknown “test” charge'}{r.flag === 'warn' && ' · unfamiliar location'}</div>
            </div>
            {r.flag && (r.reported
              ? <span className="lk-badge bad"><Check size={13} /> Reported</span>
              : <span className="lk-badge warn"><AlertTriangle size={13} /> Suspicious</span>)}
          </div>
        ))}
      </div>
      {!site.reportedTheft
        ? <button className="lk-btn danger" style={{ alignSelf: 'flex-start' }} onClick={reportTheft}><AlertTriangle size={15} /> Report suspicious activity</button>
        : <div className="lk-warnbar ok"><Check size={15} /> Reported as possible account theft. The security team will secure the account.</div>}
    </div>
  );
}

/* ---------- shared bits ---------- */
function SectionTitle({ icon: Icon, title, sub }) {
  return (
    <div className="lk-sectiontitle">
      <div className="lk-sectionicon"><Icon size={20} /></div>
      <div><h2>{title}</h2><p>{sub}</p></div>
    </div>
  );
}

const LINKUP_CSS = `
:root{
  --lk-bg:#f0f2f5; --lk-card:#ffffff; --lk-text:#1c1e21; --lk-sub:#65676b;
  --lk-line:#e4e6eb; --lk-blue:#1877f2; --lk-hover:#f2f3f5;
  --good:#10b981; --warn:#f59e0b; --bad:#ef4444;
}
.lk-top{position:sticky;top:0;z-index:50;background:var(--lk-card);border-bottom:1px solid var(--lk-line);box-shadow:0 1px 2px rgba(0,0,0,.06)}
.lk-top-inner{max-width:1100px;margin:0 auto;display:flex;align-items:center;gap:14px;padding:9px 16px}
.lk-brand{display:flex;align-items:center;gap:9px}
.lk-logo{width:38px;height:38px;border-radius:9px;background:var(--lk-blue);color:#fff;font-weight:800;display:grid;place-items:center;font-size:17px}
.lk-brandname{font-weight:800;font-size:19px;color:var(--lk-blue)}
.lk-search{flex:1;max-width:280px;display:flex;align-items:center;gap:8px;background:var(--lk-hover);border-radius:999px;padding:8px 14px;color:var(--lk-sub)}
.lk-search input{border:none;background:transparent;outline:none;font-size:14px;width:100%;color:var(--lk-text)}
.lk-topicons{margin-left:auto;display:flex;align-items:center;gap:6px}
.lk-iconbtn{position:relative;width:40px;height:40px;border-radius:50%;border:none;background:var(--lk-hover);color:#050505;display:grid;place-items:center;cursor:pointer}
.lk-iconbtn.sm{width:32px;height:32px;background:transparent}
.lk-iconbtn:hover{background:#e4e6eb}
.lk-dot{position:absolute;top:-2px;right:-2px;background:var(--bad);color:#fff;font-size:10px;font-weight:700;border-radius:999px;padding:1px 5px}
.lk-avatar-sm{width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#f59e0b,#ef4444);color:#fff;font-weight:700;display:grid;place-items:center;font-size:14px;flex-shrink:0}
.lk-avatar-sm.alt{background:linear-gradient(135deg,#6366f1,#06b6d4)}

.lk-shell{max-width:1100px;margin:0 auto;display:grid;grid-template-columns:288px 1fr;gap:20px;padding:20px 16px 80px}
.lk-left{position:sticky;top:76px;align-self:start;display:flex;flex-direction:column;gap:14px}
.lk-profilecard{background:var(--lk-card);border-radius:12px;overflow:hidden;box-shadow:0 1px 2px rgba(0,0,0,.08);text-align:center;padding-bottom:16px}
.lk-cover{height:70px;background:linear-gradient(135deg,#1877f2,#06b6d4)}
.lk-avatar-lg{width:76px;height:76px;border-radius:50%;background:linear-gradient(135deg,#f59e0b,#ef4444);color:#fff;font-weight:800;font-size:28px;display:grid;place-items:center;margin:-38px auto 8px;border:4px solid var(--lk-card)}
.lk-name{font-weight:800;font-size:17px}
.lk-handle{color:var(--lk-sub);font-size:13px}
.lk-bio{color:var(--lk-sub);font-size:12.5px;padding:8px 16px 0}
.lk-nav{background:var(--lk-card);border-radius:12px;padding:8px;box-shadow:0 1px 2px rgba(0,0,0,.08);display:flex;flex-direction:column;gap:2px}
.lk-navitem{display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:8px;border:none;background:transparent;color:var(--lk-text);font-size:14.5px;font-weight:600;cursor:pointer;text-align:left}
.lk-navitem:hover{background:var(--lk-hover)}
.lk-navitem.active{background:#e7f0fe;color:var(--lk-blue)}
.lk-footlinks{color:var(--lk-sub);font-size:11.5px;padding:0 8px}

.lk-main{min-width:0}
.lk-col{display:flex;flex-direction:column;gap:16px;max-width:640px}
.lk-card{background:var(--lk-card);border-radius:12px;box-shadow:0 1px 2px rgba(0,0,0,.08);overflow:hidden}

.lk-sectiontitle{display:flex;gap:13px;align-items:center}
.lk-sectionicon{width:44px;height:44px;border-radius:11px;background:#e7f0fe;color:var(--lk-blue);display:grid;place-items:center;flex-shrink:0}
.lk-sectiontitle h2{font-size:21px;font-weight:800}
.lk-sectiontitle p{margin:2px 0 0;color:var(--lk-sub);font-size:13.5px}

.lk-composer{background:var(--lk-card);border-radius:12px;box-shadow:0 1px 2px rgba(0,0,0,.08);display:flex;gap:10px;align-items:center;padding:12px 14px}
.lk-composer-input{flex:1;background:var(--lk-hover);border-radius:999px;padding:10px 16px;color:var(--lk-sub);font-size:14px}
.lk-post{background:var(--lk-card);border-radius:12px;box-shadow:0 1px 2px rgba(0,0,0,.08);padding:14px}
.lk-post-head{display:flex;gap:10px;align-items:center;margin-bottom:10px}
.lk-post-who{font-weight:700;font-size:14px}
.lk-post-when{color:var(--lk-sub);font-size:12px;display:flex;align-items:center;gap:4px}
.lk-post-text{font-size:14.5px;line-height:1.5}
.lk-post-actions{display:flex;gap:6px;margin-top:12px;border-top:1px solid var(--lk-line);padding-top:8px}
.lk-post-actions button{flex:1;display:flex;align-items:center;justify-content:center;gap:7px;border:none;background:transparent;color:var(--lk-sub);font-weight:600;font-size:13.5px;padding:8px;border-radius:7px;cursor:pointer}
.lk-post-actions button:hover{background:var(--lk-hover)}

.lk-about-head{font-weight:700;padding:14px 16px;border-bottom:1px solid var(--lk-line)}
.lk-about-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 16px;border-bottom:1px solid var(--lk-line)}
.lk-about-row:last-child{border-bottom:none}
.lk-about-label{color:var(--lk-sub);font-size:12.5px}
.lk-about-val{font-weight:600;font-size:14.5px;margin-top:1px}

.lk-vis{position:relative}
.lk-vis-btn{display:inline-flex;align-items:center;gap:6px;padding:6px 11px;border-radius:8px;border:1px solid var(--lk-line);font-size:12.5px;font-weight:600;cursor:pointer;background:var(--lk-hover)}
.lk-vis-btn.warn{color:var(--bad);border-color:rgba(239,68,68,.35);background:rgba(239,68,68,.06)}
.lk-vis-btn.ok{color:var(--good)}
.lk-caret{opacity:.6}
.lk-vis-menu{position:absolute;top:calc(100% + 4px);right:0;background:var(--lk-card);border:1px solid var(--lk-line);border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.16);padding:6px;z-index:20;min-width:150px}
.lk-vis-menu.right{right:0}
.lk-vis-menu button{display:flex;align-items:center;gap:9px;width:100%;padding:9px 11px;border:none;background:transparent;border-radius:7px;font-size:13.5px;cursor:pointer;color:var(--lk-text)}
.lk-vis-menu button:hover{background:var(--lk-hover)}
.lk-vis-menu button.sel{color:var(--lk-blue);font-weight:700}
.lk-vis-menu button.danger{color:var(--bad)}

.lk-postrow{display:flex;gap:11px;padding:14px 16px;border-bottom:1px solid var(--lk-line)}
.lk-postrow:last-child{border-bottom:none}
.lk-menu-wrap{position:relative}
.lk-empty{display:flex;align-items:center;gap:8px;justify-content:center;color:var(--lk-sub);font-size:13.5px;padding:16px}

.lk-msglist{display:flex;flex-direction:column}
.lk-msg{display:flex;gap:11px;align-items:center;padding:13px 16px;border-bottom:1px solid var(--lk-line);cursor:pointer}
.lk-msg:last-child{border-bottom:none}
.lk-msg:hover{background:var(--lk-hover)}
.lk-msg.phish{background:rgba(239,68,68,.04)}
.lk-msg-from{font-weight:700;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lk-msg-addr{color:var(--lk-sub);font-weight:400;font-size:11.5px}
.lk-msg-subj{font-size:13px;color:var(--lk-sub);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lk-report{display:flex;align-items:center;gap:6px;border:1px solid rgba(239,68,68,.35);background:rgba(239,68,68,.06);color:var(--bad);font-weight:700;font-size:12.5px;padding:7px 11px;border-radius:8px;cursor:pointer;flex-shrink:0}
.lk-report:hover{background:rgba(239,68,68,.12)}

.lk-modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.4);display:grid;place-items:center;z-index:200;padding:20px}
.lk-modal{background:var(--lk-card);border-radius:14px;padding:22px;width:min(460px,94vw);box-shadow:0 20px 60px rgba(0,0,0,.3)}
.lk-input{width:100%;padding:11px 14px;border:1px solid var(--lk-line);border-radius:9px;font-size:14.5px;outline:none}
.lk-input:focus{border-color:var(--lk-blue)}
.lk-strength{height:6px;background:var(--lk-line);border-radius:999px;margin-top:10px;overflow:hidden}
.lk-strength-bar{height:100%;border-radius:999px;transition:width .2s,background .2s}
.lk-strength-bar.weak{background:var(--warn)}
.lk-strength-bar.good{background:var(--good)}
.lk-warnbar{display:flex;align-items:center;gap:9px;background:rgba(239,68,68,.08);color:var(--bad);border:1px solid rgba(239,68,68,.25);border-radius:9px;padding:11px 13px;font-size:13px;font-weight:600;margin-top:14px}
.lk-warnbar.ok{background:rgba(16,185,129,.08);color:var(--good);border-color:rgba(16,185,129,.25)}

.lk-btn{display:inline-flex;align-items:center;gap:7px;padding:9px 15px;border-radius:8px;border:1px solid var(--lk-line);background:var(--lk-hover);color:var(--lk-text);font-weight:700;font-size:13.5px;cursor:pointer}
.lk-btn:hover{filter:brightness(.97)}
.lk-btn.primary{background:var(--lk-blue);border-color:var(--lk-blue);color:#fff}
.lk-btn.danger{background:rgba(239,68,68,.08);border-color:rgba(239,68,68,.3);color:var(--bad)}
.lk-btn.ghost{background:transparent}
.lk-btn:disabled{opacity:.5;cursor:not-allowed}

.lk-setrow{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px}
.lk-set-label{font-weight:700;font-size:14.5px}
.lk-set-sub{color:var(--lk-sub);font-size:12.5px;margin-top:2px}
.lk-badge{display:inline-flex;align-items:center;gap:5px;padding:5px 11px;border-radius:999px;font-size:12px;font-weight:700}
.lk-badge.ok{background:rgba(16,185,129,.12);color:var(--good)}
.lk-badge.warn{background:rgba(245,158,11,.14);color:var(--warn)}
.lk-badge.bad{background:rgba(239,68,68,.12);color:var(--bad)}

.lk-session{display:flex;align-items:center;gap:13px;padding:14px 16px;border-bottom:1px solid var(--lk-line)}
.lk-session:last-child{border-bottom:none}
.lk-session-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}
.lk-session-dot.ok{background:var(--good)}
.lk-session-dot.warn{background:var(--warn)}
.lk-session-dot.bad{background:var(--bad)}
.lk-appicon{width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#06b6d4);color:#fff;font-weight:800;display:grid;place-items:center;flex-shrink:0}
.lk-appicon.warn{background:linear-gradient(135deg,#f59e0b,#ef4444)}

.lk-actrow{display:flex;align-items:center;gap:12px;padding:13px 16px;border-bottom:1px solid var(--lk-line)}
.lk-actrow:last-child{border-bottom:none}
.lk-actrow.bad{background:rgba(239,68,68,.04)}
.lk-actrow.warn{background:rgba(245,158,11,.05)}

@media(max-width:820px){.lk-shell{grid-template-columns:1fr}.lk-left{position:static}}
`;
