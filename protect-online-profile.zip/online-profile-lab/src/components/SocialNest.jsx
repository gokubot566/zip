import React, { useState, useEffect } from 'react';
import {
  ACCOUNT, CHARACTERS, PROFILES, COMMUNITY, STORIES, FEED, SUGGESTIONS,
  TRENDS, DMS, NOTIFICATIONS,
} from '../data/scenario.js';
import { PHOTOS } from '../data/photos.js';
import { isStrongPassword } from '../data/siteLogic.js';
import { CastPhoto } from './Cast.jsx';
import {
  Home, User, MessageCircle, Bell, Search, Settings, Shield, Compass,
  MonitorSmartphone, Grid3x3, Receipt, Globe, Lock, Users, Trash2,
  AlertTriangle, Check, MoreHorizontal, LogOut, Heart, MessageSquare,
  Share2, Bookmark, BadgeCheck, Plus, TrendingUp, Image as ImageIcon,
  BarChart3, Sparkles, X, ChevronLeft, ChevronRight, Send, UserPlus, AtSign,
} from 'lucide-react';

/* ============================================================
   SocialNest — modern original social platform (full screen).
   Photos, viewable stories, working DM + notification panels.
   The trainee performs real security fixes here; Byte gates them.
   ============================================================ */

const NAV = [
  { id: 'feed', label: 'Home', icon: Home },
  { id: 'explore', label: 'Explore', icon: Compass },
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'messages', label: 'Messages', icon: MessageCircle },
  { id: 'security', label: 'Settings', icon: Settings },
  { id: 'sessions', label: 'Login activity', icon: MonitorSmartphone },
  { id: 'apps', label: 'Connected apps', icon: Grid3x3 },
  { id: 'activity', label: 'Account activity', icon: Receipt },
];

const VIEW_ALIAS = { messages: 'messages', security: 'security', profile: 'profile', activity: 'activity', apps: 'apps' };

// Resolve an author id to a display identity (cast or community).
function author(id) {
  if (CHARACTERS[id]) {
    const c = CHARACTERS[id]; const p = PROFILES[id] || {};
    return { name: c.name, color: c.color, handle: p.handle || '', verified: !!p.verified, cast: id };
  }
  const c = COMMUNITY[id] || { name: id, handle: '', color: '#7c5cff', verified: false };
  return { ...c, cast: null };
}
function Avatar({ id, size = 44 }) {
  const a = author(id);
  if (a.cast) return <CastPhoto id={a.cast} size={size} />;
  return (
    <span className="sn-init-avatar" style={{ width: size, height: size, background: `linear-gradient(135deg, ${a.color}, #22d3ee)`, fontSize: size * 0.4 }}>
      {a.name[0]}
    </span>
  );
}

export default function SocialNest({ site, setSite, view, setView, activeTaskId }) {
  const nav = VIEW_ALIAS[view] || view;
  const [panel, setPanel] = useState(null); // 'messages' | 'notifications' | null
  const [story, setStory] = useState(null);  // story object being viewed

  // Live DM + notification read-state (so badges update in real time).
  const [dms, setDms] = useState(() => DMS.map((d) => ({ ...d })));
  const [notifs, setNotifs] = useState(() => NOTIFICATIONS.map((n) => ({ ...n })));

  const markDmRead = (id) => setDms((list) => list.map((d) => d.id === id ? { ...d, unread: false } : d));
  const markAllNotifsRead = () => setNotifs((list) => list.map((n) => ({ ...n, unread: false })));

  const unreadDMs = dms.filter((d) => d.unread).length;
  const unreadNotifs = notifs.filter((n) => n.unread).length;

  return (
    <div className="sn-root">
      <style>{SN_CSS}</style>

      <header className="sn-top">
        <div className="sn-top-inner">
          <div className="sn-brand" onClick={() => { setView('feed'); setPanel(null); }} role="button">
            <div className="sn-logo"><Sparkles size={18} /></div>
            <span className="sn-brandname">SocialNest</span>
          </div>
          <div className="sn-search">
            <Search size={17} />
            <input placeholder="Search people, posts and tags" />
          </div>
          <div className="sn-topicons">
            <button className="sn-iconbtn" title="Home" onClick={() => { setView('feed'); setPanel(null); }}><Home size={20} /></button>
            <div className="sn-pop-wrap">
              <button className={`sn-iconbtn ${panel === 'messages' ? 'on' : ''}`} title="Messages" onClick={() => setPanel(panel === 'messages' ? null : 'messages')}>
                <MessageCircle size={20} />{unreadDMs > 0 && <span className="sn-dot">{unreadDMs}</span>}
              </button>
              {panel === 'messages' && <MessagesPanel dms={dms} onOpen={(id) => { markDmRead(id); setView('messages'); setPanel(null); }} onClose={() => setPanel(null)} onOpenAll={() => { setView('messages'); setPanel(null); }} />}
            </div>
            <div className="sn-pop-wrap">
              <button className={`sn-iconbtn ${panel === 'notifications' ? 'on' : ''}`} title="Notifications" onClick={() => { const opening = panel !== 'notifications'; setPanel(opening ? 'notifications' : null); if (opening) markAllNotifsRead(); }}>
                <Bell size={20} />{unreadNotifs > 0 && <span className="sn-dot">{unreadNotifs}</span>}
              </button>
              {panel === 'notifications' && <NotificationsPanel notifs={notifs} onClose={() => setPanel(null)} />}
            </div>
            <button className="sn-avatar-sm" title="Your profile" onClick={() => { setView('profile'); setPanel(null); }}>{ACCOUNT.initials}</button>
          </div>
        </div>
      </header>

      <div className="sn-shell">
        <aside className="sn-left">
          <nav className="sn-nav">
            {NAV.map((n) => {
              const Icon = n.icon; const active = nav === n.id;
              const liveBadge = n.id === 'messages' && unreadDMs > 0 ? unreadDMs : null;
              return (
                <button key={n.id} className={`sn-navitem ${active ? 'active' : ''}`} onClick={() => setView(n.id)}>
                  <Icon size={21} /> <span>{n.label}</span>
                  {liveBadge && <span className="sn-navbadge">{liveBadge}</span>}
                </button>
              );
            })}
          </nav>
          <button className="sn-post-btn"><Plus size={18} /> <span>Create post</span></button>
          <div className="sn-mini-profile">
            <div className="sn-avatar-sm lg">{ACCOUNT.initials}</div>
            <div style={{ minWidth: 0 }}>
              <div className="sn-mini-name">{ACCOUNT.name}</div>
              <div className="sn-mini-handle">{ACCOUNT.handle}</div>
            </div>
            <MoreHorizontal size={18} style={{ marginLeft: 'auto', color: 'var(--sn-sub)' }} />
          </div>
        </aside>

        <main className="sn-main">
          {nav === 'feed' && <Feed onOpenStory={setStory} />}
          {nav === 'explore' && <Explore />}
          {nav === 'profile' && <Profile site={site} setSite={setSite} />}
          {nav === 'messages' && <MessagesPage site={site} setSite={setSite} dms={dms} markDmRead={markDmRead} activeTaskId={activeTaskId} />}
          {nav === 'security' && <SecuritySettings site={site} setSite={setSite} />}
          {nav === 'sessions' && <Sessions site={site} setSite={setSite} />}
          {nav === 'apps' && <ConnectedApps site={site} setSite={setSite} />}
          {nav === 'activity' && <Activity site={site} setSite={setSite} />}
        </main>

        <aside className="sn-right">
          <div className="sn-card sn-pad">
            <div className="sn-rail-title"><TrendingUp size={16} /> Trending</div>
            {TRENDS.map((t) => (
              <div key={t.tag} className="sn-trend">
                <div className="sn-trend-tag">{t.tag}</div>
                <div className="sn-trend-sub">{t.posts}</div>
              </div>
            ))}
          </div>
          <div className="sn-card sn-pad">
            <div className="sn-rail-title"><Users size={16} /> Who to follow</div>
            {SUGGESTIONS.map((s) => <SuggestRow key={s.id} s={s} />)}
          </div>
          <div className="sn-railfoot">© 2026 SocialNest · Privacy · Terms · Help · Training demo</div>
        </aside>
      </div>

      {story && <StoryViewer story={story} onClose={() => setStory(null)} />}
    </div>
  );
}

/* ---------------- top-bar panels ---------------- */
function MessagesPanel({ dms, onOpen, onClose, onOpenAll }) {
  return (
    <div className="sn-pop" onMouseLeave={onClose}>
      <div className="sn-pop-head">Messages</div>
      <div className="sn-pop-list">
        {dms.map((d) => (
          <div key={d.id} className={`sn-pop-item ${d.unread ? 'unread' : ''}`} onClick={() => onOpen(d.id)}>
            <Avatar id={d.cast} size={40} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="sn-pop-name">{d.name}</div>
              <div className="sn-pop-preview">{d.preview}</div>
            </div>
            <div className="sn-pop-time">{d.time}</div>
            {d.unread && <span className="sn-unread-dot" style={{ marginLeft: 4 }} />}
          </div>
        ))}
      </div>
      <button className="sn-pop-foot" onClick={onOpenAll}>Open Messages</button>
    </div>
  );
}
function NotificationsPanel({ notifs, onClose }) {
  const iconFor = { like: Heart, comment: MessageSquare, follow: UserPlus, mention: AtSign, share: Share2 };
  return (
    <div className="sn-pop" onMouseLeave={onClose}>
      <div className="sn-pop-head">Notifications</div>
      <div className="sn-pop-list">
        {notifs.map((n) => {
          const I = iconFor[n.kind] || Bell;
          return (
            <div key={n.id} className={`sn-pop-item ${n.unread ? 'unread' : ''}`}>
              <div className="sn-notif-ic"><I size={15} /></div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="sn-pop-preview" style={{ color: 'var(--sn-text)' }}>{n.text}</div>
                <div className="sn-pop-time" style={{ position: 'static' }}>{n.time}</div>
              </div>
              {n.unread && <span className="sn-unread-dot" />}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- story viewer ---------------- */
function StoryViewer({ story, onClose }) {
  const [i, setI] = useState(0);
  const photos = story.photos || [];
  const a = author(story.cast);
  const next = () => (i < photos.length - 1 ? setI(i + 1) : onClose());
  const prev = () => i > 0 && setI(i - 1);
  return (
    <div className="sn-story-bg" onClick={onClose}>
      <button className="sn-story-nav left" onClick={(e) => { e.stopPropagation(); prev(); }} disabled={i === 0}><ChevronLeft size={26} /></button>
      <div className="sn-story-view" onClick={(e) => e.stopPropagation()}>
        <div className="sn-story-bars">
          {photos.map((_, k) => <span key={k} className={`sn-story-bar ${k <= i ? 'on' : ''}`} />)}
        </div>
        <div className="sn-story-header">
          <Avatar id={story.cast} size={34} />
          <span className="sn-story-user">{a.name}</span>
          <button className="sn-story-x" onClick={onClose}><X size={20} /></button>
        </div>
        <img className="sn-story-img" src={PHOTOS[photos[i]]} alt="" onClick={next} />
      </div>
      <button className="sn-story-nav right" onClick={(e) => { e.stopPropagation(); next(); }}><ChevronRight size={26} /></button>
    </div>
  );
}

/* ---------------- FEED ---------------- */
function Feed({ onOpenStory }) {
  const [posts, setPosts] = useState(FEED);
  const toggleLike = (id) => setPosts((ps) => ps.map((p) => p.id === id ? { ...p, liked: !p.liked, likes: p.likes + (p.liked ? -1 : 1) } : p));
  return (
    <div className="sn-col">
      <Stories onOpenStory={onOpenStory} />
      <Composer />
      {posts.map((p) => <PostCard key={p.id} post={p} onLike={() => toggleLike(p.id)} />)}
      <div className="sn-endcap">You're all caught up ✨</div>
    </div>
  );
}

function Stories({ onOpenStory }) {
  return (
    <div className="sn-card sn-stories">
      {STORIES.map((s) => (
        <button key={s.id} className="sn-story" onClick={() => !s.own && s.photos && onOpenStory(s)}>
          <div className={`sn-story-ring ${s.own ? 'own' : s.seen ? 'seen' : ''}`}>
            {s.own ? <div className="sn-story-add"><Plus size={20} /></div> : <CastPhoto id={s.cast} size={58} />}
          </div>
          <span className="sn-story-name">{s.name}</span>
        </button>
      ))}
    </div>
  );
}

function Composer() {
  return (
    <div className="sn-card sn-composer">
      <div className="sn-avatar-sm">{ACCOUNT.initials}</div>
      <input className="sn-composer-input" placeholder={`What's on your mind, ${ACCOUNT.name.split(' ')[0]}?`} readOnly />
      <button className="sn-composer-icon" title="Photo"><ImageIcon size={19} /></button>
      <button className="sn-composer-icon" title="Poll"><BarChart3 size={19} /></button>
      <button className="sn-btn primary sm">Post</button>
    </div>
  );
}

function PostCard({ post, onLike }) {
  const a = author(post.cast);
  const [saved, setSaved] = useState(false);
  return (
    <article className="sn-card sn-post">
      <div className="sn-post-head">
        <Avatar id={post.cast} size={44} />
        <div style={{ minWidth: 0 }}>
          <div className="sn-post-name">{a.name}{a.verified && <BadgeCheck size={15} className="sn-verified" />}</div>
          <div className="sn-post-meta">{a.handle} · {post.time} · <Globe size={11} /></div>
        </div>
        <button className="sn-iconbtn ghost" style={{ marginLeft: 'auto' }} title="More"><MoreHorizontal size={19} /></button>
      </div>

      {post.text && <div className="sn-post-text">{post.text}</div>}

      {post.kind === 'image' && (
        <>
          <img className="sn-post-photo" src={PHOTOS[post.photo]} alt={post.caption || ''} loading="lazy" />
          {post.caption && <div className="sn-post-text sn-caption">{post.caption}</div>}
        </>
      )}

      {post.kind === 'poll' && <Poll options={post.poll} votes={post.votes} />}

      <div className="sn-post-stats">
        <span>{post.likes.toLocaleString()} likes</span>
        <span>{post.comments} comments · {post.shares} shares</span>
      </div>
      <div className="sn-post-actions">
        <button className={post.liked ? 'liked' : ''} onClick={onLike}><Heart size={19} fill={post.liked ? 'currentColor' : 'none'} /> Like</button>
        <button><MessageSquare size={19} /> Comment</button>
        <button><Share2 size={19} /> Share</button>
        <button className={saved ? 'liked' : ''} onClick={() => setSaved((s) => !s)}><Bookmark size={19} fill={saved ? 'currentColor' : 'none'} /> Save</button>
      </div>
    </article>
  );
}

function Poll({ options, votes }) {
  const [voted, setVoted] = useState(null);
  return (
    <div className="sn-poll">
      {options.map((o, i) => (
        <button key={i} className={`sn-poll-opt ${voted !== null ? 'done' : ''}`} onClick={() => setVoted(i)}>
          {voted !== null && <span className="sn-poll-fill" style={{ width: `${o.pct}%` }} />}
          <span className="sn-poll-label">{o.label}{voted === i && <Check size={14} />}</span>
          {voted !== null && <span className="sn-poll-pct">{o.pct}%</span>}
        </button>
      ))}
      <div className="sn-poll-votes">{votes}{voted !== null ? ' · you voted' : ''}</div>
    </div>
  );
}

function SuggestRow({ s }) {
  const [following, setFollowing] = useState(false);
  return (
    <div className="sn-follow">
      <span className="sn-init-avatar" style={{ width: 40, height: 40, background: `linear-gradient(135deg, ${s.color}, #22d3ee)`, fontSize: 16 }}>{s.name[0]}</span>
      <div style={{ minWidth: 0, flex: 1 }}>
        <div className="sn-follow-name">{s.name}{s.verified && <BadgeCheck size={13} className="sn-verified" />}</div>
        <div className="sn-follow-handle">{s.note}</div>
      </div>
      <button className={`sn-btn ${following ? '' : 'primary'} xs`} onClick={() => setFollowing((f) => !f)}>{following ? 'Following' : 'Follow'}</button>
    </div>
  );
}

/* ---------------- EXPLORE ---------------- */
function Explore() {
  const grid = ['forest_canopy', 'airplane_sunset', 'icecream', 'beach_huts', 'puppy', 'camera', 'desert_sunset', 'bike', 'smoke'];
  return (
    <div className="sn-col">
      <SectionTitle icon={Compass} title="Explore" sub="Popular photos across SocialNest right now." />
      <div className="sn-explore-grid">
        {grid.map((ph, i) => <div key={i} className="sn-explore-tile" style={{ backgroundImage: `url(${PHOTOS[ph]})` }} />)}
      </div>
    </div>
  );
}

/* ---------------- MESSAGES (full page + task 2) ---------------- */
function MessagesPage({ site, setSite, dms, markDmRead, activeTaskId }) {
  const inbox = site.messages.filter((m) => m.status === 'inbox');
  const phishingPending = inbox.some((m) => m.phishing);
  // Open on the "Requests" tab when the phishing step is active (or any
  // phishing request is still sitting in the inbox), so the suspicious
  // messages are visible immediately instead of hidden behind Chats.
  const [tab, setTab] = useState(() => (activeTaskId === 'phishing' || phishingPending) ? 'security' : 'chats');
  const [openId, setOpenId] = useState(null);
  const [chat, setChat] = useState(dms[0].id);
  const report = (id) => { setSite((s) => ({ ...s, messages: s.messages.map((m) => m.id === id ? { ...m, status: 'reported' } : m) })); setOpenId(null); };
  const open = site.messages.find((m) => m.id === openId);
  const activeChat = dms.find((d) => d.id === chat) || dms[0];

  // If the phishing step becomes active later, surface the Requests tab.
  useEffect(() => {
    if (activeTaskId === 'phishing') setTab('security');
  }, [activeTaskId]);

  // Opening a conversation marks it read (badge updates live).
  const openChat = (id) => { setChat(id); markDmRead(id); };

  return (
    <div className="sn-col">
      <SectionTitle icon={MessageCircle} title="Messages" sub="Your chats and your message requests. Some requests aren't what they claim to be." />
      <div className="sn-msgtabs">
        <button className={tab === 'chats' ? 'on' : ''} onClick={() => setTab('chats')}>Chats</button>
        <button className={tab === 'security' ? 'on' : ''} onClick={() => setTab('security')}>Requests {inbox.length > 0 && <span className="sn-navbadge" style={{ position: 'static', marginLeft: 4 }}>{inbox.length}</span>}</button>
      </div>

      {tab === 'chats' && (
        <div className="sn-chatlayout">
          <div className="sn-card sn-chatlist">
            {dms.map((d) => (
              <button key={d.id} className={`sn-chatrow ${chat === d.id ? 'on' : ''}`} onClick={() => openChat(d.id)}>
                <Avatar id={d.cast} size={42} />
                <div style={{ flex: 1, minWidth: 0, textAlign: 'left' }}>
                  <div className="sn-pop-name">{d.name}{d.unread && <span className="sn-unread-dot" style={{ marginLeft: 6, display: 'inline-block', verticalAlign: 'middle' }} />}</div>
                  <div className="sn-pop-preview">{d.preview}</div>
                </div>
              </button>
            ))}
          </div>
          <div className="sn-card sn-chatpane">
            <div className="sn-chatpane-head"><Avatar id={activeChat.cast} size={34} /> <b>{activeChat.name}</b></div>
            <div className="sn-chatpane-body">
              {activeChat.thread.map((m, i) => (
                <div key={i} className={`sn-bubble ${m.me ? 'me' : ''}`}>{m.t}</div>
              ))}
            </div>
            <div className="sn-chatpane-input">
              <input placeholder="Write a message…" readOnly />
              <button className="sn-btn primary sm"><Send size={15} /></button>
            </div>
          </div>
        </div>
      )}

      {tab === 'security' && (
        <div className="sn-card">
          {inbox.length === 0 && <div className="sn-empty"><Check size={16} color="var(--good)" /> No pending requests. Phishing reported.</div>}
          {inbox.map((m) => (
            <div key={m.id} className={`sn-msg ${m.phishing ? 'phish' : ''}`} onClick={() => setOpenId(m.id)}>
              <div className="sn-avatar-sm alt">{m.from[0]}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="sn-msg-from">{m.from} <span className="sn-msg-addr">&lt;{m.addr}&gt;</span></div>
                <div className="sn-msg-subj">{m.subject}</div>
              </div>
              <button className="sn-report" onClick={(e) => { e.stopPropagation(); report(m.id); }}><AlertTriangle size={14} /> Report</button>
            </div>
          ))}
        </div>
      )}

      {open && (
        <div className="sn-modal-bg" onClick={() => setOpenId(null)}>
          <div className="sn-modal" onClick={(e) => e.stopPropagation()}>
            <div className="sn-msg-from" style={{ marginBottom: 2 }}>{open.from}</div>
            <div className="sn-msg-addr" style={{ marginBottom: 12 }}>&lt;{open.addr}&gt;</div>
            <div style={{ fontWeight: 700, marginBottom: 8, fontSize: 15 }}>{open.subject}</div>
            <p style={{ color: 'var(--sn-sub)', lineHeight: 1.6 }}>{open.body}</p>
            {open.phishing && <div className="sn-warnbar"><AlertTriangle size={15} /> This looks like phishing. Don't click links or share your password — report it.</div>}
            <div style={{ display: 'flex', gap: 8, marginTop: 16, justifyContent: 'flex-end' }}>
              <button className="sn-btn" onClick={() => setOpenId(null)}>Close</button>
              <button className="sn-btn danger" onClick={() => report(open.id)}><AlertTriangle size={14} /> Report as phishing</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------- PROFILE (task 1) ---------------- */
const VIS = [
  { v: 'public', label: 'Public', icon: Globe },
  { v: 'friends', label: 'Friends only', icon: Users },
  { v: 'private', label: 'Only me', icon: Lock },
];
function VisPicker({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const cur = VIS.find((x) => x.v === value) || VIS[0];
  const Icon = cur.icon;
  return (
    <div className="sn-vis">
      <button className={`sn-vis-btn ${value === 'public' ? 'warn' : 'ok'}`} onClick={() => setOpen((o) => !o)}>
        <Icon size={13} /> {cur.label} <span className="sn-caret">▾</span>
      </button>
      {open && (
        <div className="sn-menu right" onMouseLeave={() => setOpen(false)}>
          {VIS.map((o) => {
            const OIcon = o.icon;
            return (
              <button key={o.v} onClick={() => { onChange(o.v); setOpen(false); }} className={o.v === value ? 'sel' : ''}>
                <OIcon size={15} /> {o.label}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
function Profile({ site, setSite }) {
  const setVis = (field, v) => setSite((s) => ({ ...s, visibility: { ...s.visibility, [field]: v } }));
  const rows = [
    ['dob', 'Date of birth', ACCOUNT.dob],
    ['mobile', 'Mobile', ACCOUNT.mobile],
    ['suburb', 'Home suburb', ACCOUNT.suburb],
    ['school', 'School', ACCOUNT.school],
  ];
  return (
    <div className="sn-col">
      <div className="sn-card sn-profilehero">
        <div className="sn-cover" />
        <div className="sn-profilehero-body">
          <div className="sn-avatar-hero">{ACCOUNT.initials}</div>
          <div className="sn-profilehero-info">
            <div className="sn-profilehero-name">{ACCOUNT.name}</div>
            <div className="sn-profilehero-handle">{ACCOUNT.handle}</div>
          </div>
          <button className="sn-btn primary sm sn-edit-btn">Edit profile</button>
        </div>
        <div className="sn-profilehero-bio">{ACCOUNT.bio}</div>
        <div className="sn-profilehero-stats">
          <span><b>128</b> posts</span><span><b>342</b> friends</span><span><b>289</b> following</span>
        </div>
      </div>

      <SectionTitle icon={User} title="About & privacy" sub="What people can see about you, and who can see it." />
      <div className="sn-card">
        <div className="sn-about-head">Personal details</div>
        {rows.map(([key, label, val]) => (
          <div key={key} className="sn-about-row">
            <div><div className="sn-about-label">{label}</div><div className="sn-about-val">{val}</div></div>
            <VisPicker value={site.visibility[key]} onChange={(v) => setVis(key, v)} />
          </div>
        ))}
        <div className="sn-about-row">
          <div><div className="sn-about-label">Email</div><div className="sn-about-val">{ACCOUNT.email}</div></div>
          <span className="sn-vis-btn ok" style={{ cursor: 'default' }}><Lock size={13} /> Only me</span>
        </div>
      </div>

      <div className="sn-card">
        <div className="sn-about-head">Your posts</div>
        {!site.awayPostDeleted ? (
          <PostRow text="So excited — away on holiday all next week! House to myself when I'm back 🎉" when="Yesterday"
            onDelete={() => setSite((s) => ({ ...s, awayPostDeleted: true }))} />
        ) : (
          <div className="sn-empty"><Check size={16} color="var(--good)" /> That post was deleted.</div>
        )}
        <PostRow text="Study playlist is carrying me through exams 🎧" when="4 days ago" />
      </div>
    </div>
  );
}
function PostRow({ text, when, onDelete }) {
  const [menu, setMenu] = useState(false);
  return (
    <div className="sn-postrow">
      <div className="sn-avatar-sm">{ACCOUNT.initials}</div>
      <div style={{ flex: 1 }}>
        <div className="sn-post-name sm">{ACCOUNT.name} <span className="sn-post-meta">· {when} · <Globe size={11} /></span></div>
        <div className="sn-post-text" style={{ marginTop: 4 }}>{text}</div>
      </div>
      {onDelete && (
        <div className="sn-menu-wrap">
          <button className="sn-iconbtn ghost sm" onClick={() => setMenu((m) => !m)}><MoreHorizontal size={18} /></button>
          {menu && (
            <div className="sn-menu right" onMouseLeave={() => setMenu(false)}>
              <button onClick={onDelete} className="danger"><Trash2 size={15} /> Delete post</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ---------------- SECURITY (tasks 3,4,5-recovery) ---------------- */
function SecuritySettings({ site, setSite }) {
  const [pwOpen, setPwOpen] = useState(false);
  const [pw, setPw] = useState('');
  const [recOpen, setRecOpen] = useState(false);
  const [rec, setRec] = useState('');
  const strong = isStrongPassword(pw);
  const savePw = () => { if (!strong) return; setSite((s) => ({ ...s, password: pw, passwordStrong: true })); setPwOpen(false); setPw(''); };
  const saveRec = () => { if (!/@/.test(rec) || /old-address/.test(rec)) return; setSite((s) => ({ ...s, recoveryEmail: rec, recoveryFixed: true })); setRecOpen(false); setRec(''); };
  const setTwofa = (v) => setSite((s) => ({ ...s, twofa: v }));

  return (
    <div className="sn-col">
      <SectionTitle icon={Shield} title="Settings · Security" sub="Passwords, two-factor authentication, and account recovery." />
      <div className="sn-card sn-setrow">
        <div>
          <div className="sn-set-label">Password</div>
          <div className="sn-set-sub">{site.passwordStrong ? 'Strong, unique password set.' : 'Currently: ' + '•'.repeat(10) + ' — short and reused on other sites.'}</div>
        </div>
        {site.passwordStrong ? <span className="sn-badge ok"><Check size={13} /> Strong</span> : <button className="sn-btn" onClick={() => setPwOpen(true)}>Change password</button>}
      </div>
      <div className="sn-card">
        <div className="sn-setrow" style={{ borderBottom: '1px solid var(--sn-line)' }}>
          <div>
            <div className="sn-set-label">Two-factor authentication</div>
            <div className="sn-set-sub">{site.twofa === 'off' ? 'Off — your password is the only thing protecting this account.' : site.twofa === 'app' ? 'On — using an authenticator app.' : 'On — using SMS text codes.'}</div>
          </div>
          <span className={`sn-badge ${site.twofa === 'app' ? 'ok' : site.twofa === 'sms' ? 'warn' : 'bad'}`}>{site.twofa === 'off' ? 'Off' : site.twofa === 'app' ? 'App' : 'SMS'}</span>
        </div>
        <div style={{ display: 'flex', gap: 8, padding: 14, flexWrap: 'wrap' }}>
          <button className={`sn-btn ${site.twofa === 'app' ? 'primary' : ''}`} onClick={() => setTwofa('app')}>Use authenticator app</button>
          <button className="sn-btn" onClick={() => setTwofa('sms')}>Use SMS</button>
          {site.twofa !== 'off' && <button className="sn-btn ghost" onClick={() => setTwofa('off')}>Turn off</button>}
        </div>
      </div>
      <div className="sn-card sn-setrow">
        <div>
          <div className="sn-set-label">Recovery email</div>
          <div className="sn-set-sub" style={{ color: site.recoveryFixed ? 'var(--sn-sub)' : 'var(--bad)' }}>{site.recoveryEmail}{!site.recoveryFixed && ' — you no longer control this inbox'}</div>
        </div>
        {site.recoveryFixed ? <span className="sn-badge ok"><Check size={13} /> Updated</span> : <button className="sn-btn" onClick={() => setRecOpen(true)}>Update</button>}
      </div>

      {pwOpen && (
        <div className="sn-modal-bg" onClick={() => setPwOpen(false)}>
          <div className="sn-modal" onClick={(e) => e.stopPropagation()}>
            <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 12 }}>Change password</div>
            <input className="sn-input" type="text" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="New password or passphrase" autoFocus />
            <div className="sn-strength"><div className={`sn-strength-bar ${strong ? 'good' : pw.length > 0 ? 'weak' : ''}`} style={{ width: `${Math.min(100, pw.length * 7)}%` }} /></div>
            <div className="sn-set-sub" style={{ marginTop: 6, color: strong ? 'var(--good)' : 'var(--sn-sub)' }}>
              {pw.length === 0 ? 'Use 12+ characters. A few unrelated words work well. Don\u2019t reuse an old one.' : strong ? '✓ Strong and unique.' : 'Too weak — make it longer and avoid the name/year.'}
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 16, justifyContent: 'flex-end' }}>
              <button className="sn-btn" onClick={() => setPwOpen(false)}>Cancel</button>
              <button className="sn-btn primary" disabled={!strong} onClick={savePw}>Save password</button>
            </div>
          </div>
        </div>
      )}
      {recOpen && (
        <div className="sn-modal-bg" onClick={() => setRecOpen(false)}>
          <div className="sn-modal" onClick={(e) => e.stopPropagation()}>
            <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 12 }}>Update recovery email</div>
            <input className="sn-input" type="email" value={rec} onChange={(e) => setRec(e.target.value)} placeholder="current-email@example.com" autoFocus />
            <div className="sn-set-sub" style={{ marginTop: 6 }}>Use an inbox you control today — this is your "forgot password" path.</div>
            <div style={{ display: 'flex', gap: 8, marginTop: 16, justifyContent: 'flex-end' }}>
              <button className="sn-btn" onClick={() => setRecOpen(false)}>Cancel</button>
              <button className="sn-btn primary" disabled={!/@/.test(rec) || /old-address/.test(rec)} onClick={saveRec}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------- SESSIONS (task 5-sessions) ---------------- */
function Sessions({ site, setSite }) {
  const signOut = (id) => setSite((s) => ({ ...s, sessions: s.sessions.map((x) => x.id === id ? { ...x, active: false } : x) }));
  return (
    <div className="sn-col">
      <SectionTitle icon={MonitorSmartphone} title="Login activity" sub="Where your account is signed in. Sign out anything you don't recognise." />
      <div className="sn-card">
        {site.sessions.map((s) => {
          const gone = s.active === false && s.kind !== 'current';
          const tone = s.kind === 'current' ? 'ok' : s.kind === 'unknown' ? 'bad' : 'warn';
          return (
            <div key={s.id} className="sn-listrow">
              <div className={`sn-dotstat ${tone}`} />
              <div style={{ flex: 1 }}>
                <div className="sn-set-label">{s.device}</div>
                <div className="sn-set-sub">{s.loc} · {s.when}{s.kind === 'unknown' && ' · not recognised'}</div>
              </div>
              {s.kind === 'current' ? <span className="sn-badge ok">This device</span>
                : gone ? <span className="sn-badge ok"><Check size={13} /> Signed out</span>
                  : <button className="sn-btn" onClick={() => signOut(s.id)}><LogOut size={14} /> Sign out</button>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- CONNECTED APPS (task 6) ---------------- */
function ConnectedApps({ site, setSite }) {
  const remove = (id) => setSite((s) => ({ ...s, apps: s.apps.map((a) => a.id === id ? { ...a, connected: false } : a) }));
  return (
    <div className="sn-col">
      <SectionTitle icon={Grid3x3} title="Connected apps" sub="Apps that can access your account. Remove anything you don't use." />
      <div className="sn-card">
        {site.apps.filter((a) => a.connected).map((a) => (
          <div key={a.id} className="sn-listrow">
            <div className={`sn-appicon ${a.unused ? 'warn' : ''}`}>{a.name[0]}</div>
            <div style={{ flex: 1 }}>
              <div className="sn-set-label">{a.name}</div>
              <div className="sn-set-sub" style={{ color: a.unused ? 'var(--warn)' : 'var(--sn-sub)' }}>{a.access} · last used {a.used}</div>
            </div>
            <button className="sn-btn danger" onClick={() => remove(a.id)}><Trash2 size={14} /> Remove access</button>
          </div>
        ))}
        {site.apps.some((a) => !a.connected) && (
          <div className="sn-empty" style={{ justifyContent: 'flex-start' }}>
            <Check size={15} color="var(--good)" /> Removed: {site.apps.filter((a) => !a.connected).map((a) => a.name).join(', ')}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------- ACTIVITY (task 7) ---------------- */
function Activity({ site, setSite }) {
  const reportTheft = () => setSite((s) => ({ ...s, reportedTheft: true, activity: s.activity.map((r) => r.flag ? { ...r, reported: true } : r) }));
  return (
    <div className="sn-col">
      <SectionTitle icon={Receipt} title="Account activity" sub="Recent charges and logins. Small odd entries can be early signs of theft." />
      <div className="sn-card">
        {site.activity.map((r) => (
          <div key={r.id} className={`sn-actrow ${r.flag || ''}`}>
            <div style={{ flex: 1 }}>
              <div className="sn-set-label">{r.label} <span className="sn-set-sub" style={{ fontWeight: 400 }}>· {r.desc}</span></div>
              <div className="sn-set-sub">{r.when}{r.flag === 'bad' && ' · tiny unknown "test" charge'}{r.flag === 'warn' && ' · unfamiliar location'}</div>
            </div>
            {r.flag && (r.reported ? <span className="sn-badge bad"><Check size={13} /> Reported</span> : <span className="sn-badge warn"><AlertTriangle size={13} /> Suspicious</span>)}
          </div>
        ))}
      </div>
      {!site.reportedTheft
        ? <button className="sn-btn danger" style={{ alignSelf: 'flex-start' }} onClick={reportTheft}><AlertTriangle size={15} /> Report suspicious activity</button>
        : <div className="sn-warnbar ok"><Check size={15} /> Reported as possible account theft. The security team will secure the account.</div>}
    </div>
  );
}

/* ---------------- shared ---------------- */
function SectionTitle({ icon: Icon, title, sub }) {
  return (
    <div className="sn-sectiontitle">
      <div className="sn-sectionicon"><Icon size={20} /></div>
      <div><h2>{title}</h2><p>{sub}</p></div>
    </div>
  );
}

const SN_CSS = `
:root{
  --sn-bg:#0d1117; --sn-surface:#161b26; --sn-surface-2:#1c2230; --sn-elevated:#20273a;
  --sn-text:#eef2f9; --sn-sub:#93a0b8; --sn-faint:#5f6b82;
  --sn-line:rgba(255,255,255,.08); --sn-line-2:rgba(255,255,255,.14);
  --sn-brand:#7c5cff; --sn-brand-2:#22d3ee; --sn-brand-soft:rgba(124,92,255,.16);
  --good:#22c55e; --warn:#f59e0b; --bad:#f43f5e;
}
.sn-root{min-height:100vh;background:
  radial-gradient(90% 60% at 100% 0%, rgba(124,92,255,.10), transparent 60%),
  radial-gradient(70% 50% at 0% 0%, rgba(34,211,238,.07), transparent 55%),
  var(--sn-bg);color:var(--sn-text);font-family:'Inter',system-ui,-apple-system,'Segoe UI',sans-serif}
.sn-root *{box-sizing:border-box}

.sn-top{position:sticky;top:0;z-index:60;background:rgba(13,17,23,.82);backdrop-filter:blur(14px);border-bottom:1px solid var(--sn-line)}
.sn-top-inner{max-width:1240px;margin:0 auto;display:flex;align-items:center;gap:16px;padding:11px 20px}
.sn-brand{display:flex;align-items:center;gap:10px;cursor:pointer}
.sn-logo{width:38px;height:38px;border-radius:11px;background:linear-gradient(135deg,var(--sn-brand),var(--sn-brand-2));color:#fff;display:grid;place-items:center;box-shadow:0 6px 18px rgba(124,92,255,.4)}
.sn-brandname{font-weight:800;font-size:20px;letter-spacing:-.4px;background:linear-gradient(135deg,#fff,#c7bfff);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
.sn-search{flex:1;max-width:420px;display:flex;align-items:center;gap:9px;background:var(--sn-surface-2);border:1px solid var(--sn-line);border-radius:12px;padding:10px 14px;color:var(--sn-sub);transition:border-color .15s}
.sn-search:focus-within{border-color:var(--sn-brand)}
.sn-search input{border:none;background:transparent;outline:none;font-size:14px;width:100%;color:var(--sn-text)}
.sn-topicons{margin-left:auto;display:flex;align-items:center;gap:8px}
.sn-pop-wrap{position:relative}
.sn-iconbtn{position:relative;width:42px;height:42px;border-radius:12px;border:none;background:var(--sn-surface-2);color:var(--sn-text);display:grid;place-items:center;cursor:pointer;transition:background .15s,transform .08s}
.sn-iconbtn:hover{background:var(--sn-elevated)} .sn-iconbtn:active{transform:scale(.94)} .sn-iconbtn.on{background:var(--sn-brand-soft);color:var(--sn-brand-2)}
.sn-iconbtn.ghost{background:transparent} .sn-iconbtn.ghost:hover{background:var(--sn-surface-2)} .sn-iconbtn.sm{width:34px;height:34px}
.sn-dot{position:absolute;top:-3px;right:-3px;background:var(--bad);color:#fff;font-size:10px;font-weight:800;border-radius:999px;padding:1px 5px;border:2px solid var(--sn-bg)}
.sn-avatar-sm{width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,#f59e0b,#f43f5e);color:#fff;font-weight:800;display:grid;place-items:center;font-size:14px;flex-shrink:0;border:none;cursor:pointer}
.sn-avatar-sm.lg{width:44px;height:44px;font-size:15px} .sn-avatar-sm.alt{background:linear-gradient(135deg,var(--sn-brand),var(--sn-brand-2))}
.sn-init-avatar{border-radius:50%;color:#fff;font-weight:800;display:inline-grid;place-items:center;flex-shrink:0}

/* top-bar popovers */
.sn-pop{position:absolute;top:calc(100% + 10px);right:0;width:340px;max-width:88vw;background:var(--sn-elevated);border:1px solid var(--sn-line-2);border-radius:14px;box-shadow:0 20px 60px rgba(0,0,0,.55);z-index:80;overflow:hidden;animation:snPop .16s ease}
@keyframes snPop{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:none}}
.sn-pop-head{font-weight:800;font-size:14px;padding:14px 16px;border-bottom:1px solid var(--sn-line)}
.sn-pop-list{max-height:360px;overflow-y:auto}
.sn-pop-item{display:flex;align-items:center;gap:11px;padding:12px 16px;border-bottom:1px solid var(--sn-line);cursor:pointer;position:relative}
.sn-pop-item:last-child{border-bottom:none}
.sn-pop-item:hover{background:var(--sn-surface-2)}
.sn-pop-item.unread{background:rgba(124,92,255,.06)}
.sn-pop-name{font-size:13.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sn-pop-preview{font-size:12.5px;color:var(--sn-sub);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:1px}
.sn-pop-time{font-size:11px;color:var(--sn-faint);position:absolute;top:12px;right:16px}
.sn-pop-foot{width:100%;padding:12px;border:none;background:transparent;color:var(--sn-brand-2);font-weight:700;font-size:13px;cursor:pointer;border-top:1px solid var(--sn-line)}
.sn-pop-foot:hover{background:var(--sn-surface-2)}
.sn-notif-ic{width:34px;height:34px;border-radius:10px;background:var(--sn-brand-soft);color:var(--sn-brand-2);display:grid;place-items:center;flex-shrink:0}
.sn-unread-dot{width:8px;height:8px;border-radius:50%;background:var(--sn-brand-2);flex-shrink:0}

.sn-shell{max-width:1240px;margin:0 auto;display:grid;grid-template-columns:240px minmax(0,1fr) 320px;gap:24px;padding:22px 20px 90px}
.sn-left{position:sticky;top:82px;align-self:start;display:flex;flex-direction:column;gap:12px}
.sn-nav{display:flex;flex-direction:column;gap:3px}
.sn-navitem{display:flex;align-items:center;gap:14px;padding:11px 14px;border-radius:12px;border:none;background:transparent;color:var(--sn-sub);font-size:15px;font-weight:600;cursor:pointer;text-align:left;transition:background .14s,color .14s}
.sn-navitem:hover{background:var(--sn-surface);color:var(--sn-text)}
.sn-navitem.active{background:var(--sn-brand-soft);color:#fff}
.sn-navitem.active svg{color:var(--sn-brand-2)}
.sn-navbadge{margin-left:auto;background:var(--bad);color:#fff;font-size:11px;font-weight:800;border-radius:999px;padding:1px 7px}
.sn-post-btn{display:flex;align-items:center;justify-content:center;gap:8px;padding:12px;border-radius:12px;border:none;background:linear-gradient(135deg,var(--sn-brand),var(--sn-brand-2));color:#fff;font-weight:700;font-size:14.5px;cursor:pointer;box-shadow:0 8px 22px rgba(124,92,255,.35);transition:filter .15s,transform .08s}
.sn-post-btn:hover{filter:brightness(1.08)} .sn-post-btn:active{transform:scale(.98)}
.sn-mini-profile{display:flex;align-items:center;gap:10px;padding:10px;border-radius:12px;background:var(--sn-surface);border:1px solid var(--sn-line)}
.sn-mini-name{font-size:13.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sn-mini-handle{font-size:12px;color:var(--sn-sub)}

.sn-main{min-width:0}
.sn-col{display:flex;flex-direction:column;gap:18px}
.sn-card{background:var(--sn-surface);border:1px solid var(--sn-line);border-radius:16px}
.sn-pad{padding:16px}

.sn-right{position:sticky;top:82px;align-self:start;display:flex;flex-direction:column;gap:16px}
.sn-rail-title{display:flex;align-items:center;gap:8px;font-size:14px;font-weight:800;margin-bottom:12px}
.sn-rail-title svg{color:var(--sn-brand-2)}
.sn-trend{padding:9px 0;border-bottom:1px solid var(--sn-line);cursor:pointer}
.sn-trend:last-child{border-bottom:none}
.sn-trend-tag{font-size:14px;font-weight:700;color:var(--sn-text)}
.sn-trend-sub{font-size:12px;color:var(--sn-sub)}
.sn-trend:hover .sn-trend-tag{color:var(--sn-brand-2)}
.sn-follow{display:flex;align-items:center;gap:11px;padding:9px 0;border-bottom:1px solid var(--sn-line)}
.sn-follow:last-child{border-bottom:none}
.sn-follow-name{font-size:13.5px;font-weight:700;display:flex;align-items:center;gap:4px}
.sn-follow-handle{font-size:12px;color:var(--sn-sub)}
.sn-railfoot{font-size:11.5px;color:var(--sn-faint);line-height:1.6;padding:0 4px}

.sn-stories{display:flex;gap:16px;padding:16px;overflow-x:auto}
.sn-story{display:flex;flex-direction:column;align-items:center;gap:7px;cursor:pointer;flex-shrink:0;background:none;border:none}
.sn-story-ring{width:66px;height:66px;border-radius:50%;padding:3px;background:linear-gradient(135deg,var(--sn-brand),var(--sn-brand-2));display:grid;place-items:center}
.sn-story-ring.seen{background:var(--sn-line-2)}
.sn-story-ring.own{background:var(--sn-surface-2);border:2px dashed var(--sn-line-2)}
.sn-story-add{width:58px;height:58px;border-radius:50%;background:var(--sn-surface-2);display:grid;place-items:center;color:var(--sn-brand-2)}
.sn-story-ring .cast-photo{border:3px solid var(--sn-bg)}
.sn-story-name{font-size:11.5px;color:var(--sn-sub);max-width:64px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* story viewer */
.sn-story-bg{position:fixed;inset:0;background:rgba(0,0,0,.9);z-index:300;display:flex;align-items:center;justify-content:center;gap:14px;padding:20px}
.sn-story-view{position:relative;width:min(420px,92vw);height:min(80vh,760px);background:#000;border-radius:16px;overflow:hidden;display:flex;flex-direction:column}
.sn-story-bars{position:absolute;top:10px;left:10px;right:10px;display:flex;gap:4px;z-index:3}
.sn-story-bar{flex:1;height:3px;border-radius:3px;background:rgba(255,255,255,.35)}
.sn-story-bar.on{background:#fff}
.sn-story-header{position:absolute;top:22px;left:12px;right:12px;display:flex;align-items:center;gap:9px;z-index:3;color:#fff}
.sn-story-user{font-weight:700;font-size:13.5px;text-shadow:0 1px 4px rgba(0,0,0,.6)}
.sn-story-x{margin-left:auto;background:transparent;border:none;color:#fff;cursor:pointer}
.sn-story-img{width:100%;height:100%;object-fit:cover;cursor:pointer}
.sn-story-nav{width:44px;height:44px;border-radius:50%;border:none;background:rgba(255,255,255,.12);color:#fff;display:grid;place-items:center;cursor:pointer;flex-shrink:0}
.sn-story-nav:hover{background:rgba(255,255,255,.22)} .sn-story-nav:disabled{opacity:.3;cursor:default}

.sn-composer{display:flex;align-items:center;gap:11px;padding:14px 16px}
.sn-composer-input{flex:1;background:var(--sn-surface-2);border:1px solid var(--sn-line);border-radius:999px;padding:11px 18px;color:var(--sn-sub);font-size:14.5px;outline:none;cursor:pointer}
.sn-composer-icon{width:40px;height:40px;border-radius:11px;border:none;background:transparent;color:var(--sn-sub);display:grid;place-items:center;cursor:pointer}
.sn-composer-icon:hover{background:var(--sn-surface-2);color:var(--sn-brand-2)}

.sn-post{padding:16px}
.sn-post-head{display:flex;align-items:center;gap:12px;margin-bottom:12px}
.sn-post-name{font-weight:700;font-size:15px;display:flex;align-items:center;gap:5px}
.sn-post-name.sm{font-size:14px}
.sn-verified{color:var(--sn-brand-2)}
.sn-post-meta{font-size:12.5px;color:var(--sn-sub);display:flex;align-items:center;gap:5px}
.sn-post-text{font-size:15px;line-height:1.6;color:var(--sn-text);white-space:pre-wrap}
.sn-caption{margin-top:12px}
.sn-post-photo{margin-top:12px;width:100%;max-height:560px;object-fit:cover;border-radius:14px;display:block;background:var(--sn-surface-2)}
.sn-post-stats{display:flex;justify-content:space-between;font-size:12.5px;color:var(--sn-sub);margin:14px 0 10px;padding-bottom:10px;border-bottom:1px solid var(--sn-line)}
.sn-post-actions{display:flex;gap:4px}
.sn-post-actions button{flex:1;display:flex;align-items:center;justify-content:center;gap:8px;border:none;background:transparent;color:var(--sn-sub);font-weight:600;font-size:13.5px;padding:9px;border-radius:10px;cursor:pointer;transition:background .14s,color .14s}
.sn-post-actions button:hover{background:var(--sn-surface-2);color:var(--sn-text)}
.sn-post-actions button.liked{color:var(--sn-brand-2)}
.sn-endcap{text-align:center;color:var(--sn-faint);font-size:13px;padding:16px}

.sn-poll{margin-top:14px;display:flex;flex-direction:column;gap:8px}
.sn-poll-opt{position:relative;overflow:hidden;display:flex;align-items:center;justify-content:space-between;padding:12px 15px;border:1px solid var(--sn-line-2);border-radius:11px;background:var(--sn-surface-2);color:var(--sn-text);font-size:14px;font-weight:600;cursor:pointer;text-align:left}
.sn-poll-opt:hover{border-color:var(--sn-brand)}
.sn-poll-fill{position:absolute;left:0;top:0;bottom:0;background:var(--sn-brand-soft);z-index:0}
.sn-poll-label{position:relative;z-index:1;display:flex;align-items:center;gap:7px}
.sn-poll-pct{position:relative;z-index:1;color:var(--sn-sub);font-size:13px}
.sn-poll-votes{font-size:12px;color:var(--sn-sub);margin-top:2px}

.sn-explore-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.sn-explore-tile{aspect-ratio:1;border-radius:14px;background-size:cover;background-position:center;cursor:pointer;transition:transform .12s}
.sn-explore-tile:hover{transform:scale(.98)}

.sn-sectiontitle{display:flex;gap:13px;align-items:center}
.sn-sectionicon{width:46px;height:46px;border-radius:13px;background:var(--sn-brand-soft);color:var(--sn-brand-2);display:grid;place-items:center;flex-shrink:0}
.sn-sectiontitle h2{font-size:22px;font-weight:800;letter-spacing:-.3px}
.sn-sectiontitle p{margin:2px 0 0;color:var(--sn-sub);font-size:13.5px}

.sn-profilehero{overflow:hidden}
.sn-cover{height:120px;background:linear-gradient(135deg,var(--sn-brand),var(--sn-brand-2))}
.sn-profilehero-body{display:flex;align-items:flex-end;gap:16px;padding:0 20px;margin-top:-36px}
.sn-avatar-hero{width:88px;height:88px;border-radius:50%;background:linear-gradient(135deg,#f59e0b,#f43f5e);color:#fff;font-weight:800;font-size:32px;display:grid;place-items:center;border:4px solid var(--sn-surface)}
.sn-profilehero-info{flex:1;padding-bottom:6px}
.sn-profilehero-name{font-size:20px;font-weight:800}
.sn-profilehero-handle{font-size:13.5px;color:var(--sn-sub)}
.sn-edit-btn{margin-bottom:8px}
.sn-profilehero-bio{padding:14px 20px 4px;font-size:14px;color:var(--sn-text)}
.sn-profilehero-stats{display:flex;gap:20px;padding:8px 20px 18px;font-size:13.5px;color:var(--sn-sub)}
.sn-profilehero-stats b{color:var(--sn-text)}

.sn-about-head{font-weight:700;padding:15px 18px;border-bottom:1px solid var(--sn-line);font-size:14.5px}
.sn-about-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:13px 18px;border-bottom:1px solid var(--sn-line)}
.sn-about-row:last-child{border-bottom:none}
.sn-about-label{color:var(--sn-sub);font-size:12.5px}
.sn-about-val{font-weight:600;font-size:14.5px;margin-top:2px}

.sn-vis{position:relative}
.sn-vis-btn{display:inline-flex;align-items:center;gap:6px;padding:7px 12px;border-radius:10px;border:1px solid var(--sn-line-2);font-size:12.5px;font-weight:700;cursor:pointer;background:var(--sn-surface-2);color:var(--sn-text)}
.sn-vis-btn.warn{color:var(--bad);border-color:rgba(244,63,94,.4);background:rgba(244,63,94,.1)}
.sn-vis-btn.ok{color:var(--good);border-color:rgba(34,197,94,.35)}
.sn-caret{opacity:.6}
.sn-menu{position:absolute;top:calc(100% + 6px);background:var(--sn-elevated);border:1px solid var(--sn-line-2);border-radius:12px;box-shadow:0 16px 40px rgba(0,0,0,.5);padding:6px;z-index:30;min-width:158px}
.sn-menu.right{right:0}
.sn-menu button{display:flex;align-items:center;gap:10px;width:100%;padding:10px 12px;border:none;background:transparent;border-radius:9px;font-size:13.5px;cursor:pointer;color:var(--sn-text)}
.sn-menu button:hover{background:var(--sn-surface-2)}
.sn-menu button.sel{color:var(--sn-brand-2);font-weight:700}
.sn-menu button.danger{color:var(--bad)}

.sn-postrow{display:flex;gap:12px;padding:15px 18px;border-bottom:1px solid var(--sn-line)}
.sn-postrow:last-child{border-bottom:none}
.sn-menu-wrap{position:relative}
.sn-empty{display:flex;align-items:center;gap:8px;justify-content:center;color:var(--sn-sub);font-size:13.5px;padding:18px}

/* messages page */
.sn-msgtabs{display:flex;gap:6px}
.sn-msgtabs button{padding:9px 16px;border-radius:10px;border:1px solid var(--sn-line);background:var(--sn-surface);color:var(--sn-sub);font-weight:700;font-size:13.5px;cursor:pointer;display:flex;align-items:center}
.sn-msgtabs button.on{background:var(--sn-brand-soft);color:#fff;border-color:transparent}
.sn-chatlayout{display:grid;grid-template-columns:260px 1fr;gap:14px}
.sn-chatlist{padding:6px;max-height:520px;overflow-y:auto}
.sn-chatrow{display:flex;align-items:center;gap:11px;width:100%;padding:11px;border:none;background:transparent;border-radius:11px;cursor:pointer}
.sn-chatrow:hover{background:var(--sn-surface-2)} .sn-chatrow.on{background:var(--sn-brand-soft)}
.sn-chatpane{display:flex;flex-direction:column;height:520px}
.sn-chatpane-head{display:flex;align-items:center;gap:10px;padding:14px 16px;border-bottom:1px solid var(--sn-line);font-size:14.5px}
.sn-chatpane-body{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:9px}
.sn-bubble{max-width:75%;padding:10px 14px;border-radius:14px 14px 14px 4px;background:var(--sn-surface-2);font-size:13.5px;line-height:1.45;align-self:flex-start}
.sn-bubble.me{align-self:flex-end;background:linear-gradient(135deg,var(--sn-brand),var(--sn-brand-2));color:#fff;border-radius:14px 14px 4px 14px}
.sn-chatpane-input{display:flex;gap:8px;padding:12px;border-top:1px solid var(--sn-line)}
.sn-chatpane-input input{flex:1;background:var(--sn-surface-2);border:1px solid var(--sn-line);border-radius:999px;padding:10px 16px;color:var(--sn-text);outline:none;font-size:13.5px}

.sn-msg{display:flex;gap:12px;align-items:center;padding:14px 18px;border-bottom:1px solid var(--sn-line);cursor:pointer;transition:background .12s}
.sn-msg:last-child{border-bottom:none}
.sn-msg:hover{background:var(--sn-surface-2)}
.sn-msg.phish{background:rgba(244,63,94,.05)}
.sn-msg-from{font-weight:700;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sn-msg-addr{color:var(--sn-sub);font-weight:400;font-size:12px}
.sn-msg-subj{font-size:13px;color:var(--sn-sub);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sn-report{display:flex;align-items:center;gap:6px;border:1px solid rgba(244,63,94,.4);background:rgba(244,63,94,.1);color:var(--bad);font-weight:700;font-size:12.5px;padding:8px 12px;border-radius:10px;cursor:pointer;flex-shrink:0}
.sn-report:hover{background:rgba(244,63,94,.18)}

.sn-modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.6);backdrop-filter:blur(3px);display:grid;place-items:center;z-index:200;padding:20px}
.sn-modal{background:var(--sn-elevated);border:1px solid var(--sn-line-2);border-radius:16px;padding:24px;width:min(470px,94vw);box-shadow:0 24px 70px rgba(0,0,0,.6)}
.sn-input{width:100%;padding:12px 15px;border:1px solid var(--sn-line-2);border-radius:11px;font-size:14.5px;outline:none;background:var(--sn-surface);color:var(--sn-text)}
.sn-input:focus{border-color:var(--sn-brand)}
.sn-strength{height:6px;background:var(--sn-line-2);border-radius:999px;margin-top:11px;overflow:hidden}
.sn-strength-bar{height:100%;border-radius:999px;transition:width .2s,background .2s}
.sn-strength-bar.weak{background:var(--warn)} .sn-strength-bar.good{background:var(--good)}
.sn-warnbar{display:flex;align-items:center;gap:9px;background:rgba(244,63,94,.1);color:var(--bad);border:1px solid rgba(244,63,94,.3);border-radius:11px;padding:12px 14px;font-size:13px;font-weight:600;margin-top:14px}
.sn-warnbar.ok{background:rgba(34,197,94,.1);color:var(--good);border-color:rgba(34,197,94,.3)}

.sn-btn{display:inline-flex;align-items:center;gap:7px;padding:10px 16px;border-radius:11px;border:1px solid var(--sn-line-2);background:var(--sn-surface-2);color:var(--sn-text);font-weight:700;font-size:13.5px;cursor:pointer;transition:filter .15s,background .15s,transform .08s;white-space:nowrap}
.sn-btn:hover{background:var(--sn-elevated)} .sn-btn:active{transform:scale(.97)}
.sn-btn.primary{background:linear-gradient(135deg,var(--sn-brand),var(--sn-brand-2));border-color:transparent;color:#fff}
.sn-btn.primary:hover{filter:brightness(1.08)}
.sn-btn.danger{background:rgba(244,63,94,.1);border-color:rgba(244,63,94,.35);color:var(--bad)}
.sn-btn.ghost{background:transparent}
.sn-btn.sm{padding:8px 14px;font-size:13px} .sn-btn.xs{padding:6px 14px;font-size:12.5px;border-radius:999px}
.sn-btn:disabled{opacity:.5;cursor:not-allowed}

.sn-setrow{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:17px 18px}
.sn-set-label{font-weight:700;font-size:14.5px}
.sn-set-sub{color:var(--sn-sub);font-size:12.5px;margin-top:2px}
.sn-badge{display:inline-flex;align-items:center;gap:5px;padding:6px 12px;border-radius:999px;font-size:12px;font-weight:800}
.sn-badge.ok{background:rgba(34,197,94,.14);color:var(--good)}
.sn-badge.warn{background:rgba(245,158,11,.16);color:var(--warn)}
.sn-badge.bad{background:rgba(244,63,94,.14);color:var(--bad)}
.sn-listrow{display:flex;align-items:center;gap:14px;padding:15px 18px;border-bottom:1px solid var(--sn-line)}
.sn-listrow:last-child{border-bottom:none}
.sn-dotstat{width:11px;height:11px;border-radius:50%;flex-shrink:0}
.sn-dotstat.ok{background:var(--good)} .sn-dotstat.warn{background:var(--warn)} .sn-dotstat.bad{background:var(--bad)}
.sn-appicon{width:42px;height:42px;border-radius:12px;background:linear-gradient(135deg,var(--sn-brand),var(--sn-brand-2));color:#fff;font-weight:800;display:grid;place-items:center;flex-shrink:0}
.sn-appicon.warn{background:linear-gradient(135deg,#f59e0b,#f43f5e)}
.sn-actrow{display:flex;align-items:center;gap:12px;padding:14px 18px;border-bottom:1px solid var(--sn-line)}
.sn-actrow:last-child{border-bottom:none}
.sn-actrow.bad{background:rgba(244,63,94,.05)} .sn-actrow.warn{background:rgba(245,158,11,.06)}

@media(max-width:1080px){.sn-shell{grid-template-columns:72px minmax(0,1fr) 300px}.sn-navitem span,.sn-post-btn span,.sn-mini-profile{display:none}.sn-navitem{justify-content:center}.sn-post-btn{padding:12px 0}}
@media(max-width:860px){.sn-shell{grid-template-columns:72px minmax(0,1fr)}.sn-right{display:none}.sn-chatlayout{grid-template-columns:1fr}}
@media(max-width:560px){.sn-shell{grid-template-columns:1fr}.sn-left{display:none}.sn-explore-grid{grid-template-columns:repeat(2,1fr)}}
`;
