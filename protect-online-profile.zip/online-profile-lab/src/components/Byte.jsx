import React, { useState, useEffect, useRef } from 'react';
import {
  TASKS, TASK_ORDER, CHARACTERS, BYTE_INTRO, WHY_IT_MATTERS,
  LEARNING_OUTCOMES, SUMMARY, DISCLAIMER, LAB_META,
} from '../data/scenario.js';
import { CastPhoto } from './Cast.jsx';
import {
  Shield, ChevronRight, Check, Lock, Lightbulb, ArrowRight, X,
  MapPin, RotateCcw, Trophy, MessageSquare,
} from 'lucide-react';

/* Byte — the only lab overlay. Intros the scenario, gates the 7
   tasks (next unlocks only when the current fix is done on the
   site), and shows the summary report card in its own panel. */
export default function Byte({ state, patch, reset, activeTask, activeDone, advance, allDone, setView }) {
  const open = state.byteOpen;
  const [showHint, setShowHint] = useState(false);
  const [tab, setTab] = useState('guide'); // guide | checklist
  useEffect(() => { setShowHint(false); }, [activeTask?.id]);

  const doneCount = TASK_ORDER.filter((id) => state.completed[id]).length;
  const speaker = allDone ? 'elena' : (activeTask?.speaker || 'elena');

  return (
    <>
      {/* launcher */}
      {!open && (
        <button className="byte-launcher" onClick={() => patch({ byteOpen: true })} title="Open Byte">
          <CastPhoto id={speaker} size={54} speaking />
          {!allDone && <span className="byte-launch-badge">{doneCount}/{TASK_ORDER.length}</span>}
        </button>
      )}

      {open && (
        <div className="byte-panel">
          <style>{BYTE_CSS}</style>

          {/* header */}
          <div className="byte-head">
            <CastPhoto id={speaker} size={40} speaking />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="byte-title">Byte · Cyber Safety Guide</div>
              <div className="byte-sub">{allDone ? 'Audit complete' : `Step ${activeTask?.n} of ${TASK_ORDER.length} · ${CHARACTERS[speaker].name}`}</div>
            </div>
            <button className="byte-x" onClick={() => patch({ byteOpen: false })}><X size={17} /></button>
          </div>

          {/* progress rail */}
          <div className="byte-progress">
            {TASK_ORDER.map((id, i) => {
              const done = state.completed[id];
              const cur = !allDone && i === state.currentTask;
              return <span key={id} className={`byte-pip ${done ? 'done' : cur ? 'cur' : ''}`} />;
            })}
          </div>

          {/* intro overlay */}
          {!state.introSeen ? (
            <Intro onStart={() => { patch({ introSeen: true }); setView(TASKS[0].where); }} />
          ) : allDone ? (
            <Summary reset={reset} />
          ) : (
            <>
              {/* tabs */}
              <div className="byte-tabs">
                <button className={tab === 'guide' ? 'on' : ''} onClick={() => setTab('guide')}>Current step</button>
                <button className={tab === 'checklist' ? 'on' : ''} onClick={() => setTab('checklist')}>Checklist</button>
              </div>

              <div className="byte-body">
                {tab === 'guide' && activeTask && (
                  <div className="byte-fade">
                    <div className="byte-area">{activeTask.area}</div>
                    <div className="byte-speaker">
                      <CastPhoto id={activeTask.speaker} size={30} speaking />
                      <span>{CHARACTERS[activeTask.speaker].name} · {CHARACTERS[activeTask.speaker].role}</span>
                    </div>
                    <p className="byte-brief" dangerouslySetInnerHTML={{ __html: activeTask.brief }} />

                    <div className="byte-goal">
                      <div className="byte-goal-label">Your task</div>
                      {activeTask.goal}
                    </div>

                    <button className="byte-link" onClick={() => setView(activeTask.where)}>
                      <MapPin size={14} /> Go to the right screen
                    </button>

                    <button className="byte-hint-toggle" onClick={() => setShowHint((h) => !h)}>
                      <Lightbulb size={14} /> {showHint ? 'Hide hint' : 'Need a hint?'}
                    </button>
                    {showHint && <div className="byte-hint">{activeTask.hint}</div>}

                    {/* status + gate */}
                    <div className={`byte-status ${activeDone ? 'ok' : ''}`}>
                      {activeDone
                        ? <><Check size={16} /> {activeTask.successNote}</>
                        : <><Lock size={15} /> Complete this fix on the site to unlock the next step.</>}
                    </div>

                    <button className="byte-next" disabled={!activeDone} onClick={advance}>
                      {activeDone ? <>Next step <ArrowRight size={16} /></> : <>Locked <Lock size={15} /></>}
                    </button>
                  </div>
                )}

                {tab === 'checklist' && (
                  <div className="byte-fade">
                    <p className="byte-why">{WHY_IT_MATTERS}</p>
                    <div className="byte-checklist">
                      {TASKS.map((t, i) => {
                        const done = state.completed[t.id];
                        const cur = i === state.currentTask;
                        const locked = i > state.currentTask;
                        return (
                          <div key={t.id} className={`byte-check ${done ? 'done' : cur ? 'cur' : 'locked'}`}>
                            <span className="byte-check-icon">
                              {done ? <Check size={14} /> : locked ? <Lock size={12} /> : <span>{t.n}</span>}
                            </span>
                            <div>
                              <div className="byte-check-title">{t.area}</div>
                              <div className="byte-check-threat">{t.threat}</div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
}

function Intro({ onStart }) {
  const [shown, setShown] = useState(1);
  const lines = BYTE_INTRO.lines;
  const endRef = useRef(null);
  useEffect(() => {
    if (shown >= lines.length) return;
    const t = setTimeout(() => setShown((n) => n + 1), 1100);
    return () => clearTimeout(t);
  }, [shown, lines.length]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, [shown]);
  return (
    <div className="byte-body">
      <div className="byte-area">Welcome</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, margin: '4px 0 14px' }}>
        {lines.slice(0, shown).map((ln, i) => (
          <div key={i} className="byte-fade" style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <CastPhoto id={ln.s} size={30} speaking={i === shown - 1} />
            <div>
              <div className="byte-line-name" style={{ color: CHARACTERS[ln.s].color }}>{CHARACTERS[ln.s].name}</div>
              <div className="byte-line-bubble">{ln.t}</div>
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>
      {shown < lines.length && <button className="byte-hint-toggle" onClick={() => setShown(lines.length)}>Skip</button>}
      <button className="byte-next" onClick={onStart} style={{ marginTop: 8 }}>Start the audit <ArrowRight size={16} /></button>
    </div>
  );
}

function Summary({ reset }) {
  return (
    <div className="byte-body byte-fade">
      <div className="byte-trophy"><Trophy size={30} color="#04140d" /></div>
      <div className="byte-area" style={{ textAlign: 'center', color: 'var(--good)' }}>All seven fixed</div>
      <h3 className="byte-summary-title">{SUMMARY.passTitle}</h3>
      <p className="byte-summary-body">{SUMMARY.passBody}</p>

      <div className="byte-report">
        <div className="byte-report-head">Report card</div>
        {TASKS.map((t) => (
          <div key={t.id} className="byte-report-row">
            <Check size={15} color="var(--good)" />
            <div>
              <div className="byte-report-area">{t.area}</div>
              <div className="byte-report-threat">{t.threat} — resolved</div>
            </div>
          </div>
        ))}
      </div>

      <div className="byte-outcomes-title">{SUMMARY.outcomesTitle}</div>
      <ul className="byte-outcomes">
        {LEARNING_OUTCOMES.map((o, i) => <li key={i}><Check size={13} color="var(--good)" /> {o}</li>)}
      </ul>

      <div className="byte-cast-row">
        {['elena', 'marcus', 'priya', 'david', 'auditor'].map((id) => <CastPhoto key={id} id={id} size={34} />)}
      </div>
      <p className="byte-team-note">Your cyber safety team — nicely done.</p>

      <button className="byte-next ghost" onClick={reset}><RotateCcw size={15} /> Restart lab</button>
      <p className="byte-disclaimer">{DISCLAIMER}</p>
    </div>
  );
}

const BYTE_CSS = `
.byte-launcher{position:fixed;right:22px;bottom:22px;z-index:400;border:none;background:transparent;cursor:pointer;padding:0;border-radius:50%;filter:drop-shadow(0 8px 24px rgba(0,0,0,.4))}
.byte-launch-badge{position:absolute;bottom:-2px;right:-4px;background:var(--accent);color:#fff;font-size:11px;font-weight:800;border-radius:999px;padding:2px 7px;border:2px solid var(--bg-0)}
.byte-panel{position:fixed;right:22px;bottom:22px;z-index:400;width:390px;max-width:calc(100vw - 32px);max-height:calc(100vh - 44px);display:flex;flex-direction:column;background:var(--bg-1);border:1px solid var(--line-2);border-radius:16px;box-shadow:0 24px 70px rgba(0,0,0,.55);overflow:hidden;animation:byteIn .2s ease}
@keyframes byteIn{from{opacity:0;transform:translateY(18px) scale(.98)}to{opacity:1;transform:none}}
.byte-head{display:flex;align-items:center;gap:11px;padding:13px 14px;background:linear-gradient(135deg,rgba(99,102,241,.18),rgba(6,182,212,.06));border-bottom:1px solid var(--line)}
.byte-title{font-size:13.5px;font-weight:800}
.byte-sub{font-size:11.5px;color:var(--txt-2);margin-top:1px}
.byte-x{border:none;background:transparent;color:var(--txt-2);cursor:pointer;width:30px;height:30px;border-radius:8px;display:grid;place-items:center}
.byte-x:hover{background:var(--bg-3);color:var(--txt-0)}
.byte-progress{display:flex;gap:5px;padding:11px 14px 0}
.byte-pip{flex:1;height:5px;border-radius:999px;background:var(--bg-4)}
.byte-pip.done{background:var(--good)}
.byte-pip.cur{background:var(--accent)}
.byte-tabs{display:flex;gap:4px;padding:12px 14px 0}
.byte-tabs button{flex:1;padding:8px;border:none;border-radius:8px;background:var(--bg-3);color:var(--txt-2);font-weight:700;font-size:12.5px;cursor:pointer}
.byte-tabs button.on{background:var(--accent-soft);color:var(--txt-0)}
.byte-body{padding:14px;overflow-y:auto}
.byte-fade{animation:fadeUp .25s ease both}
.byte-area{font-size:11px;font-weight:800;letter-spacing:1px;text-transform:uppercase;color:var(--accent-2);margin-bottom:8px}
.byte-speaker{display:flex;align-items:center;gap:9px;font-size:12px;color:var(--txt-2);margin-bottom:10px}
.byte-brief{font-size:13.5px;line-height:1.6;color:var(--txt-1);margin:0 0 12px}
.byte-brief b{color:var(--txt-0)}
.byte-goal{background:var(--bg-3);border:1px solid var(--line);border-left:3px solid var(--accent);border-radius:8px;padding:11px 13px;font-size:13px;color:var(--txt-1);line-height:1.5}
.byte-goal-label{font-size:10.5px;font-weight:800;letter-spacing:.6px;text-transform:uppercase;color:var(--accent);margin-bottom:4px}
.byte-link{display:inline-flex;align-items:center;gap:7px;margin-top:11px;background:transparent;border:1px solid var(--line-2);color:var(--txt-1);font-weight:600;font-size:12.5px;padding:8px 12px;border-radius:8px;cursor:pointer}
.byte-link:hover{background:var(--bg-3)}
.byte-hint-toggle{display:inline-flex;align-items:center;gap:7px;margin:11px 0 0 8px;background:transparent;border:none;color:var(--accent-2);font-weight:600;font-size:12.5px;cursor:pointer}
.byte-hint{margin-top:9px;background:rgba(6,182,212,.08);border:1px solid rgba(6,182,212,.22);border-radius:8px;padding:10px 12px;font-size:12.5px;color:var(--txt-1);line-height:1.5}
.byte-status{display:flex;align-items:flex-start;gap:8px;margin-top:14px;padding:11px 13px;border-radius:8px;font-size:12.5px;line-height:1.5;background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.22);color:var(--warn)}
.byte-status.ok{background:rgba(16,185,129,.08);border-color:rgba(16,185,129,.25);color:var(--good)}
.byte-next{width:100%;margin-top:14px;display:flex;align-items:center;justify-content:center;gap:8px;padding:12px;border:none;border-radius:10px;background:var(--accent);color:#fff;font-weight:700;font-size:14px;cursor:pointer}
.byte-next:hover:not(:disabled){filter:brightness(1.08)}
.byte-next:disabled{background:var(--bg-4);color:var(--txt-3);cursor:not-allowed}
.byte-next.ghost{background:transparent;border:1px solid var(--line-2);color:var(--txt-1)}
.byte-why{font-size:12.5px;color:var(--txt-2);line-height:1.6;margin:0 0 14px}
.byte-checklist{display:flex;flex-direction:column;gap:7px}
.byte-check{display:flex;gap:11px;align-items:center;padding:10px 11px;border-radius:9px;background:var(--bg-2);border:1px solid var(--line)}
.byte-check.cur{border-color:var(--accent);background:var(--accent-soft)}
.byte-check.locked{opacity:.5}
.byte-check-icon{width:24px;height:24px;border-radius:50%;display:grid;place-items:center;font-size:11.5px;font-weight:800;flex-shrink:0;background:var(--bg-4);color:var(--txt-2)}
.byte-check.done .byte-check-icon{background:var(--good);color:#04140d}
.byte-check.cur .byte-check-icon{background:var(--accent);color:#fff}
.byte-check-title{font-size:13px;font-weight:700}
.byte-check-threat{font-size:11.5px;color:var(--txt-3)}
.byte-line-name{font-size:11.5px;font-weight:700;margin-bottom:3px}
.byte-line-bubble{font-size:13px;line-height:1.5;color:var(--txt-1);background:var(--bg-3);border:1px solid var(--line);border-radius:3px 11px 11px 11px;padding:9px 12px;display:inline-block}
.byte-trophy{width:56px;height:56px;border-radius:50%;background:var(--good);display:grid;place-items:center;margin:4px auto 12px}
.byte-summary-title{font-size:17px;font-weight:800;text-align:center;margin:0 0 8px}
.byte-summary-body{font-size:12.5px;color:var(--txt-2);line-height:1.6;text-align:center;margin:0 0 16px}
.byte-report{background:var(--bg-2);border:1px solid var(--line);border-radius:10px;overflow:hidden;margin-bottom:16px}
.byte-report-head{font-size:11px;font-weight:800;letter-spacing:.6px;text-transform:uppercase;color:var(--txt-3);padding:10px 13px;border-bottom:1px solid var(--line)}
.byte-report-row{display:flex;gap:10px;align-items:center;padding:9px 13px;border-bottom:1px solid var(--line)}
.byte-report-row:last-child{border-bottom:none}
.byte-report-area{font-size:13px;font-weight:600}
.byte-report-threat{font-size:11.5px;color:var(--txt-3)}
.byte-outcomes-title{font-size:12.5px;font-weight:700;margin-bottom:8px}
.byte-outcomes{list-style:none;padding:0;margin:0 0 16px;display:flex;flex-direction:column;gap:6px}
.byte-outcomes li{display:flex;gap:8px;align-items:flex-start;font-size:12.5px;color:var(--txt-1);line-height:1.5}
.byte-cast-row{display:flex;justify-content:center;gap:7px;margin-top:6px}
.byte-team-note{text-align:center;font-size:11.5px;color:var(--txt-3);margin:8px 0 12px}
.byte-disclaimer{font-size:10.5px;color:var(--txt-3);line-height:1.5;text-align:center;margin-top:14px;border-top:1px solid var(--line);padding-top:12px}
`;
