/* Decides whether each gated task is complete, based on live site state. */

export function isTaskDone(id, site) {
  switch (id) {
    case "oversharing":
      return (
        site.visibility.dob !== "public" &&
        site.visibility.mobile !== "public" &&
        site.visibility.suburb !== "public" &&
        site.awayPostDeleted
      );
    case "phishing": {
      // both phishing messages reported/removed; genuine one untouched
      const phish = site.messages.filter((m) => m.phishing);
      const genuine = site.messages.find((m) => !m.phishing);
      return phish.every((m) => m.status === "reported") && genuine && genuine.status === "inbox";
    }
    case "password":
      return site.passwordStrong === true;
    case "twofa":
      return site.twofa === "app";
    case "recovery": {
      const stale = site.sessions.find((s) => s.kind === "stale");
      return site.recoveryFixed && stale && stale.active === false;
    }
    case "apps":
      return site.apps.filter((a) => a.unused).every((a) => a.connected === false) &&
             site.apps.some((a) => !a.unused && a.connected); // kept the used one
    case "theft":
      return site.reportedTheft === true;
    default:
      return false;
  }
}

// Password strength check used by the change-password dialog.
export function isStrongPassword(pw) {
  if (!pw || pw.length < 12) return false;
  if (/jordan/i.test(pw)) return false;
  if (/^password/i.test(pw)) return false;
  if (/2019/.test(pw)) return false;
  // needs some variety: at least letters + (number or symbol) OR 3+ words
  const words = pw.trim().split(/\s+/).filter(Boolean);
  const hasVariety = /[a-zA-Z]/.test(pw) && /[0-9!@#$%^&*_\-]/.test(pw);
  return hasVariety || words.length >= 3;
}
