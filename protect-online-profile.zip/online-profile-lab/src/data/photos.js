// Bundled demo photos (royalty-free uploads). Imported so Vite
// fingerprints + bundles them. Keyed by short id used in scenario data.
import driving from '../assets/photos/driving.jpg';
import breakfast from '../assets/photos/breakfast.jpg';
import puppy from '../assets/photos/puppy.jpg';
import airplaneSunset from '../assets/photos/airplane_sunset.jpg';
import camera from '../assets/photos/camera.jpg';
import desertSunset from '../assets/photos/desert_sunset.jpg';
import smoke from '../assets/photos/smoke.jpg';
import bike from '../assets/photos/bike.jpg';
import forestCanopy from '../assets/photos/forest_canopy.jpg';
import icecream from '../assets/photos/icecream.jpg';
import beachHuts from '../assets/photos/beach_huts.jpg';
import lego from '../assets/photos/lego.jpg';

export const PHOTOS = {
  driving,
  breakfast,
  puppy,
  airplane_sunset: airplaneSunset,
  camera,
  desert_sunset: desertSunset,
  smoke,
  bike,
  forest_canopy: forestCanopy,
  icecream,
  beach_huts: beachHuts,
  lego,
};
