/* ============================================================
   scenario.js — content for "Protect Your Online Profile"
   (TAFE Cert III · Unit 5B)

   Model: a full-screen, realistic social site ("SocialNest"). The
   trainee fixes real issues ON the site. Byte (the only lab
   overlay) guides + GATES seven audit tasks — each task must be
   completed on the site before the next unlocks — then shows a
   summary/report card inside its own panel.
   ============================================================ */

export const LAB_META = {
  slug: "protect-online-profile",
  title: "Protect Your Online Profile",
  unit: "Cert III · Unit 5B",
  port: 8344,
  storeKey: "tafe-protect-online-profile-v2",
};

/* Shared cast (ids/colours constant course-wide; roles re-tagged per lab). */
export const CHARACTERS = {
  elena:   { name: "Elena Vasquez", role: "Cyber Safety Trainer", color: "#6366f1" },
  marcus:  { name: "Marcus Chen",   role: "Help Desk Team Lead",   color: "#3b82f6" },
  priya:   { name: "Priya Patel",   role: "Student Privacy Officer", color: "#10b981" },
  david:   { name: "David Okafor",  role: "Risk & Conduct Officer", color: "#f59e0b" },
  auditor: { name: "Hannah Wong",   role: "External Cyber Auditor", color: "#06b6d4" },
};

/* The fictional account under review. */
export const ACCOUNT = {
  name: "Jordan Avery",
  handle: "@jordan.avery",
  initials: "JA",
  school: "Riverton Community College",
  suburb: "Northbridge",
  dob: "14 March 2007",
  mobile: "0412 555 019",
  email: "jordan.avery@example.com",
  bio: "First-year student · music, gaming, hiking 🎧🎮🥾",
};

export const TASKS = [
  {
    id: "oversharing", n: 1, area: "Public profile exposure", where: "profile",
    threat: "Oversharing in public", speaker: "priya",
    brief: "Start on Jordan’s <b>Profile</b>. Their full date of birth, mobile number and an <b>“away on holiday”</b> post are all set to <b>Public</b> — exactly what scammers and thieves look for. Set the sensitive details to <b>Friends only</b> and take the away post down.",
    goal: "Set date of birth, mobile and suburb to Friends-only, and delete the “away next week” post.",
    hint: "On the Profile tab, use the visibility dropdown next to each field, and the ⋯ menu on the holiday post to delete it.",
    successNote: "Nice. A stranger can no longer see when Jordan’s home is empty or harvest their birthday and number.",
  },
  {
    id: "phishing", n: 2, area: "Phishing in the inbox", where: "messages",
    threat: "Phishing & scam messages", speaker: "marcus",
    brief: "Open <b>Messages</b>. Two are phishing: a fake <b>“verify within 24 hours”</b> from <b>socialnest-secure-verify.tk</b>, and a “prize” asking Jordan to <b>confirm their password</b>. Don’t click either — <b>report and delete</b> both.",
    goal: "Report both phishing messages. Leave the genuine message from Sam alone.",
    hint: "Use the ⚠ Report button on each suspicious message. The real message from a friend should stay.",
    successNote: "Exactly right — reported and gone, and you never touched the links. That’s how account takeovers get stopped.",
  },
  {
    id: "password", n: 3, area: "Password strength & reuse", where: "security",
    threat: "Weak / reused passwords", speaker: "elena",
    brief: "Go to <b>Settings → Security</b>. The password is <b>“jordan2019”</b> and it’s reused on email and a shopping site. Change it to a <b>long, unique passphrase</b>. A password manager makes this easy — just don’t reuse it.",
    goal: "Change the password to a strong, unique one (long, not “jordan”-based).",
    hint: "Click “Change password”. Aim for 12+ characters, a few unrelated words, nothing tied to the name or year.",
    successNote: "Strong and unique — now one leaked site can’t unlock everything Jordan owns.",
  },
  {
    id: "twofa", n: 4, area: "Two-factor authentication", where: "security",
    threat: "No two-factor authentication", speaker: "elena",
    brief: "Still in <b>Security</b>: two-factor authentication is <b>off</b>. Turn it <b>on with an authenticator app</b> (stronger than SMS). Even if the password leaks, a second step blocks the login.",
    goal: "Enable two-factor authentication using the Authenticator app option.",
    hint: "Toggle 2FA on and choose “Authenticator app” rather than SMS.",
    successNote: "That’s the single biggest win. A stolen password alone is now useless.",
  },
  {
    id: "recovery", n: 5, area: "Recovery & active sessions", where: "security",
    threat: "Risky recovery & login settings", speaker: "marcus",
    brief: "The <b>recovery email</b> is an old address Jordan no longer controls, and there’s a <b>library-PC session</b> still signed in from three weeks ago. Update the recovery email and <b>sign that session out</b>.",
    goal: "Update the recovery email to a current address AND sign out the old library-PC session.",
    hint: "Fix the recovery email field in Security, then open Login activity and “Sign out” the library-PC session.",
    successNote: "Both doors closed — the “forgot password” path is back in Jordan’s hands and the stale session is gone.",
  },
  {
    id: "apps", n: 6, area: "Connected apps & access", where: "apps",
    threat: "Over-permitted connected apps", speaker: "auditor",
    brief: "Open <b>Connected apps</b>. <b>QuizMania</b> and <b>PhotoFilter Pro</b> haven’t been used in a year but still have <b>full account access</b>. Remove the unused ones. Leave the Campus Calendar app Jordan uses daily.",
    goal: "Remove the two unused, over-permitted apps. Keep the app Jordan actively uses.",
    hint: "Use “Remove access” on QuizMania and PhotoFilter Pro. Don’t remove Campus Calendar.",
    successNote: "Good judgement — you shut the doors Jordan didn’t use without breaking the one they rely on.",
  },
  {
    id: "theft", n: 7, area: "Early signs of theft", where: "activity",
    threat: "Early signs of account theft", speaker: "david",
    brief: "Last one. Check <b>Account activity</b>: a <b>$1.20 “test” charge</b> from an unknown merchant and a <b>login from Perth</b> Jordan didn’t make. Those are classic early signs of theft. <b>Report it</b> as suspicious activity so we can secure the account.",
    goal: "Report the suspicious charge / login as possible account theft.",
    hint: "Use “Report suspicious activity” on the flagged charge or the unfamiliar Perth login.",
    successNote: "Reported and logged. Catching it this early is exactly why the small stuff matters.",
  },
];

export const TASK_ORDER = TASKS.map((t) => t.id);

export function initialSite() {
  return {
    visibility: { dob: "public", mobile: "public", suburb: "public", school: "public" },
    awayPostDeleted: false,
    messages: [
      { id: "m1", from: "SocialNest Security", addr: "no-reply@socialnest-secure-verify.tk", subject: "Unusual login detected — verify within 24 hours", body: "We noticed a login from a new device. Verify now or your account will be locked. [ Verify now ]", phishing: true, status: "inbox" },
      { id: "m2", from: "Prizes Team", addr: "win@socialnest-rewards.top", subject: "You’ve won a $500 gift card!", body: "Confirm your password to claim your reward before it expires today.", phishing: true, status: "inbox" },
      { id: "m3", from: "Sam", addr: "sam.friend", subject: "movie fri?", body: "you free friday night? new film out 🎥", phishing: false, status: "inbox" },
    ],
    password: "jordan2019",
    passwordStrong: false,
    twofa: "off",
    recoveryEmail: "old-address@oldmail.com",
    recoveryFixed: false,
    sessions: [
      { id: "s1", device: "This device · Chrome", loc: "Northbridge (you)", when: "now", kind: "current" },
      { id: "s2", device: "Library PC · Firefox", loc: "Campus library", when: "3 weeks ago", kind: "stale", active: true },
      { id: "s3", device: "Unknown Android · SocialNest app", loc: "Perth", when: "last night", kind: "unknown", active: true },
    ],
    apps: [
      { id: "a1", name: "QuizMania", access: "Full account access", used: "14 months ago", unused: true, connected: true },
      { id: "a2", name: "PhotoFilter Pro", access: "Full account access", used: "11 months ago", unused: true, connected: true },
      { id: "a3", name: "Campus Calendar", access: "Read calendar", used: "today", unused: false, connected: true },
    ],
    activity: [
      { id: "t1", label: "−$1.20", desc: "Unknown merchant (TEST*XYZ)", when: "today", flag: "bad", reported: false },
      { id: "t2", label: "−$14.00", desc: "Campus Cafe", when: "yesterday", flag: null },
      { id: "t3", label: "Login alert", desc: "New sign-in from Perth", when: "last night", flag: "warn", reported: false },
      { id: "t4", label: "−$9.99", desc: "Music subscription", when: "3 days ago", flag: null },
    ],
    reportedTheft: false,
  };
}

export const BYTE_INTRO = {
  speaker: "elena",
  lines: [
    { s: "elena", t: "Morning! You’re on the cyber safety desk today. This is Jordan Avery’s practice account on SocialNest — they’ve let trainees review it." },
    { s: "marcus", t: "It’s got the usual problems a real account picks up. Your job: find each one and actually fix it on the site." },
    { s: "priya", t: "I’ll walk you through it one step at a time. You can’t skip ahead — finish each fix and the next unlocks. Ready when you are." },
  ],
};

export const WHY_IT_MATTERS =
  "Most account breaches don’t start with clever hacking — they start with oversharing, a reused password, one convincing phishing message, or an old app that still has access. The checklist you use on Jordan’s account is the same one you’ll use on your own.";

export const LEARNING_OUTCOMES = [
  "Identify common threats to online profiles.",
  "Recognise phishing messages and suspicious interactions.",
  "Audit public exposure, passwords, logins and connected apps.",
  "Apply fixes: privacy settings, strong passwords, and two-factor authentication.",
  "Spot early indicators of account theft.",
  "Report suspicious cyber activity the right way.",
];

export const SUMMARY = {
  passTitle: "Audit complete — account secured",
  passBody:
    "You worked through every threat: locked down the public profile, cleared the phishing, fixed the password and turned on 2FA, sorted recovery and sessions, removed risky apps, and reported the suspicious activity. That’s a full profile audit, start to finish — and the exact routine to run on your own accounts.",
  outcomesTitle: "What you practised",
};

export const DISCLAIMER =
  "Training simulation. “SocialNest”, Riverton Community College, Jordan Avery and all data shown are fictional and offline — no real accounts are involved. Built for the Cert III unit “Protect Your Online Profile”.";


/* ============================================================
   SocialNest feed content. Cast appear as real profiles.
   Priya is intentionally NOT in the feed/stories/suggestions —
   she appears only inside Byte. Realistic everyday posts using
   bundled royalty-free photos, with quote-style captions.
   Photo ids map to src/data/photos.js -> PHOTOS[id].
   ============================================================ */

// Feed-facing profiles (handle, headline, followers). No Priya here.
export const PROFILES = {
  elena:   { handle: "@elena.v",      headline: "Trainer · weekend hiker · coffee first", followers: "4.2k", verified: true },
  marcus:  { handle: "@marcuschen",   headline: "IT by day, cyclist by dawn", followers: "2.8k", verified: true },
  david:   { handle: "@david.okafor", headline: "Dad, reader, sunset chaser", followers: "1.9k", verified: false },
  auditor: { handle: "@hannahwong",   headline: "Photographer · traveller · film nerd", followers: "6.1k", verified: true },
};

/* Stories rail. Priya removed. The 4 remaining cast each carry
   one or more of the uploaded photos, viewable when clicked. */
export const STORIES = [
  { id: "own", name: "Your story", own: true },
  { id: "elena", name: "Elena", cast: "elena", seen: false, photos: ["forest_canopy", "puppy"] },
  { id: "hannah", name: "Hannah", cast: "auditor", seen: false, photos: ["airplane_sunset", "camera"] },
  { id: "marcus", name: "Marcus", cast: "marcus", seen: true, photos: ["bike"] },
  { id: "david", name: "David", cast: "david", seen: false, photos: ["desert_sunset"] },
];

/* Realistic everyday feed. Mix of the cast + a few extra community
   accounts, photos with quote-style captions, one poll. */
export const FEED = [
  {
    id: "f1", cast: "auditor", time: "18m", kind: "image", photo: "airplane_sunset",
    caption: "“Once a year, go somewhere you’ve never been before.” Wheels up. ✈️",
    likes: 642, comments: 54, shares: 21, liked: false,
  },
  {
    id: "f2", cast: "elena", time: "40m", kind: "image", photo: "puppy",
    caption: "Meet the newest member of the household. Zero emails answered today and no regrets. 🐶",
    likes: 981, comments: 133, shares: 40, liked: true,
  },
  {
    id: "f3", cast: "marcus", time: "1h", kind: "image", photo: "bike",
    caption: "“Life is like riding a bicycle — to keep your balance you must keep moving.” 32km before work. 🚲",
    likes: 288, comments: 27, shares: 12, liked: false,
  },
  {
    id: "f4", cast: "david", time: "2h", kind: "image", photo: "desert_sunset",
    caption: "“The quieter you become, the more you can hear.” Golden hour in the dunes. 🌅",
    likes: 415, comments: 38, shares: 33, liked: false,
  },
  {
    id: "f5", cast: "quinn", time: "3h", kind: "image", photo: "icecream",
    caption: "Double scoop kind of day. Strawberry + vanilla, don’t @ me. 🍦",
    likes: 173, comments: 22, shares: 4, liked: false,
  },
  {
    id: "f6", cast: "auditor", time: "5h", kind: "image", photo: "camera",
    caption: "“We take photos as a return ticket to a moment otherwise gone.” Cleaned up my old film camera today.",
    likes: 526, comments: 61, shares: 29, liked: true,
  },
  {
    id: "f7", cast: "leo", time: "6h", kind: "image", photo: "beach_huts",
    caption: "Woke up to this. Palm trees, salt air, absolutely nowhere to be. 🏝️",
    likes: 734, comments: 47, shares: 58, liked: false,
  },
  {
    id: "f8", cast: "elena", time: "7h", kind: "image", photo: "forest_canopy",
    caption: "“In every walk with nature one receives far more than he seeks.” Trail therapy. 🌿",
    likes: 402, comments: 30, shares: 18, liked: false,
  },
  {
    id: "f9", cast: "maya", time: "9h", kind: "image", photo: "breakfast",
    caption: "Slow mornings and hotel breakfast in bed. This is the whole trip, honestly. 🥐☕",
    likes: 219, comments: 15, shares: 6, liked: false,
  },
  {
    id: "f10", cast: "david", time: "11h", kind: "text",
    text: "Started a new book last night and stayed up way too late. Worth it. What’s everyone reading right now? 📚",
    likes: 156, comments: 72, shares: 3, liked: false,
  },
  {
    id: "f11", cast: "marcus", time: "13h", kind: "image", photo: "driving",
    caption: "“Sometimes the best therapy is a long drive and good music.” Road trip season is officially open. 🚗",
    likes: 311, comments: 24, shares: 19, liked: false,
  },
  {
    id: "f12", cast: "quinn", time: "16h", kind: "poll",
    text: "Settling this once and for all — best season?",
    poll: [
      { label: "Summer ☀️", pct: 44 },
      { label: "Autumn 🍂", pct: 39 },
      { label: "Winter ❄️", pct: 17 },
    ], votes: "2,038 votes",
    likes: 88, comments: 41, shares: 2, liked: false,
  },
  {
    id: "f13", cast: "leo", time: "19h", kind: "image", photo: "smoke",
    caption: "Behind the scenes from yesterday’s shoot. Red smoke + city skyline = one of my favourite frames this year. 📸",
    likes: 597, comments: 44, shares: 37, liked: false,
  },
  {
    id: "f14", cast: "maya", time: "22h", kind: "image", photo: "lego",
    caption: "Spent the afternoon sorting these with my nephew. He found it more relaxing than I did. 🧱",
    likes: 142, comments: 19, shares: 5, liked: false,
  },
];

/* Non-cast community accounts referenced by the feed. */
export const COMMUNITY = {
  quinn: { name: "Quinn Alvarez", handle: "@quinnbites", color: "#f59e0b", verified: false },
  leo:   { name: "Leo Martins",   handle: "@leoshoots",  color: "#06b6d4", verified: true },
  maya:  { name: "Maya. R",      handle: "@maya.travels", color: "#ec4899", verified: false },
};

/* Who to follow — people NOT already dominating the feed, so it
   makes sense as a suggestion. Non-cast handles. */
export const SUGGESTIONS = [
  { id: "s_river", name: "Riverton College", handle: "@rivertoncollege", color: "#7c5cff", verified: true, note: "Official campus account" },
  { id: "s_music", name: "Campus Music Society", handle: "@rivertonmusic", color: "#22c55e", verified: false, note: "3 friends follow" },
  { id: "s_trails", name: "Weekend Trails AU", handle: "@weekendtrails", color: "#f59e0b", verified: false, note: "Based on your interests" },
];

export const TRENDS = [
  { tag: "#GoldenHour", posts: "12.4k posts" },
  { tag: "#WeekendVibes", posts: "8,902 posts" },
  { tag: "#RoadTrip", posts: "5,530 posts" },
  { tag: "#FilmPhotography", posts: "3,110 posts" },
  { tag: "#PuppiesOfSocialNest", posts: "2,876 posts" },
];

/* Direct messages (for the working Messages panel in the top bar). */
export const DMS = [
  { id: "d1", cast: "auditor", name: "Hannah Wong", preview: "Did you get the photos I sent from the trip?", time: "2m", unread: true,
    thread: [
      { me: false, t: "Hey! Did you get the photos I sent from the trip?" },
      { me: false, t: "The sunset one from the plane turned out unreal 😍" },
      { me: true, t: "Just saw them, they're gorgeous!! the airplane one is my favourite" },
      { me: false, t: "Right? I nearly missed it, had like 10 seconds before the clouds rolled in" },
      { me: false, t: "Anyway — did you get them ok or should I resend the full-res versions?" },
    ] },
  { id: "d2", cast: "marcus", name: "Marcus Chen", preview: "Ride Saturday morning? 6am start 🚲", time: "26m", unread: true,
    thread: [
      { me: false, t: "Ride Saturday morning? 6am start 🚲" },
      { me: true, t: "6am is aggressive but ok, count me in" },
      { me: false, t: "That's the spirit. Bring water this time 😂" },
      { me: true, t: "One time I forget water and you never let it go" },
      { me: false, t: "Route's about 32km, we'll grab coffee after. Meet at the usual spot?" },
    ] },
  { id: "d3", cast: "elena", name: "Elena Vasquez", preview: "The puppy pics are killing me 🐶", time: "1h", unread: true,
    thread: [
      { me: false, t: "The puppy pics are killing me, so cute" },
      { me: true, t: "Right?? total chaos but worth it" },
      { me: false, t: "What's the name??" },
      { me: true, t: "Still deciding! shortlist is Biscuit, Mango or Noodle 😅" },
      { me: false, t: "Noodle. 100% Noodle. Don't overthink it" },
    ] },
  { id: "d4", cast: "david", name: "David Okafor", preview: "Sending you that book title now 📚", time: "3h", unread: false,
    thread: [
      { me: true, t: "What was the book you mentioned the other day?" },
      { me: false, t: "Sending you that book title now" },
      { me: false, t: "It's \"The Midnight Library\" — really easy read, you'll finish it in a weekend" },
      { me: true, t: "Perfect, adding it to the list. Thanks!" },
    ] },
  { id: "d5", cast: "quinn", name: "Quinn Alvarez", preview: "the cafe on 5th does the best cold brew", time: "5h", unread: false,
    thread: [
      { me: false, t: "ok you HAVE to try the cafe on 5th, best cold brew in town" },
      { me: true, t: "oh nice, is that the one near the library?" },
      { me: false, t: "yep! go before 9 though, it gets packed" },
    ] },
  { id: "d6", cast: "leo", name: "Leo Martins", preview: "shoot went great, sending previews soon", time: "yesterday", unread: false,
    thread: [
      { me: false, t: "shoot went great today! got some really strong frames" },
      { me: true, t: "amazing, can't wait to see them" },
      { me: false, t: "sending previews soon, still editing the smoke series 📸" },
    ] },
];

/* Notifications (for the working bell panel). */
export const NOTIFICATIONS = [
  { id: "n1", cast: "auditor", kind: "like", text: "Hannah Wong liked your photo.", time: "3m", unread: true },
  { id: "n2", cast: "marcus", kind: "comment", text: "Marcus Chen commented: “Great shot!”", time: "21m", unread: true },
  { id: "n3", cast: "elena", kind: "follow", text: "Elena Vasquez started following you.", time: "1h", unread: true },
  { id: "n4", cast: "david", kind: "mention", text: "David Okafor mentioned you in a comment.", time: "4h", unread: false },
  { id: "n5", cast: "auditor", kind: "share", text: "Hannah Wong shared your post.", time: "yesterday", unread: false },
];
