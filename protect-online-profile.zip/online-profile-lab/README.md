# Protect Your Online Profile — Interactive Cyber Safety Lab

TAFE Cert III · Unit 5B. A hands-on, browser-based lab where the student audits a
test user's account on **Linkup** (a fictional social platform), finds the privacy
and security problems, and fixes them — guided and gated by the **Byte** assistant.

The Linkup site is a full, realistic social platform. Byte is the only lab overlay:
it walks through **seven audit tasks** in order and unlocks each one only after the
previous fix is actually done on the site, then shows a summary report card.

## The seven gated tasks
1. Public profile exposure — set sensitive fields to Friends-only, delete the "away" post
2. Phishing in the inbox — report the two phishing messages
3. Password strength & reuse — set a strong, unique passphrase
4. Two-factor authentication — turn on app-based 2FA
5. Recovery & active sessions — fix recovery email + sign out the stale session
6. Connected apps — remove the unused, over-permitted apps
7. Early signs of theft — report the suspicious charge / login

## Run it (one command)
```bash
docker compose up --build
# open http://localhost:8344
```
The container restarts automatically (`restart: unless-stopped`).

Or with plain Docker:
```bash
docker build -t protect-online-profile .
docker run -d --name protect-online-profile -p 8344:8344 --restart unless-stopped protect-online-profile
# open http://localhost:8344
```

## Develop
```bash
npm install
npm run dev      # http://localhost:8344
```

Progress is saved in the browser (localStorage). Everything is fictional and offline.
