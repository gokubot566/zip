import puppeteer from 'puppeteer';
import http from 'http';
import { readFileSync, existsSync, statSync } from 'fs';
import { join, extname } from 'path';

const ROOT = new URL('../build', import.meta.url).pathname;
const CHROME = '/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome';
const PORT = 8923;
const MIME = { '.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.json':'application/json','.woff':'font/woff','.woff2':'font/woff2','.jpg':'image/jpeg' };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  let fp = join(ROOT, p);
  if (!existsSync(fp) || !statSync(fp).isFile()) fp = join(ROOT, 'index.html');
  res.writeHead(200, { 'Content-Type': MIME[extname(fp)] || 'application/octet-stream' });
  res.end(readFileSync(fp));
});

const results = [];
const check = (name, cond, detail='') => { results.push({ name, pass: !!cond }); console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function clickByText(page, sel, text, tries = 20) {
  for (let i = 0; i < tries; i++) {
    const clicked = await page.evaluate((s, txt) => {
      for (const el of Array.from(document.querySelectorAll(s))) {
        const r = el.getBoundingClientRect();
        if (el.textContent && el.textContent.includes(txt) && r.width > 0 && r.height > 0 && !el.disabled) { el.click(); return true; }
      }
      return false;
    }, sel, text);
    if (clicked) return true;
    await sleep(120);
  }
  return false;
}

async function main() {
  await new Promise((r) => server.listen(PORT, r));
  const browser = await puppeteer.launch({ executablePath: CHROME, headless: 'new', args: ['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'] });

  // ============================================================
  // A. NEGATIVE GATING — a weak password must NOT unlock the step
  // ============================================================
  {
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 950 });
    const errors = []; page.on('pageerror', e => errors.push(e.message));
    page.on('dialog', async d => { try { await d.accept(); } catch (e) {} });
    await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'networkidle0' });
    await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
    // jump straight to the password task
    await page.evaluate(() => {
      const k = 'tafe-protect-online-profile-v2';
      localStorage.setItem(k, JSON.stringify({ completed: { oversharing: true, phishing: true }, currentTask: 2, introSeen: true, exploreSeen: true, byteOpen: true, view: 'security', site: {} }));
    });
    await page.reload({ waitUntil: 'networkidle0' }); await sleep(700);

    // open change-password, try a WEAK password (the old reused one)
    await clickByText(page, '.sn-btn', 'Change password', 8); await sleep(300);
    await page.$eval('.sn-modal .sn-input', el => { el.value = ''; });
    await page.type('.sn-modal .sn-input', 'jordan2019', { delay: 0 });
    await sleep(200);
    const saveDisabledWeak = await page.$eval('.sn-modal .sn-btn.primary', el => el.disabled).catch(() => null);
    check('NEG weak password (jordan2019) — Save is disabled', saveDisabledWeak === true);
    // policy checklist should show most requirements UNMET (jordan2019 = 10 chars,
    // has lowercase + a number, but fails length/uppercase/symbol/no-year → 2 met)
    const okItemsWeak = await page.$$eval('.sn-pw-policy li.ok', els => els.length).catch(() => -1);
    check('NEG weak password — most requirements unmet (fails length/uppercase/symbol/year)', okItemsWeak <= 3 && okItemsWeak < 6, `${okItemsWeak}/6 met`);

    // now a strong one enables Save
    await page.$eval('.sn-modal .sn-input', el => { el.value = ''; });
    await page.type('.sn-modal .sn-input', 'Coffee-River-Sunset7!', { delay: 0 });
    await sleep(200);
    const okItemsStrong = await page.$$eval('.sn-pw-policy li.ok', els => els.length).catch(() => -1);
    check('POS strong password — all 6 policy items tick green', okItemsStrong === 6, `${okItemsStrong}/6`);
    const saveEnabledStrong = await page.$eval('.sn-modal .sn-btn.primary', el => !el.disabled).catch(() => false);
    check('POS strong password — Save is enabled', saveEnabledStrong);

    // Byte step still locked BEFORE saving
    const gateBefore = await page.$eval('.byte-next', el => !el.disabled).catch(() => false);
    check('NEG Byte step stays LOCKED until password actually saved', gateBefore === false);

    // save and confirm it unlocks
    await clickByText(page, '.sn-modal .sn-btn.primary', 'Save password', 6); await sleep(400);
    const gateAfter = await page.$eval('.byte-next', el => !el.disabled).catch(() => false);
    check('POS Byte step UNLOCKS after saving a strong password', gateAfter === true);

    check('A no page errors', errors.length === 0, errors.slice(0,2).join(' | '));
    await page.close();
  }

  // ============================================================
  // B. NEGATIVE GATING — 2FA via SMS must NOT satisfy (needs app)
  // ============================================================
  {
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 950 });
    const errors = []; page.on('pageerror', e => errors.push(e.message));
    page.on('dialog', async d => { try { await d.accept(); } catch (e) {} });
    await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'networkidle0' });
    await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
    await page.evaluate(() => {
      const k = 'tafe-protect-online-profile-v2';
      localStorage.setItem(k, JSON.stringify({ completed: { oversharing: true, phishing: true, password: true }, currentTask: 3, introSeen: true, exploreSeen: true, byteOpen: true, view: 'security', site: { passwordStrong: true } }));
    });
    await page.reload({ waitUntil: 'networkidle0' }); await sleep(700);

    // choose SMS — should NOT unlock (task requires authenticator app)
    await clickByText(page, '.sn-btn', 'Use SMS', 8); await sleep(400);
    const gateSms = await page.$eval('.byte-next', el => !el.disabled).catch(() => false);
    check('NEG 2FA via SMS does NOT unlock the step (app required)', gateSms === false);

    // choose authenticator app — should unlock
    await clickByText(page, '.sn-btn', 'Use authenticator app', 8); await sleep(400);
    const gateApp = await page.$eval('.byte-next', el => !el.disabled).catch(() => false);
    check('POS 2FA via authenticator app unlocks the step', gateApp === true);

    check('B no page errors', errors.length === 0, errors.slice(0,2).join(' | '));
    await page.close();
  }

  // ============================================================
  // C. PERSISTENCE — progress survives a page reload
  // ============================================================
  {
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 950 });
    const errors = []; page.on('pageerror', e => errors.push(e.message));
    page.on('dialog', async d => { try { await d.accept(); } catch (e) {} });
    await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'networkidle0' });
    await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
    // simulate 3 completed tasks, on task 4
    await page.evaluate(() => {
      const k = 'tafe-protect-online-profile-v2';
      localStorage.setItem(k, JSON.stringify({ completed: { oversharing: true, phishing: true, password: true }, currentTask: 3, introSeen: true, exploreSeen: true, byteOpen: true, view: 'security', site: { passwordStrong: true } }));
    });
    await page.reload({ waitUntil: 'networkidle0' }); await sleep(600);
    const pipsBefore = await page.$$eval('.byte-pip.done', els => els.length).catch(() => -1);
    check('C 3 done pips before reload', pipsBefore === 3, `${pipsBefore}`);
    // reload again — progress must persist
    await page.reload({ waitUntil: 'networkidle0' }); await sleep(600);
    const pipsAfter = await page.$$eval('.byte-pip.done', els => els.length).catch(() => -1);
    check('C progress persists across reload (still 3 done)', pipsAfter === 3, `${pipsAfter}`);
    const area = await page.$eval('.byte-area', el => el.textContent).catch(() => '');
    check('C still on Task 4 after reload', /two-factor/i.test(area), area);
    check('C no page errors', errors.length === 0, errors.slice(0,2).join(' | '));
    await page.close();
  }

  // ============================================================
  // D. MOBILE VIEWPORT — renders + robot header + drag works
  // ============================================================
  {
    const page = await browser.newPage();
    await page.setViewport({ width: 390, height: 780, isMobile: true, hasTouch: true });
    const errors = []; page.on('pageerror', e => errors.push(e.message));
    page.on('dialog', async d => { try { await d.accept(); } catch (e) {} });
    await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'networkidle0' });
    await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
    await page.reload({ waitUntil: 'networkidle0' }); await sleep(800);

    check('MOBILE Byte panel mounts', !!(await page.$('.byte-panel')));
    check('MOBILE header shows robot avatar', !!(await page.$('.byte-head .byte-avatar svg')));
    // panel should fit within the ACTUAL layout viewport (headless isMobile
    // can report a wider innerWidth than the configured width, so measure live)
    const pr = await page.$eval('.byte-panel', el => { const r = el.getBoundingClientRect(); return { left: r.left, w: r.width, right: r.right }; });
    const realVw = await page.evaluate(() => window.innerWidth);
    check('MOBILE panel fits viewport width (fully on-screen)', pr.left >= 8 && pr.right <= realVw + 2, `left=${Math.round(pr.left)}, right=${Math.round(pr.right)}/${realVw}`);

    // jump to password task and confirm policy renders (single-column on mobile)
    await page.evaluate(() => {
      const k = 'tafe-protect-online-profile-v2';
      localStorage.setItem(k, JSON.stringify({ completed: { oversharing: true, phishing: true }, currentTask: 2, introSeen: true, exploreSeen: true, byteOpen: true, view: 'security', site: {} }));
    });
    await page.reload({ waitUntil: 'networkidle0' }); await sleep(700);
    check('MOBILE password policy box renders', !!(await page.$('.byte-policy')));
    const polItems = await page.$$eval('.byte-policy-list li', els => els.length).catch(() => 0);
    check('MOBILE policy lists all requirements', polItems >= 5, `${polItems} items`);

    // 2FA definition on mobile
    await page.evaluate(() => {
      const k = 'tafe-protect-online-profile-v2';
      const r = JSON.parse(localStorage.getItem(k)); r.completed = { oversharing: true, phishing: true, password: true }; r.currentTask = 3; r.site = { ...r.site, passwordStrong: true };
      localStorage.setItem(k, JSON.stringify(r));
    });
    await page.reload({ waitUntil: 'networkidle0' }); await sleep(700);
    await page.$eval('.byte-def-toggle', el => el.click()).catch(() => {});
    await sleep(300);
    check('MOBILE 2FA definition expands', !!(await page.$('.byte-def')));

    check('D no page errors', errors.length === 0, errors.slice(0,2).join(' | '));
    await page.close();
  }

  await browser.close();
  server.close();
  const passed = results.filter(r => r.pass).length, total = results.length;
  console.log(`\n==================== HARDENING SUMMARY ====================`);
  console.log(`${passed}/${total} checks passed`);
  results.filter(r => !r.pass).forEach(r => console.log('  FAILED: ' + r.name));
  console.log(`RESULT: ${passed === total ? 'ALL PASS ✓' : 'FAILURES ✗'}`);
  process.exit(passed === total ? 0 : 1);
}
main().catch((e) => { console.error(e); server.close(); process.exit(1); });
