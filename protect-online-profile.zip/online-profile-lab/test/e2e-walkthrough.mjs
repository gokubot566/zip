import puppeteer from 'puppeteer';
import http from 'http';
import { readFileSync, existsSync, statSync } from 'fs';
import { join, extname } from 'path';

const ROOT = new URL('../build', import.meta.url).pathname;
const CHROME = '/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome';
const PORT = 8922;
const MIME = { '.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.json':'application/json','.woff':'font/woff','.woff2':'font/woff2','.jpg':'image/jpeg' };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  let fp = join(ROOT, p);
  if (!existsSync(fp) || !statSync(fp).isFile()) fp = join(ROOT, 'index.html');
  res.writeHead(200, { 'Content-Type': MIME[extname(fp)] || 'application/octet-stream' });
  res.end(readFileSync(fp));
});

const results = [];
const check = (name, cond, detail='') => { results.push({ name, pass: !!cond }); console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function main() {
  await new Promise((r) => server.listen(PORT, r));
  const browser = await puppeteer.launch({ executablePath: CHROME, headless: 'new', args: ['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 950 });
  const errors = [];
  page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message));
  page.on('dialog', async (d) => { try { await d.accept(); } catch (e) {} });

  await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'networkidle0' });
  await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'networkidle0' });
  await sleep(800);

  async function clickByText(sel, text, tries = 25) {
    for (let i = 0; i < tries; i++) {
      const clicked = await page.evaluate((s, txt) => {
        for (const el of Array.from(document.querySelectorAll(s))) {
          const r = el.getBoundingClientRect();
          if (el.textContent && el.textContent.includes(txt) && r.width > 0 && r.height > 0 && !el.disabled) { el.click(); return true; }
        }
        return false;
      }, sel, text);
      if (clicked) return true;
      await sleep(120);
    }
    return false;
  }
  const gateOpen = () => page.$eval('.byte-next', el => !el.disabled).catch(() => false);
  const areaText = () => page.$eval('.byte-area', el => el.textContent).catch(() => '');
  async function gotoScreen() { await clickByText('.byte-link', 'Go to the right screen', 8); await sleep(350); }
  async function nav(label) { await clickByText('.sn-navitem', label, 10); await sleep(350); }
  async function nextStep() { const ok = await clickByText('.byte-next', 'Next step', 15); await sleep(400); return ok; }

  // intro -> explore -> tasks
  await clickByText('.byte-hint-toggle', 'Skip introductions', 10); await sleep(250);
  await clickByText('.byte-next', 'take a look around', 20); await sleep(350);
  await clickByText('.byte-next', 'start the audit', 20); await sleep(500);
  check('reached first task', /exposure|Public profile/i.test(await areaText()), await areaText());

  let done = 0;

  // ---- Task 1: oversharing (profile) — set dob/mobile/suburb to Friends, delete away post ----
  await gotoScreen();
  // open each VisPicker and choose "Friends only"
  const pickers = await page.$$('.sn-vis');
  for (let i = 0; i < pickers.length; i++) {
    // re-query each time (DOM updates)
    const ps = await page.$$('.sn-vis');
    if (!ps[i]) continue;
    const btn = await ps[i].$('.sn-vis-btn');
    if (btn) { await btn.click(); await sleep(150); }
    await clickByText('.sn-menu.right button', 'Friends only', 5);
    await sleep(150);
  }
  // delete the away post via its ⋯ menu
  const moreBtns = await page.$$('.sn-menu-wrap .sn-iconbtn');
  if (moreBtns[0]) { await moreBtns[0].click(); await sleep(200); }
  await clickByText('.sn-menu.right button', 'Delete post', 5);
  await sleep(300);
  check('T1 gate open (oversharing)', await gateOpen());
  if (await gateOpen()) { await nextStep(); done++; }

  // ---- Task 2: phishing (messages) — report both phishing, leave genuine ----
  await gotoScreen();
  await clickByText('.sn-msgtabs button', 'Requests', 6); await sleep(250);
  // report each phishing message: open it, click "Report as phishing"
  for (let k = 0; k < 3; k++) {
    const phish = await page.$('.sn-msg.phish');
    if (!phish) break;
    await phish.click(); await sleep(250);
    await clickByText('.sn-btn.danger', 'Report as phishing', 6);
    await sleep(300);
  }
  check('T2 gate open (phishing)', await gateOpen());
  if (await gateOpen()) { await nextStep(); done++; }

  // ---- Task 3: password (security) — change to strong ----
  await gotoScreen();
  await clickByText('.sn-btn', 'Change password', 8); await sleep(300);
  await page.$eval('.sn-modal .sn-input', el => { el.value = ''; });
  await page.type('.sn-modal .sn-input', 'Coffee-River-Sunset7!', { delay: 0 });
  await sleep(200);
  await clickByText('.sn-modal .sn-btn.primary', 'Save password', 6);
  await sleep(350);
  check('T3 gate open (password)', await gateOpen());
  if (await gateOpen()) { await nextStep(); done++; }

  // ---- Task 4: 2FA (security) — enable authenticator app ----
  await gotoScreen();
  await clickByText('.sn-btn', 'Use authenticator app', 8);
  await sleep(350);
  check('T4 gate open (2FA)', await gateOpen());
  if (await gateOpen()) { await nextStep(); done++; }

  // ---- Task 5: recovery — update recovery email (Settings) + sign out stale session (Login activity) ----
  await gotoScreen(); // -> Settings (security), where recovery email lives
  await clickByText('.sn-btn', 'Update', 8); await sleep(300);
  await page.$eval('.sn-modal .sn-input', el => { el.value = ''; });
  await page.type('.sn-modal .sn-input', 'jordan.new@example.com', { delay: 0 });
  await sleep(150);
  await clickByText('.sn-modal .sn-btn.primary', 'Save', 6);
  await sleep(300);
  // sign out the stale session — this lives on the "Login activity" screen
  await nav('Login activity');
  for (let s = 0; s < 3; s++) {
    const ok = await clickByText('.sn-btn', 'Sign out', 4);
    if (!ok) break;
    await sleep(250);
  }
  check('T5 gate open (recovery & sessions)', await gateOpen());
  if (await gateOpen()) { await nextStep(); done++; }

  // ---- Task 6: apps — remove the two unused, keep the used one ----
  await nav('Connected apps');
  for (const appName of ['QuizMania', 'PhotoFilter']) {
    await page.evaluate((name) => {
      const cards = Array.from(document.querySelectorAll('.sn-card, [class*="sn-app"]'));
      for (const c of cards) {
        if (c.textContent && c.textContent.includes(name)) {
          const btn = Array.from(c.querySelectorAll('button')).find(b => /remove access/i.test(b.textContent));
          if (btn) { btn.click(); return true; }
        }
      }
      return false;
    }, appName);
    await sleep(300);
  }
  check('T6 gate open (connected apps)', await gateOpen());
  if (await gateOpen()) { await nextStep(); done++; }

  // ---- Task 7: theft (activity) — report suspicious activity ----
  await nav('Account activity');
  await clickByText('.sn-btn.danger', 'Report suspicious activity', 8);
  await sleep(350);
  check('T7 gate open (theft)', await gateOpen());
  if (await gateOpen()) { await nextStep(); done++; }

  check('all 7 tasks completed via UI', done === 7, `${done}/7`);

  // summary card
  await sleep(600);
  let summary = await page.$('.byte-summary-title');
  if (!summary) { await sleep(700); summary = await page.$('.byte-summary-title'); }
  check('summary/report card appears', !!summary, summary ? await page.$eval('.byte-summary-title', el => el.textContent) : '');
  const reportRows = await page.$$eval('.byte-report-row', els => els.length).catch(() => 0);
  check('report card lists all 7 tasks', reportRows === 7, `${reportRows} rows`);

  const realErrors = errors.filter(e => e.includes('PAGEERROR'));
  check('no uncaught page errors', realErrors.length === 0, realErrors.slice(0,3).join(' | '));

  await browser.close();
  server.close();
  const passed = results.filter(r => r.pass).length, total = results.length;
  console.log(`\n==================== WALKTHROUGH SUMMARY ====================`);
  console.log(`${passed}/${total} checks passed`);
  results.filter(r => !r.pass).forEach(r => console.log('  FAILED: ' + r.name));
  console.log(`RESULT: ${passed === total ? 'ALL PASS ✓' : 'FAILURES ✗'}`);
  process.exit(passed === total ? 0 : 1);
}
main().catch((e) => { console.error(e); server.close(); process.exit(1); });
