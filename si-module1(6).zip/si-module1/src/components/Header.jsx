import { motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';

function SILogo({ size = 28 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <defs>
        <linearGradient id="siG" x1="0" y1="0" x2="32" y2="32">
          <stop offset="0%"   stopColor="#6d28d9"/>
          <stop offset="60%"  stopColor="#7c3aed"/>
          <stop offset="100%" stopColor="#c026d3"/>
        </linearGradient>
      </defs>
      <path d="M16 2L28 7.5V19.5C28 26.5 16 30.5 16 30.5C16 30.5 4 26.5 4 19.5V7.5L16 2Z"
        fill="url(#siG)"/>
      <text x="16" y="21.5" textAnchor="middle" fontFamily="Inter,sans-serif"
        fontWeight="700" fontSize="10.5" fill="#fff" letterSpacing="-0.3">SI</text>
    </svg>
  );
}

export default function Header({ sidebarOpen, setSidebarOpen, progress }) {
  return (
    <motion.header
      initial={{ y: -58, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 200,
        height: 56,
        background: '#fff',
        borderBottom: '1px solid #e2e4e9',
        display: 'flex', alignItems: 'center',
        padding: '0 20px', gap: 14,
        boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
      }}
    >
      {/* Sidebar toggle */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        style={{
          width: 34, height: 34, borderRadius: 7,
          background: 'transparent', border: '1px solid #e2e4e9',
          color: '#6b7280', cursor: 'pointer', flexShrink: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'all 0.15s',
        }}
        onMouseEnter={e => {
          e.currentTarget.style.background = '#f3f0ff';
          e.currentTarget.style.borderColor = '#c4b5fd';
          e.currentTarget.style.color = '#6d28d9';
        }}
        onMouseLeave={e => {
          e.currentTarget.style.background = 'transparent';
          e.currentTarget.style.borderColor = '#e2e4e9';
          e.currentTarget.style.color = '#6b7280';
        }}
      >
        {sidebarOpen ? <X size={15}/> : <Menu size={15}/>}
      </button>

      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
        <SILogo size={28}/>
        <div>
          <div style={{
            fontFamily: "'Inter', sans-serif", fontWeight: 700, fontSize: 14.5,
            color: '#0f1117', letterSpacing: '-0.02em', lineHeight: 1.2,
          }}>Security Impossible</div>
          <div style={{
            fontFamily: "'DM Mono', monospace", fontSize: 9, color: '#9ca3af',
            letterSpacing: '0.1em', marginTop: 1,
          }}>SECURITY & GOVERNANCE ONBOARDING</div>
        </div>
      </div>

      {/* Divider */}
      <div style={{ width: 1, height: 20, background: '#e2e4e9', flexShrink: 0 }}/>

      <span style={{
        fontFamily: "'DM Mono', monospace", fontSize: 11.5, color: '#9ca3af',
      }}>Onboarding v2.0</span>

      <div style={{ flex: 1 }}/>

      {/* Progress */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '0 14px', height: 34,
        background: '#f8f9fa', border: '1px solid #e2e4e9', borderRadius: 7,
        marginRight: 10,
      }}>
        <span style={{
          fontFamily: "'DM Mono', monospace", fontSize: 10.5,
          color: '#9ca3af', letterSpacing: '0.06em',
        }}>PROGRESS</span>
        <div style={{ width: 80, height: 3, background: '#e2e4e9', borderRadius: 2, overflow: 'hidden' }}>
          <motion.div
            initial={{ width: 0 }} animate={{ width: `${progress}%` }}
            transition={{ duration: 1.1, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
            style={{
              height: '100%', borderRadius: 2,
              background: progress === 100
                ? 'linear-gradient(90deg,#166534,#16a34a)'
                : 'linear-gradient(90deg,#6d28d9,#7c3aed)',
            }}
          />
        </div>
        <span style={{
          fontFamily: "'DM Mono', monospace", fontSize: 11.5, fontWeight: 500,
          color: progress === 100 ? '#166534' : '#6d28d9',
          minWidth: 28, textAlign: 'right',
        }}>{progress}%</span>
      </div>

      {/* User */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '0 12px', height: 34,
        background: '#f8f9fa', border: '1px solid #e2e4e9', borderRadius: 7,
        cursor: 'pointer',
      }}>
        <div style={{
          width: 22, height: 22, borderRadius: '50%',
          background: 'linear-gradient(135deg,#6d28d9,#c026d3)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 9.5, fontWeight: 700, color: '#fff',
        }}>N</div>
        <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: '#6b7280' }}>
          New Employee
        </span>
      </div>
    </motion.header>
  );
}
