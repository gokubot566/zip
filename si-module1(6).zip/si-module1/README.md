# Security Impossible — Module 1: Welcome & Why Security Matters Here

Interactive cybersecurity onboarding platform for Security Impossible Pty Ltd.

## Quick Start

```bash
# Clone / extract the project, then:
docker compose up -d --build

# Access at:
http://localhost:7070
http://<YOUR-AZURE-PUBLIC-IP>:7070
```

## Azure / Cloud Deployment

### 1. Open port 7070 in your NSG (Azure firewall)
- Azure Portal → Virtual Machines → your VM → Networking
- Add inbound port rule: TCP 7070 from Any

### 2. Deploy
```bash
git clone / unzip the project
cd si-module1
docker compose up -d --build
```

### 3. Verify
```bash
docker compose ps          # Check status
docker compose logs -f     # View logs
curl http://localhost:7070/health   # Health check
```

## Structure
```
si-module1/
├── src/
│   ├── App.jsx                   # Root app, layout, progress state
│   ├── main.jsx                  # React entry point
│   └── components/
│       ├── Header.jsx            # Top navigation bar with progress
│       ├── Sidebar.jsx           # Collapsible module navigation
│       ├── WelcomeSection.jsx    # Main content: intro, stats, principles
│       ├── ScenarioCard.jsx      # Interactive scenario (friend question)
│       ├── QuizSection.jsx       # 4-question knowledge check
│       ├── PolicyReferences.jsx  # Expandable policy accordion
│       ├── ByteAssistant.jsx     # Floating AI guide with chat
│       └── Footer.jsx            # Completion CTA + firm info
├── nginx/
│   └── default.conf              # Nginx config (port 7070)
├── Dockerfile                    # Multi-stage Node→nginx build
├── docker-compose.yml            # Single-service compose config
├── vite.config.js                # Vite build config
├── package.json
└── index.html
```

## Features
- Framer Motion animations throughout
- Byte AI assistant with contextual hints and chat
- Interactive scenario with 4 response options and feedback
- 4-question knowledge check with instant feedback and explanations
- Expandable policy reference accordion
- Progress tracking via localStorage (survives page refresh)
- Responsive sidebar with all 11 modules listed
- Header progress bar
- Docker health check on /health endpoint
- Gzip compression, security headers, static asset caching

## Commands
```bash
docker compose up -d --build    # Build and start
docker compose down             # Stop
docker compose restart          # Restart
docker compose logs -f          # Follow logs
docker compose ps               # Status
```
